package define

const (
	GAME_TYPE_YFJ  = 1 //百人
	GAME_TYPE_SLOT = 2 //水果机
	GAME_TYPE_QP   = 3 //棋牌
)

// 游戏循环最多次数
const MAX_LOOP = 50

// 游戏类型定义
const (
	//赏金船长
	CAPTAINSBOUNTY = 66
	//赏金女王
	QUEENOFBOUNTY = 67
	//金老鼠
	MOUSE = 68
	//金牛
	FORTUNEOX = 69
	//金老虎
	TIGER = 70
	//金钱兔
	RABBIT = 71
	//象财神
	GANESHAGOLD = 72
	//雷神消除JACKPOT
	GATESOFOLYMPUS = 73
	//金猪
	PIGGYGOLD = 74
	//寻龙探宝
	DRAGONHATCH = 75
	//冰雪大冲关
	THEGREATICESCAPE = 76
)
