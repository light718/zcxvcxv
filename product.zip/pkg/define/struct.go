package define

import "time"

// 普通下注游戏记录
type RecordBetInfo struct {
	Gameid      int    `db:"gameid"`
	GameNo      string `db:"order_no"`
	UserId      int64  `db:"userid"`
	BetScore    int64  `db:"usecoin"`
	WinScore    int64  `db:"wincoin"`
	ChangeScore int64  `db:"changecoin"`
	Tax         int64  `db:"tax"`
	Time        int64
	BalanceTime time.Time `db:"balancetime"`
	Mark        int       `db:"mark"`
	BfUserCoin  int64     `db:"bfusercoin"`
	AfUserCoin  int64     `db:"afusercoin"`
	RePoolCoin  int64     `db:"repoolcoin"`
	Ip          string    `db:"ip"`
}

//活动投注记录记录
type RecordActivitBetInfo struct {
	ActivityId   int    `db:"activity_id"`
	UserId       int64  `db:"account_id"`
	Account      string `db:"account"`
	GameNo       string `db:"order_no"`
	BetScore     int64  `db:"bet_amount"`
	WinScore     int64  `db:"win_amount"`
	ChangeScore  int64  `db:"change_amount"`
	BfUserBlance int64  `db:"before_blance"`
	AfUserBlance int64  `db:"after_blance"`
	Time         int64
	BetTime      time.Time `db:"bet_time"`
}
