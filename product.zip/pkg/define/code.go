package define

// 登录返回码
const (
	LOGIN_CODE_OK             = 0   //成功
	LOGIN_CODE_REPEAT         = 1   //重复
	LOGIN_CODE_MAINTAIN       = 2   //维护
	LOGIN_CODE_BUSY           = 3   //忙碌
	LOGIN_CODE_EROOR          = 4   //登录错误
	LOGIN_CODE_ACTIVIT_EXPIRE = 5   //活动过期
	LOGIN_CODE_UNKNOW         = 255 //未知
)

// 游戏错误码
const (
	GAME_RESULT_OK               = 0   //无错误
	GAME_RESULT_SCORE_NOT_ENOUGH = 1   //积分不足
	GAME_RESULT_BET_ERROR        = 2   //下注错误
	GAME_RESULT_MAINTAIN         = 3   //游戏维护
	GAME_RESUL_ACTIVIT_NOT_START = 4   //活动未开启
	GAME_RESUL_ACTIVIT_EXPIRE    = 5   //活动过期
	GAME_RESULT_BET_BUSY         = 6   //下注繁忙
	GAME_RESULT_BET_REPEAT       = 7   //重复下注
	GAME_RESULT_UNKNOW           = 255 //未知错误
)

// 房间掩码
const (
	//客户端主动退出房间
	ROOM_MASK_0 = 0
)

// api错误码
const (
	API_BET_RESULT_OK          = 1  //接口成功
	API_BET_RESULT_ERROR       = 2  //接口返回错误
	API_BET_RESULT_PARSE_ERROR = 3  //接口返回解析异常
	API_BET_RESULT_REPEAT      = 13 //接口重复订单
)
