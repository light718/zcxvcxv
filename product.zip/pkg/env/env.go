package env

// 环境
const (
	DEV = iota
	FAT
	UAT
	PRO
)

var Environment = 0
