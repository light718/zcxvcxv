package coroutines

import (
	"reflect"
	"runtime"
	"runtime/debug"

	"github.com/rs/zerolog"
)

type ITaskFunc interface {
	CoroutineTaskFunc(down chan struct{}, fn reflect.Value, args []reflect.Value)
}

type FuncObject struct {
	dispatch bool
	fn       interface{}
	args     []interface{}
}

type CoroutineTask struct {
	c          *Coroutines
	cancel     chan struct{}
	tasks      []FuncObject
	ResultArgs []interface{}
}

type Coroutines struct {
	log      *zerolog.Logger
	tasks    chan *CoroutineTask
	stopChan chan struct{}
	isrv     ITaskFunc
}

// 创建新的协程池
func NewCoroutines(log *zerolog.Logger, i ITaskFunc) *Coroutines {
	cpu := runtime.NumCPU()
	pool := &Coroutines{
		tasks:    make(chan *CoroutineTask, 8192*cpu),
		stopChan: make(chan struct{}),
		log:      log,
		isrv:     i,
	}
	for i := 0; i < 256; i++ {
		go pool.worker()
	}
	return pool
}

// 每个 worker 从任务通道中获取任务并执行
func (p *Coroutines) worker() {
	for {
		select {
		case t := <-p.tasks:
			{
				func() {
					defer func() {
						if err := recover(); err != nil {
							stack := string(debug.Stack())
							p.log.Error().Str("category", "coroutines").Msgf("Coroutines async error:%v", err)
							p.log.Error().Str("category", "coroutines").Msgf(stack)
						}
					}()
					for c := 0; c < len(t.tasks) && len(t.cancel) <= 0; c++ {
						refFunc := reflect.ValueOf(t.tasks[c].fn)
						if refFunc.Kind() != reflect.Func {
							p.log.Error().Str("category", "coroutines").Msgf("not func")
							return
						}
						numArgs := refFunc.Type().NumIn()
						if len(t.tasks[c].args)+1 != numArgs {
							p.log.Error().Str("category", "coroutines").Msgf("param num not same")
							return
						}
						args := make([]reflect.Value, numArgs)
						args[0] = reflect.ValueOf(t)
						for i := 1; i < numArgs; i++ {
							expectedType := refFunc.Type().In(i)
							argValue := reflect.ValueOf(t.tasks[c].args[i-1])
							if argValue.Type() != expectedType {
								if argValue.Type().ConvertibleTo(expectedType) {
									args[i] = argValue.Convert(expectedType)
								} else {
									p.log.Error().Str("category", "coroutines").Msgf("param type not same")
									return
								}
							} else {
								args[i] = argValue
							}
						}
						if t.tasks[c].dispatch {
							down := make(chan struct{})
							p.isrv.CoroutineTaskFunc(down, refFunc, args)
							<-down
						} else {
							refFunc.Call(args)
						}
					}
				}()
			}
		case <-p.stopChan:
			return
		}
	}
}

// 提交异步任务到协程池
func (c *Coroutines) Submit(fn interface{}, args ...interface{}) {
	ct := &CoroutineTask{
		c:      c,
		cancel: make(chan struct{}),
	}
	ct.tasks = append(ct.tasks, FuncObject{
		dispatch: false,
		fn:       fn,
		args:     args,
	})
	c.tasks <- ct
}

// 链式异步任务
func (c *Coroutines) Task(fn interface{}, args ...interface{}) (ct *CoroutineTask) {
	ct = &CoroutineTask{
		c:      c,
		cancel: make(chan struct{}),
	}
	ct.tasks = append(ct.tasks, FuncObject{
		dispatch: false,
		fn:       fn,
		args:     args,
	})
	return
}

// 异步任务
func (t *CoroutineTask) Continue(fn interface{}, args ...interface{}) *CoroutineTask {
	t.tasks = append(t.tasks,
		FuncObject{
			dispatch: false,
			fn:       fn,
			args:     args,
		})
	return t
}

// 主调度器任务
func (t *CoroutineTask) Dispatch(fn interface{}, args ...interface{}) *CoroutineTask {
	t.tasks = append(t.tasks,
		FuncObject{
			dispatch: true,
			fn:       fn,
			args:     args,
		})
	return t
}

// 保存结果
func (t *CoroutineTask) SaveResult(args ...interface{}) {
	//清理旧数据
	t.ResultArgs = make([]interface{}, 0)
	//添加
	t.ResultArgs = append(t.ResultArgs, args...)
}

func (t *CoroutineTask) AppendResult(args ...interface{}) {
	//添加
	t.ResultArgs = append(t.ResultArgs, args...)
}

func (t *CoroutineTask) Cancel() {
	t.cancel <- struct{}{}
}

func (t *CoroutineTask) Run() {
	t.c.tasks <- t
}

// 关闭协程池
func (p *Coroutines) Stop() {
	close(p.stopChan)
	close(p.tasks)
}
