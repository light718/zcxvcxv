package engine

import (
	"database/sql"

	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)

type MySqlEngine struct {
	C *sqlx.DB
}

func NewMySqlEngine(conn string) (engine *MySqlEngine) {
	db, err := sqlx.Connect("mysql", conn)
	if err != nil {
		panic(err)
	}
	db.SetMaxOpenConns(20)
	db.SetMaxIdleConns(10)
	engine = &MySqlEngine{
		C: db,
	}
	return
}

func (e *MySqlEngine) Query(query string, args ...any) (*sql.Rows, error) {
	return e.C.Query(query, args...)
}

func (e *MySqlEngine) QueryRow(query string, args ...any) *sql.Row {
	return e.C.QueryRow(query, args...)
}

func (e *MySqlEngine) In(query string, args ...interface{}) (string, []interface{}, error) {
	return sqlx.In(query, args...)
}

func (e *MySqlEngine) Exec(query string, args ...any) (sql.Result, error) {
	return e.C.Exec(query, args...)
}

func (e *MySqlEngine) NamedExec(query string, arg interface{}) (sql.Result, error) {
	return e.C.NamedExec(query, arg)
}
