package engine

import (
	"context"

	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog"
)

type ISubscribeEvent interface {
	OnSubscribeMessageEvent(channel string, msg string)
}

type PublishMessage struct {
	channel string
	msg     interface{}
}

type RedisEngine struct {
	C          *redis.ClusterClient
	subEvent   ISubscribeEvent
	pubMessage chan PublishMessage
	stop       chan struct{}
	log        *zerolog.Logger
}

func NewRedisEngine(log *zerolog.Logger, subEv ISubscribeEvent, addrs []string, password string, db int) (engine *RedisEngine) {
	c := redis.NewClusterClient(&redis.ClusterOptions{
		Addrs:    addrs,
		Password: password,
	})
	err := c.ForEachShard(context.Background(), func(ctx context.Context, shard *redis.Client) error {
		return shard.Ping(ctx).Err()
	})
	if err != nil {
		panic(err)
	}
	engine = &RedisEngine{
		C:          c,
		subEvent:   subEv,
		stop:       make(chan struct{}),
		pubMessage: make(chan PublishMessage, 8192),
		log:        log,
	}
	return
}

func (engine *RedisEngine) Start() {
	go func(e *RedisEngine) {
	LOOP:
		for {
			select {
			case msg := <-e.pubMessage:
				e.C.Publish(context.Background(), msg.channel, msg.msg)
			case <-e.stop:
				break LOOP
			}
		}
	}(engine)
}

func (engine *RedisEngine) Stop() {
	engine.stop <- struct{}{}
}

func (engine *RedisEngine) NewScript(src string) *redis.Script {
	return redis.NewScript(src)
}

func (engine *RedisEngine) RunScript(script *redis.Script, keys []string, args ...interface{}) (interface{}, error) {
	return script.Run(context.Background(), engine.C, keys, args...).Result()
}

func (engine *RedisEngine) Subscribe(channels ...string) {
	t := engine.C.Subscribe(context.Background(), channels...)
	go func(e *RedisEngine, sub *redis.PubSub) {
		for {
			msg, err := sub.ReceiveMessage(context.Background())
			if err != nil {
				engine.log.Error().Str("category", "engine").Msgf("RedisEngine receive subscribe message error:%v", err)
				break
			}
			e.subEvent.OnSubscribeMessageEvent(msg.Channel, msg.Payload)
		}
	}(engine, t)
}

func (engine *RedisEngine) Publish(channel string, msg interface{}) {
	engine.pubMessage <- PublishMessage{channel: channel, msg: msg}
}
