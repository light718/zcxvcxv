package engine

import (
	"container/heap"
	"time"
)

type TimerItem struct {
	deadline time.Time //过期
	index    int
	id1      int
	id2      int
	id3      int
	id4      int
	id5      int
	para1    interface{}
	para2    interface{}
}

type TimerItems []TimerItem
type TimerHeap struct {
	items TimerItems
}

func NewTimerHeap() (h *TimerHeap) {
	h = &TimerHeap{
		items: make(TimerItems, 0),
	}
	heap.Init(h)
	return
}

func (h TimerHeap) Len() int { return len(h.items) }
func (h TimerHeap) Less(i, j int) bool {
	return h.items[i].deadline.Before(h.items[j].deadline)
}
func (h TimerHeap) Swap(i, j int) {
	h.items[i], h.items[j] = h.items[j], h.items[i]
	h.items[i].index = i
	h.items[j].index = j
}

func (h *TimerHeap) Push(x interface{}) {
	n := len(*&h.items)
	item := x.(TimerItem)
	item.index = n
	*&h.items = append(*&h.items, item)
}

func (h *TimerHeap) Pop() interface{} {
	old := *&h.items
	n := len(old)
	item := old[n-1]
	item.index = -1
	*&h.items = old[0 : n-1]
	return item
}

func (h *TimerHeap) Add(id1, id2, id3, id4, id5 int, expire time.Duration, para1, para2 interface{}) {
	item := TimerItem{
		deadline: time.Now().Add(expire),
		id1:      id1,
		id2:      id2,
		id3:      id3,
		id4:      id4,
		id5:      id5,
		para1:    para1,
		para2:    para2,
	}
	heap.Push(h, item)
}

func (h *TimerHeap) Del(id1, id2, id3, id4, id5 int) {
	for _, v := range h.items {
		if v.id1 == id1 && v.id2 == id2 && v.id3 == id3 && v.id4 == id4 && v.id5 == id5 {
			heap.Remove(h, v.index)
			break
		}
	}
}

func (h *TimerHeap) Fix(id1, id2, id3, id4, id5 int, expire time.Duration) {
	for i := 0; i < len(h.items); i++ {
		if h.items[i].id1 == id1 && h.items[i].id2 == id2 && h.items[i].id3 == id3 && h.items[i].id4 == id4 && h.items[i].id5 == id5 {
			h.items[i].deadline = time.Now().Add(expire)
			heap.Fix(h, h.items[i].index)
			break
		}
	}
}
