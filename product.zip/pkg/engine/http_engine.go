package engine

import (
	"net/http"
	"runtime/debug"
	"sync"
	"sync/atomic"

	"github.com/rs/zerolog"
)

const (
	HTTP_PUSHMASSAGE = iota
)

type IHttpEvent interface {
	HttpMassage(hid int64, msgType int, req *http.Request)
}

type HttpMessage struct {
	Hid     int64
	Content []byte
}

type HttpConnection struct {
	hid  int64
	w    http.ResponseWriter
	down chan struct{}
}

func NewHttpConnection() *HttpConnection {
	return &HttpConnection{
		down: make(chan struct{}),
	}
}

type HttpEngine struct {
	addr       string
	iev        IHttpEvent
	message    chan HttpMessage
	register   chan *HttpConnection
	unregister chan *HttpConnection
	clients    map[int64]*HttpConnection
	pool       *sync.Pool
	stop       chan struct{}
	identity   int64
	log        *zerolog.Logger
}

func NewHttpEngine(log *zerolog.Logger, iev IHttpEvent, addr string) (engine *HttpEngine) {
	engine = &HttpEngine{
		identity:   0,
		log:        log,
		iev:        iev,
		addr:       addr,
		stop:       make(chan struct{}),
		clients:    make(map[int64]*HttpConnection),
		register:   make(chan *HttpConnection, 8192),
		unregister: make(chan *HttpConnection, 8192),
		message:    make(chan HttpMessage, 8192),
		pool: &sync.Pool{
			New: func() interface{} {
				return NewHttpConnection()
			},
		},
	}
	return
}

func (engine *HttpEngine) Start() {
	http.HandleFunc("/pushMassage", engine.PushMassage)
	go http.ListenAndServe(engine.addr, nil)
	go engine.Dispatch()
}

func (engine *HttpEngine) Stop() {
	engine.stop <- struct{}{}
}

func (engine *HttpEngine) Dispatch() bool {
	defer func() {
		if err := recover(); err != nil {
			engine.log.Error().Str("category", "engine").Msgf("HttpEngine error:%v", err)
			engine.log.Error().Str("category", "engine").Msgf(string(debug.Stack()))
		}
	}()
	stop := false
LOOP:
	for {
		select {
		case conn := <-engine.register:
			engine.clients[conn.hid] = conn
		case msg := <-engine.message:
			{
				if conn, ok := engine.clients[msg.Hid]; ok {
					conn.w.Write(msg.Content)
					conn.down <- struct{}{}
				}
			}
		case conn := <-engine.unregister:
			{
				delete(engine.clients, conn.hid)
				engine.pool.Put(conn)
			}
		case <-engine.stop:
			for _, v := range engine.clients {
				v.down <- struct{}{}
			}
			engine.clients = make(map[int64]*HttpConnection)
			stop = true
			break LOOP
		}
	}
	return stop
}

func (engine *HttpEngine) ResponseWriter(hid int64, content []byte) {
	engine.message <- HttpMessage{Hid: hid, Content: content}
}

func (engine *HttpEngine) PushMassage(w http.ResponseWriter, req *http.Request) {
	connection := engine.pool.Get().(*HttpConnection)
	connection.w = w
	connection.hid = atomic.AddInt64(&engine.identity, 1)
	if len(connection.down) > 0 {
		<-connection.down
	}
	engine.iev.HttpMassage(connection.hid, HTTP_PUSHMASSAGE, req)
	engine.register <- connection
	<-connection.down
	engine.unregister <- connection
}
