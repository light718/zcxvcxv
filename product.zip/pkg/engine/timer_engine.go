package engine

import (
	"container/heap"
	"runtime/debug"
	"time"

	"github.com/rs/zerolog"
)

// 上下文事件定义
const (
	TIMER_ENGINE_EVENT_ADD = iota
	TIMER_ENGINE_EVENT_DEL
	TIMER_ENGINE_EVENT_FIX
)

type TimerEngineContext struct {
	//事件类型
	evType int
	//定时器类型ID
	id1 int
	id2 int
	id3 int
	id4 int
	id5 int
	//过期时间
	expire time.Duration
	//附带参数
	para1 interface{}
	para2 interface{}
}

type ITimerEngineEvent interface {
	OnTimerEvent(id1, id2, id3, id4, id5 int, para1, para2 interface{})
}

// 定时器引擎
type TimerEngine struct {
	timerHeap *TimerHeap
	iev       ITimerEngineEvent
	ch        chan TimerEngineContext
	stop      chan struct{}
	log       *zerolog.Logger
}

func NewTimerEngine(log *zerolog.Logger, ev ITimerEngineEvent) (engine *TimerEngine) {
	engine = &TimerEngine{
		iev:       ev,
		timerHeap: NewTimerHeap(),
		ch:        make(chan TimerEngineContext, 16384),
		stop:      make(chan struct{}),
		log:       log,
	}

	return
}

func (engine *TimerEngine) Start() {
	go func(e *TimerEngine) {
		for {
			if stop := e.Dispatch(); stop {
				return
			}
		}
	}(engine)
}

func (engine *TimerEngine) Stop() {
	engine.stop <- struct{}{}
}

func (engine *TimerEngine) Add(id1, id2, id3, id4, id5 int, expire time.Duration, para1, para2 interface{}) {
	engine.ch <- TimerEngineContext{
		evType: TIMER_ENGINE_EVENT_ADD,
		id1:    id1,
		id2:    id2,
		id3:    id3,
		id4:    id4,
		id5:    id5,
		expire: expire,
		para1:  para1,
		para2:  para2,
	}
}

func (engine *TimerEngine) Del(id1, id2, id3, id4, id5 int) {
	engine.ch <- TimerEngineContext{
		evType: TIMER_ENGINE_EVENT_DEL,
		id1:    id1,
		id2:    id2,
		id3:    id3,
		id4:    id4,
		id5:    id5,
	}
}

func (engine *TimerEngine) Fix(id1, id2, id3, id4, id5 int, expire time.Duration) {
	engine.ch <- TimerEngineContext{
		evType: TIMER_ENGINE_EVENT_FIX,
		id1:    id1,
		id2:    id2,
		id3:    id3,
		id4:    id4,
		id5:    id5,
		expire: expire,
	}
}

func (engine *TimerEngine) Dispatch() bool {
	defer func() {
		if err := recover(); err != nil {
			engine.log.Error().Str("category", "engine").Msgf("TimerEngine error:%v", err)
			engine.log.Error().Str("category", "engine").Msgf(string(debug.Stack()))
		}
	}()
	timer := time.NewTimer(time.Millisecond)
	deadline := time.Now()
	stop := false
LOOP:
	for {
		select {
		case ctx := <-engine.ch:
			{
				switch ctx.evType {
				case TIMER_ENGINE_EVENT_ADD:
					engine.timerHeap.Add(ctx.id1, ctx.id2, ctx.id3, ctx.id4, ctx.id5, ctx.expire, ctx.para1, ctx.para2)
				case TIMER_ENGINE_EVENT_DEL:
					engine.timerHeap.Del(ctx.id1, ctx.id2, ctx.id3, ctx.id4, ctx.id5)
				case TIMER_ENGINE_EVENT_FIX:
					engine.timerHeap.Fix(ctx.id1, ctx.id2, ctx.id3, ctx.id4, ctx.id5, ctx.expire)
				}
				if engine.timerHeap.Len() > 0 {
					if !deadline.Equal(engine.timerHeap.items[0].deadline) {
						if !timer.Stop() {
							select {
							case <-timer.C:
							default:
							}
						}
						deadline = engine.timerHeap.items[0].deadline
						timer.Reset(time.Until(engine.timerHeap.items[0].deadline))
					}
				} else {
					if !timer.Stop() {
						select {
						case <-timer.C:
						default:
						}
					}
				}
			}
		case <-timer.C:
			{
				now := time.Now()
				for engine.timerHeap.Len() > 0 {
					item := &engine.timerHeap.items[0]
					if item.deadline.Before(now) {
						engine.iev.OnTimerEvent(item.id1, item.id2, item.id3, item.id4, item.id5, item.para1, item.para2)
						heap.Pop(engine.timerHeap)
					} else {
						break
					}
				}
				if engine.timerHeap.Len() > 0 {
					deadline = engine.timerHeap.items[0].deadline
					timer.Reset(deadline.Sub(now))
				}
			}
		case <-engine.stop:
			{
				stop = true
				if !timer.Stop() {
					select {
					case <-timer.C:
					default:
					}
				}
				break LOOP
			}
		}
	}
	return stop
}
