package engine

import (
	"net"
	"net/http"
	"runtime/debug"
	"strings"
	"sync"
	"sync/atomic"

	"github.com/gorilla/websocket"
	"github.com/rs/zerolog"
)

type IWebSocketEngineEvent interface {
	OnWebSocketConnEvent(sid int64, ip net.IP)
	OnWebSocketRecvEvent(sid int64, message []byte)
	OnWebSocketCloseEvent(sid int64)
}

const (
	//无效会话ID
	INVALID_SID int64 = 0
)

type Message struct {
	Sid     int64
	Content []byte
}

// 会话
type WebSocketConnection struct {
	sid   int64
	conn  *websocket.Conn
	send  chan []byte
	ip    net.IP
	close chan *sync.Pool
	stop  chan struct{}
	log   *zerolog.Logger
}

func NewWebSocketConnection() (c *WebSocketConnection) {
	c = &WebSocketConnection{
		sid:   INVALID_SID,
		send:  make(chan []byte, 16),
		stop:  make(chan struct{}),
		close: make(chan *sync.Pool),
	}
	go c.run()
	return
}

func (c *WebSocketConnection) run() {
	for {
		select {
		case content := <-c.send:
			c.writeMessage(content)
		case pool := <-c.close:
			{
				c.conn.Close()
				c.conn = nil
				pool.Put(c)
			}
		case <-c.stop:
			{
				if c.conn != nil {
					c.conn.Close()
					c.conn = nil
				}
			}
			return
		}
	}
}

func (c *WebSocketConnection) Close(pool *sync.Pool) {
	c.close <- pool
}

func (c *WebSocketConnection) Stop() {
	c.stop <- struct{}{}
}

func (c *WebSocketConnection) writeMessage(content []byte) {
	defer func() {
		if err := recover(); err != nil {
			c.log.Error().Str("category", "engine").Msgf("write message painc error:%v", err)
		}
	}()
	if c.conn == nil {
		return
	}
	if err := c.conn.WriteMessage(websocket.TextMessage, content); err != nil {
		c.log.Error().Str("category", "engine").Msgf("write message error:%v", err)
		return
	}
}

type WebSocketEngine struct {
	//升级处理
	upgrader websocket.Upgrader
	//地址
	addr string
	//接口服务
	iev IWebSocketEngineEvent
	//ID
	identity   int64
	message    chan Message
	register   chan *WebSocketConnection
	unregister chan int64
	pool       *sync.Pool
	clients    map[int64]*WebSocketConnection
	stop       chan struct{}
	log        *zerolog.Logger
}

func NewWebSocketEngine(log *zerolog.Logger, addr string, i IWebSocketEngineEvent) (engine *WebSocketEngine) {
	engine = &WebSocketEngine{
		addr:       addr,
		iev:        i,
		identity:   INVALID_SID,
		clients:    make(map[int64]*WebSocketConnection),
		message:    make(chan Message, 16384),
		register:   make(chan *WebSocketConnection, 8192),
		unregister: make(chan int64, 8192),
		stop:       make(chan struct{}),
		upgrader: websocket.Upgrader{
			CheckOrigin: func(r *http.Request) bool { return true },
		},
		log: log,
		pool: &sync.Pool{
			New: func() any {
				return NewWebSocketConnection()
			},
		},
	}
	http.HandleFunc("/ws", engine.Handler)
	go http.ListenAndServe(addr, nil)
	return
}

func (engine *WebSocketEngine) Dispatch() bool {
	defer func() {
		if err := recover(); err != nil {
			engine.log.Error().Str("category", "engine").Msgf("WebSocketEngine error:%v", err)
			engine.log.Error().Str("category", "engine").Msgf(string(debug.Stack()))
		}
	}()
	stop := false
LOOP:
	for {
		select {
		case conn := <-engine.register:
			engine.clients[conn.sid] = conn
		case sid := <-engine.unregister:
			if conn, ok := engine.clients[sid]; ok {
				conn.Close(engine.pool)
			}
			delete(engine.clients, sid)
		case msg := <-engine.message:
			if conn, ok := engine.clients[msg.Sid]; ok {
				conn.send <- msg.Content
			}
		case <-engine.stop:
			for _, v := range engine.clients {
				v.Stop()
			}
			engine.clients = make(map[int64]*WebSocketConnection)
			stop = true
			break LOOP
		}
	}
	return stop
}

func (engine *WebSocketEngine) Start() {
	go func(e *WebSocketEngine) {
		for {
			if stop := e.Dispatch(); stop {
				return
			}
		}
	}(engine)
}

// 停止
func (engine *WebSocketEngine) Stop() {
	engine.stop <- struct{}{}
}

// 连接处理
func (engine *WebSocketEngine) Handler(w http.ResponseWriter, r *http.Request) {
	c, err := engine.upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	defer c.Close()
	connection := engine.pool.Get().(*WebSocketConnection)
	connection.log = engine.log
	connection.sid = atomic.AddInt64(&engine.identity, 1)
	connection.conn = c
	if r.RemoteAddr != "" {
		arrs := strings.Split(r.RemoteAddr, ":")
		if len(arrs) > 0 {
			connection.ip = net.ParseIP(arrs[0])
		}
	}
	engine.register <- connection
	engine.iev.OnWebSocketConnEvent(connection.sid, connection.ip)
	engine.handleReads(connection)
	engine.iev.OnWebSocketCloseEvent(connection.sid)
	engine.unregister <- connection.sid
}

func (engine *WebSocketEngine) handleReads(connection *WebSocketConnection) {
	for {
		messageType, message, err := connection.conn.ReadMessage()
		if err != nil {
			break
		}
		if messageType == websocket.TextMessage {
			engine.iev.OnWebSocketRecvEvent(connection.sid, message)
		}
	}
}

// 发送接口
func (engine *WebSocketEngine) Send(sid int64, content []byte) {
	engine.message <- Message{Sid: sid, Content: content}
}

// 关闭会话
func (engine *WebSocketEngine) Close(sid int64) {
	engine.unregister <- sid
}
