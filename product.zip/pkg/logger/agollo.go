package logger

import "github.com/rs/zerolog"

type agolloLogger struct {
	log *zerolog.Logger
}

func (p *agolloLogger) Infof(format string, args ...interface{}) {
	p.log.Info().Str("category", "agollo").Msgf(format, args...)
}
func (p *agolloLogger) Errorf(format string, args ...interface{}) {
	p.log.Error().Str("category", "agollo").Msgf(format, args...)
}

func NewAgolloLogger(log *zerolog.Logger) *agolloLogger {
	return &agolloLogger{
		log: log,
	}
}
