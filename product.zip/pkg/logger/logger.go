package logger

import (
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/rs/zerolog"
)

var log zerolog.Logger

func NewZerolog(bJson bool) *zerolog.Logger {
	zerolog.TimeFieldFormat = time.DateTime
	if bJson {
		log = zerolog.New(os.Stdout).
			With().
			Timestamp().
			Caller().
			Int("pid", os.Getegid()).
			Logger()
	}
	output := zerolog.ConsoleWriter{Out: os.Stdout, TimeFormat: time.DateTime}
	output.FormatLevel = func(i interface{}) string {
		return strings.ToUpper(fmt.Sprintf("| %-6s|", i))
	}
	output.FormatMessage = func(i interface{}) string {
		return fmt.Sprintf("%s", i)
	}
	output.FormatFieldName = func(i interface{}) string {
		return fmt.Sprintf("%s:", i)
	}
	output.FormatFieldValue = func(i interface{}) string {
		return fmt.Sprintf("%s", i)
	}
	log = zerolog.New(output).With().Timestamp().Logger()
	return &log
}
