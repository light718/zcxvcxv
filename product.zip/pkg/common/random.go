package common

import (
	"math/rand"
)

// 计算权重
func CalcWeight(random *rand.Rand, arr []int) int {
	sum := 0
	for i := 0; i < len(arr); i++ {
		sum += arr[i]
	}
	value := random.Intn(sum)
	for i := 0; i < len(arr); i++ {
		if value < arr[i] {
			return i
		}
		value -= arr[i]
	}
	return 0
}

// 洗牌
func Shuffle(random *rand.Rand, arr []int) {
	random.Shuffle(len(arr), func(i, j int) {
		arr[i], arr[j] = arr[j], arr[i]
	})
}

// 随机取个值
func RandValue(random *rand.Rand, arrs []int) int {
	i := random.Intn(len(arrs))
	return arrs[i]
}

// 获取区间某个值 [begin,end]
func RandRangeValue(random *rand.Rand, begin, end int) int {
	return random.Intn(end-begin+1) + begin
}

// 围绕指定中心点center、在给定半径radius范围内的随机(即某个值的范围内波动)
// center ± radius
func RandRangeF64(random *rand.Rand, center, radius float64) float64 {
	return center + (random.Float64()*2-1)*radius
}

// 随机取索引
func RandIndex(random *rand.Rand, arrs []int) int {
	return random.Intn(len(arrs))
}

// 随机值 [)
func RandInt(random *rand.Rand, n int) int {
	return random.Intn(n)
}
