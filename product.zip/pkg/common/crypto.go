package common

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
)

var ApiPublicKey = `-----BEGIN public key-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCqTf9ohCHURPjufIITpA6z/gs4R
pXvgt5/CBgRyQIDF66RL+uVgNrwLvmubgeYVygEtqMOfAvrX2YWcJwaw6A3yfmau9
LvbhZ18InRmpWtXvrxguyje/Fv01NUM42jKRB2FepAn6FQRbaVXVnmScCOzWTSMgO
5rrdmt4o9LCTgBwIDAQAB
-----END public key-----`

// 对数据进行加密操作
func EncyptogRSA(src []byte) ([]byte, error) {
	block, _ := pem.Decode([]byte(ApiPublicKey))
	keyInit, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	pubKey := keyInit.(*rsa.PublicKey)
	encryptedChunks := make([]byte, 0)
	// 因为用的是1024key，最多只允许127字节，所以对加密数据过长的源数据进行分段加密
	chunkSize := 1024/8 - 11 // 每个块的大小
	for len(src) > 0 {
		end := chunkSize
		if len(src) < chunkSize {
			end = len(src)
		}
		chunk, err := rsa.EncryptPKCS1v15(rand.Reader, pubKey, src[:end])
		if err != nil {
			return nil, err
		}
		encryptedChunks = append(encryptedChunks, chunk...)
		src = src[end:]
	}
	return encryptedChunks, nil
}
