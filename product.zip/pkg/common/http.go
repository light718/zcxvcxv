package common

import (
	"bytes"
	"io"
	"net/http"
	"time"
)

// http Post请求
// 自定义头和超时
func Post(url string, header map[string]string, datas []byte, timeout time.Duration) ([]byte, error) {
	reqClient := http.Client{Timeout: timeout}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(datas))
	if err != nil {
		return nil, err
	}
	for k, v := range header {
		req.Header.Set(k, v)
	}
	resp, err := reqClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return io.ReadAll(resp.Body)
}
