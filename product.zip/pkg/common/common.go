package common

import "math"

// SetBit 将整数 n 的第 i 位设置为 1
func SetBit(n int, i int) int {
	return n | (1 << i)
}

// IsBitSet 检查整数 n 的第 i 位是否已经置1
func IsBitSet(n int, i int) bool {
	return n&(1<<i) != 0
}

//取不超过大小范围的值
func CheckValueF64(value, min, max float64) float64 {
	if min <= max {
		return math.Min(math.Max(value, min), max)
	} else {
		return math.Min(math.Max(value, max), min)
	}
}
