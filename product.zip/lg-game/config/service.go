package config

import (
	"os"

	"gopkg.in/yaml.v3"
)

type ServiceApp struct {
	Env       string `yaml:"env"`
	WsAddr    string `yaml:"wsaddr"`
	MysqlConn string `yaml:"mysqlconn"`
	Api       struct {
		Blance        string `yaml:"blance"`
		Bet           string `yaml:"bet"`
		BlanceTimeout int    `yaml:"blancetimeout"`
		BetTimeout    int    `yaml:"bettimeout"`
	} `yaml:"api"`
	Redis struct {
		Addrs    []string `yaml:"addrs"`
		Password string   `yaml:"password"`
		Db       int      `yaml:"db"`
	} `yaml:"redis"`
	ConnTimeout int `yaml:"conntimeout"`
}

func NewConfigWithLocal() (c *ServiceApp) {
	c = &ServiceApp{}
	bytes, err := os.ReadFile("./config.yaml")
	if err == nil {
		err = yaml.Unmarshal(bytes, c)
		if err != nil {
			panic(err)
		}
	} else {
		panic(err)
	}
	return
}

func NewConfig(strContent string) (c *ServiceApp) {
	c = &ServiceApp{}
	err := yaml.Unmarshal([]byte(strContent), c)
	if err != nil {
		panic(err)
	}
	return
}
