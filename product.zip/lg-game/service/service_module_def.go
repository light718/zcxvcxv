package service

// ////////////////////////////////////////
// 定时器ID主模块定义
const (
	ITIMER_MODULE_SERVICE = iota
	ITIMER_MODULE_LOGIC
)

// 服务模块定时器子模块
const (
	ITIMER_SERVICE_CHECK_REDIS_PING = iota
	ITIMER_SERVICE_CHECK_NET_TIMEOUT
	ITIMER_SERVICE_REGISTER
)

// 逻辑模块定时器子模块
const (
	ITIMER_LOGIC_ROOM = iota
	ITIMER_LOGIC_UPDATE_GAME_RECORD
	ITIMER_LOGIC_CHECK_GAME_SETTING
	ITIMER_LOGIC_SYNC_GAME_WINPOOL
)

// ///////////////////////////////////////
// 自定义ID主模块定义
const (
	COSTOM_MODULE_SERVICE = iota
	COSTOM_MODULE_LOGIC
)

// 自定义消息服务子模块定义
const (
	COSTOM_SERVICE_UNKNOW = iota
)

// 自定义消息逻辑子模块定义
const (
	COSTOM_LOGIC_LOGIN_CHECK_COMPLETION = iota
	COSTOM_LOGIC_CHECK_GAMEING_SETTING
	COSTOM_LOGIC_ROOM
)
