package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game73"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

type Desk73 struct {
	Desk
	config *game73.GameConfig //游戏配置
	betidx int                //下注配置的索引
	result game73.GameResult  //游戏结果
}

// 初始化
func NewDeskGame73(id, max_seat int, room *Room) (d *Desk73) {
	d = &Desk73{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx: 0,
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk73) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk73) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk73) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入
func (d *Desk73) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game73.GameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game73.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game73.GAME_MODE_NORMAL, &sence.Buffer)
	sence.BetIndex = d.betidx
	sence.JkPools = d.GetJackpot()
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
}

// 游戏消息
func (d *Desk73) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game73.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game73.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {
				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk73, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	case game73.SUB_GAME_JACKPOT_REQ:
		{
			//奖池请求
			resp := &game73.GameJackpotResp{
				ProtocolBase: protocol.ProtocolBase{
					MainCmd: protocol.MAIN_GAME,
					SubCmd:  game73.SUB_GAME_JACKPOT_RESP,
				},
			}
			resp.JkPools = d.GetJackpot()
			if datas, err := json.Marshal(resp); err == nil {
				d.SendData(sid, datas)
			}
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// //////////////////////////////////////////////////////////////////////

// 转换
func (d *Desk73) ConvertBuffer(dec *[10]int, src *[game73.ROW_DEF][game73.COL_DEF]int) {
	idex := 0
	for col := 0; col < game73.COL_DEF; col++ {
		for row := 0; row < game73.ROW_DEF; row++ {
			if col == 0 || col == 2 {
				if row == 3 {
					continue
				}
			}
			dec[idex] = src[row][col]
			idex++
		}
	}
}

// 必输的
func (d *Desk73) RandMustLoseBuffer(buff *[game73.BUFF_SIZE]int) {
	arrs := []int{}
	for i := game73.GAME_SOLT_1; i < game73.GAME_SOLT_MULT; i++ {
		arrs = append(arrs, i)
	}
	idx := 0
	common.Shuffle(d.Random(), arrs)
	for i := 0; i < 10; i++ {
		buff[i] = arrs[idx]
		idx++
	}
	idx = 0
	common.Shuffle(d.Random(), arrs)
	for i := 10; i < 20; i++ {
		buff[i] = arrs[idx]
		idx++
	}
	idx = 0
	common.Shuffle(d.Random(), arrs)
	for i := 20; i < 30; i++ {
		buff[i] = arrs[idx]
		idx++
	}
}

// 随机图案
func (d *Desk73) RandBuffer(mode int, buff *[game73.BUFF_SIZE]int) {
	if mode == game73.GAME_MODE_NORMAL {
		for col := 0; col < game73.COL_DEF; col++ {
			for row := 0; row < game73.ROW_DEF; row++ {
				idx := row*game73.COL_DEF + col
				buff[idx] = common.CalcWeight(d.Random(), d.config.Weight[col]) + 1
				if buff[idx] == game73.GAME_SOLT_MULT {
					//一百以上是实际的倍率
					buff[idx] = 100 + common.CalcWeight(d.Random(), d.config.Mult[col]) + 2
				}
			}
		}
	} else {
		idx := common.CalcWeight(d.Random(), d.config.Jackpot)
		count := 0
		switch idx {
		case 0:
			count = common.RandRangeValue(d.Random(), 8, 10)
		case 1:
			count = common.RandRangeValue(d.Random(), 11, 13)
		case 2:
			count = common.RandRangeValue(d.Random(), 14, 16)
		case 3:
			count = common.RandRangeValue(d.Random(), 17, 20)
		case 4:
			count = common.RandRangeValue(d.Random(), 20, 30)
		}
		arrs := []int{}
		for i := 0; i < game73.BUFF_SIZE; i++ {
			arrs = append(arrs, i)
		}
		common.Shuffle(d.Random(), arrs)
		for i := 0; i < count; i++ {
			idx := arrs[i]
			buff[idx] = game73.GAME_SOLT_JACKPOT
		}
		for col := 0; col < game73.COL_DEF; col++ {
			for row := 0; row < game73.ROW_DEF; row++ {
				idx := row*game73.COL_DEF + col
				if buff[idx] != game73.GAME_SOLT_EMPTY {
					continue
				}
				tmp := []int{}
				tmp = append(tmp, d.config.Weight[col]...)
				tmp[game73.GAME_SOLT_JACKPOT-1] = 0
				//出图
				buff[idx] = common.CalcWeight(d.Random(), tmp) + 1
				if buff[idx] == game73.GAME_SOLT_MULT {
					//一百以上是实际的倍率
					buff[idx] = 100 + common.CalcWeight(d.Random(), d.config.Mult[col]) + 2
				}
			}
		}
	}
}

// 获得倍率
func (d *Desk73) GetTypeMult(soltType int, count int) float64 {
	if mp, ok := game73.Mult[soltType]; ok {
		if val, exist := mp[count]; exist {
			return val
		}
	}
	return 0
}

// 处理下注逻辑
func (d *Desk73) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "gbet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game73.LINE_COUNT
	//回复下注结果
	gameResult := game73.GameResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game73.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//加入奖池
	if d.config.JkPoolPercent > 0 {
		d.AddJackpot(betScore * d.config.JkPoolPercent / 100)
	}
	//出图
	gameResult.Wins = d.DoBuffer(addPool, betScore, calcScore, &gameResult)
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.JkBonus + gameResult.Wins,
		ChangeScore: gameResult.JkBonus + gameResult.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.JkBonus + gameResult.Wins,
		ChangeScore: gameResult.JkBonus + gameResult.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.JkBonus + gameResult.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk73, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()

}

// 随机游戏
func (d *Desk73) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk73) DoBuffer(addPool, betScore, calcScore int64, result *game73.GameResult) (totalScore int64) {
	loop := 0
	var shape [game73.BUFF_SIZE]int //图案
	for ; loop < define.MAX_LOOP; loop++ {
		//游戏总分
		totalScore = 0
		result.DTime = 0
		result.JkBonus = 0
		result.Multiple = 0
		result.RoundList = make([]*game73.RoundInfo, 0)
		//随机游戏
		mode := d.RandGame(d.config.GameWeight)
		shape = [game73.BUFF_SIZE]int{}
		d.RandBuffer(mode, &shape)
		result.Shape = shape
		for {
			roundInfo := d.CalcScore(calcScore, &shape)
			if roundInfo == nil {
				break
			}
			result.Multiple += roundInfo.Multiple
			result.RoundList = append(result.RoundList, roundInfo)
			d.RandDropBuffer(mode, roundInfo, &shape)
		}
		for i := 0; i < game73.BUFF_SIZE; i++ {
			//对应客户端的图标
			if shape[i] > 100 {
				result.DTime += (shape[i] - 100)
			}
		}
		totalScore = int64(float64(calcScore) * result.Multiple * float64(result.DTime))
		if mode == game73.GAME_MODE_NORMAL {
			mult := d.GetTypeMult(game73.GAME_SOLT_JACKPOT, d.GetJackpotCount(&shape))
			if mult > 0 {
				continue
			}
		}
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		totalScore = 0
		result.DTime = 0
		result.JkBonus = 0
		result.Multiple = 0
		result.RoundList = make([]*game73.RoundInfo, 0)
		d.RandMustLoseBuffer(&result.Shape)
	} else {
		pct := d.GetTypeMult(game73.GAME_SOLT_JACKPOT, d.GetJackpotCount(&shape))
		if pct > 0 {
			result.JkBonus = d.SubJackpotByPct(int(pct))
		}
	}
	return
}

// 计算弹窗提示
func (d *Desk73) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk73) CalcScore(calcScore int64, buff *[game73.BUFF_SIZE]int) (roundInfo *game73.RoundInfo) {
	mp := map[int][]int{}
	for i := 0; i < game73.BUFF_SIZE; i++ {
		mp[buff[i]] = append(mp[buff[i]], i)
	}
	for k, v := range mp {
		if k >= 100 || k == game73.GAME_SOLT_JACKPOT {
			continue
		}
		multiple := d.GetTypeMult(k, len(v))
		if multiple > 0 {
			//新建对象
			if roundInfo == nil {
				roundInfo = &game73.RoundInfo{
					Remove: make([]int, 0),
					Add:    make([]game73.LineIcon, 0),
					Prize:  make([]game73.Prize, 0),
				}
			}
			//消除
			roundInfo.Remove = append(roundInfo.Remove, v...)
			//价格
			roundInfo.Prize = append(roundInfo.Prize, game73.Prize{
				Icon:     k,
				Count:    len(v),
				Type:     1,
				Value:    int64(multiple * float64(calcScore)),
				Multiple: multiple,
			})
			//倍数
			roundInfo.Multiple += multiple
		}
	}
	return
}

// 随机掉落的图案
func (d *Desk73) RandDropBuffer(mode int, roundInfo *game73.RoundInfo, buff *[game73.BUFF_SIZE]int) {
	//消除
	for _, v := range roundInfo.Remove {
		buff[v] = game73.GAME_SOLT_EMPTY
	}
	//掉落
	for col := 0; col < game73.COL_DEF; col++ {
		//列缓存
		colarrs := []int{}
		for row := 0; row < game73.ROW_DEF; row++ {
			idx := row*game73.COL_DEF + col
			if buff[idx] != game73.GAME_SOLT_EMPTY {
				colarrs = append(colarrs, buff[idx])
			}
		}
		dropCount := game73.ROW_DEF - len(colarrs)
		for i := 0; i < dropCount; i++ {
			colarrs = append([]int{game73.GAME_SOLT_EMPTY}, colarrs...)
		}
		if dropCount > 0 {
			lineIcon := game73.LineIcon{
				Column: col + 1,
				Icon:   make([]int, 0),
			}
			for row := 0; row < game73.ROW_DEF; row++ {
				idx := row*game73.COL_DEF + col
				if colarrs[row] == game73.GAME_SOLT_EMPTY {
					slotType := 0
					if mode == game73.GAME_MODE_SPECIAL {
						//禁止再掉出jackpot图标
						tmp := []int{}
						tmp = append(tmp, d.config.DropWeight[col]...)
						tmp[game73.GAME_SOLT_JACKPOT-1] = 0
						slotType = common.CalcWeight(d.Random(), tmp) + 1
					} else {
						slotType = common.CalcWeight(d.Random(), d.config.DropWeight[col]) + 1
					}
					if slotType == game73.GAME_SOLT_MULT {
						slotType = 100 + common.CalcWeight(d.Random(), d.config.Mult[col]) + 2
					}
					lineIcon.Icon = append([]int{slotType}, lineIcon.Icon...)
					colarrs[row] = slotType
				}
				buff[idx] = colarrs[row]
			}
			roundInfo.Add = append(roundInfo.Add, lineIcon)
		}
	}
}

func (d *Desk73) GetJackpotCount(buff *[game73.BUFF_SIZE]int) int {
	count := 0
	for i := 0; i < game73.BUFF_SIZE; i++ {
		if buff[i] == game73.GAME_SOLT_JACKPOT {
			count++
		}
	}
	return count
}
