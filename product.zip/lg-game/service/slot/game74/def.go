package game74

import "t77/lg/service/protocol"

/*
游戏ID:74
游戏名字：金猪
*/

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE    = 0 //场景协议
	SUB_GAME_BET_REQ  = 1 //下注请求
	SUB_GAME_BET_RESP = 2 //下注返回
)

// 常数定义
const (
	//3行
	ROW_DEF = 1
	//3列
	COL_DEF = 3
	//缓存大小
	BUFF_SIZE = ROW_DEF * COL_DEF
	// 线数定义
	LINE_COUNT = 1
	//免费最大缓存
	MAX_FREE_CACHE = 5
)

// 游戏图标定义
const (
	GAME_SOLT_ANY = iota - 1
	GAME_SOLT_EMPTY
	GAME_SOLT_1
	GAME_SOLT_2
	GAME_SOLT_3
	GAME_SOLT_4
	GAME_SOLT_5
	GAME_SOLT_6
	GAME_SOLT_WILD
	GAME_SOLT_WILD_2
	GAME_SOLT_WILD_5
	GAME_SOLT_WILD_10
)

// 游戏赔率定义
const (
	GAME_SOLT_ANY_MULT  = 3
	GAME_SOLT_1_MULT    = 5
	GAME_SOLT_2_MULT    = 8
	GAME_SOLT_3_MULT    = 10
	GAME_SOLT_4_MULT    = 15
	GAME_SOLT_5_MULT    = 20
	GAME_SOLT_6_MULT    = 50
	GAME_SOLT_WILD_MULT = 500
)

// 游戏模式定义
const (
	GAME_MODE_NORMAL = iota
	GAME_MODE_SPECIAL
)

// 游戏配置结构
type GameConfig struct {
	Version    int     `yaml:"Version"`
	Rtp        float64 `yaml:"Rtp"`
	BetConfig  []int64 `yaml:"BetConfig"`
	GameWeight []int   `yaml:"GameWeight"`
	Normal     [][]int `yaml:"Normal"`
	Special    struct {
		Select []int         `yaml:"Select"`
		Fill   map[int][]int `yaml:"Fill"`
	} `yaml:"Special"`
	WinMultTip map[int]int64 `yaml:"WinMultTip"`
}

// //////////////////////////
// 场景协议
type GameGameSence struct {
	protocol.ProtocolBase
	Buffer    [BUFF_SIZE]int `json:"Buffer"`
	BetConfig []int64        `json:"BetConfig"`
	BetIndex  int            `json:"BetIndex"`
	Version   int            `json:"Version"`
}

// //////////////////////////
// 下注请求
type GameBetReq struct {
	protocol.ProtocolBase
	BetIndex int `json:"BetIndex"`
	Change   int `json:"Change"`
}

// //////////////////////////
type Prize struct {
	/** 图标ID */
	Icon int `json:"iconId"`
	/** 值 */
	PriceValue int64 `json:"priceValue"`
	/** 图标个数 */
	PriceCount [BUFF_SIZE]int `json:"priceCount"`
	/** 位置 */
	Position [BUFF_SIZE]int `json:"position"`
	/** 线ID */
	BelongLine int `json:"belongLine"`
	/** 赔率 */
	PeiLv int `json:"peiLv"`
}

type RoundInfo struct {
	/** 图案 */
	CurrentShape [BUFF_SIZE]int `json:"currentShape"`
	/** 是否是金猪模式 */
	JinZhuMode bool `json:"jinZhuMode"`
}

type CalcSlotGameInfo struct {
	/** 游戏结果 */
	Result int `json:"result"`
	/** 图案列表 */
	RoundList []RoundInfo `json:"roundList"`
	/** int 1 小奖 2 中奖 3大奖 4巨奖 */
	PriceType int `json:"priceType"`
	/** Long 中奖 */
	LotterySize int64 `json:"lotterySize"`
	/** 奖励信息 */
	PriceList []Prize `json:"priceList"`
	/** 金猪模式 */
	JinZhuMode bool `json:"jinZhuMode"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
}

type GameResult struct {
	protocol.ProtocolBase
	/** 游戏信息 */
	GameInfo CalcSlotGameInfo `json:"gameInfo"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 本局赢得钱 */
	Win int64 `json:"win"`
	/** 玩家最新分数 */
	Points int64 `json:"points"`
	/** 游戏结果 */
	Result int `json:"result"`
}
