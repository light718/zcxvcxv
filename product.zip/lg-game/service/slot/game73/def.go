package game73

import "t77/lg/service/protocol"

/*
游戏ID:73
游戏名字：雷神消除jackpot
*/

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE        = 0 //场景协议
	SUB_GAME_BET_REQ      = 1 //下注请求
	SUB_GAME_BET_RESP     = 2 //下注返回
	SUB_GAME_JACKPOT_REQ  = 3 //奖池请求
	SUB_GAME_JACKPOT_RESP = 4 //奖池回复
)

// 常数定义
const (
	//行
	ROW_DEF = 5
	//列
	COL_DEF = 6
	//缓存大小
	BUFF_SIZE = ROW_DEF * COL_DEF
	// 线数定义
	LINE_COUNT = 1
	//免费最大缓存
	MAX_FREE_CACHE = 5
)

// 游戏图标定义
const (
	GAME_SOLT_EMPTY = iota
	GAME_SOLT_1
	GAME_SOLT_2
	GAME_SOLT_3
	GAME_SOLT_4
	GAME_SOLT_5
	GAME_SOLT_6
	GAME_SOLT_7
	GAME_SOLT_8
	GAME_SOLT_9
	GAME_SOLT_10
	GAME_SOLT_MULT
	GAME_SOLT_JACKPOT
)

// 游戏模式定义
const (
	GAME_MODE_NORMAL = iota
	GAME_MODE_SPECIAL
)

// 游戏配置结构
type GameConfig struct {
	Version       int           `yaml:"Version"`
	BetConfig     []int64       `yaml:"BetConfig"`
	GameWeight    []int         `yaml:"GameWeight"`
	JkPoolPercent int64         `yaml:"JkPoolPercent"`
	Weight        [][]int       `yaml:"Weight"`
	DropWeight    [][]int       `yaml:"DropWeight"`
	Mult          [][]int       `yaml:"Mult"`
	WinMultTip    map[int]int64 `yaml:"WinMultTip"`
	Jackpot       []int         `yaml:"Jackpot"`
}

// //////////////////////////
// 场景协议
type GameSence struct {
	protocol.ProtocolBase
	Buffer    [BUFF_SIZE]int `json:"Buffer"`
	BetConfig []int64        `json:"BetConfig"`
	BetIndex  int            `json:"BetIndex"`
	Version   int            `json:"Version"`
	/**当前jackpot彩金池 */
	JkPools int64 `json:"jkPools"`
}

// //////////////////////////
// 下注请求
type GameBetReq struct {
	protocol.ProtocolBase
	BetIndex int `json:"BetIndex"`
	Change   int `json:"Change"`
}

type GameJackpotReq struct {
	protocol.ProtocolBase
}

type GameJackpotResp struct {
	protocol.ProtocolBase
	JkPools int64 `json:"jkPools"`
}

// //////////////////////////
type Prize struct {
	/** 图标ID */
	Icon int `json:"icon"`
	/** 图标个数 */
	Count int `json:"count"`
	/** 奖励类型 1=普通中奖,2=免费,3=翻倍 */
	Type int `json:"type"`
	/** 值 */
	Value int64 `json:"value"`
	/** 当前回合获奖倍数 */
	Multiple float64 `json:"multiple"`
}

/**信息 */
type LineIcon struct {
	/**哪一列 */
	Column int `json:"row"`
	/**哪些图标 */
	Icon []int `json:"icon"`
}

type RoundInfo struct {
	/** 当前回合获奖倍数 */
	Multiple float64 `json:"multiple"`
	/**免费次数 */
	FTime int `json:"fTime"`
	/**翻倍 */
	DTime int `json:"dTime"`
	/**需要消除的位置列表,从左到右从上到下 */
	Remove []int `json:"remove"`
	/**掉落信息 */
	Add []LineIcon `json:"add"`
	/** 奖励信息 */
	Prize []Prize `json:"prize"`
}

type GameResult struct {
	protocol.ProtocolBase
	/** 游戏结果 */
	Result int `json:"result"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 倍率 */
	Multiple float64 `json:"multiple"`
	/**免费次数 */
	FTime int `json:"fTime"`
	/**翻倍 */
	DTime int `json:"dTime"`
	/** 初始图案从左到右从上到下总共15个 */
	Shape [BUFF_SIZE]int `json:"shape"`
	/** 回合信息 */
	RoundList []*RoundInfo `json:"roundList"`
	/**获得jackpot彩金池奖金*/
	JkBonus int64 `json:"jkBonus"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 玩家最新分数 */
	Points int64 `json:"points"`
	/**当前jackpot彩金池 */
	JkPools int64 `json:"jkPools"`
}

// 赔率表
var Mult = map[int]map[int]float64{
	GAME_SOLT_1: {
		8:  0.25,
		9:  0.25,
		10: 0.25,
		//
		11: 0.75,
		12: 0.75,
		13: 0.75,
		//
		14: 1.50,
		15: 1.50,
		16: 1.50,
		//
		17: 3.0,
		18: 3.0,
		19: 3.0,
		20: 3.0,
		//
		21: 5.0,
		22: 5.0,
		23: 5.0,
		24: 5.0,
		25: 5.0,
		26: 5.0,
		27: 5.0,
		28: 5.0,
		29: 5.0,
		30: 5.0,
	},
	GAME_SOLT_2: {
		8:  0.4,
		9:  0.4,
		10: 0.4,
		//
		11: 1.2,
		12: 1.2,
		13: 1.2,
		//
		14: 2.4,
		15: 2.4,
		16: 2.4,
		//
		17: 4.8,
		18: 4.8,
		19: 4.8,
		20: 4.8,
		//
		21: 8.0,
		22: 8.0,
		23: 8.0,
		24: 8.0,
		25: 8.0,
		26: 8.0,
		27: 8.0,
		28: 8.0,
		29: 8.0,
		30: 8.0,
	},
	GAME_SOLT_3: {
		8:  0.5,
		9:  0.5,
		10: 0.5,
		//
		11: 1.5,
		12: 1.5,
		13: 1.5,
		//
		14: 3.0,
		15: 3.0,
		16: 3.0,
		//
		17: 6.0,
		18: 6.0,
		19: 6.0,
		20: 6.0,
		//
		21: 10.0,
		22: 10.0,
		23: 10.0,
		24: 10.0,
		25: 10.0,
		26: 10.0,
		27: 10.0,
		28: 10.0,
		29: 10.0,
		30: 10.0,
	},
	GAME_SOLT_4: {
		8:  0.8,
		9:  0.8,
		10: 0.8,
		//
		11: 2.4,
		12: 2.4,
		13: 2.4,
		//
		14: 4.8,
		15: 4.8,
		16: 4.8,
		//
		17: 9.6,
		18: 9.6,
		19: 9.6,
		20: 9.6,
		//
		21: 16.0,
		22: 16.0,
		23: 16.0,
		24: 16.0,
		25: 16.0,
		26: 16.0,
		27: 16.0,
		28: 16.0,
		29: 16.0,
		30: 16.0,
	},
	GAME_SOLT_5: {
		8:  1.0,
		9:  1.0,
		10: 1.0,
		//
		11: 3.0,
		12: 3.0,
		13: 3.0,
		//
		14: 6.0,
		15: 6.0,
		16: 6.0,
		//
		17: 12.0,
		18: 12.0,
		19: 12.0,
		20: 12.0,
		//
		21: 20.0,
		22: 20.0,
		23: 20.0,
		24: 20.0,
		25: 20.0,
		26: 20.0,
		27: 20.0,
		28: 20.0,
		29: 20.0,
		30: 20.0,
	},
	GAME_SOLT_6: {
		8:  1.5,
		9:  1.5,
		10: 1.5,
		//
		11: 4.5,
		12: 4.5,
		13: 4.5,
		//
		14: 9.0,
		15: 9.0,
		16: 9.0,
		//
		17: 18.0,
		18: 18.0,
		19: 18.0,
		20: 18.0,
		//
		21: 30.0,
		22: 30.0,
		23: 30.0,
		24: 30.0,
		25: 30.0,
		26: 30.0,
		27: 30.0,
		28: 30.0,
		29: 30.0,
		30: 30.0,
	},
	GAME_SOLT_7: {
		8:  2.0,
		9:  2.0,
		10: 2.0,
		//
		11: 6.0,
		12: 6.0,
		13: 6.0,
		//
		14: 12.0,
		15: 12.0,
		16: 12.0,
		//
		17: 24.0,
		18: 24.0,
		19: 24.0,
		20: 24.0,
		//
		21: 40.0,
		22: 40.0,
		23: 40.0,
		24: 40.0,
		25: 40.0,
		26: 40.0,
		27: 40.0,
		28: 40.0,
		29: 40.0,
		30: 40.0,
	},
	GAME_SOLT_8: {
		8:  2.5,
		9:  2.5,
		10: 2.5,
		//
		11: 7.5,
		12: 7.5,
		13: 7.5,
		//
		14: 15.0,
		15: 15.0,
		16: 15.0,
		//
		17: 30.0,
		18: 30.0,
		19: 30.0,
		20: 30.0,
		//
		21: 50.0,
		22: 50.0,
		23: 50.0,
		24: 50.0,
		25: 50.0,
		26: 50.0,
		27: 50.0,
		28: 50.0,
		29: 50.0,
		30: 50.0,
	},
	GAME_SOLT_9: {
		8:  5.0,
		9:  5.0,
		10: 5.0,
		//
		11: 15.0,
		12: 15.0,
		13: 15.0,
		//
		14: 30.0,
		15: 30.0,
		16: 30.0,
		//
		17: 60.0,
		18: 60.0,
		19: 60.0,
		20: 60.0,
		//
		21: 100.0,
		22: 100.0,
		23: 100.0,
		24: 100.0,
		25: 100.0,
		26: 100.0,
		27: 100.0,
		28: 100.0,
		29: 100.0,
		30: 100.0,
	},
	GAME_SOLT_10: {
		5: 3.0,
		6: 5.0,
		7: 10.0,
		//
		8:  20.0,
		9:  20.0,
		10: 20.0,
		//
		11: 50.0,
		12: 50.0,
		13: 50.0,
		//
		14: 100.0,
		15: 100.0,
		16: 100.0,
		//
		17: 300.0,
		18: 300.0,
		19: 300.0,
		20: 300.0,
		//
		21: 500.0,
		22: 500.0,
		23: 500.0,
		24: 500.0,
		25: 500.0,
		26: 500.0,
		27: 500.0,
		28: 500.0,
		29: 500.0,
		30: 500.0,
	},
	GAME_SOLT_JACKPOT: {
		8:  10.0,
		9:  10.0,
		10: 10.0,
		//
		11: 20.0,
		12: 20.0,
		13: 20.0,
		//
		14: 30.0,
		15: 30.0,
		16: 30.0,
		//
		17: 40.0,
		18: 40.0,
		19: 40.0,
		20: 40.0,
		//
		21: 50.0,
		22: 50.0,
		23: 50.0,
		24: 50.0,
		25: 50.0,
		26: 50.0,
		27: 50.0,
		28: 50.0,
		29: 50.0,
		30: 50.0,
	},
}
