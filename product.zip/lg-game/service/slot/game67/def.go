package game67

import "t77/lg/service/protocol"

/*
游戏ID:67
游戏名字：赏金女王
*/

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE        = 0 //场景协议
	SUB_GAME_BET_REQ      = 1 //下注请求
	SUB_GAME_BET_RESP     = 2 //下注返回
	SUB_GAME_ACTIVIT_RANK = 3 //比赛活动排名
)

// 常数定义
const (
	//3行
	ROW_DEF = 3
	//5列
	COL_DEF = 5
	//缓存大小
	BUFF_SIZE = ROW_DEF * COL_DEF
	// 线数定义
	LINE_COUNT = 20
	//免费最大缓存
	MAX_FREE_CACHE = 8
	//扩展倍率最大的槽位
	MAX_MULT_SOLT_COUNT = 4
)

// 游戏图标定义
const (
	GAME_SOLT_EMPTY = iota //空图案
	GAME_SOLT_1
	GAME_SOLT_2
	GAME_SOLT_3
	GAME_SOLT_4
	GAME_SOLT_5
	GAME_SOLT_6
	GAME_SOLT_7
	GAME_SOLT_WILD
	GAME_SOLT_SCATTER
)

// 游戏模式定义
const (
	GAME_MODE_NORMAL = iota
	GAME_MODE_SPECIAL
)

type SpecialFill struct {
	Weight [][]int `yaml:"Weight"`
	Drop   [][]int `yaml:"Drop"`
}

// 游戏配置结构
type GameConfig struct {
	Version    int     `yaml:"Version"`
	Rtp        float64 `yaml:"Rtp"`
	BetConfig  []int64 `yaml:"BetConfig"`
	GameWeight []int   `yaml:"GameWeight"`
	Normal     struct {
		Weight [][]int `yaml:"Weight"`
		Drop   [][]int `yaml:"Drop"`
	} `yaml:"Normal"`
	Special struct {
		Scatter []int         `yaml:"Scatter"`
		Fill    []SpecialFill `yaml:"Fill"`
	} `yaml:"Special"`
}

// //////////////////////////
// 场景协议
type GameGameSence struct {
	protocol.ProtocolBase
	Buffer    [BUFF_SIZE]int `json:"Buffer"`
	BetConfig []int64        `json:"BetConfig"`
	Mode      int            `json:"Mode"`
	BetIndex  int            `json:"BetIndex"`
	Scatter   int            `json:"scatter"`
	Version   int            `json:"Version"`
}

// //////////////////////////
// 下注请求
type GameBetReq struct {
	protocol.ProtocolBase
	BetIndex int `json:"BetIndex"`
	FreeIdx  int `json:"freeNum"`
	Change   int `json:"Change"`
}

// //////////////////////////
type Prize struct {
	/** 图标ID */
	Icon int `json:"icon"`
	/** 图标个数 */
	Count int `json:"count"`
	/** 奖励类型 1=普通中奖,2=免费,3=翻倍 */
	Type int `json:"type"`
	/** 值 */
	Value int64 `json:"value"`
	/**线路1-20 */
	Line int `json:"line"`
	/**线路坐标0-14 */
	IconIndex []int `json:"iconIndex"`
}

/**信息 */
type LineIcon struct {
	/**哪一列 */
	Column int `json:"column"`
	/**哪些图标 */
	Icon []int `json:"icon"`
}

type RoundInfo struct {
	/** 当前回合获奖倍数 */
	Multiple int `json:"multiple"`
	/** 消除 */
	Remove []int `json:"remove"`
	/**掉落信息 */
	AddList []LineIcon `json:"addList"`
	/** 奖励信息 */
	Prize []Prize `json:"prize"`
	/**回合总赢 */
	WinRoundSum int64 `json:"winRoundSum"`
	/** 当前局免费新增数(不包含开始选择的免费数) */
	FreeNumAdd int `json:"freeNumAdd"`
}

type CalcSlotGameInfo struct {
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 倍率 */
	Multiple int `json:"multiple"`
	/** 下注倍率 */
	Rate int `json:"rate"`
	/** 翻倍 */
	DTime int `json:"dTime"`
	/** 初始图案从左到右从上到下总共15个 */
	Shape [BUFF_SIZE]int `json:"shape"`
	/** 回合信息 */
	RoundList []RoundInfo `json:"roundList"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 当前局免费新增数(不包含开始选择的免费数) */
	FreeNumAdd int `json:"freeNumAdd"`
	/** 当前局剩下免费次数 */
	MarginFreeNum int `json:"marginFreeNum"`
}

type GameResult struct {
	protocol.ProtocolBase
	/** 游戏信息 */
	InningList []CalcSlotGameInfo `json:"InningList"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 总赢得钱 */
	TotalWin int64 `json:"totalWin"`
	/** 玩家最新分数 */
	Points int64 `json:"points"`
	/** 下注倍率 */
	Rate int `json:"rate"`
	/** 游戏结果 */
	Result int `json:"result"`
	/**免费次数 */
	FTime int `json:"fTime"`
}

type ActivitGameRank struct {
	protocol.ProtocolBase
	ActivitId int `json:"activitId"`
	WinRank   int `json:"winRank"`
	MultRank  int `json:"multRank"`
}

// 赔率表
var Mult = map[int]map[int]int{
	GAME_SOLT_1: {3: 5, 4: 10, 5: 50},
	GAME_SOLT_2: {3: 4, 4: 15, 5: 75},
	GAME_SOLT_3: {3: 2, 4: 20, 5: 100},
	GAME_SOLT_4: {3: 10, 4: 25, 5: 200},
	GAME_SOLT_5: {3: 15, 4: 50, 5: 500},
	GAME_SOLT_6: {3: 20, 4: 100, 5: 1000},
	GAME_SOLT_7: {3: 50, 4: 250, 5: 2500},
}

// 额外倍率
var ExtMult = [MAX_MULT_SOLT_COUNT]int{1, 2, 3, 5}
var SpecialMult = [][MAX_MULT_SOLT_COUNT]int{
	{1, 2, 3, 5},
	{3, 6, 9, 20},
	{6, 12, 18, 40},
}
