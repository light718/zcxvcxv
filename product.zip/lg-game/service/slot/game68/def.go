package game68

import "t77/lg/service/protocol"

/*
游戏ID:68
游戏名字：金老鼠(鼠鼠福福)
*/

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE    = 0 //场景协议
	SUB_GAME_BET_REQ  = 1 //下注请求
	SUB_GAME_BET_RESP = 2 //下注返回
)

// 常数定义
const (
	//3行
	ROW_DEF = 3
	//3列
	COL_DEF = 3
	//缓存大小
	BUFF_SIZE = ROW_DEF * COL_DEF
	// 线数定义
	LINE_COUNT = 5
	//免费最大缓存
	MAX_FREE_CACHE = 5
)

// 游戏图标定义
const (
	GAME_SOLT_0 = iota //这个图标没有(为了兼容客户端从1开始)
	GAME_SOLT_1
	GAME_SOLT_2
	GAME_SOLT_3
	GAME_SOLT_4
	GAME_SOLT_5
	GAME_SOLT_6
	GAME_SOLT_WILD
	GAME_SOLT_MAX
)

// 游戏赔率定义
const (
	GAME_SOLT_0_MULT    = 0   //
	GAME_SOLT_1_MULT    = 3   //
	GAME_SOLT_2_MULT    = 5   //
	GAME_SOLT_3_MULT    = 15  //
	GAME_SOLT_4_MULT    = 30  //
	GAME_SOLT_5_MULT    = 50  //
	GAME_SOLT_6_MULT    = 100 //
	GAME_SOLT_WILD_MULT = 300 //
)

// 游戏模式定义
const (
	GAME_MODE_NORMAL = iota
	GAME_MODE_SPECIAL
)

// 游戏配置结构
type GameConfig struct {
	Version    int     `yaml:"Version"`
	Rtp        float64 `yaml:"Rtp"`
	BetConfig  []int64 `yaml:"BetConfig"`
	GameWeight []int   `yaml:"GameWeight"`
	Normal     [][]int `yaml:"Normal"`
	Special    struct {
		FirstSelect  []int   `yaml:"FirstSelect"`
		SelectWeight [][]int `yaml:"SelectWeight"`
	} `yaml:"Special"`
	WinMultTip map[int]int64 `yaml:"WinMultTip"`
}

// //////////////////////////
// 场景协议
type GameGameSence struct {
	protocol.ProtocolBase
	Buffer    [BUFF_SIZE]int `json:"Buffer"`
	BetConfig []int64        `json:"BetConfig"`
	BetIndex  int            `json:"BetIndex"`
	Version   int            `json:"Version"`
}

// //////////////////////////
// 下注请求
type GameBetReq struct {
	protocol.ProtocolBase
	BetIndex int `json:"BetIndex"`
	Change   int `json:"Change"`
}

// //////////////////////////
type Prize struct {
	/** 图标ID */
	Icon int `json:"icon"`
	/** 图标个数 */
	Count int `json:"count"`
	/** 奖励类型 1普通中奖 */
	Type int `json:"type"`
	/** 奖励数值 */
	Value int64 `json:"value"`
	/** 线 */
	Line int `json:"line"`
	/** 线路坐标 */
	IconIndex []int `json:"iconIndex"`
}

type SlotRoundInfoMessages struct {
	/** 图案 */
	Shape [BUFF_SIZE]int `json:"shape"`
	/** 奖励信息 */
	Prize []Prize `json:"prize"`
	/** 中奖线数 */
	LineCount int `json:"lineCount"`
	/** 最终获奖倍数 */
	Multiple int `json:"multiple"`
	/** 中奖 */
	LotterySize int `json:"lotterySize"`
	/** 掉落 */
	Drop map[string]int `json:"drop"`
}

type GameInfo struct {
	/** 游戏结果 */
	Result int `json:"result"`
	/** 0普通模式 1福鼠模式 */
	FsMode int `json:"fsMode"`
	/** 普通1  全屏奖2 */
	BeiShu int8 `json:"beiShu"`
	/** 对局 */
	RoundInfoMessages []SlotRoundInfoMessages `json:"slotRoundInfoMessages"`
	/** 1 小奖 2 中奖 3大奖 4巨奖 */
	Num int `json:"num"`
	/** 中奖 */
	LotterySize int64 `json:"lotterySize"`
}

type GameEnd struct {
	protocol.ProtocolBase
	/** 游戏信息 */
	Info GameInfo `json:"gameInfo"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 本局赢得钱 */
	Win int64 `json:"win"`
	/** 玩家最新分数 */
	Points int64 `json:"points"`
	/** 游戏结果 */
	Result int `json:"result"`
}
