package game72

import "t77/lg/service/protocol"

/*
游戏ID:72
游戏名字：象财神
*/

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE    = 0 //场景协议
	SUB_GAME_BET_REQ  = 1 //下注请求
	SUB_GAME_BET_RESP = 2 //下注返回
)

// 常数定义
const (
	//3行
	ROW_DEF = 3
	//5列
	COL_DEF = 5
	//缓存大小
	BUFF_SIZE = ROW_DEF * COL_DEF
	// 线数定义
	LINE_COUNT = 30
	//免费最大缓存
	MAX_FREE_CACHE = 8
)

// 游戏图标定义
const (
	GAME_SOLT_EMPTY = iota //空图案
	GAME_SOLT_1
	GAME_SOLT_2
	GAME_SOLT_3
	GAME_SOLT_4
	GAME_SOLT_5
	GAME_SOLT_6
	GAME_SOLT_7
	GAME_SOLT_8
	GAME_SOLT_WILD
	GAME_SOLT_SCATTER
)

// 游戏模式定义
const (
	GAME_MODE_NORMAL = iota
	GAME_MODE_SPECIAL
)

// 游戏配置结构
type GameConfig struct {
	Version    int           `yaml:"Version"`
	Rtp        float64       `yaml:"Rtp"`
	BetConfig  []int64       `yaml:"BetConfig"`
	GameWeight []int         `yaml:"GameWeight"`
	WinMultTip map[int]int64 `yaml:"WinMultTip"`
	Normal     [][]int       `yaml:"Normal"`
	Special    struct {
		Scatter []int   `yaml:"Scatter"`
		Weight  [][]int `yaml:"Weight"`
	} `yaml:"Special"`
}

// //////////////////////////
// 场景协议
type GameGameSence struct {
	protocol.ProtocolBase
	Buffer    [BUFF_SIZE]int `json:"Buffer"`
	BetConfig []int64        `json:"BetConfig"`
	BetIndex  int            `json:"BetIndex"`
	Version   int            `json:"Version"`
}

// //////////////////////////
// 下注请求
type GameBetReq struct {
	protocol.ProtocolBase
	BetIndex int `json:"BetIndex"`
	Change   int `json:"Change"`
}

// //////////////////////////
type Prize struct {
	/** 图标个数 */
	Count int `json:"count"`
	/** 图标ID */
	Icon int `json:"icon"`
	/** X星连珠 */
	LineCount int `json:"lineCount"`
	/** 赔率 */
	PeiLv int `json:"peiLv"`
	/** 类型 */
	Type int `json:"type"`
	/** 值 */
	Value int64 `json:"value"`
}

type RoundInfo struct {
	/** 图案 */
	CurrentShape [BUFF_SIZE]int `json:"currentShape"`
	/** 当前回合金额 */
	PriceValue int64 `json:"priceValue"`
	/** 当前免费次数 */
	FreeCount int `json:"freeCount"`
	/** 当前回合中将集合 */
	PriceList []Prize `json:"priceList"`
	/** 当前经验条 */
	CurrentProgress int `json:"currentProgress"`
	/** 当前倍数 */
	CurrentTime int64 `json:"currentTime"`
	/** 当前中奖类型 */
	CurrentPriceType int `json:"currentPriceType"`
}

type CalcSlotGameInfo struct {
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 奖励信息 */
	FirstPriceList []Prize `json:"firstPriceList"`
	/** 当前回合金额 */
	FirstPriceValue int64 `json:"firstPriceValue"`
	/** 图案 */
	InitShape [BUFF_SIZE]int `json:"initShape"`
	/** 弹窗显示的奖 */
	LotterySize int64 `json:"lotterySize"`
	/** 倍率 */
	Multiple int `json:"multiple"`
	/** 游戏结果 */
	Result int `json:"result"`
	/** int 1 小奖 2 中奖 3大奖 4巨奖 */
	PriceType int `json:"priceType"`
	/** 是否免费 */
	Free int `json:"free"`
	/** 免费次数 */
	FreeCount int `json:"freeCount"`
	/** 免费图案列表 */
	RoundList []RoundInfo `json:"roundList"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
}

type GameResult struct {
	protocol.ProtocolBase
	/** 游戏信息 */
	GameInfo CalcSlotGameInfo `json:"gameInfo"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 本局赢得钱 */
	Win int64 `json:"win"`
	/** 玩家最新分数 */
	Points int64 `json:"points"`
	/** 游戏结果 */
	Result int `json:"result"`
}

// 赔率表
var Mult = map[int]map[int]int{
	GAME_SOLT_1: {3: 5, 4: 8, 5: 15},
	GAME_SOLT_2: {3: 5, 4: 8, 5: 15},
	GAME_SOLT_3: {3: 8, 4: 10, 5: 30},
	GAME_SOLT_4: {3: 8, 4: 10, 5: 30},
	GAME_SOLT_5: {3: 10, 4: 15, 5: 45},
	GAME_SOLT_6: {3: 15, 4: 30, 5: 60},
	GAME_SOLT_7: {3: 20, 4: 45, 5: 90},
	GAME_SOLT_8: {3: 30, 4: 60, 5: 150},
}

// 用来计算线
type StCalcLine struct {
	soltType int
	count    int
	position [COL_DEF]int
}
