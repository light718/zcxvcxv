package slot

import (
	"database/sql"
	"math"
	"math/rand"
	"time"

	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/engine"
)

const (
	MIN_ROUND_SPINS  = 30           //控制轮次最小spin次数
	MAX_ROUND_SPINS  = 50           //控制轮次最大spin次数
	FRESH_TOTAL_SPIN = 50           //新手期spin次数
	MIN_RTP          = float64(0.5) //最小rtp
	MAX_RTP          = float64(2.0) //最大rtp
	MAX_LATER_COUNT  = 500          //近期记录的最大条数
)

const (
	STRATEGY_TAG_NORMAL       = iota //普通策略
	STRATEGY_TAG_RANDOM              //随机策略
	STRATEGY_TAG_TOTAL_RTP           //条件:总rtp
	STRATEGY_TAG_LATELY_RTP          //条件:近期rtp
	STRATEGY_TAG_EXPECTED_RTP        //条件:预期rtp
)

type LatelyRecord struct {
	Bet int64
	Win int64
}

// 控制结构
type Strategy struct {
	Tag      int            //策略类型
	TSpin    int64          //总spin次数
	TWin     int64          //总赢分
	TBet     int64          //总下注
	LSpin    int64          //近期spin次数
	LWin     int64          //近期赢分
	LBet     int64          //近期下注
	LRecords []LatelyRecord //近期赢分的原始数据
	CSpin    int64          //当前阶段spin次数
	CWin     int64          //当前阶段赢分
	CBet     int64          //当前阶段下注
	CRtp     float64        //当前RTP
	CTSpin   int64          //当前阶段需要下注的次数
	CTime    int64          //当前时间
	SetRtp   float64        //设置的RTP
	random   *rand.Rand     //随机对象
	weight   []int          //游戏权重
}

func (strategy *Strategy) AsyncLoad(mysql *engine.MySqlEngine, gid int, uid int64) {
	row := mysql.QueryRow(`SELECT c_spin,c_bet,c_win,c_tspin,c_rtp,c_time FROM t_game_rtp_strategy WHERE account_id = ? AND game_id = ?`, uid, gid)
	if err := row.Scan(&strategy.CSpin, &strategy.CBet, &strategy.CWin, &strategy.CTSpin, &strategy.CRtp, &strategy.CTime); err == sql.ErrNoRows {
		mysql.Exec(`INSERT INTO t_game_rtp_strategy(account_id,game_id) VALUES (?,?)`, uid, gid)
	}
	rows, err := mysql.Query("SELECT usecoin,wincoin FROM mark WHERE userid = ? AND gameid = ? AND mark = 1 ORDER BY id ASC", uid, gid)
	if err != nil {
		return
	}
	defer rows.Close()
	records := []LatelyRecord{}
	for rows.Next() {
		record := LatelyRecord{}
		if e := rows.Scan(&record.Bet, &record.Win); e == nil {
			if record.Bet > 0 {
				strategy.TSpin++
				strategy.TBet += record.Bet
				strategy.TWin += record.Win
				records = append(records, record)
			} else {
				//免费没有下注额，但是投注记录有新一条记录
				//比如赏金女王和上一局激活算在一起
				records[len(records)-1].Win += record.Win
			}
		}
	}
	//取最近500条数据
	if len(records) >= MAX_LATER_COUNT {
		for i := len(records) - MAX_LATER_COUNT; i < len(records); i++ {
			strategy.LSpin++
			strategy.LBet += records[i].Bet
			strategy.LWin += records[i].Win
			strategy.LRecords = append(strategy.LRecords, records[i])
		}
	} else {
		strategy.LSpin = strategy.TSpin
		strategy.LBet = strategy.TBet
		strategy.LWin = strategy.TBet
		strategy.LRecords = records
	}
}

func (strategy *Strategy) Set(random *rand.Rand, rtp float64, weight []int) {
	strategy.weight = append(strategy.weight, weight...)
	strategy.random = random
	if rtp != 0 {
		strategy.SetRtp = rtp
	} else {
		strategy.SetRtp = 1.0
	}
	if strategy.TSpin < FRESH_TOTAL_SPIN { //新手期
		spincnt := int64(0)
		if strategy.TSpin <= 0 {
			spincnt = int64(common.RandRangeValue(strategy.random, MIN_ROUND_SPINS, MAX_ROUND_SPINS))
		} else {
			spincnt = strategy.CTSpin - strategy.CSpin
		}
		strategy.ChangeStrategy(common.RandRangeF64(random, strategy.SetRtp, 0.1), STRATEGY_TAG_RANDOM, spincnt)
	} else {
		if time.Now().Unix()-strategy.CTime > 86400 {
			//超过1天就更新策略
			//切换的策略
			ok := strategy.ConditionStrategy()
			if !ok {
				strategy.RandomStrategy()
			}
		}
	}
}

func (strategy *Strategy) CheckDivision(a, b float64) float64 {
	if b > 0 {
		return a / b
	} else {
		return a * 100000000
	}
}

// 计算RTP值
func (strategy *Strategy) CalcRtpValue() (r1, r2, r3 float64) {
	//总下注超过1000次的
	if strategy.TSpin >= 1000 {
		r1 = float64(strategy.TWin) / float64(strategy.TBet)
	}
	//近期超过500的局的
	if strategy.LSpin >= 500 {
		r2 = float64(strategy.LWin) / float64(strategy.LBet)
	}
	//当前超过80的
	if strategy.CSpin > 80 {
		r3 = float64(strategy.CWin) / float64(strategy.CBet)
	}
	return
}

// 随机策略
func (strategy *Strategy) RandomStrategy() {
	rtp := float64(1.0)
	threshold := float64(0.5)
	if strategy.CRtp >= 1 {
		threshold = 0.7
	} else {
		threshold = 0.3
	}
	if strategy.random.Float64() < threshold {
		rtp = common.RandRangeF64(strategy.random, 0.75, 0.15) * strategy.SetRtp
	} else {
		rtp = common.RandRangeF64(strategy.random, 1.25, 0.25) * strategy.SetRtp
	}
	spincnt := int64(common.RandRangeValue(strategy.random, MIN_ROUND_SPINS, MAX_ROUND_SPINS))
	strategy.ChangeStrategy(rtp, STRATEGY_TAG_RANDOM, spincnt)
}

// 条件策略
func (strategy *Strategy) ConditionStrategy() bool {
	rtp := 1.0
	tag := STRATEGY_TAG_NORMAL
	spincnt := int64(common.RandRangeValue(strategy.random, MIN_ROUND_SPINS, MAX_ROUND_SPINS))
	tr, lr, cr := strategy.CalcRtpValue()
	if tr > 0 && math.Abs(tr-1) >= 0.5 {
		rtp = strategy.CheckDivision(strategy.SetRtp, tr)
		tag = STRATEGY_TAG_TOTAL_RTP
	} else if lr > 0 && (lr < 0.4 || lr > 2.5) {
		rtp = strategy.CheckDivision(strategy.SetRtp, lr)
		tag = STRATEGY_TAG_LATELY_RTP
	} else if cr > 0 && math.Abs(cr-strategy.CRtp) >= 0.6 && strategy.Tag != STRATEGY_TAG_EXPECTED_RTP {
		rtp = strategy.CRtp*2 - cr
		tag = STRATEGY_TAG_EXPECTED_RTP
		spincnt = int64(float64(spincnt) * 0.67)
		rtp = common.CheckValueF64(rtp, MIN_RTP*1.2, MAX_RTP*0.8)
	} else {
		return false
	}
	strategy.ChangeStrategy(rtp, tag, spincnt)
	return true
}

func (strategy *Strategy) ChangeStrategy(rtp float64, tag int, spincnt int64) {
	strategy.Tag = tag
	//清空近期下注
	//strategy.LBet = 0
	//strategy.LWin = 0
	//strategy.LSpin = 0
	//清空当前阶段下注
	strategy.CBet = 0
	strategy.CWin = 0
	strategy.CSpin = 0
	//更新数值
	strategy.CRtp = rtp
	strategy.CTSpin = spincnt
	strategy.CTime = time.Now().Unix()
}

func (strategy *Strategy) Update(now, betScore, winScore int64) {
	//当前
	strategy.CBet += betScore
	strategy.CWin += winScore
	if betScore > 0 {
		strategy.CSpin++
	}
	//近期
	strategy.LBet += betScore
	strategy.LWin += winScore
	if betScore > 0 {
		strategy.LSpin++
		strategy.LRecords = append(strategy.LRecords, LatelyRecord{betScore, winScore})
	} else {
		if len(strategy.LRecords) > 0 {
			strategy.LRecords[len(strategy.LRecords)-1].Win += winScore
		}
	}
	if strategy.LSpin > MAX_LATER_COUNT {
		strategy.LBet -= strategy.LRecords[0].Bet
		strategy.LWin -= strategy.LRecords[0].Win
		strategy.LRecords = strategy.LRecords[1:]
		strategy.LSpin--
	}
	//总累计
	strategy.TBet += betScore
	strategy.TWin += winScore
	if betScore > 0 {
		strategy.TSpin++
	}
	//当次数执行完成
	if strategy.CSpin >= strategy.CTSpin {
		//切换的策略
		ok := strategy.ConditionStrategy()
		if !ok {
			strategy.RandomStrategy()
		}
	}
}

// 暂时控制免费和jackpot
func (strategy *Strategy) Control(bidx int, outWeight []int, freeidx int) {
	var STAKE_ADJUST_RATE = []float64{
		1.3, 1.25, 1.2, 1.15, 1.1, 1.05, 1.05, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0.95, 0.95, 0.9, 0.9, 0.9}

	rtp := 1.0
	freshRatio := 1.0
	if strategy.TSpin < FRESH_TOTAL_SPIN && bidx <= 10 {
		freshRatio = 1.1 + 0.1*float64((FRESH_TOTAL_SPIN-strategy.TSpin)/FRESH_TOTAL_SPIN)
		rtp = math.Max(freshRatio, strategy.CRtp)
	} else {
		rtp = strategy.CRtp
	}
	if bidx >= len(STAKE_ADJUST_RATE) {
		bidx = len(STAKE_ADJUST_RATE) - 1
	}
	stakeRate := STAKE_ADJUST_RATE[bidx]
	outWeight[freeidx] = int(float64(strategy.weight[freeidx]) * rtp * stakeRate * freshRatio)
}
