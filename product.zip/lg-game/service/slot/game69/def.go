package game69

import "t77/lg/service/protocol"

/*
游戏ID:69
游戏名字：金牛
*/

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE    = 0 //场景协议
	SUB_GAME_BET_REQ  = 1 //下注请求
	SUB_GAME_BET_RESP = 2 //下注返回
)

// 常数定义
const (
	//3行
	ROW_DEF = 4
	//3列
	COL_DEF = 3
	//缓存大小
	BUFF_SIZE = ROW_DEF * COL_DEF
	// 线数定义
	LINE_COUNT = 10
	//免费最大缓存
	MAX_FREE_CACHE = 5
)

// 游戏图标定义
const (
	GAME_SOLT_0    = iota //这个图标没有(为了兼容客户端从1开始)
	GAME_SOLT_1           //鞭炮
	GAME_SOLT_2           //橙子
	GAME_SOLT_3           //红包
	GAME_SOLT_4           //福袋
	GAME_SOLT_5           //聚宝盒
	GAME_SOLT_6           //元宝
	GAME_SOLT_WILD        //百搭
	GAME_SOLT_MAX
)

// 游戏赔率定义
const (
	GAME_SOLT_0_MULT    = 0
	GAME_SOLT_1_MULT    = 3
	GAME_SOLT_2_MULT    = 5
	GAME_SOLT_3_MULT    = 10
	GAME_SOLT_4_MULT    = 20
	GAME_SOLT_5_MULT    = 50
	GAME_SOLT_6_MULT    = 100
	GAME_SOLT_WILD_MULT = 200
)

// 游戏模式定义
const (
	GAME_MODE_NORMAL = iota
	GAME_MODE_SPECIAL
)

type FillRule struct {
	Select []int         `yaml:"Select"`
	Fill   map[int][]int `yaml:"Fill"`
}

// 游戏配置结构
type GameConfig struct {
	Version    int           `yaml:"Version"`
	Rtp        float64       `yaml:"Rtp"`
	BetConfig  []int64       `yaml:"BetConfig"`
	GameWeight []int         `yaml:"GameWeight"`
	Normal     [][]int       `yaml:"Normal"`
	Special    FillRule      `yaml:"Special"`
	WinMultTip map[int]int64 `yaml:"WinMultTip"`
}

// //////////////////////////
// 场景协议
type GameGameSence struct {
	protocol.ProtocolBase
	Buffer    [10]int `json:"Buffer"`
	BetConfig []int64 `json:"BetConfig"`
	BetIndex  int     `json:"BetIndex"`
	Version   int     `json:"Version"`
}

// //////////////////////////
// 下注请求
type GameBetReq struct {
	protocol.ProtocolBase
	BetIndex int `json:"BetIndex"`
	Change   int `json:"Change"`
}

// //////////////////////////
type Prize struct {
	/** 图标ID */
	Icon int `json:"iconId"`
	/** 值 */
	PriceValue int64 `json:"priceValue"`
	/** 图标个数 */
	PriceCount [3]int `json:"priceCount"`
	/** 位置 */
	Position [3]int `json:"position"`
	/** 线ID */
	BelongLine int `json:"belongLine"`
	/** 赔率 */
	PeiLv int `json:"peiLv"`
}

type OxRoundInfo struct {
	/** 图案 */
	CurrentShape [10]int `json:"currentShape"`
	/** 是否是金牛模式 */
	JinNiuMode bool `json:"jinNiuMode"`
}

type CalcSlotGameInfo struct {
	/** 游戏结果 */
	Result int `json:"result"`
	/** 图案列表 */
	RoundList []OxRoundInfo `json:"roundList"`
	/** int 1 小奖 2 中奖 3大奖 4巨奖 */
	PriceType int `json:"priceType"`
	/** Long 中奖 */
	LotterySize int64 `json:"lotterySize"`
	/** 奖励信息 */
	PriceList []Prize `json:"priceList"`
	/** 福牛模式 */
	FuNiuMode bool `json:"fuNiuMode"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
}

type OxGameResult struct {
	protocol.ProtocolBase
	/** 游戏信息 */
	GameInfo CalcSlotGameInfo `json:"gameInfo"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 本局赢得钱 */
	Win int64 `json:"win"`
	/** 玩家最新分数 */
	Points int64 `json:"points"`
	/** 游戏结果 */
	Result int `json:"result"`
}
