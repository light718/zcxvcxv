package game75

import "t77/lg/service/protocol"

/*
游戏ID:75
游戏名字：寻龙探宝
*/

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE    = 0 //场景协议
	SUB_GAME_BET_REQ  = 1 //下注请求
	SUB_GAME_BET_RESP = 2 //下注返回
)

// 常数定义
const (
	//行
	ROW_DEF = 5
	//列
	COL_DEF = 5
	//缓存大小
	BUFF_SIZE = ROW_DEF * COL_DEF
	// 线数定义
	LINE_COUNT = 10
	//最大进度
	MAX_PROGRESS = 70
)

// 游戏图标定义
const (
	GAME_SOLT_EMPTY = iota
	GAME_SOLT_1
	GAME_SOLT_2
	GAME_SOLT_3
	GAME_SOLT_4
	GAME_SOLT_5
	GAME_SOLT_6
	GAME_SOLT_7
	GAME_SOLT_8
	GAME_SOLT_WILD
)

// 游戏模式定义
const (
	GAME_MODE_NORMAL = iota
)

const (
	GAME_STEP_NORMAL = iota
	GAME_STEP_EARTH
	GAME_STEP_WATER
	GAME_STEP_FIRE
	GAME_STEP_GIANT
)

// 游戏配置结构
type GameConfig struct {
	Version      int           `yaml:"Version"`
	BetConfig    []int64       `yaml:"BetConfig"`
	NormalWeight [][]int       `yaml:"NormalWeight"`
	NormalDrop   []int         `yaml:"NormalDrop"`
	EarthWeight  [][]int       `yaml:"EarthWeight"`
	EarthDrop    []int         `yaml:"EarthDrop"`
	WaterDrop    []int         `yaml:"WaterDrop"`
	FireSelect   []int         `yaml:"FireSelect"`
	FireDrop     []int         `yaml:"FireDrop"`
	GiantWeight  []int         `yaml:"GiantWeight"`
	GiantDrop    []int         `yaml:"GiantDrop"`
	WinMultTip   map[int]int64 `yaml:"WinMultTip"`
}

// //////////////////////////
// 场景协议
type GameGameSence struct {
	protocol.ProtocolBase
	Buffer    [BUFF_SIZE]int `json:"Buffer"`
	BetConfig []int64        `json:"BetConfig"`
	BetIndex  int            `json:"BetIndex"`
	Version   int            `json:"Version"`
}

// //////////////////////////
// 下注请求
type GameBetReq struct {
	protocol.ProtocolBase
	BetIndex int `json:"BetIndex"`
	Change   int `json:"Change"`
}

// //////////////////////////
type Prize struct {
	Icon     int   `json:"icon"`
	Count    int   `json:"count"`
	Value    int64 `json:"value"`
	PeiLv    int   `json:"peiLv"`
	Position []int `json:"position"`
}

/**信息 */
type IconInfo struct {
	Position int `json:"position"`
	IconId   int `json:"iconId"`
}

type RoundInfo struct {
	/** 特殊模式的初始地图 特殊模式地图从 initShape 变成 currentShape*/
	InitShape []int `json:"initShape"`
	/** 地图 */
	CurrentShape [BUFF_SIZE]int `json:"currentShape"`
	/** 最终地图 */
	FinalShape [BUFF_SIZE]int `json:"finalShape"`
	/** 当前收集进度条 */
	CurrentProgress int `json:"currentProgress"`
	/** 当前回合类型   0 普通 1土龙 2水龙 3火龙 4巨龙	 */
	Type int `json:"type"`
	/**当前回合金额 */
	PriceValue int64 `json:"priceValue"`
	/** 消除的地图 */
	RemoveList []IconInfo `json:"removeList"`
	/** 新增地图 */
	AddList []IconInfo `json:"addList"`
	/** 当前回合中奖集合 */
	PriceList []Prize `json:"priceList"`
}

type SlotGameInfo struct {
	/** 游戏结果 */
	Result int `json:"result"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 图案列表 */
	RoundList []RoundInfo `json:"roundList"`
	/** int 1 小奖 2 中奖 3大奖 4巨奖 */
	PriceType int `json:"priceType"`
	/** Long 中奖 */
	LotterySize int64 `json:"lotterySize"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 游戏模式 */
	EarthDragon bool `json:"earthDragon"`
	WaterDragon bool `json:"waterDragon"`
	FireDragon  bool `json:"fireDragon"`
	GiantDragon bool `json:"giantDragon"`
}

type GameResult struct {
	protocol.ProtocolBase
	/** 游戏信息 */
	GameInfo SlotGameInfo `json:"gameInfo"`
	/** 总下注 */
	Bet int64 `json:"bet"`
	/** 本局赢得钱 */
	Wins int64 `json:"wins"`
	/** 本局赢得钱 */
	Win int64 `json:"win"`
	/** 玩家最新分数 */
	Points int64 `json:"points"`
	/** 游戏结果 */
	Result int `json:"result"`
}

// 赔率表
var Mult = map[int]map[int]int{
	GAME_SOLT_1: {
		4: 2,
		5: 3,
		6: 4,
		7: 6,
		8: 8,
		9: 10,
		//
		10: 15,
		11: 15,
		12: 15,
		//
		13: 20,
		14: 20,
		//
		15: 40,
		16: 40,
		17: 40,
		//
		18: 100,
		19: 100,
		20: 100,
		//
		21: 200,
		22: 200,
		23: 200,
		24: 200,
		//
		25: 300,
	},
	GAME_SOLT_2: {
		4: 3,
		5: 5,
		6: 6,
		7: 10,
		8: 15,
		9: 20,
		//
		10: 30,
		11: 30,
		12: 30,
		//
		13: 40,
		14: 40,
		//
		15: 60,
		16: 60,
		17: 60,
		//
		18: 200,
		19: 200,
		20: 200,
		//
		21: 300,
		22: 300,
		23: 300,
		24: 300,
		//
		25: 400,
	},
	GAME_SOLT_3: {
		4: 4,
		5: 6,
		6: 9,
		7: 15,
		8: 20,
		9: 30,
		//
		10: 40,
		11: 40,
		12: 40,
		//
		13: 50,
		14: 50,
		//
		15: 80,
		16: 80,
		17: 80,
		//
		18: 300,
		19: 300,
		20: 300,
		//
		21: 400,
		22: 400,
		23: 400,
		24: 400,
		//
		25: 500,
	},
	GAME_SOLT_4: {
		4: 5,
		5: 10,
		6: 15,
		7: 20,
		8: 30,
		9: 40,
		//
		10: 50,
		11: 50,
		12: 50,
		//
		13: 60,
		14: 60,
		//
		15: 100,
		16: 100,
		17: 100,
		//
		18: 500,
		19: 500,
		20: 500,
		//
		21: 600,
		22: 600,
		23: 600,
		24: 600,
		//
		25: 600,
	},
	GAME_SOLT_5: {
		4: 10,
		5: 15,
		6: 30,
		7: 60,
		8: 70,
		9: 80,
		//
		10: 100,
		11: 100,
		12: 100,
		//
		13: 300,
		14: 300,
		//
		15: 400,
		16: 400,
		17: 400,
		//
		18: 600,
		19: 600,
		20: 600,
		//
		21: 800,
		22: 800,
		23: 800,
		24: 800,
		//
		25: 800,
	},
	GAME_SOLT_6: {
		4: 15,
		5: 20,
		6: 40,
		7: 70,
		8: 80,
		9: 100,
		//
		10: 200,
		11: 200,
		12: 200,
		//
		13: 400,
		14: 400,
		//
		15: 500,
		16: 500,
		17: 500,
		//
		18: 800,
		19: 800,
		20: 800,
		//
		21: 1000,
		22: 1000,
		23: 1000,
		24: 1000,
		//
		25: 1000,
	},
	GAME_SOLT_7: {
		4: 20,
		5: 30,
		6: 50,
		7: 80,
		8: 100,
		9: 200,
		//
		10: 300,
		11: 300,
		12: 300,
		//
		13: 600,
		14: 600,
		//
		15: 800,
		16: 800,
		17: 800,
		//
		18: 1000,
		19: 1000,
		20: 1000,
		//
		21: 2000,
		22: 2000,
		23: 2000,
		24: 2000,
		//
		25: 5000,
	},
	GAME_SOLT_8: {
		4: 30,
		5: 40,
		6: 70,
		7: 100,
		8: 200,
		9: 300,
		//
		10: 500,
		11: 500,
		12: 500,
		//
		13: 1000,
		14: 1000,
		//
		15: 2000,
		16: 2000,
		17: 2000,
		//
		18: 5000,
		19: 5000,
		20: 5000,
		//
		21: 10000,
		22: 10000,
		23: 10000,
		24: 10000,
		//
		25: 20000,
	},
}
