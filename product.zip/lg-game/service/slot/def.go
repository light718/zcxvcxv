package slot

import "time"

// 普通下注游戏记录
type RecordBetInfo struct {
	Gameid      int    `db:"gameid"`
	GameNo      string `db:"order_no"`
	UserId      int64  `db:"userid"`
	BetScore    int64  `db:"usecoin"`
	WinScore    int64  `db:"wincoin"`
	ChangeScore int64  `db:"changecoin"`
	Tax         int64  `db:"tax"`
	Time        int64
	BalanceTime time.Time `db:"balancetime"`
	Mark        int       `db:"mark"`
	BfUserCoin  int64     `db:"bfusercoin"`
	AfUserCoin  int64     `db:"afusercoin"`
	RePoolCoin  int64     `db:"repoolcoin"`
	Ip          string    `db:"ip"`
}
