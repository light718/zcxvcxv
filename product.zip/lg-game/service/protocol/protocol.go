package protocol

// 命令
type ProtocolBase struct {
	MainCmd int `json:"MainCmd"`
	SubCmd  int `json:"SubCmd"`
}

// token登录结构
type LoginTokenReq struct {
	ProtocolBase
	TokenCode string `json:"Token"`
	GameId    int    `json:"GameId"`
	Robot     int    `json:"Robot"`
	ActivitId int    `json:"ActivitId"` //活动ID
}

// token 登录返回
type LoginTokenResp struct {
	ProtocolBase
	Code      int    `json:"Code"`
	Score     int64  `json:"Score"`
	Nickname  string `json:"Nickname"`
	GameId    int    `json:"GameId"`
	ActivitId int    `json:"ActivitId"` //活动ID
}
