package protocol

/////////////////////////////////////////////

const (
	//系统模块
	MAIN_SYSTEM = 0 + iota //大厅100开始
	//登录模块
	MAIN_LOGIN
	//游戏模块
	MAIN_GAME
)

//////////////////////////////////////////////

// 登录模块子命令
const (
	//登录请求
	SUB_LOGIN_TOKEN_REQ = 0
	//登录返回
	SUB_LOGIN_TOKEN_RESP = 1
)

// 系统模块子命令
const (
	//心跳请求
	SUB_SYSTEM_PING = 0
	//心跳回复
	SUB_SYSTEM_PONG = 1
)

// 积分模块子命令
const (
	//金币同步
	SUB_SYNC_SCORE = 0
)

////////////////////////////////////////////
