package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game74"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

type Desk74 struct {
	Desk
	config   *game74.GameConfig //游戏配置
	betidx   int                //下注配置的索引
	result   game74.GameResult  //游戏结果
	strategy *slot.Strategy     //控制策略
}

// 初始化
func NewDeskGame74(id, max_seat int, room *Room) (d *Desk74) {
	d = &Desk74{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx:   0,
		strategy: &slot.Strategy{},
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk74) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载控制信息
	d.strategy.AsyncLoad(d.room.MySqlEngine(), gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk74) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk74) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入
func (d *Desk74) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game74.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game74.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game74.GAME_MODE_NORMAL, &sence.Buffer)
	sence.BetIndex = d.betidx
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
	d.strategy.Set(d.Random(), d.config.Rtp, d.config.GameWeight)
}

// 游戏消息
func (d *Desk74) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game74.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game74.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {
				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk74, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// //////////////////////////////////////////////////////////////////////

// 转换
func (d *Desk74) ConvertBuffer(dec *[10]int, src *[game74.ROW_DEF][game74.COL_DEF]int) {
	idex := 0
	for col := 0; col < game74.COL_DEF; col++ {
		for row := 0; row < game74.ROW_DEF; row++ {
			if col == 0 || col == 2 {
				if row == 3 {
					continue
				}
			}
			dec[idex] = src[row][col]
			idex++
		}
	}
}

// 必输的
func (d *Desk74) RandMustLoseBuffer(buff *[game74.BUFF_SIZE]int) {
	arr1 := []int{game74.GAME_SOLT_2, game74.GAME_SOLT_3, game74.GAME_SOLT_4, game74.GAME_SOLT_5, game74.GAME_SOLT_6}
	arr2 := []int{game74.GAME_SOLT_1, game74.GAME_SOLT_3, game74.GAME_SOLT_4, game74.GAME_SOLT_5, game74.GAME_SOLT_6}
	arr3 := []int{game74.GAME_SOLT_1, game74.GAME_SOLT_2, game74.GAME_SOLT_4, game74.GAME_SOLT_5, game74.GAME_SOLT_6}
	//
	arr := []int{0, 1, 2}
	v := common.RandValue(d.Random(), arr)
	switch v {
	case 0:
		{
			common.Shuffle(d.Random(), arr1)
			for i := 0; i < game74.COL_DEF; i++ {
				buff[i] = arr1[i]
			}
		}
	case 1:
		{
			common.Shuffle(d.Random(), arr2)
			for i := 0; i < game74.COL_DEF; i++ {
				buff[i] = arr2[i]
			}
		}
	case 2:
		{
			common.Shuffle(d.Random(), arr3)
			for i := 0; i < game74.COL_DEF; i++ {
				buff[i] = arr3[i]
			}
		}
	}
}

// 随机图案
func (d *Desk74) RandBuffer(mode int, buff *[game74.BUFF_SIZE]int) {
	if mode == game74.GAME_MODE_NORMAL {
		for i := 0; i < game74.COL_DEF; i++ {
			buff[i] = common.CalcWeight(d.Random(), d.config.Normal[i])
		}
	} else {
		//这个作为第一列和第三列
		t1 := common.CalcWeight(d.Random(), d.config.Special.Select) + 1
		buff[0] = t1
		buff[1] = common.CalcWeight(d.Random(), d.config.Special.Fill[t1]) + 1
		buff[2] = t1
	}
}

func (d *Desk74) GetSoltTypeMult(soltType int) (mult int) {
	switch soltType {
	case game74.GAME_SOLT_ANY:
		mult = game74.GAME_SOLT_ANY_MULT
	case game74.GAME_SOLT_1:
		mult = game74.GAME_SOLT_1_MULT
	case game74.GAME_SOLT_2:
		mult = game74.GAME_SOLT_2_MULT
	case game74.GAME_SOLT_3:
		mult = game74.GAME_SOLT_3_MULT
	case game74.GAME_SOLT_4:
		mult = game74.GAME_SOLT_4_MULT
	case game74.GAME_SOLT_5:
		mult = game74.GAME_SOLT_5_MULT
	case game74.GAME_SOLT_6:
		mult = game74.GAME_SOLT_6_MULT
	case game74.GAME_SOLT_WILD:
		fallthrough
	case game74.GAME_SOLT_WILD_2:
		fallthrough
	case game74.GAME_SOLT_WILD_5:
		fallthrough
	case game74.GAME_SOLT_WILD_10:
		mult = game74.GAME_SOLT_WILD_MULT
	}
	return
}

// 处理下注逻辑
func (d *Desk74) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "gbet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game74.LINE_COUNT
	//回复下注结果
	gameResult := game74.GameResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game74.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//控制修改
	d.strategy.Control(idx, d.config.GameWeight, game74.GAME_MODE_SPECIAL)
	d.DebugGameMsgf(pUserData, "game weight:%v", d.config.GameWeight)
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//出图
	gameResult.GameInfo, gameResult.Win = d.DoBuffer(addPool, betScore, calcScore)
	gameResult.Wins = gameResult.Win
	//推送中台下注结果
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk74, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

// 随机游戏
func (d *Desk74) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk74) DoBuffer(addPool, betScore, calcScore int64) (gameInfo game74.CalcSlotGameInfo, totalScore int64) {
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		//初始化
		gameInfo = game74.CalcSlotGameInfo{
			JinZhuMode: false,
			RoundList:  make([]game74.RoundInfo, 0),
			PriceList:  make([]game74.Prize, 0),
		}
		//游戏总分
		totalScore = 0
		//随机本局游戏
		mode := d.RandGame(d.config.GameWeight)
		//游戏对局数据
		gameRoundInfo := game74.RoundInfo{
			JinZhuMode: false,
		}
		//随机图案
		d.RandBuffer(mode, &gameRoundInfo.CurrentShape)
		if mode == game74.GAME_MODE_SPECIAL {
			gameInfo.JinZhuMode = true
			gameRoundInfo.JinZhuMode = true
		}
		//计算得分
		gameInfo.PriceList, gameInfo.LotterySize = d.CalcScore(calcScore, &gameRoundInfo)
		gameInfo.Wins = gameInfo.LotterySize
		//总得分
		totalScore = gameInfo.Wins
		//记录对局数据
		gameInfo.RoundList = append(gameInfo.RoundList, gameRoundInfo)
		//奖励弹窗
		gameInfo.PriceType = d.CalcWinMultTip(betScore, totalScore)
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		gameInfo = d.RandMustLoseGameInfo()
		//赢分0
		totalScore = 0
	}
	return
}

// 随机必输的游戏图案
func (d *Desk74) RandMustLoseGameInfo() (game game74.CalcSlotGameInfo) {
	game = game74.CalcSlotGameInfo{
		JinZhuMode: false,
		RoundList:  make([]game74.RoundInfo, 0),
		PriceList:  make([]game74.Prize, 0),
	}
	//游戏对局数据
	gameRoundInfo := game74.RoundInfo{
		JinZhuMode: false,
	}
	//必输图
	d.RandMustLoseBuffer(&gameRoundInfo.CurrentShape)
	//记录对局数据
	game.RoundList = append(game.RoundList, gameRoundInfo)
	return
}

// 计算弹窗提示
func (d *Desk74) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk74) CalcScore(calcScore int64, roundInfo *game74.RoundInfo) (prizes []game74.Prize, totalScore int64) {
	//初始化列表
	totalScore = 0
	prizes = make([]game74.Prize, 0)
	pass := true
	for i := 0; i < game74.BUFF_SIZE; i++ {
		if roundInfo.CurrentShape[i] == game74.GAME_SOLT_EMPTY {
			//只要空图标就不能中奖
			return
		}
	}
	realIcon := roundInfo.CurrentShape[0]
	for i := 1; i < game74.BUFF_SIZE; i++ {
		v := roundInfo.CurrentShape[i]
		if v == game74.GAME_SOLT_WILD ||
			v == game74.GAME_SOLT_WILD_2 ||
			v == game74.GAME_SOLT_WILD_5 ||
			v == game74.GAME_SOLT_WILD_10 {
			continue
		}
		if realIcon == game74.GAME_SOLT_WILD {
			if v != game74.GAME_SOLT_WILD &&
				v != game74.GAME_SOLT_WILD_2 &&
				v != game74.GAME_SOLT_WILD_5 &&
				v != game74.GAME_SOLT_WILD_10 {
				realIcon = v
			}
		}
		if realIcon != v {
			pass = false
			break
		}
	}
	if !pass {
		bAny := true
		for i := 0; i < game74.BUFF_SIZE; i++ {
			if roundInfo.CurrentShape[i] > game74.GAME_SOLT_3 && roundInfo.CurrentShape[i] < game74.GAME_SOLT_WILD {
				bAny = false
				break
			}
		}
		if bAny {
			pass = true
			realIcon = game74.GAME_SOLT_ANY
		}
	}
	if !pass {
		return
	}
	//图案的倍率
	mult := d.GetSoltTypeMult(realIcon)
	exMult := 1
	switch roundInfo.CurrentShape[1] {
	case game74.GAME_SOLT_WILD_2:
		exMult = 2
	case game74.GAME_SOLT_WILD_5:
		exMult = 5
	case game74.GAME_SOLT_WILD_10:
		exMult = 10
	}
	if realIcon == game74.GAME_SOLT_ANY {
		realIcon = 0
	}
	//奖励明细
	prize := game74.Prize{
		Icon:       realIcon,
		PeiLv:      mult,
		BelongLine: realIcon,
		Position:   [game74.BUFF_SIZE]int{0, 1, 2},
		PriceValue: int64(mult) * int64(exMult) * calcScore,
	}
	prize.PriceCount = roundInfo.CurrentShape
	if prize.PriceCount[1] > game74.GAME_SOLT_WILD {
		prize.PriceCount[1] = game74.GAME_SOLT_WILD
	}
	prizes = append(prizes, prize)
	//总分
	for i := 0; i < len(prizes); i++ {
		totalScore += prizes[i].PriceValue
	}
	return
}
