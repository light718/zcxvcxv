package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game69"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

// 游戏玩法结构
type Desk69 struct {
	Desk
	config   *game69.GameConfig  //游戏配置
	betidx   int                 //下注配置的索引
	result   game69.OxGameResult //游戏结果
	strategy *slot.Strategy      //控制策略
}

// 初始化
func NewDeskGame69(id, max_seat int, room *Room) (d *Desk69) {
	d = &Desk69{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx:   0,
		strategy: &slot.Strategy{},
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk69) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载控制信息
	d.strategy.AsyncLoad(d.room.MySqlEngine(), gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk69) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk69) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入
func (d *Desk69) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game69.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game69.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game69.GAME_MODE_NORMAL, &sence.Buffer)
	sence.BetIndex = d.betidx
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
	d.strategy.Set(d.Random(), d.config.Rtp, d.config.GameWeight)
}

// 游戏消息
func (d *Desk69) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game69.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game69.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {
				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk69, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// 转换
func (d *Desk69) ConvertBuffer(dec *[10]int, src *[game69.ROW_DEF][game69.COL_DEF]int) {
	idex := 0
	for col := 0; col < game69.COL_DEF; col++ {
		for row := 0; row < game69.ROW_DEF; row++ {
			if col == 0 || col == 2 {
				if row == 3 {
					continue
				}
			}
			dec[idex] = src[row][col]
			idex++
		}
	}
}

// 必输的
func (d *Desk69) RandMustLoseBuffer(buff *[10]int) {
	arr := []int{game69.GAME_SOLT_1, game69.GAME_SOLT_2, game69.GAME_SOLT_3, game69.GAME_SOLT_4, game69.GAME_SOLT_5, game69.GAME_SOLT_6}
	common.Shuffle(d.Random(), arr)
	//找出三个随机填充左右两边
	arrlr := []int{}
	for i := 0; i < 3; i++ {
		arrlr = append(arrlr, arr[i])
	}
	arr = arr[3:]
	tmpBuffer := [game69.ROW_DEF][game69.COL_DEF]int{}
	//填充左边
	for row := 0; row < game69.ROW_DEF-1; row++ {
		tmpBuffer[row][0] = arrlr[row]
	}
	//填充右边
	common.Shuffle(d.Random(), arrlr)
	for row := 0; row < game69.ROW_DEF-1; row++ {
		tmpBuffer[row][2] = arrlr[row]
	}
	//最后填充中间
	for row := 0; row < game69.ROW_DEF; row++ {
		if row == 3 {
			tmpBuffer[row][1] = common.RandValue(d.Random(), arr)
		} else {
			tmpBuffer[row][1] = arr[row]
		}
	}
	//转换
	d.ConvertBuffer(buff, &tmpBuffer)
}

// 随机图案
func (d *Desk69) RandBuffer(mode int, buff *[10]int) {
	tmpBuffer := [game69.ROW_DEF][game69.COL_DEF]int{}
	if mode == game69.GAME_MODE_NORMAL {
		for col := 0; col < game69.COL_DEF; col++ {
			for row := 0; row < game69.ROW_DEF; row++ {
				if col == 0 || col == 2 {
					if row == 3 {
						continue
					}
				}
				tmpBuffer[row][col] = common.CalcWeight(d.Random(), d.config.Normal[col])
			}
		}
	} else {
		selectType := common.CalcWeight(d.Random(), d.config.Special.Select)
		//左右两边要相同的
		for col := 0; col < game69.COL_DEF; col++ {
			if col == 1 {
				continue
			}
			for row := 0; row < game69.ROW_DEF-1; row++ {
				tmpBuffer[row][col] = selectType
			}
		}
		//中间这一列
		for row := 0; row < game69.ROW_DEF; row++ {
			tmpBuffer[row][1] = common.CalcWeight(d.Random(), d.config.Special.Fill[selectType])
		}
	}
	//转换
	d.ConvertBuffer(buff, &tmpBuffer)
}

func (d *Desk69) GetSoltTypeMult(soltType int) (mult int) {
	switch soltType {
	case game69.GAME_SOLT_0:
		mult = game69.GAME_SOLT_0_MULT
	case game69.GAME_SOLT_1:
		mult = game69.GAME_SOLT_1_MULT
	case game69.GAME_SOLT_2:
		mult = game69.GAME_SOLT_2_MULT
	case game69.GAME_SOLT_3:
		mult = game69.GAME_SOLT_3_MULT
	case game69.GAME_SOLT_4:
		mult = game69.GAME_SOLT_4_MULT
	case game69.GAME_SOLT_5:
		mult = game69.GAME_SOLT_5_MULT
	case game69.GAME_SOLT_6:
		mult = game69.GAME_SOLT_6_MULT
	case game69.GAME_SOLT_WILD:
		mult = game69.GAME_SOLT_WILD_MULT
	}
	return
}

// 处理下注逻辑
func (d *Desk69) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "gbet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game69.LINE_COUNT
	//回复下注结果
	gameResult := game69.OxGameResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game69.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//控制修改
	d.strategy.Control(idx, d.config.GameWeight, game69.GAME_MODE_SPECIAL)
	d.DebugGameMsgf(pUserData, "game weight:%v", d.config.GameWeight)
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//出图
	gameResult.GameInfo, gameResult.Win = d.DoBuffer(addPool, betScore, calcScore)
	gameResult.Wins = gameResult.Win
	//推送中台下注结果
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk69, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

// 随机游戏
func (d *Desk69) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

// 判断是否全是一样的
func (d *Desk69) IsSame(buffer *[10]int) bool {
	bYes := true
	for i := 1; i < 10; i++ {
		if buffer[i] != buffer[0] {
			bYes = false
			break
		}
	}
	return bYes
}

func (d *Desk69) DoBuffer(addPool, betScore, calcScore int64) (gameInfo game69.CalcSlotGameInfo, totalScore int64) {
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		//初始化
		gameInfo = game69.CalcSlotGameInfo{
			FuNiuMode: false,
			RoundList: make([]game69.OxRoundInfo, 0),
			PriceList: make([]game69.Prize, 0),
		}
		//游戏总分
		totalScore = 0
		//随机本局游戏
		mode := d.RandGame(d.config.GameWeight)
		//判断模式
		if mode == game69.GAME_MODE_NORMAL {
			//游戏对局数据
			gameRoundInfo := game69.OxRoundInfo{
				JinNiuMode: false,
			}
			//随机图案
			d.RandBuffer(mode, &gameRoundInfo.CurrentShape)
			//不允许金牛模式在普通中
			if d.IsSame(&gameRoundInfo.CurrentShape) {
				continue
			}
			//计算得分
			gameInfo.PriceList, gameInfo.LotterySize = d.CalcScore(calcScore, &gameRoundInfo)
			gameInfo.Wins = gameInfo.LotterySize
			if gameRoundInfo.JinNiuMode {
				gameInfo.Wins = gameInfo.Wins * 10
			}
			totalScore = gameInfo.Wins
			//记录对局数据
			gameInfo.RoundList = append(gameInfo.RoundList, gameRoundInfo)
		} else {
			gameInfo.FuNiuMode = true
			i := 0
			for i < game69.MAX_FREE_CACHE {
				//游戏对局数据
				gameRoundInfo := game69.OxRoundInfo{
					JinNiuMode: false,
				}
				//随机图案
				d.RandBuffer(mode, &gameRoundInfo.CurrentShape)
				//计算得分
				gameInfo.PriceList, gameInfo.LotterySize = d.CalcScore(calcScore, &gameRoundInfo)
				gameInfo.Wins = gameInfo.LotterySize
				if gameRoundInfo.JinNiuMode {
					gameInfo.Wins = gameInfo.Wins * 10
				}
				//记录对局数据
				gameInfo.RoundList = append(gameInfo.RoundList, gameRoundInfo)
				//退出
				if gameInfo.Wins > 0 {
					totalScore = gameInfo.Wins
					break
				}
			}
			if i >= game69.MAX_FREE_CACHE && totalScore <= 0 {
				//免费局数太多了
				continue
			}
		}
		//奖励弹窗
		gameInfo.PriceType = d.CalcWinMultTip(betScore, totalScore)
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		gameInfo = d.RandMustLoseGameInfo()
		//赢分0
		totalScore = 0
	}
	return
}

// 随机必输的游戏图案
func (d *Desk69) RandMustLoseGameInfo() (game game69.CalcSlotGameInfo) {
	game = game69.CalcSlotGameInfo{
		FuNiuMode: false,
		RoundList: make([]game69.OxRoundInfo, 0),
		PriceList: make([]game69.Prize, 0),
	}
	//游戏对局数据
	gameRoundInfo := game69.OxRoundInfo{
		JinNiuMode: false,
	}
	//必输图
	d.RandMustLoseBuffer(&gameRoundInfo.CurrentShape)
	//记录对局数据
	game.RoundList = append(game.RoundList, gameRoundInfo)
	return
}

// 计算弹窗提示
func (d *Desk69) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk69) CalcScore(calcScore int64, roundInfo *game69.OxRoundInfo) (prizes []game69.Prize, totalScore int64) {
	//初始化列表
	prizes = make([]game69.Prize, 0)
	//定义线
	Lines := [game69.LINE_COUNT][game69.COL_DEF]int{
		{2, 6, 9},
		{2, 5, 9},
		{2, 5, 8},
		{1, 5, 9},
		{1, 5, 8},
		{1, 4, 8},
		{1, 4, 7},
		{0, 4, 8},
		{0, 4, 7},
		{0, 3, 7},
	}
	//循环遍历线
	for idx, line := range Lines {
		pass := true
		realIcon := roundInfo.CurrentShape[line[0]]
		for i := 1; i < game69.COL_DEF; i++ {
			v := roundInfo.CurrentShape[line[i]]
			if v == game69.GAME_SOLT_WILD {
				continue
			}
			if realIcon == game69.GAME_SOLT_WILD {
				if v != game69.GAME_SOLT_WILD {
					realIcon = v
				}
			}
			if realIcon != v {
				pass = false
				break
			}
		}
		//记录明细
		if pass {
			//图案的倍率
			mult := d.GetSoltTypeMult(realIcon)
			//奖励明细
			prize := game69.Prize{
				Icon:       realIcon,
				PeiLv:      mult,
				BelongLine: idx + 1,
				Position:   Lines[idx],
				PriceValue: int64(mult) * calcScore,
			}
			for i := 0; i < game69.COL_DEF; i++ {
				prize.PriceCount[i] = roundInfo.CurrentShape[line[i]]
			}
			prizes = append(prizes, prize)
		}
	}
	//总分
	totalScore = 0
	for i := 0; i < len(prizes); i++ {
		totalScore += prizes[i].PriceValue
	}
	roundInfo.JinNiuMode = false
	//Ox奖金倍数
	if d.IsSame(&roundInfo.CurrentShape) {
		roundInfo.JinNiuMode = true
	}
	return
}
