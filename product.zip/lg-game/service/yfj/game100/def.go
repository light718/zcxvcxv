package game100

import (
	"t77/lg/service/protocol"
)

// 主命令是固定的 MAIN_GAME
// 游戏子命令定义
const (
	SUB_GAME_SENCE     = 0 //场景协议
	SUB_GAME_BET_STAGE = 2 //游戏阶段
	SUB_GAME_BET_REQ   = 3 //下注请求
	SUB_GAME_BET_RESP  = 4 //下注返回
	SUB_GAME_FLEE_REQ  = 5 //逃跑请求
	SUB_GAME_FLEE_RESP = 6 //逃跑返回
)

// const (
// 	//下注自定义消息
// 	ROOM_COSTOM_MESSAGE_API_BET_RESULT = iota
// 	ROOM_COSTOM_MESSAGE_API_FLEE_RESULT
// )

const (
	ROOM_STAGE_BET  = iota //押注阶段
	ROOM_STAGE_PLAY        //游戏阶段
	ROOM_STAGE_END         //结束阶段
)

const (
	TIMER_START_BET  = iota //游戏开始下注定时器ID
	TIMER_START_PLAY        //游戏开始
	TIMER_UPDATE            //更新定时器ID
)

const MAX_SLOT_COUNT = 2

const (
	MASK_DEFAULT = iota //初始状态
	MASK_BETTING        //下注中
	MASK_FLEEING        //逃跑中
)

// 游戏配置结构
type GameConfig struct {
	Version   int     `yaml:"Version"`
	BetConfig []int64 `yaml:"BetConfig"`
	BetTime   int64   `yaml:"BetTime"`
	Update    int     `yaml:"Update"`
	EndTime   int     `yaml:"EndTime"`
	Mult      []struct {
		Min    float64 `yaml:"Min"`
		Max    float64 `yaml:"Max"`
		Weight int     `yaml:"Weight"`
	} `yaml:"Mult"`
	Quad struct {
		A float64 `yaml:"a"`
		B float64 `yaml:"b"`
		C float64 `yaml:"c"`
	} `yaml:"Quad"`
}

// 场景协议
type GameSence struct {
	protocol.ProtocolBase
	BetConfig []int64 `json:"BetConfig"`
	Version   int     `json:"Version"`
	Stage     int     `json:"Stage"`
}

// 游戏阶段
type GameStage struct {
	protocol.ProtocolBase
	Stage int `json:"Stage"`
}

// 游戏下注
type GameBetReq struct {
	protocol.ProtocolBase
	SlotIndex int     `json:"SlotIndex"`
	BetIndex  int     `json:"BetIndex"`
	Flee      float64 `json:"Flee"`
}

// 游戏下注
type GameBetResp struct {
	protocol.ProtocolBase
	Result    int     `json:"result"`
	SlotIndex int     `json:"SlotIndex"`
	BetIndex  int     `json:"BetIndex"`
	Flee      float64 `json:"Flee"`
}

// 游戏逃跑
type GameFleeReq struct {
	protocol.ProtocolBase
	SlotIndex int `json:"SlotIndex"`
}

// 游戏逃跑返回
type GameFleeResp struct {
	protocol.ProtocolBase
	Result    int   `json:"result"`
	SlotIndex int   `json:"SlotIndex"`
	Wins      int64 `json:"Wins"`
	Points    int64 `json:"Points"`
}

// 下注明细结构
type RoundDetail struct {
	GameId    int     //游戏
	Serial    int64   //序列号
	UserId    int64   //用户ID
	Sid       int64   //网络ID
	Account   string  //账户
	Token     string  //token
	Timestamp int64   //时间戳
	SlotIndex int     //槽位索引
	BetIndex  int     //下注索引
	Bets      int64   //下注
	Mask      int     //掩码
	Flee      float64 //逃离倍数
	Cashout   bool    //是否已经提取
	Wins      int64   //赢分
	OrderNo   string  //订单号
	ApiCode   int     //api返回码
}

func (detail *RoundDetail) Clone() *RoundDetail {
	other := &RoundDetail{}
	*other = *detail
	return other
}

type Round struct {
	Details [MAX_SLOT_COUNT]RoundDetail
}
