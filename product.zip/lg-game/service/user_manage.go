package service

import (
	"net"
)

type UserData struct {
	id        int64  //id
	account   string //账户
	nickname  string //昵称
	gid       int    //请求登录的游戏
	sid       int64  //网络会话
	rid       int    //房间ID
	did       int    //桌子ID
	seat      int    //座位号
	score     int64  //身上的积分
	token     string //token 用户真正的令牌
	tokenCode string //tokenCode，登录用来找到真正用户的token
	ip        net.IP //登录的IP
	ins       string //服务的实例
}

func (src *UserData) Clone() (dec *UserData) {
	dec = &UserData{}
	dec = src
	if len(src.ip) > 0 {
		dec.ip = make(net.IP, len(src.ip))
		copy(dec.ip, src.ip)
	}
	return
}

type UserManage struct {
	users  map[int64]*UserData
	online map[int64]int64
}

func NewUserManage() (mgr *UserManage) {
	mgr = &UserManage{
		users:  make(map[int64]*UserData),
		online: make(map[int64]int64),
	}
	return
}

func (mgr *UserManage) GetOnlineUser(sid int64) (*UserData, bool) {
	if uid, exist := mgr.online[sid]; exist {
		if val, ok := mgr.users[uid]; ok {
			return val, true
		}
	}
	return nil, false
}

func (mgr *UserManage) SetOnlineUser(sid int64, user *UserData) {
	mgr.online[sid] = user.id
	mgr.users[user.id] = user
}

func (mgr *UserManage) DelOnline(sid int64) {
	delete(mgr.online, sid)
}

func (mgr *UserManage) DelOnlineUser(sid int64) {
	if uid, exist := mgr.online[sid]; exist {
		delete(mgr.users, uid)
	}
	delete(mgr.online, sid)
}

func (mgr *UserManage) GetUserData(uid int64) (*UserData, bool) {
	if val, ok := mgr.users[uid]; ok {
		return val, ok
	}
	return nil, false
}

func (mgr *UserManage) Range(fn func(uid int64, user *UserData) bool) {
	for k, v := range mgr.users {
		ok := fn(k, v)
		if !ok {
			return
		}
	}
}
