package service

type Setting struct {
	ID       int     //数据库自增ID
	GameId   int     //游戏ID
	GameType int     //游戏类型
	GameName string  //游戏名字
	Ratio    float64 //服务费
	Maintain int     //维护状态
}
