package service

type RoomManage struct {
	//房间ID
	identity int
	//服务指针
	pService *Service
	//当前被使用的房间列表
	activats map[int]*Room //rid => room
}

func NewRoomManage(p *Service) (manage *RoomManage) {
	manage = &RoomManage{
		identity: 0,
		pService: p,
		activats: make(map[int]*Room),
	}
	return
}

// 创建房间
func (mgr *RoomManage) Create(set *Setting, stock int64) (room *Room) {
	mgr.identity++
	room = NewRoom(mgr.identity, set, stock, mgr)
	mgr.activats[mgr.identity] = room
	return room
}

// 获取某类 游戏房间
func (mgr *RoomManage) GetGameRoom(gid int) *Room {
	var room *Room
	mgr.Range(func(rid int, r *Room) bool {
		if r.set.GameId == gid {
			room = r
			return false
		}
		return true
	})
	return room
}

// 获取房间
func (mgr *RoomManage) GetRoom(rid int) (*Room, bool) {
	r, ok := mgr.activats[rid]
	return r, ok
}

// 获取桌子
func (mgr *RoomManage) GetDesk(rid, did int) (IDeskEvent, bool) {
	if r, ok := mgr.activats[rid]; ok {
		return r.GetDesk(did)
	}
	return nil, false
}

func (mgr *RoomManage) DelDesk(rid, did int) {
	if r, ok := mgr.activats[rid]; ok {
		r.DelDesk(did)
	}
}

func (mgr *RoomManage) DelRoom(rid int) {
	delete(mgr.activats, rid)
}

// 遍历房间
func (mgr *RoomManage) Range(fn func(rid int, r *Room) bool) {
	for k, v := range mgr.activats {
		ok := fn(k, v)
		if !ok {
			return
		}
	}
}

// 获取房间数量
func (mgr *RoomManage) Count() int {
	return len(mgr.activats)
}
