package service

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"t77/lg/service/protocol"
	"time"

	"math/rand"

	"github.com/rs/zerolog"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

const (
	SUB_GAME_LEAVE_REQ  = 255 //请求离开房间
	SUB_GAME_LEAVE_RESP = 256 //请求离开房间回复
)

type (
	IDeskEvent interface {
		//异步
		AsyncLoad(gid int, uid int64)
		//属性
		ID() int
		//事件
		OnSence(pUserData *UserData)
		OnDisconnected(pUserData *UserData)
		OnTimer(tid int, para1, para2 interface{})
		OnMessage(sid int64, cmd int, message []byte)
		OnCostomMessage(id int, para1, para2 interface{})
		//操作
		SitDown(pUserData *UserData) bool
		StandUp(seat int)
		QueryStandUp() bool
	}
	//桌子结构
	Desk struct {
		//房间ID
		id int
		//房间
		room *Room
		//椅子
		seats []int64
		//掩码
		mask int
		//最大座位
		max_seat int
	}
)

func NewDesk(id, max_seat int, room *Room, log *zerolog.Logger) *Desk {
	return &Desk{
		id:       id,
		room:     room,
		mask:     0,
		max_seat: max_seat,
		seats:    make([]int64, max_seat),
	}
}
func (d *Desk) ID() int {
	return d.id
}

// 异步初始化
func (d *Desk) AsyncLoad(gid int, uid int64) {

}

// 事件
func (d *Desk) OnSence(pUserData *UserData) {
	//记录redis
	in := map[string]interface{}{}
	in["game"] = d.GameID()
	in["ip"] = pUserData.ip.String()
	in["nickname"] = pUserData.nickname
	d.Submit(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine, uid int64, val map[string]interface{}) {
		rkey := fmt.Sprintf("%s:%d", RDS_GMAE_LOGIN_KEY, uid)
		redis.C.HSet(context.Background(), rkey, val)
		redis.C.Expire(context.Background(), rkey, time.Hour*24)
	}, d.RedisEngine(), pUserData.id, in)
}

// 事件
func (d *Desk) OnDisconnected(pUserData *UserData) {
	//移除玩家所在实例
	d.Submit(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine, uid int64) {
		redis.C.Del(context.Background(), fmt.Sprintf("%s:%d", RDS_GMAE_LOGIN_KEY, uid))
	}, d.RedisEngine(), pUserData.id)
	//是否是主动离开还是被动离开
	if common.IsBitSet(d.mask, define.ROOM_MASK_0) {
		//主动离开删除登录token
		d.Submit(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine, token string) {
			redis.C.Del(context.Background(), fmt.Sprintf("T77_lg_game_api:playerTokens:%s", token))
		}, d.RedisEngine(), pUserData.token)
	} else {
		//否则重新打上登录token
		d.Submit(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine, token, tokenCode string) {
			redis.C.SetNX(context.Background(), fmt.Sprintf("T77_lg_game_api:tokensCodes:%s", tokenCode),
				fmt.Sprintf("playerTokens:%s", token), time.Minute*time.Duration(30))
		}, d.RedisEngine(), pUserData.token, pUserData.tokenCode)
	}
}

// 事件
func (d *Desk) OnTimer(tid int, para1, para2 interface{}) {

}

// 事件
func (d *Desk) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case SUB_GAME_LEAVE_REQ:
		{
			d.DebugGameMsgf(pUserData, "req leave room")
			d.mask = common.SetBit(d.mask, define.ROOM_MASK_0)
			resp := protocol.ProtocolBase{
				MainCmd: protocol.MAIN_GAME,
				SubCmd:  SUB_GAME_LEAVE_RESP,
			}
			d.Send(sid, resp)
		}
	}
}

// 事件
func (d *Desk) OnCostomMessage(id int, para1, para2 interface{}) {

}

// 设置定时器
func (d *Desk) SetTimer(tid int, expire time.Duration, para1, para2 interface{}) {
	d.room.pRoomMgr.pService.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_ROOM,
		d.room.id, d.id, tid, expire, para1, para2)
}

// 删除定时器
func (d *Desk) DelTimer(tid int) {
	d.room.pRoomMgr.pService.timerEngine.Del(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_ROOM,
		d.room.id, d.id, tid)
}

// 推送自定义消息
func (d *Desk) PushCostomMessage(id int, para1, para2 interface{}) {
	d.room.pRoomMgr.pService.PushCostomMessage(COSTOM_MODULE_LOGIC, COSTOM_LOGIC_ROOM,
		d.room.id, d.id, id, para1, para2)
}

// 异步
func (d *Desk) Submit(fn interface{}, args ...interface{}) {
	d.room.Submit(fn, args...)
}

// 异步（链式）
func (d *Desk) Task(fn interface{}, args ...interface{}) (ct *coroutines.CoroutineTask) {
	return d.room.Task(fn, args...)
}

// 发送消息
func (d *Desk) Send(sid int64, obj interface{}) {
	if datas, err := json.Marshal(obj); err == nil {
		d.SendData(sid, datas)
	}
}

// 发送消息
func (d *Desk) SendData(sid int64, data []byte) {
	d.room.SendData(sid, data)
}

// 广播消息
func (d *Desk) Broadcast(obj interface{}) {
	if datas, err := json.Marshal(obj); err == nil {
		for _, v := range d.seats {
			pUser, exist := d.GetUserData(v)
			if exist {
				d.SendData(pUser.sid, datas)
			}
		}
	}
}

// 广播消息
func (d *Desk) BroadcastMessage(message []byte) {
	for _, v := range d.seats {
		pUser, exist := d.GetUserData(v)
		if exist {
			d.SendData(pUser.sid, message)
		}
	}
}

// 日志调试
func (d *Desk) DebugGameMsgf(pUserData *UserData, format string, v ...interface{}) {
	if pUserData != nil {
		d.room.log.Debug().Str("category", "game").
			Int64("uid", pUserData.id).
			Str("nickname", pUserData.nickname).
			Str("account", pUserData.account).
			Int("game", d.room.set.GameId).Int("desk", d.id).Msgf(format, v...)
	} else {
		d.room.log.Debug().Str("category", "game").
			Int("game", d.room.set.GameId).Int("desk", d.id).Msgf(format, v...)
	}
}

func (d *Desk) ErrorGameMsgf(pUserData *UserData, format string, v ...interface{}) {
	if pUserData != nil {
		d.room.log.Error().Str("category", "game").
			Int64("uid", pUserData.id).
			Str("nickname", pUserData.nickname).
			Str("account", pUserData.account).
			Int("game", d.room.set.GameId).Int("desk", d.id).Msgf(format, v...)
	} else {
		d.room.log.Error().Str("category", "game").
			Int("game", d.room.set.GameId).Int("desk", d.id).Msgf(format, v...)
	}
}

func (d *Desk) WarnameMsgf(pUserData *UserData, format string, v ...interface{}) {
	if pUserData != nil {
		d.room.log.Warn().Str("category", "game").
			Int64("uid", pUserData.id).
			Str("nickname", pUserData.nickname).
			Str("account", pUserData.account).
			Int("game", d.room.set.GameId).Int("desk", d.id).Msgf(format, v...)
	} else {
		d.room.log.Warn().Str("category", "game").
			Int("game", d.room.set.GameId).Int("desk", d.id).Msgf(format, v...)
	}
}

func (d *Desk) GetOnlineUser(sid int64) (*UserData, bool) {
	return d.room.pRoomMgr.pService.userMgr.GetOnlineUser(sid)
}

func (d *Desk) GetUserData(user int64) (*UserData, bool) {
	return d.room.pRoomMgr.pService.userMgr.GetUserData(user)
}

func (d *Desk) GameID() int {
	return d.room.set.GameId
}

func (d *Desk) Random() *rand.Rand {
	return d.room.random
}

// Redis引擎
func (d *Desk) RedisEngine() *engine.RedisEngine {
	return d.room.RedisEngine()
}

// 数据库引擎
func (d *Desk) MySqlEngine() *engine.MySqlEngine {
	return d.room.MySqlEngine()
}

// ///////////////////////////////////////////////////////////////////////////

// 坐下
func (d *Desk) SitDown(pUserData *UserData) bool {
	pUserData.did = d.id
	for i := 0; i < d.max_seat; i++ {
		if d.seats[i] <= 0 {
			d.seats[i] = pUserData.id
			pUserData.seat = i
			return true
		}
	}
	return false
}

func (d *Desk) QueryStandUp() bool {
	return true
}

// 站起
func (d *Desk) StandUp(seat int) {
	if seat < 0 || seat >= d.max_seat {
		return
	}
	d.seats[seat] = 0
}

// ///////////////////////////////////////////////////////////////////////////
func (d *Desk) CheckMaintain() (int, bool) {
	if d.room.set.Maintain > 0 {
		return define.GAME_RESULT_MAINTAIN, false
	}
	return 0, true
}

func (d *Desk) AsyncGetSlotBetIndex(gid int, uid int64) (betidx int) {
	row := d.MySqlEngine().QueryRow("SELECT bet_idx FROM `t_game_bet_index` WHERE game_id = ? AND user_id = ?", gid, uid)
	if err := row.Scan(&betidx); err == sql.ErrNoRows {
		d.MySqlEngine().Exec(`INSERT INTO t_game_bet_index(game_id,user_id) VALUES (?,?)`, gid, uid)
	}
	return
}

// 记录下注索引
func (d *Desk) SaveSlotBetIndex(uid int64, idx int) {
	d.Submit(func(ct *coroutines.CoroutineTask, mysql *engine.MySqlEngine, gid int, uid int64, idx int) {
		mysql.Exec("UPDATE t_game_bet_index SET bet_idx = ? WHERE game_id = ? AND user_id = ?", idx, gid, uid)
	}, d.MySqlEngine(), d.GameID(), uid, idx)
}

func (d *Desk) CheckScore(betScore, userScore int64) (int, bool) {
	//比较
	if userScore < betScore {
		return define.GAME_RESULT_SCORE_NOT_ENOUGH, false
	}
	return define.GAME_RESULT_OK, true
}

// 计算入池分
func (d *Desk) CalcPoolAndTaxScore(betScore int64) (addpool int64, tax int64) {
	addpool = int64((1.0 - d.room.set.Ratio) * float64(betScore))
	tax = int64(d.room.set.Ratio * float64(betScore))
	return
}

// 检查水果机的水池
func (d *Desk) CheckSlotStock(firstIdx int, addPool, checkScore int64) bool {
	return d.room.CheckSlotStock(firstIdx, addPool, checkScore)
}

func (d *Desk) GetJackpot() int64 {
	return d.room.GetJackpot()
}

func (d *Desk) AddJackpot(val int64) {
	d.room.AddJackpot(val)
}

// 百分比来扣减当前库存
func (d *Desk) SubJackpotByPct(pct int) int64 {
	decrement := d.GetJackpot() * int64(pct) / 100
	d.room.SubJackpot(decrement)
	return decrement
}
