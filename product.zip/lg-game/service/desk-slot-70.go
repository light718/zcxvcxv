package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game70"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

// 游戏玩法结构
type Desk70 struct {
	Desk
	config   *game70.GameConfig //游戏配置
	betidx   int                //下注配置的索引
	result   game70.HHSCResult  //游戏结果
	strategy *slot.Strategy     //控制策略
}

// 初始化
func NewDeskGame70(id, max_seat int, room *Room) (d *Desk70) {
	d = &Desk70{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx:   0,
		strategy: &slot.Strategy{},
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk70) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载控制信息
	d.strategy.AsyncLoad(d.room.MySqlEngine(), gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk70) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk70) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入
func (d *Desk70) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game70.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game70.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game70.GAME_MODE_NORMAL, &sence.Buffer)
	sence.BetIndex = d.betidx
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
	d.strategy.Set(d.Random(), d.config.Rtp, d.config.GameWeight)
}

// 游戏消息
func (d *Desk70) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game70.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game70.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {
				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk70, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// //////////////////////////////////////////////////////////////////////

// 必输的
func (d *Desk70) RandMustLoseBuffer(buff *[game70.BUFF_SIZE]int) {
	arr := []int{game70.GAME_SOLT_1, game70.GAME_SOLT_2, game70.GAME_SOLT_3, game70.GAME_SOLT_4, game70.GAME_SOLT_5, game70.GAME_SOLT_6}
	common.Shuffle(d.Random(), arr)
	//前面两列不允许相同的
	idex := 0
	for col := 0; col < game70.COL_DEF-1; col++ {
		for row := 0; row < game70.ROW_DEF; row++ {
			rowidx := row * game70.ROW_DEF
			buff[rowidx+col] = arr[idex]
			idex++
		}
	}
	//最后一列随机
	idex = 0
	common.Shuffle(d.Random(), arr)
	for col := 2; col < game70.COL_DEF; col++ {
		for row := 0; row < game70.ROW_DEF; row++ {
			rowidx := row * game70.ROW_DEF
			buff[rowidx+col] = arr[idex]
			idex++
		}
	}
}

func (d *Desk70) areArraysEqual(arr1, arr2 [game70.BUFF_SIZE]int) bool {
	for i := range arr1 {
		if arr1[i] != arr2[i] {
			return false
		}
	}
	return true
}

func (d *Desk70) PritnfLine(selType int) {
	Lines := [game70.LINE_COUNT][game70.COL_DEF]int{
		{3, 4, 5},
		{0, 1, 2},
		{6, 7, 8},
		{0, 4, 8},
		{6, 4, 2},
	}

	lists := [1000][game70.BUFF_SIZE]int{}
	idx := 0
	for {
		//建立一个对局
		roundInfo := game70.SlotRoundInfoMessage{
			Prize: make([]game70.SlotPrizeInfoMessage, 0),
		}
		lineidx := []int{0, 1, 2, 3, 4}
		for i := 0; i < 4; i++ {
			rdx := common.RandIndex(d.Random(), lineidx)
			idx := lineidx[rdx]
			for _, v := range Lines[idx] {
				roundInfo.Shape[v] = selType
			}
			lineidx = append(lineidx[:rdx], lineidx[rdx+1:]...)
		}

		arrs := []int{}
		for j := 0; j < game70.BUFF_SIZE; j++ {
			if roundInfo.Shape[j] == game70.GAME_SOLT_EMPTY {
				arrs = append(arrs, j)
			}
		}
		fillcount := common.RandInt(d.Random(), len(arrs)+1)
		for fillcount > 0 {
			rdx := common.RandIndex(d.Random(), arrs)
			idx := arrs[rdx]
			roundInfo.Shape[idx] = selType
			arrs = append(arrs[:rdx], arrs[rdx+1:]...)
			fillcount--
		}

		val := d.CalcScore(0, 100, &roundInfo)
		if val > 0 && roundInfo.LineCount == 4 {
			pass := true
			for ck := 0; ck < idx; ck++ {
				danqian := lists[ck]
				same := d.areArraysEqual(roundInfo.Shape, danqian)
				if same {
					pass = false
					break
				}
			}
			if pass {
				lists[idx] = roundInfo.Shape
				fmt.Printf("%v\r\n", lists[idx])
				idx++
			}
		}

	}
}

func (d *Desk70) CalcLineCount(buff *[game70.BUFF_SIZE]int) (count int) {
	//定义线
	Lines := [game70.LINE_COUNT][game70.COL_DEF]int{
		{3, 4, 5},
		{0, 1, 2},
		{6, 7, 8},
		{0, 4, 8},
		{6, 4, 2},
	}
	//循环遍历线
	for _, line := range Lines {
		pass := true
		realIcon := buff[line[0]]
		for i := 1; i < game70.COL_DEF; i++ {
			v := buff[line[i]]
			//都是空图标
			if realIcon == game70.GAME_SOLT_EMPTY ||
				v == game70.GAME_SOLT_EMPTY {
				pass = false
				break
			}
			if v == game70.GAME_SOLT_WILD {
				continue
			}
			//判断百搭
			if realIcon == game70.GAME_SOLT_WILD {
				if v != game70.GAME_SOLT_WILD && v != game70.GAME_SOLT_EMPTY {
					realIcon = v
				}
			}
			if realIcon != v {
				pass = false
				break
			}
		}
		//记录明细
		if pass {
			count++
		}
	}
	return
}

// 随机图案
func (d *Desk70) RandSpecialBuffer(selType int, buff *[game70.BUFF_SIZE]int) int {
	count := common.CalcWeight(d.Random(), d.config.Special.Fill[selType].Weight) + 1
	for {
		for i := 0; i < game70.BUFF_SIZE; i++ {
			buff[i] = game70.GAME_SOLT_EMPTY
		}
		switch count {
		case 1:
			{
				idx := common.RandInt(d.Random(), len(game70.RewardOneLine))
				for k, v := range game70.RewardOneLine[idx] {
					if v == 0 {
						continue
					}
					if d.config.Special.Fill[selType].WildProbability > 0 {
						rval := common.RandRangeValue(d.Random(), 1, 100)
						if rval <= d.config.Special.Fill[selType].WildProbability {
							buff[k] = game70.GAME_SOLT_WILD
							continue
						}
					}
					buff[k] = selType
				}
				calccount := d.CalcLineCount(buff)
				if calccount != 1 {
					d.WarnameMsgf(nil, "rand special buffer need line count %d,but calc count:%d", 1, calccount)
					continue
				}
			}
		case 2:
			{
				idx := common.RandInt(d.Random(), len(game70.RewardTowLine))
				for k, v := range game70.RewardTowLine[idx] {
					if v == 0 {
						continue
					}
					if d.config.Special.Fill[selType].WildProbability > 0 {
						rval := common.RandRangeValue(d.Random(), 1, 100)
						if rval <= d.config.Special.Fill[selType].WildProbability {
							buff[k] = game70.GAME_SOLT_WILD
							continue
						}
					}
					buff[k] = selType
				}
				calccount := d.CalcLineCount(buff)
				if calccount != 2 {
					d.WarnameMsgf(nil, "rand special buffer need line count %d,but calc count:%d", 2, calccount)
					continue
				}
			}
		case 3:
			{
				idx := common.RandInt(d.Random(), len(game70.RewardThreeLine))
				for k, v := range game70.RewardThreeLine[idx] {
					if v == 0 {
						continue
					}
					if d.config.Special.Fill[selType].WildProbability > 0 {
						rval := common.RandRangeValue(d.Random(), 1, 100)
						if rval <= d.config.Special.Fill[selType].WildProbability {
							buff[k] = game70.GAME_SOLT_WILD
							continue
						}
					}
					buff[k] = selType
				}
				calccount := d.CalcLineCount(buff)
				if calccount != 3 {
					d.WarnameMsgf(nil, "rand special buffer need line count %d,but calc count:%d", 3, calccount)
					continue
				}
			}
		case 4:
			{
				idx := common.RandInt(d.Random(), len(game70.RewardFourLine))
				for k, v := range game70.RewardFourLine[idx] {
					if v == 0 {
						continue
					}
					if d.config.Special.Fill[selType].WildProbability > 0 {
						rval := common.RandRangeValue(d.Random(), 1, 100)
						if rval <= d.config.Special.Fill[selType].WildProbability {
							buff[k] = game70.GAME_SOLT_WILD
							continue
						}
					}
					buff[k] = selType
				}
				calccount := d.CalcLineCount(buff)
				if calccount != 4 {
					d.WarnameMsgf(nil, "rand special buffer need line count %d,but calc count:%d", 4, calccount)
					continue
				}
			}
		case 5:
			{
				for k, v := range game70.RewardFiveLine[0] {
					if v == 0 {
						continue
					}
					if d.config.Special.Fill[selType].WildProbability > 0 {
						rval := common.RandRangeValue(d.Random(), 1, 100)
						if rval <= d.config.Special.Fill[selType].WildProbability {
							buff[k] = game70.GAME_SOLT_WILD
							continue
						}
					}
					buff[k] = selType
				}
				calccount := d.CalcLineCount(buff)
				if calccount != 5 {
					d.WarnameMsgf(nil, "rand special buffer need line count %d,but calc count:%d", 5, calccount)
					continue
				}
			}
		}

		if selType != game70.GAME_SOLT_WILD {
			//不能全变百搭了
			isAllWild := true
			for i := 0; i < game70.BUFF_SIZE; i++ {
				if buff[i] != game70.GAME_SOLT_EMPTY && buff[i] != game70.GAME_SOLT_WILD {
					isAllWild = false
					break
				}
			}
			if isAllWild {
				continue
			}
		}
		break
	}
	result := 0
	for i := 0; i < game70.BUFF_SIZE; i++ {
		if buff[i] > game70.GAME_SOLT_EMPTY {
			result++
		}
	}
	return result
}

// 根据规则填充
func (d *Desk70) FillSpecialBufferByRule(targetIcon int, fillRule *[]int, tagbuff, last, buff *[game70.BUFF_SIZE]int, add *map[string]int) bool {
	if last != nil {
		for i := 0; i < game70.BUFF_SIZE; i++ {
			buff[i] = last[i]
		}
	}
	arrs := []int{}
	for i := 0; i < game70.BUFF_SIZE; i++ {
		if tagbuff[i] > game70.GAME_SOLT_EMPTY {
			if tagbuff[i] != buff[i] {
				arrs = append(arrs, i)
			}
		}
	}
	//完全一致了
	if len(arrs) <= 0 {
		return true
	}
	common.Shuffle(d.Random(), arrs)
	count := (*fillRule)[0]
	if last == nil && targetIcon != game70.GAME_SOLT_WILD && count == 1 {
		//非百搭图案 第一个不能为百搭
		if tagbuff[arrs[0]] == game70.GAME_SOLT_WILD {
			for i := 1; i < len(arrs); i++ {
				if tagbuff[arrs[i]] != game70.GAME_SOLT_WILD {
					//交换
					arrs[0], arrs[i] = arrs[i], arrs[0]
					break
				}
			}
		}
	}
	for i := 0; i < count; i++ {
		idx := arrs[0]
		buff[idx] = tagbuff[idx]
		(*add)[strconv.FormatInt(int64(idx), 10)] = buff[idx]
		arrs = arrs[1:]
	}
	//删除头
	(*fillRule) = (*fillRule)[1:]
	return d.IsAllFill(buff)
}

// 判断是否图案全满
func (d *Desk70) IsAllFill(buff *[game70.BUFF_SIZE]int) bool {
	allFill := true
	for i := 0; i < game70.BUFF_SIZE; i++ {
		if buff[i] <= 0 {
			allFill = false
			break
		}
	}
	return allFill
}

func (d *Desk70) RandBuffer(mode int, buff *[game70.BUFF_SIZE]int) (selType int) {
	if mode == game70.GAME_MODE_NORMAL {
		for col := 0; col < game70.COL_DEF; col++ {
			for row := 0; row < game70.ROW_DEF; row++ {
				rowidx := row * game70.COL_DEF
				buff[rowidx+col] = common.CalcWeight(d.Random(), d.config.Normal[col])
			}
		}
	} else {
		selType = common.CalcWeight(d.Random(), d.config.Special.Select)
	}
	return
}

func (d *Desk70) GetSoltTypeMult(soltType int) (mult int) {
	switch soltType {
	case game70.GAME_SOLT_EMPTY:
		mult = game70.GAME_SOLT_0_MULT
	case game70.GAME_SOLT_1:
		mult = game70.GAME_SOLT_1_MULT
	case game70.GAME_SOLT_2:
		mult = game70.GAME_SOLT_2_MULT
	case game70.GAME_SOLT_3:
		mult = game70.GAME_SOLT_3_MULT
	case game70.GAME_SOLT_4:
		mult = game70.GAME_SOLT_4_MULT
	case game70.GAME_SOLT_5:
		mult = game70.GAME_SOLT_5_MULT
	case game70.GAME_SOLT_6:
		mult = game70.GAME_SOLT_6_MULT
	case game70.GAME_SOLT_WILD:
		mult = game70.GAME_SOLT_WILD_MULT
	}
	return
}

// 检查是否 免费
func (d *Desk70) CheckFree(buff *[game70.BUFF_SIZE]int) bool {
	if d.IsAllWild(buff) {
		return false
	}
	bFree := true
	for row := 0; row < game70.ROW_DEF; row++ {
		rowidx := row * game70.ROW_DEF
		if buff[rowidx+1] != game70.GAME_SOLT_WILD {
			bFree = false
			break
		}
	}
	return bFree
}

// 处理下注逻辑
func (d *Desk70) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "bet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game70.LINE_COUNT
	//回复下注结果
	gameResult := game70.HHSCResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game70.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//控制修改
	d.strategy.Control(idx, d.config.GameWeight, game70.GAME_MODE_SPECIAL)
	d.DebugGameMsgf(pUserData, "game weight:%v", d.config.GameWeight)
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//出图
	gameResult.GameInfo, gameResult.Wins = d.DoBuffer(addPool, betScore, calcScore)
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk70, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

// 随机游戏
func (d *Desk70) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk70) IsAllWild(buffer *[game70.BUFF_SIZE]int) bool {
	bYes := true
	for i := 0; i < game70.BUFF_SIZE; i++ {
		if buffer[i] != game70.GAME_SOLT_WILD {
			bYes = false
			break
		}
	}
	return bYes
}

func (d *Desk70) combinationsHelper(target int, current []int, result *[][]int) {
	if target == 0 {
		temp := make([]int, len(current))
		copy(temp, current)
		*result = append(*result, temp)
		return
	}
	start := 1
	if len(current) > 0 {
		start = current[len(current)-1]
	}
	for i := start; i <= target; i++ {
		if i <= target {
			d.combinationsHelper(target-i, append(current, i), result)
		}
	}
}

// 数字拆解
func (d *Desk70) CombinationSum(target int) (result [][]int) {
	tmp := [][]int{}
	d.combinationsHelper(target, []int{}, &tmp)
	//去头
	tmp = tmp[1:]
	//去尾
	tmp = tmp[:len(tmp)-1]
	for i := 0; i < len(tmp); i++ {
		if len(tmp[i]) <= 4 {
			result = append(result, tmp[i])
		}
	}
	return result
}

func (d *Desk70) DoBuffer(addPool, betScore, calcScore int64) (gameInfo game70.CalcSlotGameInfo, totalScore int64) {
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		//游戏总分
		totalScore = 0
		//游戏对局数据
		gameInfo = game70.CalcSlotGameInfo{}
		//随机本局游戏
		gameMode := d.RandGame(d.config.GameWeight)
		//判断模式
		if gameMode == game70.GAME_MODE_NORMAL {
			//建立一个对局
			roundInfo := game70.SlotRoundInfoMessage{
				Prize: make([]game70.SlotPrizeInfoMessage, 0),
			}
			//随机图案
			d.RandBuffer(game70.GAME_MODE_NORMAL, &roundInfo.Shape)
			//计算奖励
			totalScore = d.CalcScore(game70.GAME_MODE_NORMAL, calcScore, &roundInfo)
			//加入回复列表
			gameInfo.RoundInfo = append(gameInfo.RoundInfo, roundInfo)
		} else {
			//随机图案
			gameInfo.HhscIcon = d.RandBuffer(game70.GAME_MODE_SPECIAL, nil)
			targetbuff := [game70.BUFF_SIZE]int{}
			tagCount := d.RandSpecialBuffer(gameInfo.HhscIcon, &targetbuff)
			combinations := d.CombinationSum(tagCount)
			idx := common.RandInt(d.Random(), len(combinations))
			rule := combinations[idx]
			checksum := 0
			for _, v := range rule {
				checksum += v
			}
			if checksum != tagCount {
				d.ErrorGameMsgf(nil, "checksum:%d != tagCount:%d", checksum, tagCount)
				continue
			}
			common.Shuffle(d.Random(), rule)
			for {
				//建立一个对局
				roundInfo := game70.SlotRoundInfoMessage{
					Prize: make([]game70.SlotPrizeInfoMessage, 0),
					Add:   make(map[string]int),
				}
				pass := false
				if len(gameInfo.RoundInfo) <= 0 {
					pass = d.FillSpecialBufferByRule(gameInfo.HhscIcon, &rule, &targetbuff, nil, &roundInfo.Shape, &roundInfo.Add)
				} else {
					last := len(gameInfo.RoundInfo) - 1
					pass = d.FillSpecialBufferByRule(gameInfo.HhscIcon, &rule, &targetbuff, &gameInfo.RoundInfo[last].Shape, &roundInfo.Shape, &roundInfo.Add)
				}
				gameInfo.RoundInfo = append(gameInfo.RoundInfo, roundInfo)
				if pass {
					break
				}
			}
			last := len(gameInfo.RoundInfo) - 1
			//计算奖励
			totalScore = d.CalcScore(game70.GAME_MODE_SPECIAL, calcScore, &gameInfo.RoundInfo[last])
		}
		//奖励弹窗
		gameInfo.Num = d.CalcWinMultTip(betScore, totalScore)
		gameInfo.LotterySize = totalScore
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		//游戏对局数据
		gameInfo = d.RandMustLoseGameInfo()
		//赢分0
		totalScore = 0
	}
	return
}

// 随机必输的游戏图案
func (d *Desk70) RandMustLoseGameInfo() (gameInfo game70.CalcSlotGameInfo) {
	//游戏对局数据
	gameInfo = game70.CalcSlotGameInfo{}
	//建立一个对局
	roundInfo := game70.SlotRoundInfoMessage{
		Prize: make([]game70.SlotPrizeInfoMessage, 0),
	}
	//必输图
	d.RandMustLoseBuffer(&roundInfo.Shape)
	//加入缓存
	gameInfo.RoundInfo = append(gameInfo.RoundInfo, roundInfo)
	return
}

// 计算弹窗提示
func (d *Desk70) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk70) CalcScore(mode int, calcScore int64, roundInfo *game70.SlotRoundInfoMessage) (totalScore int64) {
	//定义线
	Lines := [game70.LINE_COUNT][game70.COL_DEF]int{
		{3, 4, 5},
		{0, 1, 2},
		{6, 7, 8},
		{0, 4, 8},
		{6, 4, 2},
	}
	//循环遍历线
	for idx, line := range Lines {
		pass := true
		realIcon := roundInfo.Shape[line[0]]
		for i := 1; i < game70.COL_DEF; i++ {
			v := roundInfo.Shape[line[i]]
			//都是空图标
			if realIcon == game70.GAME_SOLT_EMPTY ||
				v == game70.GAME_SOLT_EMPTY {
				pass = false
				break
			}
			if v == game70.GAME_SOLT_WILD {
				continue
			}
			//判断百搭
			if realIcon == game70.GAME_SOLT_WILD {
				if v != game70.GAME_SOLT_WILD && v != game70.GAME_SOLT_EMPTY {
					realIcon = v
				}
			}
			if realIcon != v {
				pass = false
				break
			}
		}
		//记录明细
		if pass {
			//中奖数量
			roundInfo.LineCount++
			//图案的倍率
			mult := d.GetSoltTypeMult(realIcon)
			//倍率累计
			roundInfo.Multiple += mult
			//奖励明细
			prize := game70.SlotPrizeInfoMessage{
				Icon:      realIcon,
				Count:     3,
				Type:      1,
				Value:     int64(mult) * calcScore,
				Line:      idx + 1,
				IconIndex: line,
			}
			roundInfo.Prize = append(roundInfo.Prize, prize)
		}
	}
	for i := 0; i < len(roundInfo.Prize); i++ {
		totalScore += roundInfo.Prize[i].Value
	}

	//如果是特殊模式
	if mode == game70.GAME_MODE_SPECIAL {
		//铺满全屏的话
		if d.IsAllFill(&roundInfo.Shape) {
			totalScore *= 10
		}
	}
	return
}
