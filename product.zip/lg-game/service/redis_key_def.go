package service

//一般游戏相关的
const RDS_GMAE_POOL_KEY = "T77:Game:Pool"
const RDS_GMAE_RECORDS_KEY = "T77:Game:Record"
const RDS_GMAE_DISCONNECTION_KEY = "T77:Game:Disconnection"
const RDS_GMAE_LOGIN_KEY = "T77:Game:Login"
const RDS_GMAE_Bet_KEY = "T77:Game:Bet"
const RDS_GMAE_JACKPOT_KEY = "T77:Game:Jackpot"
