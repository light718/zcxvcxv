package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game71"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

// 游戏玩法结构
type Desk71 struct {
	Desk
	config   *game71.GameConfig //游戏配置
	betidx   int                //下注配置的索引
	result   game71.GameResult  //游戏结果
	strategy *slot.Strategy     //控制策略
}

// 初始化
func NewDeskGame71(id, max_seat int, room *Room) (d *Desk71) {
	d = &Desk71{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx:   0,
		strategy: &slot.Strategy{},
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk71) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载控制信息
	d.strategy.AsyncLoad(d.room.MySqlEngine(), gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk71) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk71) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入
func (d *Desk71) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game71.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game71.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game71.GAME_MODE_NORMAL, &sence.Buffer, nil, 0)
	sence.BetIndex = d.betidx
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
	d.strategy.Set(d.Random(), d.config.Rtp, d.config.GameWeight)
}

// 游戏消息
func (d *Desk71) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game71.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game71.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {

				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk71, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// //////////////////////////////////////////////////////////////////////

// 转换
func (d *Desk71) ConvertBuffer(mode int, dec *[10]int, cashBuff *[10]int64, src *[game71.ROW_DEF][game71.COL_DEF]int, betScore int64, cashMult []int) {
	idex := 0
	for col := 0; col < game71.COL_DEF; col++ {
		for row := 0; row < game71.ROW_DEF; row++ {
			if col == 0 || col == 2 {
				if row == 3 {
					continue
				}
			}
			if src[row][col] == game71.GAME_SOLT_CASH {
				if cashBuff != nil {
					//计算倍率
					mult := float64(0)
					if mode == game71.GAME_MODE_NORMAL {
						mult = d.GetCashMult(common.CalcWeight(d.Random(), cashMult))
					} else {
						mult = d.GetCashMult(common.CalcWeight(d.Random(), cashMult))
					}
					cashBuff[idex] = int64(float64(betScore) * mult)
				}
			}
			dec[idex] = src[row][col]
			idex++
		}
	}
}

// 必输的
func (d *Desk71) RandMustLoseBuffer(buff *[10]int) {
	arr := []int{game71.GAME_SOLT_1, game71.GAME_SOLT_2, game71.GAME_SOLT_3, game71.GAME_SOLT_4, game71.GAME_SOLT_5, game71.GAME_SOLT_6}
	common.Shuffle(d.Random(), arr)
	//找出三个随机填充左右两边
	arrlr := []int{}
	for i := 0; i < 3; i++ {
		arrlr = append(arrlr, arr[i])
	}
	arr = arr[3:]
	tmpBuffer := [game71.ROW_DEF][game71.COL_DEF]int{}
	//填充左边
	for row := 0; row < game71.ROW_DEF-1; row++ {
		tmpBuffer[row][0] = arrlr[row]
	}
	//填充右边
	common.Shuffle(d.Random(), arrlr)
	for row := 0; row < game71.ROW_DEF-1; row++ {
		tmpBuffer[row][2] = arrlr[row]
	}
	//最后填充中间
	for row := 0; row < game71.ROW_DEF; row++ {
		if row == 3 {
			tmpBuffer[row][1] = common.RandValue(d.Random(), arr)
		} else {
			tmpBuffer[row][1] = arr[row]
		}
	}
	//转换
	d.ConvertBuffer(game71.GAME_MODE_NORMAL, buff, nil, &tmpBuffer, 0, d.config.Normal.CashMult)
}

// 检查现金图案的个数
func (d *Desk71) CheckCashCount(buff *[10]int) int {
	cash := 0
	for i := 0; i < 10; i++ {
		if buff[i] == game71.GAME_SOLT_CASH {
			cash++
		}
	}
	return cash
}

// 随机图案
func (d *Desk71) RandBuffer(mode int, buff *[10]int, cashBuff *[10]int64, betScore int64) {
	tmpBuffer := [game71.ROW_DEF][game71.COL_DEF]int{}
	if mode == game71.GAME_MODE_NORMAL {
		for col := 0; col < game71.COL_DEF; col++ {
			for row := 0; row < game71.ROW_DEF; row++ {
				if col == 0 || col == 2 {
					if row == 3 {
						continue
					}
				}
				tmpBuffer[row][col] = common.CalcWeight(d.Random(), d.config.Normal.Weight[col])
			}
		}
		//转换
		d.ConvertBuffer(mode, buff, cashBuff, &tmpBuffer, betScore, d.config.Normal.CashMult)
	} else if mode == game71.GAME_MODE_Cash {
		arrs := []int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9}
		cashCount := common.CalcWeight(d.Random(), d.config.Cash.Num) + 5
		for i := 0; i < cashCount; i++ {
			ridx := common.RandIndex(d.Random(), arrs)
			idx := arrs[ridx]
			buff[idx] = game71.GAME_SOLT_CASH
			mult := d.GetCashMult(common.CalcWeight(d.Random(), d.config.Cash.CashMult))
			cashBuff[idx] = int64(float64(betScore) * mult)
			arrs = append(arrs[:ridx], arrs[ridx+1:]...)
		}
		arr := []int{game71.GAME_SOLT_1, game71.GAME_SOLT_2, game71.GAME_SOLT_3, game71.GAME_SOLT_4, game71.GAME_SOLT_5, game71.GAME_SOLT_6}
		common.Shuffle(d.Random(), arr)
		for k, v := range arrs {
			buff[v] = arr[k]
		}
	} else {
		for col := 0; col < game71.COL_DEF; col++ {
			for row := 0; row < game71.ROW_DEF; row++ {
				if col == 0 || col == 2 {
					if row == 3 {
						continue
					}
				}
				idx := common.CalcWeight(d.Random(), d.config.Special.Fill[col])
				if idx == 0 {
					tmpBuffer[row][col] = game71.GAME_SOLT_EMPTY
				} else {
					tmpBuffer[row][col] = game71.GAME_SOLT_CASH
				}
			}
		}
		//转换
		d.ConvertBuffer(mode, buff, cashBuff, &tmpBuffer, betScore, d.config.Special.CashMult)
	}
}

func (d *Desk71) GetSoltTypeMult(soltType int) (mult int) {
	switch soltType {
	case game71.GAME_SOLT_CASH:
		mult = game71.GAME_SOLT_0_MULT
	case game71.GAME_SOLT_1:
		mult = game71.GAME_SOLT_1_MULT
	case game71.GAME_SOLT_2:
		mult = game71.GAME_SOLT_2_MULT
	case game71.GAME_SOLT_3:
		mult = game71.GAME_SOLT_3_MULT
	case game71.GAME_SOLT_4:
		mult = game71.GAME_SOLT_4_MULT
	case game71.GAME_SOLT_5:
		mult = game71.GAME_SOLT_5_MULT
	case game71.GAME_SOLT_6:
		mult = game71.GAME_SOLT_6_MULT
	case game71.GAME_SOLT_WILD:
		mult = game71.GAME_SOLT_WILD_MULT
	}
	return
}

func (d *Desk71) GetCashMult(cashIdx int) (mult float64) {
	switch cashIdx {
	case game71.GAME_CASH_0_MULT:
		mult = 0.5
	case game71.GAME_CASH_1_MULT:
		mult = 1
	case game71.GAME_CASH_5_MULT:
		mult = 5
	case game71.GAME_CASH_10_MULT:
		mult = 10
	case game71.GAME_CASH_50_MULT:
		mult = 50
	case game71.GAME_CASH_100_MULT:
		mult = 100
	case game71.GAME_CASH_500_MULT:
		mult = 500
	}
	return
}

// 处理下注逻辑
func (d *Desk71) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "bet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game71.LINE_COUNT
	//回复下注结果
	gameResult := game71.GameResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game71.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//控制修改
	d.strategy.Control(idx, d.config.GameWeight, game71.GAME_MODE_SPECIAL)
	d.DebugGameMsgf(pUserData, "game weight:%v", d.config.GameWeight)
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//出图
	gameResult.GameInfo, gameResult.Win = d.DoBuffer(addPool, betScore, calcScore)
	gameResult.Wins = gameResult.Win
	//推送中台下注结果
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk71, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

// 随机游戏
func (d *Desk71) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk71) DoBuffer(addPool, betScore, calcScore int64) (gameInfo game71.CalcSlotGameInfo, totalScore int64) {
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		//初始化
		gameInfo = game71.CalcSlotGameInfo{
			BunnyMode: false,
			RoundList: make([]game71.RoundInfo, 0),
			PriceList: make([]game71.Prize, 0),
		}
		//游戏总分
		totalScore = 0
		//随机本局游戏
		mode := d.RandGame(d.config.GameWeight)
		//判断模式
		if mode == game71.GAME_MODE_NORMAL || mode == game71.GAME_MODE_Cash {
			//游戏对局数据
			roundInfo := game71.RoundInfo{
				CashMode: false,
			}
			//随机图案
			d.RandBuffer(mode, &roundInfo.CurrentShape, &roundInfo.CashShape, betScore)
			if mode == game71.GAME_MODE_NORMAL {
				if d.CheckCashCount(&roundInfo.CurrentShape) >= 5 {
					continue
				}
			}
			//计算得分
			gameInfo.PriceList, totalScore = d.CalcScore(calcScore, &roundInfo)
			//记录对局数据
			gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
		} else {
			gameInfo.BunnyMode = true
			for i := 0; i < game71.MAX_FREE_CACHE; i++ {
				//每局得分
				freeScore := int64(0)
				//游戏对局数据
				roundInfo := game71.RoundInfo{
					CashMode:     true,
					CurrentCount: game71.MAX_FREE_CACHE - i - 1,
				}
				//随机图案
				d.RandBuffer(mode, &roundInfo.CurrentShape, &roundInfo.CashShape, betScore)
				//计算得分
				gameInfo.PriceList, freeScore = d.CalcScore(calcScore, &roundInfo)
				//记录对局数据
				gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
				//累计免费总得分
				totalScore += freeScore
			}
		}
		//奖励弹窗
		gameInfo.PriceType = d.CalcWinMultTip(betScore, totalScore)
		//总赢分
		gameInfo.Wins = totalScore
		gameInfo.LotterySize = totalScore

		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		gameInfo = d.RandMustLoseGameInfo()
		//赢分0
		totalScore = 0
	}
	return
}

// 随机必输的游戏图案
func (d *Desk71) RandMustLoseGameInfo() (gameInfo game71.CalcSlotGameInfo) {
	gameInfo = game71.CalcSlotGameInfo{
		BunnyMode: false,
		RoundList: make([]game71.RoundInfo, 0),
		PriceList: make([]game71.Prize, 0),
	}
	//游戏对局数据
	gameRoundInfo := game71.RoundInfo{
		CashMode: false,
	}
	//必输图
	d.RandMustLoseBuffer(&gameRoundInfo.CurrentShape)
	//记录对局数据
	gameInfo.RoundList = append(gameInfo.RoundList, gameRoundInfo)
	return
}

// 计算弹窗提示
func (d *Desk71) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk71) CalcScore(calcScore int64, roundInfo *game71.RoundInfo) (prizes []game71.Prize, totalScore int64) {
	//初始化
	totalScore = 0
	prizes = make([]game71.Prize, 0)
	//定义线
	Lines := [game71.LINE_COUNT][game71.COL_DEF]int{
		{2, 6, 9},
		{2, 5, 9},
		{2, 5, 8},
		{1, 5, 9},
		{1, 5, 8},
		{1, 4, 8},
		{1, 4, 7},
		{0, 4, 8},
		{0, 4, 7},
		{0, 3, 7},
	}
	//计算金钱
	cashCount := 0
	cacheScore := int64(0)
	for i := 0; i < 10; i++ {
		if roundInfo.CashShape[i] > 0 {
			cashCount++
			cacheScore += roundInfo.CashShape[i]
		}
	}
	//5个或者更多才奖励
	if cashCount >= 5 {
		roundInfo.CashValue = cacheScore
		totalScore += cacheScore
	}
	//循环遍历线
	for idx, line := range Lines {
		pass := true
		realIcon := roundInfo.CurrentShape[line[0]]
		for i := 1; i < game71.COL_DEF; i++ {
			v := roundInfo.CurrentShape[line[i]]
			//都是现金图标
			if realIcon == game71.GAME_SOLT_CASH ||
				v == game71.GAME_SOLT_CASH {
				pass = false
				break
			}
			//都是空图标
			if realIcon == game71.GAME_SOLT_EMPTY ||
				v == game71.GAME_SOLT_EMPTY {
				pass = false
				break
			}
			if v == game71.GAME_SOLT_WILD {
				continue
			}
			if realIcon == game71.GAME_SOLT_WILD {
				if v != game71.GAME_SOLT_WILD {
					realIcon = v
				}
			}
			if realIcon != v {
				pass = false
				break
			}
		}
		//记录明细
		if pass {
			//图案的倍率
			mult := d.GetSoltTypeMult(realIcon)
			//奖励明细
			prize := game71.Prize{
				Icon:       realIcon,
				PeiLv:      mult,
				BelongLine: idx + 1,
				Position:   Lines[idx],
				PriceValue: int64(mult) * calcScore,
			}
			for i := 0; i < game71.COL_DEF; i++ {
				prize.PriceCount[i] = roundInfo.CurrentShape[line[i]]
			}
			prizes = append(prizes, prize)
		}
	}
	//总分
	for i := 0; i < len(prizes); i++ {
		totalScore += prizes[i].PriceValue
	}
	roundInfo.PriceValue = totalScore
	return
}
