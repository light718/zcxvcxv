package service

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"t77/lg/service/protocol"
	"t77/lg/service/yfj/game100"
	"time"

	"t77/lg/service/api"

	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/define"

	"gopkg.in/yaml.v3"
)

// CricketX
type Desk100 struct {
	Desk
	serial     int64                    //序列号
	stage      int                      //当前阶段
	launchtime float64                  //游戏开始时间
	expectTime float64                  //预期的时间
	totalwin   int64                    //玩家累计赢
	totalbet   int64                    //玩家累计下注
	bet        int64                    //本局
	rounds     map[int64]*game100.Round //对局数据
	autoflees  []int64                  //自动逃跑列表
	mult       float64                  //初始倍数
	expectMult float64                  //要执行的倍数
	config     *game100.GameConfig      //游戏配置
	update     int64                    //帧率
}

func NewDeskGame100(id, max_seat int, room *Room) (d *Desk100) {
	d = &Desk100{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		stage:      -1,
		totalwin:   0,
		totalbet:   0,
		bet:        0,
		mult:       0.0,
		expectMult: 0.0,
	}
	d.LoadConfig()
	d.BetStage()
	return
}

// 加载配置
func (d *Desk100) LoadConfig() {
	path := fmt.Sprintf("./conf/game_%d.yaml", d.GameID())
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 用户进入
func (d *Desk100) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game100.GameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game100.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
		Stage:     d.stage,
	}
	d.Send(pUserData.sid, sence)
}

// 网络断开
func (d *Desk100) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	switch d.stage {
	case game100.ROOM_STAGE_BET:
		{
			//取消订单
			if val, ok := d.rounds[pUserData.id]; ok {
				for i := 0; i < game100.MAX_SLOT_COUNT; i++ {
					if val.Details[i].Bets > 0 {

					}
				}
				//清空下注信息
				delete(d.rounds, pUserData.id)
			}
		}
	case game100.ROOM_STAGE_PLAY:
		{
			//算逃跑

		}
	}
}

// 自定义消息
func (d *Desk100) OnCostomMessage(id int, para1, para2 interface{}) {
	// switch id {
	// case game100.ROOM_COSTOM_MESSAGE_API_BET_RESULT:
	// 	{
	// 		// detail := para1.(*game100.RoundDetail)
	// 		// detail.Mask = game100.MASK_DEFAULT
	// 		// pUser, exist := d.GetUserData(detail.UserId)
	// 		// if !exist {
	// 		// 	d.ErrorGameMsgf("serial:[%d] bet result,but user:%d not exist", detail.Serial, detail.UserId)
	// 		// 	return
	// 		// }
	// 		// resp := game100.GameBetResp{
	// 		// 	ProtocolBase: protocol.ProtocolBase{
	// 		// 		MainCmd: protocol.MAIN_GAME,
	// 		// 		SubCmd:  game100.SUB_GAME_BET_RESP,
	// 		// 	},
	// 		// 	Result:    define.GAME_RESULT_BET_ERROR,
	// 		// 	Flee:      detail.Flee,
	// 		// 	SlotIndex: detail.SlotIndex,
	// 		// 	BetIndex:  detail.BetIndex,
	// 		// }
	// 		// if detail.ApiCode == define.API_BET_RESULT_OK && detail.Serial == d.serial {
	// 		// 	resp.Result = define.GAME_RESULT_OK
	// 		// 	//加入自动逃跑队列
	// 		// 	if detail.Flee > 0 {
	// 		// 		d.autoflees = append(d.autoflees, detail)
	// 		// 	}
	// 		// } else {
	// 		// 	//取消订单
	// 		// 	d.Submit(func(args ...interface{}) {

	// 		// 	}, d, detail.Clone())
	// 		// 	//清空下注
	// 		// 	*detail = game100.RoundDetail{}
	// 		// }
	// 		// //通知客户端
	// 		// d.Send(pUser.sid, resp)
	// 	}
	// case game100.ROOM_COSTOM_MESSAGE_API_FLEE_RESULT:
	// 	{
	// 		// detail := para1.(*game100.RoundDetail)
	// 		// detail.Cashout = true
	// 		// detail.Mask = game100.MASK_DEFAULT
	// 		// pUser, exist := d.GetUserData(detail.UserId)
	// 		// if !exist {
	// 		// 	d.ErrorGameMsgf("serial:[%d] flee result,but user:%d not exist", detail.Serial, detail.UserId)
	// 		// 	return
	// 		// }
	// 		// resp := game100.GameFleeResp{
	// 		// 	ProtocolBase: protocol.ProtocolBase{
	// 		// 		MainCmd: protocol.MAIN_GAME,
	// 		// 		SubCmd:  game100.SUB_GAME_FLEE_RESP,
	// 		// 	},
	// 		// 	Result:    define.GAME_RESULT_BET_ERROR,
	// 		// 	SlotIndex: detail.SlotIndex,
	// 		// }
	// 		// if detail.ApiCode == define.API_BET_RESULT_OK && detail.Serial == d.serial {
	// 		// 	//加到身上积分
	// 		// 	pUser.score += detail.Wins
	// 		// 	resp.Result = define.GAME_RESULT_OK
	// 		// 	resp.Wins = detail.Wins
	// 		// 	resp.Points = pUser.score
	// 		// } else {
	// 		// 	//取消订单
	// 		// 	d.Submit(func(args ...interface{}) {

	// 		// 	}, d, detail.Clone())
	// 		// }
	// 		// //通知客户端逃跑结果
	// 		// d.Send(pUser.sid, resp)
	// 	}
	// }
}

// 房间定时器
// tid 实际的定时器ID编号
func (d *Desk100) OnTimer(tid int, para1, para2 interface{}) {
	switch tid {
	case game100.TIMER_START_BET:
		d.BetStage()
	case game100.TIMER_START_PLAY:
		d.PlayStage()
	case game100.TIMER_UPDATE:
		d.Update()
	}
}

// 游戏消息
func (d *Desk100) OnMessage(sid int64, cmd int, message []byte) {
	switch cmd {
	case game100.SUB_GAME_BET_REQ:
		d.GameBetReq(sid, message)
	case game100.SUB_GAME_FLEE_REQ:
		d.GameFleeReq(sid, message)
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// 生成序列号
func (d *Desk100) GenerateSerial(timestamp int64) int64 {
	//4字节时间戳+2字节游戏ID+2字节随机值
	serial := int64(0)
	serial = timestamp << 32
	serial |= (int64(d.GameID()) << 16)
	serial |= (int64(d.Random().Intn(65535)))
	return serial
}

// 开始下注阶段
func (d *Desk100) BetStage() {
	if d.stage == game100.ROOM_STAGE_BET {
		return
	}
	d.mult = 1.0
	d.serial = d.GenerateSerial(time.Now().Unix())
	d.rounds = make(map[int64]*game100.Round)
	d.autoflees = make([]int64, 0)
	d.stage = game100.ROOM_STAGE_BET
	d.bet = 0
	d.BroadcastStage(d.stage)
	d.SetTimer(game100.TIMER_START_PLAY, time.Second*time.Duration(d.config.BetTime), nil, nil)
	d.DebugGameMsgf(nil, "serial:[%d] start bet", d.serial)
}

// 获取预期倍数
func (d *Desk100) GetExpectMult() float64 {
	weight := make([]int, len(d.config.Mult))
	for i := 0; i < len(d.config.Mult); i++ {
		weight[i] = d.config.Mult[i].Weight
	}
	idx := common.CalcWeight(d.Random(), weight)
	min, max := int(d.config.Mult[idx].Min*100), int(d.config.Mult[idx].Max*100)
	val := common.RandRangeValue(d.Random(), min, max)
	return float64(val) / 100
}

// 通过倍数计算时间
func (d *Desk100) CalcTimeByMult(mult float64) float64 {
	c := d.config.Quad.C - mult
	b := d.config.Quad.B
	a := d.config.Quad.A
	return (math.Sqrt(b*b-4*a*c) - b) / (2 * a)
}

// 通过时间计算倍数
func (d *Desk100) CalcMultByTime(t float64) float64 {
	multf := d.config.Quad.A*t*t + d.config.Quad.B*t + d.config.Quad.C
	//保留两位小数即可
	multi := int64(multf * 100)
	return float64(multi) / 100.0
}

// 精度用0.01秒
func (d *Desk100) GetGameTime() float64 {
	return float64(time.Now().UnixMilli()) / 1000
}

// 游戏开始阶段
func (d *Desk100) PlayStage() {
	if d.stage == game100.ROOM_STAGE_PLAY {
		return
	}
	d.update = 0
	d.stage = game100.ROOM_STAGE_PLAY
	d.launchtime = d.GetGameTime()
	//获取预期倍数
	d.expectMult = d.GetExpectMult()
	d.expectTime = d.CalcTimeByMult(d.expectMult)
	//控制
	for d.bet > 0 {
		win := d.bet * int64(d.expectMult*100) / 100
		if win+d.totalwin < d.totalbet {
			break
		}
		d.expectMult = float64(int64(d.expectMult*100)-1) / 100
		d.expectTime = d.CalcTimeByMult(d.expectMult)
		if d.expectMult <= 1.0 {
			break
		}
	}
	d.BroadcastStage(d.stage)
	d.SetTimer(game100.TIMER_UPDATE, time.Millisecond, nil, nil)
	d.DebugGameMsgf(nil, "serial:[%d] start play [boom mult:%0.2f]", d.serial, d.expectMult)
}

// 不停飞行阶段
func (d *Desk100) Update() {
	if d.stage != game100.ROOM_STAGE_PLAY {
		return
	}
	//diff := int64(0)
	if d.update != 0 {
		//diff = time.Now().UnixMilli() - d.update
	}
	d.update = time.Now().UnixMilli()
	elapsed := d.GetGameTime() - d.launchtime
	d.mult = d.CalcMultByTime(elapsed)
	//d.DebugGameMsgf("update mult:%0.2f elapsed:%0.2f-%dms", d.mult, elapsed, diff)
	d.BroadcastMult(d.mult)
	if elapsed >= d.expectTime {
		d.End()
		return
	}
	for _, v := range d.autoflees {
		d.AutoFlee(v)
	}
	d.SetTimer(game100.TIMER_UPDATE, time.Millisecond*time.Duration(d.config.Update), nil, nil)
}

// 广播倍数
func (d *Desk100) BroadcastMult(mult float64) {
	resp := game100.GameStage{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game100.SUB_GAME_BET_STAGE,
		},
	}
	if data, err := json.Marshal(resp); err == nil {
		for i := 0; i < 100; i++ {
			d.SendData(0, data)
		}
	}
}

// 广播游戏当前阶段
func (d *Desk100) BroadcastStage(stage int) {
	resp := game100.GameStage{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game100.SUB_GAME_BET_STAGE,
		},
		Stage: stage,
	}
	d.Broadcast(resp)
}

// 游戏结束阶段
func (d *Desk100) End() {
	if d.stage == game100.ROOM_STAGE_END {
		return
	}
	d.DebugGameMsgf(nil, "serial:[%d] end", d.serial)
	d.stage = game100.ROOM_STAGE_END
	d.BroadcastStage(d.stage)
	for _, v := range d.rounds {
		for i := 0; i < game100.MAX_SLOT_COUNT; i++ {
			if v.Details[i].Bets > 0 && !v.Details[i].Cashout {

			}
		}
	}
	d.SetTimer(game100.TIMER_START_BET, time.Second*time.Duration(d.config.EndTime), nil, nil)
}

// 游戏下注
func (d *Desk100) GameBetReq(sid int64, message []byte) {
	//请求
	req := game100.GameBetReq{}
	if err := json.Unmarshal(message, &req); err != nil {
		//d.ErrorGameMsgf("unmarshal GameBetReq error:%v", err)
		return
	}
	//回复
	resp := game100.GameBetResp{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game100.SUB_GAME_BET_RESP,
		},
		Result:    define.GAME_RESULT_OK,
		Flee:      req.Flee,
		SlotIndex: req.SlotIndex,
		BetIndex:  req.BetIndex,
	}
	pUser, exist := d.GetOnlineUser(sid)
	if !exist {
		//d.ErrorGameMsgf("GameBetReq user not exist")
		return
	}
	var roundinfo *game100.Round = nil
	if val, exist := d.rounds[pUser.id]; exist {
		roundinfo = val
	} else {
		roundinfo = &game100.Round{}
		d.rounds[pUser.id] = roundinfo
	}
	sidx := req.SlotIndex
	bidx := req.BetIndex
	if sidx < 0 || sidx > game100.MAX_SLOT_COUNT {
		//	d.ErrorGameMsgf("slot index error:%d", sidx)
		return
	}
	if bidx < 0 || bidx >= len(d.config.BetConfig) {
		//d.ErrorGameMsgf("bet index error:%d", bidx)
		return
	}
	detail := &roundinfo.Details[sidx]
	//非游戏下注阶段
	if d.stage != game100.ROOM_STAGE_BET {
		resp.Result = define.GAME_RESULT_BET_ERROR
		d.Send(sid, resp)
		//d.ErrorGameMsgf("GameBetReq error not bet stage")
		return
	}
	//判断金额
	if d.config.BetConfig[bidx] > pUser.score {
		resp.Result = define.GAME_RESULT_SCORE_NOT_ENOUGH
		d.Send(sid, resp)
		//d.ErrorGameMsgf("GameBetReq error score not enough")
		return
	}
	//重复下注
	if detail.Bets > 0 {
		resp.Result = define.GAME_RESULT_BET_REPEAT
		d.Send(sid, resp)
		//d.ErrorGameMsgf("GameBetReq error repeat bet")
		return
	}
	//记录下注
	d.bet += d.config.BetConfig[bidx]
	d.totalbet += d.config.BetConfig[bidx]
	//记录订单信息
	now := time.Now().Unix()
	detail.GameId = d.id
	detail.Serial = d.serial
	detail.Sid = sid
	detail.UserId = pUser.id
	detail.Account = pUser.account
	detail.Token = pUser.token
	detail.Timestamp = now
	detail.SlotIndex = sidx
	detail.BetIndex = bidx
	detail.Bets = d.config.BetConfig[bidx]
	detail.Flee = req.Flee
	detail.Cashout = false
	detail.OrderNo = api.CreateGameOrder(d.Random(), d.GameID(), pUser.account, now)
	detail.Mask = game100.MASK_BETTING
	//扣除下注额度
	pUser.score -= detail.Bets
	//加入自动列表
	if req.Flee > 0 {
		d.autoflees = append(d.autoflees, pUser.id)
	}

	//回复客户端
	d.Send(sid, resp)
}

// 自动逃跑
func (d *Desk100) AutoFlee(user int64) {
	pUserData, exist := d.GetUserData(user)
	if !exist {
		d.ErrorGameMsgf(pUserData, "AutoFlee not user data:%d", user)
		return
	}
	round, exist := d.rounds[user]
	if exist {
		for i := 0; i < game100.MAX_SLOT_COUNT; i++ {
			if round.Details[i].Flee > 0 && round.Details[i].Bets > 0 && d.mult >= round.Details[i].Flee && !round.Details[i].Cashout {
				resp := game100.GameFleeResp{
					ProtocolBase: protocol.ProtocolBase{
						MainCmd: protocol.MAIN_GAME,
						SubCmd:  game100.SUB_GAME_FLEE_RESP,
					},
					Result:    define.GAME_RESULT_OK,
					SlotIndex: round.Details[i].SlotIndex,
				}
				//处理逃跑
				resp.Wins, resp.Points = d.DoFlee(pUserData, &round.Details[i], round.Details[i].Flee)
				d.Send(pUserData.sid, resp)
			}
		}
	}
}

// 处理逃跑
func (d *Desk100) DoFlee(pUserData *UserData, detail *game100.RoundDetail, mult float64) (int64, int64) {
	detail.Cashout = true
	detail.Wins = int64(float64(detail.Bets) * mult)
	//记录赢
	d.totalwin += detail.Wins
	//更新金币
	pUserData.score += detail.Wins

	return detail.Wins, pUserData.score
}

// 游戏逃跑
func (d *Desk100) GameFleeReq(sid int64, message []byte) {
	//请求
	req := game100.GameFleeReq{}
	if err := json.Unmarshal(message, &req); err != nil {
		//d.ErrorGameMsgf("unmarshal GameFleeReq error:%v", err)
		return
	}
	//回复
	resp := game100.GameFleeResp{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game100.SUB_GAME_FLEE_RESP,
		},
		Result:    define.GAME_RESULT_OK,
		SlotIndex: req.SlotIndex,
	}
	if d.stage != game100.ROOM_STAGE_PLAY {
		resp.Result = define.GAME_RESULT_BET_ERROR
		d.Send(sid, resp)
		//d.ErrorGameMsgf("GameFleeReq error not stage play")
		return
	}
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		//d.ErrorGameMsgf("GameFleeReq user not exist")
		return
	}
	roundinfo, exist := d.rounds[pUserData.id]
	if !exist {
		resp.Result = define.GAME_RESULT_BET_ERROR
		d.Send(sid, resp)
		//d.ErrorGameMsgf("GameFleeReq error not bet info")
		return
	}
	sidx := req.SlotIndex
	detail := &roundinfo.Details[sidx]
	//逃跑错误
	if detail.Bets <= 0 {
		resp.Result = define.GAME_RESULT_BET_ERROR
		d.Send(sid, resp)
		//d.ErrorGameMsgf("GameFleeReq error not bet values")
		return
	}
	//重复逃跑
	if detail.Cashout {
		resp.Result = define.GAME_RESULT_BET_ERROR
		d.Send(sid, resp)
		//d.ErrorGameMsgf("GameFleeReq error repeat flee")
		return
	}
	//处理逃跑
	resp.Wins, resp.Points = d.DoFlee(pUserData, detail, d.mult)
	//回复客户端
	d.Send(sid, resp)
}
