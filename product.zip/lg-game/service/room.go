package service

import (
	"context"
	"encoding/json"
	"fmt"
	"math/rand"
	"strconv"
	"time"

	"github.com/rs/zerolog"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

const (
	INVALID_ROOM = -1
	INVALID_DESK = -1
	INVALID_SEAT = -1
)

const (
	ITIMER_ALTER_SLOT_STOCK = iota
)

type (
	Room struct {
		//房间ID
		id int
		//游戏配置
		set *Setting
		//房间管理
		pRoomMgr *RoomManage
		//随机引擎
		random *rand.Rand
		//日志
		log *zerolog.Logger
		//桌子的序列号
		identity int
		//桌子
		deskmap map[int]IDeskEvent
		//水池值
		stock int64
		//奖池值
		jackpot int64
	}
)

func NewRoom(id int, set *Setting, stock int64, pMgr *RoomManage) (room *Room) {
	room = &Room{
		id:       id,
		set:      set,
		pRoomMgr: pMgr,
		random:   rand.New(rand.NewSource(time.Now().UnixNano())),
		log:      pMgr.pService.log,
		identity: 0,
		deskmap:  make(map[int]IDeskEvent),
		stock:    stock,
		jackpot:  10000,
	}
	if set.GameType == define.GAME_TYPE_SLOT {
		room.SetTimer(ITIMER_ALTER_SLOT_STOCK, time.Second*5, nil, nil)
	}
	return
}

func (r *Room) ID() int {
	return r.id
}

func (r *Room) Type() int {
	return r.set.GameType
}

// 根据游戏创建桌子
func (r *Room) NewDesk() IDeskEvent {
	switch r.Type() {
	case define.GAME_TYPE_SLOT:
		{
			r.identity++
			switch r.set.GameId {
			case define.QUEENOFBOUNTY:
				return NewDeskGame67(r.identity, 1, r)
			case define.MOUSE:
				return NewDeskGame68(r.identity, 1, r)
			case define.FORTUNEOX:
				return NewDeskGame69(r.identity, 1, r)
			case define.TIGER:
				return NewDeskGame70(r.identity, 1, r)
			case define.RABBIT:
				return NewDeskGame71(r.identity, 1, r)
			case define.GANESHAGOLD:
				return NewDeskGame72(r.identity, 1, r)
			case define.GATESOFOLYMPUS:
				return NewDeskGame73(r.identity, 1, r)
			case define.PIGGYGOLD:
				return NewDeskGame74(r.identity, 1, r)
			case define.DRAGONHATCH:
				return NewDeskGame75(r.identity, 1, r)
			}
		}
	case define.GAME_TYPE_YFJ:
		return NewDeskGame100(r.identity, 200, r)
	}
	return nil
}

// 获取桌子
func (r *Room) GetDesk(id int) (IDeskEvent, bool) {
	ev, exist := r.deskmap[id]
	return ev, exist
}

// 删除桌子
func (r *Room) DelDesk(did int) {
	delete(r.deskmap, did)
}

// 删除桌子
func (r *Room) SetDesk(desk IDeskEvent) {
	r.deskmap[desk.ID()] = desk
}

// 用户进入
func (r *Room) OnEnter(pUserData *UserData) {
	switch r.Type() {
	case define.GAME_TYPE_SLOT:
		{
			d := r.NewDesk()
			r.Task(func(ct *coroutines.CoroutineTask, desk IDeskEvent, gid int, uid int64) {
				//进入之前初始化游戏数据的一些事情
				desk.AsyncLoad(gid, uid)
			}, d, pUserData.gid, pUserData.id).Dispatch(func(ct *coroutines.CoroutineTask, room *Room, desk IDeskEvent, uid int64) {
				//初始化完成后再进入场景
				if pUser, exist := room.GetUserData(uid); exist {
					room.SetDesk(desk)
					if desk.SitDown(pUser) {
						desk.OnSence(pUser)
					}
				}
			}, r, d, pUserData.id).Run()
		}
	default:
		if desk, exist := r.GetDesk(0); exist {
			if desk.SitDown(pUserData) {
				desk.OnSence(pUserData)
			}
		}
	}
}

// 断线
func (r *Room) OnDisconnected(pUserData *UserData) bool {
	desk, exist := r.GetDesk(pUserData.did)
	if exist {
		desk.OnDisconnected(pUserData)
		if desk.QueryStandUp() {
			desk.StandUp(pUserData.seat)
			return true
		}
	}
	return false
}

// 房间定时器
func (r *Room) OnTimer(tid int, para1, para2 interface{}) {
	switch tid {
	case ITIMER_ALTER_SLOT_STOCK:
		{
			r.Task(func(ct *coroutines.CoroutineTask, room *Room, gid int) {
				//检查库存修改
				alter, err := room.RedisEngine().C.Get(context.Background(), fmt.Sprintf("%s:%d", RDS_GMAE_POOL_KEY, gid)).Result()
				if err == nil && alter != "" {
					ct.SaveResult(alter)
					room.RedisEngine().C.Del(context.Background(), fmt.Sprintf("%s:%d", RDS_GMAE_POOL_KEY, gid))
				}
			}, r, r.set.GameId).Dispatch(func(ct *coroutines.CoroutineTask, room *Room) {
				defer room.SetTimer(ITIMER_ALTER_SLOT_STOCK, time.Second*5, nil, nil)
				if len(ct.ResultArgs) > 0 {
					//修改最新库存
					if stock, err := strconv.ParseInt(ct.ResultArgs[0].(string), 10, 64); err == nil {
						room.stock += stock
						if room.stock < 0 {
							room.stock = 0
						}
					}
				}
			}, r).Run()
		}
	}
}

// 自定义消息
func (r *Room) OnCostomMessage(id int, para1, para2 interface{}) {

}

// 设置定时器
func (r *Room) SetTimer(tid int, expire time.Duration, para1, para2 interface{}) {
	r.pRoomMgr.pService.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_ROOM, r.id, 0, tid, expire, para1, para2)
}

// 删除定时器
func (r *Room) DelTimer(tid int) {
	r.pRoomMgr.pService.timerEngine.Del(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_ROOM, r.id, 0, tid)
}

// 推送自定义消息
func (r *Room) PushCostomMessage(id int, para1, para2 interface{}) {
	r.pRoomMgr.pService.PushCostomMessage(COSTOM_MODULE_LOGIC, COSTOM_LOGIC_ROOM, r.id, 0, id, para1, para2)
}

// 异步
func (r *Room) Submit(fn interface{}, args ...interface{}) {
	r.pRoomMgr.pService.Submit(fn, args...)
}

// 异步（链式）
func (r *Room) Task(fn interface{}, args ...interface{}) (ct *coroutines.CoroutineTask) {
	return r.pRoomMgr.pService.Task(fn, args...)
}

// 发送消息
func (r *Room) Send(sid int64, obj interface{}) {
	if datas, err := json.Marshal(obj); err == nil {
		r.SendData(sid, datas)
	}
}

// 发送消息
func (r *Room) SendData(sid int64, data []byte) {
	r.pRoomMgr.pService.SendData(sid, data)
}

// Redis引擎
func (r *Room) RedisEngine() *engine.RedisEngine {
	return r.pRoomMgr.pService.redisEngine
}

// 数据库引擎
func (r *Room) MySqlEngine() *engine.MySqlEngine {
	return r.pRoomMgr.pService.mysqlEngine
}

// 获取在线用户
func (r *Room) GetOnlineUser(sid int64) (*UserData, bool) {
	return r.pRoomMgr.pService.userMgr.GetOnlineUser(sid)
}

// 获取用户
func (r *Room) GetUserData(uid int64) (*UserData, bool) {
	return r.pRoomMgr.pService.userMgr.GetUserData(uid)
}

// 日志调试
func (r *Room) DebugGameMsgf(format string, v ...interface{}) {
	r.log.Debug().Str("category", "game").
		Int("game", r.set.GameId).Msgf(format, v...)
}

func (r *Room) ErrorGameMsgf(format string, v ...interface{}) {
	r.log.Error().Str("category", "game").
		Int("game", r.set.GameId).Msgf(format, v...)
}

func (r *Room) WarnameMsgf(format string, v ...interface{}) {
	r.log.Warn().Str("category", "game").
		Int("game", r.set.GameId).Msgf(format, v...)
}

/////////////////////////////////////////////////////////////////////////

// 检查水果机的水池
func (r *Room) CheckSlotStock(firstIdx int, addPool, checkScore int64) bool {
	if firstIdx <= 0 {
		r.stock += addPool
	}
	left := r.stock - checkScore
	if left > 0 {
		r.stock -= checkScore
		return true
	}
	return false
}

func (r *Room) GetJackpot() int64 {
	return r.jackpot
}

func (r *Room) AddJackpot(val int64) {
	r.jackpot += val
}

func (r *Room) SubJackpot(decrement int64) int64 {
	r.jackpot -= decrement
	return r.jackpot
}
