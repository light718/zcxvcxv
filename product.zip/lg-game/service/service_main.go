package service

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net"
	"net/http"
	"reflect"
	"runtime"
	"runtime/debug"
	"strings"
	"t77/lg/config"
	"time"

	"t77/lg/service/api"

	"github.com/rs/zerolog"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/engine"
	"intech.t77.com/pkg/env"
)

const SERVICE_TYPE = "T77:Service:Game"
const LOBBY_SERVICE_TYPE = "T77:Service:Lobby"

// 服务上下文类型
const (
	SERVICE_NET_WS_CONN = iota
	SERVICE_NET_WS_RECV
	SERVICE_NET_WS_CLOSE
	SERVICE_TIMER
	SERVICE_COSTOM_MESSAGE
	SERVICE_COSTOM_FUNC
	SERVICE_SUBSCRIBE_MESSAGE
	SERVICE_HTTP_MESSAGE
	SERVICE_COROUTINE_TASK_FUNC
)

// 上下文
type ServiceEngineContext struct {
	//服务上下文类型
	OptType int
	//附带参数
	Para1 interface{}
	Para2 interface{}
	Para3 interface{}
	Para4 interface{}
	Para5 interface{}
	Para6 interface{}
	Para7 interface{}
}

// 引擎
type ServiceEngine struct {
	//上下文管道
	ch chan ServiceEngineContext
	//网络引擎
	wsEngine *engine.WebSocketEngine
	//Redis引擎
	redisEngine *engine.RedisEngine
	//数据库引擎
	mysqlEngine *engine.MySqlEngine
	//定时器引擎
	timerEngine *engine.TimerEngine
	//协程池
	goPool *coroutines.Coroutines
	//http引擎
	httpEngine *engine.HttpEngine
}

// 业务逻辑
type ServiceLogic struct {
	//登录中
	logining map[int64]bool
	//网络连接数据
	conn map[int64]net.IP
	//房间数据
	roomMgr *RoomManage
	//用户管理
	userMgr *UserManage
}

type Service struct {
	//服务实例
	instance string
	//本机ip
	hostip net.IP
	//引擎模块
	ServiceEngine
	//业务逻辑模块
	ServiceLogic
	//服务配置
	conf *config.ServiceApp
	//停止标志
	stop chan struct{}
	//随机对象
	random *rand.Rand
	//日志
	log *zerolog.Logger
}

func New(hostname string, log *zerolog.Logger, c *config.ServiceApp) (srv *Service) {
	srv = &Service{
		instance: fmt.Sprintf("%s:%s", SERVICE_TYPE, hostname),
		conf:     c,
		stop:     make(chan struct{}),
		ServiceEngine: ServiceEngine{
			ch: make(chan ServiceEngineContext, 16384),
		},
		ServiceLogic: ServiceLogic{
			conn:     make(map[int64]net.IP),
			logining: make(map[int64]bool),
		},
		random: rand.New(rand.NewSource(time.Now().UnixNano())),
		log:    log,
	}

	//环境
	switch c.Env {
	case "dev":
		env.Environment = env.DEV
	case "fat":
		env.Environment = env.FAT
	case "uat":
		env.Environment = env.UAT
	case "pro":
		env.Environment = env.PRO
	}
	//engine
	srv.wsEngine = engine.NewWebSocketEngine(log, c.WsAddr, srv)
	srv.redisEngine = engine.NewRedisEngine(log, srv, c.Redis.Addrs, c.Redis.Password, c.Redis.Db)
	srv.mysqlEngine = engine.NewMySqlEngine(c.MysqlConn)
	srv.timerEngine = engine.NewTimerEngine(log, srv)
	//srv.httpEngine = engine.NewHttpEngine(log, srv, "") //暂时无http服务要求
	srv.goPool = coroutines.NewCoroutines(log, srv)
	//logic
	srv.ServiceLogic.roomMgr = NewRoomManage(srv)
	srv.ServiceLogic.userMgr = NewUserManage()
	//初始化业务环境
	srv.InitLogicModule()
	//api init
	api.BetUrl = srv.conf.Api.Bet
	api.BetTimeout = srv.conf.Api.BetTimeout
	api.BlanceUrl = srv.conf.Api.Blance
	api.BlanceTimeout = srv.conf.Api.BlanceTimeout
	api.Log = srv.log
	//本机ip
	if addrs, err := net.InterfaceAddrs(); err == nil {
		for _, address := range addrs {
			if ipnet, ok := address.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
				srv.hostip = ipnet.IP
			}
		}
	}
	return
}

// ///////////////引擎事件///////////////////////////////
func (srv *Service) OnWebSocketConnEvent(sid int64, ip net.IP) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_NET_WS_CONN,
		Para1:   sid,
		Para2:   ip,
	}
}

func (srv *Service) OnWebSocketRecvEvent(sid int64, message []byte) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_NET_WS_RECV,
		Para1:   sid,
		Para2:   message,
	}
}

func (srv *Service) OnWebSocketCloseEvent(sid int64) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_NET_WS_CLOSE,
		Para1:   sid,
	}
}

func (srv *Service) OnTimerEvent(id1, id2, id3, id4, id5 int, para1, para2 interface{}) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_TIMER,
		Para1:   id1,
		Para2:   id2,
		Para3:   id3,
		Para4:   id4,
		Para5:   id5,
		Para6:   para1,
		Para7:   para2,
	}
}

func (srv *Service) OnSubscribeMessageEvent(channel string, msg string) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_SUBSCRIBE_MESSAGE,
		Para1:   channel,
		Para2:   msg,
	}
}

func (srv *Service) HttpMassage(hid int64, msgType int, req *http.Request) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_HTTP_MESSAGE,
		Para1:   hid,
		Para2:   msgType,
		Para3:   req,
	}
}

// ////////////////////////////////////////////////////////
func (srv *Service) Once() {
	//系统相关
	srv.timerEngine.Add(ITIMER_MODULE_SERVICE, ITIMER_SERVICE_CHECK_REDIS_PING, 0, 0, 0, time.Minute, nil, nil)
	srv.timerEngine.Add(ITIMER_MODULE_SERVICE, ITIMER_SERVICE_REGISTER, 0, 0, 0, time.Second, nil, nil)
	//逻辑相关
	srv.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_UPDATE_GAME_RECORD, 0, 0, 0, time.Second*5, nil, nil)
	srv.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_CHECK_GAME_SETTING, 0, 0, 0, time.Second*20, nil, nil)
	srv.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_SYNC_GAME_WINPOOL, 0, 0, 0, time.Second*15, nil, nil)
	//订阅
	srv.redisEngine.Subscribe(SERVICE_TYPE, srv.instance)
	srv.log.Debug().Str("category", "service").Msgf("instance:%s game server start", srv.instance)
}

func (srv *Service) Defer() {

}

func (srv *Service) Start() {
	srv.redisEngine.Start()
	srv.timerEngine.Start()
	srv.wsEngine.Start()
	go func(s *Service) {
		srv.Once()
		defer srv.Defer()
		for {
			if stop := s.Dispatch(); stop {
				return
			}
		}
	}(srv)
}

func (srv *Service) Stop() {
	srv.wsEngine.Stop()
	srv.timerEngine.Stop()
	srv.redisEngine.Stop()
	srv.goPool.Stop()
	srv.stop <- struct{}{}
}

// 禁止这个协程直接使用IO和阻塞
func (srv *Service) Dispatch() bool {
	defer func() {
		if err := recover(); err != nil {
			stack := string(debug.Stack())
			srv.log.Error().Str("category", "service").Msgf("service dispatch error:%v", err)
			srv.log.Error().Str("category", "service").Msgf(stack)
		}
	}()
	stop := false
LOOP:
	for {
		select {
		case ctx := <-srv.ch:
			start := time.Now().UnixMilli()
			srv.HandleServiceContext(&ctx)
			end := time.Now().UnixMilli()
			diff := end - start
			if diff > 100 {
				srv.log.Warn().Str("category", "system").
					Msgf("service dispatch busy:%dms,cur channel task num:%d cur room count:%d goroutine:%d",
						diff, len(srv.ch), srv.roomMgr.Count(), runtime.NumGoroutine())
			}
		case <-srv.stop:
			{
				stop = true
				break LOOP
			}
		}
	}
	return stop
}

func (srv *Service) PushCostomMessage(id1, id2, id3, id4, id5 int, para1, para2 interface{}) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_COSTOM_MESSAGE,
		Para1:   id1,
		Para2:   id2,
		Para3:   id3,
		Para4:   id4,
		Para5:   id5,
		Para6:   para1,
		Para7:   para2,
	}
}

func (srv *Service) CoroutineTaskFunc(down chan struct{}, fn reflect.Value, args []reflect.Value) {
	srv.ch <- ServiceEngineContext{
		OptType: SERVICE_COROUTINE_TASK_FUNC,
		Para1:   down,
		Para2:   fn,
		Para3:   args,
	}
}

func (srv *Service) HandleServiceContext(cxt *ServiceEngineContext) {
	switch cxt.OptType {
	case SERVICE_NET_WS_CONN:
		srv.OnWebSocketConn(cxt.Para1.(int64), cxt.Para2.(net.IP))
	case SERVICE_NET_WS_RECV:
		srv.OnWebSocketRecv(cxt.Para1.(int64), cxt.Para2.([]byte))
	case SERVICE_NET_WS_CLOSE:
		srv.OnWebSocketClose(cxt.Para1.(int64))
	case SERVICE_TIMER:
		srv.OnTimer(cxt.Para1.(int), cxt.Para2.(int), cxt.Para3.(int), cxt.Para4.(int), cxt.Para5.(int), cxt.Para6, cxt.Para7)
	case SERVICE_COSTOM_MESSAGE:
		srv.OnCostomMessage(cxt.Para1.(int), cxt.Para2.(int), cxt.Para3.(int), cxt.Para4.(int), cxt.Para5.(int), cxt.Para6, cxt.Para7)
	case SERVICE_SUBSCRIBE_MESSAGE:
		srv.OnSubscribeMessage(cxt.Para1.(string), cxt.Para2.(string))
	case SERVICE_HTTP_MESSAGE:
		srv.OnHttpMessage(cxt.Para1.(int64), cxt.Para2.(int), cxt.Para3.(*http.Request))
	case SERVICE_COROUTINE_TASK_FUNC:
		srv.OnCoroutineTaskFunc(cxt.Para1.(chan struct{}), cxt.Para2.(reflect.Value), cxt.Para3.([]reflect.Value))
	}
}

func (srv *Service) SendData(sid int64, datas []byte) {
	srv.wsEngine.Send(sid, datas)
}

func (srv *Service) RuntimeMemStat() {
	bToMb := func(b uint64) uint64 {
		return b / 1024 / 1024
	}

	memStats := &runtime.MemStats{}
	runtime.ReadMemStats(memStats)

	var builder strings.Builder
	builder.WriteString(fmt.Sprintf("Allocated memory: %v MiB\n", bToMb(memStats.Alloc)))
	builder.WriteString(fmt.Sprintf("Total memory allocated and not yet freed: %v MiB\n", bToMb(memStats.TotalAlloc)))
	builder.WriteString(fmt.Sprintf("Memory obtained from system: %v MiB\n", bToMb(memStats.Sys)))
	builder.WriteString(fmt.Sprintf("Number of goroutines: %v\n", runtime.NumGoroutine()))

	builder.WriteString("Memory stats:\n")
	builder.WriteString(fmt.Sprintf("HeapAlloc = %v MiB\n", bToMb(memStats.HeapAlloc)))
	builder.WriteString(fmt.Sprintf("HeapSys = %v MiB\n", bToMb(memStats.HeapSys)))
	builder.WriteString(fmt.Sprintf("HeapIdle = %v MiB\n", bToMb(memStats.HeapIdle)))
	builder.WriteString(fmt.Sprintf("HeapInuse = %v MiB\n", bToMb(memStats.HeapInuse)))
	builder.WriteString(fmt.Sprintf("StackInuse = %v MiB\n", bToMb(memStats.StackInuse)))

	srv.log.Warn().Str("category", "system").Msg(builder.String())
}

// 发送订阅数据
func (srv *Service) SendChannelData(channel string, main, sub int, content interface{}) {
	//订阅消息
	type ChannelMessage struct {
		FromType     string      `json:"FromType"`
		FromInstance string      `json:"FromInstance"`
		MainType     int         `json:"MainType"`
		SubType      int         `json:"SubType"`
		Content      interface{} `json:"Content"`
	}
	msg := ChannelMessage{
		FromType:     SERVICE_TYPE,
		FromInstance: srv.instance,
		MainType:     main,
		SubType:      sub,
		Content:      content,
	}
	if bytes, err := json.Marshal(msg); err == nil {
		srv.redisEngine.Publish(channel, string(bytes))
	}
}

// 异步
func (srv *Service) Submit(fn interface{}, args ...interface{}) {
	srv.goPool.Submit(fn, args...)
}

// 异步（链式）
func (srv *Service) Task(fn interface{}, args ...interface{}) (ct *coroutines.CoroutineTask) {
	return srv.goPool.Task(fn, args...)
}
