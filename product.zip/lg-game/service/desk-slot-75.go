package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game75"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

type Desk75 struct {
	Desk
	config *game75.GameConfig //游戏配置
	betidx int                //下注配置的索引
	result game75.GameResult  //游戏结果
}

// 初始化
func NewDeskGame75(id, max_seat int, room *Room) (d *Desk75) {
	d = &Desk75{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx: 0,
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk75) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk75) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk75) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入
func (d *Desk75) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game75.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game75.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(0, 0, nil, &sence.Buffer, nil, nil)
	sence.BetIndex = d.betidx
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
}

// 游戏消息
func (d *Desk75) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game75.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game75.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {
				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk75, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// //////////////////////////////////////////////////////////////////////

// 转换
func (d *Desk75) ConvertBuffer(dec *[10]int, src *[game75.ROW_DEF][game75.COL_DEF]int) {
	idex := 0
	for col := 0; col < game75.COL_DEF; col++ {
		for row := 0; row < game75.ROW_DEF; row++ {
			if col == 0 || col == 2 {
				if row == 3 {
					continue
				}
			}
			dec[idex] = src[row][col]
			idex++
		}
	}
}

// 必输的
func (d *Desk75) RandMustLoseBuffer(roundInfo *game75.RoundInfo) {
	arrs := []int{}
	lastarrs := []int{}
	for i := game75.GAME_SOLT_1; i < game75.GAME_SOLT_WILD; i++ {
		lastarrs = append(lastarrs, i)
		for j := 0; j < 3; j++ {
			arrs = append(arrs, i)
		}
	}
	common.Shuffle(d.Random(), arrs)
	idx := 0
	for _, v := range arrs {
		roundInfo.CurrentShape[idx] = v
		idx++
	}
	common.Shuffle(d.Random(), lastarrs)
	for _, v := range lastarrs {
		roundInfo.CurrentShape[idx] = v
		elements := d.FindSameElements(&roundInfo.CurrentShape)
		if len(elements) <= 0 {
			break
		}
	}
	roundInfo.FinalShape = roundInfo.CurrentShape
}

// 随机图案
func (d *Desk75) RandBuffer(step, progress int, in, out *[game75.BUFF_SIZE]int, last *[]int, gameInfo *game75.SlotGameInfo) bool {
	if in != nil {
		for i := 0; i < game75.BUFF_SIZE; i++ {
			out[i] = in[i]
			if last != nil {
				*last = append(*last, in[i])
			}
		}
	}
	switch step {
	case game75.GAME_STEP_NORMAL:
		{
			for col := 0; col < game75.COL_DEF; col++ {
				for row := 0; row < game75.ROW_DEF; row++ {
					idx := row*game75.COL_DEF + col
					out[idx] = common.CalcWeight(d.Random(), d.config.NormalWeight[col]) + 1
				}
			}
			return true
		}
	case game75.GAME_STEP_EARTH:
		{
			if progress >= 10 {
				gameInfo.EarthDragon = true
				//将所有低赔付符号从卷轴中移除
				for col := 0; col < game75.COL_DEF; col++ {
					for row := 0; row < game75.ROW_DEF; row++ {
						idx := row*game75.COL_DEF + col
						if out[idx] <= game75.GAME_SOLT_4 {
							out[idx] = game75.GAME_SOLT_EMPTY
						}
					}
				}
				//掉落
				for col := 0; col < game75.COL_DEF; col++ {
					//列缓存
					colarrs := []int{}
					for row := 0; row < game75.ROW_DEF; row++ {
						idx := row*game75.COL_DEF + col
						if out[idx] != game75.GAME_SOLT_EMPTY {
							colarrs = append(colarrs, out[idx])
						}
					}
					dropCount := game75.ROW_DEF - len(colarrs)
					for i := 0; i < dropCount; i++ {
						colarrs = append([]int{game75.GAME_SOLT_EMPTY}, colarrs...)
					}
					if dropCount > 0 {
						for row := 0; row < game75.ROW_DEF; row++ {
							if colarrs[row] == game75.GAME_SOLT_EMPTY {
								colarrs[row] = common.CalcWeight(d.Random(), d.config.EarthWeight[col]) + 1
							}
						}
						//用最新的图
						for row, v := range colarrs {
							idx := row*game75.COL_DEF + col
							out[idx] = v
						}
					}
				}
				return true
			}
		}
	case game75.GAME_STEP_WATER:
		{
			//将在卷轴中添加4个百搭符号。
			if progress >= 30 {
				gameInfo.WaterDragon = true
				out[6] = game75.GAME_SOLT_WILD
				out[8] = game75.GAME_SOLT_WILD
				out[16] = game75.GAME_SOLT_WILD
				out[18] = game75.GAME_SOLT_WILD
				return true
			}
		}
	case game75.GAME_STEP_FIRE:
		{
			//随机选择的符号 (百搭符号除外)将以棋 盘格纹添加到卷轴中(它不会替换任何百搭符号)。
			if progress >= 50 {
				gameInfo.FireDragon = true
				selectType := common.CalcWeight(d.Random(), d.config.FireSelect) + 1
				for col := 0; col < game75.COL_DEF; col++ {
					if col%2 == 0 {
						idx0 := 0*game75.COL_DEF + col
						idx2 := 2*game75.COL_DEF + col
						idx4 := 4*game75.COL_DEF + col
						if out[idx0] != game75.GAME_SOLT_WILD {
							out[idx0] = selectType
						}
						if out[idx2] != game75.GAME_SOLT_WILD {
							out[idx2] = selectType
						}
						if out[idx4] != game75.GAME_SOLT_WILD {
							out[idx4] = selectType
						}
					} else {
						idx1 := 1*game75.COL_DEF + col
						idx3 := 3*game75.COL_DEF + col
						if out[idx1] != game75.GAME_SOLT_WILD {
							out[idx1] = selectType
						}
						if out[idx3] != game75.GAME_SOLT_WILD {
							out[idx3] = selectType
						}
					}
				}
				return true
			}
		}
	case game75.GAME_STEP_GIANT:
		fallthrough
	default:
		{
			//每个低赔付符号将转化为高赔付符号或百搭符号。
			if progress >= 70 {
				gameInfo.GiantDragon = true
				bChange := false
				for col := 0; col < game75.COL_DEF; col++ {
					for row := 0; row < game75.ROW_DEF; row++ {
						idx := row*game75.COL_DEF + col
						if out[idx] <= game75.GAME_SOLT_4 {
							out[idx] = common.CalcWeight(d.Random(), d.config.GiantWeight) + 5
							bChange = true
						}
					}
				}
				return bChange
			}
		}
	}
	return false
}

// 获得倍率
func (d *Desk75) GetTypeMult(soltType int, count int) int {
	if mp, ok := game75.Mult[soltType]; ok {
		if val, exist := mp[count]; exist {
			return val
		}
	}
	return 0
}

// 处理下注逻辑
func (d *Desk75) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "gbet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game75.LINE_COUNT
	//回复下注结果
	gameResult := game75.GameResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game75.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//出图
	gameResult.Wins = d.DoBuffer(addPool, betScore, calcScore, &gameResult.GameInfo)
	//推送中台下注结果
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk75, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

// 随机游戏
func (d *Desk75) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk75) PrintfRoundInfo(roundInfo *game75.RoundInfo) {
	sb := strings.Builder{}
	sb.WriteString(fmt.Sprintf("\n===================%d===================\n", roundInfo.Type))
	tmp := roundInfo.CurrentShape
	for _, v := range roundInfo.RemoveList {
		tmp[v.Position] = 0
	}
	for row := 0; row < game75.ROW_DEF; row++ {
		if len(roundInfo.InitShape) > 0 {
			for col := 0; col < game75.COL_DEF; col++ {
				idx := row*game75.COL_DEF + col
				sb.WriteString(fmt.Sprintf("%d", roundInfo.InitShape[idx]))
				if col < game75.ROW_DEF-1 {
					sb.WriteString(",")
				}
			}
			if row == 2 {
				sb.WriteString("  To  ")
			} else {
				sb.WriteString("      ")
			}
		}
		for col := 0; col < game75.COL_DEF; col++ {
			idx := row*game75.COL_DEF + col
			sb.WriteString(fmt.Sprintf("%d", roundInfo.CurrentShape[idx]))
			if col < game75.ROW_DEF-1 {
				sb.WriteString(",")
			}
		}
		if row == 2 {
			sb.WriteString(" >>>> ")
		} else {
			sb.WriteString("      ")
		}
		for col := 0; col < game75.COL_DEF; col++ {
			idx := row*game75.COL_DEF + col
			if tmp[idx] == 0 {
				sb.WriteString("*")
			} else {
				sb.WriteString(fmt.Sprintf("%d", tmp[idx]))
			}
			if col < game75.ROW_DEF-1 {
				sb.WriteString(",")
			}
		}
		if row == 2 {
			sb.WriteString(" >>>> ")
		} else {
			sb.WriteString("      ")
		}
		for col := 0; col < game75.COL_DEF; col++ {
			idx := row*game75.COL_DEF + col
			sb.WriteString(fmt.Sprintf("%d", roundInfo.FinalShape[idx]))
			if col < game75.ROW_DEF-1 {
				sb.WriteString(",")
			}
		}
		if row < game75.COL_DEF-1 {
			sb.WriteString("\n")
		}
	}
	sb.WriteString("\n")
	fmt.Print(sb.String())
	//d.isrv.DebugGameMsgf(sb.String())
}

func (d *Desk75) DoBuffer(addPool, betScore, calcScore int64, gameInfo *game75.SlotGameInfo) (totalScore int64) {
	loop := 0
	gameInfo.Result = 0
	gameInfo.Bet = betScore
	for ; loop < define.MAX_LOOP; loop++ {
		progress := 0
		totalScore = 0
		gameInfo.RoundList = nil
		gameInfo.PriceType = 0
		gameInfo.LotterySize = 0
		gameInfo.EarthDragon = false
		gameInfo.WaterDragon = false
		gameInfo.FireDragon = false
		gameInfo.GiantDragon = false
		step := game75.GAME_STEP_NORMAL
	LOOP:
		for {
			ok := false
			roundInfo := game75.RoundInfo{}
			if len(gameInfo.RoundList) > 0 {
				ok = d.RandBuffer(step, progress, &gameInfo.RoundList[len(gameInfo.RoundList)-1].FinalShape,
					&roundInfo.CurrentShape, &roundInfo.InitShape, gameInfo)
			} else {
				ok = d.RandBuffer(step, progress, nil, &roundInfo.CurrentShape, nil, gameInfo)
			}
			if step < game75.GAME_STEP_GIANT {
				if !ok {
					break LOOP
				}
			}
			first := true
			if step > game75.GAME_STEP_GIANT {
				roundInfo.Type = game75.GAME_STEP_GIANT
			} else {
				roundInfo.Type = step
			}
			for {
				if !first {
					roundInfo.Type = 0
					roundInfo.InitShape = nil
					roundInfo.CurrentShape = gameInfo.RoundList[len(gameInfo.RoundList)-1].FinalShape
				}
				roundInfo.PriceValue = 0
				d.CalcScore(calcScore, &progress, &roundInfo, &roundInfo.CurrentShape)
				totalScore += roundInfo.PriceValue
				d.RandDropBuffer(step, &roundInfo, &roundInfo.CurrentShape, &roundInfo.FinalShape)
				if first {
					first = false
					if roundInfo.PriceValue <= 0 && !ok && step >= game75.GAME_STEP_GIANT {
						break LOOP
					}
					gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
					//d.PrintfRoundInfo(&roundInfo)
				} else {
					if roundInfo.PriceValue > 0 {
						gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
						//d.PrintfRoundInfo(&roundInfo)
					}
				}
				if step < game75.GAME_STEP_GIANT {
					if roundInfo.PriceValue <= 0 {
						break
					}
				} else {
					break
				}
			}
			step++
		}
		gameInfo.PriceType = d.CalcWinMultTip(betScore, totalScore)
		gameInfo.LotterySize = totalScore
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		//出必输图
		totalScore = 0
		gameInfo.RoundList = nil
		gameInfo.PriceType = 0
		gameInfo.LotterySize = 0
		gameInfo.EarthDragon = false
		gameInfo.WaterDragon = false
		gameInfo.FireDragon = false
		gameInfo.GiantDragon = false
		roundInfo := game75.RoundInfo{
			RemoveList: make([]game75.IconInfo, 0),
			AddList:    make([]game75.IconInfo, 0),
			PriceList:  make([]game75.Prize, 0),
		}
		d.RandMustLoseBuffer(&roundInfo)
		gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
	}
	return
}

// 计算弹窗提示
func (d *Desk75) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk75) IsValid(x, y int) bool {
	return x >= 0 && x < game75.ROW_DEF && y >= 0 && y < game75.COL_DEF
}

func (d *Desk75) DFS(buff *[game75.BUFF_SIZE]int, row, col int, target int) []int {
	idx := row*game75.COL_DEF + col
	stack := []int{idx}
	group := []int{idx}
	visited := [game75.BUFF_SIZE]bool{}
	visited[idx] = true
	for len(stack) > 0 {
		curr := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		currX := curr / game75.ROW_DEF
		currY := curr % game75.COL_DEF
		directions := [][]int{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}
		for _, dir := range directions {
			nextX := currX + dir[0]
			nextY := currY + dir[1]
			next := nextX*game75.COL_DEF + nextY
			if d.IsValid(nextX, nextY) && !visited[next] {
				if buff[next] == target || buff[next] == game75.GAME_SOLT_WILD {
					visited[next] = true
					stack = append(stack, next)
					group = append(group, next)
				}
			}
		}
	}
	return group
}

func (d *Desk75) FindSameElements(buff *[game75.BUFF_SIZE]int) [][]int {
	var result [][]int
	visited := [game75.BUFF_SIZE]bool{}
	for col := 0; col < game75.COL_DEF; col++ {
		for row := 0; row < game75.ROW_DEF; row++ {
			idx := row*game75.COL_DEF + col
			if buff[idx] == game75.GAME_SOLT_WILD {
				continue
			}
			if !visited[idx] {
				group := d.DFS(buff, row, col, buff[idx])
				if len(group) >= 4 {
					result = append(result, group)
				}
				for _, v := range group {
					visited[v] = true
				}
			}
		}
	}
	return result
}

func (d *Desk75) CalcScore(calcScore int64, progress *int, roundInfo *game75.RoundInfo, buff *[game75.BUFF_SIZE]int) {
	roundInfo.PriceValue = 0
	roundInfo.CurrentProgress = 0
	roundInfo.PriceList = make([]game75.Prize, 0)
	roundInfo.RemoveList = make([]game75.IconInfo, 0)
	elements := d.FindSameElements(buff)
	for _, element := range elements {
		soltType := game75.GAME_SOLT_EMPTY
		for i := 0; i < len(element); i++ {
			if buff[element[i]] != game75.GAME_SOLT_WILD {
				soltType = buff[element[i]]
			}
			roundInfo.RemoveList = append(roundInfo.RemoveList, game75.IconInfo{
				Position: element[i],
				IconId:   buff[element[i]],
			})
		}
		mult := d.GetTypeMult(soltType, len(element))
		value := int64(mult) * calcScore
		roundInfo.PriceValue += value
		roundInfo.PriceList = append(roundInfo.PriceList, game75.Prize{
			Icon:     soltType,
			Count:    len(element),
			PeiLv:    mult,
			Value:    value,
			Position: element,
		})
		*progress += len(element)
		if *progress > game75.MAX_PROGRESS {
			*progress = game75.MAX_PROGRESS
		}
		roundInfo.CurrentProgress = *progress
	}
}

// 随机掉落的图案
func (d *Desk75) RandDropBuffer(step int, roundInfo *game75.RoundInfo, in, out *[game75.BUFF_SIZE]int) {
	//初始化列表
	roundInfo.AddList = make([]game75.IconInfo, 0)
	//赋值
	for i := 0; i < game75.BUFF_SIZE; i++ {
		out[i] = in[i]
	}
	//消除
	for _, v := range roundInfo.RemoveList {
		out[v.Position] = game75.GAME_SOLT_EMPTY
	}
	//掉落
	for col := 0; col < game75.COL_DEF; col++ {
		//列缓存
		colarrs := []int{}
		for row := 0; row < game75.ROW_DEF; row++ {
			idx := row*game75.COL_DEF + col
			if out[idx] != game75.GAME_SOLT_EMPTY {
				colarrs = append(colarrs, out[idx])
			}
		}
		dropCount := game75.ROW_DEF - len(colarrs)
		for i := 0; i < dropCount; i++ {
			colarrs = append([]int{game75.GAME_SOLT_EMPTY}, colarrs...)
		}
		if dropCount > 0 {
			for row := 0; row < game75.ROW_DEF; row++ {
				slotType := game75.GAME_SOLT_EMPTY
				if colarrs[row] == game75.GAME_SOLT_EMPTY {
					switch step {
					case game75.GAME_STEP_NORMAL:
						slotType = common.CalcWeight(d.Random(), d.config.NormalDrop) + 1
					case game75.GAME_STEP_EARTH:
						slotType = common.CalcWeight(d.Random(), d.config.EarthDrop) + 1
					case game75.GAME_STEP_WATER:
						slotType = common.CalcWeight(d.Random(), d.config.WaterDrop) + 1
					case game75.GAME_STEP_FIRE:
						slotType = common.CalcWeight(d.Random(), d.config.FireDrop) + 1
					case game75.GAME_STEP_GIANT:
						fallthrough
					default:
						slotType = common.CalcWeight(d.Random(), d.config.GiantDrop) + 1
					}
					colarrs[row] = slotType
					roundInfo.AddList = append(roundInfo.AddList, game75.IconInfo{
						Position: row*game75.COL_DEF + col,
						IconId:   slotType,
					})
				}
			}
			//用最新的图
			for row, v := range colarrs {
				idx := row*game75.COL_DEF + col
				out[idx] = v
			}
		}
	}
}
