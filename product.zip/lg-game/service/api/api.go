package api

import (
	"crypto/md5"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math/rand"
	"net"
	"strconv"
	"strings"
	"time"

	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/define"

	"github.com/google/uuid"
	"github.com/rs/zerolog"
)

// 获取余额接口
var BlanceUrl string
var BlanceTimeout int

// 下注接口
var BetUrl string
var BetTimeout int

// 日志接口
var Log *zerolog.Logger

type ScoreParamContext struct {
	Token   string
	Account string
}

// 获取余额
func GetUserScore(token, account string) (int64, bool) {
	strReqId := uuid.New().String()
	//参数
	paraMp := map[string]string{}
	paraMp["reqId"] = strReqId
	paraMp["timestamp"] = strconv.FormatInt(time.Now().Unix(), 10)
	paraMp["token"] = token
	paraMp["gameUid"] = account
	paraBytes, _ := json.Marshal(paraMp)
	//打印
	Log.Debug().Str("category", "api").
		Str("reqid", strReqId).
		Str("account", account).
		Msgf("get token:%s score param:%s", token, string(paraBytes))
	//进行rsa加密
	rsabytes, _ := common.EncyptogRSA(paraBytes)
	//转成base64字符串
	builder := strings.Builder{}
	builder.WriteString(base64.StdEncoding.EncodeToString(rsabytes))
	//签名结构
	signMp := map[string]string{}
	signMp["sign"] = builder.String()
	singBytes, _ := json.Marshal(signMp)
	//
	Log.Debug().Str("category", "api").
		Str("reqid", strReqId).
		Str("account", account).
		Msgf("get token:%s score param sign:%s", token, string(singBytes))
	//请求
	hearder := make(map[string]string)
	hearder["Content-Type"] = "application/json;charset=utf-8"
	hearder["reqId"] = strReqId
	respBody := []byte{}
	for {
		var err error
		respBody, err = common.Post(BlanceUrl, hearder, singBytes, time.Second*time.Duration(BlanceTimeout))
		if err == nil {
			break
		}
		Log.Error().Str("category", "api").Str("reqid", strReqId).Str("account", account).Msgf("get token:%s score post error:%v", token, err)
		time.Sleep(time.Second)
	}
	//反序列化
	type BlanceResp struct {
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		Data int64  `json:"data"`
	}
	blanceObj := BlanceResp{}
	if err := json.Unmarshal(respBody, &blanceObj); err != nil {
		return 0, false
	}
	success := false
	if blanceObj.Msg == "success" {
		success = true
	}
	Log.Debug().Str("category", "api").
		Str("reqid", strReqId).
		Str("account", account).
		Msgf("get token:%s score resp:%v", token, blanceObj)
	return blanceObj.Data, success
}

func CreateGameOrder(random *rand.Rand, gameid int, account string, now int64) string {
	//订单号规则
	//（时间戳+游戏ID+厅内用户名+6位随机值）md5加密
	orderBuilder := strings.Builder{}
	orderBuilder.WriteString(strconv.FormatInt(now, 10))
	orderBuilder.WriteString(strconv.FormatInt(int64(gameid), 10))
	orderBuilder.WriteString(account)
	orderBuilder.WriteString(strconv.FormatInt(int64(common.RandRangeValue(random, 100000, 900000)), 10))
	has := md5.Sum([]byte(orderBuilder.String()))
	return fmt.Sprintf("%x", has)
}

type BetParamContext struct {
	GameID      int
	Token       string
	Account     string
	OrderNo     string
	BetScore    int64
	WinScore    int64
	ChangeScore int64
	Now         int64
}

type BetResult struct {
	Code   int
	Blance int64
}

// 推送下注
func PushOnBet(gameid int, token, account, orderNo string, betScore, winScore, changeScore, now int64) (result *BetResult) {
	result = &BetResult{}
	type BetReq struct {
		ReqId       string `json:"reqId"`
		Timestamp   string `json:"timestamp"`
		Token       string `json:"token"`
		GameUid     string `json:"gameUid"`
		Bet         int64  `json:"bet"`
		Win         int64  `json:"win"`
		ChangeMoney int64  `json:"changemoney"`
		OrderNo     string `json:"orderNo"`
		GameId      int    `json:"gameId"`
	}
	strReqId := uuid.New().String()
	param := &BetReq{
		ReqId:       strReqId,
		Timestamp:   strconv.FormatInt(now, 10),
		Token:       token,
		GameUid:     account,
		Bet:         betScore,
		Win:         winScore,
		ChangeMoney: changeScore,
		OrderNo:     orderNo,
		GameId:      gameid,
	}
	paraBytes, _ := json.Marshal(param)
	//打印
	Log.Debug().Str("category", "api").
		Int("game", gameid).
		Str("order", orderNo).
		Str("reqid", strReqId).
		Str("account", account).
		Msgf("token:%s onbet param:%s", token, string(paraBytes))
	//进行rsa加密
	rsabytes, _ := common.EncyptogRSA(paraBytes)
	//转成base64字符串
	builder := strings.Builder{}
	builder.WriteString(base64.StdEncoding.EncodeToString(rsabytes))
	//签名结构
	signMp := map[string]string{}
	signMp["sign"] = builder.String()
	singBytes, _ := json.Marshal(signMp)
	//
	Log.Debug().Str("category", "api").
		Int("game", gameid).
		Str("order", orderNo).
		Str("reqid", strReqId).
		Str("account", account).
		Msgf("token:%s onbet param sign:%s", token, string(singBytes))
	//请求
	hearder := make(map[string]string)
	hearder["Content-Type"] = "application/json;charset=utf-8"
	hearder["reqId"] = strReqId
	respBody := []byte{}
	for {
		//超时或者网络问题
		//尝试去重试
		var err error
		respBody, err = common.Post(BetUrl, hearder, singBytes, time.Second*time.Duration(BetTimeout))
		if err == nil {
			break
		}
		if e, ok := err.(net.Error); ok && e.Timeout() {
			Log.Error().Str("category", "api").Int("game", gameid).Str("order", orderNo).Str("reqid", strReqId).Str("account", account).Msgf("token:%s onbet post timeout error:%v", token, err)
		} else {
			Log.Error().Str("category", "api").Int("game", gameid).Str("order", orderNo).Str("reqid", strReqId).Str("account", account).Msgf("token:%s onbet post unknow error:%v", token, err)
		}
		time.Sleep(time.Second)
	}
	//反序列化
	type BetResp struct {
		// 10 参数缺失
		// 11 没获取到汇率
		// 12 token失效
		// 13 投注重复
		// 14 余额不足
		// 99 其他类型的投注失败
		Code int    `json:"code"`
		Msg  string `json:"msg"`
		Data int64  `json:"data"`
	}
	blanceObj := BetResp{}
	if err := json.Unmarshal(respBody, &blanceObj); err != nil {
		Log.Error().Str("category", "api").
			Int("game", gameid).
			Str("order", orderNo).
			Str("reqid", strReqId).
			Str("account", account).
			Msgf("token:%s unmarshal error", token)
		result.Blance = 0
		result.Code = define.API_BET_RESULT_PARSE_ERROR
		return
	}
	Log.Debug().Str("category", "api").Int("game", gameid).Str("order", orderNo).Str("reqid", strReqId).Str("account", account).Msgf("token:%s onbet resp:%+v", token, blanceObj)
	// if blanceObj.Msg == "success" {
	// 	return blanceObj.Data, define.API_BET_RESULT_OK
	// }
	//目前是参数缺失，token过期，汇率没获取到等会下注失败
	result.Blance = blanceObj.Data
	result.Code = blanceObj.Code
	return
}
