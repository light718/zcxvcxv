package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game72"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

type (
	Desk72 struct {
		Desk
		config   *game72.GameConfig //游戏配置
		betidx   int                //下注配置的索引
		result   game72.GameResult  //游戏结果
		strategy *slot.Strategy     //控制策略
	}
	// 用来计算线
	stCalcLine struct {
		soltType int
		count    int
		position [game72.COL_DEF]int
	}
)

// 初始化
func NewDeskGame72(id, max_seat int, room *Room) (d *Desk72) {
	d = &Desk72{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx:   0,
		strategy: &slot.Strategy{},
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk72) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载控制信息
	d.strategy.AsyncLoad(d.room.MySqlEngine(), gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk72) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk72) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入
func (d *Desk72) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game72.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game72.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game72.GAME_MODE_NORMAL, &sence.Buffer)
	sence.BetIndex = d.betidx
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
	d.strategy.Set(d.Random(), d.config.Rtp, d.config.GameWeight)
}

// 游戏消息
func (d *Desk72) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game72.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game72.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {
				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk72, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// //////////////////////////////////////////////////////////////////////

// 转换
func (d *Desk72) ConvertBuffer(mode int, dec *[10]int, cashBuff *[10]int64, src *[game72.ROW_DEF][game72.COL_DEF]int, betScore int64, cashMult [][]int) {
	idex := 0
	for col := 0; col < game72.COL_DEF; col++ {
		for row := 0; row < game72.ROW_DEF; row++ {
			if col == 0 || col == 2 {
				if row == 3 {
					continue
				}
			}
			dec[idex] = src[row][col]
			idex++
		}
	}
}

// 必输的
func (d *Desk72) RandMustLoseBuffer(buff *[game72.BUFF_SIZE]int) {
	arr := []int{game72.GAME_SOLT_1, game72.GAME_SOLT_2, game72.GAME_SOLT_3, game72.GAME_SOLT_4, game72.GAME_SOLT_5, game72.GAME_SOLT_6, game72.GAME_SOLT_7, game72.GAME_SOLT_8}
	common.Shuffle(d.Random(), arr)
	for col := 0; col < game72.COL_DEF; col++ {
		for row := 0; row < game72.ROW_DEF; row++ {
			idx := row*game72.COL_DEF + col
			if len(arr) > 0 {
				buff[idx] = arr[0]
				arr = arr[1:]
			} else {
				tmp := []int{}
				tmp = append(tmp, d.config.Normal[col]...)
				tmp[game72.GAME_SOLT_SCATTER] = 0
				buff[idx] = common.CalcWeight(d.Random(), tmp)
			}
		}
	}
}

// 随机激活免费玩法的图案个数
func (d *Desk72) RandScatterCount() int {
	idx := common.CalcWeight(d.Random(), d.config.Special.Scatter)
	switch idx {
	case 0:
		return 3
	case 1:
		return 4
	case 2:
		return 5
	}
	return 0
}

// 根据图案获取回合数
func (d *Desk72) GetScatterRoundCount(count int) int {
	switch count {
	case 3:
		return 12
	case 4:
		return 15
	case 5:
		return 20
	}
	return 0
}

// 随机激活图案
func (d *Desk72) RandActScatterBuffer(count int, buff *[game72.BUFF_SIZE]int) {
	cols := []int{0, 1, 2, 3, 4}
	start := common.RandValue(d.Random(), cols)
	for count > 0 {
		idxs := []int{}
		for row := 0; row < game72.ROW_DEF; row++ {
			idx := row * game72.COL_DEF
			idx += int(start)
			idxs = append(idxs, idx)
		}
		idx := common.RandValue(d.Random(), idxs)
		buff[idx] = game72.GAME_SOLT_SCATTER
		start = (start + 1) % game72.COL_DEF
		count--
	}
	//其余填充
	for col := 0; col < game72.COL_DEF; col++ {
		for row := 0; row < game72.ROW_DEF; row++ {
			idx := row*game72.COL_DEF + col
			if buff[idx] != game72.GAME_SOLT_SCATTER {
				tmp := []int{}
				tmp = append(tmp, d.config.Normal[col]...)
				tmp[game72.GAME_SOLT_SCATTER] = 0
				buff[idx] = common.CalcWeight(d.Random(), tmp)
			}
		}
	}
}

// 收集wild
func (d *Desk72) CollectWild(buff *[game72.BUFF_SIZE]int) int {
	count := 0
	for i := 0; i < game72.BUFF_SIZE; i++ {
		if buff[i] == game72.GAME_SOLT_WILD {
			count++
		}
	}
	return count
}

// 随机图案
func (d *Desk72) RandBuffer(mode int, buff *[game72.BUFF_SIZE]int) {
	if mode == game72.GAME_MODE_NORMAL {
		for col := 0; col < game72.COL_DEF; col++ {
			for row := 0; row < game72.ROW_DEF; row++ {
				idx := row*game72.COL_DEF + col
				buff[idx] = common.CalcWeight(d.Random(), d.config.Normal[col])
			}
		}
	} else {
		for col := 0; col < game72.COL_DEF; col++ {
			for row := 0; row < game72.ROW_DEF; row++ {
				idx := row*game72.COL_DEF + col
				buff[idx] = common.CalcWeight(d.Random(), d.config.Special.Weight[col])
			}
		}
	}
}

// 处理下注逻辑
func (d *Desk72) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "bet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game72.LINE_COUNT
	//回复下注结果
	gameResult := game72.GameResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game72.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameResult.Result = result
		//回复
		d.Send(sid, gameResult)
		return
	}
	//控制修改
	d.strategy.Control(idx, d.config.GameWeight, game72.GAME_MODE_SPECIAL)
	d.DebugGameMsgf(pUserData, "game weight:%v", d.config.GameWeight)
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//出图
	gameResult.GameInfo, gameResult.Win = d.DoBuffer(addPool, betScore, calcScore)
	gameResult.Wins = gameResult.Win
	//推送中台下注结果
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.Wins,
		ChangeScore: gameResult.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk72, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

// 随机游戏
func (d *Desk72) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk72) DoBuffer(addPool, betScore, calcScore int64) (gameInfo game72.CalcSlotGameInfo, totalScore int64) {
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		//初始化
		gameInfo = game72.CalcSlotGameInfo{
			Bet:       betScore,
			Free:      0,
			RoundList: make([]game72.RoundInfo, 0),
		}
		//游戏总分
		totalScore = 0
		//随机本局游戏
		mode := d.RandGame(d.config.GameWeight)
		//判断模式
		if mode == game72.GAME_MODE_NORMAL {
			//随机图案
			d.RandBuffer(mode, &gameInfo.InitShape)
			//检查图案是否免费
			if d.IsFree(&gameInfo.InitShape) {
				continue
			}
			//计算得分
			gameInfo.FirstPriceList, totalScore = d.CalcScore(calcScore, &gameInfo.InitShape, 1)
			gameInfo.FirstPriceValue = totalScore
		} else {
			gameInfo.Free = 1
			//随机图标个数
			scatterCount := d.RandScatterCount()
			//生成激活图案
			d.RandActScatterBuffer(scatterCount, &gameInfo.InitShape)
			//计算得分
			gameInfo.FirstPriceList, totalScore = d.CalcScore(calcScore, &gameInfo.InitShape, 1)
			gameInfo.FirstPriceValue = totalScore
			//扩展倍数
			extMult := int64(2)
			progress := 0
			//提前生成免费对局
			gameInfo.FreeCount = d.GetScatterRoundCount(scatterCount)
			for i := 0; i < gameInfo.FreeCount; i++ {
				roundInfo := game72.RoundInfo{
					FreeCount:       gameInfo.FreeCount - i,
					CurrentProgress: progress,
				}
				//随机图案
				d.RandBuffer(mode, &roundInfo.CurrentShape)
				//收集百搭
				progress += d.CollectWild(&roundInfo.CurrentShape)
				roundInfo.CurrentProgress = progress
				//经验收集倍数
				progressMult := progress / 3
				if progressMult > 9 {
					progressMult = 9
				}
				roundInfo.CurrentTime = extMult + int64(progressMult*2)
				//计算得分
				roundInfo.PriceList, roundInfo.PriceValue = d.CalcScore(calcScore, &roundInfo.CurrentShape, roundInfo.CurrentTime)
				totalScore += roundInfo.PriceValue
				//添加对局
				gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
			}
		}
		//奖励弹窗
		gameInfo.PriceType = d.CalcWinMultTip(betScore, totalScore)
		//总赢分
		gameInfo.Wins = totalScore
		gameInfo.LotterySize = totalScore

		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		//初始化
		gameInfo = d.RandMustLoseGameInfo()
		gameInfo.Bet = betScore
		//赢分0
		totalScore = 0
	}
	return
}

// 随机必输的游戏图案
func (d *Desk72) RandMustLoseGameInfo() (gameInfo game72.CalcSlotGameInfo) {
	//初始化
	gameInfo = game72.CalcSlotGameInfo{
		Free:           0,
		RoundList:      make([]game72.RoundInfo, 0),
		FirstPriceList: make([]game72.Prize, 0),
	}
	//必输图
	d.RandMustLoseBuffer(&gameInfo.InitShape)
	gameInfo.FirstPriceValue = 0
	return
}

// 检查免费
func (d *Desk72) IsFree(buff *[game72.BUFF_SIZE]int) bool {
	count := 0
	for i := 0; i < game72.BUFF_SIZE; i++ {
		if buff[i] == game72.GAME_SOLT_SCATTER {
			count++
		}
	}
	return count >= 3
}

// 计算弹窗提示
func (d *Desk72) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk72) CalcLine(buff *[game72.BUFF_SIZE]int) (arr []stCalcLine) {
	arr = make([]stCalcLine, 0)
	for row := 0; row < game72.ROW_DEF; row++ {
		idx := row*game72.COL_DEF + 0
		soltType := buff[idx]
		//特殊不允许成线
		if soltType == game72.GAME_SOLT_SCATTER {
			continue
		}
		position := [game72.COL_DEF]int{}
		position[0] = idx
		d.CalcLineSub(buff, soltType, 1, &position, &arr)
	}
	return
}

func (d *Desk72) CalcLineSub(buff *[game72.BUFF_SIZE]int, soltType int, col int, position *[game72.COL_DEF]int, arr *[]stCalcLine) bool {
	if col >= game72.COL_DEF-1 {
		return false
	}
	for row := 0; row < game72.ROW_DEF; row++ {
		idx := row*game72.COL_DEF + col
		if buff[idx] == soltType || buff[idx] == game72.GAME_SOLT_WILD {
			position[col] = idx
			//递归
			ok := d.CalcLineSub(buff, soltType, col+1, position, arr)
			if !ok && col >= 2 {
				l := stCalcLine{
					soltType: soltType,
					count:    col + 1,
					position: *position,
				}
				*arr = append(*arr, l)
			}
		}
	}
	return false
}

// 计算x星连珠
func (d *Desk72) CalcXCount(buff *[game72.BUFF_SIZE]int, arr []stCalcLine) (x map[int][]int) {
	x = map[int][]int{}
	for i := 0; i < len(arr); i++ {
		soltType := arr[i].soltType
		if _, exist := x[soltType]; !exist {
			arr := []int{}
			for col := 0; col < game72.COL_DEF; col++ {
				xcount := 0
				for row := 0; row < game72.ROW_DEF; row++ {
					idx := row*game72.COL_DEF + col
					if buff[idx] == soltType || buff[idx] == game72.GAME_SOLT_WILD {
						xcount++
					}
				}
				if xcount <= 0 {
					break
				}
				arr = append(arr, xcount)
			}
			x[soltType] = arr
		}
	}
	return
}

func (d *Desk72) GetTypeMult(soltType int, count int) int {
	if mp, ok := game72.Mult[soltType]; ok {
		if val, exist := mp[count]; exist {
			return val
		}
	}
	return 0
}

func (d *Desk72) CalcScore(calcScore int64, buff *[game72.BUFF_SIZE]int, extMult int64) (prizes []game72.Prize, totalScore int64) {
	//初始化
	prizes = make([]game72.Prize, 0)
	//得到连线的集合
	arr := d.CalcLine(buff)
	//计算x星连珠
	xmap := d.CalcXCount(buff, arr)
	//算分
	for k, v := range xmap {
		count := 0
		lineMult := 1
		for i := 0; i < len(v); i++ {
			count += v[i]
			lineMult *= v[i]
		}
		peiLv := d.GetTypeMult(k, len(v))
		value := int64(peiLv) * int64(lineMult) * calcScore
		prizes = append(prizes, game72.Prize{
			Icon:      k,
			Count:     count,
			LineCount: len(v),
			PeiLv:     peiLv,
			Type:      0,
			Value:     value,
		})
		totalScore += (value * extMult)
	}
	return
}
