package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game67"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

// 游戏玩法结构
type Desk67 struct {
	Desk
	config   *game67.GameConfig //游戏配置
	result   game67.GameResult  //游戏结果
	strategy *slot.Strategy     //控制策略
	mode     int                //模式
	betidx   int                //下注配置的索引
	scatter  int                //扩展个数
}

// 初始化
func NewDeskGame67(id, max_seat int, room *Room) (d *Desk67) {
	d = &Desk67{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		mode:     0,
		betidx:   0,
		scatter:  0,
		strategy: &slot.Strategy{},
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk67) AsyncLoad(gid int, uid int64) {
	//查询以往下注索引
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//去查询断线数据
	rkey := fmt.Sprintf("%s:%d:%d", RDS_GMAE_DISCONNECTION_KEY, gid, uid)
	if val, err := d.RedisEngine().C.Get(context.Background(), rkey).Result(); err == nil {
		if val != "" {
			scatter, _ := strconv.Atoi(val)
			d.scatter = scatter
			d.mode = game67.GAME_MODE_SPECIAL
		}
		d.RedisEngine().C.Del(context.Background(), rkey)
	}
	//加载控制信息
	d.strategy.AsyncLoad(d.room.MySqlEngine(), gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk67) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk67) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
	//记录断线数据
	if d.mode == game67.GAME_MODE_SPECIAL {
		d.Submit(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine, gid int, uid int64, scatter int) {
			redis.C.Set(context.Background(),
				fmt.Sprintf("%s:%d:%d", RDS_GMAE_DISCONNECTION_KEY, gid, uid), fmt.Sprintf("%d", scatter), time.Hour*24*7)
		}, d.RedisEngine(), d.GameID(), pUserData.id, d.scatter)
	}
}

// 进入
func (d *Desk67) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game67.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game67.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game67.GAME_MODE_NORMAL, 0, &sence.Buffer)
	sence.Mode = d.mode
	sence.BetIndex = d.betidx
	sence.Scatter = d.scatter
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
	d.strategy.Set(d.Random(), d.config.Rtp, d.config.GameWeight)
}

// 游戏消息
func (d *Desk67) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game67.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game67.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token string, account string, mode int) {
				if change > 0 && mode == game67.GAME_MODE_NORMAL {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account, d.mode).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk67, sid int64, betidx int, freeidx int) {
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx, freeidx)
					}
				}, d, sid, req.BetIndex, req.FreeIdx).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// //////////////////////////////////////////////////////////////////////

// 转换
func (d *Desk67) ConvertBuffer(mode int, dec *[10]int, cashBuff *[10]int64, src *[game67.ROW_DEF][game67.COL_DEF]int, betScore int64, cashMult [][]int) {
	idex := 0
	for col := 0; col < game67.COL_DEF; col++ {
		for row := 0; row < game67.ROW_DEF; row++ {
			if col == 0 || col == 2 {
				if row == 3 {
					continue
				}
			}
			dec[idex] = src[row][col]
			idex++
		}
	}
}

// 必输的
func (d *Desk67) RandMustLoseBuffer(buff *[game67.BUFF_SIZE]int) {
	arr := []int{game67.GAME_SOLT_1, game67.GAME_SOLT_2, game67.GAME_SOLT_3, game67.GAME_SOLT_4, game67.GAME_SOLT_5, game67.GAME_SOLT_6, game67.GAME_SOLT_7}
	common.Shuffle(d.Random(), arr)
	for col := 0; col < game67.COL_DEF; col++ {
		for row := 0; row < game67.ROW_DEF; row++ {
			idx := row*game67.COL_DEF + col
			if len(arr) > 0 {
				buff[idx] = arr[0]
				arr = arr[1:]
			} else {
				tmp := []int{}
				tmp = append(tmp, d.config.Normal.Weight[col]...)
				if col == game67.COL_DEF-1 {
					tmp[game67.GAME_SOLT_WILD] = 0
				}
				tmp[game67.GAME_SOLT_SCATTER] = 0
				buff[idx] = common.CalcWeight(d.Random(), tmp)
			}
		}
	}
}

// 随机激活图案
func (d *Desk67) RandActScatterBuffer(count int, buff *[game67.BUFF_SIZE]int) {
	cols := []int{0, 1, 2, 3, 4}
	start := common.RandValue(d.Random(), cols)
	for count > 0 {
		idxs := []int{}
		for row := 0; row < game67.ROW_DEF; row++ {
			idx := row * game67.COL_DEF
			idx += int(start)
			idxs = append(idxs, idx)
		}
		idx := common.RandValue(d.Random(), idxs)
		buff[idx] = game67.GAME_SOLT_SCATTER
		start = (start + 1) % game67.COL_DEF
		count--
	}
	//其余填充
	for col := 0; col < game67.COL_DEF; col++ {
		for row := 0; row < game67.ROW_DEF; row++ {
			idx := row*game67.COL_DEF + col
			if buff[idx] != game67.GAME_SOLT_SCATTER {
				tmp := []int{}
				tmp = append(tmp, d.config.Normal.Weight[col]...)
				if col == 0 || col == game67.COL_DEF-1 {
					tmp[game67.GAME_SOLT_WILD] = 0
				}
				tmp[game67.GAME_SOLT_SCATTER] = 0
				buff[idx] = common.CalcWeight(d.Random(), tmp)
			}
		}
	}
}

// 收集wild
func (d *Desk67) CollectWild(buff *[game67.BUFF_SIZE]int) int {
	count := 0
	for i := 0; i < game67.BUFF_SIZE; i++ {
		if buff[i] == game67.GAME_SOLT_WILD {
			count++
		}
	}
	return count
}

// 随机图案
func (d *Desk67) RandBuffer(mode int, fidx int, buff *[game67.BUFF_SIZE]int) {
	if mode == game67.GAME_MODE_NORMAL {
		for col := 0; col < game67.COL_DEF; col++ {
			for row := 0; row < game67.ROW_DEF; row++ {
				idx := row*game67.COL_DEF + col
				buff[idx] = common.CalcWeight(d.Random(), d.config.Normal.Weight[col])
			}
		}
	} else {
		for col := 0; col < game67.COL_DEF; col++ {
			for row := 0; row < game67.ROW_DEF; row++ {
				idx := row*game67.COL_DEF + col
				buff[idx] = common.CalcWeight(d.Random(), d.config.Special.Fill[fidx].Weight[col])
			}
		}
	}
}

// 处理下注逻辑
func (d *Desk67) DoGameLogic(pUserData *UserData, sid int64, idx, freeIdx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "bet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game67.LINE_COUNT
	//回复下注结果
	gameResult := game67.GameResult{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game67.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//金币校验
	if d.mode == game67.GAME_MODE_NORMAL {
		if result, ok := d.CheckMaintain(); !ok {
			gameResult.Result = result
			//回复
			d.Send(sid, gameResult)
			return
		}
		//检查下注额度
		if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
			gameResult.Result = result
			//回复
			d.Send(sid, gameResult)
			return
		}
		//记录下注
		d.betidx = idx
	}
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	if d.mode == game67.GAME_MODE_NORMAL {
		//控制修改
		d.strategy.Control(idx, d.config.GameWeight, game67.GAME_MODE_SPECIAL)
		d.DebugGameMsgf(pUserData, "game weight:%v", d.config.GameWeight)
		//出图
		gameResult.InningList, gameResult.TotalWin = d.DoBuffer(addPool, betScore, calcScore)
	} else {
		tax = 0
		addPool = 0
		gameResult.InningList, gameResult.TotalWin, gameResult.FTime = d.DoFreeBuffrer(betScore, calcScore, freeIdx)
		betScore = 0
	}
	//推送中台下注结果
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameResult.TotalWin,
		ChangeScore: gameResult.TotalWin - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameResult.TotalWin,
		ChangeScore: gameResult.TotalWin - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameResult.TotalWin - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameResult
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk67, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

// 随机游戏
func (d *Desk67) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk67) DoFreeBuffrer(betScore, calcScore int64, freeIdx int) (gameInfos []game67.CalcSlotGameInfo, totalScore int64, freeNum int) {
	freeNum = 0
	switch freeIdx {
	case 0:
		freeNum = 20 + d.ExtFreeCount(freeIdx)
	case 1:
		freeNum = 10 + d.ExtFreeCount(freeIdx)
	case 2:
		freeNum = 5 + d.ExtFreeCount(freeIdx)
	}
	if freeNum <= 0 {
		return
	}
	d.DebugGameMsgf(nil, "do free buffrer select:%d scatter:%d freenum:%d", freeIdx, d.scatter, freeNum)
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		totalScore = 0
		roundCount := freeNum
		for roundCount > 0 {
			//初始化
			gameInfo := game67.CalcSlotGameInfo{
				Bet:       0,
				RoundList: make([]game67.RoundInfo, 0),
			}
			//额外倍率
			multidx := 0
			//随机图案
			shape := [game67.BUFF_SIZE]int{}
			d.RandBuffer(game67.GAME_MODE_SPECIAL, freeIdx, &shape)
			//保存给客户端
			gameInfo.Shape = shape
			for {
				//对局
				roundInfo := game67.RoundInfo{
					Remove:   make([]int, 0),
					Prize:    make([]game67.Prize, 0),
					AddList:  make([]game67.LineIcon, 0),
					Multiple: game67.SpecialMult[freeIdx][multidx],
				}
				//计算得分
				roundInfo.WinRoundSum = d.CalcScore(calcScore, &shape, &roundInfo)
				if roundInfo.WinRoundSum > 0 {
					//掉落
					d.RandDropBuffer(game67.GAME_MODE_SPECIAL, freeIdx, &roundInfo, &shape)
					//倍率计数
					multidx++
					//不能超过槽位最大数
					if multidx >= game67.MAX_MULT_SOLT_COUNT-1 {
						multidx = game67.MAX_MULT_SOLT_COUNT - 1
					}
				}
				//本局赢
				gameInfo.Wins += roundInfo.WinRoundSum
				//免费次数
				gameInfo.MarginFreeNum = roundCount - 1
				//记录
				gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
				if roundInfo.WinRoundSum <= 0 {
					//随机到免费
					if d.IsFree(&shape) {
						//记录额外免费
						switch freeIdx {
						case 0:
							roundCount += 20
							gameInfo.FreeNumAdd = 20
							gameInfo.MarginFreeNum += 20
						case 1:
							roundCount += 10
							gameInfo.FreeNumAdd = 10
							gameInfo.MarginFreeNum += 10
						case 2:
							roundCount += 5
							gameInfo.FreeNumAdd = 5
							gameInfo.MarginFreeNum += 5
						}
					}
					break
				}
			}
			//异常保护
			if len(gameInfo.RoundList) > 100 {
				continue
			}
			//累计总赢
			totalScore += gameInfo.Wins
			//记录数据
			gameInfos = append(gameInfos, gameInfo)
			//局数
			roundCount--
		}
		//过滤倍数
		mult := totalScore / betScore
		switch freeIdx {
		case 0:
			if mult > 1000 {
				continue
			}
		case 1:
			if mult > 2000 {
				continue
			}
		case 2:
			if mult > 5000 {
				continue
			}
		}
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, 0, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	//随机必输局
	if loop >= define.MAX_LOOP {
		//初始化
		gameInfos = make([]game67.CalcSlotGameInfo, 0)
		for i := 0; i < freeNum; i++ {
			//生成必输
			gameInfo := d.RandMustLoseGameInfo()
			gameInfo.Bet = 0
			gameInfo.MarginFreeNum = freeNum - i - 1
			//记录数据
			gameInfos = append(gameInfos, gameInfo)
		}
		//赢分0
		totalScore = 0
	}
	d.mode = game67.GAME_MODE_NORMAL
	return
}

func (d *Desk67) DoBuffer(addPool, betScore, calcScore int64) (gameInfos []game67.CalcSlotGameInfo, totalScore int64) {
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		//初始化
		gameInfo := game67.CalcSlotGameInfo{
			Bet:       betScore,
			RoundList: make([]game67.RoundInfo, 0),
		}
		//游戏总分
		totalScore = 0
		//随机本局游戏
		mode := d.RandGame(d.config.GameWeight)
		//额外倍率
		multidx := 0
		//随机图案
		shape := [game67.BUFF_SIZE]int{}
		//判断模式
		if mode == game67.GAME_MODE_NORMAL {
			d.RandBuffer(mode, 0, &shape)
		} else {
			//激活图案
			d.scatter = d.RandScatterCount()
			d.RandActScatterBuffer(d.scatter, &shape)
		}
		//保存给客户端
		gameInfo.Shape = shape
		for {
			//对局
			roundInfo := game67.RoundInfo{
				Remove:   make([]int, 0),
				Prize:    make([]game67.Prize, 0),
				AddList:  make([]game67.LineIcon, 0),
				Multiple: game67.ExtMult[multidx],
			}
			//计算得分
			roundInfo.WinRoundSum = d.CalcScore(calcScore, &shape, &roundInfo)
			if roundInfo.WinRoundSum > 0 {
				//掉落
				d.RandDropBuffer(mode, 0, &roundInfo, &shape)
				//倍率计数
				multidx++
				//不能超过槽位最大数
				if multidx >= game67.MAX_MULT_SOLT_COUNT-1 {
					multidx = game67.MAX_MULT_SOLT_COUNT - 1
				}
			}
			//累计总赢分
			totalScore += roundInfo.WinRoundSum
			//记录
			gameInfo.RoundList = append(gameInfo.RoundList, roundInfo)
			if roundInfo.WinRoundSum <= 0 {
				break
			}
		}
		//随机到免费就重摇
		if d.IsFree(&shape) && mode == game67.GAME_MODE_NORMAL {
			continue
		}
		//局数总赢
		gameInfo.Wins = totalScore
		//记录数据
		gameInfos = append(gameInfos, gameInfo)
		//模式
		d.mode = mode
		//过滤倍数
		mult := totalScore / betScore
		if mult > 50 {
			continue
		}
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		//初始化
		gameInfos = make([]game67.CalcSlotGameInfo, 0)
		//生成必输
		gameInfo := d.RandMustLoseGameInfo()
		gameInfo.Bet = betScore
		//赢分0
		totalScore = 0
		//记录数据
		gameInfos = append(gameInfos, gameInfo)
		//模式
		d.mode = game67.GAME_MODE_NORMAL
	}
	return
}

// 随机必输的游戏图案
func (d *Desk67) RandMustLoseGameInfo() (gameInfo game67.CalcSlotGameInfo) {
	//初始化
	gameInfo = game67.CalcSlotGameInfo{
		RoundList: make([]game67.RoundInfo, 0),
	}
	//必输图
	d.RandMustLoseBuffer(&gameInfo.Shape)
	return
}

// 扩展个数
func (d *Desk67) ExtFreeCount(fidx int) int {
	diff := d.scatter - 3
	switch fidx {
	case 0:
		return diff * 4
	case 1:
		return diff * 2
	case 2:
		return diff * 1
	}
	return 0
}

// 随机激活免费玩法的图案个数
func (d *Desk67) RandScatterCount() int {
	idx := common.CalcWeight(d.Random(), d.config.Special.Scatter)
	switch idx {
	case 0:
		return 3
	case 1:
		return 4
	case 2:
		return 5
	}
	return 0
}

// 检查免费
func (d *Desk67) IsFree(buff *[game67.BUFF_SIZE]int) bool {
	count := 0
	for i := 0; i < game67.BUFF_SIZE; i++ {
		if buff[i] == game67.GAME_SOLT_SCATTER {
			count++
		}
	}
	return count >= 3
}

// 获得倍率
func (d *Desk67) GetTypeMult(soltType int, count int) int {
	if mp, ok := game67.Mult[soltType]; ok {
		if val, exist := mp[count]; exist {
			return val
		}
	}
	return 0
}

// 随机掉落的图案
func (d *Desk67) RandDropBuffer(mode, fidx int, roundInfo *game67.RoundInfo, buff *[game67.BUFF_SIZE]int) {
	//消除
	for _, v := range roundInfo.Remove {
		buff[v] = game67.GAME_SOLT_EMPTY
	}
	//掉落
	for col := 0; col < game67.COL_DEF; col++ {
		//列缓存
		colarrs := []int{}
		for row := 0; row < game67.ROW_DEF; row++ {
			idx := row*game67.COL_DEF + col
			if buff[idx] != game67.GAME_SOLT_EMPTY {
				colarrs = append(colarrs, buff[idx])
			}
		}
		dropCount := game67.ROW_DEF - len(colarrs)
		for i := 0; i < dropCount; i++ {
			colarrs = append([]int{game67.GAME_SOLT_EMPTY}, colarrs...)
		}
		if dropCount > 0 {
			lineIcon := game67.LineIcon{
				Column: col + 1,
				Icon:   make([]int, 0),
			}
			for row := 0; row < game67.ROW_DEF; row++ {
				idx := row*game67.COL_DEF + col
				if colarrs[row] == game67.GAME_SOLT_EMPTY {
					dropTmp := []int{}
					if col == 0 || col == game67.COL_DEF-1 {
						if mode == game67.GAME_MODE_NORMAL {
							dropTmp = append(dropTmp, d.config.Normal.Drop[col]...)
							dropTmp[game67.GAME_SOLT_WILD] = 0
						} else {
							dropTmp = append(dropTmp, d.config.Special.Fill[fidx].Drop[col]...)
							dropTmp[game67.GAME_SOLT_WILD] = 0
						}

					} else {
						if mode == game67.GAME_MODE_NORMAL {
							dropTmp = d.config.Normal.Drop[col]
						} else {
							dropTmp = d.config.Special.Fill[fidx].Drop[col]
						}
					}
					slotType := common.CalcWeight(d.Random(), dropTmp)
					lineIcon.Icon = append([]int{slotType}, lineIcon.Icon...)
					colarrs[row] = slotType
				}
				buff[idx] = colarrs[row]
			}
			roundInfo.AddList = append(roundInfo.AddList, lineIcon)
		}
	}
}

// 计算得分
func (d *Desk67) CalcScore(calcScore int64, buff *[game67.BUFF_SIZE]int, roundInfo *game67.RoundInfo) (totalScore int64) {
	Lines := [game67.LINE_COUNT][game67.COL_DEF]int{
		{5, 6, 7, 8, 9},      //1
		{0, 1, 2, 3, 4},      //2
		{10, 11, 12, 13, 14}, //3
		{0, 6, 12, 8, 4},     //4
		{10, 6, 2, 8, 14},    //5
		{0, 1, 7, 3, 4},      //6
		{10, 11, 7, 13, 14},  //7
		{5, 11, 12, 13, 9},   //8
		{5, 1, 2, 3, 9},      //9
		{0, 6, 7, 8, 4},      //10
		{10, 6, 7, 8, 14},    //11
		{5, 6, 2, 8, 9},      //12
		{5, 6, 12, 8, 9},     //13
		{5, 1, 7, 3, 9},      //14
		{5, 11, 7, 13, 9},    //15
		{0, 6, 2, 8, 4},      //16
		{10, 6, 12, 8, 14},   //17
		{0, 1, 7, 13, 14},    //18
		{10, 11, 7, 3, 4},    //19
		{0, 11, 2, 13, 4},    //20
	}
	remove := map[int]int8{}
	//循环遍历线
	for idx, line := range Lines {
		count := 1
		realIcon := buff[line[0]]
		//特殊不允许成线
		if realIcon == game67.GAME_SOLT_SCATTER {
			continue
		}
		for i := 1; i < game67.COL_DEF; i++ {
			v := buff[line[i]]
			//都是空图标
			if realIcon == game67.GAME_SOLT_EMPTY || v == game67.GAME_SOLT_EMPTY {
				break
			}
			if v == game67.GAME_SOLT_WILD {
				count++
				continue
			}
			if realIcon == game67.GAME_SOLT_WILD {
				if v != game67.GAME_SOLT_WILD {
					realIcon = v
				}
			}
			//退出判断
			if realIcon != v {
				break
			}
			count++
		}
		if count >= 3 {
			//中线了
			mult := d.GetTypeMult(realIcon, count)
			value := int64(mult) * calcScore
			prize := game67.Prize{
				Icon:  realIcon,
				Count: count,
				Line:  idx + 1,
				Value: value,
				Type:  0,
			}
			for i := 0; i < count; i++ {
				prize.IconIndex = append(prize.IconIndex, line[i])
				if _, exist := remove[line[i]]; !exist {
					remove[line[i]] = 1
				}
			}
			roundInfo.Prize = append(roundInfo.Prize, prize)
			//基础倍数
			totalScore += (value * int64(roundInfo.Multiple))
		}
	}
	for k := range remove {
		roundInfo.Remove = append(roundInfo.Remove, k)
	}
	return
}
