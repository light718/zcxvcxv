package service

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"t77/lg/service/api"
	"t77/lg/service/protocol"
	"t77/lg/service/slot"
	"t77/lg/service/slot/game68"
	"time"

	"gopkg.in/yaml.v3"
	"intech.t77.com/pkg/common"
	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"
	"intech.t77.com/pkg/engine"
)

type Desk68 struct {
	Desk
	config   *game68.GameConfig //游戏配置
	betidx   int                //下注配置的索引
	result   game68.GameEnd     //游戏结果
	strategy *slot.Strategy     //控制策略
}

// 初始化
func NewDeskGame68(id, max_seat int, room *Room) (d *Desk68) {
	d = &Desk68{
		Desk: Desk{
			id:       id,
			room:     room,
			max_seat: max_seat,
			seats:    make([]int64, max_seat),
			mask:     0,
		},
		betidx:   0,
		strategy: &slot.Strategy{},
	}
	return
}

// 异步初始化
// 进入场景前初始化对象
func (d *Desk68) AsyncLoad(gid int, uid int64) {
	//查询以往下注
	d.betidx = d.AsyncGetSlotBetIndex(gid, uid)
	//加载控制信息
	d.strategy.AsyncLoad(d.room.MySqlEngine(), gid, uid)
	//加载配置
	d.AsyncLoadConfig(gid)
}

// 加载配置
func (d *Desk68) AsyncLoadConfig(gid int) {
	path := fmt.Sprintf("./conf/game_%d.yaml", gid)
	bytes, err := os.ReadFile(path)
	if err == nil {
		err = yaml.Unmarshal(bytes, &d.config)
		if err != nil {
			panic(err)
		}
	}
}

// 事件
func (d *Desk68) OnDisconnected(pUserData *UserData) {
	d.Desk.OnDisconnected(pUserData)
	d.SaveSlotBetIndex(pUserData.id, d.betidx)
}

// 进入场景
func (d *Desk68) OnSence(pUserData *UserData) {
	d.Desk.OnSence(pUserData)
	sence := game68.GameGameSence{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game68.SUB_GAME_SENCE,
		},
		BetConfig: d.config.BetConfig,
		Version:   d.config.Version,
	}
	d.RandBuffer(game68.GAME_MODE_NORMAL, &sence.Buffer)
	sence.BetIndex = d.betidx
	d.DebugGameMsgf(pUserData, "enter game sence:%+v", sence)
	d.Send(pUserData.sid, sence)
	d.strategy.Set(d.Random(), d.config.Rtp, d.config.GameWeight)
}

// 游戏消息
func (d *Desk68) OnMessage(sid int64, cmd int, message []byte) {
	pUserData, exist := d.GetOnlineUser(sid)
	if !exist {
		return
	}
	switch cmd {
	case game68.SUB_GAME_BET_REQ: //下注
		{
			//游戏请求
			req := game68.GameBetReq{}
			if err := json.Unmarshal(message, &req); err != nil {
				d.ErrorGameMsgf(pUserData, "unmarshal GameBetReq error:%v", err)
				return
			}
			//异步请求
			d.Task(func(ct *coroutines.CoroutineTask, change int, token, account string) {
				if change > 0 {
					score, ok := api.GetUserScore(token, account)
					if !ok {
						//中止后续链路的执行
						ct.Cancel()
					}
					ct.SaveResult(score)
				}
			}, req.Change, pUserData.token, pUserData.account).
				Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk68, sid int64, betidx int) {
					//函数参数
					if pUserData, exist := desk.GetOnlineUser(sid); exist {
						if len(ct.ResultArgs) > 0 {
							pUserData.score = ct.ResultArgs[0].(int64)
						}
						desk.DoGameLogic(pUserData, sid, betidx)
					}
				}, d, sid, req.BetIndex).Run()
		}
	default:
		d.Desk.OnMessage(sid, cmd, message)
	}
}

// ////////////////////////////////////////////////////////////////////
// 处理下注逻辑
func (d *Desk68) DoGameLogic(pUserData *UserData, sid int64, idx int) {
	//错误判断
	if idx < 0 && idx >= len(d.config.BetConfig) {
		d.ErrorGameMsgf(pUserData, "bet index over config")
		return
	}
	//下注额度
	betScore := d.config.BetConfig[idx]
	//每条线的投注大小
	calcScore := d.config.BetConfig[idx] / game68.LINE_COUNT
	//回复下注结果
	gameEnd := game68.GameEnd{
		ProtocolBase: protocol.ProtocolBase{
			MainCmd: protocol.MAIN_GAME,
			SubCmd:  game68.SUB_GAME_BET_RESP,
		},
		Bet:    betScore,
		Points: pUserData.score,
		Result: define.GAME_RESULT_OK,
	}
	//检查维护状态
	if result, ok := d.CheckMaintain(); !ok {
		gameEnd.Result = result
		//回复
		d.Send(sid, gameEnd)
		return
	}
	//记录下注
	d.betidx = idx
	//检查下注额度
	if result, ok := d.CheckScore(betScore, pUserData.score); !ok {
		gameEnd.Result = result
		//回复
		d.Send(sid, gameEnd)
		return
	}
	//控制修改
	d.strategy.Control(idx, d.config.GameWeight, game68.GAME_MODE_SPECIAL)
	d.DebugGameMsgf(pUserData, "game weight:%v", d.config.GameWeight)
	//下注额度要分配一部分给库存
	addPool, tax := d.CalcPoolAndTaxScore(betScore)
	//出图
	gameEnd.Info, gameEnd.Win = d.DoBuffer(addPool, betScore, calcScore)
	gameEnd.Wins = gameEnd.Win
	now := time.Now().Unix()
	//生成游戏ID对局编号
	gameNo := api.CreateGameOrder(d.Random(), d.GameID(), pUserData.account, now)
	//aip参数
	para1 := &api.BetParamContext{
		GameID:      d.GameID(),
		Token:       pUserData.token,
		Account:     pUserData.account,
		OrderNo:     gameNo,
		BetScore:    betScore,
		WinScore:    gameEnd.Wins,
		ChangeScore: gameEnd.Wins - betScore,
		Now:         now,
	}
	//游戏记录
	para2 := &slot.RecordBetInfo{
		Gameid:      d.GameID(),
		GameNo:      gameNo,
		UserId:      pUserData.id,
		BetScore:    betScore,
		WinScore:    gameEnd.Wins,
		ChangeScore: gameEnd.Wins - betScore,
		Tax:         tax,
		Time:        now,
		BfUserCoin:  pUserData.score,
		AfUserCoin:  pUserData.score + (gameEnd.Wins - betScore),
		RePoolCoin:  0,
		Ip:          pUserData.ip.String(),
	}
	//游戏结果
	d.result = gameEnd
	//异步发送
	d.Task(func(ct *coroutines.CoroutineTask, apiparam *api.BetParamContext) {
		apiResult := api.PushOnBet(apiparam.GameID, apiparam.Token, apiparam.Account, apiparam.OrderNo,
			apiparam.BetScore, apiparam.WinScore, apiparam.ChangeScore, apiparam.Now)
		ct.SaveResult(apiResult)
	}, para1).Dispatch(func(ct *coroutines.CoroutineTask, desk *Desk68, record *slot.RecordBetInfo, uid int64) {
		apiResult := ct.ResultArgs[0].(*api.BetResult)
		record.Mark = apiResult.Code
		pUserData, eixst := desk.GetUserData(uid)
		if apiResult.Code == define.API_BET_RESULT_OK || apiResult.Code == define.API_BET_RESULT_REPEAT {
			record.AfUserCoin = apiResult.Blance
			if eixst {
				pUserData.score = apiResult.Blance
			}
		} else {
			desk.result.Result = define.GAME_RESULT_BET_ERROR
		}
		if eixst {
			desk.result.Points = pUserData.score
			if datas, err := json.Marshal(desk.result); err == nil {
				desk.SendData(pUserData.sid, datas)
				desk.DebugGameMsgf(pUserData, "resp:%s", string(datas))
			}
		}
		ct.SaveResult(record)
	}, d, para2, pUserData.id).Continue(func(ct *coroutines.CoroutineTask, redis *engine.RedisEngine) {
		record := ct.ResultArgs[0].(*slot.RecordBetInfo)
		//写入记录
		if datas, err := json.Marshal(record); err == nil {
			redis.C.RPush(context.Background(), RDS_GMAE_RECORDS_KEY, datas).Result()
		}
	}, d.RedisEngine()).Run()
}

func (d *Desk68) DoBuffer(addPool, betScore, calcScore int64) (gameInfo game68.GameInfo, totalScore int64) {
	loop := 0
	for ; loop < define.MAX_LOOP; loop++ {
		//游戏总分
		totalScore = 0
		//游戏对局数据
		gameInfo = game68.GameInfo{}
		//随机本局游戏
		gameInfo.FsMode = d.RandGame(d.config.GameWeight)
		//判断模式
		if gameInfo.FsMode == game68.GAME_MODE_NORMAL {
			//建立一个对局
			roundInfo := game68.SlotRoundInfoMessages{
				Prize: make([]game68.Prize, 0),
			}
			//随机图案
			d.RandBuffer(game68.GAME_MODE_NORMAL, &roundInfo.Shape)
			//判断是否形成免费的图案或者全部百搭符号
			if d.CheckFree(&roundInfo.Shape) || d.IsAllWild(&roundInfo.Shape) {
				continue
			}
			//计算得分
			totalScore, gameInfo.BeiShu = d.CalcScore(calcScore, &roundInfo)
			//加入缓存
			gameInfo.RoundInfoMessages = append(gameInfo.RoundInfoMessages, roundInfo)
		} else {
			gameInfo.RoundInfoMessages = nil
			i := 0
			for i < game68.MAX_FREE_CACHE {
				//建立一个对局
				roundInfo := game68.SlotRoundInfoMessages{
					Prize: make([]game68.Prize, 0),
				}
				//随机图案
				d.RandBuffer(game68.GAME_MODE_SPECIAL, &roundInfo.Shape)
				//计算得分
				totalScore, gameInfo.BeiShu = d.CalcScore(calcScore, &roundInfo)
				//计数++
				i++
				//加入缓存
				gameInfo.RoundInfoMessages = append(gameInfo.RoundInfoMessages, roundInfo)
				//判断退出
				if totalScore > 0 {
					break
				}
			}
			if i >= game68.MAX_FREE_CACHE {
				//免费局数太多了
				continue
			}
		}
		//奖励弹窗
		gameInfo.Num = d.CalcWinMultTip(betScore, totalScore)
		gameInfo.LotterySize = totalScore
		//检查水池校验是否够钱赔付
		if loop <= 0 || totalScore > 0 {
			pass := d.CheckSlotStock(loop, addPool, totalScore)
			if !pass {
				continue
			}
		}
		break
	}
	if loop >= define.MAX_LOOP {
		//重新初始化对象
		gameInfo = d.RandMustLoseGameInfo()
		//赢分0
		totalScore = 0
	}
	return
}

func (d *Desk68) RandBuffer(mode int, buff *[game68.BUFF_SIZE]int) {
	if mode == game68.GAME_MODE_NORMAL {
		for col := 0; col < game68.COL_DEF; col++ {
			for row := 0; row < game68.ROW_DEF; row++ {
				rowidx := row * game68.ROW_DEF
				buff[rowidx+col] = common.CalcWeight(d.Random(), d.config.Normal[col])
			}
		}
	} else {
		//这个作为第一列
		firstSelect := common.CalcWeight(d.Random(), d.config.Special.FirstSelect)
		for row := 0; row < game68.ROW_DEF; row++ {
			rowidx := row * game68.ROW_DEF
			buff[rowidx+0] = firstSelect + 1
		}
		//中间都是百搭
		for row := 0; row < game68.ROW_DEF; row++ {
			rowidx := row * game68.ROW_DEF
			buff[rowidx+1] = game68.GAME_SOLT_WILD
		}
		//第三列
		for row := 0; row < game68.ROW_DEF; row++ {
			rowidx := row * game68.ROW_DEF
			buff[rowidx+2] = common.CalcWeight(d.Random(), d.config.Special.SelectWeight[firstSelect]) + 1
		}
	}
}

// 随机必输的游戏图案
func (d *Desk68) RandMustLoseGameInfo() (game game68.GameInfo) {
	//重新初始化对象
	game = game68.GameInfo{
		FsMode: 0,
	}
	//建立一个对局
	roundInfo := game68.SlotRoundInfoMessages{
		Prize: make([]game68.Prize, 0),
	}
	//必输图
	d.RandMustLoseBuffer(&roundInfo.Shape)
	//加入缓存
	game.RoundInfoMessages = append(game.RoundInfoMessages, roundInfo)
	return
}

// 计算弹窗提示
func (d *Desk68) CalcWinMultTip(betScore, totalScore int64) int {
	val := 0
	if totalScore > 0 {
		for k, v := range d.config.WinMultTip {
			if totalScore/betScore >= v {
				if val <= 0 {
					val = k
				} else {
					if k > val {
						val = k
					}
				}
			}
		}
	}
	return val
}

func (d *Desk68) CalcScore(calcScore int64, roundInfo *game68.SlotRoundInfoMessages) (score int64, isWild int8) {
	//定义线
	Lines := [game68.LINE_COUNT][game68.COL_DEF]int{
		{3, 4, 5},
		{0, 1, 2},
		{6, 7, 8},
		{0, 4, 8},
		{6, 4, 2},
	}
	//循环遍历线
	for idx, line := range Lines {
		pass := true
		realIcon := roundInfo.Shape[line[0]]
		for i := 1; i < game68.COL_DEF; i++ {
			v := roundInfo.Shape[line[i]]
			if v == game68.GAME_SOLT_WILD {
				continue
			}
			if realIcon == game68.GAME_SOLT_WILD {
				if v != game68.GAME_SOLT_WILD {
					realIcon = v
				}
			}
			if realIcon != v {
				pass = false
				break
			}
		}
		//记录明细
		if pass {
			//中奖数量
			roundInfo.LineCount++
			//图案的倍率
			mult := d.GetSoltTypeMult(realIcon)
			//倍率累计
			roundInfo.Multiple += mult
			//奖励明细
			prize := game68.Prize{
				Icon:  realIcon,
				Count: 3,
				Type:  1,
				Value: int64(mult) * calcScore,
				Line:  idx,
			}
			for i := 0; i < game68.COL_DEF; i++ {
				prize.IconIndex = append(prize.IconIndex, line[i])
			}
			roundInfo.Prize = append(roundInfo.Prize, prize)
		}
	}
	//收集掉落物动画用
	if len(roundInfo.Prize) > 0 {
		roundInfo.Drop = map[string]int{}
		for i := 0; i < len(roundInfo.Prize); i++ {
			for j := 0; j < len(roundInfo.Prize[i].IconIndex); j++ {
				dropKey := strconv.FormatInt(int64(roundInfo.Prize[i].IconIndex[j]), 10)
				if _, ok := roundInfo.Drop[dropKey]; !ok {
					roundInfo.Drop[dropKey] = 1
				} else {
					roundInfo.Drop[dropKey]++
				}
			}
		}
	}
	//千倍大奖
	if d.IsAllWild(&roundInfo.Shape) {
		score = calcScore * 1000 * game68.LINE_COUNT
		isWild = 2
	} else {
		isWild = 1
		for i := 0; i < len(roundInfo.Prize); i++ {
			score += roundInfo.Prize[i].Value
		}
	}
	return
}

// 随机游戏
func (d *Desk68) RandGame(weight []int) int {
	return common.CalcWeight(d.Random(), weight)
}

func (d *Desk68) IsAllWild(buffer *[game68.BUFF_SIZE]int) bool {
	bYes := true
	for i := 0; i < game68.BUFF_SIZE; i++ {
		if buffer[i] != game68.GAME_SOLT_WILD {
			bYes = false
			break
		}
	}
	return bYes
}

func (d *Desk68) GetSoltTypeMult(soltType int) (mult int) {
	switch soltType {
	case game68.GAME_SOLT_0:
		mult = game68.GAME_SOLT_0_MULT
	case game68.GAME_SOLT_1:
		mult = game68.GAME_SOLT_1_MULT
	case game68.GAME_SOLT_2:
		mult = game68.GAME_SOLT_2_MULT
	case game68.GAME_SOLT_3:
		mult = game68.GAME_SOLT_3_MULT
	case game68.GAME_SOLT_4:
		mult = game68.GAME_SOLT_4_MULT
	case game68.GAME_SOLT_5:
		mult = game68.GAME_SOLT_5_MULT
	case game68.GAME_SOLT_6:
		mult = game68.GAME_SOLT_6_MULT
	case game68.GAME_SOLT_WILD:
		mult = game68.GAME_SOLT_WILD_MULT
	}
	return
}

// 必输的
func (d *Desk68) RandMustLoseBuffer(buff *[game68.BUFF_SIZE]int) {
	arr := []int{game68.GAME_SOLT_1, game68.GAME_SOLT_2, game68.GAME_SOLT_3, game68.GAME_SOLT_4, game68.GAME_SOLT_5, game68.GAME_SOLT_6}
	common.Shuffle(d.Random(), arr)
	//前面两列不允许相同的
	idex := 0
	for col := 0; col < game68.COL_DEF-1; col++ {
		for row := 0; row < game68.ROW_DEF; row++ {
			rowidx := row * game68.ROW_DEF
			buff[rowidx+col] = arr[idex]
			idex++
		}
	}
	//最后一列随机
	idex = 0
	common.Shuffle(d.Random(), arr)
	for col := 2; col < game68.COL_DEF; col++ {
		for row := 0; row < game68.ROW_DEF; row++ {
			rowidx := row * game68.ROW_DEF
			buff[rowidx+col] = arr[idex]
			idex++
		}
	}
}

// 检查是否 免费
func (d *Desk68) CheckFree(buff *[game68.BUFF_SIZE]int) bool {
	bFree := true
	for row := 0; row < game68.ROW_DEF; row++ {
		rowidx := row * game68.ROW_DEF
		if buff[rowidx+1] != game68.GAME_SOLT_WILD {
			bFree = false
			break
		}
	}
	return bFree
}
