package service

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"reflect"
	"strings"
	"t77/lg/service/protocol"
	"time"

	"t77/lg/service/api"

	"intech.t77.com/pkg/coroutines"
	"intech.t77.com/pkg/define"

	"github.com/redis/go-redis/v9"
)

func (srv *Service) OnWebSocketConn(sid int64, ip net.IP) {
	srv.log.Debug().Str("category", "service").Msgf("sid:%d conn", sid)
	srv.conn[sid] = ip
	//添加连接检测心跳定时器(第一次用2倍的超时时间，以防客户端已经连接上，资源没有加载好的情况)
	srv.timerEngine.Add(ITIMER_MODULE_SERVICE, ITIMER_SERVICE_CHECK_NET_TIMEOUT, int(sid), 0, 0,
		time.Second*time.Duration(srv.conf.ConnTimeout*2), nil, nil)
}

func (srv *Service) OnWebSocketClose(sid int64) {
	srv.log.Debug().Str("category", "service").Msgf("sid:%d close", sid)
	pUserData, exist := srv.userMgr.GetOnlineUser(sid)
	if exist {
		if r, ok := srv.roomMgr.GetRoom(pUserData.rid); ok {
			off := r.OnDisconnected(pUserData)
			if !off {
				//删除在线
				srv.userMgr.DelOnline(sid)
			} else {
				//删除房间桌子
				srv.roomMgr.DelDesk(pUserData.rid, pUserData.did)
				//删除用户
				srv.userMgr.DelOnlineUser(sid)
				//通知大厅用户离开游戏
				srv.SendChannelData(LOBBY_SERVICE_TYPE,
					define.SUBSCRIBE_MAIN_LOGIC, define.SUB_LOGIC_USER_LEAVE_GAME, fmt.Sprintf("%d", pUserData.id))
			}
		}
	}
	//删除会话
	delete(srv.conn, sid)
	//删除连接检测心跳定时器
	srv.timerEngine.Del(ITIMER_MODULE_SERVICE, ITIMER_SERVICE_CHECK_NET_TIMEOUT, int(sid), 0, 0)
}

func (srv *Service) InitGameRoom() {
	rows, err := srv.mysqlEngine.Query(`SELECT a.id,a.type,a.gameid,a.name,a.choushuilv,a.is_maintenance,b.ngamblingwinpool FROM game a 
	LEFT JOIN  (SELECT nGameID,ngamblingwinpool FROM gambling_game_list) b On a.id = b.ngameid`)
	if err != nil {
		panic(err)
	}
	defer rows.Close()
	for rows.Next() {
		gset := &Setting{}
		stock := int64(0)
		if e := rows.Scan(&gset.ID, &gset.GameType, &gset.GameId, &gset.GameName, &gset.Ratio, &gset.Maintain, &stock); e == nil {
			room := srv.roomMgr.Create(gset, stock)
			if gset.GameType == define.GAME_TYPE_YFJ {
				desk := room.NewDesk()
				room.SetDesk(desk)
			}
		}
	}
}

// 初始化业务环境
func (srv *Service) InitLogicModule() {
	srv.InitGameRoom()
}

// 获取在线房间
func (srv *Service) GetOnlineDesk(sid int64) (*UserData, IDeskEvent, bool) {
	pUserData, exist := srv.userMgr.GetOnlineUser(sid)
	if exist {
		if idesk, ok := srv.roomMgr.GetDesk(pUserData.rid, pUserData.did); ok {
			return pUserData, idesk, ok
		}
	}
	return nil, nil, false
}

// 定时器
func (srv *Service) OnTimer(id1, id2, id3, id4, id5 int, para1, para2 interface{}) {
	switch id1 {
	case ITIMER_MODULE_SERVICE:
		{
			switch id2 {
			case ITIMER_SERVICE_CHECK_REDIS_PING: //服务模块的定时器
				{
					//ping数据库和redis链路
					srv.Submit(func(ct *coroutines.CoroutineTask, s *Service) {
						defer s.timerEngine.Add(ITIMER_MODULE_SERVICE, ITIMER_SERVICE_CHECK_REDIS_PING, 0, 0, 0,
							time.Minute, nil, nil)
						err1 := s.mysqlEngine.C.Ping()
						if err1 != nil {
							srv.log.Error().Str("category", "service").Msgf("%v", err1)
						}
						err2 := s.redisEngine.C.ForEachMaster(context.Background(), func(ctx context.Context, client *redis.Client) error {
							return client.Ping(ctx).Err()
						})
						if err2 != nil {
							srv.log.Error().Str("category", "service").Msgf("%v", err1)
						}
					}, srv)
				}
			case ITIMER_SERVICE_CHECK_NET_TIMEOUT: //链路心跳超时
				{
					sid := int64(id3)
					if _, ok := srv.conn[sid]; ok {
						srv.log.Debug().Str("category", "service").Msgf("sid:%d hearbeat timeout", sid)
						srv.wsEngine.Close(sid)
					}
				}
			case ITIMER_SERVICE_REGISTER:
				{
					//服务注册
					srv.SendChannelData(LOBBY_SERVICE_TYPE, define.SUBSCRIBE_MAIN_SERVICE, define.SUB_SERVICE_REGISTER_REQ, srv.instance)
					srv.timerEngine.Add(ITIMER_MODULE_SERVICE, ITIMER_SERVICE_REGISTER, 0, 0, 0, time.Second*5, nil, nil)
				}
			}
		}
	case ITIMER_MODULE_LOGIC: //逻辑模块的定时器
		switch id2 {
		case ITIMER_LOGIC_ROOM:
			{
				//房间定时器
				idesk, exist := srv.roomMgr.GetDesk(id3, id4)
				if exist {
					idesk.OnTimer(id5, para1, para2)
				} else {
					if r, ok := srv.roomMgr.GetRoom(id3); ok {
						r.OnTimer(id5, para1, para2)
					}
				}
			}
		case ITIMER_LOGIC_CHECK_GAME_SETTING: //检查游戏设置
			{
				//检查一下游戏的设置是否更改
				srv.Submit(func(ct *coroutines.CoroutineTask, s *Service) {
					defer s.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_CHECK_GAME_SETTING, 0, 0, 0,
						time.Second*20, nil, nil)
					//加载游戏列表
					rows, err := s.mysqlEngine.Query("SELECT `id`,`type`,`gameid`,`name`,`choushuilv`,`is_maintenance` FROM game")
					if err != nil {
						srv.log.Error().Str("category", "service").Msgf("MysqlEngine check game setting query error:%v", err)
						return
					}
					defer rows.Close()
					setting := map[int]*Setting{}
					for rows.Next() {
						gset := &Setting{}
						if err := rows.Scan(&gset.ID, &gset.GameType, &gset.GameId, &gset.GameName, &gset.Ratio, &gset.Maintain); err == nil {
							setting[gset.ID] = gset
						}
					}
					if len(setting) > 0 {
						s.PushCostomMessage(COSTOM_MODULE_LOGIC, COSTOM_LOGIC_CHECK_GAMEING_SETTING, 0, 0, 0, setting, nil)
					}
				}, srv)
			}
		case ITIMER_LOGIC_UPDATE_GAME_RECORD: //更新游戏记录
			{
				//映射自增ID
				mp := map[int]int{}
				srv.roomMgr.Range(func(rid int, r *Room) bool {
					mp[r.set.GameId] = r.set.ID
					return true
				})
				//异步从缓存写到数据库
				srv.Submit(func(ct *coroutines.CoroutineTask, s *Service, mpID map[int]int) {
					defer s.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_UPDATE_GAME_RECORD, 0, 0, 0,
						time.Second*2, nil, nil)
					strs, _ := s.redisEngine.C.LPopCount(context.Background(), RDS_GMAE_RECORDS_KEY, 1000).Result()
					if len(strs) <= 0 {
						return
					}
					//汇总积分信息
					type ScoreInfo struct {
						ID                    int
						TotalBetScore         int64 //总投注
						PlatformTotalWinScore int64 //平台总盈利(玩家输即平台赢，玩家赢即平台输)
						TotalTaxScore         int64 //总税收
					}
					//更新汇总的数据
					updateScore := map[int]ScoreInfo{}
					//批量插入数组
					arrs := make([]define.RecordBetInfo, 0)
					for _, v := range strs {
						obj := define.RecordBetInfo{}
						if err := json.Unmarshal([]byte(v), &obj); err == nil {
							obj.BalanceTime = time.Unix(obj.Time, 0)
							arrs = append(arrs, obj)
						}
						//汇总
						if id, ok := mpID[obj.Gameid]; ok {
							val, exist := updateScore[id]
							if !exist {
								val = ScoreInfo{
									ID:                    id,
									TotalBetScore:         obj.BetScore,
									PlatformTotalWinScore: -obj.ChangeScore,
									TotalTaxScore:         obj.Tax,
								}
							} else {
								val.TotalBetScore += obj.BetScore
								val.PlatformTotalWinScore += (-obj.ChangeScore)
								val.TotalTaxScore += obj.Tax
							}
							updateScore[id] = val
						}
					}
					//批量插入
					query := strings.Builder{}
					query.WriteString(`INSERT INTO mark(order_no,userid,usecoin,wincoin,changecoin,tax,gameid,balancetime,mark,bfusercoin,afusercoin,repoolcoin,ip) 
					VALUES (:order_no,:userid,:usecoin,:wincoin,:changecoin,:tax,:gameid,:balancetime,:mark,:bfusercoin,:afusercoin,:repoolcoin,:ip)`)
					if _, err := s.mysqlEngine.NamedExec(query.String(), arrs); err != nil {
						s.log.Error().Str("category", "service").Msgf("do async record game infos error:%v", err)
					}
					//批量更新
					if len(updateScore) > 0 {
						query.Reset()
						query.WriteString("Update gambling_game_list SET ")
						for i := 0; i < 3; i++ {
							switch i {
							case 0:
								{
									query.WriteString("ngamblingbalancegold = CASE ngameid")
									for k, v := range updateScore {
										query.WriteString(fmt.Sprintf(" WHEN %d THEN ngamblingbalancegold + %d", k, v.PlatformTotalWinScore))
									}
									query.WriteString(" ELSE nGamblingBalanceGold END,")
								}
							case 1:
								{
									query.WriteString("usecointotal = CASE ngameid")
									for k, v := range updateScore {
										query.WriteString(fmt.Sprintf(" WHEN %d THEN usecointotal + %d", k, v.TotalBetScore))
									}
									query.WriteString(" ELSE useCoinTotal END,")
								}
							case 2:
								{
									query.WriteString("taxcointotal = CASE ngameid")
									for k, v := range updateScore {
										query.WriteString(fmt.Sprintf(" WHEN %d THEN taxcointotal + %d", k, v.TotalTaxScore))
									}
									query.WriteString(" ELSE taxCoinTotal END ")
								}
							}
						}
						query.WriteString("WHERE ngameid IN (")
						i := 0
						for k := range updateScore {
							query.WriteString(fmt.Sprintf("%d", k))
							if i < len(updateScore)-1 {
								query.WriteString(",")
							}
							i++
						}
						query.WriteString(");")
						_, errU := s.mysqlEngine.Exec(query.String())
						if errU != nil {
							s.log.Error().Str("category", "service").Msgf("do async upate game gambling_game_list error:%v", errU)
						}
					}
				}, srv, mp)
			}
		case ITIMER_LOGIC_SYNC_GAME_WINPOOL: //同步水池到数据库
			{
				mp := map[int]int64{}
				srv.roomMgr.Range(func(rid int, r *Room) bool {
					if r.set.GameType == define.GAME_TYPE_SLOT {
						mp[r.set.ID] = r.stock
					}
					return true
				})
				//异步同步
				srv.Submit(func(ct *coroutines.CoroutineTask, s *Service, update map[int]int64) {
					defer s.timerEngine.Add(ITIMER_MODULE_LOGIC, ITIMER_LOGIC_SYNC_GAME_WINPOOL, 0, 0, 0, time.Second*10, nil, nil)
					//需要数据库
					//批量更新
					query := strings.Builder{}
					query.WriteString("Update gambling_game_list SET")
					query.WriteString("	ngamblingwinpool = CASE ngameid")
					for k, val := range update {
						query.WriteString(fmt.Sprintf(" WHEN %d THEN %d", k, val))
					}
					query.WriteString(" ELSE ngamblingwinpool END ")
					query.WriteString("WHERE ngameid IN (")
					i := 0
					for k := range update {
						query.WriteString(fmt.Sprintf("%d", k))
						if i < len(update)-1 {
							query.WriteString(",")
						}
						i++
					}
					query.WriteString(");")
					_, errU := s.mysqlEngine.Exec(query.String())
					if errU != nil {
						srv.log.Error().
							Str("category", "service").
							Msgf("do async upate game gambling_game_list win pool error:%v", errU)
					}
				}, srv, mp)
			}
		}
	}
}

func (srv *Service) OnSubscribeMessage(channel string, data string) {
	srv.log.Debug().Str("category", "service").Msgf("channel:%s recv subscribe message:%s", channel, data)
	type ChannelMessage struct {
		Type     string      `json:"Type"`
		From     string      `json:"From"`
		MainType int         `json:"MainType"`
		SubType  int         `json:"SubType"`
		Content  interface{} `json:"Content"`
	}
	object := ChannelMessage{}
	json.Unmarshal([]byte(data), &object)
	switch object.MainType {
	case define.SUBSCRIBE_MAIN_SERVICE:
		{
			switch object.SubType {
			case define.SUB_SERVICE_REGISTER_REQ:
				{
				}
			case define.SUB_SERVICE_REGISTER_RESP:
				{
				}
			}
		}
	}
}

func (srv *Service) OnHttpMessage(hid int64, msgType int, req *http.Request) {
	//srv.httpEngine.PushMassage()
}

func (srv *Service) OnCoroutineTaskFunc(down chan struct{}, fn reflect.Value, args []reflect.Value) {
	fn.Call(args)
	down <- struct{}{}
}

func (srv *Service) OnCostomMessage(id1, id2, id3, id4, id5 int, para1, para2 interface{}) {
	switch id1 {
	case COSTOM_MODULE_SERVICE:
		switch id2 {
		case COSTOM_SERVICE_UNKNOW:
		}
	case COSTOM_MODULE_LOGIC:
		{
			switch id2 {
			case COSTOM_LOGIC_LOGIN_CHECK_COMPLETION: //回调登录完成
				{
					resp := protocol.LoginTokenResp{
						ProtocolBase: protocol.ProtocolBase{
							MainCmd: protocol.MAIN_LOGIN,
							SubCmd:  protocol.SUB_LOGIN_TOKEN_RESP,
						},
						Code: define.LOGIN_CODE_OK,
					}
					//登录校验完成消息
					sid := para1.(int64)
					//删除登录中的状态
					delete(srv.logining, sid)
					//如果连接还在
					if ip, ok := srv.conn[sid]; ok && para2 != nil {
						//登录成功
						userData := para2.(*UserData)
						//返回用户数据
						resp.Nickname = userData.nickname
						resp.Score = userData.score
						resp.GameId = userData.gid
						//用客户端的游戏ID来创建房间逻辑
						if r := srv.roomMgr.GetGameRoom(userData.gid); r != nil {
							//绑定房间号
							userData.rid = r.id
							userData.ip = ip
							userData.ins = srv.instance
							//设置用户数据
							srv.userMgr.SetOnlineUser(sid, userData)
							//回复登录成功
							datas, _ := json.Marshal(&resp)
							srv.SendData(sid, datas)
							//进入
							r.OnEnter(userData)
							//记录
							srv.log.Debug().Str("category", "service").
								Msgf("account:%s user:%d nickname:%s login success,enter room:%d",
									userData.account, userData.id, userData.nickname, r.ID())
							//通知大厅用户参与游戏
							srv.SendChannelData(LOBBY_SERVICE_TYPE,
								define.SUBSCRIBE_MAIN_LOGIC, define.SUB_LOGIC_USER_ENTER_GAME,
								fmt.Sprintf("%d,%d,%d", userData.id, userData.gid, 0))
							return
						}
					}
					resp.Code = define.LOGIN_CODE_EROOR
					if datas, err := json.Marshal(&resp); err == nil {
						srv.SendData(sid, datas)
					}
				}
			case COSTOM_LOGIC_CHECK_GAMEING_SETTING: //回调游戏设置
				{
					setting := para1.(map[int]*Setting)
					srv.roomMgr.Range(func(rid int, r *Room) bool {
						set, ok := setting[r.set.ID]
						if ok {
							r.set = set
						}
						return true
					})
				}
			case COSTOM_LOGIC_ROOM: //房间自定义消息
				{
					idesk, exist := srv.roomMgr.GetDesk(id3, id4)
					if exist {
						idesk.OnCostomMessage(id5, para1, para2)
					} else {
						if r, ok := srv.roomMgr.GetRoom(id3); ok {
							r.OnCostomMessage(id5, para1, para2)
						}
					}
				}
			}
		}
	}
}

func (srv *Service) OnWebSocketRecv(sid int64, message []byte) {
	srv.log.Debug().Str("category", "service").Msgf("sid:%d recv:%s", sid, string(message))
	//请求命令
	cmd := protocol.ProtocolBase{}
	if err := json.Unmarshal(message, &cmd); err != nil {
		srv.log.Error().Str("category", "service").Msgf("sid:%d recv:%s unmarshal error:%v", sid, string(message), err)
		srv.wsEngine.Close(sid)
		return
	}
	switch cmd.MainCmd {
	case protocol.MAIN_SYSTEM: //系统模块
		{
			switch cmd.SubCmd {
			case protocol.SUB_SYSTEM_PING:
				{
					//更新连接心跳时间
					srv.timerEngine.Fix(ITIMER_MODULE_SERVICE, ITIMER_SERVICE_CHECK_NET_TIMEOUT, int(sid), 0, 0,
						time.Second*time.Duration(srv.conf.ConnTimeout))
					type Pong struct {
						protocol.ProtocolBase
						Timestamp int64 `json:"Timestamp"`
					}
					obj := Pong{
						ProtocolBase: protocol.ProtocolBase{
							MainCmd: protocol.MAIN_SYSTEM,
							SubCmd:  protocol.SUB_SYSTEM_PONG,
						},
						Timestamp: time.Now().Unix(),
					}
					bytes, err := json.Marshal(&obj)
					if err == nil {
						srv.wsEngine.Send(sid, bytes)
					}
				}
			}
		}
	case protocol.MAIN_LOGIN: //登录协议
		{
			switch cmd.SubCmd {
			case protocol.SUB_LOGIN_TOKEN_REQ:
				{
					req := &protocol.LoginTokenReq{}
					err := json.Unmarshal(message, req)
					if err != nil {
						srv.log.Error().Str("category", "service").Msgf("sid:%d login token req unmarshal error:%v", sid, err)
						return
					}
					exist := false
					bMaintain := 0
					srv.roomMgr.Range(func(rid int, r *Room) bool {
						if r.set.GameId == req.GameId {
							exist = true
							bMaintain = r.set.Maintain
							return false
						}
						return true
					})
					//检查游戏ID
					if !exist {
						//登录不存在的游戏
						srv.log.Error().Str("category", "service").Msgf("sid:%d req error game id:%d", sid, req.GameId)
						return
					}
					//游戏维护状态
					if bMaintain > 0 {
						//禁止登录维护中的游戏
						srv.log.Warn().Str("category", "service").Msgf("sid:%d token code:%s req maintain game id:%d", sid, req.TokenCode, req.GameId)
						resp := protocol.LoginTokenResp{
							ProtocolBase: protocol.ProtocolBase{
								MainCmd: protocol.MAIN_LOGIN,
								SubCmd:  protocol.SUB_LOGIN_TOKEN_RESP,
							},
							Code: define.LOGIN_CODE_MAINTAIN,
						}
						if datas, err := json.Marshal(&resp); err == nil {
							srv.SendData(sid, datas)
						}
						return
					}
					if _, exist := srv.userMgr.GetOnlineUser(sid); !exist {
						//拦截异步登录过程中的时候，再接受到登录请求
						if val, exist := srv.logining[sid]; exist && val {
							srv.log.Warn().Str("category", "service").Msgf("sid:%d login more", sid)
							resp := protocol.LoginTokenResp{
								ProtocolBase: protocol.ProtocolBase{
									MainCmd: protocol.MAIN_LOGIN,
									SubCmd:  protocol.SUB_LOGIN_TOKEN_RESP,
								},
								Code: define.LOGIN_CODE_BUSY,
							}
							if datas, err := json.Marshal(&resp); err == nil {
								srv.SendData(sid, datas)
							}
							return
						}
						//登录验证token
						srv.Submit(func(ct *coroutines.CoroutineTask, s *Service, ssid int64, reqJson *protocol.LoginTokenReq) {
							//函数参数
							gid := reqJson.GameId          //游戏ID
							tokenCode := reqJson.TokenCode //临时token
							//拼接字符串
							builder := strings.Builder{}
							builder.WriteString("T77_lg_game_api:")
							builder.WriteString("tokensCodes:")
							builder.WriteString(tokenCode)
							//临时token中拿到用户的真正token
							ctx := context.Background()
							if val, err := s.redisEngine.C.Get(ctx, builder.String()).Result(); err == nil && val != "" {
								//删除token
								s.redisEngine.C.Del(ctx, builder.String())
								builder.Reset()
								builder.WriteString("T77_lg_game_api:")
								builder.WriteString(val)
							} else {
								srv.log.Error().Str("category", "service").Msgf("tokens codes:%s get redis error:%v", tokenCode, err)
								s.PushCostomMessage(COSTOM_MODULE_LOGIC,
									COSTOM_LOGIC_LOGIN_CHECK_COMPLETION, 0, 0, 0, ssid, nil)
								return
							}
							//分割临时字符串提取真正的token
							strs := strings.Split(builder.String(), ":")
							if len(strs) <= 1 {
								srv.log.Error().Str("category", "service").Msgf("token codes:%s spllit error", builder.String())
								s.PushCostomMessage(COSTOM_MODULE_LOGIC,
									COSTOM_LOGIC_LOGIN_CHECK_COMPLETION, 0, 0, 0, ssid, nil)
								return
							}
							//用临时token绑定隐射真正的token获取用户数据
							val, err := s.redisEngine.C.Get(ctx, builder.String()).Result()
							if err != nil {
								srv.log.Error().Str("category", "service").Msgf("token codes value:%s get redis error:%v", builder.String(), err)
								s.PushCostomMessage(COSTOM_MODULE_LOGIC,
									COSTOM_LOGIC_LOGIN_CHECK_COMPLETION, 0, 0, 0, ssid, nil)
								return
							}
							//临时对象数据
							type TempUser struct {
								Id       int64  `json:"id"`
								Account  string `json:"account"`
								Nickname string `json:"nickname"`
							}
							obj := &TempUser{}
							//反序列化
							err = json.Unmarshal([]byte(val), obj)
							if err != nil {
								srv.log.Error().Str("category", "service").Msgf("token:%s get redis value:%s unmarshal json error:%v", strs[2], val, err)
								s.PushCostomMessage(COSTOM_MODULE_LOGIC,
									COSTOM_LOGIC_LOGIN_CHECK_COMPLETION, 0, 0, 0, ssid, nil)
								return
							}
							//用户结构
							userData := &UserData{
								sid:       ssid,
								id:        obj.Id,
								account:   obj.Account,
								nickname:  obj.Nickname,
								rid:       INVALID_ROOM,
								did:       INVALID_DESK,
								seat:      INVALID_SEAT,
								score:     0,
								token:     strs[2],
								gid:       gid,
								tokenCode: tokenCode}

							//获取用户金额
							score, ok := api.GetUserScore(userData.token, userData.account)
							if !ok {
								srv.log.Error().Str("category", "service").Msgf("token:%s account:%s get score faild", userData.token, userData.account)
								s.PushCostomMessage(COSTOM_MODULE_LOGIC,
									COSTOM_LOGIC_LOGIN_CHECK_COMPLETION, 0, 0, 0, ssid, nil)
								return
							}
							userData.score = score
							//异步登录完成
							s.PushCostomMessage(COSTOM_MODULE_LOGIC,
								COSTOM_LOGIC_LOGIN_CHECK_COMPLETION, 0, 0, 0, ssid, userData)
						}, srv, sid, req)
						//异步登录中
						srv.logining[sid] = true
					} else {
						//重复登录
						srv.log.Error().Str("category", "service").Msgf("sid:%d repeat login", sid)
						resp := protocol.LoginTokenResp{
							ProtocolBase: protocol.ProtocolBase{
								MainCmd: protocol.MAIN_LOGIN,
								SubCmd:  protocol.SUB_LOGIN_TOKEN_RESP,
							},
							Code: define.LOGIN_CODE_REPEAT,
						}
						if datas, err := json.Marshal(&resp); err == nil {
							srv.SendData(sid, datas)
						}
					}
				}
			}
		}
	case protocol.MAIN_GAME: //游戏协议
		{
			if _, idesk, exist := srv.GetOnlineDesk(sid); exist {
				idesk.OnMessage(sid, cmd.SubCmd, message)
			}
		}
	}
}
