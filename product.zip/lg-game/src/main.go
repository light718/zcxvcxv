package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"t77/lg/service"

	"intech.t77.com/pkg/logger"

	"t77/lg/config"

	"github.com/philchia/agollo/v4"
	"github.com/rs/zerolog"
)

func main() {
	//环境变量获得配置地址
	app := os.Getenv("APP_ID")
	addr := os.Getenv("APOLLO_META")
	var log *zerolog.Logger
	//程序配置
	var conf *config.ServiceApp = nil
	if addr != "" {
		log = logger.NewZerolog(true)
		//apollo
		agollo.Start(&agollo.Conf{
			AppID:          app,
			Cluster:        "default",
			NameSpaceNames: []string{"application.properties", "config.yaml"},
			MetaAddr:       addr,
		}, agollo.WithLogger(logger.NewAgolloLogger(log)))
		//apollo 监听更新
		agollo.OnUpdate(func(ce *agollo.ChangeEvent) {

		})
		strContent := agollo.GetContent(agollo.WithNamespace("config.yaml"))
		if strContent == "" {
			panic(fmt.Sprintf("addr:%s get content error", addr))
		}
		conf = config.NewConfig(strContent)
	} else {
		log = logger.NewZerolog(false)
		conf = config.NewConfigWithLocal()
	}
	hostname, _ := os.Hostname()
	srv := service.New(hostname, log, conf)
	if srv == nil {
		panic("main srv nil")
	}
	srv.Start()
	defer srv.Stop()
	c := make(chan os.Signal)
	signal.Notify(c, syscall.SIGTERM, syscall.SIGINT)
	select {
	case <-c:
		os.Exit(1)
	}
}
