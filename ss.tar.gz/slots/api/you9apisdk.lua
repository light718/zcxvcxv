local skynet = require "skynet"
require "skynet.manager"
local httpc = require "http.httpc"
local cjson = require "cjson"
local jsondecode = cjson.decode

local snax = require "snax"
local cluster = require "cluster"
local webclient
local CMD = {}
local url_head = "http://192.168.50.124/game/"
local MAX_REGISTER_NUM = 100 --最多同时创建的用户数量
local TIME_OUT  = 3000
--1=正常，0=游戏维护中
local game_switch = 0
--白名单列表 用,分割
local game_swl = ""
local LOCAL_POOL_CHECK = false --是否检查本地水线
----为生成唯一id使用的变量
----为生成唯一id使用的变量

local MAX_SUBGAME_LOSE = 10000 --子游戏保底到1W，如果低于这个值 那么借钱或者扣款不成功

--主动请求redbagsetting 如果出现错误会定时重新请求
function requestredbagsetting()
    local url = url_head.."/game/system/redbagsetting"
    local ok, body = skynet.call(webclient, "lua", "request", url, nil, nil, false,TIME_OUT)
    local resp = nil
    local needrecall = false
    if not ok or body == nil then
        needrecall = true
    else
        LOG_DEBUG("requestredbagsetting body:", body)
        ok,resp = pcall(jsondecode,body)
        if not ok then
            needrecall = true
        else
            --[[
                成功：
                {
                    "errcode": 0,
                    "error": "",
                    "data": {
                        "pool_rb_isopen": 1,        【救济红包】 是否开启救济红包
                        "pool_rb_limitup": 10,      【救济红包】 发放红包上限 下限超过上限时红包不会发放
                        "pool_rb_limitdown": 1,     【救济红包】 发放红包下限 下限超过上限时红包不会发放
                        "pool_rb_coinless": 10,     【救济红包】 玩家当前余额小于
                        "pool_rb_7daycoindiff": -1  【救济红包】 7日分差 >=
                    }
                }
            ]]
            if resp.errcode ~= 0 then
                --启动一个定时服务 有可能后台在维护
                needrecall = true
            end
        end
    end

    if needrecall then
        --启动一个定时服务 有可能后台在维护
        local function t()
            requestredbagsetting()
        end
        --6000 60秒之后再请求一次 不用太频繁
        skynet.timeout(6000, t)
        return
    end

    local pool_rb_isopen = resp.data.pool_rb_isopen
    local pool_rb_limitup = resp.data.pool_rb_limitup
    local pool_rb_limitdown = resp.data.pool_rb_limitdown
    local pool_rb_coinless = resp.data.pool_rb_coinless
    local pool_rb_7daycoindiff = resp.data.pool_rb_7daycoindiff 

    local data = {}
    data.pool_rb_isopen = pool_rb_isopen
    data.pool_rb_limitup = pool_rb_limitup
    data.pool_rb_limitdown = pool_rb_limitdown
    data.pool_rb_coinless = pool_rb_coinless
    data.pool_rb_7daycoindiff = pool_rb_7daycoindiff

    LOG_DEBUG("requestredbagsetting data:", data)
    do_redis({"hmset", PDEFINE.REDISKEY.YOU9API.redbagsetting, data})
end

--[[
请求游戏开关接口
]]
function requestgameswitch( )
    local url = url_head.."/game/system/gameswitch"
    local ok, body = skynet.call(webclient, "lua", "request", url, nil, nil, false,TIME_OUT)
    local resp = nil
    local needrecall = false
    if not ok or body == nil then
        needrecall = true
    else
        LOG_DEBUG("requestgameswitch body:", body)
        ok,resp = pcall(jsondecode,body)
        if not ok then
            needrecall = true
        else
            if resp.errcode ~= 0 then
                --启动一个定时服务 有可能后台在维护
                needrecall = true
            end
        end
    end

    if needrecall then
        --启动一个定时服务 有可能后台在维护
        local function t()
            requestgameswitch()
        end
        --6000 60秒之后再请求一次 不用太频繁
        skynet.timeout(6000, t)
        return
    end

    game_switch = resp.data.game_switch
    game_swl = resp.data.game_swl
    if game_swl == nil then
        game_swl = ""
    end
    if game_switch == 0 then
        --关闭
        ok, retok, result = pcall(cluster.call, "master", ".mgrdesk", "apiCloseServer")
        --T人下线
        ok,retok,result = pcall(cluster.call, "master", ".userCenter", "ApiPushRestart")
    elseif game_switch == 1 then
        --开启
        ok, retok, result = pcall(cluster.call, "master", ".mgrdesk", "apiStartServer")
    end

end

--[[
请求jp,bigbang,双龙,争霸彩封装
]]
local function requestapi( url_tail, rediskey, setdata)
    local url = url_head..url_tail
    LOG_DEBUG("requestapi url:", url)
    local ok, body = skynet.call(webclient, "lua", "request", url, nil, nil, false, TIME_OUT)
    local resp = nil
    local needrecall = false
    if not ok or body == nil then
        needrecall = true
    else
        LOG_DEBUG("requestapi body:", body)
        ok,resp = pcall(jsondecode,body)
        if not ok then
            needrecall = true
        else
            --[[
                成功：
                {
                    "errcode": 0,
                    "error": "",
                    "data": {
                        "pool_jp_disbaseline": "200000",    【JP池】 DIS 显示基准值
                        "pool_jp_diswave": "11",            【JP池】 DIS 波动额
                        "pool_jp_disinterval": "10",        【JP池】 DIS 下降间隔时间
                        "pool_jp_disdownpar": "123"         【JP池】 DIS 下降率
                    }
                }
            ]]
            if resp.errcode ~= 0 then
                --启动一个定时服务 有可能后台在维护
                needrecall = true
            end
        end
    end

    if needrecall then
        --启动一个定时服务 有可能后台在维护
        local function t()
            requestapi(url_tail, rediskey)
        end
        --6000 60秒之后再请求一次 不用太频繁
        skynet.timeout(6000, t)
        return
    end

    local data = setdata(resp.data)
    assert(data.disbaseline)
    assert(data.valdown_parl)
    assert(data.valdown_time)
    assert(data.wave_val)
    data.update_time = os.time()

    LOG_DEBUG("requestapi data:", data)
    do_redis({"hmset", rediskey, data})
end

--后台上下分
--@param uid
--@param coin
--@param ipaddr
--@return code
function CMD.addCoin(uid, coin, ipaddr, addType, extend1)
    LOG_DEBUG("-->-->-->addCoin uid", uid, "coin", coin, ' addType:', addType)
    coin = tonumber(coin)
    local ok, retok, result = pcall(cluster.call, "master", ".userCenter", "apiAddCoin", uid, coin, ipaddr, addType, extend1)
    if not ok or retok~=PDEFINE.RET.SUCCESS then
        LOG_ERROR("addCoin CALL_FAIL uid", uid, "coin", coin, ' addType:', addType)
        return PDEFINE.RET.ERROR.CALL_FAIL
    end
    if retok == PDEFINE.RET.SUCCESS and 'red_envelope' ~= addType then
        local updowncoin = coin

        local datestr = os.date("%Y%m%d",os.time())
        --记录到redis 并且设置7天后过期
        local rediskey = PDEFINE.REDISKEY.YOU9API.day7coindiff..":"..uid..":"..datestr
        local value = do_redis( {"get", rediskey}, uid )
        if value == nil then
            --这里设置过期时间 14天 为了方便查询之前的数据
            local DAY7COINDIFF_EXPIRETIME = 14*24*3600
            do_redis( {"setex", rediskey, updowncoin, DAY7COINDIFF_EXPIRETIME}, uid )
        else
            updowncoin = tonumber(value) + updowncoin
            do_redis( {"set", rediskey, updowncoin}, uid )
        end

        return PDEFINE.RET.SUCCESS
    else
        LOG_ERROR("addCoin retok", retok)
        return retok
    end
end

--[[
检查是否有用户需要创建
根据后台API服的队列通知，建立游戏服账号
]]
local function checkregister( )
    local registernum = 0
    local rediskey = "{bigbang}:logs:players"
    local result = do_redis_withprename( "api_", {"lpop", rediskey} )
    while result ~= nil do
        registernum = registernum + 1
        if registernum > MAX_REGISTER_NUM then
            break
        end
        LOG_DEBUG( "checkregister registeruser:", result )
        local ok,jsondata = pcall(jsondecode,result)
        if not ok then
            LOG_ERROR( "checkregister fail,jsondata error:", result )
        else
            local ok = pcall(cluster.call, "master", ".userCenter", "registeruser", jsondata)
            LOG_DEBUG( "checkregister call userCenter ok:", ok)
            if not ok then
                --失败了
                LOG_ERROR( "checkregister fail,registeruser:", result )
                --可能是服务出错了 先不继续执行了
                return
            end
            --创建成功了 开始上下分
            if tonumber(jsondata.coin) > 0 then
                --上下分
                local ok, code = pcall(CMD.addCoin, math.floor(tonumber(jsondata.uid)), tonumber(jsondata.coin), jsondata.ipaddr)
                if not ok or code ~= PDEFINE.RET.SUCCESS then
                    LOG_ERROR( "checkregister fail,addCoin error ok:", ok, "code:", code)
                end
            end
            --BB红包用户，代理创建完账号,直接就给玩家红包，玩家登录只展示红包打开动作
            if nil~=jsondata.red_envelope and tonumber(jsondata.red_envelope) > 0 then
                --上下分
                local ok, code = pcall(CMD.addCoin, math.floor(tonumber(jsondata.uid)), tonumber(jsondata.red_envelope), jsondata.ipaddr, 'red_envelope')
                if not ok or code ~= PDEFINE.RET.SUCCESS then
                    LOG_ERROR( "checkregister red_envelope fail ,addCoin error ok:", ok, "code:", code)
                end
            end
        end

        result = do_redis_withprename( "api_", {"lpop", rediskey} )
    end
end

--1S执行一次
function update( )
    while true do
        pcall(checkregister)
        skynet.sleep(20)
    end
end

--设置游戏状态
function CMD.setgameswitch(game_switch_p, game_swl_p)
    game_switch = tonumber(game_switch_p) or 1
    game_swl = game_swl_p
    return PDEFINE.RET.SUCCESS
end

--获取游戏状态
function CMD.getgameswitch()
    LOG_DEBUG( "getgameswitch game_switch:", game_switch, " game_swl:", game_swl )
    return game_switch, game_swl
end

--导入库存量
--@param gameid
--@return 库存量
local function reloadSubGamePool(gameid)
    local pool = do_redis({"get", string.format("%s:%s", PDEFINE.REDISKEY.YOU9API.subgame_localpool, gameid)})
    if pool == nil then
        pool = 0
    end
    return pool
end

--获取库存量
--@param gameid
--@return 库存量
local function getSubgamePool(gameid)
    local local_pool = reloadSubGamePool(gameid)
    return local_pool
end

--设置库存量
--@param gameid
--@param pool 库存量
local function setSubgamePool(gameid, pool)
    do_redis({"set", string.format("%s:%s", PDEFINE.REDISKEY.YOU9API.subgame_localpool, gameid), pool})
end

--设置库存量
--@param gameid
--@param pool 库存量
function CMD.addSubgamePool(gameid, num)
    local local_pool = getSubgamePool(math.floor(tonumber(gameid)))
    do_redis({"set", string.format("%s:%s", PDEFINE.REDISKEY.YOU9API.subgame_localpool, math.floor(tonumber(gameid))), local_pool + num})
end

--检查本地库存控制是否能通过
--@param gameid 子游戏id
--@param altercoin 修改金币数量
--@return true 通过  false 不通过
function CMD.localPoolCheck(gameid, altercoin)
    if gameid < 100 then    -- 捕鱼借的比较多，不检查
        return true
    end
    if not LOCAL_POOL_CHECK then
        return true
    end
    local gameid_num = math.floor(tonumber(gameid))
    if altercoin <= 0 then
        return true
    end
    local local_pool = getSubgamePool(gameid_num)
    if local_pool - altercoin < MAX_SUBGAME_LOSE then
        LOG_INFO("localPoolCheck", gameid, altercoin, local_pool)
        return false
    else
        setSubgamePool(gameid_num, local_pool - altercoin)
        return true
    end
end

--bigbang API数据转化为统一数据
function setdisbigbang( data )
    local bb_disbaseline = data.bb_disbaseline --显示基准值，自设定起，大厅界面中的BBJP奖池金额将从这个值开始浮动
    local bb_valdown_parl = data.bb_valdown_parl --下降率，左值
    local bb_valdown_time = data.bb_valdown_time --下降间隔时间，单位分钟
    local bb_wave_val = data.bb_wave_val --BBJP奖池金额显示值以所有拉霸游戏实际的下注为时机进行波动。每次下注行为将会向BBJP奖池增加以下设定金额

    local tmp = {}
    tmp.disbaseline = bb_disbaseline
    tmp.valdown_parl = bb_valdown_parl
    tmp.valdown_time = bb_valdown_time
    tmp.wave_val = bb_wave_val
    return tmp
end

--双龙彩 API数据转化为统一数据
function setdisslcdata( data )
    local bb_disbaseline = data.pool_slc_disbaseline --显示基准值，自设定起，大厅界面中的BBJP奖池金额将从这个值开始浮动
    local bb_valdown_parl = data.pool_slc_disdownpar --下降率，左值
    local bb_valdown_time = data.pool_slc_disinterval --下降间隔时间，单位分钟
    local bb_wave_val = data.pool_slc_diswave --BBJP奖池金额显示值以所有拉霸游戏实际的下注为时机进行波动。每次下注行为将会向BBJP奖池增加以下设定金额

    local tmp = {}
    tmp.disbaseline = bb_disbaseline
    tmp.valdown_parl = bb_valdown_parl
    tmp.valdown_time = bb_valdown_time
    tmp.wave_val = bb_wave_val
    return tmp
end

--争霸彩 API数据转化为统一数据
function setdiszbcdata( data )
    local bb_disbaseline = data.pool_zbc_disbaseline --显示基准值，自设定起，大厅界面中的BBJP奖池金额将从这个值开始浮动
    local bb_valdown_parl = data.pool_zbc_disdownpar --下降率，左值
    local bb_valdown_time = data.pool_zbc_disinterval --下降间隔时间，单位分钟
    local bb_wave_val = data.pool_zbc_diswave --BBJP奖池金额显示值以所有拉霸游戏实际的下注为时机进行波动。每次下注行为将会向BBJP奖池增加以下设定金额

    local tmp = {}
    tmp.disbaseline = bb_disbaseline
    tmp.valdown_parl = bb_valdown_parl
    tmp.valdown_time = bb_valdown_time
    tmp.wave_val = bb_wave_val
    return tmp
end

--pooljp API数据转化为统一数据
function setpooljp( data )
    local pool_jp_disbaseline = data.pool_jp_disbaseline
    local pool_jp_diswave = data.pool_jp_diswave
    local pool_jp_disinterval = data.pool_jp_disinterval
    local pool_jp_disdownpar = data.pool_jp_disdownpar

    local tmp = {}
    tmp.disbaseline = pool_jp_disbaseline
    tmp.valdown_parl = pool_jp_disdownpar
    tmp.valdown_time = pool_jp_disinterval
    tmp.wave_val = pool_jp_diswave
    return tmp
end

-- 设置mega奖池数据
function setpoolmega(data)
    local disbaseline = data.pool_mega_disbaseline
    local diswave = data.pool_mega_diswave
    local disinterval = data.pool_mega_disinterval
    local disdownpar = data.pool_mega_disdownpar

    local tmp = {}
    tmp.disbaseline = disbaseline
    tmp.valdown_parl = disdownpar
    tmp.valdown_time = disinterval
    tmp.wave_val = diswave
    return tmp
end

-- 设置grand奖池数据
function setpoolgrand(data)
    local disbaseline = data.pool_grand_disbaseline
    local diswave = data.pool_grand_diswave
    local disinterval = data.pool_grand_disinterval
    local disdownpar = data.pool_grand_disdownpar

    local tmp = {}
    tmp.disbaseline = disbaseline
    tmp.valdown_parl = disdownpar
    tmp.valdown_time = disinterval
    tmp.wave_val = diswave
    return tmp
end

skynet.start(function()
    local apiurl = cluster.call( "master", ".configmgr", "get", "apiurl" )
    if apiurl == nil then
        LOG_ERROR("you9apisdk apiurl isnil.")
    end
    url_head = apiurl.v
    for i= 1, PDEFINE.MAX_APIWORKER do
        skynet.newservice("you9api_worker", i)
    end
    skynet.dispatch("lua", function(session, address, cmd, ...)
        local f = CMD[cmd]
        skynet.retpack(f(...))
    end)
    webclient = skynet.newservice("webreq")
    requestredbagsetting()
    requestgameswitch()

    requestapi("/game/system/dispoolgrand", PDEFINE.REDISKEY.YOU9API.poolgrand, setpoolgrand) --poolgrand 盛大奖池
    requestapi("/game/system/dispoolmega", PDEFINE.REDISKEY.YOU9API.poolmega, setpoolmega) --poolmega  超大奖池
    requestapi("/game/system/dispooljp", PDEFINE.REDISKEY.YOU9API.pooljp, setpooljp) --pooljp 大奖池
    requestapi("/game/system/disslc", PDEFINE.REDISKEY.YOU9API.disslc, setdisslcdata) --双龙彩  中等奖池
    requestapi("/game/system/diszbc", PDEFINE.REDISKEY.YOU9API.diszbc, setdiszbcdata) --争霸彩  小奖池
    requestapi("/game/system/disbigbang", PDEFINE.REDISKEY.YOU9API.disbigbang, setdisbigbang) --bigbang
    skynet.register(".you9apisdk")

    skynet.fork(update)
end)