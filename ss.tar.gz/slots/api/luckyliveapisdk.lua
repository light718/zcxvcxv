local skynet = require "skynet"
require "skynet.manager"
local httpc = require "http.httpc"
local cjson = require "cjson"
local snax = require "snax"
local cluster = require "cluster"
local CMD = {}
local url_head = "http://192.168.50.124/game/"
local OP = skynet.getenv("evo_op")
local PRIVATE_KEY = skynet.getenv("evo_privatekey")
----为生成唯一id使用的变量
local ticket_uniquepara = { uniqueindex = 0, lasttime = 1 }

function CMD.genticketid( uid )
    local time = os.time()
    if ticket_uniquepara.lasttime ~= time then
        ticket_uniquepara.uniqueindex = 0
    end
    ticket_uniquepara.lasttime = time
    ticket_uniquepara.uniqueindex = ticket_uniquepara.uniqueindex + 1
    local id = time*10000 + ticket_uniquepara.uniqueindex
    return "tk"..id
end

function CMD.insertevo_amount_log( data )
    --TODO id改成代码生成 insert放到worker去
    LOG_DEBUG("insertevo_amount_log:",data)

    local ticketid = data.ticketid
    local amount = data.amount
    local state = tonumber(data.state)
    local gameid = data.gameid
    local deskuuid = data.deskuuid
    local deskid = data.deskid
    local uid = tonumber(data.uid)
    local evoaccount = data.evoaccount
    local game_identification = data.game_identification

    local sql = string.format("insert into evo_amount_log(id,ticketid,amount,backamount,state,gameid,deskuuid,deskid,uid,evoaccount,time,updatetime,checktime,game_identification) "..
                                                "values (0,'%s', %0.4f, 0, %d, %d,'%s','%s',%d,'%s',%d,%d,0,%d)", ticketid, amount,state,gameid,deskuuid,deskid,uid,evoaccount,os.time(),os.time(),game_identification)
    LOG_DEBUG("insertevo_amount_log sql=",sql)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    local uniqueid = rs.insert_id

    return uniqueid,data
end


skynet.start(function()
    local apiurl = cluster.call( "master", ".configmgr", "get", "apiurl" )
    if apiurl == nil then
        LOG_ERROR("luckyliveapisdk apiurl isnil.")
    end
    url_head = apiurl.v
    LOG_DEBUG("PRIVATE_KEY:", PRIVATE_KEY, " luckyliveapiurl:", url_head, " OP:", OP)
    for i= 1, PDEFINE.MAX_APIWORKER do
        skynet.newservice("luckyliveapisdk_worker", i)
    end
    skynet.dispatch("lua", function(session, address, cmd, ...)
        local f = CMD[cmd]
        skynet.retpack(f(...))
    end)
    skynet.register(".luckyliveapisdk")
end)