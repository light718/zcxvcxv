local skynet = require "skynet"
require "skynet.manager"
local httpc = require "http.httpc"
local cjson = require "cjson"
local snax = require "snax"
local cluster = require "cluster"
local player_tool = require "base.player_tool"
local webclient
local CMD = {}
local url_head = "http://192.168.50.124/game/"
local TIME_OUT  = 20000
local OP = skynet.getenv("evo_op") -- Token
local PRIVATE_KEY = skynet.getenv("evo_privatekey") -- Key
local worker_index = ...
local APP = skynet.getenv("app")

-- 错误码
local APIRET =
{
    [200] = PDEFINE.RET.SUCCESS,              -- 成功
    [300] = PDEFINE.RET.UNDEFINE,             -- 未定义错误
}

--我们的游戏id对应evo的大厅id
local GAMEID2PAGECODE=
{
    [30201]=103,--百家乐视频
    [30209]=104,--俄罗斯视频
    [30210]=105,--21点视频
    [30206]=103,--龙虎斗视频
}

--进入游戏
function CMD.LaunchGame(param)

    local access_token = param.token
    local amount       = math.abs(param.alteramount)
    local identification = param.game_identification
    local evoaccount   = param.evoaccount

    if nil == webclient then
        LOG_ERROR("webclient not ready!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end

    local url = url_head.."/evolution/game/start"
    LOG_DEBUG( "LaunchGame url:", url .. '?token=' .. access_token, ' post: game_identification:', identification, ' coin:', amount)
    local ok, body = skynet.call(webclient, "lua", "request", url, {token = access_token}, {token = access_token, game_identification = identification, coin=amount, evoaccount=evoaccount}, false, TIME_OUT) --post请求
    LOG_DEBUG("OK:", ok, " BODY:", body)
    if not ok then
        LOG_ERROR("LaunchGame user from you9apisdk error!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end
    LOG_DEBUG("LaunchGame post qequest url:", url, " body:", body)
    local ok,resp = pcall(jsondecode,body)
    if not ok then
        LOG_ERROR("LaunchGame url:", url," Verify token from you9apisdk body error!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end

    local rs = {}
    rs.apirs = resp
    if resp.errcode > 0 then
        LOG_ERROR("LaunchGame url:", url, "you9apisdk getAccessToken err. resp:",resp)
        local myerrcode = APIRET[math.floor(resp.errcode)]
        if myerrcode == nil then
            myerrcode = PDEFINE.RET.UNDEFINE
        end
        return myerrcode,rs
    end

    return PDEFINE.RET.SUCCESS, resp.data.uri, resp.data.euid
end

--确认evo的返回金额游戏服已经收到
function CMD.ConfirmAmountBackGame(param)
    local access_token = param.token
    local transid       = param.transid
    local result       = math.abs(param.result)

    if nil == webclient then
        LOG_ERROR("webclient not ready!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end

    local url = url_head.."/evolution/game/order"
    LOG_DEBUG( "ConfirmAmount url:", url .. '?token=' .. access_token, ' post: transid:', transid, ' result:', result)
    local ok, body = skynet.call(webclient, "lua", "request", url, {token = access_token}, {token = access_token, transid = transid, result=result}, false, TIME_OUT) --post请求
    LOG_DEBUG("ConfirmAmount OK:", ok, " BODY:", body)
    if not ok then
        LOG_ERROR("ConfirmAmount user from you9apisdk error!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end
    local ok,resp = pcall(jsondecode, body)
    if not ok then
        LOG_ERROR("ConfirmAmount url:", url," Verify token from you9apisdk ConfirmAmount body error!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end

    local rs = {}
    rs.apirs = resp
    if resp.errcode > 0 then
        LOG_ERROR("ConfirmAmount url:", url, "you9apisdk ConfirmAmount err. resp:",resp)
        local myerrcode = APIRET[math.floor(resp.errcode)]
        if myerrcode == nil then
            myerrcode = PDEFINE.RET.UNDEFINE
        end
        return myerrcode,rs
    end

    return PDEFINE.RET.SUCCESS, resp.data
end

--往evo充值
function CMD.RechargeGame(param)
    local access_token = param.token
    local amount       = math.abs(param.alteramount)
    local identification = param.game_identification

    if nil == webclient then
        LOG_ERROR("webclient not ready!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end

    local url = url_head.."/evolution/game/recharge"
    LOG_DEBUG( "RechargeGame url:", url .. '?token=' .. access_token, ' post: game_identification:', identification, ' coin:', amount)
    local ok, body = skynet.call(webclient, "lua", "request", url, {token = access_token}, {token = access_token, game_identification = identification, coin=amount}, false, TIME_OUT) --post请求
    LOG_DEBUG("RechargeGame OK:", ok, " BODY:", body)
    if not ok then
        LOG_ERROR("RechargeGame user from you9apisdk error!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end
    local ok,resp = pcall(jsondecode,body)
    if not ok then
        LOG_ERROR("RechargeGame url:", url," Verify token from you9apisdk body error!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end

    local rs = {}
    rs.apirs = resp
    if resp.errcode > 0 then
        LOG_ERROR("RechargeGame url:", url, "you9apisdk getAccessToken err. resp:",resp)
        local myerrcode = APIRET[math.floor(resp.errcode)]
        if myerrcode == nil then
            myerrcode = PDEFINE.RET.UNDEFINE
        end
        return myerrcode,rs
    end

    return PDEFINE.RET.SUCCESS, resp.data
end

function insert_evolog(uid,evoaccount,amount,gameid,deskuuid,deskid, ticketid, game_identification)
    --插入数据记录
    local data = {}
    data.ticketid = ticketid
    data.amount = amount
    data.state = PDEFINE.EVO_AMOUNT_STATE.ready
    data.gameid = gameid
    data.deskuuid = deskuuid
    data.deskid = deskid
    data.uid = uid
    data.evoaccount = evoaccount
    data.game_identification = game_identification
    local uniqueid,evologdata = skynet.call(".luckyliveapisdk","lua","insertevo_amount_log",data)
    return uniqueid,evologdata
end

--开始游戏
--@param game_identification 一轮evo游戏的唯一id
function CMD.StartGame(param)
    local uid        = param.uid
    local evoaccount = param.evoaccount
    local amount     = param.alteramount
    local gameid     = param.gameid
    local deskid     = param.deskid 
    local deskuuid   = param.uid
    local game_identification = param.game_identification
    if evoaccount ==nil or evoaccount == "" then
        evoaccount = param.uid
    end
    LOG_DEBUG("startgame-----------lucky", param)
    local result = {}
    local ok, redirect_url, euid = CMD.LaunchGame(param)
    LOG_DEBUG("LaunchGame redirect_url:",redirect_url,"ok:",ok, " euid: ", euid)
    if not ok then
        return PDEFINE.RET.ERROR.DESK_ERROR, amount
    end

    local ticketid = skynet.call(".luckyliveapisdk","lua","genticketid",uid)
    local uniqueid,evologdata = insert_evolog(uid,evoaccount,amount,gameid,deskuuid,deskid,ticketid,game_identification)

    result.page_url = redirect_url
    result.session = ticketid
    result.redirect_url = redirect_url
    result.ticketid = ticketid
    result.uniqueid = uniqueid
    result.euid = euid
    return PDEFINE.RET.SUCCESS, 0, result
end

local exitGameRetryTimes = {}

--退出游戏
function CMD.ExitGame(evouser, deskInfo, access_token, game_identification) 
    LOG_DEBUG("ExitGame evouser:",evouser,"deskInfo.deskid:",deskInfo.deskid, 'token:', access_token)
    local uid = evouser.uid

    if nil == webclient then
        LOG_ERROR("webclient not ready!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end

    local url = url_head.."/evolution/game/logout"
    LOG_DEBUG( "ExitGame url:", url .. '?token=' .. access_token)
    local ok, body = skynet.call(webclient, "lua", "request", url, {token = access_token}, {token = access_token}, false, TIME_OUT) --post请求
    LOG_DEBUG("ExitGame post back :", ok, body)
    if not ok then
        LOG_ERROR("ExitGame user from you9apisdk error!")

        if exitGameRetryTimes[access_token]==nil or exitGameRetryTimes[access_token] <= 3 then 
            
            --启动一个定时服务 有可能网络异常
            local function t()
                CMD.ExitGame(evouser, deskInfo, access_token, game_identification) 
            end
            --1秒之后再请求一次 不用太频繁
            skynet.timeout(100, t)
            
            if exitGameRetryTimes[access_token] == nil then 
                exitGameRetryTimes[access_token] = 1
            else
                exitGameRetryTimes[access_token] = exitGameRetryTimes[access_token] + 1
            end
            LOG_DEBUG("ExitGame FAIL, access_token" , access_token, " retry times:" , exitGameRetryTimes[access_token])
        end
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end
    local ok,resp = pcall(jsondecode,body)
    if not ok then
        LOG_ERROR("ExitGame url:", url," Verify token from you9apisdk body error!")
        return PDEFINE.RET.ERROR.REGISTER_FAIL
    end
    if exitGameRetryTimes[access_token] ~= nil then
        exitGameRetryTimes[access_token] = nil --请求通了，不需要再重试
    end

    local rs = {}
    rs.apirs = resp
    if resp.errcode > 0 then
        LOG_ERROR("ExitGame url:", url, "you9apisdk getAccessToken err. resp:",resp)
        return math.floor(resp.errcode),rs
    end

    local eTransID = resp.data.eTransID or ""
    local backamount = resp.data.withdraw 
    backamount = tonumber(backamount)
    if backamount~=nil and backamount >= 0 then
        -- --通知api转钱回来了
        local ok,code = player_tool.calUserCoin_do(
            uid, 
            backamount, 
            "evo backamount:"..backamount, 
            PDEFINE.ALTERCOINTAG.WITHDRAWTHIRDGAME, 
            PDEFINE.GAME_TYPE.SPECIAL.PLATFORM_EVO, 
            PDEFINE.POOL_TYPE.none, 
            uid, 
            0,
            nil,
            game_identification,
            nil,
            eTransID
        )
        if not ok then
            LOG_ERROR("evo backamount fail.code:",code," coin:",backamount)
        end
    end

    if tonumber(APP) == 4 then
        CMD.ConfirmAmountBackGame({token=access_token, transid=eTransID, result=1})
    end
    return PDEFINE.RET.SUCCESS, rs
end

skynet.start(function()
    local apiurl = cluster.call( "master", ".configmgr", "get", "apiurl" )
    if apiurl == nil then
        LOG_ERROR("luckyliveapisdk_worker apiurl isnil.")
    end
    url_head = apiurl.v

    LOG_DEBUG("PRIVATE_KEY:", PRIVATE_KEY, " luckyliveapiurl:", url_head, " OP:", OP)
    skynet.dispatch("lua", function(session, address, cmd, ...)
        LOG_DEBUG("receive cmd:", cmd, ...)
        local f = CMD[cmd]
        skynet.retpack(f(...))
    end)
    webclient = skynet.newservice("webreq")
    skynet.register(".luckyliveapisdk_worker"..worker_index)
end)