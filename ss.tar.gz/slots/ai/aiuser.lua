local skynet = require "skynet"
local random = require "random"
require "skynet.manager"
local cluster = require "cluster"
local snax = require "snax"
local cjson = require "cjson"
local date = require "date"

local CMD = {}
local iid = 0
local aiUserList = {}
local spLevelUserList = {}  -- 特定等级机器人，等级不会变
local APP = skynet.getenv("app") or 1
local autoChangeRobotLevel = nil  -- 自动更换机器人等级

local function rearrange(count)
    local l = table.size(aiUserList)
    if l < 2 then return end
    for i = 1, count do
        local r = random_get(2,l)
        local r1 = random_get(1,r-1)
        local r2 = random_get(r, l)
        local tmp = aiUserList[r1]
        aiUserList[r1] = aiUserList[r2]
        aiUserList[r2] = tmp
    end
end

local function loadData()
    local temp_config_list = {}
    -- 每次启动的时候，将机器人的金币随机下，目前是随机1亿以内的数据
    local updateCoinSql = "update d_user set coin=FLOOR(RAND()*1000000000) where isrobot=1";
    skynet.call(".mysqlpool", "lua", "execute", updateCoinSql)
    local sql = "select * from d_user where isrobot=1"
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        for _, row in pairs(rs) do
            do_redis({"hmset", "d_user:" .. row.uid, row})
            table.insert(temp_config_list, row)
        end
    end
    aiUserList = temp_config_list
    spLevelUserList = aiUserList
end

-- 获取机器人用户信息
function CMD.getAiInfo(session, coin, gameid, deskid)
    --重排
    rearrange(100)

    local aiPlayerInfo = {}
    local aiCount = 0
    local cond = true
    for _, aIconName in pairs(aiUserList) do
        --还在此游戏的冷却时间内
        -- local cond = true
        -- if nil == deskid then
        --     cond = (nil==aIconName.lastgameid or nil==aIconName.cooltime or aIconName.lastgameid ~= gameid or time >= aIconName.cooltime)
        -- else
        --     cond = (nil==aIconName.lastgameid or nil==aIconName.cooltime or aIconName.lastgameid ~= gameid or (aIconName.lastgameid == gameid and deskid~=aIconName.deskid) or time >= aIconName.cooltime)
        -- end
        -- if not aIconName.curstate and cond then
            aIconName.curstate = true
            aiPlayerInfo.usericon = aIconName.usericon
            aiPlayerInfo.playername = aIconName.playername
            aiPlayerInfo.memo = aIconName.memo
            aiPlayerInfo.state = -1
            aiPlayerInfo.coin = coin
            aiPlayerInfo.integral = aIconName.integral or 0
            aiPlayerInfo.sex = aIconName.sex
            aiPlayerInfo.uid = aIconName.uid
            aiPlayerInfo.gameid = gameid

            --机器人初始携带的金币
            aIconName.gameid = gameid
            aIconName.coin   = coin
            break
        -- end
        aiCount = aiCount + 1
    end

    if table.empty(aiPlayerInfo) then
        LOG_DEBUG(os.date("%Y-%m-%d %H:%M:%S", os.time()),"--结束获取机器人-aiCount:",aiCount, gameid, " 没有获取到机器人")
    else
        LOG_DEBUG(gameid, "获取到一个机器人:",aiPlayerInfo.playername)
    end
    return aiPlayerInfo
end


-- 百人牛牛获取机器人用户信息
function CMD.getAiInfoForNiuNiu(gameid)
	local aiPlayerInfo = {}
    local time = os.time()

    if math.random(10000) < 5000 then
        local size = table.size(aiUserList)
        for i = 1, size do
            local ranOne = math.random(1, size+1-i)
            aiUserList[ranOne], aiUserList[size+1-i] = aiUserList[size+1-i],aiUserList[ranOne]
        end
    end

	for _, aIconName in pairs(aiUserList) do
        if not aIconName.curstate  and (nil==aIconName.lastgameid or nil==aIconName.cooltime or aIconName.lastgameid ~= gameid or time >= aIconName.cooltime) then
            aIconName.curstate = true
            aiPlayerInfo.usericon = aIconName.usericon
            -- if APP == 2 then
            --     aiPlayerInfo.playername = "wx" .. aIconName.uid
            -- else
                aiPlayerInfo.playername = aIconName.playername
            -- end

            aiPlayerInfo.memo = aIconName.memo
            aiPlayerInfo.state = -1
            aiPlayerInfo.integral = aIconName.integral or 0
            aiPlayerInfo.sex = aIconName.sex
            aiPlayerInfo.uid = aIconName.uid

            --机器人初始携带的金币
            aIconName.gameid = gameid
            break
        end
	end

	return aiPlayerInfo
end


-- 回收机器人
-- playername: 机器人昵称,
-- gameid: 上一把游戏id,
-- cooltime 上一把游戏冷却截止时间
-- deskid 上一把游戏的桌子id
function CMD.recycleAi(uid, coin, cooltime, deskid)
	iid = iid - 1
	for _, aiUser in pairs(aiUserList) do
		if aiUser.uid == uid and aiUser.curstate then
			aiUser.curstate = nil
            if nil ~= coin then
                pcall(cluster.call, "master", ".gamemgr", "setValue", aiUser.gameid, 'robotcoin', coin, 1)
            end
            aiUser.lastgameid = aiUser.gameid
            if nil ~= cooltime then
                aiUser.cooltime = cooltime
            end

            if nil ~= deskid then
                aiUser.deskid = deskid
            end
            aiUser.coin = 0
			break
		end
	end
end

---------------------- robot ------------------------------
local games = 
    {
        [PDEFINE.GAME_TYPE.POKER_SSS] = 
        {
            ["ai"] = {
               ["ROBOT_BANCH"] = {3,  4,  5, 2,  6},   --携带不同倍数的金币 
               ["ROBOT_NUM"]   = {20, 20, 10, 20, 10},   --携带不同倍数金币的机器人数
               ["ROBOT_CURNUM"]= {0, 0, 0, 0, 0},      --现有机器人数
               ["ROBOT_TOP"]   = {100,  50,  30, 20,  5},    --携带金币的上限, 够了就退出
               ["ROBOT_LOWER"] = {2, 10, 5, 3, 8},           --低于(携带金币/N)此值 下把退出
               ["ROBOT_BETPLACE_RATE"] = {45, 45, 5},  --押注不同方位的几率
               ["ROBOT_SEATDOWN_RATE"] = {60, 70, 50, 60, 70},  --坐下概率
               ["ROBOT_BETINDEX_RATE"] = {{40, 34, 20, 5, 1},{44, 30, 20, 5, 1},{40, 32, 20, 5, 3},{40, 32, 20, 5, 3},{40, 32, 20, 5, 3}}, --每个档位押注，选不同筹码押注的几率
               ["ROBOT_LEFT"]      = {{10, 10}, {5, 20}, {20, 40},{15, 20}, {30, 10}}, --离开局数(连续打多少局)及概率
               ["ROBOT_COOL_TIME"] = {{10, 60, 10}, {10, 30, 20}, {10,40, 40},{10, 50 ,20 },{10, 20, 10}}, --机器人冷却最小时间-最长时间, 概率
               ["ROBOT_SSID"] = {{80000,400000},{80000,400000},{360000,600000}},   --携带不同倍数的金币
           }
        },
        [PDEFINE.GAME_TYPE.POKER_LM] = 
        {
           ["ai"] = {
               ["ROBOT_BANCH"] = {3,  4,  5, 2,  6},   --携带不同倍数的金币 
               ["ROBOT_NUM"]   = {20, 20, 10, 20, 10},   --携带不同倍数金币的机器人数
               ["ROBOT_CURNUM"]= {0, 0, 0, 0, 0},      --现有机器人数
               ["ROBOT_TOP"]   = {100,  50,  30, 20,  5},    --携带金币的上限, 够了就退出
               ["ROBOT_LOWER"] = {2, 10, 5, 3, 8},           --低于(携带金币/N)此值 下把退出
               ["ROBOT_BETPLACE_RATE"] = {45, 45, 5},  --押注不同方位的几率
               ["ROBOT_SEATDOWN_RATE"] = {60, 70, 50, 60, 70},  --坐下概率
               ["ROBOT_BETINDEX_RATE"] = {{40, 34, 20, 5, 1},{44, 30, 20, 5, 1},{40, 32, 20, 5, 3},{40, 32, 20, 5, 3},{40, 32, 20, 5, 3}}, --每个档位押注，选不同筹码押注的几率
               ["ROBOT_LEFT"]      = {{10, 10}, {5, 20}, {20, 40},{15, 20}, {30, 10}}, --离开局数(连续打多少局)及概率
               ["ROBOT_COOL_TIME"] = {{10, 60, 10}, {10, 30, 20}, {10,40, 40},{10, 50 ,20 },{10, 20, 10}}, --机器人冷却最小时间-最长时间, 概率
               ["ROBOT_SSID"] = {{400,40000},{400,40000},{40000,100000}},   --携带不同倍数的金币
            }
        },
        [PDEFINE.GAME_TYPE.POKER_BENZ] = 
        {
           ["ai"] = {
               ["ROBOT_BANCH"] = {3,  4,  5, 2,  6},   --携带不同倍数的金币 
               ["ROBOT_NUM"]   = {20, 20, 10, 20, 10},   --携带不同倍数金币的机器人数
               ["ROBOT_CURNUM"]= {0, 0, 0, 0, 0},      --现有机器人数
               ["ROBOT_TOP"]   = {100,  50,  30, 20,  5},    --携带金币的上限, 够了就退出
               ["ROBOT_LOWER"] = {2, 10, 5, 3, 8},           --低于(携带金币/N)此值 下把退出
               ["ROBOT_BETPLACE_RATE"] = {45, 45, 5},  --押注不同方位的几率
               ["ROBOT_SEATDOWN_RATE"] = {60, 70, 50, 60, 70},  --坐下概率
               ["ROBOT_BETINDEX_RATE"] = {{40, 34, 20, 5, 1},{44, 30, 20, 5, 1},{40, 32, 20, 5, 3},{40, 32, 20, 5, 3},{40, 32, 20, 5, 3}}, --每个档位押注，选不同筹码押注的几率
               ["ROBOT_LEFT"]      = {{10, 10}, {5, 20}, {20, 40},{15, 20}, {30, 10}}, --离开局数(连续打多少局)及概率
               ["ROBOT_COOL_TIME"] = {{10, 60, 10}, {10, 30, 20}, {10,40, 40},{10, 50 ,20 },{10, 20, 10}}, --机器人冷却最小时间-最长时间, 概率
               ["ROBOT_SSID"] = {{400,40000},{400,40000},{40000,100000}},   --携带不同倍数的金币
           }
        },
    }
    
--排花AI加入
function CMD.addSssAIusers(ssid,coin,unum,gameName,agent)
    local gameid = PDEFINE.GAME_TYPE.POKER_SSS
    local num = 6/2 - unum + 2 --一半人数时可加入 筹够一半人数的机器人
    local aiusers = {}
    if num > 0 then
        local aicount = 0
        if unum == 0 then
            aicount = math.random(2,4)
        else
            aicount = math.random(num)
        end
        
        for i = 1 ,aicount do
            --先随机加，不行就依批次加
            local batch = math.random(#games[gameid]["ai"].ROBOT_BANCH)
            aiusers = {}
            aiusers.batch = batch
            coin = math.random(coin,coin*2)
            aiusers.coin = coin--math.random(games[gameid]["ai"].ROBOT_SSID[ssid][1],games[gameid]["ai"].ROBOT_SSID[ssid][2])
            aiusers.top = games[gameid]["ai"].ROBOT_TOP[batch] * coin    
            aiusers.lower = math.floor(coin/games[gameid]["ai"].ROBOT_LOWER[batch]) --下限
            aiusers.continuenum = games[gameid]["ai"].ROBOT_LEFT[batch][1]
            aiusers.leftrate = games[gameid]["ai"].ROBOT_LEFT[batch][2]
            aiusers.cooltime = games[gameid]["ai"].ROBOT_COOL_TIME[batch]
            aiusers.seatdrate =  games[gameid]["ai"].ROBOT_SEATDOWN_RATE[batch]
            pcall(cluster.call, gameName, agent, "aiJoin", aiusers)
        --[[else
            for idx, value in pairs(ROBOT_BANCH) do
                if idx ~= batch and ROBOT_CURNUM[batch] < ROBOT_NUM[batch] then
                    local maxcoin = ROBOT_BANCH[batch] * basecoin       --允许携带的最大金币
                    local coin = math.random(deskInfo.mincoin, maxcoin) --携带金币
                    local top     = ROBOT_TOP[batch] * coin             --上限
                    local lower   = math.floor(coin/ROBOT_LOWER[batch]) --下限
                    local rate    = ROBOT_LEFT[batch]
                    local cooltime    = ROBOT_COOL_TIME[batch]
                    aiJoin(batch, coin, top, lower, ROBOT_BETINDEX_RATE[batch], math.random(1, rate[1]), rate[2], cooltime)
                end
            end]]
        end
    end
end

--马来AI加入
function CMD.addMlAIusers(ssid,coin,unum,gameName,agent)
    local gameid = PDEFINE.GAME_TYPE.POKER_LM
    local num = 3 - unum  --一半人数时可加入 筹够一半人数的机器人

    local ok, config = pcall(cluster.call, "master", ".configmgr", "get", "mlrobot")
    if ok and config~=nil then
        if math.floor(config.v) == 1 then --配置为1，最多加1个机器人
            if num >=2 then
                num = num - 1
            end
        end
        if math.floor(config.v) == 2 then --配置为2，不加机器人
            num = 0
        end
    end
    local aiusers = {}
    if num > 0 then
        local aicount = math.random(num)
        for i = 1 ,aicount do
            --先随机加，不行就依批次加
            local batch = math.random(#games[gameid]["ai"].ROBOT_BANCH)
            aiusers = {}
            aiusers.batch = batch
            coin = math.random(coin,coin*2)
            aiusers.coin = coin--math.random(games[gameid]["ai"].ROBOT_SSID[ssid][1],games[gameid]["ai"].ROBOT_SSID[ssid][2])
            aiusers.top = games[gameid]["ai"].ROBOT_TOP[batch] * coin    
            aiusers.lower = math.floor(coin/games[gameid]["ai"].ROBOT_LOWER[batch]) --下限
            aiusers.continuenum = games[gameid]["ai"].ROBOT_LEFT[batch][1]
            aiusers.leftrate = games[gameid]["ai"].ROBOT_LEFT[batch][2]
            aiusers.cooltime = games[gameid]["ai"].ROBOT_COOL_TIME[batch]
            aiusers.seatdrate =  games[gameid]["ai"].ROBOT_SEATDOWN_RATE[batch]
            
            pcall(cluster.call, gameName, agent, "aiJoin", aiusers)
        --[[else
            for idx, value in pairs(ROBOT_BANCH) do
                if idx ~= batch and ROBOT_CURNUM[batch] < ROBOT_NUM[batch] then
                    local maxcoin = ROBOT_BANCH[batch] * basecoin       --允许携带的最大金币
                    local coin = math.random(deskInfo.mincoin, maxcoin) --携带金币
                    local top     = ROBOT_TOP[batch] * coin             --上限
                    local lower   = math.floor(coin/ROBOT_LOWER[batch]) --下限
                    local rate    = ROBOT_LEFT[batch]
                    local cooltime    = ROBOT_COOL_TIME[batch]
                    aiJoin(batch, coin, top, lower, ROBOT_BETINDEX_RATE[batch], math.random(1, rate[1]), rate[2], cooltime)
                end
            end]]
        end
    end
end

function CMD.loadAiConfig(gameid)
    local ok, row = pcall(cluster.call, "master", ".gamemgr", "getRow", gameid)
    if row.robot ~= nil and row.robot~="" then
       local robot = cjson.decode(row.robot)
       local tmp = {
           ROBOT_BANCH = robot.ROBOT_BANCH,   --携带不同倍数的金币 
           ROBOT_NUM   = robot.ROBOT_NUM,   --携带不同倍数金币的机器人数
           ROBOT_CURNUM= robot.ROBOT_CURNUM,      --现有机器人数
           ROBOT_TOP   = robot.ROBOT_TOP,    --携带金币的上限, 够了就退出
           ROBOT_LOWER = robot.ROBOT_LOWER,           --低于(携带金币/N)此值 下把退出
           ROBOT_BETPLACE_RATE = robot.ROBOT_BETPLACE_RATE,  --押注不同方位的几率
           ROBOT_SEATDOWN_RATE = robot.ROBOT_SEATDOWN_RATE,  --坐下概率
           ROBOT_BETINDEX_RATE = robot.ROBOT_BETINDEX_RATE,
           ROBOT_LEFT      = robot.ROBOT_LEFT, --离开局数(连续打多少局)及概率
           ROBOT_COOL_TIME = robot.ROBOT_COOL_TIME, --机器人冷却最小时间-最长时间, 概率
           ROBOT_SSID = robot.ROBOT_SSID,   --携带不同倍数的金币
       }
       games[gameid]["ai"] = tmp
    end
    if row.control ~= nil and row.control~="" then
        local control = cjson.decode(row.control)
        local tmp = {
            CONTROL_SYS_STORAGE = control.SYS_STORAGE,                --库存
            CONTROL_SYS_COIN_WAVE = control.SYS_COIN_WAVE,            --取存钱 低于1/2取钱， 多余5倍存钱
            CONTROL_SYS_RATE_WIN = control.SYS_RATE_WIN,              --赢的几率 ，库存不够的增加步长，上限
            CONTROL_SYS_RATE_LOSE = control.SYS_RATE_LOSE,            --输的几率
            CONTROL_SYS_RATE_CONTINUE = control.SYS_RATE_CONTINUE,    --连赢或连输控牌几率,步长,上限
            CONTROL_SYS_CONTINUE_TIMES = control.SYS_CONTINUE_TIMES,  --连赢或输的次数(上限或下限)
        }
        games[gameid]["sys"] = tmp
    end
end

-------- 拉米更新机器人的人气值 --------
function CMD.addRenqi(uid, num)
    if num < 0 or num ==nil then
        return
    end
    for _, robot in pairs(aiUserList) do
        if robot.uid == uid then
            robot.integral = robot.integral + num
            break
        end
    end

    local sql = string.format("update d_robot set integral=integral+ %d where uid=%d", num, uid)
    skynet.call(".dbsync", "lua", "sync", sql)
end

function CMD.getAiBehaviour(gameid,mode)
    if mode == "ai" then
       if games[gameid]["ai"] then
            return games[gameid]["ai"]
       end
    elseif mode == "sys" then
        if games[gameid]["sys"] then
            return games[gameid]["sys"]
       end
    else
        return games[gameid]
    end
    return nil
end

-- 获取N个机器人用户信息
function CMD.getAiListByNum(num)
    --重排
    rearrange(100)

    local userList = {}
    local aiCount = 0
    for _, aIconName in pairs(aiUserList) do
        local aiPlayerInfo = {}
        aIconName.curstate = true
        aiPlayerInfo.usericon = aIconName.usericon
        aiPlayerInfo.playername = aIconName.playername
        aiPlayerInfo.sex = aIconName.sex
        aiPlayerInfo.uid = aIconName.uid
        table.insert(userList, aiPlayerInfo)
        aiCount = aiCount + 1
        if aiCount > num then
            break
        end
    end
    return userList
end

-- 根据机器人UID，返回机器人信息w
function CMD.getAiInfoByUid(tbl)
    local ret = {}
    for _, uid in ipairs(tbl) do
        ret[uid] = {}
    end
    for _, user in pairs(aiUserList) do
        if ret[user.uid] then
            ret[user.uid] = {
                ["usericon"] = user.usericon,
                ["playername"] = user.playername,
                ["level"] = user.level,
            }
        end
    end
    -- for _, user in pairs(spLevelUserList) do
    --     if ret[user.uid] then
    --         ret[user.uid] = {
    --             ["usericon"] = user.img,
    --             ["playername"] = user.nickname,
    --             ["level"] = user.level,
    --         }
    --     end
    -- end
    return ret
end

-- 根据等级分配第一天的排行榜
function CMD.allocAiByLevel(num)
    local ret = {}
    local aiLen = #spLevelUserList
    local randIdxs = genRandIdxs(aiLen, num)
    for _, idx in ipairs(randIdxs) do
        local aiUser = spLevelUserList[idx]
        local aiPlayerInfo = {}
        aiPlayerInfo.usericon = aiUser.usericon
        aiPlayerInfo.playername = aiUser.playername
        aiPlayerInfo.sex = aiUser.sex
        aiPlayerInfo.uid = aiUser.uid
        table.insert(ret, aiPlayerInfo)
    end
    return ret
end

-- 每天增加一定等级
-- 查找出最近7天登录玩家平均等级，上下浮动30%，计算出每个机器人的随机等级
-- 只能向上调整，不能向下调整
-- 2:4:2的分布进行等级调整
local function changeAiLevelExp()
    LOG_DEBUG("changeAiLevelExp")
    local maxMinLevelSql = string.format([[
        select max(level) as maxLevel,min(level) as minLevel
        from d_user where login_time>'%s' and isrobot is null or isrobot<>1
    ]], os.date("%Y-%m-%d", os.time() - 7 * 24 * 3600))
    local result = skynet.call(".mysqlpool", "lua", "execute", maxMinLevelSql)
    if not result or #result == 0 then
        LOG_DEBUG("changeAiLevelExp: no maxMinLevel")
        return
    end
    local maxLevel = result[1].maxLevel
    local minLevel = result[1].minLevel
    LOG_DEBUG(string.format("changeAiLevelExp: maxLevel:%d, minLevel:%d", maxLevel, minLevel))
    local recentUserSql = string.format([[
        select avg(level) as avgLevel from d_user
        where login_time > '%s'
        and (isrobot is null or isrobot<>1)
        and level <> %d
        and level <> %d
    ]], os.date("%Y-%m-%d", os.time() - 7 * 24 * 3600), minLevel, maxLevel)
    local result = skynet.call(".mysqlpool", "lua", "execute", recentUserSql)
    if not result or #result == 0 then
        LOG_DEBUG("changeAiLevelExp: no average level")
        return
    end
    local avgLevel = result[1].avgLevel
    if not avgLevel then
        LOG_DEBUG("changeAiLevelExp: no avgLevel")
        return
    end
    avgLevel = math.floor(avgLevel*1.5)
    -- 已有机器人按照等级排序
    table.sort(aiUserList, function(a, b)
        return a.level < b.level
    end)
    -- 前面25%的机器人等级调整为avgLevel - 30% --> avgLevel - 10% 
    -- 中间50%的机器人等级调整为avgLevel - 10% --> avgLevel + 10%
    -- 后面25%的机器人等级调整为avgLevel + 10% --> avgLevel + 30%
    local range1,range2,range3,range4 = avgLevel-math.floor(avgLevel*0.3),avgLevel-math.floor(avgLevel*0.1),avgLevel+math.floor(avgLevel*0.1),avgLevel+math.floor(avgLevel*0.3)
    LOG_DEBUG(string.format("changeAiLevelExp: range1:%d, range2:%d, range3:%d, range4:%d", range1, range2, range3, range4))
    -- 求出平均等级之后，调整机器人的等级
    local aiLen = #aiUserList
    for idx, robot in ipairs(aiUserList) do
        local randLevel
        if idx <= math.floor(aiLen*0.25) then
            randLevel = math.random(range1,range2)
        elseif idx <= math.floor(aiLen*0.75) then
            randLevel = math.random(range2,range3)
        else
            randLevel = math.random(range3,range4)
        end
        if robot.level < randLevel then
            robot.level = randLevel
            do_redis({"hset", "d_user:" .. robot.uid, "level", randLevel})
            local sql = string.format([[
                update d_user set level=%d where uid=%d
            ]], randLevel, robot.uid)
            skynet.call(".mysqlpool", "lua", "execute", sql)
        end
    end
    LOG_DEBUG("changeAiLevelExp: change ai level complete")
end

function CMD.start()
    loadData()
    autoChangeRobotLevel = function ()
        changeAiLevelExp()
        skynet.timeout(24 * 3600 * 100, function ()
            if autoChangeRobotLevel then
                autoChangeRobotLevel()
            end
        end)
    end
    -- 算出凌晨时间
    local now = os.time()
    local delayTime = date.GetTodayZeroTime() + 24*60*60 - now
    skynet.timeout(delayTime * 100, autoChangeRobotLevel)
end

skynet.start(function()
	skynet.dispatch("lua", function(session, address, cmd, ...)
		local f = CMD[cmd]
		skynet.retpack(f(...))
	end)
	skynet.register(".aiuser")
end)
