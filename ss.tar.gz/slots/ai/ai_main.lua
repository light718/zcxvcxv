local skynet = require "skynet"
local cluster = require "cluster"

local config = {
}

local user = {
}

local common = {
	{ name = "d_robot", key = "id"},
    { name = "s_game", key = "id"},
}

skynet.start(function()
    
	LOG_INFO("Server start")

	local emmylua_port = skynet.getenv("emmylua_port")
    if emmylua_port then
        local dbg = require("emmy_core")
		local ret = dbg.tcpListen("localhost", emmylua_port)
		print("dbg.tcpListen", emmylua_port, ret)
		-- dbg.waitIDE()
		-- dbg.breakHere()
    end

	local debug_port = skynet.getenv("debug_port")
    if debug_port then 
        skynet.newservice("debug_console",debug_port)
    end
    
	local log = skynet.uniqueservice("log")
	skynet.call(log, "lua", "start")
	
	local name = skynet.getenv("mastername") or "ai"
	cluster.open(name)
    
    local dbmgr = skynet.uniqueservice("dbmgr")
    skynet.call(dbmgr, "lua", "start", config, user, common)

	local ai = skynet.uniqueservice("aiuser")
	skynet.call(ai, "lua", "start")
    
    --TODO 修复数据
	local mysqlpool = skynet.uniqueservice("mysqlpool")
	skynet.call(mysqlpool, "lua", "start")

	-- 根据redis中给定的游戏id，来判断初始化哪个游戏
    local current_game = do_redis({"hget", PDEFINE.REDISKEY.SUBGAME.INFO, "currGame"})
    if not current_game then
        current_game = PDEFINE.SUBGAME_TYPE.BINGO
    end
    pcall(cluster.call, "master", ".pvpmgr", "initAiPlayerInfo")
    if tonumber(current_game) == PDEFINE.SUBGAME_TYPE.BINGO then
        -- 初始化 bingo 游戏相关
        pcall(cluster.call, "master", ".bingomgr", "initAiPlayerInfo")
    elseif tonumber(current_game) == PDEFINE.SUBGAME_TYPE.JOURNEY then
        -- 初始化 journey 游戏相关
    end
	
	skynet.exit()
end)
