local skynet = require "skynet"
local cluster = require "cluster"

local APP = skynet.getenv("app") or 1
APP = tonumber(APP)

local common = {
}

local user = {
    { name = "d_clubs", key = "id" },
}

-- 初始化俱乐部ID,从6位开始
local function initClubID()
    local club_id = do_redis({'get', PDEFINE.CACHE_LOG_KEY.club_id})
    if not club_id then
        do_redis({"set", PDEFINE.CACHE_LOG_KEY.club_id, 100000})
    end
end

skynet.start(function()
	local nodename  = skynet.getenv("nodename")
    assert(nodename)

	local debug_port = skynet.getenv("debug_port")
    if debug_port then
        skynet.newservice("debug_console",debug_port)
    end

	local log = skynet.uniqueservice("log")
	skynet.call(log, "lua", "start")
	cluster.open(nodename)

	local dbmgr = skynet.uniqueservice("dbmgr")
    skynet.call(dbmgr, "lua", "start", {}, user, common)

	--数据同步
	local dbsync = skynet.uniqueservice("dbsync")
	skynet.call(dbsync, "lua", "start")

    local clubmgr = skynet.uniqueservice("clubmgr")
    skynet.call(clubmgr, "lua", "start")

	skynet.uniqueservice("servernode", "true")
    local info={
        servername=nodename,
        tag="club",
    }
    skynet.call(".servernode", "lua", "setMyInfo", info)
    initClubID()
	skynet.exit()
end)
