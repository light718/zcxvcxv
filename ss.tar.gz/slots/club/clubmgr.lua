local skynet = require "skynet"
require "skynet.manager"
local cluster = require "cluster"
local snax = require "snax"
local player_tool = require "base.player_tool"
local table_tool = require "table_tool"
local cjson   = require "cjson"
local PAGE_SIZE = 10
local defaultLevel = 1
local defaultPlayerName = "Guest"
local defaultUserIcon = "https://jp.inter.rummyslot.com/head/img99.jpg"
local USER_REDIS_KEY = "d_user:"
local CLUB_MAX_CNT = 20

-- 俱乐部管理
local CLUB_LIST = {} --俱乐部列表
local CLUB_NAME = {} --俱乐部名字对应的ID，俱乐部名字排重用
local USERS_CLUB = {} --用户uid和俱乐部id的对应关系
local obj = {}
local CMD = {}

local function addRewards(rewards, id, num)
    for _, reward in ipairs(rewards) do
        if reward.id == id then
            reward.num = reward.num + num
            return
        end
    end
    table.insert(rewards, {id = id, num = num})
end

local function newClubData(joinTime)
    return {
        joinTime=joinTime,
        rewardids={},
        tasktimestamp=0,
        taskids={},
    }
end

-- 获取俱乐部成员的金币数
function obj.getClubScore(club_id)
    local sql = string.format("select * from d_clubs_members where club_id = %d ", club_id)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    local score = 0 --俱乐部成员所有分数
    if #rs > 0 then
        local tmp_club_mems = {}
        for _, row in pairs(rs) do
            table.insert(tmp_club_mems, row.uid)
            USERS_CLUB[row.uid] = club_id
        end

        local sql2 = string.format("select sum(coin) as t from d_user where uid in (" .. table.concat(tmp_club_mems, ',')..")")
        local rs2 = skynet.call(".mysqlpool", "lua", "execute", sql2)
        score = rs2[1].t
    end
    return score
end

function obj.load()
    local sql = string.format("select * from d_clubs")
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        local tmp_data_list = {}
        local tmp_name_list = {}
        for _, row in pairs(rs) do
            if tmp_data_list[row.club_id] == nil then
                tmp_data_list[row.club_id] = {}
            end
            row.score = obj.getClubScore(row.club_id)
            tmp_data_list[row.club_id] = row
            tmp_name_list[row.name] = row.club_id
        end
        CLUB_LIST = tmp_data_list
        CLUB_NAME = tmp_name_list
    end
end

-- 生产俱乐部id
local function genClubID()
    local club_id = do_redis({'incr', PDEFINE.CACHE_LOG_KEY.club_id})
    return club_id
end

--! 可申请的俱乐部列表
-- 找到用户未申请过的俱乐部列表即可
function CMD.canApplyList(recvobj)
    local uid  = math.floor(recvobj.uid)
    local sql = string.format("select * from d_clubs where club_id not in (select club_id from d_clubs_apply where uid=%d and stype=2) limit %d", uid, PAGE_SIZE)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    local datalist = {}
    if #rs > 0 then
        for _, row in pairs(rs) do
            local tmp  = {
                ["ID"] = row.club_id,
                ["Name"] = row.name,
                ["Avatar"] = row.avatar,
                ["Num"] = row.curcnt,
                ["MaxNum"] = row.maxcnt,
                ["Score"] = row.score
            }
            table.insert(datalist, tmp)
        end
    end

    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = {Items = datalist, UserID = uid}}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部邀请列表
function CMD.invitelist(recvobj)
    local uid = math.floor(recvobj.uid)

    local clubID = USERS_CLUB[uid]
    if nil ~= clubID then
        LOG_DEBUG("club user already join ", clubID, " uid:", uid)
        return PDEFINE.RET.ERROR.USER_IN_OTHER_CLUB
    end

    local sql = string.format("select * from d_clubs_apply where uid=%d and stype = 1 order by create_time desc", uid)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    local res = {UserID = uid, Items = {}}
    if #rs > 0 then
        for _, row in pairs(rs) do
            local club = CLUB_LIST[row.club_id]
            local result = do_redis({"hgetall", USER_REDIS_KEY .. club.owner_id})
            local member = make_pairs_table(result)

            local tmp  = {
                ["Club"] = {
                    ID = club.club_id,
                    OwnerID = club.owner_id,
                    Name = club.name,
                    Avatar = club.avatar,
                    Num = club.curcnt,
                    MaxNum = club.maxcnt,
                },
                ["Owner"] = {
					ID  = member.uid,
					Name = member.playername,
					Avatar = member.usericon,
					Level  = member.level,
					Score  = member.coin,
					JoinTime = club.create_time,
                },
                InviteTime = row.create_time
            }
            table.insert(res["Items"], tmp)
        end
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = res}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部邀请 邀请加入俱乐部
function CMD.invite(recvobj)
    local uid       = math.floor(recvobj.uid)
    local inviteUID = math.floor(recvobj.inviteUID)

    local playerInfo = player_tool.getPlayerInfo(inviteUID)
    if not playerInfo.uid then
        return PDEFINE.RET.ERROR.PLAYER_NOT_FOUND
    end

    local userClub = USERS_CLUB[inviteUID]
    if userClub ~= nil then
        return PDEFINE.RET.ERROR.USER_IN_OTHER_CLUB
    end
    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND --无俱乐部信息
    end
    local clubInfo = CLUB_LIST[clubID]
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND --无俱乐部信息
    end
    if clubInfo.owner_id ~= uid then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --不是俱乐部创建人，无权限邀请
    end
    if clubInfo.curcnt >= CLUB_MAX_CNT then
        return PDEFINE.RET.ERROR.CLUB_IS_FULL --俱乐部人数已满
    end
    local now = os.time()
    local insert_sql = string.format("insert into d_clubs_apply(club_id, uid, stype, create_time) value(%d, %d, %d, %d)", clubInfo.club_id, inviteUID, 1, now)
    skynet.call(".mysqlpool", "lua", "execute", insert_sql)

    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, inviteUID = inviteUID}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部列表
function CMD.list(recvobj)
    local uid   = math.floor(recvobj.uid)
    local page  = math.floor(recvobj.page)

    if page < 1 then
        page = 1
    end
    local rpcRes = {
        Page = page,
        Items = {},
        HasNextPage = false,
    }
    local begin = (page - 1) * PAGE_SIZE
    local sql = string.format("select * from d_clubs where club_id not in (select club_id from d_clubs_apply where uid=%d and stype=2) order by score desc limit %d, %d", uid, begin, PAGE_SIZE)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        for rank, row in pairs(rs) do
            local tmp  = {
                ["Name"] = row.name,
                ["Avatar"] = row.avatar,
                ["Num"] = row.curcnt,
                ["ID"] = row.id,
                ["Score"] = row.score,
                ["MaxNum"] = row.maxcnt,
                ["Rank"] = rank
            }
            table.insert(rpcRes.Items, tmp)
        end
    end
    local cntsql = string.format("select count(*) as t from d_clubs")
    local cntrs = skynet.call(".mysqlpool", "lua", "execute", cntsql)
    if #cntrs > 0 then
        if cntrs[1].t > page * PAGE_SIZE then
            rpcRes.HasNextPage = true
        end
    end
    --TODO 要查找自己俱乐部的排名
    local clubID = USERS_CLUB[uid]
    if nil ~= clubID then
        local clubInfo = CLUB_LIST[clubID]
        if nil ~= clubInfo then
            rpcRes.Self = {
                ID = clubInfo.club_id,
                Name = clubInfo.name,
                Avatar = clubInfo.usericon,
                Num = clubInfo.curcnt,
                MaxNum = clubInfo.maxcnt,
                Score = clubInfo.score,
                Rank = 0, --自己俱乐部的排名, 按分数排名占比，如排第25位，再除以总俱乐部数
            }
        end
    end

    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = rpcRes}
    return PDEFINE.RET.SUCCESS, retobj
end

-- 内部调用获取用户的俱乐部信息(世界聊天频道展示用)
function CMD.getInfo(uid)
    local club_id = USERS_CLUB[uid]
    if nil == club_id then
        return
    end
    local clubInfo = CLUB_LIST[club_id]
    return clubInfo
end

--! 俱乐部信息
function CMD.info(recvobj)
    local uid  = math.floor(recvobj.uid)

    local clubID = USERS_CLUB[uid]
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, hasInvite = false}
    if nil ~= clubID then
        local resData = {}
        local joinTime = 0
        local sql = string.format("select * from d_clubs_members where club_id =%d and uid = %d ", clubID, uid)
        local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
        if #rs > 0 then
            if nil == clubID then
                clubID = rs[1].club_id
            end
            joinTime = rs[1].create_time
        end

        local clubInfo = CLUB_LIST[clubID]
        if clubInfo.owner_id == uid then
            local applySql = string.format("select count(*) as t from d_clubs_apply where club_id = %d and type=2", clubID)
            local applyResult = skynet.call(".mysqlpool", "lua", "execute", applySql)
            if #applyResult > 0 then
                resData["HasApply"] = applyResult[1].t > 0
            end
        else
            local inviteSql = string.format("select count(*) as t from d_clubs_apply where club_id = %d and type=1", clubID)
            local inviteResult = skynet.call(".mysqlpool", "lua", "execute", inviteSql)
            if #inviteResult > 0 then
                retobj.hasInvite = inviteResult[1].t > 0
            end
        end
        resData["Club"] = {
            ID = clubID,
            OwnerID = clubInfo.owner_id,
            Name = clubInfo.name,
            Avatar = clubInfo.avatar,
            Num = clubInfo.curcnt,
            MaxNum = clubInfo.maxcnt
        }
        local playerInfo = player_tool.getPlayerInfo(uid)
        resData["Member"] = {
            ID = uid,
            Name = playerInfo.playername,
            Avatar = playerInfo.usericon,
            Level = playerInfo.level,
            Score = playerInfo.coin,
            JoinTime = joinTime
        }
        retobj.data = resData
    end
    return PDEFINE.RET.SUCCESS, retobj
end

--! 搜索俱乐部
function CMD.search(recvobj)
    local clubID  = math.floor(recvobj.clubID)
    
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS}
    if nil ~= clubID then
        local resData = {}
        local clubInfo = CLUB_LIST[clubID]
        resData["Club"] = {
            ID = clubID,
            OwnerID = clubInfo.owner_id,
            Name = clubInfo.name,
            Avatar = clubInfo.avatar,
            Num = clubInfo.curcnt,
            MaxNum = clubInfo.maxcnt
        }
        retobj.data = resData
    end
    return PDEFINE.RET.SUCCESS, retobj
end

--! 创建俱乐部
--[[
    创建俱乐部(俱乐部id和名称不重复)
    创建成功后从申请列表和邀请列表中移除
]]
function CMD.create(recvobj)
    local uid       = math.floor(recvobj.uid)
    local clubName  = recvobj.clubName
    local clubAvatar= recvobj.clubAvatar
    local autoFalg  = recvobj.autoadd

    if nil ~= CLUB_NAME[clubName] then
        return PDEFINE.RET.ERROR.CLUB_NAME_NOT_EMPTY --俱乐部名字被占用
    end
    local clubInfo = USERS_CLUB[uid]
    if clubInfo ~= nil then
        return PDEFINE.RET.ERROR.USER_IN_OTHER_CLUB --用户已经有俱乐部了
    end
    local autoAdd = 0
    if autoFalg then
        autoAdd = 1
    end
    local playerInfo = player_tool.getPlayerInfo(uid)
    local now = os.time()
    local club_id = genClubID()
    USERS_CLUB[uid] = club_id
    CLUB_NAME[clubName] = club_id
    CLUB_LIST[club_id] = {
        club_id = club_id,
        owner_id = uid,
        name = clubName,
        avatar = clubAvatar,
        create_time = now,
        score = playerInfo.coin,
        curcnt = 1,
        maxcnt = CLUB_MAX_CNT,
        autoadd = autoAdd,
    }
    local sql = string.format("insert into d_clubs(club_id, owner_id, name, avatar, create_time, score, curcnt, maxcnt,autoadd) value(%d, %d, '%s', '%s', %d, %d,%d,%d,%d)", club_id, uid, clubName, clubAvatar, now, playerInfo.coin, 1, CLUB_MAX_CNT, autoAdd)
    skynet.call(".mysqlpool", "lua", "execute", sql)

    local insert_sql = string.format("insert into d_clubs_members(club_id, uid, create_time) value(%d, %d, %d)", club_id, uid, now)
    skynet.call(".mysqlpool", "lua", "execute", insert_sql)
    pcall(cluster.call, "master", ".club", "setTaskMemberLevelByClubID", club_id)

    sql = string.format("delete from d_clubs_apply where uid = %d", uid)
    skynet.call(".mysqlpool", "lua", "execute", sql)
    local rpcRes = {
        ID = club_id,
	    OwnerID = uid,
	    Name = clubName,
	    Avatar = clubAvatar,
	    Num = 1,
	    MaxNum = CLUB_MAX_CNT
    }
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = rpcRes}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 回复俱乐部邀请 同意或拒绝(用户回复俱乐部的邀请)
function CMD.inviteReply(recvobj)
    local uid       = math.floor(recvobj.uid)
    local agree     = recvobj.agree  -- true or false
    local clubID    = math.floor(recvobj.clubID)

    if not agree then
        local sql = string.format("delete from d_clubs_apply where uid = %d and stype = 1", uid)  --用户拒绝，把俱乐部邀请的记录删除
        skynet.call(".mysqlpool", "lua", "execute", sql)
    else
        local sql = string.format("select * from d_clubs_apply where uid = %d and club_id = %d and stype = 1", uid, clubID)
        local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
        if #rs == 0 then --俱乐部是否邀请了此用户
            return PDEFINE.RET.ERROR.CLUB_NOT_APPLEY
        end
        local otherClubID = USERS_CLUB[uid]
        if nil ~= otherClubID then
            return PDEFINE.RET.ERROR.USER_IN_OTHER_CLUB -- 用户已经加入其他俱乐部
        end
        --俱乐部id是否存在，人数是否超了
        local clubInfo = CLUB_LIST[clubID]
        if nil == clubInfo or clubInfo.curcnt >= clubInfo.maxcnt then -- 要加入的俱乐部人数是否超限
            return PDEFINE.RET.ERROR.CLUB_IS_FULL
        end
        local playerInfo = player_tool.getPlayerInfo(uid)
        local score = playerInfo.coin or 0
        clubInfo.curcnt = clubInfo.curcnt + 1
        CLUB_LIST[clubID] = clubInfo
        USERS_CLUB[uid] = clubID
        local insert_sql = string.format("insert into d_clubs_members(club_id, uid, create_time) value(%d, %d, %d)", clubID, uid, os.time())
        skynet.call(".mysqlpool", "lua", "execute", insert_sql)
        local update_sql = string.format("update d_clubs set curcnt=curcnt+1,score=score+%d where club_id = %d", score, clubID)
        skynet.call(".mysqlpool", "lua", "execute", update_sql)

        local del_sql = string.format("delete from d_clubs_apply where uid = %d and stype = 1", uid)  --把俱乐部邀请的记录删除
        skynet.call(".mysqlpool", "lua", "execute", del_sql)

        pcall(cluster.call, "master", ".club", "setTaskMemberLevelByClubID", clubID)
    end

    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, agree = agree, clubID = clubID}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部回复
--[[
    uid是不是俱乐部管理员，是不是存在俱乐部
    加入俱乐部会员，清理用户的俱乐部申请记录和邀请记录
]]
function CMD.reply(recvobj)
    local uid       = math.floor(recvobj.uid)
    local agree     = recvobj.agree
    local applyUserIDs  = recvobj.applyUserIDs
    if #applyUserIDs == 0 then
        return PDEFINE.RET.ERROR.BAD_REQUEST --缺少请求的人
    end
    local clubID = USERS_CLUB[uid]
    if nil == clubID then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --用户没有俱乐部
    end
    local clubInfo = CLUB_LIST[clubID]
    if clubInfo.owner_id ~= uid then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --用户不是俱乐部管理员，即他没有俱乐部操作权限
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = {
        UserID = uid,
        Agree =  agree,
        ApplyUserIDs = applyUserIDs
    }}
    retobj.data.ClubID = clubInfo.club_id
    local applyUIDs = {}
    for apply_uid, _ in pairs(applyUserIDs) do
        local tmp = math.floor(apply_uid)
        if tmp > 0 and tmp ~= uid then --过滤非法uid，过滤自己
            table.insert(applyUIDs, tmp)
        end
    end
    if #applyUIDs == 0 then
        return PDEFINE.RET.ERROR.BAD_REQUEST --都过滤掉了
    end
    local applyIDStr = table.concat(applyUIDs, ',')
    if not agree then --拒绝, 已清理了申请记录
        local delSql = string.format("delete from d_clubs_apply where uid in (%s) and stype = 2", applyIDStr)  --把俱乐部申请的记录删除
        skynet.call(".mysqlpool", "lua", "execute", delSql)
        return PDEFINE.RET.SUCCESS, cjson.encode(retobj)
    end

    local clubMemSql = string.format("select club_id, uid from d_clubs_members where club_id=%d and uid in (%s)", clubID, applyIDStr)
    local rs2 = skynet.call(".mysqlpool", "lua", "execute", clubMemSql)
    if #rs2 >= 0 then --过滤已经在俱乐部内的人,只留下未加入俱乐部的uid
         for row in pairs(rs2) do
             for idex, k in pairs(applyUIDs) do
                 if row.uid == k then
                    applyUIDs[idex] = nil
                    break
                 end
             end
         end
    end
    local delSql = string.format("delete from d_clubs_apply where uid in (%s)", applyIDStr)  --把俱乐部申请的记录删除
    skynet.call(".mysqlpool", "lua", "execute", delSql)
    local addScore, addCnt = 0, 0
    local now = os.time()
    for _, userID in pairs(applyUIDs) do
        if userID ~= nil then
            if clubInfo.curcnt < CLUB_MAX_CNT then
                local result = do_redis({"hgetall", USER_REDIS_KEY .. userID})
                local user = make_pairs_table_int(result)

                local insert_sql = string.format("insert into d_clubs_members(club_id, uid, create_time) value(%d, %d, %d)", clubID, userID, now)
                skynet.call(".mysqlpool", "lua", "execute", insert_sql)
                
                addCnt   = addCnt + 1
                addScore = addScore + user.coin
                USERS_CLUB[userID] = clubID
            end
        end
    end
    local update_sql = string.format("update d_clubs set curcnt=curcnt+%d, score=score+%d where club_id=%d", addCnt, addScore, clubID)
    skynet.call(".mysqlpool", "lua", "execute", update_sql)
    clubInfo.score  = clubInfo.score + addScore
    clubInfo.curcnt = clubInfo.curcnt + addCnt
    CLUB_LIST[clubID] = clubInfo

    pcall(cluster.call, "master", ".club", "setTaskMemberLevelByClubID", clubID)
    return PDEFINE.RET.SUCCESS, cjson.encode(retobj)
end

--! 用户退出俱乐部
function CMD.quit(recvobj)
    local uid = math.floor(recvobj.uid)

    local clubID = USERS_CLUB[uid]
    if nil == clubID then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION
    end
    local clubInfo = CLUB_LIST[clubID]
    if nil == clubInfo then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION
    end
    if clubInfo.owner_id == uid then
        return PDEFINE.RET.ERROR.CLUB_OWNER_CANT_QUIT
    end
    local playerInfo = player_tool.getPlayerInfo(uid)
    local sql = string.format("delete from d_clubs_members where uid = %d", uid)
    skynet.call(".mysqlpool", "lua", "execute", sql)

    local update_sql = string.format("update d_clubs set curcnt=curcnt-1, score=score-%d where club_id=%d", playerInfo.coin, clubID)
    skynet.call(".mysqlpool", "lua", "execute", update_sql)
    clubInfo.curcnt = clubInfo.curcnt - 1
    clubInfo.score = clubInfo.score - playerInfo.coin
    CLUB_LIST[clubID] = clubInfo
    USERS_CLUB[uid] = nil

    pcall(cluster.call, "master", ".club", "setTaskMemberLevelByClubID", clubID)
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = { ClubID = clubID, UserID = uid}}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部解散
function CMD.dismiss(recvobj)
    local uid = math.floor(recvobj.uid)

    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND --未找到俱乐部信息
    end
    local clubInfo = CLUB_LIST[clubID]
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    if clubInfo.owner_id ~= uid then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --无权限
    end
    local sql = string.format("delete from d_clubs where club_id = %d", clubID)
    skynet.call(".mysqlpool", "lua", "execute", sql)
    CLUB_LIST[clubID] = nil

    local sql1 = string.format("select * from d_clubs_members where club_id=%d", clubID)
    local rs =  skynet.call(".mysqlpool", "lua", "execute", sql1)
    if #rs > 0 then
        for _, row in pairs(rs) do
            USERS_CLUB[row.uid] = nil
        end
    end
    sql = string.format("delete from d_clubs_members where club_id = %d", clubID)
    skynet.call(".mysqlpool", "lua", "execute", sql)

    sql = string.format("delete from d_clubs_apply where club_id = %d", clubID)
    skynet.call(".mysqlpool", "lua", "execute", sql)

    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = {UserID = uid}}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 修改俱乐部名字图标
function CMD.modify(recvobj)
    local uid       = math.floor(recvobj.uid)
    local clubName  = recvobj.clubName
    local clubAvatar= recvobj.clubAvatar

    if nil ~= CLUB_NAME[clubName] then
        return PDEFINE.RET.ERROR.CLUB_NAME_NOT_EMPTY --俱乐部名称已被占用
    end
    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND --未找到俱乐部信息
    end
    local clubInfo = CLUB_LIST[clubID]
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    if clubInfo.owner_id ~= uid then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --无权限
    end

    CLUB_NAME[clubName] = clubInfo.club_id
    clubInfo.name = clubName
    clubInfo.avatar = clubAvatar
    CLUB_LIST[clubInfo.club_id] = clubInfo
    local sql = string.format("update d_clubs set name='%s', avatar='%s' where club_id=%d", clubName, clubAvatar, clubID)
    skynet.call(".mysqlpool", "lua", "execute", sql)

    local resClubInfo = {
        ID = clubInfo.club_id,
        OwnerID = uid,
        Name = clubName,
        Avatar = clubAvatar,
        Num = clubInfo.curcnt,
        MaxNum = clubInfo.maxcnt,
    }
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = {Club = resClubInfo, UserID = uid}}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部踢人
function CMD.kick(recvobj)
    local uid       = math.floor(recvobj.uid)
    local kickUserIDs   = recvobj.kickUserIDs

    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = {
        UserID = uid,
        KickUserIDs = kickUserIDs,
    }}

    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --未找到俱乐部信息
    end
    local clubInfo = CLUB_LIST[clubID]
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    if clubInfo.owner_id ~= uid then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --无权限
    end

    retobj.data.ClubID = clubInfo.club_id
    local tmpUIDs = {}
    for _, kickUID in pairs(kickUserIDs) do
        if kickUID ~= uid then
            table.insert(tmpUIDs, kickUID)
        end
    end
    if #tmpUIDs > 0 then
        local sql = string.format("delete from d_clubs_members where club_id = %d and uid in (%s) ", clubInfo.club_id, table.concat(tmpUIDs, ','))
        skynet.call(".mysqlpool", "lua", "execute", sql)
       
        local addScore = 0
        for _, userID in pairs(tmpUIDs) do
            local result = do_redis({"hgetall", USER_REDIS_KEY .. userID})
            local user = make_pairs_table_int(result)
            addScore = addScore + user.coin
            USERS_CLUB[userID] = nil 
        end
        sql = string.format("update d_clubs set curcnt=curcnt - %d, score = score - %d where club_id=%d", #tmpUIDs, addScore, clubInfo.club_id)
        skynet.call(".mysqlpool", "lua", "execute", sql)
        clubInfo.score = clubInfo.score - addScore
        clubInfo.curcnt = clubInfo.curcnt - #tmpUIDs
        CLUB_LIST[clubID] = clubInfo
    end

    return PDEFINE.RET.SUCCESS, retobj
end

--! 用户申请单个俱乐部,申请加入俱乐部
function CMD.apply(recvobj)
    local uid       = math.floor(recvobj.uid)
    local clubIDs   = recvobj.clubIDs

    local clubID = USERS_CLUB[uid]
    if clubID ~= nil then
        return PDEFINE.RET.ERROR.USER_IN_OTHER_CLUB --用户已在其他俱乐部中
    end
    if nil ==clubIDs or #clubIDs <= 0 then --快速申请加入俱乐部
        if nil == clubIDs then
            clubIDs = {}
        end
        local clubSql = "select * from d_clubs where curcnt < maxcnt order by autoadd desc,create_time asc limit 1"
        local clubRs = skynet.call(".mysqlpool", "lua", "execute", clubSql)
        if #clubRs > 0 then
            table.insert(clubIDs, clubRs[1].club_id)
        end
    end
    local clubIDStr = table.concat(clubIDs, ',')
    local playerInfo = player_tool.getPlayerInfo(uid)
    local sql = string.format("select * from d_clubs where club_id in (%s)", clubIDStr)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        local now = os.time()
        for _, clubInfo in pairs(rs) do
            if clubInfo.curcnt < clubInfo.maxcnt then
                local insert_sql = string.format("insert into d_clubs_apply(club_id, uid, stype, create_time) value(%d, %d, %d, %d)", clubInfo.club_id, uid, 2, now)
                skynet.call(".mysqlpool", "lua", "execute", insert_sql)
            end
        end
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = {
        ClubIDs = clubIDs,
        Member  = {ID=uid, Name=playerInfo.playername, Avatar=playerInfo.usericon, Level=playerInfo.level,Score=math.floor(playerInfo.coin)}
    }}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部申请列表
function CMD.applyList(recvobj)
    local uid       = math.floor(recvobj.uid)
    local page      = math.floor(recvobj.page)

    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.USER_NOT_IN_CLUB --用户加入俱乐部
    end
    local clubInfo = CLUB_LIST[clubID]
    if nil == clubInfo then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    if clubInfo.owner_id ~= uid then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION --不是管理员，无权限操作
    end

    local rpcRes = { HasNextPage = false, Items = {}}
    local begin = (page - 1) * PAGE_SIZE
    local applySql = string.format("select * from d_clubs_apply where club_id = %d and stype=2 order by create_time desc limit %d, %d", clubID, begin, PAGE_SIZE)
    local applyResult = skynet.call(".mysqlpool", "lua", "execute", applySql)

    for _, row in pairs(applyResult) do
        local result = do_redis({"hgetall", USER_REDIS_KEY .. row.uid})
        local playerInfo = make_pairs_table(result)
        local tmp = {
            ID = row.uid,
            ApplyTime = row.create_time,
            Name = playerInfo.playername,
            Avatar = playerInfo.usericon,
            Level = playerInfo.level
        }
        table.insert(rpcRes.Items, tmp)
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = rpcRes}
    return PDEFINE.RET.SUCCESS, retobj
end

-- 获取俱乐部内成员的加入时间
local function getMemberJoinTime(club_id, uid)
    local joinTime = 0
    local sql = string.format("select * from d_clubs_members where club_id = %d and uid = %d ", club_id, uid)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        joinTime = rs[1].create_time
    end
    return joinTime
end

--！俱乐部任务
function CMD.task(recvobj)
    local uid = math.floor(recvobj.uid)

    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    local clubInfo = CLUB_LIST[clubID]
    LOG_DEBUG("task clubInfo", clubInfo)
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end

    local ok, tasktimestamp, taskItems = pcall(cluster.call, "master", ".club", "getTaskItems", clubID)
    if not ok then
        return PDEFINE.RET.ERROR.CALL_FAIL
    end
    local joinTime = getMemberJoinTime(clubID, uid)
    local items = {}
    if #taskItems > 0 then
        local playerInfo = player_tool.getPlayerInfo(uid)
        local clubdata = nil
        if playerInfo and playerInfo.clubdata and playerInfo.clubdata ~= "" then
            clubdata = cjson.decode(playerInfo.clubdata)
            if clubdata.joinTime ~= joinTime then
                clubdata = nil
            end
            if clubdata and clubdata.tasktimestamp ~= tasktimestamp then
                clubdata.tasktimestamp = tasktimestamp
                clubdata.taskids = {}
            end
        end
        LOG_DEBUG("clubdata", uid, clubdata)
        for _, taskItem in pairs(taskItems) do
            local state = PDEFINE.TASK_STATE.ACTIVE
            if taskItem.complete then
                if taskItem.completeTime < joinTime then
                    state = PDEFINE.TASK_STATE.NONE
                elseif clubdata and clubdata.taskids and table_tool.find(clubdata.taskids, function(ele)
                    if ele < taskItem.id then
                        return -1
                    elseif ele > taskItem.id then
                        return 1
                    else
                        return 0
                    end
                end) then
                    state = PDEFINE.TASK_STATE.FINISH
                else
                    state = PDEFINE.TASK_STATE.COMPLETE
                end
            end
            local item = {
                id = taskItem.id,
                key = taskItem.key,
                param1 = taskItem.param1,
                param2 = taskItem.param2,
                state = state,
                value = taskItem.value,
                maxvalue = taskItem.maxvalue,
                rewardid = taskItem.rewardid,
                rewardnum = taskItem.rewardnum,
            }
            table.insert(items, item)
        end
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, items = items}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部任务奖励领取
function CMD.takeTaskReward(recvobj)
    local uid       = math.floor(recvobj.uid)
    local id        = math.floor(recvobj.id)

    local clubID = USERS_CLUB[uid]
    local clubInfo = CLUB_LIST[clubID]
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    local tasktimestamp, taskItems
    if id and id > 0 then
        local ok, taskItem
        ok, tasktimestamp, taskItem = pcall(cluster.call, "master", ".club", "getTaskItem", clubInfo.club_id, id)
        if not ok then
            LOG_DEBUG("getTaskItem not ok")
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
        if not taskItem or not taskItem.complete then
            LOG_DEBUG("getTaskItem fail", taskItem)
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
        taskItems = {taskItem}
    else
        local ok
        ok, tasktimestamp, taskItems = pcall(cluster.call, "master", ".club", "getCompleteTaskItems", clubInfo.club_id)
        if not ok then
            LOG_DEBUG("getCompleteTaskItems not ok")
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
        if not taskItems or #taskItems <= 0 then
            LOG_DEBUG("getCompleteTaskItems fail", taskItems)
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
    end
    local playerInfo = player_tool.getPlayerInfo(uid)
    local clubdata = nil
    local joinTime = getMemberJoinTime(clubID, uid)
    if playerInfo and playerInfo.clubdata and playerInfo.clubdata ~= "" then
        clubdata = cjson.decode(playerInfo.clubdata)
        if clubdata.joinTime ~= joinTime then
            clubdata = newClubData(joinTime)
        end
        if clubdata.tasktimestamp ~= tasktimestamp then
            clubdata.tasktimestamp = tasktimestamp
            clubdata.taskids = {}
        end
    else
        clubdata = newClubData(joinTime)
    end
    LOG_DEBUG("clubdata", uid, clubdata)
    local rewards = {}
    for _, taskItem in pairs(taskItems) do
        if clubdata and clubdata.taskids and not table_tool.find(clubdata.taskids, function(ele)
            if ele < taskItem.id then
                return -1
            elseif ele > taskItem.id then
                return 1
            else
                return 0
            end
        end) then
            addRewards(rewards, taskItem.rewardid, taskItem.rewardnum)
            table.insert(clubdata.taskids, taskItem.id)
            table.sort(clubdata.taskids, function(a, b)
                return a < b
            end)
        end
    end
    if #rewards <= 0 then
        return PDEFINE.RET.ERROR.CALL_FAIL
    end

    local ok, agent = pcall(cluster.call, "master", ".userCenter", "getAgent", uid)
    if ok and agent ~= nil then
        pcall(cluster.call, agent.server, agent.address, "clusterModuleCall", "player", "setClubData", uid, clubdata)
        pcall(cluster.call, agent.server, agent.address, "addProps", rewards, "takeClubTaskReward")
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, id = id, rewards = rewards}
    return PDEFINE.RET.SUCCESS, retobj
end

--！俱乐部奖励
function CMD.reward(recvobj)
    local uid       = math.floor(recvobj.uid)
    local page      = math.floor(recvobj.page)

    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    local clubInfo = CLUB_LIST[clubID]
    LOG_DEBUG("reward clubInfo", clubInfo)
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end

    local joinTime = 0
    local sql = string.format("select * from d_clubs_members where club_id = %d and uid = %d ", clubID, uid)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        joinTime = rs[1].create_time
    end

    local ok, page, hasNextPage, rewards = pcall(cluster.call, "master", ".club", "getRewardPage", clubID, joinTime, page, PAGE_SIZE)
    if not ok then
        return PDEFINE.RET.ERROR.CALL_FAIL
    end
    local items = {}
    if #rewards > 0 then
        local playerInfo = player_tool.getPlayerInfo(uid)
        local clubdata = nil
        if playerInfo and playerInfo.clubdata and playerInfo.clubdata ~= "" then
            clubdata = cjson.decode(playerInfo.clubdata)
            if clubdata.joinTime ~= joinTime then
                clubdata = nil
            end
        end
        LOG_DEBUG("clubdata", uid, clubdata)
        for _, reward in pairs(rewards) do
            local coin = 0
            if reward.type == PDEFINE.REWARD_TYPE.JACKPOT then
                local betcoin = 10000
                if playerInfo.uid then
                    local ok
                    ok, betcoin = pcall(cluster.call, "master", ".vipCenter", "getBet", playerInfo.level, reward.betIndex)
                    if ok then
                    end
                end
                coin = reward.mult * betcoin * 0.2
            end
            local state = nil
            if reward.present_time < joinTime then
                state = PDEFINE.REWARD_STATE.NONE
            elseif clubdata and clubdata.rewardids and table_tool.find(clubdata.rewardids, function(ele)
                if ele < reward.id then
                    return -1
                elseif ele > reward.id then
                    return 1
                else
                    return 0
                end
            end) then
                state = PDEFINE.REWARD_STATE.ALREADY_TAKE
            else
                state = PDEFINE.REWARD_STATE.CAN_TAKE
            end
            local item = {
                id = reward.id,
                uid = reward.uid,
                game_id = reward.game_id or 0,
                type = reward.type,
                coin = coin,
                state = state,
                present_time = reward.present_time,
                level = reward.level or defaultLevel,
                playername = reward.playername or defaultPlayerName,
                usericon = reward.usericon or defaultUserIcon,
            }
            table.insert(items, item)
        end
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, page = page, hasNextPage = hasNextPage, items = items}
    return PDEFINE.RET.SUCCESS, retobj
end

--！俱乐部奖励领取
function CMD.takeReward(recvobj)
    local uid = math.floor(recvobj.uid)
    local id  = math.floor(recvobj.id)

    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end
    local clubInfo = CLUB_LIST[clubID]
    LOG_DEBUG("task clubInfo", clubInfo)
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end

    local playerInfo = player_tool.getPlayerInfo(uid)
    local joinTime = getMemberJoinTime(clubID, uid)
    local clubdata = nil
    if playerInfo and playerInfo.clubdata and playerInfo.clubdata ~= "" then
        clubdata = cjson.decode(playerInfo.clubdata)
        if clubdata.joinTime ~= joinTime then
            clubdata = newClubData(joinTime)
        end
    else
        clubdata = newClubData(joinTime)
    end
    LOG_DEBUG("clubdata", uid, clubdata)
    local rewards = {}
    if id and id > 0 then
        local ok, reward = pcall(cluster.call, "master", ".club", "getReward", clubID, id)
        if not ok then
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
        if not reward then
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
        if clubdata and clubdata.rewardids and table_tool.find(clubdata.rewardids, function(ele)
            if ele < reward.id then
                return -1
            elseif ele > reward.id then
                return 1
            else
                return 0
            end
        end) then
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
        table.insert(rewards, reward)
    else
        local ok, clubRewards = pcall(cluster.call, "master", ".club", "getRewards", clubID)
        if not ok then
            return PDEFINE.RET.ERROR.CALL_FAIL
        end
        if clubRewards and #clubRewards > 0 then
            for _, clubReward in pairs(clubRewards) do
                local hasTake = clubdata and clubdata.rewardids and table_tool.find(clubdata.rewardids, function(ele)
                    if ele < clubReward.id then
                        return -1
                    elseif ele > clubReward.id then
                        return 1
                    else
                        return 0
                    end
                end)
                if not hasTake then
                    table.insert(rewards, clubReward)
                end
            end
        end
    end
    local coin = 0
    for _, reward in pairs(rewards) do
        if reward.type == PDEFINE.REWARD_TYPE.JACKPOT then
            local betcoin = 10000
            if playerInfo.uid then
                local ok
                ok, betcoin = pcall(cluster.call, "master", ".vipCenter", "getBet", playerInfo.level, reward.betIndex)
                if ok then
                end
            end
            coin = coin + reward.mult * betcoin * 0.2
        end
        table.insert(clubdata.rewardids, reward.id)
    end
    table.sort(clubdata.rewardids, function(a, b)
        return a < b
    end)
    while #clubdata.rewardids > PDEFINE.LIMIT.CLUB_REWARD_COUNT do
        table.remove(clubdata.rewardids, 1)
    end
    local ok, agent = pcall(cluster.call, "master", ".userCenter", "getAgent", uid)
    if ok and agent ~= nil then
        pcall(cluster.call, agent.server, agent.address, "clusterModuleCall", "player", "setClubData", uid, clubdata)
        pcall(cluster.call, agent.server, agent.address, "addProps", rewards, "takeClubTaskReward")
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, id = id, coin = coin}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 俱乐部成员列表
function CMD.memberList(recvobj)
    local uid       = math.floor(recvobj.uid)
    local page      = math.floor(recvobj.page)

    local clubID = USERS_CLUB[uid]
    if clubID == nil then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION
    end
    local clubInfo = CLUB_LIST[clubID]
    if clubInfo == nil then
        return PDEFINE.RET.ERROR.CLUB_NOT_FOUND
    end

    if page < 1 then
        page = 1
    end
    local rpcRes = {UserID = uid, Page = page, HasNextPage = true, Items = {}}
    local begin = (page - 1) * PAGE_SIZE
    local sql = string.format("select * from d_clubs_members where club_id=%d order by create_time desc limit %d, %d", clubID, begin, PAGE_SIZE)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs == 0 then
        return PDEFINE.RET.ERROR.CLUB_NO_PERMISSION
    end
    local cntsql = string.format("select count(*) as t from d_clubs_members where club_id=%d", clubID)
    local cntrs = skynet.call(".mysqlpool", "lua", "execute", cntsql)
    if #cntrs > 0 and cntrs[1].t > PAGE_SIZE then
        rpcRes.HasNextPage = true
    end
    for _, row in pairs(rs) do
        local result = do_redis({"hgetall", USER_REDIS_KEY .. row.uid})
        local playerInfo = make_pairs_table(result)
        table.insert(rpcRes.Items, {
            ID  = row.uid,
            Name = playerInfo.playername,
            Avatar = playerInfo.usericon,
            Level = playerInfo.level,
            Score = playerInfo.coin,
            JoinTime = row.create_time
        })
    end
    local retobj = {c = math.floor(recvobj.c), code = PDEFINE.RET.SUCCESS, data = rpcRes}
    return PDEFINE.RET.SUCCESS, retobj
end

--! 登录时候的邀请弹窗
function CMD.invitepop(uid)
    local clubID = USERS_CLUB[uid]
    if clubID ~= nil then
        return
    end

    local Items = {}
    local sql = string.format("select * from d_clubs_apply where uid=%d and stype=1 order by create_time desc limit %d", uid, PAGE_SIZE)
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        for _, row in pairs(rs) do
            local clubInfo = CLUB_LIST(row.club_id)
            local result = do_redis({"hgetall", USER_REDIS_KEY .. row.owner_id})
            local playerInfo = make_pairs_table(result)

            local tmp = {
                ["Club"] = {
                    ID = clubInfo.club_id,
                    OwnerID = clubInfo.owner_id,
                    Name = clubInfo.name,
                    Avatar = clubInfo.avatar,
                    Num = clubInfo.curcnt,
                    MaxNum = clubInfo.maxcnt
                },
                ["Owner"] = {
                    ID = clubInfo.owner_id,
                    Name = playerInfo.playername,
                    Avatar = playerInfo.usericon,
                    Level = playerInfo.level,
                    Score = playerInfo.coin,
                    JoinTime = clubInfo.create_time,
                },
                InviteTime = row.create_time
            }
            table.inesrt(Items, tmp)
        end
    end
    if #Items == 0 then
        return
    end

    return Items
end

function CMD.reload()
    obj.load()
end

function CMD.start()
    obj.load()
end

function CMD.test()
    LOG_DEBUG("test test test clubmgr")
end

skynet.start(function()
	skynet.dispatch("lua", function(session, address, cmd, ...)
		local f = CMD[cmd]
		skynet.retpack(f(...))
	end)
    skynet.register(".clubmgr")
end)