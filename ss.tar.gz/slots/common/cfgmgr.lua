local skynet = require "skynet"
require "skynet.manager"

--[[
如何重新加载配置
1，打开debug_console: nc 127.0.0.1 port
2，查看cfgmgr的地址， 控制台输入: list
3，调用reload接口: call adress "reload"
]]--

--直接调用cfg的接口
local CMD = require "cfg"

function CMD.start()
    CMD.load()
    LOG_INFO("cfgmgr start:", skynet.self())
end

skynet.start(function()
    skynet.dispatch("lua", function(session, address, cmd, ...)
        local f = assert(CMD[cmd], cmd .. "not found")
        skynet.retpack(f(...))
    end)
    skynet.register(".cfgmgr")
end)
