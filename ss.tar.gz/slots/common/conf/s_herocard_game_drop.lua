return{
 
 {
  gameid = 601,
  id = 1,
  drop_prob = 0.012
 },
 {
  gameid = 602,
  id = 2,
  drop_prob = 0.015
 },
 {
  gameid = 603,
  id = 3,
  drop_prob = 0.014
 },
 {
  gameid = 604,
  id = 4,
  drop_prob = 0.017
 },
 {
  gameid = 605,
  id = 5,
  drop_prob = 0.015
 },
 {
  gameid = 606,
  id = 6,
  drop_prob = 0
 },
 {
  gameid = 607,
  id = 7,
  drop_prob = 0
 },
 {
  gameid = 608,
  id = 8,
  drop_prob = 0.017
 },
 {
  gameid = 609,
  id = 9,
  drop_prob = 0.014
 },
 {
  gameid = 610,
  id = 10,
  drop_prob = 0.014
 },
 {
  gameid = 611,
  id = 11,
  drop_prob = 0.015
 },
 {
  gameid = 612,
  id = 12,
  drop_prob = 0.016
 },
 {
  gameid = 613,
  id = 13,
  drop_prob = 0.017
 },
 {
  gameid = 614,
  id = 14,
  drop_prob = 0.014
 },
 {
  gameid = 615,
  id = 15,
  drop_prob = 0.015
 },
 {
  gameid = 616,
  id = 16,
  drop_prob = 0.016
 },
 {
  gameid = 617,
  id = 17,
  drop_prob = 0.018
 },
 {
  gameid = 618,
  id = 18,
  drop_prob = 0.017
 },
 {
  gameid = 619,
  id = 19,
  drop_prob = 0.017
 },
 {
  gameid = 620,
  id = 20,
  drop_prob = 0.015
 },
 {
  gameid = 621,
  id = 21,
  drop_prob = 0.016
 },
 {
  gameid = 622,
  id = 22,
  drop_prob = 0.015
 },
 {
  gameid = 623,
  id = 23,
  drop_prob = 0.017
 },
 {
  gameid = 624,
  id = 24,
  drop_prob = 0.015
 },
 {
  gameid = 625,
  id = 25,
  drop_prob = 0.018
 },
 {
  gameid = 626,
  id = 26,
  drop_prob = 0.015
 },
 {
  gameid = 627,
  id = 27,
  drop_prob = 0.014
 },
 {
  gameid = 628,
  id = 28,
  drop_prob = 0.016
 },
 {
  gameid = 629,
  id = 29,
  drop_prob = 0.017
 },
 {
  gameid = 630,
  id = 30,
  drop_prob = 0.016
 },
 {
  gameid = 631,
  id = 31,
  drop_prob = 0.015
 },
 {
  gameid = 632,
  id = 32,
  drop_prob = 0.017
 },
 {
  gameid = 633,
  id = 33,
  drop_prob = 0.018
 },
 {
  gameid = 634,
  id = 34,
  drop_prob = 0.016
 },
 {
  gameid = 635,
  id = 35,
  drop_prob = 0.014
 },
 {
  gameid = 636,
  id = 36,
  drop_prob = 0.015
 },
 {
  gameid = 637,
  id = 37,
  drop_prob = 0.016
 },
 {
  gameid = 638,
  id = 38,
  drop_prob = 0.014
 },
 {
  gameid = 639,
  id = 39,
  drop_prob = 0.015
 },
 {
  gameid = 640,
  id = 40,
  drop_prob = 0.014
 },
 {
  gameid = 641,
  id = 41,
  drop_prob = 0.016
 },
 {
  gameid = 642,
  id = 42,
  drop_prob = 0.018
 },
 {
  gameid = 643,
  id = 43,
  drop_prob = 0.015
 },
 {
  gameid = 644,
  id = 44,
  drop_prob = 0.015
 },
 {
  gameid = 645,
  id = 45,
  drop_prob = 0.016
 },
 {
  gameid = 646,
  id = 46,
  drop_prob = 0.017
 },
 {
  gameid = 668,
  id = 47,
  drop_prob = 0.015
 },
 {
  gameid = 648,
  id = 48,
  drop_prob = 0.015
 },
 {
  gameid = 650,
  id = 49,
  drop_prob = 0.014
 },
 {
  gameid = 652,
  id = 50,
  drop_prob = 0.018
 },
 {
  gameid = 656,
  id = 51,
  drop_prob = 0.016
 },
 {
  gameid = 657,
  id = 52,
  drop_prob = 0.015
 },
 {
  gameid = 658,
  id = 53,
  drop_prob = 0.016
 },
 {
  gameid = 659,
  id = 54,
  drop_prob = 0.015
 },
 {
  gameid = 660,
  id = 55,
  drop_prob = 0.014
 },
 {
  gameid = 661,
  id = 56,
  drop_prob = 0.017
 },
 {
  gameid = 662,
  id = 57,
  drop_prob = 0.018
 },
 {
  gameid = 663,
  id = 58,
  drop_prob = 0.018
 },
 {
  gameid = 664,
  id = 59,
  drop_prob = 0.017
 },
 {
  gameid = 665,
  id = 60,
  drop_prob = 0.018
 },
 {
  gameid = 666,
  id = 61,
  drop_prob = 0.016
 },
 {
  gameid = 667,
  id = 62,
  drop_prob = 0.015
 },
 {
  gameid = 682,
  id = 63,
  drop_prob = 0.016
 },
 {
  gameid = 655,
  id = 64,
  drop_prob = 0.017
 },
 {
  gameid = 653,
  id = 65,
  drop_prob = 0.016
 },
 {
  gameid = 654,
  id = 66,
  drop_prob = 0.016
 },
 {
  gameid = 683,
  id = 67,
  drop_prob = 0.016
 },
 {
  gameid = 684,
  id = 68,
  drop_prob = 0.016
 },
 {
  gameid = 688,
  id = 69,
  drop_prob = 0.017
 },
 {
  gameid = 686,
  id = 70,
  drop_prob = 0.015
 },
 {
  gameid = 687,
  id = 71,
  drop_prob = 0.015
 },
 {
  gameid = 669,
  id = 72,
  drop_prob = 0.016
 },
 {
  gameid = 675,
  id = 73,
  drop_prob = 0.014
 },
 {
  gameid = 671,
  id = 74,
  drop_prob = 0.016
 },
 {
  gameid = 672,
  id = 75,
  drop_prob = 0.017
 },
 {
  gameid = 673,
  id = 76,
  drop_prob = 0.015
 },
 {
  gameid = 677,
  id = 77,
  drop_prob = 0.017
 },
 {
  gameid = 649,
  id = 78,
  drop_prob = 0.014
 },
 {
  gameid = 674,
  id = 79,
  drop_prob = 0.017
 },
 {
  gameid = 670,
  id = 80,
  drop_prob = 0.018
 },
 {
  gameid = 676,
  id = 81,
  drop_prob = 0.018
 },
 {
  gameid = 519,
  id = 82,
  drop_prob = 0.016
 }
}