local TYPE = PDEFINE.NEW_QUEST.TYPE
local KIND = PDEFINE.NEW_QUEST.KIND
local GRADE = PDEFINE.NEW_QUEST.GRADE
local PROP_ID = PDEFINE.PROP_ID
return {
    [1] = {
        id = 1,
        type = TYPE.Daily,
        kind = KIND.Spin,
        detail = "Spin 30 times.",
        params = 30,
        diamond = 50,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 20000
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [2] = {
        id = 2,
        type = TYPE.Daily,
        kind = KIND.DifferentSlots,
        detail = "Bet 3 different slots.",
        params = 3,
        diamond = 50,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 50000
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [3] = {
        id = 3,
        type = TYPE.Daily,
        kind = KIND.WinCoin,
        detail = "Win a total of %d coins.",
        params = 500000,
        diamond = 100,
        grade = GRADE.Medium,
        rewards = {{
            type = PROP_ID.COIN,
            count = 80000
        }, {
            type = PROP_ID.VIP_POINT,
            count = 50
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [4] = {
        id = 4,
        type = TYPE.Daily,
        kind = KIND.SpecialBet,
        detail = "Bet %d in a single spin 10 times.",
        params = '10,80000',
        diamond = 100,
        grade = GRADE.Medium,
        rewards = {{
            type = PROP_ID.DOUBLE_LEVEL_EXP,
            count = 1800
        },{
            type = PROP_ID.GIFT_Drink,
            count = 1
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [5] = {
        id = 5,
        type = TYPE.Daily,
        kind = KIND.WinSize,
        detail = "Get 3 big wins.",
        params = '3,1',
        diamond = 100,
        grade = GRADE.High,
        rewards = {{
            type = PROP_ID.COIN,
            count = 120000
        }, {
            type = PROP_ID.PALACE_POINT,
            count = 20
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [6] = {
        id = 6,
        type = TYPE.Daily,
        kind = KIND.PlayTime,
        detail = "Play any slot for 30 minutes.",
        params = 30,
        diamond = 100,
        grade = GRADE.Medium,
        rewards = {{
            type = PROP_ID.COIN,
            count = 140000
        }, {
            type = PROP_ID.REVIVE_CARD,
            count = 1
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [7] = {
        id = 7,
        type = TYPE.Daily,
        kind = KIND.Bet,
        detail = "Bet a total of %d Coins.",
        params = 1000000,
        diamond = 100,
        grade = GRADE.Medium,
        rewards = {{
            type = PROP_ID.COIN,
            count = 160000
        }, {
            type = PROP_ID.HERO_CARD,
            count = 1
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [8] = {
        id = 8,
        type = TYPE.Daily,
        kind = KIND.Spin,
        detail = "Spin 50 times.",
        params = 50,
        diamond = 100,
        grade = GRADE.Medium,
        rewards = {{
            type = PROP_ID.VIP_POINT,
            count = 20
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [9] = {
        id = 9,
        type = TYPE.Daily,
        kind = KIND.WinSize,
        detail = "Get 2 huge wins.",
        params = '2,2',
        diamond = 220,
        grade = GRADE.High,
        rewards = {{
            type = PROP_ID.COIN,
            count = 300000
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.HERO_CARD,
            count = 1
        }}
    },
    [10] = {
        id = 10,
        type = TYPE.Daily,
        kind = KIND.LevelUp,
        detail = "Level up 1 time.",
        params = 1,
        diamond = 250,
        grade = GRADE.Medium,
        rewards = {{
            type = PROP_ID.REVIVE_CARD,
            count = 1
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }}
    },
    [11] = {
        id = 11,
        type = TYPE.Daily,
        kind = KIND.Bet,
        detail = "Bet a total of %d Coins.",
        params = 50000000,
        diamond = 280,
        grade = GRADE.High,
        rewards = {{
            type = PROP_ID.COIN,
            count = 500000
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.HERO_CARD,
            count = 2
        }}
    },
    [12] = {
        id = 12,
        type = TYPE.Daily,
        kind = KIND.ShareFbTimes,
        detail = "Share to Facebook 1 time.",
        params = 1,
        diamond = 300,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 600000
        }, {
            type = PROP_ID.DAILY_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.PALACE_POINT,
            count = 100
        }}
    },
    [21] = {
        id = 21,
        type = TYPE.Weekly,
        kind = KIND.Scratch,
        detail = "Scratch&win 10 times.",
        params = 10,
        diamond = 100,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 200000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }}
    },
    [22] = {
        id = 22,
        type = TYPE.Weekly,
        kind = KIND.SpecialBet,
        detail = "Bet %d in a single spin 40 times.",
        params = '40,200000',
        diamond = 100,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 400000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.HERO_CARD,
            count = 1
        }}
    },
    [23] = {
        id = 23,
        type = TYPE.Weekly,
        kind = KIND.Chips,
        detail = "Get 80 fragments.",
        params = 80,
        diamond = 300,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 500000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.PALACE_POINT,
            count = 100
        }}
    },
    [24] = {
        id = 24,
        type = TYPE.Weekly,
        kind = KIND.LuckyFlipcard,
        detail = "Play lucky flipcard for 5 times.",
        params = 5,
        diamond = 120,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 600000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.HERO_CARD,
            count = 2
        }}
    },
    [25] = {
        id = 25,
        type = TYPE.Weekly,
        kind = KIND.SpecialWin,
        detail = "Win %d in a single spin 50 times.",
        params = '50,200000',
        diamond = 150,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 500000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.VIP_POINT,
            count = 50
        }}
    },
    [26] = {
        id = 26,
        type = TYPE.Weekly,
        kind = KIND.ShareFBDays,
        detail = "Share to Facebook for 5 days.",
        params = 5,
        diamond = 200,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 600000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.PALACE_POINT,
            count = 100
        }}
    },
    [27] = {
        id = 27,
        type = TYPE.Weekly,
        kind = KIND.Palace,
        detail = "Earn 1000 hero palace points.",
        params = 1000,
        diamond = 200,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 600000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.HERO_CARD,
            count = 2
        }}
    },
    [28] = {
        id = 28,
        type = TYPE.Weekly,
        kind = KIND.Spin,
        detail = "Spin 2500 times.",
        params = 2500,
        diamond = 100,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 500000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.HERO_CARD,
            count = 2
        }}
    },
    [29] = {
        id = 29,
        type = TYPE.Weekly,
        kind = KIND.Purchase,
        detail = "Make a purchase.",
        params = 1,
        diamond = 300,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 1000000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.HERO_CARD,
            count = 5
        }}
    },
    [30] = {
        id = 30,
        type = TYPE.Weekly,
        kind = KIND.UnlockHero,
        detail = "Unlock or evolve 3 heroes.",
        params = 3,
        diamond = 300,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 1500000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.GIFT_Money,
            count = 1
        }}
    },
    [31] = {
        id = 31,
        type = TYPE.Weekly,
        kind = KIND.WinCoin,
        detail = "Win a total of %d coins.",
        params = 4000000,
        diamond = 250,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 1000000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.PALACE_POINT,
            count = 200
        }}
    },
    [32] = {
        id = 32,
        type = TYPE.Weekly,
        kind = KIND.Bet,
        detail = "Bet a total of %d coins.",
        params = 6000000,
        diamond = 250,
        grade = GRADE.Low,
        rewards = {{
            type = PROP_ID.COIN,
            count = 1200000
        }, {
            type = PROP_ID.WEEK_ACTIVITY,
            count = 10
        }, {
            type = PROP_ID.VIP_POINT,
            count = 200
        }}
    }
}

