return{
 
 {
  level = 0,
  weight = 80,
  id = 1,
  campid = 1001,
  cardid = 1001
 },
 {
  level = 0,
  weight = 100,
  id = 2,
  campid = 1001,
  cardid = 1002
 },
 {
  level = 100,
  weight = 120,
  id = 3,
  campid = 1001,
  cardid = 1003
 },
 {
  level = 0,
  weight = 140,
  id = 4,
  campid = 1001,
  cardid = 1004
 },
 {
  level = 0,
  weight = 100,
  id = 5,
  campid = 1001,
  cardid = 1005
 },
 {
  level = 300,
  weight = 20,
  id = 6,
  campid = 1004,
  cardid = 1006
 },
 {
  level = 500,
  weight = 120,
  id = 7,
  campid = 1005,
  cardid = 1007
 },
 {
  level = 500,
  weight = 160,
  id = 8,
  campid = 1005,
  cardid = 1008
 },
 {
  level = 600,
  weight = 140,
  id = 9,
  campid = 1005,
  cardid = 1009
 },
 {
  level = 150,
  weight = 100,
  id = 10,
  campid = 1002,
  cardid = 1010
 },
 {
  level = 300,
  weight = 100,
  id = 11,
  campid = 1004,
  cardid = 1011
 },
 {
  level = 100,
  weight = 60,
  id = 12,
  campid = 1002,
  cardid = 1012
 },
 {
  level = 100,
  weight = 100,
  id = 13,
  campid = 1002,
  cardid = 1013
 },
 {
  level = 150,
  weight = 140,
  id = 14,
  campid = 1002,
  cardid = 1014
 },
 {
  level = 150,
  weight = 160,
  id = 15,
  campid = 1002,
  cardid = 1015
 },
 {
  level = 200,
  weight = 160,
  id = 16,
  campid = 1002,
  cardid = 1016
 },
 {
  level = 300,
  weight = 100,
  id = 17,
  campid = 1004,
  cardid = 1017
 },
 {
  level = 600,
  weight = 120,
  id = 18,
  campid = 1005,
  cardid = 1018
 },
 {
  level = 0,
  weight = 80,
  id = 19,
  campid = 1004,
  cardid = 1019
 },
 {
  level = 100,
  weight = 140,
  id = 20,
  campid = 1001,
  cardid = 1020
 },
 {
  level = 400,
  weight = 120,
  id = 21,
  campid = 1004,
  cardid = 1021
 },
 {
  level = 600,
  weight = 140,
  id = 22,
  campid = 1005,
  cardid = 1022
 },
 {
  level = 150,
  weight = 120,
  id = 23,
  campid = 1002,
  cardid = 1023
 },
 {
  level = 150,
  weight = 100,
  id = 24,
  campid = 1002,
  cardid = 1024
 },
 {
  level = 500,
  weight = 100,
  id = 25,
  campid = 1005,
  cardid = 1025
 },
 {
  level = 300,
  weight = 140,
  id = 26,
  campid = 1004,
  cardid = 1026
 },
 {
  level = 400,
  weight = 80,
  id = 27,
  campid = 1004,
  cardid = 1027
 },
 {
  level = 400,
  weight = 100,
  id = 28,
  campid = 1004,
  cardid = 1028
 },
 {
  level = 200,
  weight = 60,
  id = 29,
  campid = 1003,
  cardid = 1029
 },
 {
  level = 300,
  weight = 80,
  id = 30,
  campid = 1003,
  cardid = 1030
 },
 {
  level = 0,
  weight = 100,
  id = 31,
  campid = 1003,
  cardid = 1031
 },
 {
  level = 200,
  weight = 120,
  id = 32,
  campid = 1003,
  cardid = 1032
 },
 {
  level = 200,
  weight = 140,
  id = 33,
  campid = 1003,
  cardid = 1033
 },
 {
  level = 200,
  weight = 80,
  id = 34,
  campid = 1003,
  cardid = 1034
 },
 {
  level = 300,
  weight = 100,
  id = 35,
  campid = 1003,
  cardid = 1035
 },
 {
  level = 150,
  weight = 120,
  id = 36,
  campid = 1002,
  cardid = 1036
 },
 {
  level = 200,
  weight = 160,
  id = 37,
  campid = 1003,
  cardid = 1037
 },
 {
  level = 200,
  weight = 140,
  id = 38,
  campid = 1003,
  cardid = 1038
 },
 {
  level = 400,
  weight = 120,
  id = 39,
  campid = 1004,
  cardid = 1039
 },
 {
  level = 600,
  weight = 160,
  id = 40,
  campid = 1005,
  cardid = 1040
 },
 {
  level = 200,
  weight = 100,
  id = 41,
  campid = 1003,
  cardid = 1041
 },
 {
  level = 200,
  weight = 100,
  id = 42,
  campid = 1003,
  cardid = 1042
 },
 {
  level = 300,
  weight = 120,
  id = 43,
  campid = 1003,
  cardid = 1043
 },
 {
  level = 100,
  weight = 140,
  id = 44,
  campid = 1001,
  cardid = 1044
 },
 {
  level = 0,
  weight = 100,
  id = 45,
  campid = 1003,
  cardid = 1045
 },
 {
  level = 0,
  weight = 100,
  id = 46,
  campid = 1001,
  cardid = 1046
 },
 {
  level = 0,
  weight = 80,
  id = 47,
  campid = 1001,
  cardid = 1047
 },
 {
  level = 150,
  weight = 160,
  id = 48,
  campid = 1002,
  cardid = 1048
 },
 {
  level = 150,
  weight = 120,
  id = 49,
  campid = 1002,
  cardid = 1049
 },
 {
  level = 0,
  weight = 100,
  id = 50,
  campid = 1002,
  cardid = 1050
 },
 {
  level = 100,
  weight = 120,
  id = 51,
  campid = 1002,
  cardid = 1051
 },
 {
  level = 500,
  weight = 100,
  id = 52,
  campid = 1005,
  cardid = 1052
 },
 {
  level = 100,
  weight = 80,
  id = 53,
  campid = 1001,
  cardid = 1053
 },
 {
  level = 100,
  weight = 140,
  id = 54,
  campid = 1002,
  cardid = 1054
 },
 {
  level = 500,
  weight = 160,
  id = 55,
  campid = 1005,
  cardid = 1055
 },
 {
  level = 500,
  weight = 160,
  id = 56,
  campid = 1005,
  cardid = 1056
 },
 {
  level = 500,
  weight = 140,
  id = 57,
  campid = 1005,
  cardid = 1057
 },
 {
  level = 600,
  weight = 160,
  id = 58,
  campid = 1005,
  cardid = 1058
 },
 {
  level = 400,
  weight = 120,
  id = 59,
  campid = 1004,
  cardid = 1059
 },
 {
  level = 400,
  weight = 100,
  id = 60,
  campid = 1004,
  cardid = 1060
 },
 {
  level = 400,
  weight = 120,
  id = 61,
  campid = 1004,
  cardid = 1061
 },
 {
  level = 300,
  weight = 140,
  id = 62,
  campid = 1003,
  cardid = 1062
 },
 {
  level = 400,
  weight = 120,
  id = 63,
  campid = 1004,
  cardid = 1063
 },
 {
  level = 300,
  weight = 120,
  id = 64,
  campid = 1004,
  cardid = 1064
 },
 {
  level = 600,
  weight = 120,
  id = 65,
  campid = 1005,
  cardid = 1065
 },
 {
  level = 300,
  weight = 120,
  id = 66,
  campid = 1003,
  cardid = 1066
 },
 {
  level = 150,
  weight = 140,
  id = 67,
  campid = 1002,
  cardid = 1067
 },
 {
  level = 100,
  weight = 100,
  id = 68,
  campid = 1001,
  cardid = 1068
 },
 {
  level = 100,
  weight = 100,
  id = 69,
  campid = 1001,
  cardid = 1069
 },
 {
  level = 500,
  weight = 120,
  id = 70,
  campid = 1004,
  cardid = 1070
 },
 {
  level = 500,
  weight = 80,
  id = 71,
  campid = 1004,
  cardid = 1071
 },
 {
  level = 500,
  weight = 60,
  id = 72,
  campid = 1005,
  cardid = 1072
 },
 {
  level = 600,
  weight = 140,
  id = 73,
  campid = 1005,
  cardid = 1073
 },
 {
  level = 100,
  weight = 100,
  id = 74,
  campid = 1001,
  cardid = 1074
 },
 {
  level = 400,
  weight = 140,
  id = 75,
  campid = 1004,
  cardid = 1075
 },
 {
  level = 0,
  weight = 20,
  id = 76,
  campid = 1001,
  cardid = 1076
 },
 {
  level = 400,
  weight = 140,
  id = 77,
  campid = 1004,
  cardid = 1077
 },
 {
  level = 200,
  weight = 160,
  id = 78,
  campid = 1002,
  cardid = 1078
 },
 {
  level = 150,
  weight = 160,
  id = 79,
  campid = 1002,
  cardid = 1079
 },
 {
  level = 0,
  weight = 120,
  id = 80,
  campid = 1004,
  cardid = 1080
 }
}