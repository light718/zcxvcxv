return{
 
 {
  desc = 'The light will find you!',
  id = 1,
  campid = 1001,
  name = 'Light'
 },
 {
  desc = 'Never underestimate the power of nature.',
  id = 2,
  campid = 1002,
  name = 'Nature'
 },
 {
  desc = 'It is never wise to fight the current.',
  id = 3,
  campid = 1003,
  name = 'Water'
 },
 {
  desc = 'Ready to get burned?',
  id = 4,
  campid = 1004,
  name = 'Fire'
 },
 {
  desc = 'Wanna see a perfect storm?',
  id = 5,
  campid = 1005,
  name = 'Storm'
 }
}