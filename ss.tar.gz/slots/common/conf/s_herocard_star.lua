return{
 
 {
  percent = 0,
  need_chips = 60,
  star = 1,
  id = 1
 },
 {
  percent = 5,
  need_chips = 90,
  star = 2,
  id = 2
 },
 {
  percent = 10,
  need_chips = 120,
  star = 3,
  id = 3
 },
 {
  percent = 15,
  need_chips = 160,
  star = 4,
  id = 4
 },
 {
  percent = 30,
  need_chips = 210,
  star = 5,
  id = 5
 }
}