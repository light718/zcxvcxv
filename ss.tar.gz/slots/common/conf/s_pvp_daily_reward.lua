return{
 
 {
  rewards = '1:400000|8:3',
  id = 1,
  rank = 1
 },
 {
  rewards = '1:300000|8:2',
  id = 2,
  rank = 2
 },
 {
  rewards = '1:250000|8:2',
  id = 3,
  rank = 3
 },
 {
  rewards = '1:200000|8:2',
  id = 4,
  rank = 4
 },
 {
  rewards = '1:150000|8:2',
  id = 5,
  rank = 5
 },
 {
  rewards = '1:120000|8:1',
  id = 6,
  rank = 6
 },
 {
  rewards = '1:120000|8:1',
  id = 7,
  rank = 7
 },
 {
  rewards = '1:120000|8:1',
  id = 8,
  rank = 8
 },
 {
  rewards = '1:120000|8:1',
  id = 9,
  rank = 9
 },
 {
  rewards = '1:120000|8:1',
  id = 10,
  rank = 10
 },
 {
  rewards = '1:100000|8:1',
  id = 11,
  rank = 11
 },
 {
  rewards = '1:100000|8:1',
  id = 12,
  rank = 12
 },
 {
  rewards = '1:100000|8:1',
  id = 13,
  rank = 13
 },
 {
  rewards = '1:100000|8:1',
  id = 14,
  rank = 14
 },
 {
  rewards = '1:100000|8:1',
  id = 15,
  rank = 15
 },
 {
  rewards = '1:100000|8:1',
  id = 16,
  rank = 16
 },
 {
  rewards = '1:100000|8:1',
  id = 17,
  rank = 17
 },
 {
  rewards = '1:100000|8:1',
  id = 18,
  rank = 18
 },
 {
  rewards = '1:100000|8:1',
  id = 19,
  rank = 19
 },
 {
  rewards = '1:100000|8:1',
  id = 20,
  rank = 20
 }
}