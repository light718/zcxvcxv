return{
 
 {
  betidx = 1,
  id = 1,
  drop_coeff = 0.75
 },
 {
  betidx = 2,
  id = 2,
  drop_coeff = 0.85
 },
 {
  betidx = 3,
  id = 3,
  drop_coeff = 0.9
 },
 {
  betidx = 4,
  id = 4,
  drop_coeff = 0.9
 },
 {
  betidx = 5,
  id = 5,
  drop_coeff = 0.95
 },
 {
  betidx = 6,
  id = 6,
  drop_coeff = 0.95
 },
 {
  betidx = 7,
  id = 7,
  drop_coeff = 0.95
 },
 {
  betidx = 8,
  id = 8,
  drop_coeff = 1
 },
 {
  betidx = 9,
  id = 9,
  drop_coeff = 1
 },
 {
  betidx = 10,
  id = 10,
  drop_coeff = 1
 },
 {
  betidx = 11,
  id = 11,
  drop_coeff = 1.12
 },
 {
  betidx = 12,
  id = 12,
  drop_coeff = 1.12
 },
 {
  betidx = 13,
  id = 13,
  drop_coeff = 1.24
 },
 {
  betidx = 14,
  id = 14,
  drop_coeff = 1.24
 },
 {
  betidx = 15,
  id = 15,
  drop_coeff = 1.36
 },
 {
  betidx = 16,
  id = 16,
  drop_coeff = 1.36
 },
 {
  betidx = 17,
  id = 17,
  drop_coeff = 1.48
 },
 {
  betidx = 18,
  id = 18,
  drop_coeff = 1.48
 },
 {
  betidx = 19,
  id = 19,
  drop_coeff = 1.6
 },
 {
  betidx = 20,
  id = 20,
  drop_coeff = 1.6
 },
 {
  betidx = 21,
  id = 21,
  drop_coeff = 1.72
 },
 {
  betidx = 22,
  id = 22,
  drop_coeff = 1.72
 },
 {
  betidx = 23,
  id = 23,
  drop_coeff = 1.84
 },
 {
  betidx = 24,
  id = 24,
  drop_coeff = 1.84
 },
 {
  betidx = 25,
  id = 25,
  drop_coeff = 1.96
 },
 {
  betidx = 26,
  id = 26,
  drop_coeff = 2
 },
 {
  betidx = 27,
  id = 27,
  drop_coeff = 2
 },
 {
  betidx = 28,
  id = 28,
  drop_coeff = 2
 },
 {
  betidx = 29,
  id = 29,
  drop_coeff = 2
 },
 {
  betidx = 30,
  id = 30,
  drop_coeff = 2
 },
 {
  betidx = 31,
  id = 31,
  drop_coeff = 2
 },
 {
  betidx = 32,
  id = 32,
  drop_coeff = 2
 },
 {
  betidx = 33,
  id = 33,
  drop_coeff = 2
 },
 {
  betidx = 34,
  id = 34,
  drop_coeff = 2
 },
 {
  betidx = 35,
  id = 35,
  drop_coeff = 2
 },
 {
  betidx = 36,
  id = 36,
  drop_coeff = 2
 },
 {
  betidx = 37,
  id = 37,
  drop_coeff = 2
 },
 {
  betidx = 38,
  id = 38,
  drop_coeff = 2
 },
 {
  betidx = 39,
  id = 39,
  drop_coeff = 2
 },
 {
  betidx = 40,
  id = 40,
  drop_coeff = 2
 }
}