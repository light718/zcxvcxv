return{
 
 {
  level = 1,
  need_exp = 0,
  id = 1,
  rarity = 1
 },
 {
  level = 2,
  need_exp = 2816,
  id = 2,
  rarity = 1
 },
 {
  level = 3,
  need_exp = 2848,
  id = 3,
  rarity = 1
 },
 {
  level = 4,
  need_exp = 2848,
  id = 4,
  rarity = 1
 },
 {
  level = 5,
  need_exp = 2880,
  id = 5,
  rarity = 1
 },
 {
  level = 6,
  need_exp = 2880,
  id = 6,
  rarity = 1
 },
 {
  level = 7,
  need_exp = 2912,
  id = 7,
  rarity = 1
 },
 {
  level = 8,
  need_exp = 2944,
  id = 8,
  rarity = 1
 },
 {
  level = 9,
  need_exp = 2976,
  id = 9,
  rarity = 1
 },
 {
  level = 10,
  need_exp = 3040,
  id = 10,
  rarity = 1
 },
 {
  level = 11,
  need_exp = 3072,
  id = 11,
  rarity = 1
 },
 {
  level = 12,
  need_exp = 3136,
  id = 12,
  rarity = 1
 },
 {
  level = 13,
  need_exp = 3168,
  id = 13,
  rarity = 1
 },
 {
  level = 14,
  need_exp = 3232,
  id = 14,
  rarity = 1
 },
 {
  level = 15,
  need_exp = 3296,
  id = 15,
  rarity = 1
 },
 {
  level = 16,
  need_exp = 3360,
  id = 16,
  rarity = 1
 },
 {
  level = 17,
  need_exp = 3424,
  id = 17,
  rarity = 1
 },
 {
  level = 18,
  need_exp = 3488,
  id = 18,
  rarity = 1
 },
 {
  level = 19,
  need_exp = 3584,
  id = 19,
  rarity = 1
 },
 {
  level = 20,
  need_exp = 3648,
  id = 20,
  rarity = 1
 },
 {
  level = 21,
  need_exp = 3744,
  id = 21,
  rarity = 1
 },
 {
  level = 22,
  need_exp = 3840,
  id = 22,
  rarity = 1
 },
 {
  level = 23,
  need_exp = 3936,
  id = 23,
  rarity = 1
 },
 {
  level = 24,
  need_exp = 4032,
  id = 24,
  rarity = 1
 },
 {
  level = 25,
  need_exp = 4128,
  id = 25,
  rarity = 1
 },
 {
  level = 26,
  need_exp = 4256,
  id = 26,
  rarity = 1
 },
 {
  level = 27,
  need_exp = 4352,
  id = 27,
  rarity = 1
 },
 {
  level = 28,
  need_exp = 4480,
  id = 28,
  rarity = 1
 },
 {
  level = 29,
  need_exp = 4608,
  id = 29,
  rarity = 1
 },
 {
  level = 30,
  need_exp = 4704,
  id = 30,
  rarity = 1
 },
 {
  level = 31,
  need_exp = 4832,
  id = 31,
  rarity = 1
 },
 {
  level = 32,
  need_exp = 4992,
  id = 32,
  rarity = 1
 },
 {
  level = 33,
  need_exp = 5120,
  id = 33,
  rarity = 1
 },
 {
  level = 34,
  need_exp = 5248,
  id = 34,
  rarity = 1
 },
 {
  level = 35,
  need_exp = 5408,
  id = 35,
  rarity = 1
 },
 {
  level = 36,
  need_exp = 5568,
  id = 36,
  rarity = 1
 },
 {
  level = 37,
  need_exp = 5696,
  id = 37,
  rarity = 1
 },
 {
  level = 38,
  need_exp = 5856,
  id = 38,
  rarity = 1
 },
 {
  level = 39,
  need_exp = 6016,
  id = 39,
  rarity = 1
 },
 {
  level = 40,
  need_exp = 6208,
  id = 40,
  rarity = 1
 },
 {
  level = 41,
  need_exp = 6368,
  id = 41,
  rarity = 1
 },
 {
  level = 42,
  need_exp = 6528,
  id = 42,
  rarity = 1
 },
 {
  level = 43,
  need_exp = 6720,
  id = 43,
  rarity = 1
 },
 {
  level = 44,
  need_exp = 6912,
  id = 44,
  rarity = 1
 },
 {
  level = 45,
  need_exp = 7104,
  id = 45,
  rarity = 1
 },
 {
  level = 46,
  need_exp = 7296,
  id = 46,
  rarity = 1
 },
 {
  level = 47,
  need_exp = 7488,
  id = 47,
  rarity = 1
 },
 {
  level = 48,
  need_exp = 7680,
  id = 48,
  rarity = 1
 },
 {
  level = 49,
  need_exp = 7872,
  id = 49,
  rarity = 1
 },
 {
  level = 50,
  need_exp = 8096,
  id = 50,
  rarity = 1
 },
 {
  level = 51,
  need_exp = 8320,
  id = 51,
  rarity = 1
 },
 {
  level = 52,
  need_exp = 8512,
  id = 52,
  rarity = 1
 },
 {
  level = 53,
  need_exp = 8736,
  id = 53,
  rarity = 1
 },
 {
  level = 54,
  need_exp = 8960,
  id = 54,
  rarity = 1
 },
 {
  level = 55,
  need_exp = 9216,
  id = 55,
  rarity = 1
 },
 {
  level = 56,
  need_exp = 9440,
  id = 56,
  rarity = 1
 },
 {
  level = 57,
  need_exp = 9664,
  id = 57,
  rarity = 1
 },
 {
  level = 58,
  need_exp = 9920,
  id = 58,
  rarity = 1
 },
 {
  level = 59,
  need_exp = 10176,
  id = 59,
  rarity = 1
 },
 {
  level = 60,
  need_exp = 10432,
  id = 60,
  rarity = 1
 },
 {
  level = 61,
  need_exp = 10688,
  id = 61,
  rarity = 1
 },
 {
  level = 62,
  need_exp = 10944,
  id = 62,
  rarity = 1
 },
 {
  level = 63,
  need_exp = 11200,
  id = 63,
  rarity = 1
 },
 {
  level = 64,
  need_exp = 11456,
  id = 64,
  rarity = 1
 },
 {
  level = 65,
  need_exp = 11744,
  id = 65,
  rarity = 1
 },
 {
  level = 66,
  need_exp = 12000,
  id = 66,
  rarity = 1
 },
 {
  level = 67,
  need_exp = 12288,
  id = 67,
  rarity = 1
 },
 {
  level = 68,
  need_exp = 12576,
  id = 68,
  rarity = 1
 },
 {
  level = 69,
  need_exp = 12864,
  id = 69,
  rarity = 1
 },
 {
  level = 70,
  need_exp = 13152,
  id = 70,
  rarity = 1
 },
 {
  level = 71,
  need_exp = 13472,
  id = 71,
  rarity = 1
 },
 {
  level = 72,
  need_exp = 13760,
  id = 72,
  rarity = 1
 },
 {
  level = 73,
  need_exp = 14080,
  id = 73,
  rarity = 1
 },
 {
  level = 74,
  need_exp = 14368,
  id = 74,
  rarity = 1
 },
 {
  level = 75,
  need_exp = 14688,
  id = 75,
  rarity = 1
 },
 {
  level = 76,
  need_exp = 15008,
  id = 76,
  rarity = 1
 },
 {
  level = 77,
  need_exp = 15328,
  id = 77,
  rarity = 1
 },
 {
  level = 78,
  need_exp = 15680,
  id = 78,
  rarity = 1
 },
 {
  level = 79,
  need_exp = 16000,
  id = 79,
  rarity = 1
 },
 {
  level = 80,
  need_exp = 16320,
  id = 80,
  rarity = 1
 },
 {
  level = 81,
  need_exp = 16672,
  id = 81,
  rarity = 1
 },
 {
  level = 82,
  need_exp = 17024,
  id = 82,
  rarity = 1
 },
 {
  level = 83,
  need_exp = 17376,
  id = 83,
  rarity = 1
 },
 {
  level = 84,
  need_exp = 17728,
  id = 84,
  rarity = 1
 },
 {
  level = 85,
  need_exp = 18080,
  id = 85,
  rarity = 1
 },
 {
  level = 86,
  need_exp = 18432,
  id = 86,
  rarity = 1
 },
 {
  level = 87,
  need_exp = 18816,
  id = 87,
  rarity = 1
 },
 {
  level = 88,
  need_exp = 19168,
  id = 88,
  rarity = 1
 },
 {
  level = 89,
  need_exp = 19552,
  id = 89,
  rarity = 1
 },
 {
  level = 90,
  need_exp = 19936,
  id = 90,
  rarity = 1
 },
 {
  level = 91,
  need_exp = 20320,
  id = 91,
  rarity = 1
 },
 {
  level = 92,
  need_exp = 20704,
  id = 92,
  rarity = 1
 },
 {
  level = 93,
  need_exp = 21088,
  id = 93,
  rarity = 1
 },
 {
  level = 94,
  need_exp = 21472,
  id = 94,
  rarity = 1
 },
 {
  level = 95,
  need_exp = 21888,
  id = 95,
  rarity = 1
 },
 {
  level = 96,
  need_exp = 22272,
  id = 96,
  rarity = 1
 },
 {
  level = 97,
  need_exp = 22688,
  id = 97,
  rarity = 1
 },
 {
  level = 98,
  need_exp = 23104,
  id = 98,
  rarity = 1
 },
 {
  level = 99,
  need_exp = 23520,
  id = 99,
  rarity = 1
 },
 {
  level = 100,
  need_exp = 23936,
  id = 100,
  rarity = 1
 },
 {
  level = 1,
  need_exp = 0,
  id = 101,
  rarity = 2
 },
 {
  level = 2,
  need_exp = 2688,
  id = 102,
  rarity = 2
 },
 {
  level = 3,
  need_exp = 2720,
  id = 103,
  rarity = 2
 },
 {
  level = 4,
  need_exp = 2720,
  id = 104,
  rarity = 2
 },
 {
  level = 5,
  need_exp = 2752,
  id = 105,
  rarity = 2
 },
 {
  level = 6,
  need_exp = 2752,
  id = 106,
  rarity = 2
 },
 {
  level = 7,
  need_exp = 2784,
  id = 107,
  rarity = 2
 },
 {
  level = 8,
  need_exp = 2816,
  id = 108,
  rarity = 2
 },
 {
  level = 9,
  need_exp = 2848,
  id = 109,
  rarity = 2
 },
 {
  level = 10,
  need_exp = 2880,
  id = 110,
  rarity = 2
 },
 {
  level = 11,
  need_exp = 2944,
  id = 111,
  rarity = 2
 },
 {
  level = 12,
  need_exp = 2976,
  id = 112,
  rarity = 2
 },
 {
  level = 13,
  need_exp = 3040,
  id = 113,
  rarity = 2
 },
 {
  level = 14,
  need_exp = 3072,
  id = 114,
  rarity = 2
 },
 {
  level = 15,
  need_exp = 3136,
  id = 115,
  rarity = 2
 },
 {
  level = 16,
  need_exp = 3200,
  id = 116,
  rarity = 2
 },
 {
  level = 17,
  need_exp = 3264,
  id = 117,
  rarity = 2
 },
 {
  level = 18,
  need_exp = 3328,
  id = 118,
  rarity = 2
 },
 {
  level = 19,
  need_exp = 3424,
  id = 119,
  rarity = 2
 },
 {
  level = 20,
  need_exp = 3488,
  id = 120,
  rarity = 2
 },
 {
  level = 21,
  need_exp = 3584,
  id = 121,
  rarity = 2
 },
 {
  level = 22,
  need_exp = 3648,
  id = 122,
  rarity = 2
 },
 {
  level = 23,
  need_exp = 3744,
  id = 123,
  rarity = 2
 },
 {
  level = 24,
  need_exp = 3840,
  id = 124,
  rarity = 2
 },
 {
  level = 25,
  need_exp = 3936,
  id = 125,
  rarity = 2
 },
 {
  level = 26,
  need_exp = 4064,
  id = 126,
  rarity = 2
 },
 {
  level = 27,
  need_exp = 4160,
  id = 127,
  rarity = 2
 },
 {
  level = 28,
  need_exp = 4256,
  id = 128,
  rarity = 2
 },
 {
  level = 29,
  need_exp = 4384,
  id = 129,
  rarity = 2
 },
 {
  level = 30,
  need_exp = 4512,
  id = 130,
  rarity = 2
 },
 {
  level = 31,
  need_exp = 4640,
  id = 131,
  rarity = 2
 },
 {
  level = 32,
  need_exp = 4768,
  id = 132,
  rarity = 2
 },
 {
  level = 33,
  need_exp = 4896,
  id = 133,
  rarity = 2
 },
 {
  level = 34,
  need_exp = 5024,
  id = 134,
  rarity = 2
 },
 {
  level = 35,
  need_exp = 5152,
  id = 135,
  rarity = 2
 },
 {
  level = 36,
  need_exp = 5312,
  id = 136,
  rarity = 2
 },
 {
  level = 37,
  need_exp = 5440,
  id = 137,
  rarity = 2
 },
 {
  level = 38,
  need_exp = 5600,
  id = 138,
  rarity = 2
 },
 {
  level = 39,
  need_exp = 5760,
  id = 139,
  rarity = 2
 },
 {
  level = 40,
  need_exp = 5920,
  id = 140,
  rarity = 2
 },
 {
  level = 41,
  need_exp = 6080,
  id = 141,
  rarity = 2
 },
 {
  level = 42,
  need_exp = 6240,
  id = 142,
  rarity = 2
 },
 {
  level = 43,
  need_exp = 6400,
  id = 143,
  rarity = 2
 },
 {
  level = 44,
  need_exp = 6592,
  id = 144,
  rarity = 2
 },
 {
  level = 45,
  need_exp = 6784,
  id = 145,
  rarity = 2
 },
 {
  level = 46,
  need_exp = 6944,
  id = 146,
  rarity = 2
 },
 {
  level = 47,
  need_exp = 7136,
  id = 147,
  rarity = 2
 },
 {
  level = 48,
  need_exp = 7328,
  id = 148,
  rarity = 2
 },
 {
  level = 49,
  need_exp = 7520,
  id = 149,
  rarity = 2
 },
 {
  level = 50,
  need_exp = 7744,
  id = 150,
  rarity = 2
 },
 {
  level = 51,
  need_exp = 7936,
  id = 151,
  rarity = 2
 },
 {
  level = 52,
  need_exp = 8128,
  id = 152,
  rarity = 2
 },
 {
  level = 53,
  need_exp = 8352,
  id = 153,
  rarity = 2
 },
 {
  level = 54,
  need_exp = 8576,
  id = 154,
  rarity = 2
 },
 {
  level = 55,
  need_exp = 8800,
  id = 155,
  rarity = 2
 },
 {
  level = 56,
  need_exp = 9024,
  id = 156,
  rarity = 2
 },
 {
  level = 57,
  need_exp = 9248,
  id = 157,
  rarity = 2
 },
 {
  level = 58,
  need_exp = 9472,
  id = 158,
  rarity = 2
 },
 {
  level = 59,
  need_exp = 9696,
  id = 159,
  rarity = 2
 },
 {
  level = 60,
  need_exp = 9952,
  id = 160,
  rarity = 2
 },
 {
  level = 61,
  need_exp = 10176,
  id = 161,
  rarity = 2
 },
 {
  level = 62,
  need_exp = 10432,
  id = 162,
  rarity = 2
 },
 {
  level = 63,
  need_exp = 10688,
  id = 163,
  rarity = 2
 },
 {
  level = 64,
  need_exp = 10944,
  id = 164,
  rarity = 2
 },
 {
  level = 65,
  need_exp = 11200,
  id = 165,
  rarity = 2
 },
 {
  level = 66,
  need_exp = 11456,
  id = 166,
  rarity = 2
 },
 {
  level = 67,
  need_exp = 11744,
  id = 167,
  rarity = 2
 },
 {
  level = 68,
  need_exp = 12000,
  id = 168,
  rarity = 2
 },
 {
  level = 69,
  need_exp = 12288,
  id = 169,
  rarity = 2
 },
 {
  level = 70,
  need_exp = 12576,
  id = 170,
  rarity = 2
 },
 {
  level = 71,
  need_exp = 12864,
  id = 171,
  rarity = 2
 },
 {
  level = 72,
  need_exp = 13152,
  id = 172,
  rarity = 2
 },
 {
  level = 73,
  need_exp = 13440,
  id = 173,
  rarity = 2
 },
 {
  level = 74,
  need_exp = 13728,
  id = 174,
  rarity = 2
 },
 {
  level = 75,
  need_exp = 14016,
  id = 175,
  rarity = 2
 },
 {
  level = 76,
  need_exp = 14336,
  id = 176,
  rarity = 2
 },
 {
  level = 77,
  need_exp = 14656,
  id = 177,
  rarity = 2
 },
 {
  level = 78,
  need_exp = 14944,
  id = 178,
  rarity = 2
 },
 {
  level = 79,
  need_exp = 15264,
  id = 179,
  rarity = 2
 },
 {
  level = 80,
  need_exp = 15584,
  id = 180,
  rarity = 2
 },
 {
  level = 81,
  need_exp = 15904,
  id = 181,
  rarity = 2
 },
 {
  level = 82,
  need_exp = 16256,
  id = 182,
  rarity = 2
 },
 {
  level = 83,
  need_exp = 16576,
  id = 183,
  rarity = 2
 },
 {
  level = 84,
  need_exp = 16928,
  id = 184,
  rarity = 2
 },
 {
  level = 85,
  need_exp = 17248,
  id = 185,
  rarity = 2
 },
 {
  level = 86,
  need_exp = 17600,
  id = 186,
  rarity = 2
 },
 {
  level = 87,
  need_exp = 17952,
  id = 187,
  rarity = 2
 },
 {
  level = 88,
  need_exp = 18304,
  id = 188,
  rarity = 2
 },
 {
  level = 89,
  need_exp = 18656,
  id = 189,
  rarity = 2
 },
 {
  level = 90,
  need_exp = 19008,
  id = 190,
  rarity = 2
 },
 {
  level = 91,
  need_exp = 19392,
  id = 191,
  rarity = 2
 },
 {
  level = 92,
  need_exp = 19744,
  id = 192,
  rarity = 2
 },
 {
  level = 93,
  need_exp = 20128,
  id = 193,
  rarity = 2
 },
 {
  level = 94,
  need_exp = 20512,
  id = 194,
  rarity = 2
 },
 {
  level = 95,
  need_exp = 20896,
  id = 195,
  rarity = 2
 },
 {
  level = 96,
  need_exp = 21280,
  id = 196,
  rarity = 2
 },
 {
  level = 97,
  need_exp = 21664,
  id = 197,
  rarity = 2
 },
 {
  level = 98,
  need_exp = 22048,
  id = 198,
  rarity = 2
 },
 {
  level = 99,
  need_exp = 22432,
  id = 199,
  rarity = 2
 },
 {
  level = 100,
  need_exp = 22848,
  id = 200,
  rarity = 2
 },
 {
  level = 1,
  need_exp = 0,
  id = 201,
  rarity = 3
 },
 {
  level = 2,
  need_exp = 2560,
  id = 202,
  rarity = 3
 },
 {
  level = 3,
  need_exp = 2592,
  id = 203,
  rarity = 3
 },
 {
  level = 4,
  need_exp = 2592,
  id = 204,
  rarity = 3
 },
 {
  level = 5,
  need_exp = 2624,
  id = 205,
  rarity = 3
 },
 {
  level = 6,
  need_exp = 2624,
  id = 206,
  rarity = 3
 },
 {
  level = 7,
  need_exp = 2656,
  id = 207,
  rarity = 3
 },
 {
  level = 8,
  need_exp = 2688,
  id = 208,
  rarity = 3
 },
 {
  level = 9,
  need_exp = 2720,
  id = 209,
  rarity = 3
 },
 {
  level = 10,
  need_exp = 2752,
  id = 210,
  rarity = 3
 },
 {
  level = 11,
  need_exp = 2784,
  id = 211,
  rarity = 3
 },
 {
  level = 12,
  need_exp = 2848,
  id = 212,
  rarity = 3
 },
 {
  level = 13,
  need_exp = 2880,
  id = 213,
  rarity = 3
 },
 {
  level = 14,
  need_exp = 2944,
  id = 214,
  rarity = 3
 },
 {
  level = 15,
  need_exp = 3008,
  id = 215,
  rarity = 3
 },
 {
  level = 16,
  need_exp = 3040,
  id = 216,
  rarity = 3
 },
 {
  level = 17,
  need_exp = 3104,
  id = 217,
  rarity = 3
 },
 {
  level = 18,
  need_exp = 3168,
  id = 218,
  rarity = 3
 },
 {
  level = 19,
  need_exp = 3264,
  id = 219,
  rarity = 3
 },
 {
  level = 20,
  need_exp = 3328,
  id = 220,
  rarity = 3
 },
 {
  level = 21,
  need_exp = 3392,
  id = 221,
  rarity = 3
 },
 {
  level = 22,
  need_exp = 3488,
  id = 222,
  rarity = 3
 },
 {
  level = 23,
  need_exp = 3584,
  id = 223,
  rarity = 3
 },
 {
  level = 24,
  need_exp = 3680,
  id = 224,
  rarity = 3
 },
 {
  level = 25,
  need_exp = 3776,
  id = 225,
  rarity = 3
 },
 {
  level = 26,
  need_exp = 3872,
  id = 226,
  rarity = 3
 },
 {
  level = 27,
  need_exp = 3968,
  id = 227,
  rarity = 3
 },
 {
  level = 28,
  need_exp = 4064,
  id = 228,
  rarity = 3
 },
 {
  level = 29,
  need_exp = 4160,
  id = 229,
  rarity = 3
 },
 {
  level = 30,
  need_exp = 4288,
  id = 230,
  rarity = 3
 },
 {
  level = 31,
  need_exp = 4416,
  id = 231,
  rarity = 3
 },
 {
  level = 32,
  need_exp = 4512,
  id = 232,
  rarity = 3
 },
 {
  level = 33,
  need_exp = 4640,
  id = 233,
  rarity = 3
 },
 {
  level = 34,
  need_exp = 4768,
  id = 234,
  rarity = 3
 },
 {
  level = 35,
  need_exp = 4928,
  id = 235,
  rarity = 3
 },
 {
  level = 36,
  need_exp = 5056,
  id = 236,
  rarity = 3
 },
 {
  level = 37,
  need_exp = 5184,
  id = 237,
  rarity = 3
 },
 {
  level = 38,
  need_exp = 5344,
  id = 238,
  rarity = 3
 },
 {
  level = 39,
  need_exp = 5472,
  id = 239,
  rarity = 3
 },
 {
  level = 40,
  need_exp = 5632,
  id = 240,
  rarity = 3
 },
 {
  level = 41,
  need_exp = 5792,
  id = 241,
  rarity = 3
 },
 {
  level = 42,
  need_exp = 5952,
  id = 242,
  rarity = 3
 },
 {
  level = 43,
  need_exp = 6112,
  id = 243,
  rarity = 3
 },
 {
  level = 44,
  need_exp = 6272,
  id = 244,
  rarity = 3
 },
 {
  level = 45,
  need_exp = 6464,
  id = 245,
  rarity = 3
 },
 {
  level = 46,
  need_exp = 6624,
  id = 246,
  rarity = 3
 },
 {
  level = 47,
  need_exp = 6816,
  id = 247,
  rarity = 3
 },
 {
  level = 48,
  need_exp = 6976,
  id = 248,
  rarity = 3
 },
 {
  level = 49,
  need_exp = 7168,
  id = 249,
  rarity = 3
 },
 {
  level = 50,
  need_exp = 7360,
  id = 250,
  rarity = 3
 },
 {
  level = 51,
  need_exp = 7552,
  id = 251,
  rarity = 3
 },
 {
  level = 52,
  need_exp = 7744,
  id = 252,
  rarity = 3
 },
 {
  level = 53,
  need_exp = 7968,
  id = 253,
  rarity = 3
 },
 {
  level = 54,
  need_exp = 8160,
  id = 254,
  rarity = 3
 },
 {
  level = 55,
  need_exp = 8384,
  id = 255,
  rarity = 3
 },
 {
  level = 56,
  need_exp = 8576,
  id = 256,
  rarity = 3
 },
 {
  level = 57,
  need_exp = 8800,
  id = 257,
  rarity = 3
 },
 {
  level = 58,
  need_exp = 9024,
  id = 258,
  rarity = 3
 },
 {
  level = 59,
  need_exp = 9248,
  id = 259,
  rarity = 3
 },
 {
  level = 60,
  need_exp = 9472,
  id = 260,
  rarity = 3
 },
 {
  level = 61,
  need_exp = 9696,
  id = 261,
  rarity = 3
 },
 {
  level = 62,
  need_exp = 9952,
  id = 262,
  rarity = 3
 },
 {
  level = 63,
  need_exp = 10176,
  id = 263,
  rarity = 3
 },
 {
  level = 64,
  need_exp = 10432,
  id = 264,
  rarity = 3
 },
 {
  level = 65,
  need_exp = 10688,
  id = 265,
  rarity = 3
 },
 {
  level = 66,
  need_exp = 10912,
  id = 266,
  rarity = 3
 },
 {
  level = 67,
  need_exp = 11168,
  id = 267,
  rarity = 3
 },
 {
  level = 68,
  need_exp = 11424,
  id = 268,
  rarity = 3
 },
 {
  level = 69,
  need_exp = 11712,
  id = 269,
  rarity = 3
 },
 {
  level = 70,
  need_exp = 11968,
  id = 270,
  rarity = 3
 },
 {
  level = 71,
  need_exp = 12224,
  id = 271,
  rarity = 3
 },
 {
  level = 72,
  need_exp = 12512,
  id = 272,
  rarity = 3
 },
 {
  level = 73,
  need_exp = 12800,
  id = 273,
  rarity = 3
 },
 {
  level = 74,
  need_exp = 13088,
  id = 274,
  rarity = 3
 },
 {
  level = 75,
  need_exp = 13376,
  id = 275,
  rarity = 3
 },
 {
  level = 76,
  need_exp = 13664,
  id = 276,
  rarity = 3
 },
 {
  level = 77,
  need_exp = 13952,
  id = 277,
  rarity = 3
 },
 {
  level = 78,
  need_exp = 14240,
  id = 278,
  rarity = 3
 },
 {
  level = 79,
  need_exp = 14528,
  id = 279,
  rarity = 3
 },
 {
  level = 80,
  need_exp = 14848,
  id = 280,
  rarity = 3
 },
 {
  level = 81,
  need_exp = 15168,
  id = 281,
  rarity = 3
 },
 {
  level = 82,
  need_exp = 15456,
  id = 282,
  rarity = 3
 },
 {
  level = 83,
  need_exp = 15776,
  id = 283,
  rarity = 3
 },
 {
  level = 84,
  need_exp = 16096,
  id = 284,
  rarity = 3
 },
 {
  level = 85,
  need_exp = 16448,
  id = 285,
  rarity = 3
 },
 {
  level = 86,
  need_exp = 16768,
  id = 286,
  rarity = 3
 },
 {
  level = 87,
  need_exp = 17088,
  id = 287,
  rarity = 3
 },
 {
  level = 88,
  need_exp = 17440,
  id = 288,
  rarity = 3
 },
 {
  level = 89,
  need_exp = 17760,
  id = 289,
  rarity = 3
 },
 {
  level = 90,
  need_exp = 18112,
  id = 290,
  rarity = 3
 },
 {
  level = 91,
  need_exp = 18464,
  id = 291,
  rarity = 3
 },
 {
  level = 92,
  need_exp = 18816,
  id = 292,
  rarity = 3
 },
 {
  level = 93,
  need_exp = 19168,
  id = 293,
  rarity = 3
 },
 {
  level = 94,
  need_exp = 19520,
  id = 294,
  rarity = 3
 },
 {
  level = 95,
  need_exp = 19904,
  id = 295,
  rarity = 3
 },
 {
  level = 96,
  need_exp = 20256,
  id = 296,
  rarity = 3
 },
 {
  level = 97,
  need_exp = 20640,
  id = 297,
  rarity = 3
 },
 {
  level = 98,
  need_exp = 20992,
  id = 298,
  rarity = 3
 },
 {
  level = 99,
  need_exp = 21376,
  id = 299,
  rarity = 3
 },
 {
  level = 100,
  need_exp = 21760,
  id = 300,
  rarity = 3
 },
 {
  level = 1,
  need_exp = 0,
  id = 301,
  rarity = 4
 },
 {
  level = 2,
  need_exp = 2432,
  id = 302,
  rarity = 4
 },
 {
  level = 3,
  need_exp = 2464,
  id = 303,
  rarity = 4
 },
 {
  level = 4,
  need_exp = 2464,
  id = 304,
  rarity = 4
 },
 {
  level = 5,
  need_exp = 2464,
  id = 305,
  rarity = 4
 },
 {
  level = 6,
  need_exp = 2496,
  id = 306,
  rarity = 4
 },
 {
  level = 7,
  need_exp = 2528,
  id = 307,
  rarity = 4
 },
 {
  level = 8,
  need_exp = 2560,
  id = 308,
  rarity = 4
 },
 {
  level = 9,
  need_exp = 2592,
  id = 309,
  rarity = 4
 },
 {
  level = 10,
  need_exp = 2624,
  id = 310,
  rarity = 4
 },
 {
  level = 11,
  need_exp = 2656,
  id = 311,
  rarity = 4
 },
 {
  level = 12,
  need_exp = 2688,
  id = 312,
  rarity = 4
 },
 {
  level = 13,
  need_exp = 2752,
  id = 313,
  rarity = 4
 },
 {
  level = 14,
  need_exp = 2784,
  id = 314,
  rarity = 4
 },
 {
  level = 15,
  need_exp = 2848,
  id = 315,
  rarity = 4
 },
 {
  level = 16,
  need_exp = 2912,
  id = 316,
  rarity = 4
 },
 {
  level = 17,
  need_exp = 2944,
  id = 317,
  rarity = 4
 },
 {
  level = 18,
  need_exp = 3008,
  id = 318,
  rarity = 4
 },
 {
  level = 19,
  need_exp = 3104,
  id = 319,
  rarity = 4
 },
 {
  level = 20,
  need_exp = 3168,
  id = 320,
  rarity = 4
 },
 {
  level = 21,
  need_exp = 3232,
  id = 321,
  rarity = 4
 },
 {
  level = 22,
  need_exp = 3328,
  id = 322,
  rarity = 4
 },
 {
  level = 23,
  need_exp = 3392,
  id = 323,
  rarity = 4
 },
 {
  level = 24,
  need_exp = 3488,
  id = 324,
  rarity = 4
 },
 {
  level = 25,
  need_exp = 3584,
  id = 325,
  rarity = 4
 },
 {
  level = 26,
  need_exp = 3680,
  id = 326,
  rarity = 4
 },
 {
  level = 27,
  need_exp = 3776,
  id = 327,
  rarity = 4
 },
 {
  level = 28,
  need_exp = 3872,
  id = 328,
  rarity = 4
 },
 {
  level = 29,
  need_exp = 3968,
  id = 329,
  rarity = 4
 },
 {
  level = 30,
  need_exp = 4064,
  id = 330,
  rarity = 4
 },
 {
  level = 31,
  need_exp = 4192,
  id = 331,
  rarity = 4
 },
 {
  level = 32,
  need_exp = 4288,
  id = 332,
  rarity = 4
 },
 {
  level = 33,
  need_exp = 4416,
  id = 333,
  rarity = 4
 },
 {
  level = 34,
  need_exp = 4544,
  id = 334,
  rarity = 4
 },
 {
  level = 35,
  need_exp = 4672,
  id = 335,
  rarity = 4
 },
 {
  level = 36,
  need_exp = 4800,
  id = 336,
  rarity = 4
 },
 {
  level = 37,
  need_exp = 4928,
  id = 337,
  rarity = 4
 },
 {
  level = 38,
  need_exp = 5056,
  id = 338,
  rarity = 4
 },
 {
  level = 39,
  need_exp = 5216,
  id = 339,
  rarity = 4
 },
 {
  level = 40,
  need_exp = 5344,
  id = 340,
  rarity = 4
 },
 {
  level = 41,
  need_exp = 5504,
  id = 341,
  rarity = 4
 },
 {
  level = 42,
  need_exp = 5664,
  id = 342,
  rarity = 4
 },
 {
  level = 43,
  need_exp = 5792,
  id = 343,
  rarity = 4
 },
 {
  level = 44,
  need_exp = 5952,
  id = 344,
  rarity = 4
 },
 {
  level = 45,
  need_exp = 6112,
  id = 345,
  rarity = 4
 },
 {
  level = 46,
  need_exp = 6304,
  id = 346,
  rarity = 4
 },
 {
  level = 47,
  need_exp = 6464,
  id = 347,
  rarity = 4
 },
 {
  level = 48,
  need_exp = 6624,
  id = 348,
  rarity = 4
 },
 {
  level = 49,
  need_exp = 6816,
  id = 349,
  rarity = 4
 },
 {
  level = 50,
  need_exp = 7008,
  id = 350,
  rarity = 4
 },
 {
  level = 51,
  need_exp = 7168,
  id = 351,
  rarity = 4
 },
 {
  level = 52,
  need_exp = 7360,
  id = 352,
  rarity = 4
 },
 {
  level = 53,
  need_exp = 7552,
  id = 353,
  rarity = 4
 },
 {
  level = 54,
  need_exp = 7744,
  id = 354,
  rarity = 4
 },
 {
  level = 55,
  need_exp = 7936,
  id = 355,
  rarity = 4
 },
 {
  level = 56,
  need_exp = 8160,
  id = 356,
  rarity = 4
 },
 {
  level = 57,
  need_exp = 8352,
  id = 357,
  rarity = 4
 },
 {
  level = 58,
  need_exp = 8576,
  id = 358,
  rarity = 4
 },
 {
  level = 59,
  need_exp = 8768,
  id = 359,
  rarity = 4
 },
 {
  level = 60,
  need_exp = 8992,
  id = 360,
  rarity = 4
 },
 {
  level = 61,
  need_exp = 9216,
  id = 361,
  rarity = 4
 },
 {
  level = 62,
  need_exp = 9440,
  id = 362,
  rarity = 4
 },
 {
  level = 63,
  need_exp = 9664,
  id = 363,
  rarity = 4
 },
 {
  level = 64,
  need_exp = 9888,
  id = 364,
  rarity = 4
 },
 {
  level = 65,
  need_exp = 10144,
  id = 365,
  rarity = 4
 },
 {
  level = 66,
  need_exp = 10368,
  id = 366,
  rarity = 4
 },
 {
  level = 67,
  need_exp = 10624,
  id = 367,
  rarity = 4
 },
 {
  level = 68,
  need_exp = 10880,
  id = 368,
  rarity = 4
 },
 {
  level = 69,
  need_exp = 11104,
  id = 369,
  rarity = 4
 },
 {
  level = 70,
  need_exp = 11360,
  id = 370,
  rarity = 4
 },
 {
  level = 71,
  need_exp = 11616,
  id = 371,
  rarity = 4
 },
 {
  level = 72,
  need_exp = 11872,
  id = 372,
  rarity = 4
 },
 {
  level = 73,
  need_exp = 12160,
  id = 373,
  rarity = 4
 },
 {
  level = 74,
  need_exp = 12416,
  id = 374,
  rarity = 4
 },
 {
  level = 75,
  need_exp = 12704,
  id = 375,
  rarity = 4
 },
 {
  level = 76,
  need_exp = 12960,
  id = 376,
  rarity = 4
 },
 {
  level = 77,
  need_exp = 13248,
  id = 377,
  rarity = 4
 },
 {
  level = 78,
  need_exp = 13536,
  id = 378,
  rarity = 4
 },
 {
  level = 79,
  need_exp = 13824,
  id = 379,
  rarity = 4
 },
 {
  level = 80,
  need_exp = 14112,
  id = 380,
  rarity = 4
 },
 {
  level = 81,
  need_exp = 14400,
  id = 381,
  rarity = 4
 },
 {
  level = 82,
  need_exp = 14688,
  id = 382,
  rarity = 4
 },
 {
  level = 83,
  need_exp = 15008,
  id = 383,
  rarity = 4
 },
 {
  level = 84,
  need_exp = 15296,
  id = 384,
  rarity = 4
 },
 {
  level = 85,
  need_exp = 15616,
  id = 385,
  rarity = 4
 },
 {
  level = 86,
  need_exp = 15936,
  id = 386,
  rarity = 4
 },
 {
  level = 87,
  need_exp = 16224,
  id = 387,
  rarity = 4
 },
 {
  level = 88,
  need_exp = 16544,
  id = 388,
  rarity = 4
 },
 {
  level = 89,
  need_exp = 16864,
  id = 389,
  rarity = 4
 },
 {
  level = 90,
  need_exp = 17216,
  id = 390,
  rarity = 4
 },
 {
  level = 91,
  need_exp = 17536,
  id = 391,
  rarity = 4
 },
 {
  level = 92,
  need_exp = 17856,
  id = 392,
  rarity = 4
 },
 {
  level = 93,
  need_exp = 18208,
  id = 393,
  rarity = 4
 },
 {
  level = 94,
  need_exp = 18560,
  id = 394,
  rarity = 4
 },
 {
  level = 95,
  need_exp = 18880,
  id = 395,
  rarity = 4
 },
 {
  level = 96,
  need_exp = 19232,
  id = 396,
  rarity = 4
 },
 {
  level = 97,
  need_exp = 19584,
  id = 397,
  rarity = 4
 },
 {
  level = 98,
  need_exp = 19936,
  id = 398,
  rarity = 4
 },
 {
  level = 99,
  need_exp = 20320,
  id = 399,
  rarity = 4
 },
 {
  level = 100,
  need_exp = 20672,
  id = 400,
  rarity = 4
 },
 {
  level = 1,
  need_exp = 0,
  id = 401,
  rarity = 5
 },
 {
  level = 2,
  need_exp = 2304,
  id = 402,
  rarity = 5
 },
 {
  level = 3,
  need_exp = 2304,
  id = 403,
  rarity = 5
 },
 {
  level = 4,
  need_exp = 2336,
  id = 404,
  rarity = 5
 },
 {
  level = 5,
  need_exp = 2336,
  id = 405,
  rarity = 5
 },
 {
  level = 6,
  need_exp = 2368,
  id = 406,
  rarity = 5
 },
 {
  level = 7,
  need_exp = 2400,
  id = 407,
  rarity = 5
 },
 {
  level = 8,
  need_exp = 2400,
  id = 408,
  rarity = 5
 },
 {
  level = 9,
  need_exp = 2432,
  id = 409,
  rarity = 5
 },
 {
  level = 10,
  need_exp = 2464,
  id = 410,
  rarity = 5
 },
 {
  level = 11,
  need_exp = 2528,
  id = 411,
  rarity = 5
 },
 {
  level = 12,
  need_exp = 2560,
  id = 412,
  rarity = 5
 },
 {
  level = 13,
  need_exp = 2592,
  id = 413,
  rarity = 5
 },
 {
  level = 14,
  need_exp = 2656,
  id = 414,
  rarity = 5
 },
 {
  level = 15,
  need_exp = 2688,
  id = 415,
  rarity = 5
 },
 {
  level = 16,
  need_exp = 2752,
  id = 416,
  rarity = 5
 },
 {
  level = 17,
  need_exp = 2816,
  id = 417,
  rarity = 5
 },
 {
  level = 18,
  need_exp = 2848,
  id = 418,
  rarity = 5
 },
 {
  level = 19,
  need_exp = 2912,
  id = 419,
  rarity = 5
 },
 {
  level = 20,
  need_exp = 3008,
  id = 420,
  rarity = 5
 },
 {
  level = 21,
  need_exp = 3072,
  id = 421,
  rarity = 5
 },
 {
  level = 22,
  need_exp = 3136,
  id = 422,
  rarity = 5
 },
 {
  level = 23,
  need_exp = 3232,
  id = 423,
  rarity = 5
 },
 {
  level = 24,
  need_exp = 3296,
  id = 424,
  rarity = 5
 },
 {
  level = 25,
  need_exp = 3392,
  id = 425,
  rarity = 5
 },
 {
  level = 26,
  need_exp = 3488,
  id = 426,
  rarity = 5
 },
 {
  level = 27,
  need_exp = 3552,
  id = 427,
  rarity = 5
 },
 {
  level = 28,
  need_exp = 3648,
  id = 428,
  rarity = 5
 },
 {
  level = 29,
  need_exp = 3744,
  id = 429,
  rarity = 5
 },
 {
  level = 30,
  need_exp = 3872,
  id = 430,
  rarity = 5
 },
 {
  level = 31,
  need_exp = 3968,
  id = 431,
  rarity = 5
 },
 {
  level = 32,
  need_exp = 4064,
  id = 432,
  rarity = 5
 },
 {
  level = 33,
  need_exp = 4192,
  id = 433,
  rarity = 5
 },
 {
  level = 34,
  need_exp = 4288,
  id = 434,
  rarity = 5
 },
 {
  level = 35,
  need_exp = 4416,
  id = 435,
  rarity = 5
 },
 {
  level = 36,
  need_exp = 4544,
  id = 436,
  rarity = 5
 },
 {
  level = 37,
  need_exp = 4672,
  id = 437,
  rarity = 5
 },
 {
  level = 38,
  need_exp = 4800,
  id = 438,
  rarity = 5
 },
 {
  level = 39,
  need_exp = 4928,
  id = 439,
  rarity = 5
 },
 {
  level = 40,
  need_exp = 5056,
  id = 440,
  rarity = 5
 },
 {
  level = 41,
  need_exp = 5216,
  id = 441,
  rarity = 5
 },
 {
  level = 42,
  need_exp = 5344,
  id = 442,
  rarity = 5
 },
 {
  level = 43,
  need_exp = 5504,
  id = 443,
  rarity = 5
 },
 {
  level = 44,
  need_exp = 5664,
  id = 444,
  rarity = 5
 },
 {
  level = 45,
  need_exp = 5792,
  id = 445,
  rarity = 5
 },
 {
  level = 46,
  need_exp = 5952,
  id = 446,
  rarity = 5
 },
 {
  level = 47,
  need_exp = 6112,
  id = 447,
  rarity = 5
 },
 {
  level = 48,
  need_exp = 6272,
  id = 448,
  rarity = 5
 },
 {
  level = 49,
  need_exp = 6464,
  id = 449,
  rarity = 5
 },
 {
  level = 50,
  need_exp = 6624,
  id = 450,
  rarity = 5
 },
 {
  level = 51,
  need_exp = 6784,
  id = 451,
  rarity = 5
 },
 {
  level = 52,
  need_exp = 6976,
  id = 452,
  rarity = 5
 },
 {
  level = 53,
  need_exp = 7168,
  id = 453,
  rarity = 5
 },
 {
  level = 54,
  need_exp = 7328,
  id = 454,
  rarity = 5
 },
 {
  level = 55,
  need_exp = 7520,
  id = 455,
  rarity = 5
 },
 {
  level = 56,
  need_exp = 7712,
  id = 456,
  rarity = 5
 },
 {
  level = 57,
  need_exp = 7904,
  id = 457,
  rarity = 5
 },
 {
  level = 58,
  need_exp = 8128,
  id = 458,
  rarity = 5
 },
 {
  level = 59,
  need_exp = 8320,
  id = 459,
  rarity = 5
 },
 {
  level = 60,
  need_exp = 8512,
  id = 460,
  rarity = 5
 },
 {
  level = 61,
  need_exp = 8736,
  id = 461,
  rarity = 5
 },
 {
  level = 62,
  need_exp = 8960,
  id = 462,
  rarity = 5
 },
 {
  level = 63,
  need_exp = 9152,
  id = 463,
  rarity = 5
 },
 {
  level = 64,
  need_exp = 9376,
  id = 464,
  rarity = 5
 },
 {
  level = 65,
  need_exp = 9600,
  id = 465,
  rarity = 5
 },
 {
  level = 66,
  need_exp = 9824,
  id = 466,
  rarity = 5
 },
 {
  level = 67,
  need_exp = 10048,
  id = 467,
  rarity = 5
 },
 {
  level = 68,
  need_exp = 10304,
  id = 468,
  rarity = 5
 },
 {
  level = 69,
  need_exp = 10528,
  id = 469,
  rarity = 5
 },
 {
  level = 70,
  need_exp = 10784,
  id = 470,
  rarity = 5
 },
 {
  level = 71,
  need_exp = 11008,
  id = 471,
  rarity = 5
 },
 {
  level = 72,
  need_exp = 11264,
  id = 472,
  rarity = 5
 },
 {
  level = 73,
  need_exp = 11520,
  id = 473,
  rarity = 5
 },
 {
  level = 74,
  need_exp = 11776,
  id = 474,
  rarity = 5
 },
 {
  level = 75,
  need_exp = 12032,
  id = 475,
  rarity = 5
 },
 {
  level = 76,
  need_exp = 12288,
  id = 476,
  rarity = 5
 },
 {
  level = 77,
  need_exp = 12544,
  id = 477,
  rarity = 5
 },
 {
  level = 78,
  need_exp = 12832,
  id = 478,
  rarity = 5
 },
 {
  level = 79,
  need_exp = 13088,
  id = 479,
  rarity = 5
 },
 {
  level = 80,
  need_exp = 13376,
  id = 480,
  rarity = 5
 },
 {
  level = 81,
  need_exp = 13632,
  id = 481,
  rarity = 5
 },
 {
  level = 82,
  need_exp = 13920,
  id = 482,
  rarity = 5
 },
 {
  level = 83,
  need_exp = 14208,
  id = 483,
  rarity = 5
 },
 {
  level = 84,
  need_exp = 14496,
  id = 484,
  rarity = 5
 },
 {
  level = 85,
  need_exp = 14784,
  id = 485,
  rarity = 5
 },
 {
  level = 86,
  need_exp = 15072,
  id = 486,
  rarity = 5
 },
 {
  level = 87,
  need_exp = 15392,
  id = 487,
  rarity = 5
 },
 {
  level = 88,
  need_exp = 15680,
  id = 488,
  rarity = 5
 },
 {
  level = 89,
  need_exp = 16000,
  id = 489,
  rarity = 5
 },
 {
  level = 90,
  need_exp = 16288,
  id = 490,
  rarity = 5
 },
 {
  level = 91,
  need_exp = 16608,
  id = 491,
  rarity = 5
 },
 {
  level = 92,
  need_exp = 16928,
  id = 492,
  rarity = 5
 },
 {
  level = 93,
  need_exp = 17248,
  id = 493,
  rarity = 5
 },
 {
  level = 94,
  need_exp = 17568,
  id = 494,
  rarity = 5
 },
 {
  level = 95,
  need_exp = 17888,
  id = 495,
  rarity = 5
 },
 {
  level = 96,
  need_exp = 18240,
  id = 496,
  rarity = 5
 },
 {
  level = 97,
  need_exp = 18560,
  id = 497,
  rarity = 5
 },
 {
  level = 98,
  need_exp = 18912,
  id = 498,
  rarity = 5
 },
 {
  level = 99,
  need_exp = 19232,
  id = 499,
  rarity = 5
 },
 {
  level = 100,
  need_exp = 19584,
  id = 500,
  rarity = 5
 }
}