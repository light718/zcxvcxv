return{
 
 {
  drop_weight = 2000,
  gameid = 601,
  id = 1,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 601,
  id = 2,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 601,
  id = 3,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 601,
  id = 4,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 601,
  id = 5,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 6,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 7,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 8,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 9,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 10,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 11,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 12,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 13,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 14,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 15,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 16,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 17,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 18,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 19,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 601,
  id = 20,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 21,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 22,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 23,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 24,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 25,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 26,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 27,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 28,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 29,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 30,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 31,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 32,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 33,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 34,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 35,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 36,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 37,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 38,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 39,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 40,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 41,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 42,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 43,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 601,
  id = 44,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 45,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 601,
  id = 46,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 601,
  id = 47,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 48,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 49,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 50,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 51,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 52,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 601,
  id = 53,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 54,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 55,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 56,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 57,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 58,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 59,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 60,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 61,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 62,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 63,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 64,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 65,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 66,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 67,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 601,
  id = 68,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 601,
  id = 69,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 70,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 71,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 72,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 73,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 601,
  id = 74,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 75,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 601,
  id = 76,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 77,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 78,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 79,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 601,
  id = 80,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 602,
  id = 81,
  cardid = 1001
 },
 {
  drop_weight = 2000,
  gameid = 602,
  id = 82,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 602,
  id = 83,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 602,
  id = 84,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 602,
  id = 85,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 86,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 87,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 88,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 89,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 90,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 91,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 92,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 93,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 94,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 95,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 96,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 97,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 98,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 99,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 602,
  id = 100,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 101,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 102,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 103,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 104,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 105,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 106,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 107,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 108,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 109,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 110,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 111,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 112,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 113,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 114,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 115,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 116,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 117,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 118,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 119,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 120,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 121,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 122,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 123,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 602,
  id = 124,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 125,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 602,
  id = 126,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 602,
  id = 127,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 128,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 129,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 130,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 131,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 132,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 602,
  id = 133,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 134,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 135,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 136,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 137,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 138,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 139,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 140,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 141,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 142,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 143,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 144,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 145,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 146,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 147,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 602,
  id = 148,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 602,
  id = 149,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 150,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 151,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 152,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 153,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 602,
  id = 154,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 155,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 602,
  id = 156,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 157,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 158,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 159,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 602,
  id = 160,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 603,
  id = 161,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 603,
  id = 162,
  cardid = 1002
 },
 {
  drop_weight = 2000,
  gameid = 603,
  id = 163,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 603,
  id = 164,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 603,
  id = 165,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 166,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 167,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 168,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 169,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 170,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 171,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 172,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 173,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 174,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 175,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 176,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 177,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 178,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 179,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 603,
  id = 180,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 181,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 182,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 183,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 184,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 185,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 186,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 187,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 188,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 189,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 190,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 191,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 192,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 193,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 194,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 195,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 196,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 197,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 198,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 199,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 200,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 201,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 202,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 203,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 603,
  id = 204,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 205,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 603,
  id = 206,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 603,
  id = 207,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 208,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 209,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 210,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 211,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 212,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 603,
  id = 213,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 214,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 215,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 216,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 217,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 218,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 219,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 220,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 221,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 222,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 223,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 224,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 225,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 226,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 227,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 603,
  id = 228,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 603,
  id = 229,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 230,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 231,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 232,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 233,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 603,
  id = 234,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 235,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 603,
  id = 236,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 237,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 238,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 239,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 603,
  id = 240,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 604,
  id = 241,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 604,
  id = 242,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 604,
  id = 243,
  cardid = 1003
 },
 {
  drop_weight = 2000,
  gameid = 604,
  id = 244,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 604,
  id = 245,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 246,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 247,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 248,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 249,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 250,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 251,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 252,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 253,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 254,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 255,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 256,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 257,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 258,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 259,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 604,
  id = 260,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 261,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 262,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 263,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 264,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 265,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 266,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 267,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 268,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 269,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 270,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 271,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 272,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 273,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 274,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 275,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 276,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 277,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 278,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 279,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 280,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 281,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 282,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 283,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 604,
  id = 284,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 285,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 604,
  id = 286,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 604,
  id = 287,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 288,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 289,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 290,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 291,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 292,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 604,
  id = 293,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 294,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 295,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 296,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 297,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 298,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 299,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 300,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 301,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 302,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 303,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 304,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 305,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 306,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 307,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 604,
  id = 308,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 604,
  id = 309,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 310,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 311,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 312,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 313,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 604,
  id = 314,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 315,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 604,
  id = 316,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 317,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 318,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 319,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 604,
  id = 320,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 605,
  id = 321,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 605,
  id = 322,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 605,
  id = 323,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 605,
  id = 324,
  cardid = 1004
 },
 {
  drop_weight = 2000,
  gameid = 605,
  id = 325,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 326,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 327,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 328,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 329,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 330,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 331,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 332,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 333,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 334,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 335,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 336,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 337,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 338,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 339,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 605,
  id = 340,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 341,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 342,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 343,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 344,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 345,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 346,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 347,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 348,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 349,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 350,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 351,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 352,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 353,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 354,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 355,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 356,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 357,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 358,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 359,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 360,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 361,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 362,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 363,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 605,
  id = 364,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 365,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 605,
  id = 366,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 605,
  id = 367,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 368,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 369,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 370,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 371,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 372,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 605,
  id = 373,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 374,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 375,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 376,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 377,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 378,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 379,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 380,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 381,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 382,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 383,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 384,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 385,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 386,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 387,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 605,
  id = 388,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 605,
  id = 389,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 390,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 391,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 392,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 393,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 605,
  id = 394,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 395,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 605,
  id = 396,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 397,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 398,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 399,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 605,
  id = 400,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 401,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 402,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 403,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 404,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 405,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 406,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 407,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 408,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 409,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 410,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 411,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 412,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 413,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 414,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 415,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 416,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 417,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 418,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 419,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 420,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 421,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 422,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 423,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 424,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 425,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 426,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 427,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 428,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 429,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 430,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 431,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 432,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 433,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 434,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 435,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 436,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 437,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 438,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 439,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 440,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 441,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 442,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 443,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 444,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 445,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 446,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 447,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 448,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 449,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 450,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 451,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 452,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 453,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 454,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 455,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 456,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 457,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 458,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 459,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 460,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 461,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 462,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 463,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 464,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 465,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 466,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 467,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 468,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 469,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 470,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 471,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 472,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 473,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 474,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 475,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 476,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 477,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 478,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 479,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 606,
  id = 480,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 481,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 482,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 483,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 484,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 485,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 486,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 487,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 488,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 489,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 490,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 491,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 492,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 493,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 494,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 495,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 496,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 497,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 498,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 499,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 500,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 501,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 502,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 503,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 504,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 505,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 506,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 507,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 508,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 509,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 510,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 511,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 512,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 513,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 514,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 515,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 516,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 517,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 518,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 519,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 520,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 521,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 522,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 523,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 524,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 525,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 526,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 527,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 528,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 529,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 530,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 531,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 532,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 533,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 534,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 535,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 536,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 537,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 538,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 539,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 540,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 541,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 542,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 543,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 544,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 545,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 546,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 547,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 548,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 549,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 550,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 551,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 552,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 553,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 554,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 555,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 556,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 557,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 558,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 559,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 607,
  id = 560,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 561,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 562,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 563,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 564,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 565,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 566,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 567,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 568,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 569,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 570,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 571,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 572,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 573,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 574,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 575,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 576,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 577,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 578,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 579,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 580,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 581,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 582,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 583,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 584,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 585,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 586,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 587,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 588,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 608,
  id = 589,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 608,
  id = 590,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 608,
  id = 591,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 608,
  id = 592,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 608,
  id = 593,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 608,
  id = 594,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 608,
  id = 595,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 596,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 608,
  id = 597,
  cardid = 1037
 },
 {
  drop_weight = 2000,
  gameid = 608,
  id = 598,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 599,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 600,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 608,
  id = 601,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 608,
  id = 602,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 608,
  id = 603,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 604,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 608,
  id = 605,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 606,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 607,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 608,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 609,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 610,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 611,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 612,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 613,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 614,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 615,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 616,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 617,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 618,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 619,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 620,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 621,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 608,
  id = 622,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 623,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 624,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 625,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 608,
  id = 626,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 627,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 628,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 629,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 630,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 631,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 632,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 633,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 634,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 635,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 636,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 637,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 638,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 639,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 608,
  id = 640,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 641,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 642,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 643,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 644,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 645,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 646,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 647,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 648,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 649,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 650,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 651,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 652,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 653,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 654,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 655,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 656,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 657,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 658,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 659,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 660,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 661,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 662,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 663,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 664,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 665,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 666,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 667,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 668,
  cardid = 1028
 },
 {
  drop_weight = 2000,
  gameid = 609,
  id = 669,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 609,
  id = 670,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 609,
  id = 671,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 609,
  id = 672,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 609,
  id = 673,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 609,
  id = 674,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 609,
  id = 675,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 676,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 609,
  id = 677,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 609,
  id = 678,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 679,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 680,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 609,
  id = 681,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 609,
  id = 682,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 609,
  id = 683,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 684,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 609,
  id = 685,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 686,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 687,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 688,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 689,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 690,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 691,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 692,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 693,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 694,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 695,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 696,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 697,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 698,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 699,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 700,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 701,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 609,
  id = 702,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 703,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 704,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 705,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 609,
  id = 706,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 707,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 708,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 709,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 710,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 711,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 712,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 713,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 714,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 715,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 716,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 717,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 718,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 719,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 609,
  id = 720,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 721,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 722,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 723,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 724,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 725,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 726,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 727,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 728,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 729,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 730,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 731,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 732,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 733,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 734,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 735,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 736,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 737,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 738,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 739,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 740,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 741,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 742,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 743,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 744,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 745,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 746,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 747,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 748,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 610,
  id = 749,
  cardid = 1029
 },
 {
  drop_weight = 2000,
  gameid = 610,
  id = 750,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 610,
  id = 751,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 610,
  id = 752,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 610,
  id = 753,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 610,
  id = 754,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 610,
  id = 755,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 756,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 610,
  id = 757,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 610,
  id = 758,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 759,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 760,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 610,
  id = 761,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 610,
  id = 762,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 610,
  id = 763,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 764,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 610,
  id = 765,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 766,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 767,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 768,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 769,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 770,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 771,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 772,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 773,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 774,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 775,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 776,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 777,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 778,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 779,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 780,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 781,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 610,
  id = 782,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 783,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 784,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 785,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 610,
  id = 786,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 787,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 788,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 789,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 790,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 791,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 792,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 793,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 794,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 795,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 796,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 797,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 798,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 799,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 610,
  id = 800,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 801,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 802,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 803,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 804,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 805,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 806,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 807,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 808,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 809,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 810,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 811,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 812,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 813,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 814,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 815,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 816,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 817,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 818,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 819,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 820,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 821,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 822,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 823,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 824,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 825,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 826,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 827,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 828,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 611,
  id = 829,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 611,
  id = 830,
  cardid = 1030
 },
 {
  drop_weight = 2000,
  gameid = 611,
  id = 831,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 611,
  id = 832,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 611,
  id = 833,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 611,
  id = 834,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 611,
  id = 835,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 836,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 611,
  id = 837,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 611,
  id = 838,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 839,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 840,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 611,
  id = 841,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 611,
  id = 842,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 611,
  id = 843,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 844,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 611,
  id = 845,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 846,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 847,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 848,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 849,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 850,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 851,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 852,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 853,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 854,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 855,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 856,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 857,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 858,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 859,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 860,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 861,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 611,
  id = 862,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 863,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 864,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 865,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 611,
  id = 866,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 867,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 868,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 869,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 870,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 871,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 872,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 873,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 874,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 875,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 876,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 877,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 878,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 879,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 611,
  id = 880,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 881,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 882,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 883,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 884,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 885,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 886,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 887,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 888,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 889,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 890,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 891,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 892,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 893,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 894,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 895,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 896,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 897,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 898,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 899,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 900,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 901,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 902,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 903,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 904,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 905,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 906,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 907,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 908,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 612,
  id = 909,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 612,
  id = 910,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 612,
  id = 911,
  cardid = 1031
 },
 {
  drop_weight = 2000,
  gameid = 612,
  id = 912,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 612,
  id = 913,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 612,
  id = 914,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 612,
  id = 915,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 916,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 612,
  id = 917,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 612,
  id = 918,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 919,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 920,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 612,
  id = 921,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 612,
  id = 922,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 612,
  id = 923,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 924,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 612,
  id = 925,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 926,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 927,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 928,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 929,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 930,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 931,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 932,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 933,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 934,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 935,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 936,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 937,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 938,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 939,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 940,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 941,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 612,
  id = 942,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 943,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 944,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 945,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 612,
  id = 946,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 947,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 948,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 949,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 950,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 951,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 952,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 953,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 954,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 955,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 956,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 957,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 958,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 959,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 612,
  id = 960,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 961,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 962,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 963,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 964,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 965,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 966,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 967,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 968,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 969,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 970,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 971,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 972,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 973,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 974,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 975,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 976,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 977,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 978,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 979,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 980,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 981,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 982,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 983,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 984,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 985,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 986,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 987,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 988,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 613,
  id = 989,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 613,
  id = 990,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 613,
  id = 991,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 613,
  id = 992,
  cardid = 1032
 },
 {
  drop_weight = 2000,
  gameid = 613,
  id = 993,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 613,
  id = 994,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 613,
  id = 995,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 996,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 613,
  id = 997,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 613,
  id = 998,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 999,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1000,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 613,
  id = 1001,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 613,
  id = 1002,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 613,
  id = 1003,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1004,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 613,
  id = 1005,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1006,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1007,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1008,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1009,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1010,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1011,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1012,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1013,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1014,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1015,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1016,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1017,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1018,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1019,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1020,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1021,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 613,
  id = 1022,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1023,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1024,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1025,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 613,
  id = 1026,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1027,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1028,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1029,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1030,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1031,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1032,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1033,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1034,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1035,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1036,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1037,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1038,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1039,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 613,
  id = 1040,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1041,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1042,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1043,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1044,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1045,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1046,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1047,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1048,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1049,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1050,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1051,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1052,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1053,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1054,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1055,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1056,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1057,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1058,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1059,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1060,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1061,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1062,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1063,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1064,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1065,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1066,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1067,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1068,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 614,
  id = 1069,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 614,
  id = 1070,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 614,
  id = 1071,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 614,
  id = 1072,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 614,
  id = 1073,
  cardid = 1033
 },
 {
  drop_weight = 2000,
  gameid = 614,
  id = 1074,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 614,
  id = 1075,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1076,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 614,
  id = 1077,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 614,
  id = 1078,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1079,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1080,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 614,
  id = 1081,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 614,
  id = 1082,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 614,
  id = 1083,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1084,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 614,
  id = 1085,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1086,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1087,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1088,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1089,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1090,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1091,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1092,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1093,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1094,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1095,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1096,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1097,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1098,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1099,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1100,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1101,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 614,
  id = 1102,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1103,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1104,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1105,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 614,
  id = 1106,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1107,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1108,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1109,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1110,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1111,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1112,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1113,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1114,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1115,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1116,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1117,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1118,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1119,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 614,
  id = 1120,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1121,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1122,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1123,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1124,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1125,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1126,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1127,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1128,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1129,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1130,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1131,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1132,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1133,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1134,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1135,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1136,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1137,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1138,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1139,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1140,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1141,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1142,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1143,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1144,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1145,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1146,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1147,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1148,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 615,
  id = 1149,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 615,
  id = 1150,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 615,
  id = 1151,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 615,
  id = 1152,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 615,
  id = 1153,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 615,
  id = 1154,
  cardid = 1034
 },
 {
  drop_weight = 2000,
  gameid = 615,
  id = 1155,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1156,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 615,
  id = 1157,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 615,
  id = 1158,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1159,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1160,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 615,
  id = 1161,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 615,
  id = 1162,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 615,
  id = 1163,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1164,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 615,
  id = 1165,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1166,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1167,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1168,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1169,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1170,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1171,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1172,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1173,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1174,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1175,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1176,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1177,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1178,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1179,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1180,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1181,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 615,
  id = 1182,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1183,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1184,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1185,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 615,
  id = 1186,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1187,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1188,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1189,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1190,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1191,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1192,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1193,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1194,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1195,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1196,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1197,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1198,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1199,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 615,
  id = 1200,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1201,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1202,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1203,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1204,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1205,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1206,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1207,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1208,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1209,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 616,
  id = 1210,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1211,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 616,
  id = 1212,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 616,
  id = 1213,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 616,
  id = 1214,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 616,
  id = 1215,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 616,
  id = 1216,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1217,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1218,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1219,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1220,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1221,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1222,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 616,
  id = 1223,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 616,
  id = 1224,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1225,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1226,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1227,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1228,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1229,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1230,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1231,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1232,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1233,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1234,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1235,
  cardid = 1035
 },
 {
  drop_weight = 2000,
  gameid = 616,
  id = 1236,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1237,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1238,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1239,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1240,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1241,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1242,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1243,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1244,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1245,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1246,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1247,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 616,
  id = 1248,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 616,
  id = 1249,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 616,
  id = 1250,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 616,
  id = 1251,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1252,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1253,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 616,
  id = 1254,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1255,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1256,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1257,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1258,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1259,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1260,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1261,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1262,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1263,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1264,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1265,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1266,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 616,
  id = 1267,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1268,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1269,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1270,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1271,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1272,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1273,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1274,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1275,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1276,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1277,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 616,
  id = 1278,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 616,
  id = 1279,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 616,
  id = 1280,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1281,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1282,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1283,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1284,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1285,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1286,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1287,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1288,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1289,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1290,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1291,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1292,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1293,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1294,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1295,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1296,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1297,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1298,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1299,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1300,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1301,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1302,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1303,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1304,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1305,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1306,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1307,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1308,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 617,
  id = 1309,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 617,
  id = 1310,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 617,
  id = 1311,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 617,
  id = 1312,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 617,
  id = 1313,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 617,
  id = 1314,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 617,
  id = 1315,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1316,
  cardid = 1036
 },
 {
  drop_weight = 2000,
  gameid = 617,
  id = 1317,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 617,
  id = 1318,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1319,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1320,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 617,
  id = 1321,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 617,
  id = 1322,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 617,
  id = 1323,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1324,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 617,
  id = 1325,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1326,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1327,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1328,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1329,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1330,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1331,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1332,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1333,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1334,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1335,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1336,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1337,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1338,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1339,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1340,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1341,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 617,
  id = 1342,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1343,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1344,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1345,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 617,
  id = 1346,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1347,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1348,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1349,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1350,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1351,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1352,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1353,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1354,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1355,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1356,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1357,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1358,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1359,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 617,
  id = 1360,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1361,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1362,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1363,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1364,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1365,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1366,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 618,
  id = 1367,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 618,
  id = 1368,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 618,
  id = 1369,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1370,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1371,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1372,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1373,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1374,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1375,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1376,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1377,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 618,
  id = 1378,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1379,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1380,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1381,
  cardid = 1021
 },
 {
  drop_weight = 2000,
  gameid = 618,
  id = 1382,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1383,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1384,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 618,
  id = 1385,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1386,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1387,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1388,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1389,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1390,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1391,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1392,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1393,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1394,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1395,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1396,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1397,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1398,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1399,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 618,
  id = 1400,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1401,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1402,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1403,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1404,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1405,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1406,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1407,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1408,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1409,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1410,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1411,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 618,
  id = 1412,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1413,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1414,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 618,
  id = 1415,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 618,
  id = 1416,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 618,
  id = 1417,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 618,
  id = 1418,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1419,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1420,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1421,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1422,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1423,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1424,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 618,
  id = 1425,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1426,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1427,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1428,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1429,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1430,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1431,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 618,
  id = 1432,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 618,
  id = 1433,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1434,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1435,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1436,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1437,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1438,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1439,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 618,
  id = 1440,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1441,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1442,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1443,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1444,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1445,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 619,
  id = 1446,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1447,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1448,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1449,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1450,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 619,
  id = 1451,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1452,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1453,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1454,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1455,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1456,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 619,
  id = 1457,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1458,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 619,
  id = 1459,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1460,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1461,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1462,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1463,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1464,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1465,
  cardid = 1025
 },
 {
  drop_weight = 2000,
  gameid = 619,
  id = 1466,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 619,
  id = 1467,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 619,
  id = 1468,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1469,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1470,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1471,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1472,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1473,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1474,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1475,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1476,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1477,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1478,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1479,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1480,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1481,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1482,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1483,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1484,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1485,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1486,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1487,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1488,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1489,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1490,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1491,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1492,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1493,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1494,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1495,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1496,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1497,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1498,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1499,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 619,
  id = 1500,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1501,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1502,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1503,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1504,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1505,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1506,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1507,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1508,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1509,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1510,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 619,
  id = 1511,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1512,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1513,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1514,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 619,
  id = 1515,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1516,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 619,
  id = 1517,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1518,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 619,
  id = 1519,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 619,
  id = 1520,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1521,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1522,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1523,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1524,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1525,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1526,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 620,
  id = 1527,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 620,
  id = 1528,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 620,
  id = 1529,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1530,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1531,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1532,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1533,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1534,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1535,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1536,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1537,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 620,
  id = 1538,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1539,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1540,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1541,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 620,
  id = 1542,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1543,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1544,
  cardid = 1024
 },
 {
  drop_weight = 2000,
  gameid = 620,
  id = 1545,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1546,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1547,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1548,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1549,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1550,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1551,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1552,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1553,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1554,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1555,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1556,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1557,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1558,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1559,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 620,
  id = 1560,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1561,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1562,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1563,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1564,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1565,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1566,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1567,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1568,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1569,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1570,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1571,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 620,
  id = 1572,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1573,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1574,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 620,
  id = 1575,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 620,
  id = 1576,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 620,
  id = 1577,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 620,
  id = 1578,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1579,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1580,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1581,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1582,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1583,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1584,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 620,
  id = 1585,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1586,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1587,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1588,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1589,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1590,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1591,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 620,
  id = 1592,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 620,
  id = 1593,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1594,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1595,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1596,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1597,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1598,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1599,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 620,
  id = 1600,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1601,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1602,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1603,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1604,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1605,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1606,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1607,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1608,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1609,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 621,
  id = 1610,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1611,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 621,
  id = 1612,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 621,
  id = 1613,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 621,
  id = 1614,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 621,
  id = 1615,
  cardid = 1015
 },
 {
  drop_weight = 2000,
  gameid = 621,
  id = 1616,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1617,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1618,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1619,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1620,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1621,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1622,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 621,
  id = 1623,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 621,
  id = 1624,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1625,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1626,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1627,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1628,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1629,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1630,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1631,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1632,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1633,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1634,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1635,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 621,
  id = 1636,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1637,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1638,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1639,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1640,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1641,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1642,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1643,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1644,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1645,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1646,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1647,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 621,
  id = 1648,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 621,
  id = 1649,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 621,
  id = 1650,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 621,
  id = 1651,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1652,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1653,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 621,
  id = 1654,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1655,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1656,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1657,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1658,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1659,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1660,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1661,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1662,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1663,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1664,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1665,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1666,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 621,
  id = 1667,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1668,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1669,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1670,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1671,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1672,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1673,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1674,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1675,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1676,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1677,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 621,
  id = 1678,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 621,
  id = 1679,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 621,
  id = 1680,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1681,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1682,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1683,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1684,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1685,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 622,
  id = 1686,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1687,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1688,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1689,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1690,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 622,
  id = 1691,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1692,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1693,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1694,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1695,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1696,
  cardid = 1016
 },
 {
  drop_weight = 2000,
  gameid = 622,
  id = 1697,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1698,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 622,
  id = 1699,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1700,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1701,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1702,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1703,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1704,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1705,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 622,
  id = 1706,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 622,
  id = 1707,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 622,
  id = 1708,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1709,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1710,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1711,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1712,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1713,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1714,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1715,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1716,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1717,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1718,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1719,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1720,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1721,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1722,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1723,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1724,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1725,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1726,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1727,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1728,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1729,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1730,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1731,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1732,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1733,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1734,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1735,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1736,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1737,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1738,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1739,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 622,
  id = 1740,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1741,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1742,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1743,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1744,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1745,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1746,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1747,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1748,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1749,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1750,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 622,
  id = 1751,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1752,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1753,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1754,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 622,
  id = 1755,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1756,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 622,
  id = 1757,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1758,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 622,
  id = 1759,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 622,
  id = 1760,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 623,
  id = 1761,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 623,
  id = 1762,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 623,
  id = 1763,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 623,
  id = 1764,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 623,
  id = 1765,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1766,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1767,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1768,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1769,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1770,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1771,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1772,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1773,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1774,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1775,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1776,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1777,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1778,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1779,
  cardid = 1019
 },
 {
  drop_weight = 2000,
  gameid = 623,
  id = 1780,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1781,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1782,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1783,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1784,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1785,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1786,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1787,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1788,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1789,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1790,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1791,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1792,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1793,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1794,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1795,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1796,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1797,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1798,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1799,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1800,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1801,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1802,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1803,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 623,
  id = 1804,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1805,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 623,
  id = 1806,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 623,
  id = 1807,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1808,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1809,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1810,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1811,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1812,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 623,
  id = 1813,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1814,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1815,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1816,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1817,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1818,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1819,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1820,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1821,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1822,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1823,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1824,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1825,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1826,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1827,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 623,
  id = 1828,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 623,
  id = 1829,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1830,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1831,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1832,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1833,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 623,
  id = 1834,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1835,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 623,
  id = 1836,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1837,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1838,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1839,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 623,
  id = 1840,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1841,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1842,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1843,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1844,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1845,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 624,
  id = 1846,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1847,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1848,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1849,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1850,
  cardid = 1010
 },
 {
  drop_weight = 2000,
  gameid = 624,
  id = 1851,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1852,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1853,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1854,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1855,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1856,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 624,
  id = 1857,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1858,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 624,
  id = 1859,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1860,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1861,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1862,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1863,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1864,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1865,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 624,
  id = 1866,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 624,
  id = 1867,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 624,
  id = 1868,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1869,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1870,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1871,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1872,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1873,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1874,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1875,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1876,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1877,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1878,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1879,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1880,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1881,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1882,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1883,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1884,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1885,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1886,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1887,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1888,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1889,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1890,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1891,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1892,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1893,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1894,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1895,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1896,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1897,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1898,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1899,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 624,
  id = 1900,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1901,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1902,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1903,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1904,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1905,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1906,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1907,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1908,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1909,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1910,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 624,
  id = 1911,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1912,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1913,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1914,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 624,
  id = 1915,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1916,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 624,
  id = 1917,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1918,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 624,
  id = 1919,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 624,
  id = 1920,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1921,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1922,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1923,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1924,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1925,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1926,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 625,
  id = 1927,
  cardid = 1007
 },
 {
  drop_weight = 2000,
  gameid = 625,
  id = 1928,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 625,
  id = 1929,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1930,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1931,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1932,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1933,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1934,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1935,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1936,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1937,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 625,
  id = 1938,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1939,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1940,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1941,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 625,
  id = 1942,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1943,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1944,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 625,
  id = 1945,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1946,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1947,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1948,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1949,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1950,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1951,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1952,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1953,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1954,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1955,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1956,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1957,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1958,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1959,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 625,
  id = 1960,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1961,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1962,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1963,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1964,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1965,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1966,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1967,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1968,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1969,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1970,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1971,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 625,
  id = 1972,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1973,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1974,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 625,
  id = 1975,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 625,
  id = 1976,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 625,
  id = 1977,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 625,
  id = 1978,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1979,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1980,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1981,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1982,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1983,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1984,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 625,
  id = 1985,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1986,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1987,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1988,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1989,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1990,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1991,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 625,
  id = 1992,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 625,
  id = 1993,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1994,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1995,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1996,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1997,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1998,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 1999,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 625,
  id = 2000,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2001,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2002,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2003,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2004,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2005,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2006,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2007,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2008,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2009,
  cardid = 1009
 },
 {
  drop_weight = 2000,
  gameid = 626,
  id = 2010,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2011,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 626,
  id = 2012,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 626,
  id = 2013,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 626,
  id = 2014,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 626,
  id = 2015,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 626,
  id = 2016,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2017,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2018,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2019,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2020,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2021,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2022,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 626,
  id = 2023,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 626,
  id = 2024,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2025,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2026,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2027,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2028,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2029,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2030,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2031,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2032,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2033,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2034,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2035,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 626,
  id = 2036,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2037,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2038,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2039,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2040,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2041,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2042,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2043,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2044,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2045,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2046,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2047,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 626,
  id = 2048,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 626,
  id = 2049,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 626,
  id = 2050,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 626,
  id = 2051,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2052,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2053,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 626,
  id = 2054,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2055,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2056,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2057,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2058,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2059,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2060,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2061,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2062,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2063,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2064,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2065,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2066,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 626,
  id = 2067,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2068,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2069,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2070,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2071,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2072,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2073,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2074,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2075,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2076,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2077,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 626,
  id = 2078,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 626,
  id = 2079,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 626,
  id = 2080,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2081,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2082,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2083,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2084,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2085,
  cardid = 1005
 },
 {
  drop_weight = 2000,
  gameid = 627,
  id = 2086,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2087,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2088,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2089,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2090,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 627,
  id = 2091,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2092,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2093,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2094,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2095,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2096,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 627,
  id = 2097,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2098,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 627,
  id = 2099,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2100,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2101,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2102,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2103,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2104,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2105,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 627,
  id = 2106,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 627,
  id = 2107,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 627,
  id = 2108,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2109,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2110,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2111,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2112,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2113,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2114,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2115,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2116,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2117,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2118,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2119,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2120,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2121,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2122,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2123,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2124,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2125,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2126,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2127,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2128,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2129,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2130,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2131,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2132,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2133,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2134,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2135,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2136,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2137,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2138,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2139,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 627,
  id = 2140,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2141,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2142,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2143,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2144,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2145,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2146,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2147,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2148,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2149,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2150,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 627,
  id = 2151,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2152,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2153,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2154,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 627,
  id = 2155,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2156,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 627,
  id = 2157,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2158,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 627,
  id = 2159,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 627,
  id = 2160,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2161,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2162,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2163,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2164,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2165,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2166,
  cardid = 1006
 },
 {
  drop_weight = 2000,
  gameid = 628,
  id = 2167,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 628,
  id = 2168,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 628,
  id = 2169,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2170,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2171,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2172,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2173,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2174,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2175,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2176,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2177,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 628,
  id = 2178,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2179,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2180,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2181,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 628,
  id = 2182,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2183,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2184,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 628,
  id = 2185,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2186,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2187,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2188,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2189,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2190,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2191,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2192,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2193,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2194,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2195,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2196,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2197,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2198,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2199,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 628,
  id = 2200,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2201,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2202,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2203,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2204,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2205,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2206,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2207,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2208,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2209,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2210,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2211,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 628,
  id = 2212,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2213,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2214,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 628,
  id = 2215,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 628,
  id = 2216,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 628,
  id = 2217,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 628,
  id = 2218,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2219,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2220,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2221,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2222,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2223,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2224,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 628,
  id = 2225,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2226,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2227,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2228,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2229,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2230,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2231,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 628,
  id = 2232,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 628,
  id = 2233,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2234,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2235,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2236,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2237,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2238,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2239,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 628,
  id = 2240,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2241,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2242,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2243,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2244,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2245,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2246,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 629,
  id = 2247,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 629,
  id = 2248,
  cardid = 1008
 },
 {
  drop_weight = 2000,
  gameid = 629,
  id = 2249,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2250,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2251,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2252,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2253,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2254,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2255,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2256,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2257,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 629,
  id = 2258,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2259,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2260,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2261,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 629,
  id = 2262,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2263,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2264,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 629,
  id = 2265,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2266,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2267,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2268,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2269,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2270,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2271,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2272,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2273,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2274,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2275,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2276,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2277,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2278,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2279,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 629,
  id = 2280,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2281,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2282,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2283,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2284,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2285,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2286,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2287,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2288,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2289,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2290,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2291,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 629,
  id = 2292,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2293,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2294,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 629,
  id = 2295,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 629,
  id = 2296,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 629,
  id = 2297,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 629,
  id = 2298,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2299,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2300,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2301,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2302,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2303,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2304,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 629,
  id = 2305,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2306,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2307,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2308,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2309,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2310,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2311,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 629,
  id = 2312,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 629,
  id = 2313,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2314,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2315,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2316,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2317,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2318,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2319,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 629,
  id = 2320,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2321,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2322,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2323,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2324,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2325,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2326,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2327,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2328,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2329,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 630,
  id = 2330,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2331,
  cardid = 1011
 },
 {
  drop_weight = 2000,
  gameid = 630,
  id = 2332,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 630,
  id = 2333,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 630,
  id = 2334,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 630,
  id = 2335,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 630,
  id = 2336,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2337,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2338,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2339,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2340,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2341,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2342,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 630,
  id = 2343,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 630,
  id = 2344,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2345,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2346,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2347,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2348,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2349,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2350,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2351,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2352,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2353,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2354,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2355,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 630,
  id = 2356,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2357,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2358,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2359,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2360,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2361,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2362,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2363,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2364,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2365,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2366,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2367,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 630,
  id = 2368,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 630,
  id = 2369,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 630,
  id = 2370,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 630,
  id = 2371,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2372,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2373,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 630,
  id = 2374,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2375,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2376,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2377,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2378,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2379,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2380,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2381,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2382,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2383,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2384,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2385,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2386,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 630,
  id = 2387,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2388,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2389,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2390,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2391,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2392,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2393,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2394,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2395,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2396,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2397,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 630,
  id = 2398,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 630,
  id = 2399,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 630,
  id = 2400,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2401,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2402,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2403,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2404,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2405,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2406,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2407,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2408,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2409,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 631,
  id = 2410,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2411,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 631,
  id = 2412,
  cardid = 1012
 },
 {
  drop_weight = 2000,
  gameid = 631,
  id = 2413,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 631,
  id = 2414,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 631,
  id = 2415,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 631,
  id = 2416,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2417,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2418,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2419,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2420,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2421,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2422,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 631,
  id = 2423,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 631,
  id = 2424,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2425,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2426,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2427,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2428,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2429,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2430,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2431,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2432,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2433,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2434,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2435,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 631,
  id = 2436,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2437,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2438,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2439,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2440,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2441,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2442,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2443,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2444,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2445,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2446,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2447,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 631,
  id = 2448,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 631,
  id = 2449,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 631,
  id = 2450,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 631,
  id = 2451,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2452,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2453,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 631,
  id = 2454,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2455,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2456,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2457,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2458,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2459,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2460,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2461,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2462,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2463,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2464,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2465,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2466,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 631,
  id = 2467,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2468,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2469,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2470,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2471,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2472,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2473,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2474,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2475,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2476,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2477,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 631,
  id = 2478,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 631,
  id = 2479,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 631,
  id = 2480,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2481,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2482,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2483,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2484,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2485,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2486,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2487,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2488,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2489,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 632,
  id = 2490,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2491,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 632,
  id = 2492,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 632,
  id = 2493,
  cardid = 1013
 },
 {
  drop_weight = 2000,
  gameid = 632,
  id = 2494,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 632,
  id = 2495,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 632,
  id = 2496,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2497,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2498,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2499,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2500,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2501,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2502,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 632,
  id = 2503,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 632,
  id = 2504,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2505,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2506,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2507,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2508,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2509,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2510,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2511,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2512,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2513,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2514,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2515,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 632,
  id = 2516,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2517,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2518,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2519,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2520,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2521,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2522,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2523,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2524,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2525,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2526,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2527,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 632,
  id = 2528,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 632,
  id = 2529,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 632,
  id = 2530,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 632,
  id = 2531,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2532,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2533,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 632,
  id = 2534,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2535,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2536,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2537,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2538,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2539,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2540,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2541,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2542,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2543,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2544,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2545,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2546,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 632,
  id = 2547,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2548,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2549,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2550,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2551,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2552,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2553,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2554,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2555,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2556,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2557,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 632,
  id = 2558,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 632,
  id = 2559,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 632,
  id = 2560,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2561,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2562,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2563,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2564,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2565,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2566,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2567,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2568,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2569,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 633,
  id = 2570,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2571,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 633,
  id = 2572,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 633,
  id = 2573,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 633,
  id = 2574,
  cardid = 1014
 },
 {
  drop_weight = 2000,
  gameid = 633,
  id = 2575,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 633,
  id = 2576,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2577,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2578,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2579,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2580,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2581,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2582,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 633,
  id = 2583,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 633,
  id = 2584,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2585,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2586,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2587,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2588,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2589,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2590,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2591,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2592,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2593,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2594,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2595,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 633,
  id = 2596,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2597,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2598,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2599,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2600,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2601,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2602,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2603,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2604,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2605,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2606,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2607,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 633,
  id = 2608,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 633,
  id = 2609,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 633,
  id = 2610,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 633,
  id = 2611,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2612,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2613,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 633,
  id = 2614,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2615,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2616,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2617,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2618,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2619,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2620,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2621,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2622,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2623,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2624,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2625,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2626,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 633,
  id = 2627,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2628,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2629,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2630,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2631,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2632,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2633,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2634,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2635,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2636,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2637,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 633,
  id = 2638,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 633,
  id = 2639,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 633,
  id = 2640,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2641,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2642,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2643,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2644,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2645,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2646,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 634,
  id = 2647,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 634,
  id = 2648,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 634,
  id = 2649,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2650,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2651,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2652,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2653,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2654,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2655,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2656,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2657,
  cardid = 1017
 },
 {
  drop_weight = 2000,
  gameid = 634,
  id = 2658,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2659,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2660,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2661,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 634,
  id = 2662,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2663,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2664,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 634,
  id = 2665,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2666,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2667,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2668,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2669,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2670,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2671,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2672,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2673,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2674,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2675,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2676,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2677,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2678,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2679,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 634,
  id = 2680,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2681,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2682,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2683,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2684,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2685,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2686,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2687,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2688,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2689,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2690,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2691,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 634,
  id = 2692,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2693,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2694,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 634,
  id = 2695,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 634,
  id = 2696,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 634,
  id = 2697,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 634,
  id = 2698,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2699,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2700,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2701,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2702,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2703,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2704,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 634,
  id = 2705,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2706,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2707,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2708,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2709,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2710,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2711,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 634,
  id = 2712,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 634,
  id = 2713,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2714,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2715,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2716,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2717,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2718,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2719,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 634,
  id = 2720,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2721,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2722,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2723,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2724,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2725,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 635,
  id = 2726,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2727,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2728,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2729,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2730,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 635,
  id = 2731,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2732,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2733,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2734,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2735,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2736,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 635,
  id = 2737,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2738,
  cardid = 1018
 },
 {
  drop_weight = 2000,
  gameid = 635,
  id = 2739,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2740,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2741,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2742,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2743,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2744,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2745,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 635,
  id = 2746,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 635,
  id = 2747,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 635,
  id = 2748,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2749,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2750,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2751,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2752,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2753,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2754,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2755,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2756,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2757,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2758,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2759,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2760,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2761,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2762,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2763,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2764,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2765,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2766,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2767,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2768,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2769,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2770,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2771,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2772,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2773,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2774,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2775,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2776,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2777,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2778,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2779,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 635,
  id = 2780,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2781,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2782,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2783,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2784,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2785,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2786,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2787,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2788,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2789,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2790,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 635,
  id = 2791,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2792,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2793,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2794,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 635,
  id = 2795,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2796,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 635,
  id = 2797,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2798,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 635,
  id = 2799,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 635,
  id = 2800,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2801,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2802,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2803,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2804,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2805,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2806,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2807,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2808,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2809,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 636,
  id = 2810,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2811,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 636,
  id = 2812,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 636,
  id = 2813,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 636,
  id = 2814,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 636,
  id = 2815,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 636,
  id = 2816,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2817,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2818,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2819,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2820,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2821,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2822,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 636,
  id = 2823,
  cardid = 1023
 },
 {
  drop_weight = 2000,
  gameid = 636,
  id = 2824,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2825,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2826,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2827,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2828,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2829,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2830,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2831,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2832,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2833,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2834,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2835,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 636,
  id = 2836,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2837,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2838,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2839,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2840,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2841,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2842,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2843,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2844,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2845,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2846,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2847,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 636,
  id = 2848,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 636,
  id = 2849,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 636,
  id = 2850,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 636,
  id = 2851,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2852,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2853,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 636,
  id = 2854,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2855,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2856,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2857,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2858,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2859,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2860,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2861,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2862,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2863,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2864,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2865,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2866,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 636,
  id = 2867,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2868,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2869,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2870,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2871,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2872,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2873,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2874,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2875,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2876,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2877,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 636,
  id = 2878,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 636,
  id = 2879,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 636,
  id = 2880,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2881,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2882,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2883,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2884,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2885,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2886,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2887,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2888,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2889,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 637,
  id = 2890,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2891,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 637,
  id = 2892,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 637,
  id = 2893,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 637,
  id = 2894,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 637,
  id = 2895,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 637,
  id = 2896,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2897,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2898,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2899,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2900,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2901,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2902,
  cardid = 1022
 },
 {
  drop_weight = 2000,
  gameid = 637,
  id = 2903,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 637,
  id = 2904,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2905,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2906,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2907,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2908,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2909,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2910,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2911,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2912,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2913,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2914,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2915,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 637,
  id = 2916,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2917,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2918,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2919,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2920,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2921,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2922,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2923,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2924,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2925,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2926,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2927,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 637,
  id = 2928,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 637,
  id = 2929,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 637,
  id = 2930,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 637,
  id = 2931,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2932,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2933,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 637,
  id = 2934,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2935,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2936,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2937,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2938,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2939,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2940,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2941,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2942,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2943,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2944,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2945,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2946,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 637,
  id = 2947,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2948,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2949,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2950,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2951,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2952,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2953,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2954,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2955,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2956,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2957,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 637,
  id = 2958,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 637,
  id = 2959,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 637,
  id = 2960,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2961,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2962,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2963,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2964,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2965,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 638,
  id = 2966,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2967,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2968,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2969,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2970,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 638,
  id = 2971,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2972,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2973,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2974,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2975,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2976,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 638,
  id = 2977,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2978,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 638,
  id = 2979,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2980,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 2981,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2982,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2983,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2984,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2985,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 638,
  id = 2986,
  cardid = 1026
 },
 {
  drop_weight = 2000,
  gameid = 638,
  id = 2987,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 638,
  id = 2988,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2989,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2990,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2991,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2992,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2993,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2994,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2995,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2996,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2997,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 2998,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 2999,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3000,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3001,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3002,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3003,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3004,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3005,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3006,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3007,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3008,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3009,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3010,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3011,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3012,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3013,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3014,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3015,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3016,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3017,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3018,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 3019,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 638,
  id = 3020,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 3021,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3022,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 3023,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 3024,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3025,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3026,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3027,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3028,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3029,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 3030,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 638,
  id = 3031,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3032,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3033,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3034,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 638,
  id = 3035,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3036,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 638,
  id = 3037,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3038,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 638,
  id = 3039,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 638,
  id = 3040,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3041,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3042,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3043,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3044,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3045,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 639,
  id = 3046,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3047,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3048,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3049,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3050,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 639,
  id = 3051,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3052,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3053,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3054,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3055,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3056,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 639,
  id = 3057,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3058,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 639,
  id = 3059,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3060,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3061,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3062,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3063,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3064,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3065,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 639,
  id = 3066,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 639,
  id = 3067,
  cardid = 1027
 },
 {
  drop_weight = 2000,
  gameid = 639,
  id = 3068,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3069,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3070,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3071,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3072,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3073,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3074,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3075,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3076,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3077,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3078,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3079,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3080,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3081,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3082,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3083,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3084,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3085,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3086,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3087,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3088,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3089,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3090,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3091,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3092,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3093,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3094,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3095,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3096,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3097,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3098,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3099,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 639,
  id = 3100,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3101,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3102,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3103,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3104,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3105,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3106,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3107,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3108,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3109,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3110,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 639,
  id = 3111,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3112,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3113,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3114,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 639,
  id = 3115,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3116,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 639,
  id = 3117,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3118,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 639,
  id = 3119,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 639,
  id = 3120,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3121,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3122,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3123,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3124,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3125,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 640,
  id = 3126,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3127,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3128,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3129,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3130,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 640,
  id = 3131,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3132,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3133,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3134,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3135,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3136,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 640,
  id = 3137,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3138,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 640,
  id = 3139,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3140,
  cardid = 1020
 },
 {
  drop_weight = 2000,
  gameid = 640,
  id = 3141,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3142,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3143,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3144,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3145,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 640,
  id = 3146,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 640,
  id = 3147,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 640,
  id = 3148,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3149,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3150,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3151,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3152,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3153,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3154,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3155,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3156,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3157,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3158,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 640,
  id = 3159,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3160,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3161,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3162,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3163,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3164,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3165,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3166,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3167,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3168,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3169,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3170,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3171,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3172,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3173,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3174,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3175,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3176,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3177,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3178,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 640,
  id = 3179,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 640,
  id = 3180,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 640,
  id = 3181,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3182,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 640,
  id = 3183,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 640,
  id = 3184,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3185,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3186,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3187,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3188,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3189,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 640,
  id = 3190,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 640,
  id = 3191,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3192,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3193,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3194,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 640,
  id = 3195,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3196,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 640,
  id = 3197,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3198,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 640,
  id = 3199,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 640,
  id = 3200,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3201,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3202,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3203,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3204,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3205,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 641,
  id = 3206,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3207,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3208,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3209,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3210,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 641,
  id = 3211,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3212,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3213,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3214,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3215,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3216,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 641,
  id = 3217,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3218,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 641,
  id = 3219,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3220,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 641,
  id = 3221,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3222,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3223,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3224,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3225,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 641,
  id = 3226,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 641,
  id = 3227,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 641,
  id = 3228,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3229,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3230,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3231,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3232,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3233,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3234,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3235,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3236,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3237,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3238,
  cardid = 1038
 },
 {
  drop_weight = 2000,
  gameid = 641,
  id = 3239,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3240,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3241,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3242,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3243,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3244,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3245,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3246,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3247,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3248,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3249,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3250,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3251,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3252,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3253,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3254,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3255,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3256,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3257,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3258,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 641,
  id = 3259,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 641,
  id = 3260,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 641,
  id = 3261,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3262,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 641,
  id = 3263,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 641,
  id = 3264,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3265,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3266,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3267,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3268,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3269,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 641,
  id = 3270,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 641,
  id = 3271,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3272,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3273,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3274,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 641,
  id = 3275,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3276,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 641,
  id = 3277,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3278,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 641,
  id = 3279,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 641,
  id = 3280,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3281,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3282,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3283,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3284,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3285,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3286,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 642,
  id = 3287,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 642,
  id = 3288,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 642,
  id = 3289,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3290,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3291,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3292,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3293,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3294,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3295,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3296,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3297,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 642,
  id = 3298,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3299,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3300,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3301,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 642,
  id = 3302,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3303,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3304,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 642,
  id = 3305,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3306,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3307,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3308,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3309,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3310,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3311,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3312,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3313,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3314,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3315,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3316,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3317,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3318,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3319,
  cardid = 1039
 },
 {
  drop_weight = 2000,
  gameid = 642,
  id = 3320,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3321,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3322,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3323,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3324,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3325,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3326,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3327,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3328,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3329,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3330,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3331,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 642,
  id = 3332,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3333,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3334,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 642,
  id = 3335,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 642,
  id = 3336,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 642,
  id = 3337,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 642,
  id = 3338,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3339,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3340,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3341,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3342,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3343,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3344,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 642,
  id = 3345,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3346,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3347,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3348,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3349,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3350,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3351,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 642,
  id = 3352,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 642,
  id = 3353,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3354,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3355,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3356,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3357,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3358,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3359,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 642,
  id = 3360,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3361,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3362,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3363,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3364,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3365,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3366,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3367,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3368,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3369,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3370,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3371,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3372,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3373,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3374,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3375,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3376,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3377,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3378,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3379,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3380,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3381,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3382,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3383,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3384,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3385,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3386,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3387,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3388,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 643,
  id = 3389,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 643,
  id = 3390,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 643,
  id = 3391,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 643,
  id = 3392,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 643,
  id = 3393,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 643,
  id = 3394,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 643,
  id = 3395,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3396,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 643,
  id = 3397,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 643,
  id = 3398,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3399,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3400,
  cardid = 1040
 },
 {
  drop_weight = 2000,
  gameid = 643,
  id = 3401,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 643,
  id = 3402,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 643,
  id = 3403,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3404,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 643,
  id = 3405,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3406,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3407,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3408,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3409,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3410,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3411,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3412,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3413,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3414,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3415,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3416,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3417,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3418,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3419,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3420,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3421,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 643,
  id = 3422,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3423,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3424,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3425,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 643,
  id = 3426,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3427,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3428,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3429,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3430,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3431,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3432,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3433,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3434,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3435,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3436,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3437,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3438,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3439,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 643,
  id = 3440,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3441,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3442,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3443,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3444,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3445,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3446,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3447,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3448,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3449,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3450,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3451,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3452,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3453,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3454,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3455,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3456,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3457,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3458,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3459,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3460,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3461,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3462,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3463,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3464,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3465,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3466,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3467,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3468,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 644,
  id = 3469,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 644,
  id = 3470,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 644,
  id = 3471,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 644,
  id = 3472,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 644,
  id = 3473,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 644,
  id = 3474,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 644,
  id = 3475,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3476,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 644,
  id = 3477,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 644,
  id = 3478,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3479,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3480,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 644,
  id = 3481,
  cardid = 1041
 },
 {
  drop_weight = 2000,
  gameid = 644,
  id = 3482,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 644,
  id = 3483,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3484,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 644,
  id = 3485,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3486,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3487,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3488,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3489,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3490,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3491,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3492,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3493,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3494,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3495,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3496,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3497,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3498,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3499,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3500,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3501,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 644,
  id = 3502,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3503,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3504,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3505,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 644,
  id = 3506,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3507,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3508,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3509,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3510,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3511,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3512,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3513,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3514,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3515,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3516,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3517,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3518,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3519,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 644,
  id = 3520,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3521,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3522,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3523,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3524,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3525,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3526,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3527,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3528,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3529,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3530,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3531,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3532,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3533,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3534,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3535,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3536,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3537,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3538,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3539,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3540,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3541,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3542,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3543,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3544,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3545,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3546,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3547,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3548,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 645,
  id = 3549,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 645,
  id = 3550,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 645,
  id = 3551,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 645,
  id = 3552,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 645,
  id = 3553,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 645,
  id = 3554,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 645,
  id = 3555,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3556,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 645,
  id = 3557,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 645,
  id = 3558,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3559,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3560,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 645,
  id = 3561,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 645,
  id = 3562,
  cardid = 1042
 },
 {
  drop_weight = 2000,
  gameid = 645,
  id = 3563,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3564,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 645,
  id = 3565,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3566,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3567,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3568,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3569,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3570,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3571,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3572,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3573,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3574,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3575,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3576,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3577,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3578,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3579,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3580,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3581,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 645,
  id = 3582,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3583,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3584,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3585,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 645,
  id = 3586,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3587,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3588,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3589,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3590,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3591,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3592,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3593,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3594,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3595,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3596,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3597,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3598,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3599,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 645,
  id = 3600,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 646,
  id = 3601,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 646,
  id = 3602,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 646,
  id = 3603,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 646,
  id = 3604,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 646,
  id = 3605,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3606,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3607,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3608,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3609,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3610,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3611,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3612,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3613,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3614,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3615,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3616,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3617,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3618,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3619,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 646,
  id = 3620,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3621,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3622,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3623,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3624,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3625,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3626,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3627,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3628,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3629,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3630,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3631,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3632,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3633,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3634,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3635,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3636,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3637,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3638,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3639,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3640,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3641,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3642,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3643,
  cardid = 1043
 },
 {
  drop_weight = 2000,
  gameid = 646,
  id = 3644,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3645,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 646,
  id = 3646,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 646,
  id = 3647,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3648,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3649,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3650,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3651,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3652,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 646,
  id = 3653,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3654,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3655,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3656,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3657,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3658,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3659,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3660,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3661,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3662,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3663,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3664,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3665,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3666,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3667,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 646,
  id = 3668,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 646,
  id = 3669,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3670,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3671,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3672,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3673,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 646,
  id = 3674,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3675,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 646,
  id = 3676,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3677,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3678,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3679,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 646,
  id = 3680,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3681,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3682,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3683,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3684,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3685,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3686,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3687,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3688,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3689,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3690,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3691,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3692,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3693,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3694,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3695,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3696,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3697,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3698,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3699,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3700,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3701,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3702,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3703,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3704,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3705,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3706,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3707,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3708,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 668,
  id = 3709,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 668,
  id = 3710,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 668,
  id = 3711,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 668,
  id = 3712,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 668,
  id = 3713,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 668,
  id = 3714,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 668,
  id = 3715,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3716,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 668,
  id = 3717,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 668,
  id = 3718,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3719,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3720,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 668,
  id = 3721,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 668,
  id = 3722,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 668,
  id = 3723,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3724,
  cardid = 1044
 },
 {
  drop_weight = 2000,
  gameid = 668,
  id = 3725,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3726,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3727,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3728,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3729,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3730,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3731,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3732,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3733,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3734,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3735,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3736,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3737,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3738,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3739,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3740,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3741,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 668,
  id = 3742,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3743,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3744,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3745,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 668,
  id = 3746,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3747,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3748,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3749,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3750,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3751,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3752,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3753,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3754,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3755,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3756,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3757,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3758,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3759,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 668,
  id = 3760,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 648,
  id = 3761,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 648,
  id = 3762,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 648,
  id = 3763,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 648,
  id = 3764,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 648,
  id = 3765,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3766,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3767,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3768,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3769,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3770,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3771,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3772,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3773,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3774,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3775,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3776,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3777,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3778,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3779,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 648,
  id = 3780,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3781,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3782,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3783,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3784,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3785,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3786,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3787,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3788,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3789,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3790,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3791,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3792,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3793,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3794,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3795,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3796,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3797,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3798,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3799,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3800,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3801,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3802,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3803,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 648,
  id = 3804,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3805,
  cardid = 1045
 },
 {
  drop_weight = 2000,
  gameid = 648,
  id = 3806,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 648,
  id = 3807,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3808,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3809,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3810,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3811,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3812,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 648,
  id = 3813,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3814,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3815,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3816,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3817,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3818,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3819,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3820,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3821,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3822,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3823,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3824,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3825,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3826,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3827,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 648,
  id = 3828,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 648,
  id = 3829,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3830,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3831,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3832,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3833,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 648,
  id = 3834,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3835,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 648,
  id = 3836,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3837,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3838,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3839,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 648,
  id = 3840,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 650,
  id = 3841,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 650,
  id = 3842,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 650,
  id = 3843,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 650,
  id = 3844,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 650,
  id = 3845,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3846,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3847,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3848,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3849,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3850,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3851,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3852,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3853,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3854,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3855,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3856,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3857,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3858,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3859,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 650,
  id = 3860,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3861,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3862,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3863,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3864,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3865,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3866,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3867,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3868,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3869,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3870,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3871,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3872,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3873,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3874,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3875,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3876,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3877,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3878,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3879,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3880,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3881,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3882,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3883,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 650,
  id = 3884,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3885,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 650,
  id = 3886,
  cardid = 1046
 },
 {
  drop_weight = 2000,
  gameid = 650,
  id = 3887,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3888,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3889,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3890,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3891,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3892,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 650,
  id = 3893,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3894,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3895,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3896,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3897,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3898,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3899,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3900,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3901,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3902,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3903,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3904,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3905,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3906,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3907,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 650,
  id = 3908,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 650,
  id = 3909,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3910,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3911,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3912,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3913,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 650,
  id = 3914,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3915,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 650,
  id = 3916,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3917,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3918,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3919,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 650,
  id = 3920,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3921,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3922,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3923,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3924,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3925,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3926,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3927,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3928,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3929,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 652,
  id = 3930,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3931,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 652,
  id = 3932,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 652,
  id = 3933,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 652,
  id = 3934,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 652,
  id = 3935,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 652,
  id = 3936,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3937,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3938,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3939,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3940,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3941,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3942,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 652,
  id = 3943,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 652,
  id = 3944,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3945,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3946,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3947,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3948,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3949,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3950,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3951,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3952,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3953,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3954,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3955,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 652,
  id = 3956,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3957,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3958,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3959,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3960,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3961,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3962,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3963,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3964,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3965,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3966,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3967,
  cardid = 1047
 },
 {
  drop_weight = 2000,
  gameid = 652,
  id = 3968,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 652,
  id = 3969,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 652,
  id = 3970,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 652,
  id = 3971,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3972,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3973,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 652,
  id = 3974,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3975,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3976,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3977,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3978,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3979,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3980,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3981,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3982,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3983,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3984,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3985,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3986,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 652,
  id = 3987,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3988,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3989,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3990,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3991,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3992,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3993,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3994,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3995,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3996,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 3997,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 652,
  id = 3998,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 652,
  id = 3999,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 652,
  id = 4000,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4001,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4002,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4003,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4004,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4005,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4006,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4007,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4008,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4009,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 656,
  id = 4010,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4011,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 656,
  id = 4012,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 656,
  id = 4013,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 656,
  id = 4014,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 656,
  id = 4015,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 656,
  id = 4016,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4017,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4018,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4019,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4020,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4021,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4022,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 656,
  id = 4023,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 656,
  id = 4024,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4025,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4026,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4027,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4028,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4029,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4030,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4031,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4032,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4033,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4034,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4035,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 656,
  id = 4036,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4037,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4038,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4039,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4040,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4041,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4042,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4043,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4044,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4045,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4046,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4047,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 656,
  id = 4048,
  cardid = 1048
 },
 {
  drop_weight = 2000,
  gameid = 656,
  id = 4049,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 656,
  id = 4050,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 656,
  id = 4051,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4052,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4053,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 656,
  id = 4054,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4055,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4056,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4057,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4058,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4059,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4060,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4061,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4062,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4063,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4064,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4065,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4066,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 656,
  id = 4067,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4068,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4069,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4070,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4071,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4072,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4073,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4074,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4075,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4076,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4077,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 656,
  id = 4078,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 656,
  id = 4079,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 656,
  id = 4080,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4081,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4082,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4083,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4084,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4085,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4086,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4087,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4088,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4089,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 657,
  id = 4090,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4091,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 657,
  id = 4092,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 657,
  id = 4093,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 657,
  id = 4094,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 657,
  id = 4095,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 657,
  id = 4096,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4097,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4098,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4099,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4100,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4101,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4102,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 657,
  id = 4103,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 657,
  id = 4104,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4105,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4106,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4107,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4108,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4109,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4110,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4111,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4112,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4113,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4114,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4115,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 657,
  id = 4116,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4117,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4118,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4119,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4120,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4121,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4122,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4123,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4124,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4125,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4126,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4127,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 657,
  id = 4128,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 657,
  id = 4129,
  cardid = 1049
 },
 {
  drop_weight = 2000,
  gameid = 657,
  id = 4130,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 657,
  id = 4131,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4132,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4133,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 657,
  id = 4134,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4135,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4136,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4137,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4138,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4139,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4140,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4141,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4142,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4143,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4144,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4145,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4146,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 657,
  id = 4147,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4148,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4149,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4150,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4151,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4152,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4153,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4154,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4155,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4156,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4157,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 657,
  id = 4158,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 657,
  id = 4159,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 657,
  id = 4160,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4161,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4162,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4163,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4164,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4165,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4166,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4167,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4168,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4169,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 658,
  id = 4170,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4171,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 658,
  id = 4172,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 658,
  id = 4173,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 658,
  id = 4174,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 658,
  id = 4175,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 658,
  id = 4176,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4177,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4178,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4179,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4180,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4181,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4182,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 658,
  id = 4183,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 658,
  id = 4184,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4185,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4186,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4187,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4188,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4189,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4190,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4191,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4192,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4193,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4194,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4195,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 658,
  id = 4196,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4197,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4198,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4199,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4200,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4201,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4202,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4203,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4204,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4205,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4206,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4207,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 658,
  id = 4208,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 658,
  id = 4209,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 658,
  id = 4210,
  cardid = 1050
 },
 {
  drop_weight = 2000,
  gameid = 658,
  id = 4211,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4212,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4213,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 658,
  id = 4214,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4215,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4216,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4217,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4218,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4219,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4220,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4221,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4222,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4223,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4224,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4225,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4226,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 658,
  id = 4227,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4228,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4229,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4230,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4231,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4232,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4233,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4234,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4235,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4236,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4237,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 658,
  id = 4238,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 658,
  id = 4239,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 658,
  id = 4240,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4241,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4242,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4243,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4244,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4245,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4246,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 659,
  id = 4247,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 659,
  id = 4248,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 659,
  id = 4249,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4250,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4251,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4252,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4253,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4254,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4255,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4256,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4257,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 659,
  id = 4258,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4259,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4260,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4261,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 659,
  id = 4262,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4263,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4264,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 659,
  id = 4265,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4266,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4267,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4268,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4269,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4270,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4271,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4272,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4273,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4274,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4275,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4276,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4277,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4278,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4279,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 659,
  id = 4280,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4281,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4282,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4283,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4284,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4285,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4286,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4287,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4288,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4289,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4290,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4291,
  cardid = 1051
 },
 {
  drop_weight = 2000,
  gameid = 659,
  id = 4292,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4293,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4294,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 659,
  id = 4295,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 659,
  id = 4296,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 659,
  id = 4297,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 659,
  id = 4298,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4299,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4300,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4301,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4302,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4303,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4304,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 659,
  id = 4305,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4306,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4307,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4308,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4309,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4310,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4311,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 659,
  id = 4312,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 659,
  id = 4313,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4314,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4315,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4316,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4317,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4318,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4319,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 659,
  id = 4320,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 660,
  id = 4321,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 660,
  id = 4322,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 660,
  id = 4323,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 660,
  id = 4324,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 660,
  id = 4325,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4326,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4327,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4328,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4329,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4330,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4331,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4332,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4333,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4334,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4335,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4336,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4337,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4338,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4339,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 660,
  id = 4340,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4341,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4342,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4343,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4344,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4345,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4346,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4347,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4348,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4349,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4350,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4351,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4352,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4353,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4354,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4355,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4356,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4357,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4358,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4359,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4360,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4361,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4362,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4363,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 660,
  id = 4364,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4365,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 660,
  id = 4366,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 660,
  id = 4367,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4368,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4369,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4370,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4371,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4372,
  cardid = 1052
 },
 {
  drop_weight = 2000,
  gameid = 660,
  id = 4373,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4374,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4375,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4376,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4377,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4378,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4379,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4380,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4381,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4382,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4383,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4384,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4385,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4386,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4387,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 660,
  id = 4388,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 660,
  id = 4389,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4390,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4391,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4392,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4393,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 660,
  id = 4394,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4395,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 660,
  id = 4396,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4397,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4398,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4399,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 660,
  id = 4400,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4401,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4402,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4403,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4404,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4405,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4406,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4407,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4408,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4409,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 661,
  id = 4410,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4411,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 661,
  id = 4412,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 661,
  id = 4413,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 661,
  id = 4414,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 661,
  id = 4415,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 661,
  id = 4416,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4417,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4418,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4419,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4420,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4421,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4422,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 661,
  id = 4423,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 661,
  id = 4424,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4425,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4426,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4427,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4428,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4429,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4430,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4431,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4432,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4433,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4434,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4435,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 661,
  id = 4436,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4437,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4438,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4439,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4440,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4441,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4442,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4443,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4444,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4445,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4446,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4447,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 661,
  id = 4448,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 661,
  id = 4449,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 661,
  id = 4450,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 661,
  id = 4451,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4452,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4453,
  cardid = 1053
 },
 {
  drop_weight = 2000,
  gameid = 661,
  id = 4454,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4455,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4456,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4457,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4458,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4459,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4460,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4461,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4462,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4463,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4464,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4465,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4466,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 661,
  id = 4467,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4468,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4469,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4470,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4471,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4472,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4473,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4474,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4475,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4476,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4477,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 661,
  id = 4478,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 661,
  id = 4479,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 661,
  id = 4480,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4481,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4482,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4483,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4484,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4485,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4486,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 662,
  id = 4487,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 662,
  id = 4488,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 662,
  id = 4489,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4490,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4491,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4492,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4493,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4494,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4495,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4496,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4497,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 662,
  id = 4498,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4499,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4500,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4501,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 662,
  id = 4502,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4503,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4504,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 662,
  id = 4505,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4506,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4507,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4508,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4509,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4510,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4511,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4512,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4513,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4514,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4515,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4516,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4517,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4518,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4519,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 662,
  id = 4520,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4521,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4522,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4523,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4524,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4525,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4526,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4527,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4528,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4529,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4530,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4531,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 662,
  id = 4532,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4533,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4534,
  cardid = 1054
 },
 {
  drop_weight = 2000,
  gameid = 662,
  id = 4535,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 662,
  id = 4536,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 662,
  id = 4537,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 662,
  id = 4538,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4539,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4540,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4541,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4542,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4543,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4544,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 662,
  id = 4545,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4546,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4547,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4548,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4549,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4550,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4551,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 662,
  id = 4552,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 662,
  id = 4553,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4554,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4555,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4556,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4557,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4558,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4559,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 662,
  id = 4560,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4561,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4562,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4563,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4564,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4565,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4566,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 663,
  id = 4567,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 663,
  id = 4568,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 663,
  id = 4569,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4570,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4571,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4572,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4573,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4574,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4575,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4576,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4577,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 663,
  id = 4578,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4579,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4580,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4581,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 663,
  id = 4582,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4583,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4584,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 663,
  id = 4585,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4586,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4587,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4588,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4589,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4590,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4591,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4592,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4593,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4594,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4595,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4596,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4597,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4598,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4599,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 663,
  id = 4600,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4601,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4602,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4603,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4604,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4605,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4606,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4607,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4608,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4609,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4610,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4611,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 663,
  id = 4612,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4613,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4614,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 663,
  id = 4615,
  cardid = 1055
 },
 {
  drop_weight = 2000,
  gameid = 663,
  id = 4616,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 663,
  id = 4617,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 663,
  id = 4618,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4619,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4620,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4621,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4622,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4623,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4624,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 663,
  id = 4625,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4626,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4627,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4628,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4629,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4630,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4631,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 663,
  id = 4632,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 663,
  id = 4633,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4634,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4635,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4636,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4637,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4638,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4639,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 663,
  id = 4640,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4641,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4642,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4643,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4644,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4645,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4646,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 664,
  id = 4647,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 664,
  id = 4648,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 664,
  id = 4649,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4650,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4651,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4652,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4653,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4654,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4655,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4656,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4657,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 664,
  id = 4658,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4659,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4660,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4661,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 664,
  id = 4662,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4663,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4664,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 664,
  id = 4665,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4666,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4667,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4668,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4669,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4670,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4671,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4672,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4673,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4674,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4675,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4676,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4677,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4678,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4679,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 664,
  id = 4680,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4681,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4682,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4683,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4684,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4685,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4686,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4687,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4688,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4689,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4690,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4691,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 664,
  id = 4692,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4693,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4694,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 664,
  id = 4695,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 664,
  id = 4696,
  cardid = 1056
 },
 {
  drop_weight = 2000,
  gameid = 664,
  id = 4697,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 664,
  id = 4698,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4699,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4700,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4701,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4702,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4703,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4704,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 664,
  id = 4705,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4706,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4707,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4708,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4709,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4710,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4711,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 664,
  id = 4712,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 664,
  id = 4713,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4714,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4715,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4716,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4717,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4718,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4719,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 664,
  id = 4720,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4721,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4722,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4723,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4724,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4725,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4726,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 665,
  id = 4727,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 665,
  id = 4728,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 665,
  id = 4729,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4730,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4731,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4732,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4733,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4734,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4735,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4736,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4737,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 665,
  id = 4738,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4739,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4740,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4741,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 665,
  id = 4742,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4743,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4744,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 665,
  id = 4745,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4746,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4747,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4748,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4749,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4750,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4751,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4752,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4753,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4754,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4755,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4756,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4757,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4758,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4759,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 665,
  id = 4760,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4761,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4762,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4763,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4764,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4765,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4766,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4767,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4768,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4769,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4770,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4771,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 665,
  id = 4772,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4773,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4774,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 665,
  id = 4775,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 665,
  id = 4776,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 665,
  id = 4777,
  cardid = 1057
 },
 {
  drop_weight = 2000,
  gameid = 665,
  id = 4778,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4779,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4780,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4781,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4782,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4783,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4784,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 665,
  id = 4785,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4786,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4787,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4788,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4789,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4790,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4791,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 665,
  id = 4792,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 665,
  id = 4793,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4794,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4795,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4796,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4797,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4798,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4799,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 665,
  id = 4800,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4801,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4802,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4803,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4804,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4805,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 666,
  id = 4806,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4807,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4808,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4809,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4810,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 666,
  id = 4811,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4812,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4813,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4814,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4815,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4816,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 666,
  id = 4817,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4818,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 666,
  id = 4819,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4820,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 666,
  id = 4821,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4822,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4823,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4824,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4825,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 666,
  id = 4826,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 666,
  id = 4827,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 666,
  id = 4828,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4829,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4830,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4831,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4832,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4833,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4834,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4835,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4836,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4837,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4838,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 666,
  id = 4839,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4840,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4841,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4842,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4843,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4844,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4845,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4846,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4847,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4848,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4849,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4850,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4851,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4852,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4853,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4854,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4855,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4856,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4857,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4858,
  cardid = 1058
 },
 {
  drop_weight = 2000,
  gameid = 666,
  id = 4859,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 666,
  id = 4860,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 666,
  id = 4861,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4862,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 666,
  id = 4863,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 666,
  id = 4864,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4865,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4866,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4867,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4868,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4869,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 666,
  id = 4870,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 666,
  id = 4871,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4872,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4873,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4874,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 666,
  id = 4875,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4876,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 666,
  id = 4877,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4878,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 666,
  id = 4879,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 666,
  id = 4880,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4881,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4882,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4883,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4884,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4885,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 667,
  id = 4886,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4887,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4888,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4889,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4890,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 667,
  id = 4891,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4892,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4893,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4894,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4895,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4896,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 667,
  id = 4897,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4898,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 667,
  id = 4899,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4900,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4901,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4902,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4903,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4904,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4905,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 667,
  id = 4906,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 667,
  id = 4907,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 667,
  id = 4908,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4909,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4910,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4911,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4912,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4913,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4914,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4915,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4916,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4917,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4918,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4919,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4920,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4921,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4922,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4923,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4924,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4925,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4926,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4927,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4928,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4929,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4930,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4931,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4932,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4933,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4934,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4935,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4936,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4937,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4938,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4939,
  cardid = 1059
 },
 {
  drop_weight = 2000,
  gameid = 667,
  id = 4940,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4941,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4942,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4943,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4944,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4945,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4946,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4947,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4948,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4949,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4950,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 667,
  id = 4951,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4952,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4953,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4954,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 667,
  id = 4955,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4956,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 667,
  id = 4957,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4958,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 667,
  id = 4959,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 667,
  id = 4960,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4961,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4962,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4963,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4964,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4965,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 682,
  id = 4966,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4967,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4968,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4969,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4970,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 682,
  id = 4971,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4972,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4973,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4974,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4975,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4976,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 682,
  id = 4977,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4978,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 682,
  id = 4979,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4980,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 682,
  id = 4981,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4982,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4983,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4984,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4985,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 682,
  id = 4986,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 682,
  id = 4987,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 682,
  id = 4988,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4989,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4990,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4991,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4992,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4993,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4994,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4995,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4996,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4997,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 4998,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 682,
  id = 4999,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5000,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5001,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5002,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5003,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5004,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5005,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5006,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5007,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5008,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5009,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5010,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5011,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5012,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5013,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5014,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5015,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5016,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5017,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5018,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 682,
  id = 5019,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 682,
  id = 5020,
  cardid = 1060
 },
 {
  drop_weight = 2000,
  gameid = 682,
  id = 5021,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5022,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 682,
  id = 5023,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 682,
  id = 5024,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5025,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5026,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5027,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5028,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5029,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 682,
  id = 5030,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 682,
  id = 5031,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5032,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5033,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5034,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 682,
  id = 5035,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5036,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 682,
  id = 5037,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5038,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 682,
  id = 5039,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 682,
  id = 5040,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5041,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5042,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5043,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5044,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5045,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5046,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5047,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5048,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5049,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5050,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5051,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5052,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5053,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5054,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5055,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5056,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5057,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5058,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5059,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5060,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5061,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5062,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5063,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5064,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5065,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5066,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5067,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5068,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 655,
  id = 5069,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 655,
  id = 5070,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 655,
  id = 5071,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 655,
  id = 5072,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 655,
  id = 5073,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 655,
  id = 5074,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 655,
  id = 5075,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5076,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 655,
  id = 5077,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 655,
  id = 5078,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5079,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5080,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 655,
  id = 5081,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 655,
  id = 5082,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 655,
  id = 5083,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5084,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 655,
  id = 5085,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5086,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5087,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5088,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5089,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5090,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5091,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5092,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5093,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5094,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5095,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5096,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5097,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5098,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5099,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5100,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5101,
  cardid = 1061
 },
 {
  drop_weight = 2000,
  gameid = 655,
  id = 5102,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5103,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5104,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5105,
  cardid = 1065
 },
 {
  drop_weight = 60,
  gameid = 655,
  id = 5106,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5107,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5108,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5109,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5110,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5111,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5112,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5113,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5114,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5115,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5116,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5117,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5118,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5119,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 655,
  id = 5120,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5121,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5122,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5123,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5124,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5125,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 653,
  id = 5126,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5127,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5128,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5129,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5130,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 653,
  id = 5131,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5132,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5133,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5134,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5135,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5136,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 653,
  id = 5137,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5138,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 653,
  id = 5139,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5140,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 653,
  id = 5141,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5142,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5143,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5144,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5145,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 653,
  id = 5146,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 653,
  id = 5147,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 653,
  id = 5148,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5149,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5150,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5151,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5152,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5153,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5154,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5155,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5156,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5157,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5158,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 653,
  id = 5159,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5160,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5161,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5162,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5163,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5164,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5165,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5166,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5167,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5168,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5169,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5170,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5171,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5172,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5173,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5174,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5175,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5176,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5177,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5178,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 653,
  id = 5179,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 653,
  id = 5180,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 653,
  id = 5181,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5182,
  cardid = 1062
 },
 {
  drop_weight = 2000,
  gameid = 653,
  id = 5183,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 653,
  id = 5184,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5185,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5186,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5187,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5188,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5189,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 653,
  id = 5190,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 653,
  id = 5191,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5192,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5193,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5194,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 653,
  id = 5195,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5196,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 653,
  id = 5197,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5198,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 653,
  id = 5199,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 653,
  id = 5200,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5201,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5202,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5203,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5204,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5205,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 654,
  id = 5206,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5207,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5208,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5209,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5210,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 654,
  id = 5211,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5212,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5213,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5214,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5215,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5216,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 654,
  id = 5217,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5218,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 654,
  id = 5219,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5220,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 654,
  id = 5221,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5222,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5223,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5224,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5225,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 654,
  id = 5226,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 654,
  id = 5227,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 654,
  id = 5228,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5229,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5230,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5231,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5232,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5233,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5234,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5235,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5236,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5237,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5238,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 654,
  id = 5239,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5240,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5241,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5242,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5243,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5244,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5245,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5246,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5247,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5248,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5249,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5250,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5251,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5252,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5253,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5254,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5255,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5256,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5257,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5258,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 654,
  id = 5259,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 654,
  id = 5260,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 654,
  id = 5261,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5262,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 654,
  id = 5263,
  cardid = 1063
 },
 {
  drop_weight = 2000,
  gameid = 654,
  id = 5264,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5265,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5266,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5267,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5268,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5269,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 654,
  id = 5270,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 654,
  id = 5271,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5272,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5273,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5274,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 654,
  id = 5275,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5276,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 654,
  id = 5277,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5278,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 654,
  id = 5279,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 654,
  id = 5280,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5281,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5282,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5283,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5284,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5285,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5286,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 683,
  id = 5287,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 683,
  id = 5288,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 683,
  id = 5289,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5290,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5291,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5292,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5293,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5294,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5295,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5296,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5297,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 683,
  id = 5298,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5299,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5300,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5301,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 683,
  id = 5302,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5303,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5304,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 683,
  id = 5305,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5306,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5307,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5308,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5309,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5310,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5311,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5312,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5313,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5314,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5315,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5316,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5317,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5318,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5319,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 683,
  id = 5320,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5321,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5322,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5323,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5324,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5325,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5326,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5327,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5328,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5329,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5330,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5331,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 683,
  id = 5332,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5333,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5334,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 683,
  id = 5335,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 683,
  id = 5336,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 683,
  id = 5337,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 683,
  id = 5338,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5339,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5340,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5341,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5342,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5343,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5344,
  cardid = 1064
 },
 {
  drop_weight = 2000,
  gameid = 683,
  id = 5345,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5346,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5347,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5348,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5349,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5350,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5351,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 683,
  id = 5352,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 683,
  id = 5353,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5354,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5355,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5356,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5357,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5358,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5359,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 683,
  id = 5360,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5361,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5362,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5363,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5364,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5365,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5366,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5367,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5368,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5369,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5370,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5371,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5372,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5373,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5374,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5375,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5376,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5377,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5378,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5379,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5380,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5381,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5382,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5383,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5384,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5385,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5386,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5387,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5388,
  cardid = 1028
 },
 {
  drop_weight = 60,
  gameid = 684,
  id = 5389,
  cardid = 1029
 },
 {
  drop_weight = 20,
  gameid = 684,
  id = 5390,
  cardid = 1030
 },
 {
  drop_weight = 40,
  gameid = 684,
  id = 5391,
  cardid = 1031
 },
 {
  drop_weight = 60,
  gameid = 684,
  id = 5392,
  cardid = 1032
 },
 {
  drop_weight = 80,
  gameid = 684,
  id = 5393,
  cardid = 1033
 },
 {
  drop_weight = 20,
  gameid = 684,
  id = 5394,
  cardid = 1034
 },
 {
  drop_weight = 40,
  gameid = 684,
  id = 5395,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5396,
  cardid = 1036
 },
 {
  drop_weight = 100,
  gameid = 684,
  id = 5397,
  cardid = 1037
 },
 {
  drop_weight = 80,
  gameid = 684,
  id = 5398,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5399,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5400,
  cardid = 1040
 },
 {
  drop_weight = 40,
  gameid = 684,
  id = 5401,
  cardid = 1041
 },
 {
  drop_weight = 40,
  gameid = 684,
  id = 5402,
  cardid = 1042
 },
 {
  drop_weight = 60,
  gameid = 684,
  id = 5403,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5404,
  cardid = 1044
 },
 {
  drop_weight = 40,
  gameid = 684,
  id = 5405,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5406,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5407,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5408,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5409,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5410,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5411,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5412,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5413,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5414,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5415,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5416,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5417,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5418,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5419,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5420,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5421,
  cardid = 1061
 },
 {
  drop_weight = 80,
  gameid = 684,
  id = 5422,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5423,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5424,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5425,
  cardid = 1065
 },
 {
  drop_weight = 2000,
  gameid = 684,
  id = 5426,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5427,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5428,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5429,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5430,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5431,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5432,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5433,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5434,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5435,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5436,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5437,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5438,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5439,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 684,
  id = 5440,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5441,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5442,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5443,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5444,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5445,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5446,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5447,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5448,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5449,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 688,
  id = 5450,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5451,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 688,
  id = 5452,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 688,
  id = 5453,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 688,
  id = 5454,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 688,
  id = 5455,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 688,
  id = 5456,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5457,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5458,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5459,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5460,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5461,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5462,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 688,
  id = 5463,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 688,
  id = 5464,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5465,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5466,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5467,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5468,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5469,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5470,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5471,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5472,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5473,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5474,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5475,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 688,
  id = 5476,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5477,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5478,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5479,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5480,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5481,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5482,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5483,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5484,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5485,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5486,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5487,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 688,
  id = 5488,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 688,
  id = 5489,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 688,
  id = 5490,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 688,
  id = 5491,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5492,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5493,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 688,
  id = 5494,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5495,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5496,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5497,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5498,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5499,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5500,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5501,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5502,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5503,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5504,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5505,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5506,
  cardid = 1066
 },
 {
  drop_weight = 2000,
  gameid = 688,
  id = 5507,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5508,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5509,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5510,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5511,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5512,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5513,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5514,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5515,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5516,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5517,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 688,
  id = 5518,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 688,
  id = 5519,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 688,
  id = 5520,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 686,
  id = 5521,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 686,
  id = 5522,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 686,
  id = 5523,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 686,
  id = 5524,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 686,
  id = 5525,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5526,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5527,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5528,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5529,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5530,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5531,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5532,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5533,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5534,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5535,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5536,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5537,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5538,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5539,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 686,
  id = 5540,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5541,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5542,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5543,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5544,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5545,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5546,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5547,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5548,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5549,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5550,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5551,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5552,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5553,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5554,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5555,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5556,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5557,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5558,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5559,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5560,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5561,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5562,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5563,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 686,
  id = 5564,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5565,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 686,
  id = 5566,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 686,
  id = 5567,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5568,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5569,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5570,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5571,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5572,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 686,
  id = 5573,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5574,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5575,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5576,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5577,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5578,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5579,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5580,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5581,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5582,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5583,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5584,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5585,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5586,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5587,
  cardid = 1067
 },
 {
  drop_weight = 2000,
  gameid = 686,
  id = 5588,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 686,
  id = 5589,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5590,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5591,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5592,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5593,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 686,
  id = 5594,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5595,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 686,
  id = 5596,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5597,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5598,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5599,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 686,
  id = 5600,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 687,
  id = 5601,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 687,
  id = 5602,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 687,
  id = 5603,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 687,
  id = 5604,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 687,
  id = 5605,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5606,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5607,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5608,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5609,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5610,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5611,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5612,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5613,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5614,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5615,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5616,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5617,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5618,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5619,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 687,
  id = 5620,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5621,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5622,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5623,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5624,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5625,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5626,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5627,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5628,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5629,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5630,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5631,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5632,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5633,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5634,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5635,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5636,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5637,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5638,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5639,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5640,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5641,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5642,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5643,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 687,
  id = 5644,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5645,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 687,
  id = 5646,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 687,
  id = 5647,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5648,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5649,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5650,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5651,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5652,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 687,
  id = 5653,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5654,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5655,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5656,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5657,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5658,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5659,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5660,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5661,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5662,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5663,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5664,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5665,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5666,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5667,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 687,
  id = 5668,
  cardid = 1068
 },
 {
  drop_weight = 2000,
  gameid = 687,
  id = 5669,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5670,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5671,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5672,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5673,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 687,
  id = 5674,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5675,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 687,
  id = 5676,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5677,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5678,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5679,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 687,
  id = 5680,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5681,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5682,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5683,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5684,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5685,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 669,
  id = 5686,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5687,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5688,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5689,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5690,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 669,
  id = 5691,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5692,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5693,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5694,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5695,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5696,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 669,
  id = 5697,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5698,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 669,
  id = 5699,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5700,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 669,
  id = 5701,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5702,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5703,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5704,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5705,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 669,
  id = 5706,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 669,
  id = 5707,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 669,
  id = 5708,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5709,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5710,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5711,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5712,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5713,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5714,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5715,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5716,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5717,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5718,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 669,
  id = 5719,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5720,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5721,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5722,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5723,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5724,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5725,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5726,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5727,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5728,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5729,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5730,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5731,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5732,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5733,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5734,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5735,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5736,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5737,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5738,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 669,
  id = 5739,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 669,
  id = 5740,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 669,
  id = 5741,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5742,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 669,
  id = 5743,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 669,
  id = 5744,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5745,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5746,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5747,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5748,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5749,
  cardid = 1069
 },
 {
  drop_weight = 2000,
  gameid = 669,
  id = 5750,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 669,
  id = 5751,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5752,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5753,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5754,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 669,
  id = 5755,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5756,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 669,
  id = 5757,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5758,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 669,
  id = 5759,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 669,
  id = 5760,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5761,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5762,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5763,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5764,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5765,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 675,
  id = 5766,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5767,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5768,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5769,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5770,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 675,
  id = 5771,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5772,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5773,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5774,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5775,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5776,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 675,
  id = 5777,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5778,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 675,
  id = 5779,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5780,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5781,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5782,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5783,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5784,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5785,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 675,
  id = 5786,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 675,
  id = 5787,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 675,
  id = 5788,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5789,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5790,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5791,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5792,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5793,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5794,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5795,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5796,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5797,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5798,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5799,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5800,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5801,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5802,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5803,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5804,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5805,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5806,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5807,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5808,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5809,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5810,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5811,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5812,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5813,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5814,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5815,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5816,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5817,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5818,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5819,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 675,
  id = 5820,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5821,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5822,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5823,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5824,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5825,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5826,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5827,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5828,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5829,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5830,
  cardid = 1070
 },
 {
  drop_weight = 2000,
  gameid = 675,
  id = 5831,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5832,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5833,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5834,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 675,
  id = 5835,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5836,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 675,
  id = 5837,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5838,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 675,
  id = 5839,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 675,
  id = 5840,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5841,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5842,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5843,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5844,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5845,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5846,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 671,
  id = 5847,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 671,
  id = 5848,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 671,
  id = 5849,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5850,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5851,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5852,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5853,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5854,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5855,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5856,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5857,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 671,
  id = 5858,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5859,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5860,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5861,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 671,
  id = 5862,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5863,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5864,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 671,
  id = 5865,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5866,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5867,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5868,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5869,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5870,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5871,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5872,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5873,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5874,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5875,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5876,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5877,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5878,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5879,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 671,
  id = 5880,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5881,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5882,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5883,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5884,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5885,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5886,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5887,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5888,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5889,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5890,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5891,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 671,
  id = 5892,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5893,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5894,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 671,
  id = 5895,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 671,
  id = 5896,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 671,
  id = 5897,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 671,
  id = 5898,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5899,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5900,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5901,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5902,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5903,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5904,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 671,
  id = 5905,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5906,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5907,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5908,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5909,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5910,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5911,
  cardid = 1071
 },
 {
  drop_weight = 2000,
  gameid = 671,
  id = 5912,
  cardid = 1072
 },
 {
  drop_weight = 80,
  gameid = 671,
  id = 5913,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5914,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5915,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5916,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5917,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5918,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5919,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 671,
  id = 5920,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5921,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5922,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5923,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5924,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5925,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5926,
  cardid = 1006
 },
 {
  drop_weight = 60,
  gameid = 672,
  id = 5927,
  cardid = 1007
 },
 {
  drop_weight = 100,
  gameid = 672,
  id = 5928,
  cardid = 1008
 },
 {
  drop_weight = 80,
  gameid = 672,
  id = 5929,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5930,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5931,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5932,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5933,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5934,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5935,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5936,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5937,
  cardid = 1017
 },
 {
  drop_weight = 60,
  gameid = 672,
  id = 5938,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5939,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5940,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5941,
  cardid = 1021
 },
 {
  drop_weight = 80,
  gameid = 672,
  id = 5942,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5943,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5944,
  cardid = 1024
 },
 {
  drop_weight = 40,
  gameid = 672,
  id = 5945,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5946,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5947,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5948,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5949,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5950,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5951,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5952,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5953,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5954,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5955,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5956,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5957,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5958,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5959,
  cardid = 1039
 },
 {
  drop_weight = 100,
  gameid = 672,
  id = 5960,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5961,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5962,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5963,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5964,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5965,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5966,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5967,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5968,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5969,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5970,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5971,
  cardid = 1051
 },
 {
  drop_weight = 40,
  gameid = 672,
  id = 5972,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5973,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5974,
  cardid = 1054
 },
 {
  drop_weight = 100,
  gameid = 672,
  id = 5975,
  cardid = 1055
 },
 {
  drop_weight = 100,
  gameid = 672,
  id = 5976,
  cardid = 1056
 },
 {
  drop_weight = 80,
  gameid = 672,
  id = 5977,
  cardid = 1057
 },
 {
  drop_weight = 100,
  gameid = 672,
  id = 5978,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5979,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5980,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5981,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5982,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5983,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5984,
  cardid = 1064
 },
 {
  drop_weight = 60,
  gameid = 672,
  id = 5985,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5986,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5987,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5988,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5989,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5990,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5991,
  cardid = 1071
 },
 {
  drop_weight = 60,
  gameid = 672,
  id = 5992,
  cardid = 1072
 },
 {
  drop_weight = 2000,
  gameid = 672,
  id = 5993,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5994,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5995,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5996,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5997,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5998,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 5999,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 672,
  id = 6000,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 673,
  id = 6001,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 673,
  id = 6002,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 673,
  id = 6003,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 673,
  id = 6004,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 673,
  id = 6005,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6006,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6007,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6008,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6009,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6010,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6011,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6012,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6013,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6014,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6015,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6016,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6017,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6018,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6019,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 673,
  id = 6020,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6021,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6022,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6023,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6024,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6025,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6026,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6027,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6028,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6029,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6030,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6031,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6032,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6033,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6034,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6035,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6036,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6037,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6038,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6039,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6040,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6041,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6042,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6043,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 673,
  id = 6044,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6045,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 673,
  id = 6046,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 673,
  id = 6047,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6048,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6049,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6050,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6051,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6052,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 673,
  id = 6053,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6054,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6055,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6056,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6057,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6058,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6059,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6060,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6061,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6062,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6063,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6064,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6065,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6066,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6067,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 673,
  id = 6068,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 673,
  id = 6069,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6070,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6071,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6072,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6073,
  cardid = 1073
 },
 {
  drop_weight = 2000,
  gameid = 673,
  id = 6074,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6075,
  cardid = 1075
 },
 {
  drop_weight = 20,
  gameid = 673,
  id = 6076,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6077,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6078,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6079,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 673,
  id = 6080,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6081,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6082,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6083,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6084,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6085,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 677,
  id = 6086,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6087,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6088,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6089,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6090,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 677,
  id = 6091,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6092,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6093,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6094,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6095,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6096,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 677,
  id = 6097,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6098,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 677,
  id = 6099,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6100,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6101,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6102,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6103,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6104,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6105,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 677,
  id = 6106,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 677,
  id = 6107,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 677,
  id = 6108,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6109,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6110,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6111,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6112,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6113,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6114,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6115,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6116,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6117,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6118,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6119,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6120,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6121,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6122,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6123,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6124,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6125,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6126,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6127,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6128,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6129,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6130,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6131,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6132,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6133,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6134,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6135,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6136,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6137,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6138,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6139,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 677,
  id = 6140,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6141,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6142,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6143,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6144,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6145,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6146,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6147,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6148,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6149,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6150,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 677,
  id = 6151,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6152,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6153,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6154,
  cardid = 1074
 },
 {
  drop_weight = 2000,
  gameid = 677,
  id = 6155,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6156,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 677,
  id = 6157,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6158,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 677,
  id = 6159,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 677,
  id = 6160,
  cardid = 1080
 },
 {
  drop_weight = 20,
  gameid = 649,
  id = 6161,
  cardid = 1001
 },
 {
  drop_weight = 40,
  gameid = 649,
  id = 6162,
  cardid = 1002
 },
 {
  drop_weight = 60,
  gameid = 649,
  id = 6163,
  cardid = 1003
 },
 {
  drop_weight = 80,
  gameid = 649,
  id = 6164,
  cardid = 1004
 },
 {
  drop_weight = 40,
  gameid = 649,
  id = 6165,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6166,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6167,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6168,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6169,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6170,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6171,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6172,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6173,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6174,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6175,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6176,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6177,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6178,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6179,
  cardid = 1019
 },
 {
  drop_weight = 80,
  gameid = 649,
  id = 6180,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6181,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6182,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6183,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6184,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6185,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6186,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6187,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6188,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6189,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6190,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6191,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6192,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6193,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6194,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6195,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6196,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6197,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6198,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6199,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6200,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6201,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6202,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6203,
  cardid = 1043
 },
 {
  drop_weight = 80,
  gameid = 649,
  id = 6204,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6205,
  cardid = 1045
 },
 {
  drop_weight = 40,
  gameid = 649,
  id = 6206,
  cardid = 1046
 },
 {
  drop_weight = 20,
  gameid = 649,
  id = 6207,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6208,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6209,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6210,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6211,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6212,
  cardid = 1052
 },
 {
  drop_weight = 20,
  gameid = 649,
  id = 6213,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6214,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6215,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6216,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6217,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6218,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6219,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6220,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6221,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6222,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6223,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6224,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6225,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6226,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6227,
  cardid = 1067
 },
 {
  drop_weight = 40,
  gameid = 649,
  id = 6228,
  cardid = 1068
 },
 {
  drop_weight = 40,
  gameid = 649,
  id = 6229,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6230,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6231,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6232,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6233,
  cardid = 1073
 },
 {
  drop_weight = 40,
  gameid = 649,
  id = 6234,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6235,
  cardid = 1075
 },
 {
  drop_weight = 2000,
  gameid = 649,
  id = 6236,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6237,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6238,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6239,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 649,
  id = 6240,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6241,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6242,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6243,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6244,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6245,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 674,
  id = 6246,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6247,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6248,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6249,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6250,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 674,
  id = 6251,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6252,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6253,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6254,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6255,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6256,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 674,
  id = 6257,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6258,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 674,
  id = 6259,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6260,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6261,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6262,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6263,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6264,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6265,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 674,
  id = 6266,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 674,
  id = 6267,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 674,
  id = 6268,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6269,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6270,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6271,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6272,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6273,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6274,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6275,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6276,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6277,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6278,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6279,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6280,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6281,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6282,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6283,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6284,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6285,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6286,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6287,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6288,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6289,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6290,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6291,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6292,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6293,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6294,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6295,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6296,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6297,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6298,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6299,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 674,
  id = 6300,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6301,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6302,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6303,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6304,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6305,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6306,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6307,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6308,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6309,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6310,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 674,
  id = 6311,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6312,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6313,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6314,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 674,
  id = 6315,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6316,
  cardid = 1076
 },
 {
  drop_weight = 2000,
  gameid = 674,
  id = 6317,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6318,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 674,
  id = 6319,
  cardid = 1079
 },
 {
  drop_weight = 60,
  gameid = 674,
  id = 6320,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6321,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6322,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6323,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6324,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6325,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6326,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6327,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6328,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6329,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 670,
  id = 6330,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6331,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 670,
  id = 6332,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 670,
  id = 6333,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 670,
  id = 6334,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 670,
  id = 6335,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 670,
  id = 6336,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6337,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6338,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6339,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6340,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6341,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6342,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 670,
  id = 6343,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 670,
  id = 6344,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6345,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6346,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6347,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6348,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6349,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6350,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6351,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6352,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6353,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6354,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6355,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 670,
  id = 6356,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6357,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6358,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6359,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6360,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6361,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6362,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6363,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6364,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6365,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6366,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6367,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 670,
  id = 6368,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 670,
  id = 6369,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 670,
  id = 6370,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 670,
  id = 6371,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6372,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6373,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 670,
  id = 6374,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6375,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6376,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6377,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6378,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6379,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6380,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6381,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6382,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6383,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6384,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6385,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6386,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 670,
  id = 6387,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6388,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6389,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6390,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6391,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6392,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6393,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6394,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6395,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6396,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6397,
  cardid = 1077
 },
 {
  drop_weight = 2000,
  gameid = 670,
  id = 6398,
  cardid = 1078
 },
 {
  drop_weight = 100,
  gameid = 670,
  id = 6399,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 670,
  id = 6400,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6401,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6402,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6403,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6404,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6405,
  cardid = 1005
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6406,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6407,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6408,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6409,
  cardid = 1009
 },
 {
  drop_weight = 40,
  gameid = 676,
  id = 6410,
  cardid = 1010
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6411,
  cardid = 1011
 },
 {
  drop_weight = 60,
  gameid = 676,
  id = 6412,
  cardid = 1012
 },
 {
  drop_weight = 40,
  gameid = 676,
  id = 6413,
  cardid = 1013
 },
 {
  drop_weight = 80,
  gameid = 676,
  id = 6414,
  cardid = 1014
 },
 {
  drop_weight = 100,
  gameid = 676,
  id = 6415,
  cardid = 1015
 },
 {
  drop_weight = 100,
  gameid = 676,
  id = 6416,
  cardid = 1016
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6417,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6418,
  cardid = 1018
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6419,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6420,
  cardid = 1020
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6421,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6422,
  cardid = 1022
 },
 {
  drop_weight = 60,
  gameid = 676,
  id = 6423,
  cardid = 1023
 },
 {
  drop_weight = 40,
  gameid = 676,
  id = 6424,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6425,
  cardid = 1025
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6426,
  cardid = 1026
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6427,
  cardid = 1027
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6428,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6429,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6430,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6431,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6432,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6433,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6434,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6435,
  cardid = 1035
 },
 {
  drop_weight = 60,
  gameid = 676,
  id = 6436,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6437,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6438,
  cardid = 1038
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6439,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6440,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6441,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6442,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6443,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6444,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6445,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6446,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6447,
  cardid = 1047
 },
 {
  drop_weight = 100,
  gameid = 676,
  id = 6448,
  cardid = 1048
 },
 {
  drop_weight = 60,
  gameid = 676,
  id = 6449,
  cardid = 1049
 },
 {
  drop_weight = 40,
  gameid = 676,
  id = 6450,
  cardid = 1050
 },
 {
  drop_weight = 60,
  gameid = 676,
  id = 6451,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6452,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6453,
  cardid = 1053
 },
 {
  drop_weight = 80,
  gameid = 676,
  id = 6454,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6455,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6456,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6457,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6458,
  cardid = 1058
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6459,
  cardid = 1059
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6460,
  cardid = 1060
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6461,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6462,
  cardid = 1062
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6463,
  cardid = 1063
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6464,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6465,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6466,
  cardid = 1066
 },
 {
  drop_weight = 80,
  gameid = 676,
  id = 6467,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6468,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6469,
  cardid = 1069
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6470,
  cardid = 1070
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6471,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6472,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6473,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6474,
  cardid = 1074
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6475,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6476,
  cardid = 1076
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6477,
  cardid = 1077
 },
 {
  drop_weight = 100,
  gameid = 676,
  id = 6478,
  cardid = 1078
 },
 {
  drop_weight = 2000,
  gameid = 676,
  id = 6479,
  cardid = 1079
 },
 {
  drop_weight = 0,
  gameid = 676,
  id = 6480,
  cardid = 1080
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6481,
  cardid = 1001
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6482,
  cardid = 1002
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6483,
  cardid = 1003
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6484,
  cardid = 1004
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6485,
  cardid = 1005
 },
 {
  drop_weight = 20,
  gameid = 519,
  id = 6486,
  cardid = 1006
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6487,
  cardid = 1007
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6488,
  cardid = 1008
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6489,
  cardid = 1009
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6490,
  cardid = 1010
 },
 {
  drop_weight = 40,
  gameid = 519,
  id = 6491,
  cardid = 1011
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6492,
  cardid = 1012
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6493,
  cardid = 1013
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6494,
  cardid = 1014
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6495,
  cardid = 1015
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6496,
  cardid = 1016
 },
 {
  drop_weight = 40,
  gameid = 519,
  id = 6497,
  cardid = 1017
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6498,
  cardid = 1018
 },
 {
  drop_weight = 20,
  gameid = 519,
  id = 6499,
  cardid = 1019
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6500,
  cardid = 1020
 },
 {
  drop_weight = 60,
  gameid = 519,
  id = 6501,
  cardid = 1021
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6502,
  cardid = 1022
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6503,
  cardid = 1023
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6504,
  cardid = 1024
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6505,
  cardid = 1025
 },
 {
  drop_weight = 80,
  gameid = 519,
  id = 6506,
  cardid = 1026
 },
 {
  drop_weight = 20,
  gameid = 519,
  id = 6507,
  cardid = 1027
 },
 {
  drop_weight = 40,
  gameid = 519,
  id = 6508,
  cardid = 1028
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6509,
  cardid = 1029
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6510,
  cardid = 1030
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6511,
  cardid = 1031
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6512,
  cardid = 1032
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6513,
  cardid = 1033
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6514,
  cardid = 1034
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6515,
  cardid = 1035
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6516,
  cardid = 1036
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6517,
  cardid = 1037
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6518,
  cardid = 1038
 },
 {
  drop_weight = 60,
  gameid = 519,
  id = 6519,
  cardid = 1039
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6520,
  cardid = 1040
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6521,
  cardid = 1041
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6522,
  cardid = 1042
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6523,
  cardid = 1043
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6524,
  cardid = 1044
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6525,
  cardid = 1045
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6526,
  cardid = 1046
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6527,
  cardid = 1047
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6528,
  cardid = 1048
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6529,
  cardid = 1049
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6530,
  cardid = 1050
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6531,
  cardid = 1051
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6532,
  cardid = 1052
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6533,
  cardid = 1053
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6534,
  cardid = 1054
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6535,
  cardid = 1055
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6536,
  cardid = 1056
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6537,
  cardid = 1057
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6538,
  cardid = 1058
 },
 {
  drop_weight = 60,
  gameid = 519,
  id = 6539,
  cardid = 1059
 },
 {
  drop_weight = 40,
  gameid = 519,
  id = 6540,
  cardid = 1060
 },
 {
  drop_weight = 60,
  gameid = 519,
  id = 6541,
  cardid = 1061
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6542,
  cardid = 1062
 },
 {
  drop_weight = 60,
  gameid = 519,
  id = 6543,
  cardid = 1063
 },
 {
  drop_weight = 60,
  gameid = 519,
  id = 6544,
  cardid = 1064
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6545,
  cardid = 1065
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6546,
  cardid = 1066
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6547,
  cardid = 1067
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6548,
  cardid = 1068
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6549,
  cardid = 1069
 },
 {
  drop_weight = 60,
  gameid = 519,
  id = 6550,
  cardid = 1070
 },
 {
  drop_weight = 20,
  gameid = 519,
  id = 6551,
  cardid = 1071
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6552,
  cardid = 1072
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6553,
  cardid = 1073
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6554,
  cardid = 1074
 },
 {
  drop_weight = 80,
  gameid = 519,
  id = 6555,
  cardid = 1075
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6556,
  cardid = 1076
 },
 {
  drop_weight = 80,
  gameid = 519,
  id = 6557,
  cardid = 1077
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6558,
  cardid = 1078
 },
 {
  drop_weight = 0,
  gameid = 519,
  id = 6559,
  cardid = 1079
 },
 {
  drop_weight = 2000,
  gameid = 519,
  id = 6560,
  cardid = 1080
 }
}