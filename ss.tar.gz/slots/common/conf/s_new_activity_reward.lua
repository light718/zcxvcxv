local TYPE = PDEFINE.NEW_QUEST.TYPE
local PROP_ID = PDEFINE.PROP_ID
return {
    [1] = {
        id = 1,
        rid = 1,
        type = TYPE.Daily,
        count = 20,
        rewards = {{
            type = PROP_ID.COIN,
            count = 100000
        }}
    },
    [2] = {
        id = 2,
        rid = 2,
        type = TYPE.Daily,
        count = 40,
        rewards = {{
            type = PROP_ID.VIP_POINT,
            count = 5
        }}
    },
    [3] = {
        id = 3,
        rid = 3,
        type = TYPE.Daily,
        count = 60,
        rewards = {{
            type = PROP_ID.GOLD_EGG,
            count = 1
        }}
    },
    [4] = {
        id = 4,
        rid = 4,
        type = TYPE.Daily,
        count = 80,
        rewards = {{
            type = PROP_ID.PALACE_POINT,
            count = 100
        }}
    },
    [11] = {
        id = 11,
        rid = 1,
        type = TYPE.Weekly,
        count = 20,
        rewards = {{
            type = PROP_ID.COIN,
            count = 100000
        }}
    },
    [12] = {
        id = 12,
        rid = 2,
        type = TYPE.Weekly,
        count = 40,
        rewards = {{
            type = PROP_ID.COIN,
            count = 200000
        }}
    },
    [13] = {
        id = 13,
        rid = 3,
        type = TYPE.Weekly,
        count = 60,
        rewards = {{
            type = PROP_ID.COIN,
            count = 300000
        }}
    },
    [14] = {
        id = 14,
        rid = 4,
        type = TYPE.Weekly,
        count = 80,
        rewards = {{
            type = PROP_ID.PALACE_POINT,
            count = 500
        }}
    }
}

