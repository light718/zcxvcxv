return {{
    id = 1,
    rtype = 1,
    rank = 1,
    rewards = "1:2000000|8:3|2:40"
}, {
    id = 2,
    rtype = 1,
    rank = 2,
    rewards = "1:1500000|8:2|2:30"
}, {
    id = 3,
    rtype = 1,
    rank = 3,
    rewards = "1:1000000|8:2|2:20"
}, {
    id = 4,
    rtype = 1,
    rank = 4,
    rewards = "1:600000|8:1|2:10"
}, {
    id = 5,
    rtype = 1,
    rank = 5,
    rewards = "1:600000|8:1|2:10"
}, {
    id = 6,
    rtype = 1,
    rank = 6,
    rewards = "1:600000|8:1|2:10"
}, {
    id = 7,
    rtype = 1,
    rank = 7,
    rewards = "1:600000|8:1|2:10"
}, {
    id = 8,
    rtype = 1,
    rank = 8,
    rewards = "1:600000|8:1|2:10"
}, {
    id = 9,
    rtype = 1,
    rank = 9,
    rewards = "1:600000|8:1|2:10"
}, {
    id = 10,
    rtype = 1,
    rank = 10,
    rewards = "1:600000|8:1|2:10"
}, {
    id = 11,
    rtype = 1,
    rank = 11,
    rewards = "1:500000|2:10"
}, {
    id = 12,
    rtype = 1,
    rank = 12,
    rewards = "1:500000|2:10"
}, {
    id = 13,
    rtype = 1,
    rank = 13,
    rewards = "1:500000|2:10"
}, {
    id = 14,
    rtype = 1,
    rank = 14,
    rewards = "1:500000|2:10"
}, {
    id = 15,
    rtype = 1,
    rank = 15,
    rewards = "1:500000|2:10"
}, {
    id = 16,
    rtype = 1,
    rank = 16,
    rewards = "1:500000|2:10"
}, {
    id = 17,
    rtype = 1,
    rank = 17,
    rewards = "1:500000|2:10"
}, {
    id = 18,
    rtype = 1,
    rank = 18,
    rewards = "1:500000|2:10"
}, {
    id = 19,
    rtype = 1,
    rank = 19,
    rewards = "1:500000|2:10"
}, {
    id = 20,
    rtype = 1,
    rank = 20,
    rewards = "1:500000|2:10"
}, {
    id = 21,
    rtype = 2,
    rank = 1,
    rewards = "1:2000000|8:3|2:20"
}, {
    id = 22,
    rtype = 2,
    rank = 2,
    rewards = "1:1500000|8:2|2:15"
}, {
    id = 23,
    rtype = 2,
    rank = 3,
    rewards = "1:1000000|8:2|2:10"
}, {
    id = 24,
    rtype = 2,
    rank = 4,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 25,
    rtype = 2,
    rank = 5,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 26,
    rtype = 2,
    rank = 6,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 27,
    rtype = 2,
    rank = 7,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 28,
    rtype = 2,
    rank = 8,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 29,
    rtype = 2,
    rank = 9,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 30,
    rtype = 2,
    rank = 10,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 31,
    rtype = 2,
    rank = 11,
    rewards = "1:500000|2:5"
}, {
    id = 32,
    rtype = 2,
    rank = 12,
    rewards = "1:500000|2:5"
}, {
    id = 33,
    rtype = 2,
    rank = 13,
    rewards = "1:500000|2:5"
}, {
    id = 34,
    rtype = 2,
    rank = 14,
    rewards = "1:500000|2:5"
}, {
    id = 35,
    rtype = 2,
    rank = 15,
    rewards = "1:500000|2:5"
}, {
    id = 36,
    rtype = 2,
    rank = 16,
    rewards = "1:500000|2:5"
}, {
    id = 37,
    rtype = 2,
    rank = 17,
    rewards = "1:500000|2:5"
}, {
    id = 38,
    rtype = 2,
    rank = 18,
    rewards = "1:500000|2:5"
}, {
    id = 39,
    rtype = 2,
    rank = 19,
    rewards = "1:500000|2:5"
}, {
    id = 40,
    rtype = 2,
    rank = 20,
    rewards = "1:500000|2:5"
}, {
    id = 41,
    rtype = 4,
    rank = 1,
    rewards = "1:2000000|8:3|2:20"
}, {
    id = 42,
    rtype = 4,
    rank = 2,
    rewards = "1:1500000|8:2|2:15"
}, {
    id = 43,
    rtype = 4,
    rank = 3,
    rewards = "1:1000000|8:2|2:10"
}, {
    id = 44,
    rtype = 4,
    rank = 4,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 45,
    rtype = 4,
    rank = 5,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 46,
    rtype = 4,
    rank = 6,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 47,
    rtype = 4,
    rank = 7,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 48,
    rtype = 4,
    rank = 8,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 49,
    rtype = 4,
    rank = 9,
    rewards = "1:600000|8:1|2:5"
}, {
    id = 50,
    rtype = 4,
    rank = 10,
    rewards = "1:600000|2:5"
}, {
    id = 51,
    rtype = 4,
    rank = 11,
    rewards = "1:500000|2:5"
}, {
    id = 52,
    rtype = 4,
    rank = 12,
    rewards = "1:500000|2:5"
}, {
    id = 53,
    rtype = 4,
    rank = 13,
    rewards = "1:500000|2:5"
}, {
    id = 54,
    rtype = 4,
    rank = 14,
    rewards = "1:500000|2:5"
}, {
    id = 55,
    rtype = 4,
    rank = 15,
    rewards = "1:500000|2:5"
}, {
    id = 56,
    rtype = 4,
    rank = 16,
    rewards = "1:500000|2:5"
}, {
    id = 57,
    rtype = 4,
    rank = 17,
    rewards = "1:500000|2:5"
}, {
    id = 58,
    rtype = 4,
    rank = 18,
    rewards = "1:500000|2:5"
}, {
    id = 59,
    rtype = 4,
    rank = 19,
    rewards = "1:500000|2:5"
}, {
    id = 60,
    rtype = 4,
    rank = 20,
    rewards = "1:500000|2:5"
}, {
    id = 61,
    rtype = 5,
    rank = 1,
    rewards = "1:2000000"
}, {
    id = 62,
    rtype = 5,
    rank = 2,
    rewards = "1:1500000"
}, {
    id = 63,
    rtype = 5,
    rank = 3,
    rewards = "1:1000000"
}, {
    id = 64,
    rtype = 5,
    rank = 4,
    rewards = "1:800000"
}, {
    id = 65,
    rtype = 5,
    rank = 5,
    rewards = "1:800000"
}, {
    id = 66,
    rtype = 5,
    rank = 6,
    rewards = "1:800000"
}, {
    id = 67,
    rtype = 5,
    rank = 7,
    rewards = "1:800000"
}, {
    id = 68,
    rtype = 5,
    rank = 8,
    rewards = "1:800000"
}, {
    id = 69,
    rtype = 5,
    rank = 9,
    rewards = "1:800000"
}, {
    id = 70,
    rtype = 5,
    rank = 10,
    rewards = "1:800000"
}, {
    id = 71,
    rtype = 5,
    rank = 11,
    rewards = "1:500000"
}, {
    id = 72,
    rtype = 5,
    rank = 12,
    rewards = "1:500000"
}, {
    id = 73,
    rtype = 5,
    rank = 13,
    rewards = "1:500000"
}, {
    id = 74,
    rtype = 5,
    rank = 14,
    rewards = "1:500000"
}, {
    id = 75,
    rtype = 5,
    rank = 15,
    rewards = "1:500000"
}, {
    id = 76,
    rtype = 5,
    rank = 16,
    rewards = "1:500000"
}, {
    id = 77,
    rtype = 5,
    rank = 17,
    rewards = "1:500000"
}, {
    id = 78,
    rtype = 5,
    rank = 18,
    rewards = "1:500000"
}, {
    id = 79,
    rtype = 5,
    rank = 19,
    rewards = "1:500000"
}, {
    id = 80,
    rtype = 5,
    rank = 20,
    rewards = "1:500000"
}, {
    id = 81,
    rtype = 6,
    rank = 1,
    rewards = "1:500000|8:3"
}, {
    id = 82,
    rtype = 6,
    rank = 2,
    rewards = "1:400000|8:2"
}, {
    id = 83,
    rtype = 6,
    rank = 3,
    rewards = "1:300000|8:2"
}, {
    id = 84,
    rtype = 6,
    rank = 4,
    rewards = "1:200000|8:2"
}, {
    id = 85,
    rtype = 6,
    rank = 5,
    rewards = "1:150000|8:2"
}, {
    id = 86,
    rtype = 6,
    rank = 6,
    rewards = "1:120000|8:1"
}, {
    id = 87,
    rtype = 6,
    rank = 7,
    rewards = "1:120000|8:1"
}, {
    id = 88,
    rtype = 6,
    rank = 8,
    rewards = "1:120000|8:1"
}, {
    id = 89,
    rtype = 6,
    rank = 9,
    rewards = "1:120000|8:1"
}, {
    id = 90,
    rtype = 6,
    rank = 10,
    rewards = "1:120000|8:1"
}, {
    id = 91,
    rtype = 6,
    rank = 11,
    rewards = "1:100000|8:1"
}, {
    id = 92,
    rtype = 6,
    rank = 12,
    rewards = "1:100000|8:1"
}, {
    id = 93,
    rtype = 6,
    rank = 13,
    rewards = "1:100000|8:1"
}, {
    id = 94,
    rtype = 6,
    rank = 14,
    rewards = "1:100000|8:1"
}, {
    id = 95,
    rtype = 6,
    rank = 15,
    rewards = "1:100000|8:1"
}, {
    id = 96,
    rtype = 6,
    rank = 16,
    rewards = "1:100000|8:1"
}, {
    id = 97,
    rtype = 6,
    rank = 17,
    rewards = "1:100000|8:1"
}, {
    id = 98,
    rtype = 6,
    rank = 18,
    rewards = "1:100000|8:1"
}, {
    id = 99,
    rtype = 6,
    rank = 19,
    rewards = "1:100000|8:1"
}, {
    id = 100,
    rtype = 6,
    rank = 20,
    rewards = "1:100000|8:1"
}, {
    id = 101,
    rtype = 7,
    rank = 1,
    rewards = "1:1000000"
}, {
    id = 102,
    rtype = 7,
    rank = 2,
    rewards = "1:600000"
}, {
    id = 103,
    rtype = 7,
    rank = 3,
    rewards = "1:400000"
}, {
    id = 104,
    rtype = 7,
    rank = 4,
    rewards = "1:200000"
}, {
    id = 105,
    rtype = 7,
    rank = 5,
    rewards = "1:150000"
}, {
    id = 106,
    rtype = 7,
    rank = 6,
    rewards = "1:120000"
}, {
    id = 107,
    rtype = 7,
    rank = 7,
    rewards = "1:120000"
}, {
    id = 108,
    rtype = 7,
    rank = 8,
    rewards = "1:120000"
}, {
    id = 109,
    rtype = 7,
    rank = 9,
    rewards = "1:120000"
}, {
    id = 110,
    rtype = 7,
    rank = 10,
    rewards = "1:120000"
}, {
    id = 111,
    rtype = 7,
    rank = 11,
    rewards = "1:100000"
}, {
    id = 112,
    rtype = 7,
    rank = 12,
    rewards = "1:100000"
}, {
    id = 113,
    rtype = 7,
    rank = 13,
    rewards = "1:100000"
}, {
    id = 114,
    rtype = 7,
    rank = 14,
    rewards = "1:100000"
}, {
    id = 115,
    rtype = 7,
    rank = 15,
    rewards = "1:100000"
}, {
    id = 116,
    rtype = 7,
    rank = 16,
    rewards = "1:100000"
}, {
    id = 117,
    rtype = 7,
    rank = 17,
    rewards = "1:100000"
}, {
    id = 118,
    rtype = 7,
    rank = 18,
    rewards = "1:100000"
}, {
    id = 119,
    rtype = 7,
    rank = 19,
    rewards = "1:100000"
}, {
    id = 120,
    rtype = 7,
    rank = 20,
    rewards = "1:100000"
}}
