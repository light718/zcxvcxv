local entity = require "Entity"

local fund_dc = {}
local Entfund

function fund_dc.init()
    Entfund = entity.Get("d_fund")
    Entfund:Init()
end

function fund_dc.load(uid)
    if not uid then return end
    Entfund:Load(uid)
end

function fund_dc.unload(uid)
    if not uid then return end
    Entfund:UnLoad(uid)
end

function fund_dc.getvalue(uid, id, key)
    return Entfund:GetValue(uid, id, key)
end

function fund_dc.setvalue(uid, id, key, value)
    return Entfund:SetValue(uid, id, key, value)
end

function fund_dc.add(row)
    return Entfund:Add(row)
end

function fund_dc.delete(row)
    return Entfund:Delete(row)
end

function fund_dc.get_list(uid)
    return Entfund:Get(uid)
end

function fund_dc.get_info(uid, fundid)
    return Entfund:Get(uid, fundid)
end

return fund_dc