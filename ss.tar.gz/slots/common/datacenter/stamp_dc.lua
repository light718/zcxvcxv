local entity = require "Entity"
local cjson   = require "cjson"

local stamp_dc = {}
local EntStamp

function stamp_dc.init()
	EntStamp = entity.Get("d_stamp")
	EntStamp:Init()
end

function stamp_dc.load(uid)
	if not uid then return end
	EntStamp:Load(uid)
end

function stamp_dc.unload(uid)
	if not uid then return end
	EntStamp:UnLoad(uid)
end

function stamp_dc.getvalue(uid, key)
	return EntStamp:GetValue(uid, key)
end

function stamp_dc.setvalue(uid, key, value)
	return EntStamp:SetValue(uid, key, value)
end

function stamp_dc.add(row)
	return EntStamp:Add(row)
end

function stamp_dc.delete(row)
	return EntStamp:Delete(row)
end

function stamp_dc.user_addvalue(uid, key, n)
	local value = EntStamp:GetValue(uid, key)
	value = value + n
	local ret = EntStamp:SetValue(uid, key, value)
	return ret, value
end

function stamp_dc.get(uid)
	return EntStamp:Get(uid)
end

function stamp_dc.set_data_change(uid)
	return EntStamp:set_data_change(uid)
end

local function newStamp(uid)
    return {
        uid = uid,
        data = cjson.encode({})
    }
end

function stamp_dc.getdata(uid)
    local ent = EntStamp:Get(uid)
    -- LOG_DEBUG("for debug", ent)
    if not ent then
        ent = newStamp(uid)
        EntStamp:Add(ent)
    end
    LOG_DEBUG("for debug getdata", ent)
    return cjson.decode(ent.data)
end

function stamp_dc.setdata(uid, data)
    LOG_DEBUG("for debug setdata", uid, data)
	return EntStamp:SetValue(uid, "data", cjson.encode(data))
end

return stamp_dc
