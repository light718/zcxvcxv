local entity = require "Entity"

local mission_dc = {}
local EntMission

function mission_dc.init()
    EntMission = entity.Get("d_mission")
    EntMission:Init()
end

function mission_dc.load(uid)
    if not uid then return end
    EntMission:Load(uid)
end

function mission_dc.unload(uid)
    if not uid then return end
    EntMission:UnLoad(uid)
end

function mission_dc.getvalue(uid, key)
    return EntMission:GetValue(uid, key)
end

function mission_dc.setvalue(uid, key, value)
    return EntMission:SetValue(uid, key, value)
end

function mission_dc.add(row)
    return EntMission:Add(row)
end

function mission_dc.delete(row)
    return EntMission:Delete(row)
end

function mission_dc.get(uid)
    return EntMission:Get(uid)
end

return mission_dc