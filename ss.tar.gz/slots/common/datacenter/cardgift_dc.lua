local entity = require "Entity"
local cjson   = require "cjson"

local cardgift_dc = {}
local EntCardGift

function cardgift_dc.init()
	EntCardGift = entity.Get("d_card_gift")
	EntCardGift:Init()
end

function cardgift_dc.load(uid)
	if not uid then return end
	EntCardGift:Load(uid)
end

function cardgift_dc.unload(uid)
	if not uid then return end
	EntCardGift:UnLoad(uid)
end

function cardgift_dc.getvalue(uid, key)
	return EntCardGift:GetValue(uid, key)
end

function cardgift_dc.setvalue(uid, key, value)
	return EntCardGift:SetValue(uid, key, value)
end

function cardgift_dc.add(row)
	return EntCardGift:Add(row)
end

function cardgift_dc.delete(row)
	return EntCardGift:Delete(row)
end

function cardgift_dc.user_addvalue(uid, key, n)
	local value = EntCardGift:GetValue(uid, key)
	value = value + n
	local ret = EntCardGift:SetValue(uid, key, value)
	return ret, value
end

function cardgift_dc.get(uid)
	return EntCardGift:Get(uid)
end

function cardgift_dc.set_data_change(uid)
	return EntCardGift:set_data_change(uid)
end

local function newData(uid)
    local end_time = calRoundEndTime()
    return {
        uid = uid,
        lv = 1,
        jackpot = cjson.encode({}),
        end_time = end_time,
        status = 1, --1正常 0Game over
        uuid = GUID(),
        roundid = 1, --同一批次里，一个关卡可能多次复活后抽奖
    }
end

function cardgift_dc.getdata(uid)
    local ent = EntCardGift:Get(uid)
    if not ent then
        ent = newData(uid)
        EntCardGift:Add(ent)
        LOG_DEBUG("for debug getdata222 (nil)", ent)
        ent.isnew = true
    else
        if ent.isnew then
            ent.isnew = false
        end
    end
    if type(ent.jackpot) =='string' then
        ent.jackpot = cjson.decode(ent.jackpot)
    end
    return ent
end

function cardgift_dc.setdata(uid, data)
    local result
    for k, v in pairs(data) do
        if k == 'jackpot' then
            result = EntCardGift:SetValue(uid, k, cjson.encode(v))
        else
            result = EntCardGift:SetValue(uid, k, v)
        end
    end
	return result
end

return cardgift_dc
