local entity = require "Entity"

local activity_dc = {}
local EntActivity

local ActivityConfig = {
    uid = nil,  -- 用户id
    type = nil,  -- 任务类型
    expire_time = nil,  -- 过期时间
    activity = nil,  -- 活跃度值
    obtain_rewards = nil,  -- 已经领取的奖励
}

function activity_dc.init()
    EntActivity = entity.Get("d_new_activity")
    EntActivity:Init()
end

function activity_dc.load(uid)
    if not uid then return end
    EntActivity:Load(uid)
end

function activity_dc.unload(uid)
    if not uid then return end
    EntActivity:UnLoad(uid)
end

function activity_dc.getvalue(uid, id, key)
    return EntActivity:GetValue(uid, id, key)
end

function activity_dc.setvalue(uid, id, key, value)
    return EntActivity:SetValue(uid, id, key, value)
end

function activity_dc.add(row)
    return EntActivity:Add(row)
end

function activity_dc.delete(row)
    return EntActivity:Delete(row)
end

function activity_dc.get_list(uid)
    return EntActivity:Get(uid)
end

function activity_dc.get_info(uid, questid)
    return EntActivity:Get(uid, questid)
end

return activity_dc