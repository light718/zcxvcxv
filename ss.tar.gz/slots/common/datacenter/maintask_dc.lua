local entity = require "Entity"

local maintask_dc = {}
local EntTask

local function genID(type, taskid)
    return type*100 + taskid
end

local function decodeRecord(record)
    if table.empty(record) then
        return {}
    end
    record.taskid = record.taskid % 100
    return record
end

local function encodeRecord(record)
    if table.empty(record) then
        return {}
    end
    record.taskid = genID(record.type, record.taskid)
    return record
end

function maintask_dc.init()
    EntTask = entity.Get("d_main_task")
    EntTask:Init()
end

function maintask_dc.load(uid)
    if not uid then return end
    EntTask:Load(uid)
end

function maintask_dc.unload(uid)
    if not uid then return end
    EntTask:UnLoad(uid)
end

function maintask_dc.getvalue(uid, type, taskid, key)
    local id = genID(type, taskid)
    return decodeRecord(EntTask:GetValue(uid, id, key))
end

function maintask_dc.setvalue(uid, type, taskid, key, value)
    local id = genID(type, taskid)
    return EntTask:SetValue(uid, id, key, value)
end

function maintask_dc.add(row)
    row = encodeRecord(row)
    return EntTask:Add(row)
end

function maintask_dc.delete(row)
    local row = encodeRecord(row)
    return EntTask:Delete(row)
end

function maintask_dc.get_list(uid)
    local records = EntTask:Get(uid)
    if not records then
        return nil
    end
    for _, record in pairs(records) do
        decodeRecord(record)
    end
    return records
end

function maintask_dc.get_info(uid, type, taskid)
    local id = genID(type, taskid)
    local record = EntTask:Get(uid, id)
    if not record then
        return nil
    end
    return decodeRecord(EntTask:Get(uid, id))
end


return maintask_dc