local entity = require "Entity"

local herocard_dc = {}
local EntHerocard

function herocard_dc.init()
    EntHerocard = entity.Get("d_herocard")
    EntHerocard:Init()
end

function herocard_dc.load(uid)
    if not uid then return end
    EntHerocard:Load(uid)
end

function herocard_dc.unload(uid)
    if not uid then return end
    EntHerocard:UnLoad(uid)
end

function herocard_dc.getvalue(uid, id, key)
    return EntHerocard:GetValue(uid, id, key)
end

function herocard_dc.setvalue(uid, id, key, value)
    return EntHerocard:SetValue(uid, id, key, value)
end

function herocard_dc.add(row)
    return EntHerocard:Add(row)
end

function herocard_dc.delete(row)
    return EntHerocard:Delete(row)
end

function herocard_dc.getlist(uid)
    return EntHerocard:Get(uid)
end

function herocard_dc.getinfo(uid, cardid)
    return EntHerocard:Get(uid, cardid)
end


return herocard_dc