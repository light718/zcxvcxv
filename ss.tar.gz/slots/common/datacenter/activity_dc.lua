local entity = require "Entity"

local activity_dc = {}
local EntActivity

function activity_dc.init()
    EntActivity = entity.Get("d_activity")
    EntActivity:Init()
end

function activity_dc.load(uid)
    if not uid then return end
    EntActivity:Load(uid)
end

function activity_dc.unload(uid)
    if not uid then return end
    EntActivity:UnLoad(uid)
end

function activity_dc.getvalue(uid, key)
    return EntActivity:GetValue(uid, key)
end

function activity_dc.setvalue(uid, key, value)
    return EntActivity:SetValue(uid, key, value)
end

function activity_dc.add(row)
    return EntActivity:Add(row)
end

function activity_dc.delete(row)
    return EntActivity:Delete(row)
end

function activity_dc.get(uid)
    return EntActivity:Get(uid)
end

return activity_dc