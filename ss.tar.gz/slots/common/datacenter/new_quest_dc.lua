local entity = require "Entity"

local quest_dc = {}
local EntQuest

local QuestConfig = {
    uid = nil,  -- 用户id
    questid = nil,  -- 任务id
    params = nil,  -- 任务参数
    level = nil,  -- 开始任务时的等级
    expire_time = nil,  -- 过期时间
}

function quest_dc.init()
    EntQuest = entity.Get("d_new_quest")
    EntQuest:Init()
end

function quest_dc.load(uid)
    if not uid then return end
    EntQuest:Load(uid)
end

function quest_dc.unload(uid)
    if not uid then return end
    EntQuest:UnLoad(uid)
end

function quest_dc.clear(uid)
    if not uid then return end
    EntQuest:Clear(uid)
end

function quest_dc.getvalue(uid, id, key)
    return EntQuest:GetValue(uid, id, key)
end

function quest_dc.setvalue(uid, id, key, value)
    return EntQuest:SetValue(uid, id, key, value)
end

function quest_dc.add(row)
    return EntQuest:Add(row)
end

function quest_dc.delete(row)
    return EntQuest:Delete(row)
end

function quest_dc.get_list(uid)
    return EntQuest:Get(uid)
end

function quest_dc.get_info(uid, questid)
    return EntQuest:Get(uid, questid)
end


return quest_dc