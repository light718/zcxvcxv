--配置文件
local codecache = require "skynet.codecache"
codecache.mode("OFF")  --关闭skynet代码缓存

local cfgs = {
    s_herocamp = "conf.s_herocamp",
    s_herocard_base_attr = "conf.s_herocard_base_attr",
    s_herocard_betidx_drop_coeff = "conf.s_herocard_betidx_drop_coeff",
    s_herocard_card_drop = "conf.s_herocard_card_drop",
    s_herocard_game_drop = "conf.s_herocard_game_drop",
    s_herocard_level_attr = "conf.s_herocard_level_attr",
    s_herocard_level = "conf.s_herocard_level",
    s_herocard_star_attr = "conf.s_herocard_star_attr",
    s_herocard_star = "conf.s_herocard_star",
    s_herocard = "conf.s_herocard",
    s_herocard_pvp_team = "conf.s_herocard_pvp_team",
    s_herocard_common_drop = "conf.s_herocard_common_drop",
    s_new_quest = "conf.s_new_quest",
}

local datas = {}

--部分配置文件转化为便于查询的map
local herocard_card_map = {}
local herocard_gamedrop_map = {}
local herocard_carddrop_map = {}
local herocard_betidx_drop_coeff_map = {}
local herocard_cardlevel_map = {}
local herocard_commondrop_map = {}
local herocard_alldrop_map = {}
local new_quest_map = {}

--加载英雄卡牌配置
local function loadCardCfg()
    local card_map = {}
    for _, row in pairs(datas.s_herocard) do
        card_map[row.cardid] = row
    end
    return card_map
end

--加载游戏掉落卡牌概率配置
local function loadGameDropCfg()
    local gamedrop_map = {}
    for _, row in pairs(datas.s_herocard_game_drop) do
        gamedrop_map[row.gameid] = row.drop_prob
    end
    return gamedrop_map
end

--加载卡牌掉落概率配置
local function loadCardDropCfg()
    local carddrop_map = {}
    for _, row in pairs(datas.s_herocard_card_drop) do
        if not carddrop_map[row.gameid] then
            carddrop_map[row.gameid] = {}
        end
        local item = {cardid = row.cardid, weight = row.drop_weight}
        table.insert(carddrop_map[row.gameid], item)
    end
    return carddrop_map
end

--加载下注挡位掉落系数配置
local function loadBetidxDropCoeffCfg()
    local betidx_drop_coeff_map = {}
    for _, row in pairs(datas.s_herocard_betidx_drop_coeff) do
        betidx_drop_coeff_map[row.betidx] = row.drop_coeff
    end
    return betidx_drop_coeff_map
end

--加载卡牌升级配置
local function loadCardLevelCfg()
    local cardlevel_map = {}
    for _, row in pairs(datas.s_herocard_level) do
        if not cardlevel_map[row.rarity] then
            cardlevel_map[row.rarity] = {}
        end
        table.insert(cardlevel_map[row.rarity], row)
    end
    return cardlevel_map
end

-- 加载常规卡牌掉落概率
local function loadCommonCardDropCfg()
    local common_carddrop_map = {}
    for _, row in pairs(datas.s_herocard_common_drop) do
        local item = {cardid = row.cardid, weight = row.weight, campid = row.campid, level = row.level}
        table.insert(common_carddrop_map, item)
    end
    return common_carddrop_map
end

-- 加载卡牌掉落概率
local function loadAllCardDropCfg()
    local all_carddrop_map = {}
    for _, row in pairs(datas.s_herocard_card_drop) do
        if row.drop_weight > 0 then
            local exist = false
            for _, item in ipairs(all_carddrop_map) do
                if item.cardid == row.cardid then
                    item.weight = item.weight + row.drop_weight
                    exist = true
                    break
                end
            end
            if not exist then
                local item = {cardid = row.cardid, weight = row.drop_weight}
                table.insert(all_carddrop_map, item)
            end
        end
    end
    return all_carddrop_map
end

-- 加载每日任务配置
local function loadAllNewQuestCfg()
    local all_new_quest_cfg = {}
    for id, row in pairs(datas.s_new_quest) do
        all_new_quest_cfg[id] = row
    end
    return all_new_quest_cfg
end

local function load()
    for key, file in pairs(cfgs) do
        datas[key] = require(file)
    end

    herocard_card_map = loadCardCfg()
    herocard_gamedrop_map = loadGameDropCfg()
    herocard_carddrop_map = loadCardDropCfg()
    herocard_betidx_drop_coeff_map = loadBetidxDropCoeffCfg()
    herocard_cardlevel_map = loadCardLevelCfg()
    herocard_commondrop_map = loadCommonCardDropCfg()
    herocard_alldrop_map = loadAllCardDropCfg()
    new_quest_map = loadAllNewQuestCfg()

    print("cfg loaded")
end

local function reload()
    print("cfg reload")
    --清理缓存
    for _, file in pairs(cfgs) do
        package.loaded[file] = nil
    end
    --加载
    load()

    return "cfg reloaded succ"
end

local function getCampCfg(campid)
    for _, v in pairs(datas.s_herocamp) do
        if v.campid == campid then
            return v
        end
    end
    return nil
end

local function getCardCfg(cardid)
    return herocard_card_map[cardid]
end

local function getCardMap()
    return herocard_card_map
end

local function getDropPolicy(gameid)
    if not herocard_gamedrop_map[gameid] then
        return nil
    end
    local policy = {}
    policy.gameid = gameid
    policy.drop_prob = herocard_gamedrop_map[gameid]
    policy.cards_weight = herocard_carddrop_map[gameid]
    policy.betidx_coeff = herocard_betidx_drop_coeff_map
    -- 增加指定卡牌的经验，所以需要传递卡牌信息
    policy.cardid = nil
    for _, cardcfg in pairs(datas.s_herocard) do
        if cardcfg.gameid == gameid then
            policy.cardid = cardcfg.cardid
            break
        end
    end
    return policy
end

local function getCardStarStarCfg(star)
    for _, v in pairs(datas.s_herocard_star) do
        if v.star == star then
            return v
        end
    end
    return nil
end

local function getCardLevelCfg(cardid, level)
    local cardCfg = getCardCfg(cardid)
    local rarityCfg = herocard_cardlevel_map[cardCfg.rarity]
    for _, levelCfg in ipairs(rarityCfg) do
        if levelCfg.level == level then
            return levelCfg
        end
    end
    return nil
end

local function getCardBaseAttr(cardid)
    for _, v in pairs(datas.s_herocard_base_attr) do
        if v.cardid == cardid then
            return v
        end
    end
    return nil
end

local function getCardLevelAttr(cardid)
    for _, v in pairs(datas.s_herocard_level_attr) do
        if v.cardid == cardid then
            return v
        end
    end
    return nil
end

local function getCardStarAttr(cardid, star)
    for _, v in package(datas.s_herocard_star_attr) do
        if v.cardid == cardid and v.star == star then
            return v
        end
    end
    return nil
end

local function getRandRobot(cnt)
    local robots = {}
    local confLen = #datas.s_herocard_pvp_team
    local idxs = genRandIdxs(confLen, cnt)
    for _, idx in ipairs(idxs) do
        table.insert(robots, datas.s_herocard_pvp_team[idx])
    end
    return robots
end

local function getAllCardGameId()
    local gamelist = {}
    for _, cfg in ipairs(datas.s_herocard) do
        table.insert(gamelist, cfg.gameid)
    end
    return gamelist
end

local function getCommonCardDropCfg(level)
    level = level or 1000
    local cfg = {}
    for _, v in ipairs(herocard_commondrop_map) do
        if level >= v.level then
            table.insert(cfg, {cardid=v.cardid, weight=v.weight})
        end
    end
    return cfg
end

local function getCommonCardDropCfgByCampid(campid)
    local cfg = {}
    for _, v in ipairs(herocard_commondrop_map) do
        if campid == v.campid then
            table.insert(cfg, {cardid=v.cardid, weight=v.weight})
        end
    end
    return cfg
end

local function getAllCardDropCfg()
    return herocard_alldrop_map
end

local function getAllQuestCfg()
    return new_quest_map
end

return {
    load = load,
    reload = reload,
    getCampCfg = getCampCfg,    --获取阵营配置
    getCardCfg = getCardCfg,    --获取卡牌配置
    getCardMap = getCardMap,    --获取卡牌字典
    getDropPolicy = getDropPolicy,  --获取掉落策略
    getCardStarStarCfg = getCardStarStarCfg,    --获取升星配置
    getCardLevelCfg = getCardLevelCfg,  --获取升级配置
    getCardBaseAttr = getCardBaseAttr,  --卡牌基础属性
    getCardLevelAttr = getCardLevelAttr,    --卡牌等级属性
    getCardStarAttr = getCardStarAttr,  --卡牌星级属性
    getRandRobot = getRandRobot,  -- 获取pvp机器人
    getAllCardGameId = getAllCardGameId,  -- 获取所有卡牌对应的gameid
    getCommonCardDropCfg = getCommonCardDropCfg, -- 获取常规卡牌掉落概率
    getCommonCardDropCfgByCampid = getCommonCardDropCfgByCampid, -- 获取种族卡牌掉落概率
    getAllCardDropCfg = getAllCardDropCfg,  --获取所有卡牌的掉落概率
    getAllQuestCfg = getAllQuestCfg,  -- 获取每日任务配置
}

