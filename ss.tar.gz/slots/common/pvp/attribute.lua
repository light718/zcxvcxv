--卡牌战斗属性

local s_herocard_base_attr = require "conf.s_herocard_base_attr"
local s_herocard_level_attr = require "conf.s_herocard_level_attr"
local s_herocard_star_attr = require "conf.s_herocard_star_attr"

local function getCardBaseAttr(cardid)
    for _, v in pairs(s_herocard_base_attr) do
        if v.cardid == cardid then
            return v
        end
    end
    return nil
end

local function getCardLevelAttr(cardid)
    for _, v in pairs(s_herocard_level_attr) do
        if v.cardid == cardid then
            return v
        end
    end
    return nil
end

local function getCardStarAttr(cardid, star)
    for _, v in pairs(s_herocard_star_attr) do
        if v.cardid == cardid and v.star == star then
            return v
        end
    end
    return nil
end

--回能
local function calcMp(baseAttr, starAttr)
    local mp = baseAttr.mp
    if starAttr then
        mp = mp + starAttr.mp
    end
    return mp
end

local function _calcLevelAddAttribute(lv, levelAttr, attr, base)
    local add = 0
    if lv > 1 then
        local l = lv - 1
        add = add + levelAttr[attr.."_b1"] * l + levelAttr[attr.."_r1"] * base * l
    end
    if lv > 5 then
        local l = math.floor((lv - 1) / 5)
        add = add + levelAttr[attr.."_b5"] * l +  levelAttr[attr.."_r5"] * base * l
    end
    return add
end

--最大血量
local function calcMaxHp(lv, baseAttr, levelAttr, starAttr)
    local hp = baseAttr.hp
    if levelAttr then
        hp = hp + _calcLevelAddAttribute(lv, levelAttr, "hp", baseAttr.hp)
    end
    if starAttr then
        hp = hp + starAttr.hp
    end
    return math.floor(hp)
end

--最小攻击
local function calcMinAtk(lv, baseAttr, levelAttr, starAttr)
    local atk = baseAttr.atk1
    if levelAttr then
        atk = atk + _calcLevelAddAttribute(lv, levelAttr, "atk", baseAttr.atk1)
    end
    if starAttr then
        atk = atk + starAttr.atk1
    end
    return math.floor(atk)
end

--最大攻击
local function calcMaxAtk(lv, baseAttr, levelAttr, starAttr)
    local atk = baseAttr.atk2
    if levelAttr then
        atk = atk + _calcLevelAddAttribute(lv, levelAttr, "atk", baseAttr.atk2)
    end
    if starAttr then
        atk = atk + starAttr.atk2
    end
    return math.floor(atk)
end

--防御
local function calcDef(lv, baseAttr, levelAttr, starAttr)
    local def = baseAttr.def
    if levelAttr then
        def = def + _calcLevelAddAttribute(lv, levelAttr, "def", baseAttr.def)
    end
    if starAttr then
        def = def + starAttr.def
    end
    return math.floor(def)
end

--命中
local function calcHit(lv, baseAttr, levelAttr, starAttr)
    local hit = baseAttr.hit
    if levelAttr then
        hit = hit + _calcLevelAddAttribute(lv, levelAttr, "hit", baseAttr.hit)
    end
    if starAttr then
        hit = hit + starAttr.hit
    end
    return hit
end

--闪避
local function calcDod(lv, baseAttr, levelAttr, starAttr)
    local dod = baseAttr.dod
    if levelAttr then
        dod = dod + _calcLevelAddAttribute(lv, levelAttr, "dod", baseAttr.dod)
    end
    if starAttr then
        dod = dod + starAttr.dod
    end
    return dod
end

--计算战力
local function calcCombatCapacity(cardid, lv, star)
    local baseAttr = getCardBaseAttr(cardid)
    local levelAttr = getCardLevelAttr(cardid)
    local starAttr = getCardStarAttr(cardid, star)
    local hp = calcMaxHp(lv, baseAttr, levelAttr, starAttr)
    local minAtk = calcMinAtk(lv, baseAttr, levelAttr, starAttr)
    local maxAtk = calcMaxAtk(lv, baseAttr, levelAttr, starAttr)
    local def = calcDef(lv, baseAttr, levelAttr, starAttr)
    local hit = calcHit(lv, baseAttr, levelAttr, starAttr)
    local dod = calcDod(lv, baseAttr, levelAttr, starAttr)

    local cc = hp + (minAtk+maxAtk)/2 * 3 + def * 3 + hit * 10 + dod * 10
    return math.floor(cc)
end

--计算卡牌阵型战力
local function calcCC(cardInfos)
    local cc = 0
    for _, cardInfo in ipairs(cardInfos) do
        cc = cc + calcCombatCapacity(cardInfo.cardid, cardInfo.lv, cardInfo.star)
    end
    return cc
end

return {
    getCardBaseAttr = getCardBaseAttr,  --卡牌基础属性
    getCardLevelAttr = getCardLevelAttr,    --卡牌等级属性
    getCardStarAttr = getCardStarAttr,  --卡牌星级属性
    calcMp = calcMp,    --计算回能
    calcMaxHp = calcMaxHp,  --计算最大血量
    calcMinAtk = calcMinAtk,    --计算最小攻击
    calcMaxAtk = calcMaxAtk,    --计算最大攻击
    calcDef = calcDef,  --计算防御
    calcHit = calcHit,  --计算命中
    calcDod = calcDod,  --计算闪避
    calcCC = calcCC, --计算战力
}