--卡牌战斗逻辑

local Recorder = require "pvp.recorder"
local Role = require "pvp.role"
math.randomseed(tostring(os.time()):reverse():sub(1, 7))

--回合类型
local TURN_TYPE = {

}

--[[站位顺序
1   2
3   4
5   6
7   8
9   10
]]--
local MAX_POS = 10  --最多10个

local MAX_ROUND = 100   --最大轮数

local VERSION_NUMBER = 1  --战斗版本号

local Battle = class()

function Battle:ctor()
end

function Battle:getVersion()
    return VERSION_NUMBER
end

function Battle:init(attackerCardInfos, defenserCardInfos)
    self._round = 0 --轮次
    self._idx = 0    --当前进攻角色序列号
    self._roles = {}    --玩家列表，位置为索引
    self._recorder = Recorder.new(self:getVersion())

    --初始化玩家数据
    local pos = 1
    for _, info in ipairs(attackerCardInfos) do
        local role = Role.new()
        role:init(info.cardid, info.lv, info.star, info.camp, pos)
        self._roles[role:getPos()] = role
        pos = pos + 2
    end
    pos = 2
    for _, info in ipairs(defenserCardInfos) do
        local role = Role.new()
        role:init(info.cardid, info.lv, info.star, info.camp, pos)
        self._roles[role:getPos()] = role
        pos = pos + 2
    end

    self._recorder:formation(self._roles)
end


--检查对战结果
-- 0: 进行中
-- 1：胜利(进攻方)
-- 2: 失败
function Battle:checkResult()
    local cnt_atk = 0
    local cnt_def = 0
    for i = 1, MAX_POS do
        local role = self._roles[i]
        if role and role:isAlive() then
            if role:getSide() == 1 then
                cnt_atk = cnt_atk + 1
            else
                cnt_def = cnt_def + 1
            end
        end
    end
    if cnt_atk == 0 then
        return 2
    end
    if cnt_def == 0 then
        return 1
    end
    if self._round > MAX_ROUND then
        if cnt_atk > cnt_def then
            return 1
        else
            return 2
        end
    end

    return 0
end

function Battle:start()
    while true do
        local result = self:checkResult()
        if result > 0 then
            self:finish(result)
            break
        end
        self:next()
    end
end

function Battle:getAttackRole()
    for i = 0, 9 do
        local idx = self._idx + i
        if idx > 10 then idx = idx - 10 end
        local role = self._roles[idx]
        if role and role:isAlive() then
            return role
        end
    end
    return nil
end

function Battle:removeDeadRole(list)
    for i = #list, 1, -1 do
        local role = list[i]
        if not role:isAlive() then
            table.remove(list, i)
        end
    end
end

function Battle:next()
    --获取当前进攻角色
    local role = self:getAttackRole()
    local enemies = {}
    for i = 1, MAX_POS do
        local r = self._roles[i]
        if r and r:isAlive() then
            if r:getSide() ~= role:getSide() then  --目标列表
                table.insert(enemies, r)
            end
        end
    end
    self._recorder:new_round()
    role:attack(enemies, self._recorder)

    for i = 1, MAX_POS do
        local r = self._roles[i]
        if r and r:isAlive() then
            r:addMp(2)
        end
    end
    self._recorder:round_refreshmp(self._roles)
    --下一位攻击者
    self._idx = role:getPos() + 1
    if self._idx > 10 then
        self._idx = 1
    end
    --轮次加1
    self._round = self._round + 1
end

function Battle:finish(res)
    self._recorder:result(res)
end

function Battle:getRecord()
    return self._recorder:getData()
end


return Battle

