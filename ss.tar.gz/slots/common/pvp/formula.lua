
--阵营
local CAMP_TYPE = {
    GOLD = 1001,    --金
    WOOD = 1002,    --木
    WATER = 1003,   --水
    FIRE = 1004,    --火
    EARTH = 1005,   --土
}

local CAMP_RESTRAIN_RATIO = 1.2 --阵营克制系数


--实际命中率计算
local function calcHitrate(attacker, defenser)
    local hit = attacker:getHit()
    local dod = defenser:getDod()
    local hitrate = hit / (hit + dod) + 0.1
    return hitrate
end

--阵营克制系数
local function calcRestrainRatio(atkCamp, defCamp)
    if atkCamp == CAMP_TYPE.GOLD and defCamp == CAMP_TYPE.WOOD
      or atkCamp == CAMP_TYPE.WOOD and defCamp == CAMP_TYPE.EARTH
      or atkCamp == CAMP_TYPE.WATER and defCamp == CAMP_TYPE.FIRE
      or atkCamp == CAMP_TYPE.FIRE and defCamp == CAMP_TYPE.GOLD
      or atkCamp == CAMP_TYPE.EARTH and defCamp == CAMP_TYPE.WATER then
        return CAMP_RESTRAIN_RATIO
    end
    return 1
end

--伤害计算
local function calcDamge(attacker, defenser)
    local atk = attacker:getAtk()
    local def = defenser:getDef()
    local dmg = atk * atk / (2 * def + atk)
    local r = calcRestrainRatio(attacker:getCamp(), defenser:getCamp())
    dmg = math.floor(dmg * r)
    return math.max(1, dmg)
end

--积分计算
--[[
    Ra: 玩家a当前积分（进攻方）
    Rb: 玩家b当前积分
    res: 胜负结果  a胜利为1， 否则为0
    返回值
    Sa: 玩家a增加的积分
    Sb: 玩家b增加的积分
]]

local function calcEloScore(Ra, Rb, res)
    local Ea = 1 / (1 + 10 ^ ((Rb-Ra)/400))
    local Eb = 1 / (1 + 10 ^ ((Ra-Rb)/400))
    local Kwin = 36
    local Klose = 30
    local Sa = 0
    local Sb = 0
    if res == 1 then
        Sa = Kwin * (1 - Ea)
        Sb = Klose * (0 - Eb)
    else
        Sa = Klose * (0 - Ea)
        Sb = Kwin * (1 - Eb)
    end
    return math.floor(Sa), math.floor(Sb)
end

return {
    calcHitrate = calcHitrate,
    calcRestrainRatio = calcRestrainRatio,
    calcDamge = calcDamge,
    calcEloScore = calcEloScore,
}