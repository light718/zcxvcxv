local skynetroot = "./skynet/"

local lua_cpath = skynetroot .. "luaclib/?.so;" .. "./luaclib/?.so"
package.cpath = package.cpath .. lua_cpath

local lua_path = skynetroot .. "lualib/?.lua;" ..  skynetroot .. "lualib/compat10/?.lua;" .. 
           "./?.lua;"..
           "./lualib/?.lua;" ..
           "./global/?.lua;" ..
           "./common/?.lua;"
package.path = lua_path

require "pdefine"
require "luaext"

local Role = require "pvp.role"
local Battle = require "pvp.battle"
local formula = require "pvp.formula"
local s_herocard = require "conf.s_herocard"

local function print_role(r)
    print("hp:"..r:getCurHp().."/"..r:getMaxHp(), "mp:"..r:getCurMp().."/"..r:getMaxMp().."("..r:getMp()..")",
        "atk:"..r:getMinAtk().."-"..r:getMaxAtk(), "def:"..r:getDef(), "hit:"..r:getHit(), "dod:"..r:getDod(), "sp:"..r:getSARatio())
end

local function print_record(rec)
    local fmt = ""
    for i = 1, 10 do
        local role = nil
        for _, r in ipairs(rec.formation) do
            if r.pos == i then
               role = r
               break
            end
        end
        if not role then
           break
        end
        if i%2==0 then
            fmt = fmt.."\t\t\t\t"
        end
        fmt = fmt .. string.format("%d:%d(%d,%d) hp:%d/%d mp:%d/%d", i, role.cardid, role.lv, role.star, role.hp,role.maxhp, role.mp, role.maxmp)
        if i%2==0 then
            fmt = fmt.."\n"
        end
    end
    print(fmt)
    for i, rd in ipairs(rec.rounds) do
        local ak = rd.ak
        print("##"..i.."  atker:"..ak.pos.."  at:"..ak.at)
        for _, rs in ipairs(rd.rs) do
            fmt = "    --> "..rs.pos.."  dmg:"..rs.dmg.."  hp.."..rs.hp
            if rs.hp <= 0 then
                fmt = fmt .. " (killed)"
            end
            print(fmt)
        end
    end
    if rec.res == 1 then
        print("atk win")
    else
        print("atk fail")
    end
end


-- 测试积分计算
local function test_calc_elo_score()
    local testcases = {
        {Ra=1020, Rb=800, res=1},
        {Ra=1020, Rb=800, res=2},
        {Ra=1001, Rb=999, res=1},
        {Ra=1001, Rb=999, res=2},
        {Ra=1600, Rb=800, res=1},
        {Ra=1600, Rb=800, res=2},
    }

    for _, case in ipairs(testcases) do
        local sa, sb = formula.calcEloScore(case.Ra, case.Rb, case.res)
        print(string.format("Ra:%d\tRb:%d\tres:%d\tsa:%d\tsb:%s", case.Ra, case.Rb, case.res, sa, sb))    
    end
end


--测试属性计算
local function test_calc_attribute()
    local testcases = {
        {cardid=1001, lv=5, star=0},
        {cardid=1002, lv=11, star=0},
        {cardid=1003, lv=6, star=2},
    }

    local role = Role.new()
    for _, case in ipairs(testcases) do
        role:init(case.cardid, case.lv, case.star, case.camp, 1)
        print("cardid:"..case.cardid, "lv:"..case.lv, "star:"..case.star)
        print_role(role)
        print("\n")
    end
end


local function test_fight()
    local testcases1 = {
        {cardid=1001, lv=5, star=0, camp=1001},
        {cardid=1002, lv=11, star=0, camp=1001},
        {cardid=1003, lv=6, star=2, camp=1001},
    }
    local testcases2 = {
        {cardid=1004, lv=5, star=0, camp=1001},
        {cardid=1005, lv=11, star=0, camp=1001},
        {cardid=1006, lv=6, star=2, camp=1001},
    }

    local battle = Battle.new()
    battle:init(testcases1, testcases2)
    battle:start()
    local record = battle:getRecord()
    print_record(record)
end

local function random_team(cnt, min_lv, max_lv, star)
    star = star or 0
    local team = {}
    for i = 1, cnt do
        local cardcfg = s_herocard[math.random(1, #s_herocard)]
        table.insert(team, {
            cardid = cardcfg.cardid,
            lv = math.random(min_lv, max_lv),
            star = star,
            camp = cardcfg.campid
        })
    end
    return team
end

local function test_team_battle(test_cnt, role_cnt, atk_min_lv, atk_max_lv, atk_star, def_min_lv, def_max_lv, def_star)
    local rounds = 0
    local skills = 0
    local battle = Battle.new()
    local cardid_map = {}
    local card_wins = {}
    local card_loses = {}
    local atk_wins = 0
    for i = 1, test_cnt do
        local t1 = random_team(role_cnt, atk_min_lv, atk_max_lv, atk_star)
        local t2 = random_team(role_cnt, def_min_lv, def_max_lv, def_star)
        battle:init(t1, t2)
        battle:start()
        local record = battle:getRecord()
        local winteam = t1
        local loseteam = t2
        if record.res == 2 then
            winteam = t2
            loseteam = t1
        end
        for _, v in ipairs(winteam) do
            card_wins[v.cardid] = (card_wins[v.cardid] or 0) + 1
            cardid_map[v.cardid] = 1
        end
        for _, v in ipairs(loseteam) do
            card_loses[v.cardid] = (card_loses[v.cardid] or 0) + 1
            cardid_map[v.cardid] = 1
        end
        rounds = rounds + #(record.rounds)
        for _, round in ipairs(record.rounds) do
            if round.ak.at ~= 'nor' then
                skills = skills + 1
            end
        end
        if record.res == 1 then
            atk_wins = atk_wins + 1
        end
    end

    print("average rounds", rounds/test_cnt)
    print("atk win rate", atk_wins/test_cnt)
    print("average skills", skills/test_cnt)
    local cardids = table.indices(cardid_map)
    table.sort(cardids)
    for _, cardid in pairs(cardids) do
        local win = card_wins[cardid] or 0
        local lose = card_loses[cardid] or 0
        print(string.format("%d:\t%d\t%d\t%f", cardid, win, lose, win/(win+lose)))
    end
end

--测试积分算法
--test_calc_elo_score()

--测试属性计算
--test_calc_attribute()

--模拟对战
--test_fight()

--测试 1v1 数值
--test_team_battle(100000, 1, 10, 12, 0, 10, 12, 0)
--测试 3v3 数值
test_team_battle(100000, 3, 10, 12, 0, 10, 12, 0)
--测试 5v5 数值
--test_team_battle(100000, 5, 10, 12, 0, 10, 12, 0)

--测试不同等级对战数值
--test_team_battle(100000, 3, 10, 12, 0, 20, 24, 0)

--测试不同星级对战数值
--test_team_battle(100000, 3, 10, 12, 1, 10, 12, 2)
