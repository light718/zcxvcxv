--卡牌战斗角色

local attribute = require "pvp.attribute"
local formula = require "pvp.formula"

local MAX_MP = 100   --最大能量

--普通攻击
local NORMAL_ATTACK_TYPE = "nor"

--必杀技类型
local SPECIAL_ATTACK_TYPE = {
    SINGLE_RAND = "srd",    --随机攻击一名敌人
    SINGLE_ATK = "satk",    --攻击对方阵营攻击力最高的一名敌人
    SINGLE_HP = "shp",      --攻击对方阵营血量最低的一名敌人
    MULTIPLE_X2 = "m2",     --连续发动2次攻击，随机攻击对方两名敌人
    MULTIPLE_X3 = "m3",     --连续发动3次攻击，随机攻击对方三名敌人
    MULTIPLE_X5 = "m5",     --攻击对方全体敌人
}


local Role = class()

function Role:ctor()
    self._cardid = 0 --卡牌id
    self._lv = 0    --等级
    self._star = 0  --星级
    self._camp = 0  --阵营
    self._curHp = 0 --当前血量
    self._curMp = 0 --当前能量
    self._pos = 0   --当前站位
end

function Role:init(cardid, lv, star, camp, pos)
    self._cardid = cardid
    self._lv = lv
    self._star = star
    self._camp = camp
    self._pos = pos

    --战斗属性
    local baseAttr = attribute.getCardBaseAttr(cardid)
    local levelAttr = attribute.getCardLevelAttr(cardid)
    local starAttr = attribute.getCardStarAttr(cardid, star)
    self._st = baseAttr.st
    self._sp = baseAttr.sp
    self._mp = attribute.calcMp(baseAttr, starAttr)
    self._maxHp = attribute.calcMaxHp(lv, baseAttr, levelAttr, starAttr)
    self._minAtk = attribute.calcMinAtk(lv, baseAttr, levelAttr, starAttr)
    self._maxAtk = attribute.calcMaxAtk(lv, baseAttr, levelAttr, starAttr)
    self._def = attribute.calcDef(lv, baseAttr, levelAttr, starAttr)
    self._hit = attribute.calcHit(lv, baseAttr, levelAttr, starAttr)
    self._dod = attribute.calcDod(lv, baseAttr, levelAttr, starAttr)

    --初始满血
    self._curHp = self._maxHp
end

--卡牌信息
function Role:getCardId()
    return self._cardid
end
function Role:getLv()
    return self._lv
end
function Role:getStar()
    return self._star
end
function Role:getCamp()
    return self._camp
end

--获取位置
function Role:getPos()
    return self._pos
end

--获取相对位置
function Role:getOppositePos()
    if self._pos % 2 == 1 then
        return self._pos + 1
    else
        return self._pos - 1
    end
end

--获取立场
--1: 左边，进攻方
--2: 右边，防守方
function Role:getSide()
    if self._pos % 2 == 1 then
        return 1
    else
        return 2
    end
end

--血量
function Role:getCurHp()
    return self._curHp
end
function Role:getMaxHp()
    return self._maxHp
end
function Role:addHp(hp)
    self._curHp = math.max(self._curHp + hp, 0)
    self._curHp = math.min(self._curHp, self._maxHp)
    return self._curHp
end

--能量
function Role:getCurMp()
    return self._curMp
end
function Role:addMp(mp)
    self._curMp = math.min(self._curMp+mp, MAX_MP)
end
function Role:getMp()
    return self._mp
end
function Role:getMaxMp()
    return MAX_MP
end
function Role:resetMp()
    self._curMp = 0
end

--必杀技类型
function Role:getSAType()
    return self._st
end

--必杀技伤害系数
function Role:getSARatio()
    return self._sp
end

--攻击
function Role:getAtk()
    return math.random(self._minAtk,self._maxAtk)
end
function Role:getMinAtk()
    return self._minAtk
end
function Role:getMaxAtk()
    return self._maxAtk
end
function Role:getAvgAtk()
    return (self._minAtk + self._maxAtk) / 2
end

--防御
function Role:getDef()
    return self._def
end

--命中
function Role:getHit()
    return self._hit
end

--闪避
function Role:getDod()
    return self._dod
end

--是否存活
function Role:isAlive()
    return self._curHp > 0
end

--攻击
function Role:attack(enemies, recorder)
    if self:getCurMp() >= self:getMaxMp() then
        return self:specialAttack(enemies, recorder)
    else
        return self:normalAttack(enemies, recorder)
    end
end

--普通攻击
function Role:normalAttack(enemies, recorder)
    local target = nil
    if math.random() < 0.5 then
        target = enemies[math.random(#enemies)]
    else
        for _, enemy in ipairs(enemies) do
            if enemy:getPos() == self:getOppositePos() then
                target = enemy
            end
        end
        if not target then
            target = enemies[1]
        end
    end

    --加能量
    self:addMp(self:getMp())

    recorder:round_attacker(self, NORMAL_ATTACK_TYPE, self:getMp())

    local hitrate = formula.calcHitrate(self, target)
    if math.random() < hitrate then
        local dmg = formula.calcDamge(self, target)
        --扣血
        target:addHp(-dmg)
        --回能
        local addmp = 0
        if target:isAlive() then
            addmp = target:getMp()*2
            target:addMp(addmp)
        end
        recorder:round_denfeser(target, dmg, addmp)
    else
        -- miss
        --回能
        local addmp = target:getMp()*2
        target:addMp(addmp)
        recorder:round_denfeser(target, 0, addmp)
    end
end

--从enemies中获取num个不重复的值
function Role:getRandomEnemies(enemies, num)
    local idxs = {}
    for i = 1, #enemies do
        local pos = math.random(i)
        table.insert(idxs, pos, i)
    end
    local targets = {}
    num = math.min(#enemies, num)
    for i = 1, num do
        table.insert(targets, enemies[idxs[i]])
    end
    return targets
end

--确定技能攻击目标
function Role:determineSkillTargets(enemies, recorder)
    local targets = {}
    local sat = self:getSAType()
    if sat == SPECIAL_ATTACK_TYPE.SINGLE_RAND then
        --随机攻击一名敌人
        table.insert(targets, enemies[math.random(#enemies)])
    elseif sat == SPECIAL_ATTACK_TYPE.SINGLE_ATK then
        --攻击对方阵营攻击力最高的一名敌人
        local target = enemies[1]
        local maxatk = target:getAvgAtk()
        for i = 2, #enemies do
            if maxatk < enemies[i]:getAvgAtk() then
                maxatk = enemies[i]:getAvgAtk()
                target = enemies[i]
            end
        end
        table.insert(targets, target)
    elseif sat == SPECIAL_ATTACK_TYPE.SINGLE_HP then
        --攻击对方阵营血量最低的一名敌人
        local target = enemies[1]
        local minhp = target:getCurHp()
        for i = 2, #enemies do
            if minhp > enemies[i]:getCurHp() then
                minhp = enemies[i]:getCurHp()
                target = enemies[i]
            end
        end
        table.insert(targets, target)
    elseif sat == SPECIAL_ATTACK_TYPE.MULTIPLE_X2 then
        --连续发动2次攻击，随机攻击对方两名敌人
        targets = self:getRandomEnemies(enemies, 2)
    elseif sat == SPECIAL_ATTACK_TYPE.MULTIPLE_X3 then
        --连续发动3次攻击，随机攻击对方三名敌人
        targets = self:getRandomEnemies(enemies, 3)
    elseif sat == SPECIAL_ATTACK_TYPE.MULTIPLE_X5 then
        --攻击对方全体敌人
        for _, enemy in ipairs(enemies) do
            table.insert(targets, enemy)
        end
    else
        assert(false, "unknow special atk type: "..sat)
    end
    return targets
end

--必杀技攻击
function Role:specialAttack(enemies, recorder)
    --能量清空
    self:resetMp()
    --加能量
    self:addMp(self:getMp())

    recorder:round_attacker(self, self:getSAType(), self:getMp())

    local targets = self:determineSkillTargets(enemies)
    for _, target in ipairs(targets) do
        target:addMp(target:getMp()*2)

        local dmg = formula.calcDamge(self, target)
        dmg = math.floor(dmg * (1 + self:getSARatio()) + self:getAtk() * 0.2)
        --扣血
        target:addHp(-dmg)
        --回能
        local addmp = 0
        if target:isAlive() then
            addmp = target:getMp()*2
            target:addMp(addmp)
        end

        recorder:round_denfeser(target, dmg, addmp)
    end
end

return Role

