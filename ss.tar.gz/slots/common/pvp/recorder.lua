--记录类型
local Recorder = class()

function Recorder:ctor(version)
    self._data = {}
    self._data.ver = version
    self._roundid = 0
    self._data.rounds = {}
end

function Recorder:reset()
    self._roundid = 0
    self._data.rounds = {}
end

--阵型
function Recorder:formation(roles)
    local formation = {}
    for _, role in pairs(roles) do
        table.insert(formation, {pos=role:getPos(), cardid=role:getCardId(), lv=role:getLv(),
          star=role:getStar(), hp=role:getCurHp(), maxhp=role:getMaxHp(),
          mp=role:getCurMp(), maxmp=role:getMaxMp()})
    end
    self._data.formation = formation
end

function Recorder:new_round()
    self._roundid = self._roundid + 1
    self._data.rounds[self._roundid] = {}
end

--攻击
function Recorder:round_attacker(role, atktype, addmp)
    local round = self._data.rounds[self._roundid]
    round.ak = {pos=role:getPos(), at=atktype, amp=addmp}
end

function Recorder:round_denfeser(target, dmg, addmp)
    local round = self._data.rounds[self._roundid]
    if not round.rs then
        round.rs = {}
    end
    table.insert(round.rs, {pos=target:getPos(), dmg=dmg, hp=target:getCurHp(), amp=addmp})
end

--刷新能量
function Recorder:round_refreshmp(roles)
    local round = self._data.rounds[self._roundid]
    round.mp = {}
    for i = 1, 10 do
        local role = roles[i]
        if role and role:isAlive() then
            table.insert(round.mp, role:getCurMp())
        else
            table.insert(round.mp, 0)
        end
    end
end

--战斗结果
function Recorder:result(res)
    self._data.res = res
end

--获取数据
function Recorder:getData()
    return self._data
end


return Recorder
