
package.path = "./?.lua;".."./lualib/?.lua;".."./global/?.lua;".."./common/?.lua;"
local s_herocard = require "conf.s_herocard"

math.randomseed(tostring(os.time()):reverse():sub(1, 7))

local teams = {}

local cardids = {}
for _, card in ipairs(s_herocard) do
    table.insert(cardids, card.cardid)
end
table.sort(cardids)

local function gen_team(team_cnt, role_cnt, min_lv, max_lv, min_star, max_star)
    local size = #cardids
    for i = 1, team_cnt do
        local team = {}
        for j = 1, role_cnt do
            local idx = 0
            local cardid = 0
            while true do
                local rand = math.random()
                if rand < 0.33 then
                    idx = math.random(1, size)
                elseif rand < 0.66 then
                    idx = math.random(1, math.floor(size*0.85))
                else
                    idx = math.random(1, math.floor(size*0.7))
                end
                cardid = cardids[idx]
                local exist = false
                for _, v in ipairs(team) do
                    if v.cardid == cardid then
                        exist = true
                        break
                    end
                end
                if not exist then
                    break
                end
            end
             
            table.insert(team, {
                cardid = cardid,
                lv = math.random(min_lv, max_lv),
                star = math.random(min_star, max_star)
            })
        end
        table.insert(teams, team)
    end
end

--team_cnt, role_cnt, min_lv, max_lv, min_star, max_star
gen_team(5, 1, 1, 2, 0, 0)
gen_team(8, 2, 1, 2, 0, 0)
gen_team(10, 2, 2, 4, 0, 0)
gen_team(10, 3, 2, 5, 0, 0)
gen_team(12, 3, 3, 8, 0, 0)
gen_team(12, 3, 2, 10, 0, 0)
gen_team(4, 3, 4, 10, 0, 1)
gen_team(6, 4, 1, 5, 0, 0)
gen_team(8, 4, 3, 12, 0, 0)
gen_team(10, 4, 5, 15, 0, 0)
gen_team(6, 4, 12, 30, 0, 0)
gen_team(6, 4, 15, 30, 0, 0)
gen_team(4, 4, 15, 30, 0, 2)
gen_team(3, 4, 20, 40, 1, 2)
gen_team(8, 5, 1, 10, 0, 0)
gen_team(6, 5, 5, 15, 0, 0)
gen_team(4, 5, 15, 25, 0, 1)
gen_team(3, 5, 20, 40, 0, 0)
gen_team(3, 5, 25, 50, 0, 1)
gen_team(2, 5, 30, 50, 0, 1)
gen_team(1, 5, 50, 70, 1, 2)
gen_team(1, 5, 60, 80, 2, 3)

print("team count:", #teams)

local filename = "common/conf/s_herocard_pvp_team.lua"
local file = io.open(filename, "w")
file:write("return {\n")
for _, team in ipairs(teams) do
    local content = " {\n"
    for __, role in ipairs(team) do
        content = content .. string.format("  {cardid=%d,lv=%d,star=%d},\n", role.cardid, role.lv, role.star)
    end
    content = content.." },\n"
    file:write(content)
end
file:write("}\n")
file:close()