--卡牌战斗服务

local skynet = require "skynet"
require "skynet.manager"
local attribute = require "pvp.attribute"
local Battle = require "pvp.battle"


--直接调用cfg的接口
local CMD = {}

--计算战力
function CMD.calcCC(cardInfos)
    return attribute.calcCC(cardInfos)
end

--战斗
function CMD.fight(attackerCardInfos, defenserCardInfos)
    local battle = Battle.new()
    battle:init(attackerCardInfos, defenserCardInfos)
    battle:start()
    return battle:getRecord()
end

skynet.start(function()
    skynet.dispatch("lua", function(session, address, cmd, ...)
        local f = assert(CMD[cmd], cmd .. "not found")
        skynet.retpack(f(...))
    end)
    skynet.register(".battlemgr")
end)