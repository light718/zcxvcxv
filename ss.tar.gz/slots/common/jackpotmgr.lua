--node服和game服各起一个jackpotmgr服务
--node服用于向前端提供奖池数值显示
--game服用于发奖

local skynet = require "skynet"
require "skynet.manager"
local cluster = require "cluster"
local cjson = require "cjson"
cjson.encode_sparse_array(true)
cjson.encode_empty_table_as_object(false)

math.randomseed(tostring(os.time()):reverse():sub(1, 7))

local gamejackpots = {}

local CMD = {}

local function setTimer(ti, func, params)
    local function repeat_func()
        func(params)
        setTimer(ti, func, params)
    end
    skynet.timeout(ti, repeat_func)
end

local function loadFromDb()
    local ok, level_bet_list = pcall(cluster.call, "master", ".vipCenter", "getLevelBetList")
    if not ok then
        LOG_ERROR("jackpotmgr getLevelBetList fail")
        return
    end

    local lst = {}
    local sql = "SELECT A.id, A.betrate, A.jackpot, A.jp_unlock_lv FROM s_game AS A, s_game_type AS B WHERE A.id = B.gameid and B.state > 0"
    local rs = skynet.call(".mysqlpool", "lua", "execute", sql)
    if #rs > 0 then
        for _, row in pairs(rs) do
            local info = {}
            info.id = row.id
            info.jp = cjson.decode(row.jackpot)
            info.unlockindex = cjson.decode(row.jp_unlock_lv)
            info.unlock = {}
            for i, v in ipairs(info.unlockindex) do
                if level_bet_list[v] then
                    info.unlock[i] = level_bet_list[v].betcoin
                else
                    LOG_WARNING("jackpotmgr unlock level_bet_list not exist", info.id, v)
                    info.unlock[i] = 10000
                end
            end
            --local betrate = tonumber(row.betrate)
            --for i = 1, #info.jp do
            --    info.jp[i] = info.jp[i]*betrate
            --end
            lst[info.id] = info
        end
    end

    gamejackpots = lst
end

local function randomlize(jpinfo)
    local info = {}
    info.id = jpinfo.id
    info.jp = {}
    info.unlock = {}
    info.unlockindex = {}
    for i = 1, #jpinfo.jp do
        info.jp[i] = math.floor(jpinfo.jp[i] * (0.9 + math.random()*0.2) + 0.5)
        info.unlock[i] = jpinfo.unlock[i]
        info.unlockindex[i] =  jpinfo.unlockindex[i]
    end
    return info
end

function CMD.start()
    loadFromDb()
    -- 每5钟从数据库加载
    setTimer(300*100, loadFromDb)
end

function CMD.getGameJackpot()
    local lst = {}
    for _, jpinfo in pairs(gamejackpots) do
        lst[jpinfo.id] = randomlize(jpinfo)
    end
    return lst
end

function CMD.getGameJackpotByGameId(gameid)
    local jpinfo = gamejackpots[gameid]
    if not jpinfo then
        jpinfo = {id=gameid, jp={10,50,100,500}, unlock={0,0,0,0}, unlockindex={1,1,1,1},}
    end
    return randomlize(jpinfo)
end

--@func 获取解锁的奖池列表
--@param gameid: 游戏ID
--@param totalbet: 玩家总下注

--@return 解锁的奖池序号列表
function CMD.getUnlockJackpot(gameid, totalbet)
    local unlockjps = {}
    local jpinfo = gamejackpots[gameid]
    if jpinfo then
        for jpidx, unlock_bet in ipairs(jpinfo.unlock) do
            if totalbet>=unlock_bet then
                table.insert(unlockjps, jpidx)
            end
        end
    end
    return unlockjps
end

--@func 获得奖池中奖金额
--@param gameid: 游戏ID
--@param jpidx：奖池序号
    -- 1:mini
    -- 2:minor
    -- 3:major:
    -- 4:grand(mega)
    -- 5:...游戏自定义奖池
--@param totalbet: 玩家总下注

--@return 玩家中奖值
function CMD.getJackpotValueByBet(gameid, jpidx, totalbet)
    local info = CMD.getGameJackpotByGameId(gameid)
    local jpvalue = info.jp[jpidx] or 10
    --随机化 1.0~1.1倍之间随机
    jpvalue = jpvalue * (1.0 + math.random()*0.1)
    local award = jpvalue*totalbet
    -- 取整
    award = math.floor(award/100)*100
    return award
end

skynet.start(function()
    skynet.dispatch("lua", function(session, address, cmd, ...)
        local f = CMD[cmd]
        skynet.retpack(f(...))
    end)
    skynet.register(".jackpotmgr")
end)
