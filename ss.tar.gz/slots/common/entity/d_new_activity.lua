require "UserIndexEntity"

local EntityType = class(UserIndexEntity)

function EntityType:ctor()
    self.tbname = "d_new_activity"
    self.baseid = "type"			-- 基础索引字段
end

return EntityType.new()
