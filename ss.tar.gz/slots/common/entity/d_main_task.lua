require "UserIndexEntity"

local EntityType = class(UserIndexEntity)

function EntityType:ctor()
    self.tbname = "d_main_task"
    self.baseid = "taskid"
end

return EntityType.new()