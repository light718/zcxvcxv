require "UserSingleEntity"

local EntityType = class(UserSingleEntity)

function EntityType:ctor()
    self.tbname = "d_mission"
end

return EntityType.new()
