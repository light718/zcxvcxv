require "UserIndexEntity"

local EntityType = class(UserIndexEntity)

function EntityType:ctor()
    self.tbname = "d_new_quest"
	self.baseid = "questid"			-- 基础索引字段
end

return EntityType.new()