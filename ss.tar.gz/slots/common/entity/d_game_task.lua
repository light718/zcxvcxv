require "UserSingleEntity"

local EntityType = class(UserSingleEntity)

function EntityType:ctor()
    self.tbname = "d_game_task"
end

return EntityType.new()
