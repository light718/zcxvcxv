require "UserSingleEntity"

local EntityType = class(UserSingleEntity)

function EntityType:ctor()
    self.tbname = "d_card_gift"
end

return EntityType.new()
