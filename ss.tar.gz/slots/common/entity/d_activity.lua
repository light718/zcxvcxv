require "UserSingleEntity"

local EntityType = class(UserSingleEntity)

function EntityType:ctor()
    self.tbname = "d_activity"
end

return EntityType.new()
