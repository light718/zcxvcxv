local skynet    = require "skynet"
local cluster   = require "cluster"
local cjson     = require "cjson"
local baccarattool = require "baccarattool"
local queue     = require "skynet.queue"
local snax = require "snax"
cjson.encode_sparse_array(true)
local cardslib = require "baccarat_cardslib"
local water_pool = require "base.water_pool"
local probability_ctl = require "base.multibet_probability"
local player_tool = require "base.player_tool"

--[[
777 百家乐
等待下一局 (5s) -> 下注(20s) -> 结算(8s)
--]]

local timeout         = {6, 20, 14}  --游戏阶段时间, 1 等待下一局；2 下注阶段(下注20s，等待结算); 3结算阶段（摊牌结算）
local CHIP = {0.5,1,5,10,50,100,500,1000} --押注筹码
local unbettime = 3 --下注的时候后面3秒是不让下注的
local STATUS = {
    ["READYGO"] = 0, --游戏未开始
    ["WAIT"]    = 1, --等待下一局
    ["STARTBET"]= 2, --开始下注
    ["OPEN"]    = 3, --开牌
}

local basebacca = {}

function basebacca.start ( gameconf )
    assert(gameconf.id)
    assert(gameconf.betlimit)
    assert(gameconf.allbetlimit)

    local cs = queue()
    local CMD = {}
    local betonline = require "base.betonline" 
    local baccaratgame = require "baccaratgame"()
    local game_hander = {}
    local game = {}
    local AiMgr = require "base.BetAiMgr"() --create多个服会被覆盖
    local LAST_RESULT = 0 --上一局的结果 1：闲赢 2：和 3：庄赢
    local HISTORY = {} --64路路单
    local WAY = {} --48路路单
    --阶段时间
    local timeoutIntervel  = 0 --区间倒计时时间长度 比如下注时间 20s
    local intervel_endtime = 0 --阶段倒计时开始时间
    local GAME_ID = gameconf.id
    local BET_LIMIT = gameconf.betlimit
    local ALLBET_LIMIT = gameconf.allbetlimit
    --[[
    
    local BET_LIMIT = {-- 闲赢 和 庄赢 闲对子 庄对子
                        [1] = 
                            {
                                ["min"] = 0.5,
                                ["max"] = 1000
                            },
                        [2] = 
                            {
                                ["min"] = 0.5,
                                ["max"] = 500
                            },
                        [3] = 
                            {
                                ["min"] = 0.5,
                                ["max"] = 500
                            },   
                        [4] = 
                            {
                                ["min"] = 0.5,
                                ["max"] = 500
                            },  
                        [5] = 
                            {
                                ["min"] = 0.5,
                                ["max"] = 500
                            },  
                    }
    ]]

    -------- 桌子定时器 --------
    function game.setAutoState(deskobj, type, autoTime)
        deskobj:stop_action('AUTO_STATE')
        intervel_endtime  = os.time() + autoTime --倒计时开始时间
        timeoutIntervel   = math.floor(autoTime)
        deskobj.intervel = timeoutIntervel
        if type == "startBet" then
            deskobj:auto_action('AUTO_STATE', autoTime, function() 
                game.startBet(deskobj)
            end)
        elseif type == "stopBet" then
            deskobj:auto_action('AUTO_STATE', autoTime, function() 
                game.stopBetTip(deskobj)
            end)
        elseif type == "startFree" then
            deskobj:auto_action('AUTO_STATE', autoTime, function() 
                game.startFree(deskobj)
            end)
        elseif type == "nextRound" then
            deskobj:auto_action('AUTO_STATE', autoTime, function() 
                game.startNextRound(deskobj)
            end)
        end
    end

    -------- 更改房间阶段状态(0游戏未开始  1开始发牌 2开始下注 3停止下注结算中) --------
    local function changeDeskState(deskobj, state)
        deskobj.state = state
    end

    local last_check_sec = 0
    local last_time = 0

    function game.startBet(deskobj)
        if deskobj.state ~= STATUS.STARTBET then
            return false
        end

        deskobj.poolround_id = water_pool.startPoolRound(deskobj, 0, PDEFINE.POOL_TYPE.none)

        -- AI下注
        AiMgr:startbet( timeout[2]-unbettime,CHIP )
        -- deskobj:auto_action("AI_BET", 2, seatUserBet) -- 两秒后AI下注
        game.setAutoState(deskobj, "stopBet", timeout[2])
    end

    local function startGame(deskobj)
        changeDeskState(deskobj, STATUS.STARTBET)
        deskobj.curround = deskobj.curround + 1
        local retobj = {c = PDEFINE.NOTIFY.BACCARAT_START, code = PDEFINE.RET.SUCCESS}  -- 提示回合开始
        deskobj:broadcastdesk(retobj)
        game.startBet(deskobj)
    end

    function game.startNextRound(deskobj)
        startGame(deskobj)
    end

    function game.stopBetTip(deskobj)
        if deskobj.state ~= STATUS.STARTBET then
            return false
        end
        changeDeskState(deskobj, STATUS.OPEN)
        AiMgr:stopbet( )
        game.setAutoState(deskobj, "startFree", timeout[3]) --N秒后进入空闲时间
        game.balance(deskobj)

        water_pool.endPoolRound(0, deskobj, PDEFINE.POOL_TYPE.none, deskobj.poolround_id)
    end

    function game.startFree(deskobj)
        
        changeDeskState(deskobj, STATUS.WAIT)
        deskobj.bet       = {0, 0, 0, 0, 0} -- 每1轮方位押注金额
        deskobj.realbet   = {0, 0, 0, 0, 0}
        deskobj.betdetail = {{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0}}

        for _, user in pairs(deskobj.users) do
            user.hadbet = 0
            user.bet = {0, 0, 0, 0, 0}
            user.betcoin = 0
            user.bchip = {}
        end

        local retobj = {c = PDEFINE.NOTIFY.BACCARAT_TIME_FREE, code = PDEFINE.RET.SUCCESS  }  --提示 空闲时间
        deskobj:broadcastdesk(retobj)

        game.setAutoState(deskobj, "nextRound", timeout[1]) --空闲时间结束后，回合开始
    end

    function CMD.bet(deskobj, user, recvobj)
        if deskobj.state ~= STATUS.STARTBET then
            return PDEFINE.DEFAULTREWARDRATE.RET.WAIT_FOR_NEXT_TIME
        end
        local uid     = math.floor(recvobj.uid)
        local bet    = recvobj.bet or {} --玩家下注
        if table.empty(bet) then
            plog("玩家下注", GAME_ID,  " 空的bet", msg)
            return PDEFINE.RET.ERROR.BET_NOT_ENOUGH
        end

        if nil == user then
            plog("玩家下注", GAME_ID,  " 玩家已不在房间:s", uid)
            return PDEFINE.RET.ERROR.PLAYER_NOT_FOUND
        end

        local coin = 0
        for i, row in ipairs(bet) do
            local betv = 0
            for index, times in pairs(row) do
                local betcoin = CHIP[index] * times

                betv = betv + betcoin
                coin = coin + betcoin
            end
            if betv > 0 then
                local checkbetv = betv + user.bet[i]
                if checkbetv < BET_LIMIT[i]["min"] or checkbetv > BET_LIMIT[i]["max"] then
                    return  PDEFINE.RET.ERROR.BET_NOT_ENOUGH --超出上限 
                end
            end
        end

        if coin <= 0 then
            plog("玩家下注", GAME_ID,  " 押注金币小于0", uid, coin)
            return PDEFINE.RET.ERROR.BET_NOT_ENOUGH
        end

        -- if coin < ALLBET_LIMIT["min"] or coin > ALLBET_LIMIT["max"] then
        --     return  PDEFINE.RET.ERROR.BET_NOT_ENOUGH --超出上限 
        -- end

        if user.coin < coin then
            plog("玩家下注", GAME_ID,  " 玩家金币不足", uid, user.coin, " vs ", coin)
            return PDEFINE.RET.ERROR.BET_NOT_ENOUGH
        end
        local ok,code = player_tool.calUserCoin(uid, -coin, "百家乐修改金币:"..(-coin), PDEFINE.ALTERCOINTAG.BET, deskobj, PDEFINE.POOL_TYPE.loan)
        if not ok then
            LOG_ERROR("百家乐修改金币失败.code:",code," coin:",-coin)
            return PDEFINE.RET.ERROR.BET_NOT_ENOUGH
        end

        user.hadbet = 1
        user.betcoin = user.betcoin + coin
        user.coin = Double_Add(user.coin ,-coin)

        local userbet = {}
        for place, row in pairs(bet) do
            if nil == userbet[place] then
                userbet[place] = 0
            end
            for index, times in pairs(row) do
                if nil == user.bet[place] then
                    user.bet[place] = 0
                end
                user.bet[place] = user.bet[place] + CHIP[index] * times
                userbet[place] = userbet[place] + CHIP[index] * times
                if user.bchip[place] == nil then
                    user.bchip[place] = {}
                end
                if user.bchip[place][index] == nil then
                    user.bchip[place][index] = 0
                end
                user.bchip[place][index] = user.bchip[place][index] + times

                deskobj.betdetail[place][index] = deskobj.betdetail[place][index] + times
                deskobj.bet[place]              = deskobj.bet[place] + CHIP[index] * times -- 每1轮 方位的 押注金额
                deskobj.realbet[place]          = deskobj.realbet[place] + CHIP[index] * times -- 每1轮 方位的 押注金额
            end
        end
        -- user.bchip  = bet
        --桌子押注金额变化
        local places = {}
        for i = 1, 5 do
            local tmp = {total=deskobj.bet[i], chip=deskobj.betdetail[i],coin=userbet[i], bchip = bet[i]}
            deskobj.places[i] = tmp
        end
        local retobj = { c = PDEFINE.NOTIFY.BACCARAT_CHANGE_DESKINFO, code = PDEFINE.RET.SUCCESS, places = deskobj.places, uid=user.uid}
        deskobj:broadcastdesk(retobj, user.uid)

        -- local resp = {coin = user.coin} --当前玩家的金币
        local resp = {coin = user.coin, bet = user.bet, bchip = user.bchip, betcoin = user.betcoin} --当前玩家的金币
        return PDEFINE.RET.SUCCESS, cjson.encode(resp)
    end

    local function global_over(deskobj)
        for _, user in pairs(deskobj.users) do
            if user.hadbet then
                user.hadbet = 0
                user.win = {0, 0, 0, 0, 0}
                user.bet = {0, 0, 0, 0, 0}
                user.betcoin = 0
                user.bchip = {}
            end
        end
        deskobj.win = {0, 0, 0, 0, 0}
        deskobj.places = {}
    end

    local function selectBalance(uid, balanList)
        for _, balan in pairs(balanList) do
            if uid == balan.uid then
                return balan
            end
        end
        return nil
    end

    function game.balance(deskobj)

        plog("开始结算", GAME_ID)
        local retobj = { c = PDEFINE.NOTIFY.BACCARAT_OVER_GAME, code = PDEFINE.RET.SUCCESS, fight = {}, places={}}

        local _type, win_ret, fight, rsplaces, loanid, loancoin = baccaratgame.balance(deskobj.realbet, deskobj.control[tonumber(PDEFINE.DEFAULTREWARDRATE)], deskobj)
        deskobj.fight = fight
        baccaratgame.maintainHistory(HISTORY, deskobj.fight, win_ret, _type)
        LAST_RESULT = baccaratgame.maintainDeskTrend(WAY, LAST_RESULT, deskobj.history, rsplaces)
        
        retobj.fight = deskobj.fight
        local now = os.time()
        local balanList     = {}
        local balanceCoin   = 0 --庄此轮输赢
        local noRobotBalanceCoin = 0 --去掉机器人的庄家输赢
        local bankwin  = 0

        local realUserNum = 0
        local result_users = {}
        local prize_results = {}

        for _, muser in pairs(deskobj.users) do
            if muser.cluster_info then
                realUserNum = realUserNum + 1
            end
            if muser.hadbet > 0 then
                local userBlance = { uid = muser.uid, coin = 0, bet = 0, win = 0} --bet:当前局的玩家的押注, win:当前局玩家赢到的金币，为负数表示输掉了
                --方位
                local usercalcoin = 0
                for i= 1, 5 do
                    if muser.bet[i] > 0 then
                        if rsplaces[i].win > 0 then  --方位赢了
                            local amount = (muser.bet[i] * rsplaces[i].multiple) --庄家赔付金额
                            muser.win[i] = muser.win[i] + amount + muser.bet[i] --玩家赢分要返回押注额
                            userBlance.win = userBlance.win + amount + muser.bet[i] --结算界面展示
                            balanceCoin    = balanceCoin - amount
                            ----庄家输
                            if muser.cluster_info then
                                usercalcoin        = usercalcoin + amount + muser.bet[i]
                                -- bankerwin[i]       = bankerwin[i] - amount
                                noRobotBalanceCoin = noRobotBalanceCoin - amount
                            end
                        else
                            local amount = muser.bet[i] --闲家赔付金额
                            muser.win[i] = muser.win[i] - amount
                            balanceCoin = balanceCoin + amount
                            if muser.cluster_info then
                                noRobotBalanceCoin = noRobotBalanceCoin + amount
                                -- bankerwin[i] = bankerwin[i] + amount
                            end
                        end
                    end
                end

                if muser.cluster_info then
                    local addcoin = usercalcoin - muser.betcoin
                    LOG_DEBUG("baccaratgame.userwin",addcoin, usercalcoin, muser.betcoin)
                    bankwin = bankwin - addcoin
                    local prize_results = {}
                    prize_results.bet = muser.bet
                    prize_results.win = rsplaces
                    prize_results.result = deskobj.fight
                    table.insert(result_users, { uid = muser.uid, bet_coin = muser.betcoin, win_coin = addcoin, prize_result = prize_results})

                    local ok,code = player_tool.calUserCoin(muser.uid, usercalcoin, "百家乐修改金币:"..usercalcoin, PDEFINE.ALTERCOINTAG.WIN, deskobj, PDEFINE.POOL_TYPE.loan)
                    if not ok then
                        LOG_ERROR("百家乐修改金币失败.code:",code," coin:",usercalcoin)
                    end
                    
                    muser.coin = Double_Add(muser.coin , usercalcoin)

                    local msg = horse_race_lamp1(muser.uid, usercalcoin, muser.betcoin)
                    if msg then
                        pcall(cluster.call, "master", ".userCenter", "sendAllServerNotice", msg, 2, 1)
                    end
                end
                userBlance.coin = muser.coin
                table.insert(balanList, userBlance)
            end
        end

        -- 百人直接上报结果
        water_pool.sendGameLog({
            mb = 1,
            send_api_result_userlist = result_users,
        }, deskobj, {}, nil, nil, deskobj.poolround_id)

        LOG_DEBUG("baccaratgame.balance2",loanid, loancoin, bankwin)

        if loanid ~= nil and loanid > 0 then
            water_pool.poolEvent(deskobj, nil, PDEFINE.POOL_TYPE.loan, loanid, loancoin, deskobj.poolround_id)
        else
            --没有借款就看有没有入彩池的钱
            -- local bankwin = 0
            -- for k,amount in pairs(bankerwin) do
            --     bankwin = bankwin + amount
            -- end
            if bankwin > 0 then
                water_pool.pushPool(nil, deskobj, bankwin, deskobj.poolround_id)
                water_pool.revertpool_local(bankwin, deskobj.gameid, true)
            end
        end
        retobj.history = deskobj.history
        for _, row in pairs(rsplaces) do
            row.multilple = nil
        end
        retobj.places = rsplaces
        plog("真实玩家", GAME_ID, realUserNum)
        if realUserNum > 0 then
            --庄家结算记录
            local cards = {deskobj.fight[1].cards, deskobj.fight[2].cards}
        end

        for _, muser in pairs(deskobj.users) do
            if muser.cluster_info then
                local balan = selectBalance(muser.uid, balanList)
                if nil == balan then
                    --没下注的玩家
                    retobj.user = { uid = muser.uid, coin = muser.coin, win = 0}
                else
                    retobj.user = balan
                end
                pcall(cluster.call, muser.cluster_info.server, muser.cluster_info.address, "sendToClient", cjson.encode(retobj))
            end
        end
        deskobj:removeExitedUser()
        global_over(deskobj)
    end

    function game_hander.create_deskinfo(deskobj_all)
        local deskobj = {
            state   = STATUS.WAIT, --桌子状态
            chip    = CHIP, --下注筹码选项
            min      = ALLBET_LIMIT["min"], --最小押注金额
            max      = ALLBET_LIMIT["max"], --最大押注金额
            curround = 0, --当前轮数
            outtime  = timeout,
            intervel = timeout[1],
            bet      = {0,0,0,0,0}, -- 每1轮 各方位押注
            realbet  = {0,0,0,0,0}, -- 每1轮 各方位真实押注
            betdetail= {
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0}
            }, --每个方位，筹码的投注次数
            win      = {0,0,0,0,0}, -- 每1轮 各方位输赢
            places = {},
            state       = 1,  --房间当前游戏状态
            fight       = {}, --2方 庄，闲
            places      = {}, --方位押注信息
            history     = {}, --最近64局记录
        }

        for i =1 ,5 do
            table.insert(deskobj.places, {total=0, chip={0,0,0,0,0,0,0,0}, bet=0})
        end
        for i = 1, 2 do
            table.insert(deskobj.fight, {cardtype=0, cards={0,0}})
        end

        --构建假的历史数据 64路
        deskobj.history ,HISTORY, WAY = baccaratgame.buildHistory()
        LAST_RESULT = deskobj.history[#deskobj.history]

        intervel_endtime  = os.time() --倒计时开始时间
        timeoutIntervel   = 0

        AiMgr:initcontrol( deskobj_all.aicontrol,game_hander,deskobj_all )
        
        return deskobj
    end

    function game_hander.start_game(deskobj)
        deskobj:auto_action('GAME_ACTION', timeout[1], function() 
            startGame(deskobj)
        end)
        -- addAIusers(ROBOT_NUMIN)
    end

    function game_hander.create_userinfo()
        local userInfo        = {}
        userInfo.state        = 0 --未准备 0待准备 1准备 2已发牌
        userInfo.bet          = {0, 0, 0, 0, 0} --每个方位的押注额
        userInfo.win          = {0, 0, 0, 0, 0} --1轮的各方位输赢
        userInfo.hadbet       = 0 --1 已押(随便压1个方位就行) 0未押
        userInfo.bchip        = {} --每个方位投注筹码次数
        userInfo.betcoin = 0
        return userInfo
    end

    --玩家重新进游戏的时候需要重置的信息
    function game_hander.reset_userinfo( user )
        -- body
    end

    function CMD.trend(deskobj, user, recvobj)
        if nil == user then
            return PDEFINE.RET.ERROR.NOT_IN_ROOM
        end
        return PDEFINE.RET.SUCCESS, cjson.encode({ history=HISTORY, way=WAY})
    end

    function game_hander.get_deskinfo_2c(deskobj, user)
        deskobj.uuid = nil
        deskobj.uuid = nil
        deskobj.ssid = nil
        deskobj.users = nil
        deskobj.basecoin = nil
        deskobj.win = nil
        deskobj.level = nil
        deskobj.revenue = nil
        deskobj.realbet = nil
        deskobj.curseat = nil
        deskobj.seat = nil
        deskobj.betdetail = nil
        deskobj.chip = nil
        deskobj.control = nil
        deskobj.aicontrol = nil
        deskobj.intervel = math.max(intervel_endtime - os.time(), 0)
        return deskobj
    end

    function game_hander.get_userinfo_2c(user)
        local t = 0
        for _, v in pairs(user.bet) do
            t = t + v
        end
        return {
            uid = user.uid,
            coin = user.coin,
            bet = user.bet,
            betcoin = user.betcoin,
            win = 0,
            bchip = user.bchip,
        }
    end

    function game_hander.ai_join(deskobj, ai)

    end

    function game_hander.ai_kick(deskobj, ai)

    end

    --[[
    ai:
    {
        uid=xx,
        coin=xx
    }

    betplace_table:
    {
        [1] = {
            bet_place=xx,
            betcoin=xx,
            chipplace=xx
        },
        [2] = {
            bet_place=xx,
            betcoin=xx,
            chipplace=xx
        },
    }
    betinfo.bet_place = bet_place
    betinfo.betcoin = betcoin
    betinfo.chipplace = chipplace

    ]]
    function game_hander.ai_bet(deskobj, ai, betplace_table)
        
        -- LOG_DEBUG("ai_bet betplace_table:",betplace_table)

        for k,betinfo in pairs(betplace_table) do
            local place = betinfo.bet_place
            local betcoin = betinfo.betcoin
            local coin_index = betinfo.chipplace

            deskobj.bet[place]  = deskobj.bet[place] + betcoin -- 每1轮 方位的 押注金额
            deskobj.betdetail[place][coin_index] = deskobj.betdetail[place][coin_index] + 1 --方位筹码的某筹码的投注次数，客户端展示金币用
            for i = 1, 5 do
                local bchip = {0,0,0,0,0,0,0,0}
                local tmp = {total=deskobj.bet[i], chip=deskobj.betdetail[i],coin=0,bchip = {}}
                if place == i then
                    for k=1, 8 do
                        if k == coin_index then
                            bchip[coin_index] = bchip[coin_index] + 1
                        end
                    end
                end
                tmp.bchip = bchip
                deskobj.places[i] = tmp
            end

            local retobj = { c = PDEFINE.NOTIFY.BACCARAT_CHANGE_DESKINFO, code = PDEFINE.RET.SUCCESS, places = deskobj.places, uid=ai.uid}
            -- LOG_DEBUG("ai_bet places:",deskobj.places)
            deskobj:broadcastdesk(retobj)
        end
    end

    function game_hander.exitWhileGameStart( deskobj,user )
        -- body
    end

    betonline.start(game_hander, CMD)
end

return basebacca