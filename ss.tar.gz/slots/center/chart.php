<?php 
ini_set('memory_limit', '1024M');

/**
* pool.json 解开格式：
* Array
(
    [gameid] => 101 //游戏id
    [beforecoin] => 100 //开始金币
    [datalist] => Array //最近1000局记录
        ( 
            [0] => 1 //每局的金币变化情况 正为入水池，负为出水池
            [1] => 2   
    )

)
*/
$file_pool_log = "./pool.json"; 

/**
* user.json 解开格式：
* Array
(
    [beforecoin] => 100 //开始金币
    [datalist] => Array //最近1000局输赢记录
        ( 
            [0] => 1 //每局的金币变化情况 正为中奖，负为亏损
            [1] => 2   
    )

)
*/
$file_user_log = "./user.json"; 

$pooldata = json_decode(file_get_contents($file_pool_log), true);

$userdata = json_decode(file_get_contents($file_user_log), true);

//玩家金币变化情况
$userbettimes = [];
$usercoinarr = [];
$i = 0;
$coin = $userdata['beforecoin'];
foreach($userdata['datalist'] as $v) {
  $i++;
  $userbettimes[] = $i;

  $coin = $coin + $v;
  $usercoinarr[] = $coin;
}  
$userdata['aftercoin'] = $coin;

//奖池变化情况 & 开奖情况
$pooltimes = [];
$poolcoinarr = [];
$addcoinarr  = [];
$coin = $pooldata['beforecoin'];
$i = 0;
foreach($pooldata['datalist'] as $v) {
  $i++;
  $pooltimes[] = $i;

  $coin = $coin + $v;
  $poolcoinarr[] = $coin;

  $addcoinarr[] = $v;
}  

?>
<!DOCTYPE html>
<html style="height: 100%">
   <head>
       <meta charset="utf-8">
   </head>
   <body style="height: 100%; margin: 0">
    <?php 
    echo "<br/>";
    // $rate = number_format(($winCnt/$allCnt), 2);
echo "玩家金币从{$userdata['beforecoin']}开始，押注". count($poolcoinarr)."次, 变为:{$userdata['aftercoin']}";
echo "<br/>";
echo "<br/>";
echo "总开奖:", $i, "次,  总中奖金币:", array_sum($addcoinarr);
echo "<br/>";
echo "<br/>";
    ?>
     <div style="width: 1200px;height:300px;float:left;">
       <div id="container1" style="height: 100%; width: 1000px;"></div>
     </div>
     <div style="width: 1200px;height:300px;float:left;">
       <div id="container2" style="height: 100%; width: 1000px;"></div>
     </div>
     <div style="width: 1200px;height:300px;float:left;">
       <div id="container3" style="height: 100%; width: 1000px;"></div>
     </div>
      <script type="text/javascript" src="echarts.common.min.js"></script>
       <script type="text/javascript">
var dom = document.getElementById("container1");
var myChart = echarts.init(dom);
var app = {};
option = null;
option = {
  title:{
    text: "玩家金币变化",
    textStyle:{
      align: "center",
    }
  },
    xAxis: {
        type: 'category',
        data: <?php echo "[" . implode($userbettimes, ",") . "]";?>
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        data: <?php echo "[" . implode($usercoinarr, ",") . "]";?>,
        type: 'line',
        smooth: true
    }]
};
myChart.setOption(option, true);

var dom2 = document.getElementById("container2");
var myChart2 = echarts.init(dom2);
var app = {};
option = null;
option = {
  title:{
    text: "奖池变化情况",
    textStyle:{
      align: "center",
    }
  },
    xAxis: {
        type: 'category',
        data: <?php echo "[" . implode($pooltimes, ",") . "]";?>
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        data: <?php echo "[" . implode($poolcoinarr, ",") . "]";?>,
        type: 'line',
        smooth: true
    }]
};

myChart2.setOption(option, true);

var dom3 = document.getElementById("container3");
var myChart3 = echarts.init(dom3);
var app = {};
option = null;
option = {
  title:{
    text: "开奖情况",
    textStyle:{
      align: "center",
    }
  },
    xAxis: {
        type: 'category',
        data: <?php echo "[" . implode($pooltimes, ",") . "]";?>
    },
    yAxis: {
        type: 'value'
    },
    series: [{
        data: <?php echo "[" . implode($addcoinarr, ",") . "]";?>,
        type: 'line',
        smooth: true
    }]
};
myChart3.setOption(option, true);

       </script>
   </body>
</html>
