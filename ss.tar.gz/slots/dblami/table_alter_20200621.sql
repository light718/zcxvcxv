DROP TABLE IF EXISTS `s_reward_online`;
CREATE TABLE `s_reward_online` (
  `id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `s_reward_online` VALUES (1,1,1000,1),(2,3,1000,2);

update s_game_type set state=0 where gameid=253;



DELETE FROM `s_quest` WHERE id=6;
INSERT INTO `s_quest` VALUES (6,1,0,1,'分享', 8000,'10001_icon.png',0,1,1,0,0,0,0,0.00,0.00);






DROP TABLE IF EXISTS `s_fb_award`;
CREATE TABLE `s_fb_award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` int(11) NOT NULL COMMENT '分享或邀请次数',
  `count` int(11) NOT NULL COMMENT '分享或邀请奖金',
  `type` int(11) NOT NULL  COMMENT '奖励类型, 1分享奖金 2邀请奖金',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


--单次分享奖励  --单次邀请奖励
INSERT INTO `s_fb_award` (`num`, `count`, `type`) VALUES (0,8000, 1),(0,20000, 2);  

INSERT INTO `s_fb_award` (`num`, `count`, `type`) VALUES (1,18000, 1),(8,36000, 1),(12 , 54000, 1),(23 , 72000, 1),(34  ,90000, 1),(52 , 100000, 1),(71  ,125000, 1),(100 , 250000, 1);

INSERT INTO `s_fb_award` (`num`, `count`, `type`) VALUES (1 , 80000, 2),(3 , 100000, 2),(5 , 100000, 2),(8 , 180000, 2),(15 , 350000, 2),(25 , 500000, 2),(35 , 500000, 2),(50 , 750000, 2);
