ALTER TABLE `s_config_level_upgrade` 
ADD COLUMN `ratefree` float(5, 3) NULL COMMENT '免费触发概率' AFTER `openbetlevel`,
ADD COLUMN `expendconsume` int(11) NULL COMMENT '期望消耗' AFTER `ratefree`;


ALTER TABLE `s_game` 
ADD COLUMN `ratefree` float(5, 4) NULL DEFAULT 0.0 COMMENT '免费游戏概率' AFTER `betrate`,
ADD COLUMN `ratesub` float(5, 4) NULL DEFAULT 0.0 COMMENT '小游戏概率' AFTER `ratefree`;


update s_game set ratefree='0.20525451' where id=141;
update s_game set ratefree='0.019561815' where id=150;
update s_game set ratefree='0.293944738' where id=151;
update s_game set ratefree='0.017307027' where id=152;
update s_game set ratefree='0.116570496' where id=156;
update s_game set ratefree='0.192233756' where id=158;
update s_game set ratefree='0.174337517' where id=170;
update s_game set ratefree='0.121654501' where id=171;
update s_game set ratefree='0.166666667' where id=415;
update s_game set ratefree='0.128205128' where id=416;
update s_game set ratefree='0.10801469' where id=417;
update s_game set ratefree='0.176320197' where id=418;

update s_game set ratesub='0.187617261' where id=113;
update s_game set ratesub='0.033707865' where id=150;
update s_game set ratesub='0.024416712' where id=152;
update s_game set ratesub='0.031575624' where id=159;

update s_game set betrate=0.9 where id in (141,158);