update `s_game_type` set state = 2 where gameid = 102;
update `s_game_type` set state = 2 where gameid = 103;
update `s_game_type` set state = 2 where gameid = 104;


DROP TABLE IF EXISTS `d_actions`;
DROP TABLE IF EXISTS `d_statistics`;
CREATE TABLE `d_statistics` (
  `id` int(11) NOT NULL COMMENT '序列id' AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL COMMENT '玩家uid',
  `act` varchar(1024) DEFAULT '' COMMENT '操作位置',
  `ts` int(11) DEFAULT NULL COMMENT '时间戳',
  `ext` varchar(100) DEFAULT NULL COMMENT '操作类型唯一id',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='rummySlots打点统计';
