ALTER TABLE `s_shop` ADD COLUMN `ocount` varchar(255) NULL COMMENT '原始金币' AFTER `title`;

update s_shop set `count`=750000, ocount=375000 where productid='com.rummyslots.gold2' and stype=1;
update s_shop set `count`=1150000, ocount=575000 where productid='com.rummyslots.gold3' and stype=1;
update s_shop set `count`=2000000, ocount=1000000 where productid='com.rummyslots.gold5' and stype=1;
update s_shop set `count`=4200000, ocount=2100000 where productid='com.rummyslots.gold10' and stype=1;
update s_shop set `count`=9000000, ocount=4500000 where productid='com.rummyslots.gold13' and stype=1;
update s_shop set `count`=27000000, ocount=13500000 where productid='com.rummyslots.gold14' and stype=1;


update s_config set v='{"times":5,"delay":20,"cfg_1":[10000,100000,20000,200000,30000,300000,40000,400000,50000,450000,70000,580000,80000,680000,90000,800000],"rate_1":[15,1,30,1,25,1,20,1,15,1,10,1,8,1,5,1],"cfg_2":[800000,2000000,3000000,4000000,12000000,18000000,8800000,21800000,9800000,88800000],"rate_2":[5,6,8,4,3,2,2,1,1,1],"vip":[1,1.25,1.5,2,3,4,5],"coins":[10000,12000,16000,20000]}' where k='turntable';
update s_shop set productid='com.rummyslots.gold5', productid_gp='com.rummyslots.gold5',count=3800000, title='金币3800000' where stype=2;
