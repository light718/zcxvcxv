update s_shop set productid='com.rummyslots.gold5', productid_gp='com.rummyslots.gold5',`count`=3800000, title='金币3800000',amount=4.99,discountTime=300 where stype=2;

ALTER TABLE `s_shop` MODIFY COLUMN `stype` tinyint(1) NULL DEFAULT NULL COMMENT '类型1商城 2限时优惠 3转盘 4激励礼包 5等级礼包 6签到 7首充礼包 8onetimeonly' AFTER `appid`;