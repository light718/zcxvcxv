update s_sess set mincoin = 50000 where gameid=252 and `level` = 2;
update s_sess set mincoin = 500000 where gameid=252 and `level` = 3;
update s_sess set mincoin = 5000000 where gameid=252 and `level` = 4;
update s_sess set mincoin = 50000000 where gameid=252 and `level` = 5;

ALTER TABLE `d_user` 
ADD COLUMN `wincoin` bigint(20) NULL DEFAULT 0 COMMENT '输赢金币' AFTER `deviceToken`,
ADD COLUMN `consvalue` bigint(20) NULL DEFAULT 0 COMMENT '玩家消耗价值' AFTER `wincoin`;