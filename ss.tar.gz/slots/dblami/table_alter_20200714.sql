update s_shop set ocount=1000000,count=6000000,discount=500 where stype=5;

insert into s_game (id,title,status,betrate,allincontrol) values(419,'regal tiger',1,1,''),(420,'god of fire',1,1,''),(421,'moment of wonder', 1,1,''),(422,'theme park blast',1,1,'');

insert into s_sess (gameid,title,basecoin,ord)
values (419,'regal tiger',1,105),(420,'god of fire',1,110),(421,'moment of wonder',1,115),(422,'theme park blast',1,120);

insert into s_game_type(gametype,gameid,title,state,hot)
 values(2,419,'regal tiger',1,100),(2,420,'god of fire',1,100),(2,421,'moment of wonder',1,100),(2,422,'theme park blast',1,100);


 ALTER TABLE `d_user` ADD COLUMN `buffcoin`  bigint(20) NULL DEFAULT 0 COMMENT 'buff累加coin';

 ALTER TABLE `s_shop` MODIFY COLUMN `stype` tinyint(1) NULL DEFAULT NULL COMMENT '类型1商城 2限时优惠 3转盘 4激励礼包 5等级礼包 6签到 7首充礼包 8onetimeonly 9排行榜商品' AFTER `appid`;

 INSERT INTO `s_shop` VALUES ('40', '排行', null, '400000', '0.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold1', 'com.rummyslots.gold1', '0', '9', '', '1');
INSERT INTO `s_shop` VALUES ('41', '排行', null, '900000', '1.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold2', 'com.rummyslots.gold2', '0', '9', '', '2');
INSERT INTO `s_shop` VALUES ('42', '排行', null, '1380000', '2.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold3', 'com.rummyslots.gold3', '0', '9', '', '3');
INSERT INTO `s_shop` VALUES ('43', '排行', null, '1880000', '3.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold4', 'com.rummyslots.gold4', '0', '9', '', '4');
INSERT INTO `s_shop` VALUES ('44', '排行', null, '2400000', '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold5', 'com.rummyslots.gold5', '0', '9', '', '5');
INSERT INTO `s_shop` VALUES ('45', '排行', null, '3000000', '5.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold6', 'com.rummyslots.gold6', '0', '9', '', '6');
INSERT INTO `s_shop` VALUES ('46', '排行', null, '3400000', '6.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold7', 'com.rummyslots.gold7', '0', '9', '', '7');
INSERT INTO `s_shop` VALUES ('47', '排行', null, '3800000', '7.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold8', 'com.rummyslots.gold8', '0', '9', '', '8');
INSERT INTO `s_shop` VALUES ('48', '排行', null, '4400000', '8.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold9', 'com.rummyslots.gold9', '0', '9', '', '9');
INSERT INTO `s_shop` VALUES ('49', '排行', null, '5040000', '9.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold10', 'com.rummyslots.gold10', '0', '9', '', '10');
INSERT INTO `s_shop` VALUES ('50', '排行', null, '6240000', '11.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold18', 'com.rummyslots.gold18', '0', '9', '', '11');
INSERT INTO `s_shop` VALUES ('51', '排行', null, '6800000', '12.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold11', 'com.rummyslots.gold11', '0', '9', '', '12');
INSERT INTO `s_shop` VALUES ('52', '排行', null, '7200000', '13.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold21', 'com.rummyslots.gold21', '0', '9', '', '13');
INSERT INTO `s_shop` VALUES ('53', '排行', null, '8200000', '15.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold12', 'com.rummyslots.gold12', '0', '9', '', '14');
INSERT INTO `s_shop` VALUES ('54', '排行', null, '9120000', '17.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold25', 'com.rummyslots.gold25', '0', '9', '', '15');
INSERT INTO `s_shop` VALUES ('55', '排行', null, '10800000', '19.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold13', 'com.rummyslots.gold13', '0', '9', '', '16');
INSERT INTO `s_shop` VALUES ('56', '排行', null, '13440000', '23.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold19', 'com.rummyslots.gold19', '0', '9', '', '17');
INSERT INTO `s_shop` VALUES ('57', '排行', null, '14400000', '25.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold23', 'com.rummyslots.gold23', '0', '9', '', '18');
INSERT INTO `s_shop` VALUES ('58', '排行', null, '15360000', '27.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold17', 'com.rummyslots.gold17', '0', '9', '', '19');
INSERT INTO `s_shop` VALUES ('59', '排行', null, '19200000', '34.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold16', 'com.rummyslots.gold16', '0', '9', '', '20');
INSERT INTO `s_shop` VALUES ('60', '排行', null, '20400000', '35.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold26', 'com.rummyslots.gold26', '0', '9', '', '21');
INSERT INTO `s_shop` VALUES ('61', '排行', null, '24480000', '44.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold24', 'com.rummyslots.gold24', '0', '9', '', '22');
INSERT INTO `s_shop` VALUES ('62', '排行', null, '26400000', '47.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold20', 'com.rummyslots.gold20', '0', '9', '', '23');
INSERT INTO `s_shop` VALUES ('63', '排行', null, '28800000', '48.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold22', 'com.rummyslots.gold22', '0', '9', '', '24');
INSERT INTO `s_shop` VALUES ('64', '排行', null, '32400000', '49.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold14', 'com.rummyslots.gold14', '0', '9', '', '25');
INSERT INTO `s_shop` VALUES ('65', '排行', null, '50000000', '69.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'com.rummyslots.gold27', 'com.rummyslots.gold27', '0', '9', '', '26');
INSERT INTO `s_shop` VALUES ('66', '排行', null, '80000000', '99.99', '0', null, '0', '0', '1', '10', '1', '0', '0', ' com.rummyslots.gold15', ' com.rummyslots.gold15', '0', '9', '', '27');