INSERT INTO `s_config` (`k`, `v`, `memo`) VALUES ('betlevelbuff', '{"gear":5,"mult":100,"buff":1.2}', '押注等级buff');

update s_game set ratefree='0.130208333' where id=141;
update s_game set ratesub='0.194552529' where id=113;
update s_game set ratefree='0.04456328', ratesub='0.026415094' where id=150;
update s_game set ratefree='0.182149362' where id=151;
update s_game set ratefree='0.036764706', ratesub='0.019337017' where id=152;
update s_game set ratefree='0.164473684' where id=156;
update s_game set ratefree='0.160513644' where id=158;
update s_game set ratesub='0.034246575' where id=159;
update s_game set ratefree='0.086843248' where id=170;
update s_game set ratefree='0.064926633' where id=171;
update s_game set ratefree='0.10161982' where id=415;
update s_game set ratefree='0.099615484' where id=416;
update s_game set ratefree='0.068714354' where id=417;
update s_game set ratefree='0.137513751' where id=418;