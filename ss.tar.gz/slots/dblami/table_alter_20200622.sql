

ALTER TABLE `s_reward_online` ADD `random` varchar(500);
UPDATE `s_reward_online` SET `random`= '{"s":5,"e":15}', `itemid`= 1, `time`= 15 where `id` = 1;
UPDATE `s_reward_online` SET `random`= '{"s":15,"e":100}', `itemid`= 2, `time`= 180 where `id` = 2;


update d_robot set uid=round(uid/100);