


--现金争霸赛前三名得奖玩家填报的信息
DROP TABLE IF EXISTS `d_cash_rummy_match`;
CREATE TABLE `d_cash_rummy_match` (
  `id` int(11) NOT NULL COMMENT '序列id' AUTO_INCREMENT,
  `mailid` bigint(20) DEFAULT NULL COMMENT '对应的邮件id',
  `uid` bigint(20) NOT NULL COMMENT '用户id',
  `facebook` varchar(100) DEFAULT NULL COMMENT 'fackbook昵称', 
  `phone` varchar(100) DEFAULT NULL COMMENT '电话号码',
  `name` varchar(100) DEFAULT NULL COMMENT '玩家昵称',
  `time` varchar(100) DEFAULT NULL COMMENT '填报的时间',
  `expire` int(11) NOT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mailid` (`mailid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='现金争霸赛前三名得奖玩家填报的信息';

-- insert into d_cash_rummy_match (mailid, uid, facebook, phone, name, time, expire) values(1167, 100126, 'facekbooklll', '88755554444', 'bart_test', '2020-07-08 20:56:00', 1594212960 + 259200);
