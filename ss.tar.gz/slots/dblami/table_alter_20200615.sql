
update s_quest set count=20000 where id= 1;
update s_quest set count=50000 where id= 2;
update s_quest set count=100000 where id= 3;

update s_quest set descr='押注金币超过500000' where id= 4;
update s_quest set parm1=500000 where id= 4;
update s_quest set count=120000 where id= 4;

update s_quest set count=150000 where id= 5;


update s_reward_online set count=1000 where id= 1;
update s_reward_online set count=1000 where id= 2;





update `s_config` set v = '{"times":5,"delay":3600,"cfg_1":[10000,15000,20000,25000,30000,35000,40000,45000,50000,60000,70000,80000,90000,100000,150000,200000],"rate_1":[1,2,3,4,5,6,7,8,9,8,7,6,5,4,3,2],"cfg_2":[4000000,5000000,6000000,8000000,10000000,12000000,14000000,16000000,18000000,20000000],"rate_2":[5,6,8,4,3,2,2,1,1,1],"vip":[1,1.25,1.5,2,3,4,5],"coins":[10000,12000,16000,20000]}' where k = 'turntable';