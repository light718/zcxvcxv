


ALTER TABLE `d_user` ADD COLUMN `isgetinitgift` tinyint(1) DEFAULT '0' COMMENT '是否领取过新手礼包';
ALTER TABLE `d_user` ADD COLUMN `logintype` int(11) NOT NULL DEFAULT '0' COMMENT '玩家登录方式';


UPDATE `s_game_type` SET  `hot` = 101 WHERE `gameid` = 102;
UPDATE `s_game_type` SET  `hot` = 101 WHERE `gameid` = 103;
UPDATE `s_game_type` SET  `hot` = 101 WHERE `gameid` = 104;
