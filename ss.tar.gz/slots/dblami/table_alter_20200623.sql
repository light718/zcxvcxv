ALTER TABLE `s_game` ADD COLUMN `betrate` float(4, 2) NULL DEFAULT 1.00 COMMENT '投注比例' AFTER `collector`;

update s_game set betrate=0.6 where id=141;
update s_game set betrate=0.9 where id=113;
update s_game set betrate=1 where id=150;
update s_game set betrate=1 where id=151;
update s_game set betrate=1 where id=152;
update s_game set betrate=1 where id=153;
update s_game set betrate=1 where id=156;
update s_game set betrate=0.6 where id=158;
update s_game set betrate=1 where id=159;
update s_game set betrate=1 where id=170;
update s_game set betrate=1 where id=415;
update s_game set betrate=1 where id=416;
update s_game set betrate=1 where id=417;
update s_game set betrate=1 where id=418;

update s_config_level_upgrade set level=level+1;
insert into s_config_level_upgrade(level, coin,reward,scale,vipexp,defaultbetlevel,openbetlevel) value(1,0,0,1,0,1,2);