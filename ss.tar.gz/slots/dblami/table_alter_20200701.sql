
update `s_config` set `v` = 1000000 where `k` = "bindfbcoin";


