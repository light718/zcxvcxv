INSERT INTO `s_shop` VALUES (37, '开服活动', '100', 300, 0.00, 0, NULL, 300, 0, 0, 10, 1, 0, 0, 'com.rummyslots.gold1', 'com.rummyslots.gold1', 0, 7, '', 0);
INSERT INTO `s_shop` VALUES (38, 'one time only', '372500', 1490000, 0.99, 0, NULL, 300, 0, 0, 10, 1, 0, 0, 'com.rummyslots.gold1', 'com.rummyslots.gold1', 0, 8, '', 0);
INSERT INTO `s_shop` VALUES (39, '等级ingame', '360000', 3600000, 0.99, 0, NULL, 900, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold5', 'com.rummyslots.gold5', 0, 5, '', 0);

ALTER TABLE `s_config_level_upgrade` MODIFY COLUMN `expendconsume` bigint(20) NULL DEFAULT NULL COMMENT '期望消耗' AFTER `ratefree`;

ALTER TABLE `d_user` ADD COLUMN `isonetime` int(0) NULL DEFAULT 0 COMMENT '购买过onetimeonly的时间';

CREATE TABLE `d_user_firstbuy`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NULL COMMENT 'uid',
  `product_id` varchar(255) NULL COMMENT '商品id',
  `create_time` int(11) NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  INDEX `uid`(`uid`)
) COMMENT = '用户单个商品首次购买记录';

update s_shop set discountTime=3*3600 where stype=5;