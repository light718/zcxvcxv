replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (493, "古灵精怪的舰娘", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(493, "quickwittedcollection", 0, 0.1, 0.1, '[10,20,500,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 493, "古灵精怪的舰娘", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (494, "无所畏惧的舰娘", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(494, "heroiccollection", 0, 0.1, 0.1, '[10,20,50,5000,500]', '[4,6,9,16,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 494, "无所畏惧的舰娘", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (495, "阿尔忒弥斯", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(495, "aphrodite", 0, 0.1, 0.1, '[5,20,300,1000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 495, "阿尔忒弥斯", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (496, "崛起的美杜莎", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(496, "risingmedush", 0, 0.1, 0.1, '[5,20,100,5000,1000]', '[4,6,9,16,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 496, "崛起的美杜莎", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (497, "波塞冬", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(497, "poseidon", 0, 0.1, 0.1, '[5,10,200,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 497, "波塞冬", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (498, "雅典娜", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(498, "athena", 0, 0.1, 0.1, '[15,60,500,5000,1000,2500]', '[4,6,9,16,11,13]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 498, "雅典娜", 1, 100);