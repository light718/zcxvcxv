DROP TABLE IF EXISTS `d_user_fund2`;
CREATE TABLE `d_user_fund2` (
  `uid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'uid',
  `fundid` int(11) NOT NULL COMMENT '基金配置id',
  `lv` int(11) DEFAULT NULL COMMENT '开发领取的等级',
  `coin` int(11) DEFAULT NULL COMMENT '赠送的金币',
  `prize` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '赠送的vip点数',
  `collect_time` int(11) DEFAULT NULL COMMENT '领取时间',
  `state` tinyint(1) DEFAULT '0' COMMENT '状态 0未开启 1正常',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`uid`,`fundid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户成长基金记录表';


DROP TABLE IF EXISTS `s_fund`;
CREATE TABLE `s_fund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT NULL COMMENT '开启等级',
  `coin` int(11) DEFAULT NULL COMMENT '赠送金币数',
  `prize` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '其他道具json格式',
  `status` tinyint(1) DEFAULT '1' COMMENT '是否有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成长基金配置';


INSERT INTO `s_fund` VALUES ('1', '0', '5500000', '[{\"s\":8,\"n\":5},{\"s\":10,\"n\":500}]', '1');
INSERT INTO `s_fund` VALUES ('2', '15', '13500000', '[{\"s\":8,\"n\":5},{\"s\":10,\"n\":500}]', '1');
INSERT INTO `s_fund` VALUES ('3', '30', '13500000', '[{\"s\":8,\"n\":6},{\"s\":10,\"n\":300}]', '1');
INSERT INTO `s_fund` VALUES ('4', '45', '13500000', '[{\"s\":8,\"n\":8},{\"s\":10,\"n\":400}]', '1');
INSERT INTO `s_fund` VALUES ('5', '60', '13500000', '[{\"s\":8,\"n\":10},{\"s\":10,\"n\":500}]', '1');
INSERT INTO `s_fund` VALUES ('6', '75', '13500000', '[{\"s\":8,\"n\":12},{\"s\":10,\"n\":600}]', '1');
INSERT INTO `s_fund` VALUES ('7', '100', '13500000', '[{\"s\":8,\"n\":14},{\"s\":10,\"n\":700}]', '1');
INSERT INTO `s_fund` VALUES ('8', '130', '13500000', '[{\"s\":8,\"n\":16},{\"s\":10,\"n\":800}]', '1');
INSERT INTO `s_fund` VALUES ('9', '160', '13500000', '[{\"s\":8,\"n\":18},{\"s\":10,\"n\":900}]', '1');
INSERT INTO `s_fund` VALUES ('10', '200', '13500000', '[{\"s\":8,\"n\":20},{\"s\":10,\"n\":1000}]', '1');
INSERT INTO `s_fund` VALUES ('11', '250', '13500000', '[{\"s\":8,\"n\":30},{\"s\":10,\"n\":2000}]', '1');

DROP TABLE IF EXISTS `s_herocard_common_drop`;
CREATE TABLE `s_herocard_common_drop` (
  `id` int(11) NOT NULL,
  `star` int(11) DEFAULT '0' COMMENT '星级',
  `cardid` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `s_herocard_common_drop` VALUES ('1', '1', '1008', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('2', '1', '1015', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('3', '1', '1016', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('4', '1', '1037', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('5', '2', '1004', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('6', '2', '1009', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('7', '2', '1014', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('8', '2', '1020', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('9', '2', '1022', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('10', '2', '1026', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('11', '2', '1029', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('12', '2', '1033', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('13', '3', '1003', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('14', '3', '1007', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('15', '3', '1012', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('16', '3', '1018', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('17', '3', '1021', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('18', '3', '1023', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('19', '3', '1032', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('20', '3', '1036', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('21', '4', '1002', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('22', '4', '1005', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('23', '4', '1010', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('24', '4', '1011', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('25', '4', '1013', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('26', '4', '1017', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('27', '4', '1024', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('28', '4', '1025', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('29', '4', '1028', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('30', '4', '1031', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('31', '4', '1035', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('32', '5', '1001', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('33', '5', '1006', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('34', '5', '1019', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('35', '5', '1027', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('36', '5', '1030', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('37', '5', '1034', '320');