-- 新增一个数据表，记录碎片记录
DROP TABLE IF EXISTS `d_chips_wheel_record`;
CREATE TABLE `d_chips_wheel_record` (
    `id` int(11) PRIMARY KEY AUTO_INCREMENT,
    `uid`  int(11) NOT NULL COMMENT 'uid',
    `count` int(11) NOT NULL COMMENT '消耗碎片数',
    `detail` text NOT NULL COMMENT '消耗明细(json)',
    `result` text NOT NULL COMMENT '转盘结果(json)',
    `create_time` int(11) NOT NULL COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户碎片转盘记录明细';
