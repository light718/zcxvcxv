-- ----------------------------
-- Table structure for d_friend
-- ----------------------------
DROP TABLE IF EXISTS `d_friend`;
CREATE TABLE `d_friend`  (
  `uid` int(11) NOT NULL,
  `friend_uid` int(11) NOT NULL,
  `present_time` int(11) NOT NULL DEFAULT 0,
  `hastake` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`, `friend_uid`) USING BTREE,
  INDEX `friend_uid`(`friend_uid`) USING BTREE
) ENGINE = InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Table structure for d_friend_jackpot
-- ----------------------------
DROP TABLE IF EXISTS `d_friend_jackpot`;
CREATE TABLE `d_friend_jackpot`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `friend_uid` int(11) NOT NULL,
  `betIndex` int(11) NOT NULL,
  `mult` int(11) NOT NULL,
  `hastake` tinyint(1) NOT NULL DEFAULT 0,
  `present_time` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid_friend_uid`(`uid`, `friend_uid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
