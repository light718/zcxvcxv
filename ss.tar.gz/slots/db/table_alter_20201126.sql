ALTER TABLE `coin_log` 
MODIFY COLUMN `before_coin` decimal(30, 2) NOT NULL DEFAULT 0.0000 COMMENT '变动前分数' AFTER `game_id`,
MODIFY COLUMN `coin` decimal(30, 2) NOT NULL DEFAULT 0.0000 COMMENT '变动分数' AFTER `before_coin`,
MODIFY COLUMN `after_coin` decimal(30, 2) NOT NULL DEFAULT 0.0000 COMMENT '变动后分数' AFTER `coin`;

update s_game set jp_unlock_lv='[4,6,9,15,12]' where id=455;
update s_config set v=1000000 where k='initcoin';
update s_config set v=1.2 where k='rateNum';