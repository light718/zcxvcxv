-- 更新卡牌配置

-- 更改升星所需碎片
update s_herocard_star set need_chips=60 where star=1;
update s_herocard_star set need_chips=80 where star=2;
update s_herocard_star set need_chips=90 where star=3;
update s_herocard_star set need_chips=100 where star=4;
update s_herocard_star set need_chips=120 where star=5;

-- 解锁碎片统一改成40张
update s_herocard set unlock_chips=40 where unlock_chips is not null;
