DROP TABLE IF EXISTS `d_chat`;
CREATE TABLE `d_chat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `stype` tinyint(1) DEFAULT '1' COMMENT '聊天类型',
  `create_time` int(11) DEFAULT '0',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`) USING BTREE,
  KEY `idx_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='世界聊天';