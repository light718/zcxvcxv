-- ----------------------------
-- Table structure for d_club
-- ----------------------------
DROP TABLE IF EXISTS `d_club`;
CREATE TABLE `d_club` (
  `id` bigint(11) NOT NULL DEFAULT '0' COMMENT '俱乐部id',
  `data` mediumtext COMMENT 'json数据',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户邮票表';

-- ----------------------------
-- Table structure for d_club_reward
-- ----------------------------
DROP TABLE IF EXISTS `d_club_reward`;
CREATE TABLE `d_club_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `club_id` bigint(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` tinyint(3) NOT NULL DEFAULT '1',
  `betIndex` int(11) NOT NULL DEFAULT '1',
  `mult` int(11) NOT NULL DEFAULT '1',
  `present_time` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `club_id` (`club_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4289 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for s_club_task
-- ----------------------------
DROP TABLE IF EXISTS `s_club_task`;
CREATE TABLE `s_club_task` (
  `id` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  `param1` int(11) DEFAULT NULL,
  `param2` int(11) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `rewardid` int(11) NOT NULL DEFAULT '0',
  `rewardnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of s_club_task
-- ----------------------------
BEGIN;
INSERT INTO `s_club_task` VALUES (1, 1, NULL, NULL, 5000, 1, 20000);
INSERT INTO `s_club_task` VALUES (2, 4, NULL, NULL, 1000000000, 1, 50000);
INSERT INTO `s_club_task` VALUES (3, 2, 1, NULL, 50, 1, 80000);
INSERT INTO `s_club_task` VALUES (4, 2, 2, NULL, 20, 1, 100000);
INSERT INTO `s_club_task` VALUES (5, 1, 1, NULL, 300, 1, 120000);
INSERT INTO `s_club_task` VALUES (6, 5, 100, NULL, 10, 1, 150000);
INSERT INTO `s_club_task` VALUES (7, 3, NULL, NULL, 2000000000, 1, 200000);
COMMIT;

ALTER TABLE `d_user` ADD COLUMN `clubdata` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '俱乐部json数据' AFTER `ginlamicount`;
