--new
update s_game set gametag = 2, `level`=0 where id in (616,615);

--hot
update s_game set gametag = 1, `level`=0 where id in (614,624);


-- hot
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=614&type=2&ord=1'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=624&type=2&ord=3'

-- new
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=615&type=2&ord=2'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=616&type=2&ord=4'