-- 将所有换皮游戏，id从600开始

--  Zeus - King of Universe 宙斯-宇宙之王
update s_sess set gameid = 601 where gameid = 492;
update s_game set id = 601 where id = 492;
update s_game_type set gameid = 601 where gameid = 492;

--  Athena - Goddess of Wisdom  雅典娜-智慧女神
update s_sess set gameid = 602 where gameid = 498;
update s_game set id = 602 where id = 498;
update s_game_type set gameid = 602 where gameid = 498;

--  Poseidon - God of the Sea   海神波塞冬
update s_sess set gameid = 603 where gameid = 497;
update s_game set id = 603 where id = 497;
update s_game_type set gameid = 603 where gameid = 497;

--  RISING MEDUSH  崛起的美杜莎
update s_sess set gameid = 604 where gameid = 496;
update s_game set id = 604 where id = 496;
update s_game_type set gameid = 604 where gameid = 496;

--  Aphrodite - Goddess of Love and Beauty 阿尔忒弥斯-爱与美的女神
update s_sess set gameid = 605 where gameid = 495;
update s_game set id = 605 where id = 495;
update s_game_type set gameid = 605 where gameid = 495;

--  HEROIC COLLECTION 无所畏惧的舰娘
update s_sess set gameid = 606 where gameid = 494;
update s_game set id = 606 where id = 494;
update s_game_type set gameid = 606 where gameid = 494;

-- QUICK-WITTED COLLECTION 古灵精怪的舰娘 
update s_sess set gameid = 607 where gameid = 493;
update s_game set id = 607 where id = 493;
update s_game_type set gameid = 607 where gameid = 493;


