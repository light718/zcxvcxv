-- 修改蒙面英雄解锁等级
update `s_game` set `jp_unlock_lv` = '[2,5,8,11,14]' where id = 477;
