update s_game set gametag=0 where id in (select gameid from s_game_type where gametype=2);
update s_game_type set `taghot`=0 where  taghot>0;
-- new
update s_game set gametag = 2, `level`=0 where id in (488,484,450);
-- hot
update s_game set gametag = 1, `level`=0 where id in (458,437,419);

update s_game set `level`=5 where id = 493;
update s_game set `level`=10 where id = 479;
update s_game set `level`=15 where id = 489;
update s_game set `level`=20 where id = 490;
update s_game set `level`=25 where id = 443;
update s_game set `level`=30 where id = 487;
update s_game set `level`=35 where id = 449;
update s_game set `level`=40 where id = 492;
update s_game set `level`=45 where id = 475;
update s_game set `level`=50 where id = 480;
update s_game set `level`=55 where id = 483;
update s_game set `level`=60 where id = 482;
update s_game set `level`=65 where id = 428;
update s_game set `level`=70 where id = 425;
update s_game set `level`=75 where id = 433;
update s_game set `level`=80 where id = 420;
update s_game set `level`=85 where id = 469;
update s_game set `level`=90 where id = 446;
update s_game set `level`=95 where id = 466;
update s_game set `level`=100 where id = 452;
update s_game set `level`=105 where id = 422;
update s_game set `level`=110 where id = 459;
update s_game set `level`=115 where id = 473;
update s_game set `level`=120 where id = 477;
update s_game set `level`=125 where id = 481;
update s_game set `level`=130 where id = 478;
update s_game set `level`=135 where id = 476;
update s_game set `level`=140 where id = 448;
update s_game set `level`=145 where id = 474;
update s_game set `level`=150 where id = 472;
update s_game set `level`=155 where id = 462;
update s_game set `level`=160 where id = 454;
update s_game set `level`=165 where id = 468;
update s_game set `level`=170 where id = 423;
update s_game set `level`=175 where id = 441;
update s_game set `level`=180 where id = 460;
update s_game set `level`=185 where id = 434;
update s_game set `level`=190 where id = 455;
update s_game set `level`=195 where id = 471;
update s_game set `level`=200 where id = 432;
update s_game set `level`=205 where id = 427;
update s_game set `level`=210 where id = 461;
update s_game set `level`=215 where id = 464;
update s_game set `level`=220 where id = 470;
update s_game set `level`=225 where id = 463;
update s_game set `level`=230 where id = 421;
update s_game set `level`=235 where id = 481;
update s_game set `level`=240 where id = 436;
update s_game set `level`=245 where id = 451;
update s_game set `level`=250 where id = 440;
update s_game set `level`=255 where id = 442;
update s_game set `level`=260 where id = 465;
update s_game set `level`=265 where id = 439;
update s_game set `level`=270 where id = 424;
update s_game set `level`=275 where id = 467;
update s_game set `level`=280 where id = 435;
update s_game set `level`=285 where id = 453;
update s_game set `level`=290 where id = 447;
update s_game set `level`=295 where id = 429;


update s_game_type set `hot`=7 where  gameid = 493;
update s_game_type set `hot`=8 where  gameid = 479;
update s_game_type set `hot`=10 where  gameid = 489;
update s_game_type set `hot`=13 where  gameid = 490;
update s_game_type set `hot`=14 where  gameid = 443;
update s_game_type set `hot`=15 where  gameid = 487;
update s_game_type set `hot`=16 where  gameid = 449;
update s_game_type set `hot`=18 where  gameid = 492;
update s_game_type set `hot`=19 where  gameid = 475;
update s_game_type set `hot`=20 where  gameid = 480;
update s_game_type set `hot`=25 where  gameid = 483;
update s_game_type set `hot`=30 where  gameid = 482;
update s_game_type set `hot`=35 where  gameid = 428;
update s_game_type set `hot`=40 where  gameid = 425;
update s_game_type set `hot`=45 where  gameid = 433;
update s_game_type set `hot`=50 where  gameid = 420;
update s_game_type set `hot`=55 where  gameid = 469;
update s_game_type set `hot`=60 where  gameid = 446;
update s_game_type set `hot`=65 where  gameid = 466;
update s_game_type set `hot`=70 where  gameid = 452;
update s_game_type set `hot`=75 where  gameid = 422;
update s_game_type set `hot`=80 where  gameid = 459;
update s_game_type set `hot`=85 where  gameid = 473;
update s_game_type set `hot`=90 where  gameid = 477;
update s_game_type set `hot`=95 where  gameid = 481;
update s_game_type set `hot`=100 where  gameid = 478;
update s_game_type set `hot`=105 where  gameid = 476;
update s_game_type set `hot`=110 where  gameid = 448;
update s_game_type set `hot`=115 where  gameid = 474;
update s_game_type set `hot`=120 where  gameid = 472;
update s_game_type set `hot`=125 where  gameid = 462;
update s_game_type set `hot`=130 where  gameid = 454;
update s_game_type set `hot`=135 where  gameid = 468;
update s_game_type set `hot`=140 where  gameid = 423;
update s_game_type set `hot`=145 where  gameid = 441;
update s_game_type set `hot`=150 where  gameid = 460;
update s_game_type set `hot`=155 where  gameid = 434;
update s_game_type set `hot`=160 where  gameid = 455;
update s_game_type set `hot`=165 where  gameid = 471;
update s_game_type set `hot`=170 where  gameid = 432;
update s_game_type set `hot`=175 where  gameid = 427;
update s_game_type set `hot`=180 where  gameid = 461;
update s_game_type set `hot`=185 where  gameid = 464;
update s_game_type set `hot`=190 where  gameid = 470;
update s_game_type set `hot`=195 where  gameid = 463;
update s_game_type set `hot`=200 where  gameid = 421;
update s_game_type set `hot`=205 where  gameid = 481;
update s_game_type set `hot`=210 where  gameid = 436;
update s_game_type set `hot`=215 where  gameid = 451;
update s_game_type set `hot`=220 where  gameid = 440;
update s_game_type set `hot`=225 where  gameid = 442;
update s_game_type set `hot`=230 where  gameid = 465;
update s_game_type set `hot`=235 where  gameid = 439;
update s_game_type set `hot`=240 where  gameid = 424;
update s_game_type set `hot`=245 where  gameid = 467;
update s_game_type set `hot`=250 where  gameid = 435;
update s_game_type set `hot`=255 where  gameid = 453;
update s_game_type set `hot`=260 where  gameid = 447;
update s_game_type set `hot`=265 where  gameid = 429;

curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=458&type=2&ord=1'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=437&type=2&ord=3'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=419&type=2&ord=5'

curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=488&type=2&ord=2'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=484&type=2&ord=4'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=450&type=2&ord=6'