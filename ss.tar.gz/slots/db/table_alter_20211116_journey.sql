-- 新游戏
CREATE TABLE `d_journey_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT 0 COMMENT '用户uid',
  `point` int(11) DEFAULT 0 COMMENT '已收集到的点数',
  `position` int(11) DEFAULT 0 COMMENT '所在位置',
  `start_time` int(11) DEFAULT 1 COMMENT '开始时间(方便区分redis中数据的新旧)',
  `round_id` int(11) DEFAULT 1 COMMENT '当前轮次',
  `buff` int(11) DEFAULT 0  COMMENT '购买礼包',
  `is_new` int(11) DEFAULT 0 COMMENT '是否新用户',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='游戏记录获取表';