-- 跟现有卡牌数据添加need_exp字段
ALTER TABLE d_herocard ADD need_exp INT DEFAULT 0 AFTER `exp`;
-- 在每个卡牌上添加一个成就领取记录
ALTER TABLE d_herocard ADD gain_task VARCHAR(128) DEFAULT '' AFTER `need_exp`;

-- 在用户表里面加一个字段，表示集卡成就领取记录
ALTER TABLE d_user ADD gain_herocard_task VARCHAR(128) DEFAULT '';

-- 更新现有卡牌，将need_exp设置成正确数值
UPDATE d_herocard a
INNER JOIN
(
    select 
        a.uid,
        a.cardid,
        c.need_exp
    from d_herocard a 
    left join s_herocard b 
        on a.cardid = b.cardid 
    left join s_herocard_level c
        on b.rarity = c.rarity and a.lv + 1 = c.level
    where a.lv > 0
) b 
ON a.uid = b.uid and a.cardid = b.cardid
SET a.need_exp = b.need_exp;