ALTER TABLE `d_user` MODIFY COLUMN `login_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '登录ip' AFTER `login_time`;
-- cash tonoda
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (496, "魔法球", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(496, "magicorb", 0, 0.1, 0.1, '[10,20,200,2000]', '[1,3,6,9]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 496, "魔法球", 1, 100);