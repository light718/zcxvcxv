
update s_shop set stamppropid = 100013, stamppropnum = 1 where stype = 1 and status = 1 and amount = 1.99;
update s_shop set stamppropid = 100023, stamppropnum = 1 where stype = 1 and status = 1 and amount = 2.99;
update s_shop set stamppropid = 100033, stamppropnum = 2 where stype = 1 and status = 1 and amount = 4.99;
update s_shop set stamppropid = 100043, stamppropnum = 2 where stype = 1 and status = 1 and amount = 9.99;
update s_shop set stamppropid = 100053, stamppropnum = 3 where stype = 1 and status = 1 and amount = 19.99;
update s_shop set stamppropid = 100053, stamppropnum = 4 where stype = 1 and status = 1 and amount = 49.99;
