update s_game set jackpot='[5,10,17,167,33]',jp_unlock_lv='[4,6,9,12,15]' where id =451;
UPDATE s_game SET jackpot = '[15,60,500,5000,1000,2500]' WHERE id = 425;

ALTER TABLE `d_statistics` ADD COLUMN `gameid` int(11) NULL DEFAULT 0 COMMENT '游戏id' AFTER `ts`,ADD COLUMN `menu` tinyint(1) NULL DEFAULT 0 COMMENT '菜单id' AFTER `gameid`, ADD COLUMN `itemid` int(11) NULL DEFAULT 0 COMMENT '对象id' AFTER `menu`;