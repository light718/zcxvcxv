
-- 在每个卡牌上添加一个状态字段
ALTER TABLE d_herocard ADD st int(4) DEFAULT 0 AFTER `gain_task`;
