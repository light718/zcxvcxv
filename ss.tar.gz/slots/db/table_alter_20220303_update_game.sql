-- 辛巴达jackpot修改，去掉最高位
UPDATE `s_game` SET `jackpot` = '[5,10,15,20,30,50,100,150,200,300]', `jp_unlock_lv`='[1,1,1,1,1,1,1,1,1,1]' WHERE id = 696;