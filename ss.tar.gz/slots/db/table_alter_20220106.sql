ALTER TABLE `d_chat_user`
ADD COLUMN `endtime`  int(11) NULL DEFAULT 0 AFTER `received`;

ALTER TABLE `d_chat_user`
ADD COLUMN `cardid`  int(11) NULL DEFAULT 0 AFTER `endtime`;