-- 更新每日任务的描述
UPDATE `s_quest` set `descr`="Spin 30 times." WHERE id=1;
UPDATE `s_quest` set `descr`="Win a total of 500k coins." WHERE id=2;
UPDATE `s_quest` set `descr`="Get 3 big wins." WHERE id=3;
UPDATE `s_quest` set `descr`="Bet a total of 1M Coins." WHERE id=4;
UPDATE `s_quest` set `descr`="Get 2 huge wins." WHERE id=5;
UPDATE `s_quest` set `descr`="Bet a total of 5M Coins." WHERE id=6;
commit;