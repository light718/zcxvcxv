ALTER TABLE `d_user` ADD COLUMN `points`  bigint(20) NULL DEFAULT 0 COMMENT '富豪厅积分' AFTER `coin`;

-- source table_alter_20210727_config_level_bet.sql
-- source table_alter_20210727_config_level_upgrade.sql
-- source table_alter_20210727_config_level_sess.sql

ALTER TABLE `d_user_login_log` ADD COLUMN `ip`  varbinary(16) NULL COMMENT 'ip' AFTER `coin`, ADD COLUMN `appid`  tinyint(2) NULL DEFAULT 5 COMMENT '渠道包id' AFTER `ip`;


CREATE TABLE `d_user_palace_log` (
    `id`  bigint(20) NOT NULL ,
    `uid`  int(11) NULL ,
    `stype`  varchar(30) NULL ,
    `points`  int(11) NULL ,
    `create_time`  int(11) NULL ,
    PRIMARY KEY (`id`),
    INDEX `idx_uid` (`uid`, `create_time`) 
) COMMENT='用户富豪厅点数记录';

ALTER TABLE `d_user_palace_log` MODIFY COLUMN `id`  bigint(20) NOT NULL AUTO_INCREMENT FIRST ;