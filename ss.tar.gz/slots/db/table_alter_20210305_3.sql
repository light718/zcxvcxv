-- 第一组换皮游戏

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (608, "灭世魔狼", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(608, "destructivedemonwolf", 0, 0.1, 0.1, '[5,10,625,1250,5000]', '[4,6,9,12,16]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 608, "灭世魔狼", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (609, "贞德传奇", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(609, "legendofjoanofarc", 0, 0.1, 0.1, '[5,10,100,1000]', '[4,6,9,16]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 609, "贞德传奇", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (610, "凯撒大帝", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(610, "lordcaesar", 0, 0.1, 0.1, '[10,40,100,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 610, "凯撒大帝", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (611, "雷神", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(611, "lordofthunder", 0, 0.1, 0.1, '[3,8,140,500,5000]', '[4,6,9,16,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 611, "雷神", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (612, "冥海女神", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(612, "goddessofdeath", 0, 0.1, 0.1, '[10,50,500,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 612, "冥海女神", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (613, "精灵的祝福", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(613, "elvesblessing", 0, 0.1, 0.1, '[10,200,1000,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 613, "精灵的祝福", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (614, "奥丁的愤怒", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(614, "odinsanger", 0, 0.1, 0.1, '[5,100,1000,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 614, "奥丁的愤怒", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (615, "圆桌骑士的探索", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(615, "theroundtableknightsexplore", 0, 0.1, 0.1, '[10,25,100,1000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 615, "圆桌骑士的探索", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (616, "绚丽的埃及艳后", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(616, "gorgeouscleopatra", 0, 0.1, 0.1, '[10,20,200,1000,5000]', '[4,6,9,12,16]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 616, "绚丽的埃及艳后", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (617, "邪恶者", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(617, "theevil", 0, 0.1, 0.1, '[5,25,300,10000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 617, "邪恶者", 1, 100);