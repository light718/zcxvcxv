update `d_user` set usericon = replace(`usericon`,'jp.inter.rummyslot.com','inter.spinxstudio.com') where usericon like '%jp.inter.rummyslot.com%';

update d_robot set img=replace(img, 'jp.inter.rummyslot.com','inter.spinxstudio.com') where img like '%jp.inter.rummyslot.com%';