UPDATE `s_bingo_reward` SET `rewards`="1:2450000|2:10" WHERE `type`=1 AND `section_id`=1 AND `order_id`=1;
UPDATE `s_bingo_reward` SET `rewards`="1:2840000|2:10" WHERE `type`=1 AND `section_id`=1 AND `order_id`=2;
UPDATE `s_bingo_reward` SET `rewards`="1:3360000|2:10" WHERE `type`=1 AND `section_id`=1 AND `order_id`=3;
UPDATE `s_bingo_reward` SET `rewards`="1:3780000|3:1" WHERE `type`=1 AND `section_id`=2 AND `order_id`=1;
UPDATE `s_bingo_reward` SET `rewards`="1:4000000|3:1" WHERE `type`=1 AND `section_id`=2 AND `order_id`=2;
UPDATE `s_bingo_reward` SET `rewards`="1:4120000|3:1" WHERE `type`=1 AND `section_id`=2 AND `order_id`=3;
UPDATE `s_bingo_reward` SET `rewards`="1:4620000|8:1:2" WHERE `type`=1 AND `section_id`=3 AND `order_id`=1;
UPDATE `s_bingo_reward` SET `rewards`="1:5460000|8:1:2" WHERE `type`=1 AND `section_id`=3 AND `order_id`=2;
UPDATE `s_bingo_reward` SET `rewards`="1:6300000|8:1:2" WHERE `type`=1 AND `section_id`=3 AND `order_id`=3;

UPDATE `s_bingo_reward` SET `rewards`="1:13050000|2:10|8:1:4" WHERE `type`=2 AND `section_id`=0 AND `order_id`=0;

UPDATE `s_bingo_reward` SET `rewards`="1:7500000" WHERE `type`=3 AND `l_rank`=1;
UPDATE `s_bingo_reward` SET `rewards`="1:3000000" WHERE `type`=3 AND `l_rank`=2;
UPDATE `s_bingo_reward` SET `rewards`="1:1500000" WHERE `type`=3 AND `l_rank`=3;
UPDATE `s_bingo_reward` SET `rewards`="1:435000" WHERE `type`=3 AND `l_rank`=4;

