ALTER TABLE `d_club_reward` ADD COLUMN `game_id` int(11) NOT NULL default 0 COMMENT '游戏ID' AFTER `uid`;
