-- 新的任务系统，使用新的表

DROP TABLE IF EXISTS `s_new_quest`;
CREATE TABLE `s_new_quest` (
    `id` int(11) PRIMARY KEY AUTO_INCREMENT,
    `type`  int(11) NOT NULL COMMENT '类型, 1=日常任务, 2=周任务, 等等',
    `kind`  int(11) NOT NULL COMMENT '种类, 1=spin, 2=winCoin, 3=winSize, 4=chips, 等等',
    `detail` varchar(255) NULL COMMENT '任务详情，可带参数',
    `params`  varchar(255) NULL COMMENT '任务参数，用逗号隔开',
    `diamond` int(11) NOT NULL COMMENT '消耗钻石数',
    `prev_quest` int(11) NULL COMMENT '前置任务',
    `rewards` varchar(255) NOT NULL COMMENT '奖励数据',
    `jump_to`  int(11) NULL COMMENT '跳转'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务配置';

DROP TABLE IF EXISTS `d_new_quest`;
CREATE TABLE `d_new_quest` (
    `uid` int(11) NOT NULL AUTO_INCREMENT,
    `questid` int(11) NOT NULL COMMENT '任务id',
    `params`  varchar(255) NULL COMMENT '任务参数',
    `need`   int(11) NOT NULL COMMENT '需要的数量',
    `count`  int(11) NULL COMMENT '目前完成的数量',
    `state`   int(11) NOT NULL COMMENT '任务状态',
    `expire_time` int(11) NOT NULL COMMENT '失效时间',
    PRIMARY KEY (`uid`,`questid`),
    KEY `uid_idx` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务记录';

DROP TABLE IF EXISTS `s_new_activity_reward`;
CREATE TABLE `s_new_activity_reward` (
  `id` int(11) NOT NULL COMMENT '奖励id',
  `rid` int(11) NOT NULL COMMENT '奖励序号',
  `type` int(11) NOT NULL COMMENT '活跃度类型',
  `count` int(11) NOT NULL COMMENT '达标的活跃度',
  `rewards` varchar(255) NOT NULL COMMENT '奖励的物品, 类型:数量, 多个奖励分隔符分开, eg: 1:100|2:200',  -- 奖励的物品
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `d_new_activity`;
CREATE TABLE `d_new_activity` (
    `uid` int(11) NOT NULL COMMENT '玩家id',
    `type` int(11) NOT NULL COMMENT '活跃度类型',
    `expire_time` int(11) NOT NULL COMMENT '失效时间',
    `activity` int(8) NOT NULL COMMENT '当前活跃度',
    `obtain_rewards` varchar(255) NOT NULL COMMENT '已获得的奖励, 对应s_activity_reward中的rid，逗号分开eg: 1,2,3',
    PRIMARY KEY (`uid`,`type`),
    KEY `uid_idx` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='任务记录';

-- id, questid, type, kind, detail, params, diamond, prev_quest, rewards, jump_to
-- kind, 1=spin, 2=winCoin,3=bet, 4=winSize, 5=chips, 
-- 日任务
INSERT INTO `s_new_quest` VALUES (1,  1, 1, 'Spin 30 times.',              '30',      50,  null, '1:20000|6:10',  null);
INSERT INTO `s_new_quest` VALUES (2,  1, 5, 'Get 1 fragment.',             '1',       80,  1,    '1:50000|6:10',  null);
INSERT INTO `s_new_quest` VALUES (3,  1, 2, 'Win a total of 500k coins.',  '500000',  100, 2,    '1:80000|6:10',  null);
INSERT INTO `s_new_quest` VALUES (4,  1, 5, 'Get 3 fragments.',            '3',       120, 3,    '1:100000|6:10', null);
INSERT INTO `s_new_quest` VALUES (5,  1, 4, 'Get 3 big wins.',             '3,1',     140, 4,    '1:120000|6:10', null);
INSERT INTO `s_new_quest` VALUES (6,  1, 5, 'Get 5 fragments.',            '5',       160, 5,    '1:140000|6:10|13:1', null);
INSERT INTO `s_new_quest` VALUES (7,  1, 3, 'Bet a total of 1M Coins.',    '1000000', 180, 6,    '1:160000|6:10', null);
INSERT INTO `s_new_quest` VALUES (8,  1, 5, 'Get 7 fragments.',            '7',       200, 7,    '1:200000|6:10', null);
INSERT INTO `s_new_quest` VALUES (9,  1, 4, 'Get 2 huge wins.',            '2,2',     220, 8,    '1:300000|6:10|8:1', null);
INSERT INTO `s_new_quest` VALUES (10, 1, 5, 'Get 9 fragments.',            '9',       250, 9,    '1:400000|6:10', null);
INSERT INTO `s_new_quest` VALUES (11, 1, 3, 'Bet a total of 5M Coins.',    '5000000', 280, 10,   '1:500000|6:10|8:2', null);
INSERT INTO `s_new_quest` VALUES (12, 1, 5, 'Get 15 fragments.',           '15',      300, 11,   '1:600000|6:10|10:100', null);

-- 周任务
-- kind, 1=spin, 2=winCoin, 3=bet, 4=winSize, 5=chips,  6=scratch, 7=specialbet, 
-- 8=luckyflipcard, 9=spcialwin, 10=sharefb, 11=palace, 12=purchase, 13=unlockhero
INSERT INTO `s_new_quest` VALUES (21, 2, 6, 'Scratch&win 10 times.',             '10',         100, null, '1:200000|6:10',  null);
INSERT INTO `s_new_quest` VALUES (22, 2, 7, 'Bet %d in a single spin 40 times.', '40,200000',  100, null,    '1:400000|6:10|8:1',  null);
INSERT INTO `s_new_quest` VALUES (23, 2, 5, 'Get 80 fragments.',                 '80',         300, null,    '1:500000|6:10|10:100',  null);
INSERT INTO `s_new_quest` VALUES (24, 2, 8, 'Play lucky flipcard for 5 times.',  '5',          120, null,    '1:600000|6:10|8:2', null);
INSERT INTO `s_new_quest` VALUES (25, 2, 9, 'Win %d in a single spin 50 times.', '50,200000',  150, null,    '1:500000|6:10|2:50', null);
INSERT INTO `s_new_quest` VALUES (26, 2, 10, 'Share to Facebook for 5 days.',    '5',          200, null,    '1:600000|6:10|10:100', null);
INSERT INTO `s_new_quest` VALUES (27, 2, 11, 'Earn 1000 hero palace points.',    '1000',       200, null,    '1:600000|6:10|8:2', null);
INSERT INTO `s_new_quest` VALUES (28, 2, 1, 'Spin 2500 times.',                  '2500',       100, null,    '1:500000|6:10|8:2', null);
INSERT INTO `s_new_quest` VALUES (29, 2, 12, 'Make a purchase.',                 '1',          300, null,    '1:1000000|6:10|8:5', null);
INSERT INTO `s_new_quest` VALUES (30, 2, 13, 'Unlock or evolve 3 heroes.',       '3',          300, null,    '1:1500000|6:10|25:300', null);
INSERT INTO `s_new_quest` VALUES (31, 2, 2, 'Win a total of %d coins.',          '4000000',    250, null,   '1:1000000|6:10|10:200', null);
INSERT INTO `s_new_quest` VALUES (32, 2, 3, 'Bet a total of %d coins.',          '6000000',    250, null,   '1:1200000|6:10|2:200', null);

-- 日活跃度奖励
-- id, rid, type, count, rewards
INSERT INTO `s_new_activity_reward` VALUES (1, 1, 1, 20, '1:100000');
INSERT INTO `s_new_activity_reward` VALUES (2, 2, 1, 40, '1:150000');
INSERT INTO `s_new_activity_reward` VALUES (3, 3, 1, 60, '1:200000');
INSERT INTO `s_new_activity_reward` VALUES (4, 4, 1, 80, '1:300000');
INSERT INTO `s_new_activity_reward` VALUES (5, 5, 1, 100, '10:100');

-- 周活跃度奖励
INSERT INTO `s_new_activity_reward` VALUES (11, 1, 2, 20, '1:100000');
INSERT INTO `s_new_activity_reward` VALUES (12, 2, 2, 40, '1:150000');
INSERT INTO `s_new_activity_reward` VALUES (13, 3, 2, 60, '1:200000');
INSERT INTO `s_new_activity_reward` VALUES (14, 4, 2, 80, '1:300000');
INSERT INTO `s_new_activity_reward` VALUES (15, 5, 2, 100, '10:500');