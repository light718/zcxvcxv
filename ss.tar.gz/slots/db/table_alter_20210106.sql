ALTER TABLE `d_friend` DROP COLUMN `hastake`;

ALTER TABLE `d_friend_jackpot` 
ADD COLUMN `type` tinyint(3) NOT NULL DEFAULT 1 AFTER `friend_uid`;
rename table d_friend_jackpot to d_friend_reward;