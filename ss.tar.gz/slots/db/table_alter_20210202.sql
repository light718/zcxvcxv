replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (485, "舞蹈嘉年华", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(485, "dancingcarnival", 0, 0.1, 0.1, '[10,50,100,650,2000,5000]', '[4,6,8,10,12,14]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 485, "舞蹈嘉年华 ", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (486, "现金穆拉", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(486, "cashmoolah", 0, 0.1, 0.1, '[5,15,100,1000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 486, "现金穆拉 ", 1, 100);