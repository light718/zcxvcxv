-- 447  珍宝丛林  treasurejungle  minor, major, grand
UPDATE `s_game` SET `jackpot` = '[10,200,5000]' WHERE id = 447;