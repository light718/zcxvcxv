-- 咆哮的月亮 Howling Moon
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (513, "咆哮的月亮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(513, "howlingmoon", 0, 0.1, 0.1, '[8,20,200,1000]', '[1,3,6,9]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 513, "咆哮的月亮", 1, 100);