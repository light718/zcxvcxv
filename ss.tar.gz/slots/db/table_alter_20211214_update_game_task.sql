-- 任务内容调整
update s_game_task_detail set `value`=15 where taskid=3 and roundid=1 and detailid=1;
update s_game_task_detail set `value`=25 where taskid=4 and roundid=1 and detailid=1;
update s_game_task_detail set `value`=50 where taskid=6 and roundid=1 and detailid=1;
