DROP TABLE IF EXISTS `s_sign_pack`;
CREATE TABLE `s_sign_pack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` int(11) DEFAULT '0' COMMENT '累计签到天数',
  `prize` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '奖品',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `s_sign_pack` VALUES ('1', '8', '[{\"s\":1,\"n\":4200000},{\"s\":2,\"n\":40},{\"s\":3,\"n\":14400}]');
INSERT INTO `s_sign_pack` VALUES ('2', '15', '[{\"s\":1,\"n\":8400000},{\"s\":3,\"n\":14400},{\"s\":9,\"n\":5}]');
INSERT INTO `s_sign_pack` VALUES ('3', '22', '[{\"s\":1,\"n\":12600000},{\"s\":2,\"n\":50},{\"s\":3,\"n\":21600}]');
INSERT INTO `s_sign_pack` VALUES ('4', '30', '[{\"s\":1,\"n\":16800000},{\"s\":9,\"n\":5},{\"s\":8,\"n\":5}]');