-- 更新vip权益配置
-- 只改了刮刮乐，商城每日赠送，
TRUNCATE TABLE `s_config_vip_upgrade`;
INSERT INTO `s_config_vip_upgrade` VALUES 
(1,1,100,'{\"scratch\":0.1,\"store\":1,\"maxfriends\":15, \"inboxcollect\":0,\"turntable\":0.1}'),
(2,2,1000,'{\"scratch\":0.15,\"store\":2,\"maxfriends\":20, \"inboxcollect\":0,\"turntable\":0.25}'),
(3,3,10000,'{\"scratch\":0.3,\"store\":4,\"maxfriends\":25, \"inboxcollect\":1,\"turntable\":0.5}'),
(4,4,20000,'{\"scratch\":0.5,\"store\":6,\"maxfriends\":30, \"inboxcollect\":1,\"turntable\":1}'),
(5,5,40000,'{\"scratch\":0.6,\"store\":7,\"maxfriends\":35, \"inboxcollect\":1,\"turntable\":2}'),
(6,6,60000,'{\"scratch\":0.8,\"store\":10,\"maxfriends\":40, \"inboxcollect\":1,\"turntable\":3}'),
(7,7,100000,'{\"scratch\":1,\"store\":12,\"maxfriends\":45, \"inboxcollect\":1,\"turntable\":4}'),
(8,0,0,'{\"scratch\":0,\"store\":0,\"maxfriends\":10, \"inboxcollect\":0,\"turntable\":0}');