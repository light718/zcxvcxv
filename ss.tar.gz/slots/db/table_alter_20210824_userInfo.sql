-- 跟现有user表中增加fb_icon字段，用来存储fb的头像
ALTER TABLE d_user ADD fb_icon VARCHAR(255) DEFAULT NULL AFTER `usericon`;

-- 更新现有信息，存储fb头像
UPDATE d_user SET fb_icon = usericon WHERE isbindfb = 1;