-- 更改石器时代的彩金倍率
update s_game set jackpot='[10,25,250,5000]' where id=489;