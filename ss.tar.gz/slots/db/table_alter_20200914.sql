delete from `s_sess` where gameid >= 446 and gameid <= 463;
delete from `s_game` where id >= 446 and id <= 463;
delete from `s_game_type` where gameid >= 446 and gameid <= 463;

-- 国洋
-- 446  宾果猫  bingomeow
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (446, "宾果猫", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(446, "bingomeow", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 446, "446", 1, 100);

-- 447  珍宝丛林  treasurejungle
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (447, "珍宝丛林", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(447, "treasurejungle", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 447, "珍宝丛林", 1, 100);

-- 448 圣诞老人在哪里 whereisthesantaclaus
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (448, "圣诞老人在哪里", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(448, "whereisthesantaclaus", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 448, "圣诞老人在哪里", 1, 100);

-- 449 青蛙王子  princecharming
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (449, "青蛙王子", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(449, "princecharming", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 449, "青蛙王子", 1, 100);

-- 450 皇家小犬  royalpuppies
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (450, "皇家小犬", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(450, "royalpuppies", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 450, "皇家小犬", 1, 100);

-- 451 大功率  highpower
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (451, "大功率", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(451, "highpower", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 451, "大功率", 1, 100);


-- 意哥
-- 452 啤酒馆 miasbearhallmia
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (452, "啤酒馆", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(452, "miasbearhallmia", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 452, "啤酒馆", 1, 100);

-- 453 泰山 jungleking
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (453, "泰山", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(453, "jungleking", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 453, "泰山", 1, 100);

-- 454 来开派对 letisparty
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (454, "来开派对", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(454, "gorgeouscleopatra", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 454, "来开派对", 1, 100);

-- 455 宇航员 adventuresinspace
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (455, "宇航员", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(455, "adventuresinspace", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 455, "宇航员", 1, 100);

-- 456 鼠年 yearoftherat
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (456, "鼠年", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(456, "yearoftherat", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 456, "鼠年", 1, 100);

-- 457 野生澳大利亚 wildaustralia
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (457, "野生澳大利亚", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(457, "wildaustralia", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 457, "野生澳大利亚", 1, 100);


-- 旭哥
-- 458 小恶魔 superwickedblast
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (458, "小恶魔", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(458, "superwickedblast", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 458, "小恶魔", 1, 100);

-- 459 美杜莎 risingmedusa 
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (459, "美杜莎", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(459, "risingmedusa", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 459, "美杜莎", 1, 100);

-- 460 财富宫 fortunegong
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (460, "财富宫", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(460, "fortunegong", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 460, "财富宫", 1, 100);

-- 461 命运之轮豪华车 fortunewheeldeluxe
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (461, "命运之轮豪华车", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(461, "fortunewheeldeluxe", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 461, "命运之轮豪华车", 1, 100);

-- 462 埃及的幻想 egyptianfantasy
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (462, "埃及的幻想", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(462, "egyptianfantasy", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 462, "埃及的幻想", 1, 100);

-- 463 马戏嘉年华 circuscarnival
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (463, "马戏嘉年华", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(463, "circuscarnival", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 463, "马戏嘉年华", 1, 100);