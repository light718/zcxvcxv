ALTER TABLE `d_bankrupt_log` ADD COLUMN `gameid` int(11) NULL COMMENT '游戏id' AFTER `create_time`;

insert into s_config(k,v,memo) value('offlineawards','{"maxcoin":1500000,"interval":7200,"base":500,"maxtime":172800}','离线金币奖励配置');

update s_shop set productid_gp='com.rummyfree.11',amount=12.99 where stype=13;