DROP TABLE IF EXISTS `s_egg`;
CREATE TABLE `s_egg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT '0' COMMENT '开启等级',
  `type` tinyint(1) DEFAULT NULL COMMENT '1银蛋 2金蛋',
  `rewards` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '奖励, 格式: 类型:数量|类型:数量, eg: 1:200000|2:50',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='蛋蛋配置';

INSERT INTO `s_egg` VALUES (1, 20, 1, '1:200000|7:50|8:1');
INSERT INTO `s_egg` VALUES (2, 20, 2, '1:500000|2:50|7:50|8:1|3:2');

DROP TABLE IF EXISTS `d_egg_record`;
CREATE TABLE `d_egg_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0' COMMENT '用户uid',
  `type` tinyint(2) DEFAULT '1' COMMENT '1银锤子 2金锤子',
  `status` tinyint(2) DEFAULT '1' COMMENT '1未砸 2已砸',
  `orderId` tinyint(4) DEFAULT '1' COMMENT '蛋的序号，一共有7个蛋',
  `create_time` int(11) DEFAULT '0' COMMENT '获取时间',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='锤子记录获取表';