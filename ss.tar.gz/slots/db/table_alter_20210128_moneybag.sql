update `s_config` set v = '{"bag":750000, "maxmul":3, "addrate":0.15,"probability":0.25, "bonus":3000000}' where k = 'moneybag';
