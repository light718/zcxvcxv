ALTER TABLE `d_user` 
MODIFY COLUMN `from_channel` int(11) NULL DEFAULT NULL COMMENT '注册登录方式' AFTER `code`;