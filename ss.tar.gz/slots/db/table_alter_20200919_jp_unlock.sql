ALTER TABLE `s_game` ADD COLUMN `jp_unlock_lv` varchar(255) default '[4,6,9,12]' COMMENT 'Slots奖池解锁等级,前4个值分别表示mini,minor,major,grand的解锁等级,如果有自定义奖池,数组向后扩展';

UPDATE `s_game` SET `jp_unlock_lv` = '[4,6,9,12,15]' WHERE id IN(420,437,438,443,446,447,451,453,455,459,462,463);
UPDATE `s_game` SET `jp_unlock_lv` = '[4,6,9,12,15,18]' WHERE id IN(429,433,434,442);
UPDATE `s_game` SET `jp_unlock_lv` = '[1,1,1,1,1,1,1,1,1,1,1]' WHERE id IN(441);

