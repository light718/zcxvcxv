replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (427, "传统的邦妮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(427, "thelegarybonieclyde", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 427, "传统的邦妮", 1, 100);