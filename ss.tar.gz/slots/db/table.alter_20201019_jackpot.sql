
-- 440 苏轼的情人 sushilover   mini, major, grand,
UPDATE `s_game` SET `jackpot` = '[10,500,5000]' WHERE id = 440;

