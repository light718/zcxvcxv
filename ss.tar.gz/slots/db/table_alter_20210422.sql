-- 426改名，从杰克猫改成猫火枪手
UPDATE `s_sess` set `title` = "猫火枪手" where `gameid` = 426;
UPDATE `s_game_type` set `title` = "猫火枪手" where `gameid` = 426;
commit;