-- 换皮游戏

-- 641 源义经 Minamoto no Yoshitsune
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    641, "源义经", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 489
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    641, "minamotonoyoshitsune", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 489;
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 641, "源义经", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 489
LIMIT 1;

-- 642 黑帮教父 Gangster Godfather
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    642, "黑帮教父", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 512
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    642, "gangstergodfather", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 512
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 642, "黑帮教父", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 512
LIMIT 1;


-- 643 洛基  Loki
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    643, "洛基", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 504
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    643, "loki", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 504
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 643, "洛基", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 504
LIMIT 1;

-- 644 弗雷  Frey
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    644, "弗雷", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 510
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    644, "frey", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 510
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 644, "弗雷", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 510
LIMIT 1;

-- 645 亚历山大  Alexander
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    645, "亚历山大", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 450
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    645, "alexander", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 450
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 645, "亚历山大", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 450
LIMIT 1;

-- 646 哈迪斯  Hades-King of Underworld
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    646, "哈迪斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 506;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    646, "hadesking", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 506;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 646, "哈迪斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 506;
