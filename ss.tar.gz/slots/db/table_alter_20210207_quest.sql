-- 更新任务系统, 增加活跃度奖励字段, 字段
ALTER TABLE `s_quest` ADD COLUMN `rewards` varchar(255) NOT NULL DEFAULT "" COMMENT '奖励的物品, 类型:数量, 多个奖励分隔符分开';
ALTER TABLE `s_quest` ADD COLUMN `jumpTo` varchar(255) NOT NULL DEFAULT "" COMMENT '任务跳转，透传字段，服务端不需要';

-- 更新任务系统，玩家任务数据里面，增加对应的奖励
ALTER TABLE `d_quest` ADD COLUMN `rewards` varchar(255) DEFAULT "" COMMENT '对应奖励的物品, 类型:数量, 多个奖励分隔符分开';
ALTER TABLE `d_quest` ADD COLUMN `jumpTo` varchar(255) NOT NULL DEFAULT "" COMMENT '任务跳转，透传字段，服务端不需要';

-- ----------------------------
-- Table structure for d_activity_record
-- ----------------------------
DROP TABLE IF EXISTS `d_activity`;
CREATE TABLE `d_activity` (
  `uid` int(11) NOT NULL,  -- 玩家id
  `expireTime` int(11) NOT NULL,  -- 失效时间
  `activity` int(8) NOT NULL,  -- 当前活跃度
  `obtainRewards` varchar(255) NOT NULL COMMENT '已获得的奖励, 对应s_activity_reward中的rid，逗号分开eg: 1,2,3',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for s_activity_reward
-- ----------------------------
DROP TABLE IF EXISTS `s_activity_reward`;
CREATE TABLE `s_activity_reward` (
  `id` int(11) NOT NULL,  -- 奖励id
  `activity` int(11) NOT NULL,  -- 达标的活跃度
  `rewards` varchar(255) NOT NULL COMMENT '奖励的物品, 类型:数量, 多个奖励分隔符分开, eg: 1:100|2:200',  -- 奖励的物品
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 物品 1: 金币， 2: 活跃度 3: 待定

-- 插入活跃度奖励数据
INSERT INTO `s_activity_reward` VALUES (1, 10, "1:100000");
INSERT INTO `s_activity_reward` VALUES (2, 80, "1:200000");
INSERT INTO `s_activity_reward` VALUES (3, 150, "1:400000");
INSERT INTO `s_activity_reward` VALUES (4, 220, "1:600000");
INSERT INTO `s_activity_reward` VALUES (5, 300, "1:2000000");

-- 插入每日任务奖励数据
-- icon: 1-spin 2-win 3-bet
update `s_quest` set `parm1`=30,`descr`='make 30 spins',`rewards`="1:20000|6:10",`icon`="1" where id = 1;
update `s_quest` set `parm1`=500000,`descr`='win a total of 500k coins',`rewards`="1:50000|6:10",`icon`="2" where id = 2;
update `s_quest` set `parm1`=3,`descr`='get 3 big wins',`rewards`="1:80000|6:10",`icon`="1" where id = 3;
update `s_quest` set `parm1`=1000000,`descr`='betting on chips over 1M',`rewards`="1:100000|6:10",`icon`="3" where id = 4;
update `s_quest` set `parm1`=2,`descr`='get 2 huge wins',`rewards`="1:120000|6:10",`icon`="1" where id = 5;
update `s_quest` set `parm1`=5000000,`descr`='betting on chips over 5M',`rewards`="1:150000|6:20",`icon`="3" where id = 6;