UPDATE `s_sess` set `title` = '花木兰' where `gameid` = 647;
UPDATE `s_game_type` set `title` = '花木兰' where `gameid` = 647;
UPDATE `s_game` set `title` = 'Mulan' where `id` = 647;

UPDATE `s_sess` set `title` = '德墨忒尔' where `gameid` = 668;
UPDATE `s_game_type` set `title` = '德墨忒尔' where `gameid` = 668;
UPDATE `s_game` set `title` = 'DemeterGooddes' where `id` = 668;