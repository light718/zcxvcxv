CREATE TABLE `s_fund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT NULL COMMENT '开启等级',
  `coin` int(11) DEFAULT NULL COMMENT '赠送金币数',
  `vipexp` int(11) DEFAULT NULL COMMENT '赠送的vip点数',
  `level_mult` int(11) DEFAULT NULL COMMENT '个人加速倍数',
  `level_time` int(11) DEFAULT NULL COMMENT '个人升级加速时间秒数',
  `ext` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '其他道具json格式',
  `status` tinyint(1) DEFAULT '1' COMMENT '是否有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='成长基金配置';

INSERT INTO `s_fund` VALUES (1, 0, 24000000, 240, 0, 0, NULL, 1);
INSERT INTO `s_fund` VALUES (2, 10, 6000000, 40, 0, 0, NULL, 1);
INSERT INTO `s_fund` VALUES (3, 30, 72000000, 60, 2, 7200, NULL, 1);
INSERT INTO `s_fund` VALUES (4, 50, 108000000, 80, 2, 7200, NULL, 1);
INSERT INTO `s_fund` VALUES (5, 70, 144000000, 100, 2, 7200, NULL, 1);
INSERT INTO `s_fund` VALUES (6, 100, 360000000, 180, 0, 0, NULL, 1);

CREATE TABLE `d_user_fund` (
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT 'uid',
  `fundid` int(11) NOT NULL COMMENT '基金配置id',
  `level` int(11) DEFAULT NULL COMMENT '开发领取的等级',
  `coin` int(11) DEFAULT NULL COMMENT '赠送的金币',
  `vipexp` int(11) DEFAULT NULL COMMENT '赠送的vip点数',
  `level_mult` int(11) DEFAULT NULL COMMENT '升级加速倍数',
  `level_time` int(11) DEFAULT NULL COMMENT '升级加速时长',
  `collect_time` int(11) DEFAULT NULL COMMENT '领取时间',
  `ext` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '其他内容',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`uid`,`fundid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户基金';

ALTER TABLE `d_user_fund` ADD COLUMN `state` tinyint(1) NULL DEFAULT 0 COMMENT '状态 0未开启 1正常' AFTER `ext`;

ALTER TABLE `s_shop` MODIFY COLUMN `stype` tinyint(1) NULL DEFAULT NULL COMMENT '类型1商城 2限时优惠 3转盘 4激励礼包 5等级礼包 6签到 7首充礼包 8onetimeonly 9排行榜时榜 10金猪 13成长基金' AFTER `appid`;

insert into s_shop(title,`ocount`,`count`,`amount`,`discount`,`status`,`productid`,`productid_gp`,`stype`) value ('成长基金',0,0,13.99,2400,1,'com.rummyslots.gold21','com.rummyslots.gold21',13);