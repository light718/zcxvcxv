-- 换皮游戏
---- 636 吸血鬼 Vampire Count
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    636, "吸血鬼", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 480;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    636, "vampirecount", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 480;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 636, "吸血鬼", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 480;

-- 637 酒馆女巫 Tavern Witch
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    637, "酒馆女巫", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 452;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    637, "tavernwitch", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 452;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 637, "酒馆女巫", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 452;

-- 638 宫本武藏 Blade Master Tokugawa
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    638, "宫本武藏", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 453;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    638, "blademastertokugawa", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 453;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 638, "宫本武藏", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 453;

-- 639 织田信长 Sixth Day The Demon
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    639, "织田信长", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 460;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    639, "sixthdaythedemon", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 460;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 639, "织田信长", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 460;
