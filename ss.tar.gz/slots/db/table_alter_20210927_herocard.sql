DROP TABLE IF EXISTS `s_herocard`;
CREATE TABLE `s_herocard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cardid` int(11) NOT NULL COMMENT '卡牌ID',
  `name` varchar(64) NOT NULL COMMENT '卡牌名称',
  `campid` int(11) NOT NULL COMMENT '所属阵营',
  `gameid` int(11) NOT NULL COMMENT '子游戏ID',
  `unlock_chips` int(11) NOT NULL COMMENT '解锁所需碎片',
  `init_star` tinyint(3) unsigned NOT NULL COMMENT '初始星级',
  `max_star` tinyint(3) unsigned NOT NULL COMMENT '最大星级',
  `rarity` tinyint(3) unsigned NOT NULL COMMENT '稀有度',
  `skillid` int(1) NOT NULL COMMENT '卡牌技能',
  `voice` varchar(64) DEFAULT '' COMMENT '卡牌语音',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='英雄卡牌';

INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '601', 'Zeus', '1', '60', '1001', '5', '', '1001', '1', '1');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '602', 'Athena', '2', '60', '1001', '5', '', '1002', '2', '2');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '603', 'Poseidon', '3', '60', '1003', '5', '', '1003', '3', '3');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '604', 'Medusa', '4', '60', '1002', '5', '', '1004', '4', '4');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '605', 'Aphrodite', '2', '60', '1001', '5', '', '1005', '5', '5');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '627', 'Emperor Qin', '1', '60', '1004', '5', '', '1006', '6', '6');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '628', 'Magician', '3', '60', '1005', '5', '', '1007', '7', '7');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '625', 'Interstellar', '5', '60', '1005', '5', '', '1008', '8', '8');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '629', 'Fantasy Chocolate Factory', '4', '60', '1005', '5', '', '1009', '9', '9');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '626', 'Clown', '2', '60', '1004', '5', '', '1010', '10', '10');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '624', 'The God of Fortune', '2', '60', '1004', '5', '', '1011', '11', '11');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '630', 'Lamp of Aladdin', '3', '60', '1003', '5', '', '1012', '12', '12');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '631', 'The Mermaid', '2', '60', '1003', '5', '', '1013', '13', '13');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '632', 'The Minstrel', '4', '60', '1002', '5', '', '1014', '14', '14');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '633', 'The Frog Prince', '5', '60', '1002', '5', '', '1015', '15', '15');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '621', 'The Lion', '5', '60', '1002', '5', '', '1016', '16', '16');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '622', 'The Panda', '2', '60', '1002', '5', '', '1017', '17', '17');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '634', 'The Mammoth', '3', '60', '1002', '5', '', '1018', '18', '18');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '635', 'The Legend of Dragon', '1', '60', '1002', '5', '', '1019', '19', '19');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '623', 'The Unicorn', '4', '60', '1002', '5', '', '1020', '20', '20');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '640', 'The Magic Hanzo', '3', '60', '1004', '5', '', '1021', '21', '21');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '618', 'Double Agent', '4', '60', '1005', '5', '', '1022', '22', '22');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '637', 'Tavern Witch', '3', '60', '1003', '5', '', '1023', '23', '23');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '636', 'Vampire Count', '2', '60', '1003', '5', '', '1024', '24', '24');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '620', 'Big Duel', '2', '60', '1003', '5', '', '1025', '25', '25');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '619', 'Lucky Cat', '4', '60', '1004', '5', '', '1026', '26', '26');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '638', 'Blade Master Tokugawa', '1', '60', '1003', '5', '', '1027', '27', '27');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '639', 'Sixth Day The Demon', '2', '60', '1004', '5', '', '1028', '28', '28');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '609', 'Joan of Arc', '4', '60', '1005', '5', '', '1029', '29', '29');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '610', 'Lord Caesar', '1', '60', '1001', '5', '', '1030', '30', '30');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '611', 'Lord of Thunder', '2', '60', '1001', '5', '', '1031', '31', '31');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '612', 'Goddess of Death', '3', '60', '1003', '5', '', '1032', '32', '32');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '613', 'Elves\' Blessing', '4', '60', '1001', '5', '', '1033', '33', '33');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '614', 'Odin\'s Anger', '1', '60', '1005', '5', '', '1034', '34', '34');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '615', 'The Round Table Knights\' Explore', '2', '60', '1005', '5', '', '1035', '35', '35');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '616', 'Gorgeous Cleopatra', '3', '60', '1001', '5', '', '1036', '36', '36');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '617', 'The Evil', '5', '60', '1004', '5', '', '1037', '37', '37');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '608', 'Fenrir', '4', '60', '1002', '5', '', '1038', '38', '38');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '641', 'Minamoto no Yoshitsune', '3', '60', '1004', '5', '', '1039', '39', '39');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '642', 'Gangster Godfather', '5', '60', '1005', '5', '', '1040', '40', '40');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '643', 'Loki', '2', '60', '1005', '5', '', '1041', '41', '41');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '644', 'Freyr', '2', '60', '1005', '5', '', '1042', '42', '42');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '645', 'Alexander', '3', '60', '1005', '5', '', '1043', '43', '43');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '646', 'Hades', '4', '60', '1003', '5', '', '1044', '44', '44');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '668', 'Demeter', '2', '60', '1001', '5', '', '1045', '45', '45');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '648', 'Hermes', '2', '60', '1001', '5', '', '1046', '46', '46');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '650', 'Prometheus', '1', '60', '1001', '5', '', '1047', '47', '47');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '652', 'Sphinx', '5', '60', '1001', '5', '', '1048', '48', '48');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '656', 'Nine-headed Bird', '3', '60', '1002', '5', '', '1049', '49', '49');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '657', 'Magic Froy', '2', '60', '1002', '5', '', '1050', '50', '50');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '658', 'Dwarfs And Princess', '3', '60', '1003', '5', '', '1051', '51', '51');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '659', 'Lucky Santa', '2', '60', '1005', '5', '', '1052', '52', '52');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '660', 'The Phoenix', '1', '60', '1002', '5', '', '1053', '53', '53');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '661', 'Robin Hood', '4', '60', '1003', '5', '', '1054', '54', '54');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '662', 'Bunny Girl', '5', '60', '1005', '5', '', '1055', '55', '55');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '663', 'Gold Miner', '5', '60', '1004', '5', '', '1056', '56', '56');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '664', 'Father of Invention', '4', '60', '1005', '5', '', '1057', '57', '57');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '665', 'West Cowboy', '5', '60', '1004', '5', '', '1058', '58', '58');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '666', 'Rising Sun The Great King', '3', '60', '1004', '5', '', '1059', '59', '59');
INSERT INTO `s_herocard`(`init_star`,`gameid`,`name`,`rarity`,`unlock_chips`,`campid`,`max_star`,`voice`,`cardid`,`id`,`skillid`) VALUES ('0', '667', 'Momen Tokichi', '2', '60', '1004', '5', '', '1060', '60', '60');
DROP TABLE IF EXISTS `s_herocard_star`;
CREATE TABLE `s_herocard_star` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `star` int(11) NOT NULL COMMENT '卡牌星级',
  `need_chips` int(11) NOT NULL COMMENT '升到当前星级所需碎片',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='卡牌升星';

TRUNCATE TABLE `s_herocard_star`;
INSERT INTO `s_herocard_star`(`need_chips`,`star`,`id`) VALUES ('80', '1', '1');
INSERT INTO `s_herocard_star`(`need_chips`,`star`,`id`) VALUES ('90', '2', '2');
INSERT INTO `s_herocard_star`(`need_chips`,`star`,`id`) VALUES ('100', '3', '3');
INSERT INTO `s_herocard_star`(`need_chips`,`star`,`id`) VALUES ('120', '4', '4');
INSERT INTO `s_herocard_star`(`need_chips`,`star`,`id`) VALUES ('150', '5', '5');
TRUNCATE TABLE `s_herocard_game_drop`;
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('601', '1', '0.008');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('602', '2', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('603', '3', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('604', '4', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('605', '5', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('606', '6', '0.009');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('607', '7', '0.009');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('608', '8', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('609', '9', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('610', '10', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('611', '11', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('612', '12', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('613', '13', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('614', '14', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('615', '15', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('616', '16', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('617', '17', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('618', '18', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('619', '19', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('620', '20', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('621', '21', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('622', '22', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('623', '23', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('624', '24', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('625', '25', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('626', '26', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('627', '27', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('628', '28', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('629', '29', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('630', '30', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('631', '31', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('632', '32', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('633', '33', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('634', '34', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('635', '35', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('636', '36', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('637', '37', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('638', '38', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('639', '39', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('640', '40', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('641', '41', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('642', '42', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('643', '43', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('644', '44', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('645', '45', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('646', '46', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('668', '47', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('648', '48', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('650', '49', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('652', '50', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('656', '51', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('657', '52', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('658', '53', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('659', '54', '0.011');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('660', '55', '0.01');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('661', '56', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('662', '57', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('663', '58', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('664', '59', '0.013');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('665', '60', '0.014');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('666', '61', '0.012');
INSERT INTO `s_herocard_game_drop`(`gameid`,`id`,`drop_prob`) VALUES ('667', '62', '0.011');
