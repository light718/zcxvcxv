replace into `s_sess` (`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`)
    VALUES (255, 'dzpk', 1, 1, 1, 1, 1, 100, 0, 0, 20000, 1000, 2000, 2, 3, 6);

replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(255, "dzpk", '', 0, 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (6, 255, "dzpk", 1, 100);
