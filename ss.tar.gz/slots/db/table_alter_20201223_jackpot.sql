-- 466 猛犸象  Mammoth          mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[10,50,800,5000]' WHERE id = 466;
