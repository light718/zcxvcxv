UPDATE `s_bingo_reward` SET `rewards`="1:3780000|3:3600" WHERE `type`=1 AND `section_id`=2 AND `order_id`=1;
UPDATE `s_bingo_reward` SET `rewards`="1:4000000|3:3600" WHERE `type`=1 AND `section_id`=2 AND `order_id`=2;
UPDATE `s_bingo_reward` SET `rewards`="1:4120000|3:3600" WHERE `type`=1 AND `section_id`=2 AND `order_id`=3;

