
--473 leprechcarniscoins妖精硬币
--474 mammothgrand 猛犸象大
--475  rockingdisco摇摆迪斯科
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (473, "妖精硬币", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(473, "leprechcarniscoins", 0, 0.1, 0.1, '[10,200,1000,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 473, "妖精硬币", 1, 100);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (474, "猛犸象大 ", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(474, "mammothgrand", 0, 0.1, 0.1, '[5,100,1000,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 474, "猛犸象大 ", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (475, "摇摆迪斯科 ", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(475, "rockingdisco", 0, 0.1, 0.1, '[15,20,50,500, 5000]', '[4,6,9,16,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 475, "摇摆迪斯科 ", 1, 100);
