replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (514, "富贵熊猫", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(514, "wealthofpanda", 0, 0.1, 0.1, '[5,10,50,100,250]', '[1,1,1,1,1]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 514, "富贵熊猫", 1, 500);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (513, "咆哮的月亮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(513, "howlingmoon", 0, 0.1, 0.1, '[8,20,200,1000]', '[1,3,6,9]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 513, "咆哮的月亮", 1, 500);


update s_game set gametag=0 where id in (select gameid from s_game_type where gametype=2);
update s_game_type set `taghot`=0 where  taghot>0;
update s_game_type set `hot`=500 where gametype=2 and gameid>=419;
update s_game set `level`=0 where id >= 419;

--new
update s_game set gametag = 2, `level`=0 where id in (614,615);
--hot
update s_game set gametag = 1, `level`=0 where id in (616,624);

update s_game set `level`=5 where id = 601;
update s_game set `level`=10 where id = 605;
update s_game set `level`=15 where id = 613;
update s_game set `level`=20 where id = 602;
update s_game set `level`=25 where id = 610;
update s_game set `level`=30 where id = 611;
update s_game set `level`=35 where id = 650;
update s_game set `level`=40 where id = 668;
update s_game set `level`=45 where id = 648;
update s_game set `level`=50 where id = 652;

update s_game set `level`=10 where id = 621;
update s_game set `level`=55 where id = 622;
update s_game set `level`=60 where id = 623;
update s_game set `level`=65 where id = 604;
update s_game set `level`=70 where id = 657;
update s_game set `level`=75 where id = 635;
update s_game set `level`=80 where id = 656;
update s_game set `level`=85 where id = 619;
update s_game set `level`=90 where id = 608;
update s_game set `level`=95 where id = 634;
update s_game set `level`=100 where id = 633;
update s_game set `level`=105 where id = 660;
update s_game set `level`=110 where id = 632;

update s_game set `level`=15 where id = 603;
update s_game set `level`=115 where id = 612;
update s_game set `level`=120 where id = 637;
update s_game set `level`=125 where id = 636;
update s_game set `level`=130 where id = 630;
update s_game set `level`=135 where id = 631;
update s_game set `level`=140 where id = 646;
update s_game set `level`=145 where id = 620;
update s_game set `level`=150 where id = 638;
update s_game set `level`=155 where id = 658;
update s_game set `level`=160 where id = 661;

update s_game set `level`=20 where id = 640;
update s_game set `level`=165 where id = 639;
update s_game set `level`=170 where id = 641;
update s_game set `level`=175 where id = 666;
update s_game set `level`=180 where id = 667;
update s_game set `level`=185 where id = 627;
update s_game set `level`=190 where id = 617;
update s_game set `level`=195 where id = 665;
update s_game set `level`=200 where id = 663;
update s_game set `level`=205 where id = 628;
update s_game set `level`=210 where id = 626;

update s_game set `level`=25 where id = 609;
update s_game set `level`=215 where id = 643;
update s_game set `level`=220 where id = 644;
update s_game set `level`=225 where id = 645;
update s_game set `level`=230 where id = 642;
update s_game set `level`=235 where id = 659;
update s_game set `level`=240 where id = 662;
update s_game set `level`=245 where id = 625;
update s_game set `level`=250 where id = 618;
update s_game set `level`=255 where id = 664;
update s_game set `level`=260 where id = 629;
update s_game set `level`=265 where id = 513;
update s_game set `level`=270 where id = 514;

update s_game_type set `hot`=10 where  gameid = 601;
update s_game_type set `hot`=11 where  gameid = 605;
update s_game_type set `hot`=12 where  gameid = 613;
update s_game_type set `hot`=13 where  gameid = 602;
update s_game_type set `hot`=14 where  gameid = 610;
update s_game_type set `hot`=15 where  gameid = 611;
update s_game_type set `hot`=16 where  gameid = 650;
update s_game_type set `hot`=17 where  gameid = 668;
update s_game_type set `hot`=18 where  gameid = 648;
update s_game_type set `hot`=19 where  gameid = 652;

update s_game_type set `hot`=50 where  gameid = 621;
update s_game_type set `hot`=51 where  gameid = 622;
update s_game_type set `hot`=52 where  gameid = 623;
update s_game_type set `hot`=53 where  gameid = 604;
update s_game_type set `hot`=54 where  gameid = 657;
update s_game_type set `hot`=55 where  gameid = 635;
update s_game_type set `hot`=56 where  gameid = 656;
update s_game_type set `hot`=57 where  gameid = 619;
update s_game_type set `hot`=58 where  gameid = 608;
update s_game_type set `hot`=59 where  gameid = 634;
update s_game_type set `hot`=60 where  gameid = 633;
update s_game_type set `hot`=61 where  gameid = 660;
update s_game_type set `hot`=62 where  gameid = 632;

update s_game_type set `hot`=100 where  gameid = 603;
update s_game_type set `hot`=101 where  gameid = 612;
update s_game_type set `hot`=102 where  gameid = 637;
update s_game_type set `hot`=103 where  gameid = 636;
update s_game_type set `hot`=104 where  gameid = 630;
update s_game_type set `hot`=105 where  gameid = 631;
update s_game_type set `hot`=106 where  gameid = 646;
update s_game_type set `hot`=107 where  gameid = 620;
update s_game_type set `hot`=108 where  gameid = 638;
update s_game_type set `hot`=109 where  gameid = 658;
update s_game_type set `hot`=110 where  gameid = 661;

update s_game_type set `hot`=150 where  gameid = 640;
update s_game_type set `hot`=151 where  gameid = 639;
update s_game_type set `hot`=152 where  gameid = 641;
update s_game_type set `hot`=153 where  gameid = 666;
update s_game_type set `hot`=154 where  gameid = 667;
update s_game_type set `hot`=155 where  gameid = 627;
update s_game_type set `hot`=156 where  gameid = 617;
update s_game_type set `hot`=157 where  gameid = 665;
update s_game_type set `hot`=158 where  gameid = 663;
update s_game_type set `hot`=159 where  gameid = 628;
update s_game_type set `hot`=160 where  gameid = 626;

update s_game_type set `hot`=200 where  gameid = 609;
update s_game_type set `hot`=201 where  gameid = 643;
update s_game_type set `hot`=202 where  gameid = 644;
update s_game_type set `hot`=203 where  gameid = 645;
update s_game_type set `hot`=204 where  gameid = 642;
update s_game_type set `hot`=205 where  gameid = 659;
update s_game_type set `hot`=206 where  gameid = 662;
update s_game_type set `hot`=207 where  gameid = 625;
update s_game_type set `hot`=208 where  gameid = 618;
update s_game_type set `hot`=209 where  gameid = 664;
update s_game_type set `hot`=210 where  gameid = 629;
update s_game_type set `hot`=215 where  gameid = 513;
update s_game_type set `hot`=230 where  gameid = 514;

-- hot
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=616&type=2&ord=1'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=624&type=2&ord=3'

-- new
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=615&type=2&ord=2'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=614&type=2&ord=4'