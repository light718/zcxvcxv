-- 更新任务

UPDATE `s_new_quest` SET detail='Bet 3 different slots.',kind=14,params=3 WHERE id=2;
UPDATE `s_new_quest` SET detail='Win a total of %d coins.',kind=2,params=500000 WHERE id=3;
UPDATE `s_new_quest` SET detail='Bet %d in a single spin 10 times.',kind=7,params='10,80000' WHERE id=4;

UPDATE `s_new_quest` SET detail='Play any slot for 30 minutes.',kind=17,params=30 WHERE id=6;
UPDATE `s_new_quest` SET detail='Bet a total of %d Coins.',kind=3,params=1000000 WHERE id=7;
UPDATE `s_new_quest` SET detail='Spin 50 times.',kind=1,params=50 WHERE id=8;

UPDATE `s_new_quest` SET detail='Level up 1 time.',kind=15,params=1 WHERE id=10;
UPDATE `s_new_quest` SET detail='Bet a total of %d Coins.',kind=3,params=5000000 WHERE id=11;
UPDATE `s_new_quest` SET detail='Share to Facebook 1 time.',kind=16,params=1 WHERE id=12;
