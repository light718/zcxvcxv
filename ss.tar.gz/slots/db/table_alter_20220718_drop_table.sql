-- s_new_quest 已转 conf.s_new_quest
-- s_rank_reward 已转 conf.s_rank_reward
drop table s_new_quest;
drop table s_rank_reward;