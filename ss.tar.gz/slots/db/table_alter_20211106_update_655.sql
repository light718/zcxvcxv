-- 更改换皮游戏655，从499改成470

update s_game set jackpot = '[10,50,100,650,2000,5000]', jp_unlock_lv = '[4,6,7,13,9,11]' where id=655;