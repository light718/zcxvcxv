update s_game_type set hot=5 where gameid=422;
update s_game_type set hot=10 where gameid=416;

update s_game_type set hot=15 where gameid=420;
update s_game_type set hot=20 where gameid=113;

update s_game_type set hot=25 where gameid=421;
update s_game_type set hot=30 where gameid=171;


update s_game_type set hot=35 where gameid=419;
update s_game_type set hot=40 where gameid=156;


update s_game_type set hot=45 where gameid=425;
update s_game_type set hot=50 where gameid=141;


update s_game_type set hot=55 where gameid=427;
update s_game_type set hot=60 where gameid=150;


update s_game_type set hot=65 where gameid=428;
update s_game_type set hot=70 where gameid=151;

update s_game_type set hot=75 where gameid=435;
update s_game_type set hot=80 where gameid=152;

update s_game_type set hot=85 where gameid=452;
update s_game_type set hot=90 where gameid=153;

update s_game_type set hot= 95 where gameid=170;
update s_game_type set hot= 95 where gameid=141;
update s_game_type set hot= 95 where gameid=158;