-- 446  宾果猫  bingomeow   mini, minor, major, grand, mega
UPDATE `s_game` SET `jackpot` = '[5,50,500,5000,1000]' WHERE id = 446;
-- 447  珍宝丛林  treasurejungle  min, minor, major, grand， 必须包含mini,前端可以不用
UPDATE `s_game` SET `jackpot` = '[5,10,200,5000]' WHERE id = 447;
-- 448 圣诞老人在哪里 whereisthesantaclaus  mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[10,20,500,5000]' WHERE id = 448;
-- 449 青蛙王子  princecharming    mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[20,100,1000,5000]' WHERE id = 449;
-- 450 皇家小犬  royalpuppies      mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[5,10,50,1000]' WHERE id = 450;
-- 451 大功率  highpower          mini, minor, major, grand, mega
UPDATE `s_game` SET `jackpot` = '[5,10,17,167,33]' WHERE id = 451;
-- 452 啤酒馆 miasbearhallmia     mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[10,20,500,5000]' WHERE id = 452;
-- 453 泰山 jungleking            mini, minor, major, grand, maxi
UPDATE `s_game` SET `jackpot` = '[10,20,100,5000,1000]' WHERE id = 453;
-- 454 来开派对 letisparty         mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[5,20,300,10000]' WHERE id = 454;
-- 455 宇航员 adventuresinspace    mini, minor, major, grand, maxi
UPDATE `s_game` SET `jackpot` = '[10,20,100,5000,500]' WHERE id = 455;
-- 456 鼠年 yearoftherat          mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[5,20,500,5000]' WHERE id = 456;
-- 457 野生澳大利亚 wildaustralia  mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[5,10,100,5000]' WHERE id = 457;
-- 458 小恶魔 superwickedblast    mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[5,20,300,10000]' WHERE id = 458;
-- 459 美杜莎 risingmedusa        mini, minor, major, grand, maxi
UPDATE `s_game` SET `jackpot` = '[5,20,100,5000,1000]' WHERE id = 459;
-- 460 财富宫 fortunegong         mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[5,20,300,10000]' WHERE id = 460;
-- 461 命运之轮豪华车 fortunewheeldeluxe    mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[10,60,1000,5000]' WHERE id = 461;
-- 462 埃及的幻想 egyptianfantasy   mini, minor, major, grand, maxi
UPDATE `s_game` SET `jackpot` = '[10,40,100,1500,400]' WHERE id = 462;
-- 463 马戏嘉年华 circuscarnival    mini, minor, major, grand, maxi
UPDATE `s_game` SET `jackpot` = '[5,15,50,5000,500]' WHERE id = 463;
