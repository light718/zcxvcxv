replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (483, "大型金库亿万富翁", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(483, "megavaultbillionaire", 0, 0.1, 0.1, '[5,20,300,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 483, "大型金库亿万富翁 ", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (484, "怪物现金", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(484, "monstercash", 0, 0.1, 0.1, '[5,20,500,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 484, "怪物现金 ", 1, 100);

insert into d_sys_mail(title,msg,attach,timestamp,stype) value('New Slot Pelican Quest','New Game Pelican Quest is on! Check it out spinners! Hope you enjoy your game!','[{"id":1,"num":200000,"gameid":478}]',1611292940,11);
insert into d_sys_mail(title,msg,attach,timestamp,stype) value('Welcome to Cash Hero',"We've prepared a gift for you. Hope you enjoy our game!",'[{"id":1,"num":200000}]',1611292940,8);
