CREATE TABLE `d_app_log`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` int(10) NULL DEFAULT 0 COMMENT 'uid',
  `act` varchar(100) NULL COMMENT '操作类型',
  `ts` int(11) NULL COMMENT '操作时间',
  `ddid` varchar(100) NULL COMMENT '设备id',
  `os` tinyint(1) NULL COMMENT '设备类型1安卓 2ios 3web',
  `appid` int(10) NULL COMMENT '客户端类型',
  `appver` varchar(100) NULL DEFAULT '' COMMENT '客户端版本',
  `ip` int(11) UNSIGNED NULL COMMENT '客户端ip',
  `country` varchar(255) NULL COMMENT '国家',
  `city` varchar(255) NULL COMMENT '城市',
  `latitude` double(20, 6) NULL COMMENT '纬度',
  `longitude` double(20, 6) NULL COMMENT '经度',
  `ext` varchar(300) NULL COMMENT '扩展',
  PRIMARY KEY (`id`)
) COMMENT = '启动日志';

ALTER TABLE `d_app_log` 
ADD INDEX `index_ts_ddid`(`ts`, `ddid`);
--文良
--472 太空猫 spacecat
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (472, "太空猫", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(472, "spacecat", 0, 0.1, 0.1, '[10, 300, 5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 472, "太空猫", 1, 100);


update `s_game` set `jackpot` = '[10,50,100,650,2000,300]' where `id` = 470;