-- dz

delete from `s_sess` where gameid = 255;
replace into `s_sess` (`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`)
    VALUES (255, 'dzpk', 1000, 10000, 1, 1, 1, 100, 0, 2, 20000, 1000, 2000, 2, 3, 5);
    
replace into `s_sess` (`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`)
    VALUES (255, 'dzpk',10000, 1500000, 1, 1, 1, 100, 0, 3, 20000, 1000, 2000, 2, 3, 5);

replace into `s_sess` (`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`)
    VALUES (255, 'dzpk', 1000000, 150000000, 1, 1, 1, 100, 0, 4, 20000, 1000, 2000, 2, 3, 5);

replace into `s_sess` (`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`)
    VALUES (255, 'dzpk',  100000000, 15000000000, 1, 1, 1, 100, 0, 5, 20000, 1000, 2000, 2, 3, 5);