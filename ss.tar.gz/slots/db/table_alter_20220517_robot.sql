update d_user set isrobot=0 where isrobot is null;

