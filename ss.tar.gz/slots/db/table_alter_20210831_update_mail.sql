-- 更改邮件标题
update d_sys_mail set title = 'Welcome To Cash Hero!' where title = 'Welcome To Cash Hero';
update d_sys_mail set msg = 'This is your VIP rewards, please check Upgrade VIP level gets higher privilege!' where title = 'VIP System Is ON';
update d_sys_mail set title = 'System Rewards', msg = 'Just test hope you enjoy your game!' where title = '维护奖励';

