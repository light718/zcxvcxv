update s_activity_reward set rewards='1:100000' where id=1;
update s_game set jackpot='[10,20,50,5000,500]' where id=475;