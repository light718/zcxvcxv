DROP TABLE IF EXISTS `s_game_task`;
CREATE TABLE `s_game_task` (
  `roundid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `rewardid` int(11) NOT NULL DEFAULT '0',
  `rewardnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`roundid`,`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `s_game_task_detail`;
CREATE TABLE `s_game_task_detail` (
  `roundid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `detailid` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  `param1` int(11) DEFAULT NULL,
  `param2` int(11) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`roundid`,`taskid`,`detailid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `s_game_task` VALUES ('1', '1', '440', '1', '1500000');
INSERT INTO `s_game_task` VALUES ('1', '2', '611', '1', '2250000');
INSERT INTO `s_game_task` VALUES ('1', '3', '446', '1', '3375000');
INSERT INTO `s_game_task` VALUES ('1', '4', '479', '1', '4000000');
INSERT INTO `s_game_task` VALUES ('1', '5', '602', '1', '8000000');
INSERT INTO `s_game_task` VALUES ('1', '6', '484', '1', '12000000');
INSERT INTO `s_game_task` VALUES ('2', '1', '458', '1', '7500000');
INSERT INTO `s_game_task` VALUES ('2', '2', '437', '1', '11250000');
INSERT INTO `s_game_task` VALUES ('2', '3', '443', '1', '16875000');
INSERT INTO `s_game_task` VALUES ('2', '4', '428', '1', '20250000');
INSERT INTO `s_game_task` VALUES ('2', '5', '425', '1', '40500000');
INSERT INTO `s_game_task` VALUES ('2', '6', '433', '1', '60750000');
INSERT INTO `s_game_task` VALUES ('3', '1', '440', '1', '13500000');
INSERT INTO `s_game_task` VALUES ('3', '2', '446', '1', '20250000');
INSERT INTO `s_game_task` VALUES ('3', '3', '611', '1', '30375000');
INSERT INTO `s_game_task` VALUES ('3', '4', '479', '1', '36450000');
INSERT INTO `s_game_task` VALUES ('3', '5', '602', '1', '72900000');
INSERT INTO `s_game_task` VALUES ('3', '6', '484', '1', '109350000');


INSERT INTO `s_game_task_detail` VALUES ('1', '1', '1', '1', null, null, '30');
INSERT INTO `s_game_task_detail` VALUES ('1', '1', '2', '3', null, null, '2000000');
INSERT INTO `s_game_task_detail` VALUES ('1', '2', '1', '1', null, '1', '2');
INSERT INTO `s_game_task_detail` VALUES ('1', '2', '2', '3', null, null, '8000000');
INSERT INTO `s_game_task_detail` VALUES ('1', '3', '1', '2', null, null, '25');
INSERT INTO `s_game_task_detail` VALUES ('1', '3', '2', '1', null, '1', '2');
INSERT INTO `s_game_task_detail` VALUES ('1', '3', '3', '3', null, null, '3500000');
INSERT INTO `s_game_task_detail` VALUES ('1', '4', '1', '6', '2', null, '45');
INSERT INTO `s_game_task_detail` VALUES ('1', '4', '2', '7', null, null, '800');
INSERT INTO `s_game_task_detail` VALUES ('1', '5', '1', '4', null, null, '10000000');
INSERT INTO `s_game_task_detail` VALUES ('1', '5', '2', '6', '2', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('1', '5', '3', '1', '1', null, '1');
INSERT INTO `s_game_task_detail` VALUES ('1', '6', '1', '6', '6', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('1', '6', '2', '1', null, '1', '1');
INSERT INTO `s_game_task_detail` VALUES ('1', '6', '3', '4', '1', null, '2400000');
INSERT INTO `s_game_task_detail` VALUES ('2', '1', '1', '1', null, null, '20');
INSERT INTO `s_game_task_detail` VALUES ('2', '1', '2', '3', null, null, '10000000');
INSERT INTO `s_game_task_detail` VALUES ('2', '2', '1', '2', null, null, '12');
INSERT INTO `s_game_task_detail` VALUES ('2', '2', '2', '6', '2', null, '25');
INSERT INTO `s_game_task_detail` VALUES ('2', '2', '3', '4', null, null, '25000000');
INSERT INTO `s_game_task_detail` VALUES ('2', '3', '1', '2', '1', null, '5');
INSERT INTO `s_game_task_detail` VALUES ('2', '3', '2', '3', null, null, '28200000');
INSERT INTO `s_game_task_detail` VALUES ('2', '4', '1', '6', '2', null, '50');
INSERT INTO `s_game_task_detail` VALUES ('2', '4', '2', '1', '1', null, '1');
INSERT INTO `s_game_task_detail` VALUES ('2', '4', '3', '4', null, null, '20800000');
INSERT INTO `s_game_task_detail` VALUES ('2', '5', '1', '6', '2', null, '60');
INSERT INTO `s_game_task_detail` VALUES ('2', '5', '2', '4', null, null, '16100000');
INSERT INTO `s_game_task_detail` VALUES ('2', '6', '1', '6', '2', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('2', '6', '2', '1', null, '1', '1');
INSERT INTO `s_game_task_detail` VALUES ('2', '6', '3', '4', '1', null, '24100000');
INSERT INTO `s_game_task_detail` VALUES ('3', '1', '1', '1', null, null, '30');
INSERT INTO `s_game_task_detail` VALUES ('3', '1', '2', '3', null, null, '120000000');
INSERT INTO `s_game_task_detail` VALUES ('3', '2', '1', '2', null, null, '25');
INSERT INTO `s_game_task_detail` VALUES ('3', '2', '2', '1', null, '1', '2');
INSERT INTO `s_game_task_detail` VALUES ('3', '2', '3', '4', null, null, '40000000');
INSERT INTO `s_game_task_detail` VALUES ('3', '3', '1', '2', '1', null, '5');
INSERT INTO `s_game_task_detail` VALUES ('3', '3', '2', '3', null, null, '70000000');
INSERT INTO `s_game_task_detail` VALUES ('3', '4', '1', '6', '2', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('3', '4', '2', '1', '1', null, '2');
INSERT INTO `s_game_task_detail` VALUES ('3', '5', '1', '4', null, null, '150000000');
INSERT INTO `s_game_task_detail` VALUES ('3', '5', '2', '6', '2', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('3', '5', '3', '1', '1', null, '3');
INSERT INTO `s_game_task_detail` VALUES ('3', '6', '1', '6', '6', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('3', '6', '2', '1', null, '1', '2');
INSERT INTO `s_game_task_detail` VALUES ('3', '6', '3', '4', '1', null, '30000000');