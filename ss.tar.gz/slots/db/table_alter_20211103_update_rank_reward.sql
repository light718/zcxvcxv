-- 增加新的排行榜奖励，对应等级排行榜

INSERT INTO `s_rank_reward` VALUES (61, 5, 1, '1:2000000');
INSERT INTO `s_rank_reward` VALUES (62, 5, 2, '1:1500000');
INSERT INTO `s_rank_reward` VALUES (63, 5, 3, '1:1000000');
INSERT INTO `s_rank_reward` VALUES (64, 5, 4, '1:800000');
INSERT INTO `s_rank_reward` VALUES (65, 5, 5, '1:800000');
INSERT INTO `s_rank_reward` VALUES (66, 5, 6, '1:800000');
INSERT INTO `s_rank_reward` VALUES (67, 5, 7, '1:800000');
INSERT INTO `s_rank_reward` VALUES (68, 5, 8, '1:800000');
INSERT INTO `s_rank_reward` VALUES (69, 5, 9, '1:800000');
INSERT INTO `s_rank_reward` VALUES (70, 5, 10, '1:800000');
INSERT INTO `s_rank_reward` VALUES (71, 5, 11, '1:500000');
INSERT INTO `s_rank_reward` VALUES (72, 5, 12, '1:500000');
INSERT INTO `s_rank_reward` VALUES (73, 5, 13, '1:500000');
INSERT INTO `s_rank_reward` VALUES (74, 5, 14, '1:500000');
INSERT INTO `s_rank_reward` VALUES (75, 5, 15, '1:500000');
INSERT INTO `s_rank_reward` VALUES (76, 5, 16, '1:500000');
INSERT INTO `s_rank_reward` VALUES (77, 5, 17, '1:500000');
INSERT INTO `s_rank_reward` VALUES (78, 5, 18, '1:500000');
INSERT INTO `s_rank_reward` VALUES (79, 5, 19, '1:500000');
INSERT INTO `s_rank_reward` VALUES (80, 5, 20, '1:500000');
