-- 修正花木兰jackpot
update s_game set jackpot='[5,10,50,150]', jp_unlock_lv='[4,6,9,12]' where id=647;