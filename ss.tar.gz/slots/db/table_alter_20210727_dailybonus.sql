DROP TABLE IF EXISTS `s_sign_new`;
CREATE TABLE `s_sign_new` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coin` int(11) NOT NULL COMMENT '原始签到金币',
  `prize` varchar(255) DEFAULT '' COMMENT '其他奖品',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;

INSERT INTO `s_sign_new` VALUES ('1', '84000', '[{\"s\":2,\"n\":40}]');
INSERT INTO `s_sign_new` VALUES ('2', '168000', '[{\"s\":3,\"n\":7200}]');
INSERT INTO `s_sign_new` VALUES ('3', '336000', '[{\"s\":8,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('4', '504000', '[{\"s\":9,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('5', '840000', '[{\"s\":16,\"n\":30}]');
INSERT INTO `s_sign_new` VALUES ('6', '1680000', '[{\"s\":3,\"n\":14400}]');
INSERT INTO `s_sign_new` VALUES ('7', '2520000', '[{\"s\":3,\"n\":14400},{\"s\":8,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('8', '168000', '[{\"s\":2,\"n\":40}]');
INSERT INTO `s_sign_new` VALUES ('9', '336000', '[{\"s\":3,\"n\":7200}]');
INSERT INTO `s_sign_new` VALUES ('10', '672000', '[{\"s\":8,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('11', '1008000', '[{\"s\":9,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('12', '1680000', '[{\"s\":16,\"n\":30}]');
INSERT INTO `s_sign_new` VALUES ('13', '3360000', '[{\"s\":3,\"n\":14400}]');
INSERT INTO `s_sign_new` VALUES ('14', '5040000', '[{\"s\":3,\"n\":14400},{\"s\":8,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('15', '504000', '[{\"s\":2,\"n\":40}]');
INSERT INTO `s_sign_new` VALUES ('16', '504000', '[{\"s\":3,\"n\":7200}]');
INSERT INTO `s_sign_new` VALUES ('17', '1008000', '[{\"s\":8,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('18', '1512000', '[{\"s\":9,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('19', '2520000', '[{\"s\":16,\"n\":30}]');
INSERT INTO `s_sign_new` VALUES ('20', '5040000', '[{\"s\":3,\"n\":14400}]');
INSERT INTO `s_sign_new` VALUES ('21', '7560000', '[{\"s\":3,\"n\":14400},{\"s\":8,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('22', '672000', '[{\"s\":2,\"n\":40}]');
INSERT INTO `s_sign_new` VALUES ('23', '672000', '[{\"s\":3,\"n\":7200}]');
INSERT INTO `s_sign_new` VALUES ('24', '1344000', '[{\"s\":8,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('25', '2016000', '[{\"s\":9,\"n\":3}]');
INSERT INTO `s_sign_new` VALUES ('26', '3360000', '[{\"s\":16,\"n\":30}]');
INSERT INTO `s_sign_new` VALUES ('27', '6720000', '[{\"s\":3,\"n\":14400}]');
INSERT INTO `s_sign_new` VALUES ('28', '10080000', '[{\"s\":3,\"n\":14400},{\"s\":8,\"n\":3}]');

DROP TABLE IF EXISTS `s_sign_pack`;
CREATE TABLE `s_sign_pack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` int(11) DEFAULT '0' COMMENT '累计签到天数',
  `prize` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '奖品',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `s_sign_pack` VALUES ('1', '8', '[{\"s\":1,\"n\":4200000},{\"s\":2,\"n\":40},{\"s\":3,\"n\":14400}]');
INSERT INTO `s_sign_pack` VALUES ('2', '15', '[{\"s\":1,\"n\":12600000},{\"s\":3,\"n\":14400},{\"s\":9,\"n\":5}]');
INSERT INTO `s_sign_pack` VALUES ('3', '22', '[{\"s\":1,\"n\":8400000},{\"s\":2,\"n\":50},{\"s\":3,\"n\":21600}]');
INSERT INTO `s_sign_pack` VALUES ('4', '30', '[{\"s\":1,\"n\":16800000},{\"s\":9,\"n\":5},{\"s\":8,\"n\":5}]');

DROP TABLE IF EXISTS `s_herocard_common_drop`;
CREATE TABLE `s_herocard_common_drop` (
  `id` int(11) NOT NULL,
  `star` int(11) DEFAULT '0' COMMENT '星级',
  `cardid` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `s_herocard_common_drop` VALUES ('1', '1', '1008', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('2', '1', '1015', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('3', '1', '1016', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('4', '1', '1037', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('5', '2', '1004', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('6', '2', '1009', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('7', '2', '1014', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('8', '2', '1020', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('9', '2', '1022', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('10', '2', '1026', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('11', '2', '1029', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('12', '2', '1033', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('13', '3', '1003', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('14', '3', '1007', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('15', '3', '1012', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('16', '3', '1018', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('17', '3', '1021', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('18', '3', '1023', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('19', '3', '1032', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('20', '3', '1036', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('21', '4', '1002', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('22', '4', '1005', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('23', '4', '1010', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('24', '4', '1011', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('25', '4', '1013', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('26', '4', '1017', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('27', '4', '1024', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('28', '4', '1025', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('29', '4', '1028', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('30', '4', '1031', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('31', '4', '1035', '160');
INSERT INTO `s_herocard_common_drop` VALUES ('32', '5', '1001', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('33', '5', '1006', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('34', '5', '1019', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('35', '5', '1027', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('36', '5', '1030', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('37', '5', '1034', '320');