-- 换皮游戏
---- 630 阿拉丁神灯 Lamp of Aladdin
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    630, "阿拉丁神灯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 442;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    630, "lampofaladdin", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 442;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 630, "阿拉丁神灯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 442;

-- 631 美人鱼 The Mermaid
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    631, "美人鱼", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 424;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    631, "themermaid", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 424;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 631, "美人鱼", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 424;

-- 632 吟游诗人 The Minstrel
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    632, "吟游诗人", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 423;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    632, "theminstrel", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 423;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 632, "吟游诗人", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 423;

-- 633 青蛙王子 The Frog Prince
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    633, "青蛙王子", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 449;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    633, "thefrogprince", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 449;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 633, "青蛙王子", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 449;

-- 634 猛犸象 The Mammoth
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    634, "猛犸象", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 466;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    634, "themammoth", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 466;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 634, "猛犸象", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 466;


-- 635 龙的传说 The Legend of Dragon
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    635, "龙的传说", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 443;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    635, "thelegendofdragon", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 443;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 635, "龙的传说", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 443;


-- 修复前面游戏错误问题
UPDATE `s_sess` SET `title` = "日本招财猫" where gameid = 619;
UPDATE `s_game` SET `title` = "luckycat" where id = 619;
UPDATE `s_game_type` SET `title` = "日本招财猫" where gameid = 619;
