
DROP TABLE IF EXISTS `s_newbie_task`;
CREATE TABLE `s_newbie_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT 0 COMMENT '任务序号',
  `type`  int(11)  DEFAULT 0 COMMENT '任务类型',
  `detail` varchar(255) DEFAULT 0 COMMENT '任务描述',
  `condition` int(11) DEFAULT 0 COMMENT '任务条件',
  `count` int(11) DEFAULT 0 COMMENT '任务数量',
  `rewards` varchar(255) DEFAULT 0 COMMENT '奖励',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='新手任务配置';

INSERT INTO `s_newbie_task` VALUES (1, 1, 1, 'Make 5 Spins', 0, 5, '1:100000');
INSERT INTO `s_newbie_task` VALUES (2, 2, 2, 'Reach level 3', 0, 3, '1:150000');
INSERT INTO `s_newbie_task` VALUES (3, 3, 2, 'Reach level 4', 0, 4, '1:200000');

DROP TABLE IF EXISTS `d_newbie_task`;
CREATE TABLE `d_newbie_task` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT 0 COMMENT '用户uid',
  `state` int(11) DEFAULT 0 COMMENT '任务状态 0:任务进行中, 1:待领取, 2:已完成(无下一个任务)',
  `type` int(11) DEFAULT 0 COMMENT '任务类型',
  `count` int(11) DEFAULT 0 COMMENT '已达到的数量',
  `total` int(11) DEFAULT 0 COMMENT '需要达到的数量',
  `order_id` int(11) DEFAULT 0 COMMENT '当前任务序号',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='新手任务记录表';


-- 更改bingo数据结构，增加一个字段, 用来判断是否第一次操作bingo
ALTER TABLE `d_bingo_record` ADD `is_new` int DEFAULT 0 COMMENT '是否是新用户(是否操作过bingo),0是老用户,1是新用户';

-- 更新bingo任务，从周一到周日
UPDATE `s_bingo` SET `start_day`=1, `end_day`=7;