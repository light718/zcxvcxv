ALTER TABLE `d_mail` ADD COLUMN `sysMailID` int(11) NULL DEFAULT 0 COMMENT '系统邮件id' AFTER `received`;

ALTER TABLE `d_sys_mail` ADD COLUMN `stype` int(11) NULL DEFAULT 1 COMMENT '邮件类型' AFTER `timestamp`;