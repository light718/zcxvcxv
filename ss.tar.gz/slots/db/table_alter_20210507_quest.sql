
ALTER TABLE `s_quest` ADD COLUMN `preid` int(11) NOT NULL DEFAULT 0 COMMENT '前置任务ID' AFTER `id`;

update s_quest set preid = 0 where id = 1;
update s_quest set preid = 1 where id = 2;
update s_quest set preid = 2 where id = 3;
update s_quest set preid = 3 where id = 4;
update s_quest set preid = 4 where id = 5;
update s_quest set preid = 5 where id = 6;

update s_quest set count = 150000, rewards='1:150000|6:20' where id = 6;
update s_quest set count = 150000, rewards='1:150000' where id = 7;

INSERT INTO `s_quest` set id = 21, preid=0, `type`=1, parm1=1, parm2=0, parmCnt=1, descr='1x fragment', `count`=100000, icon='4',rewards='1:100000|6:10';
INSERT INTO `s_quest` set id = 22, preid=21, `type`=1, parm1=3, parm2=0, parmCnt=1, descr='3x fragments', `count`=300000, icon='4',rewards='1:300000|6:10';
INSERT INTO `s_quest` set id = 23, preid=22, `type`=1, parm1=5, parm2=0, parmCnt=1, descr='5x fragments', `count`=500000, icon='4',rewards='1:500000|6:10';
INSERT INTO `s_quest` set id = 24, preid=23, `type`=1, parm1=7, parm2=0, parmCnt=1, descr='7x fragments', `count`=700000, icon='4',rewards='1:700000|6:10';
INSERT INTO `s_quest` set id = 25, preid=24, `type`=1, parm1=9, parm2=0, parmCnt=1, descr='9x fragments', `count`=900000, icon='4',rewards='1:900000|6:10';
INSERT INTO `s_quest` set id = 26, preid=25, `type`=1, parm1=15, parm2=0, parmCnt=1, descr='15x fragments', `count`=1500000, icon='4',rewards='1:1500000|6:20';