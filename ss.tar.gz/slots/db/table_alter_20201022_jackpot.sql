-- 425  太阳女神  sun goddess  min, minor, major, grand, maxi, mage
UPDATE `s_game` SET `jackpot` = '[15,60,500,5000,1000,2500]' WHERE id = 425;
-- 451 大功率  highpower          mini, minor, major, grand, mega
UPDATE `s_game` SET `jackpot` = '[5,10,17,167,33]' WHERE id = 451;