ALTER TABLE `d_user`
ADD COLUMN `charm`  int(11) NULL DEFAULT 0 COMMENT '魅力值' AFTER `points`;

CREATE TABLE `d_user_sendcharm` (
	`id`  int(11) NULL AUTO_INCREMENT ,
	`uid1`  bigint(20) NULL ,
	`uid2`  bigint(20) NULL ,
	`create_time`  int(11) NULL ,
	`charmid`  int NULL ,
	`title`  varchar(300) NULL ,
	`title_al`  varchar(300) NULL ,
	`img`  varchar(300) NULL DEFAULT '' ,
	`coin`  int(11) NULL ,
	`charm`  int(11) NULL ,
	PRIMARY KEY (`id`),
	INDEX `idx_uid1` (`uid1`) ,
	INDEX `idx_uid2` (`uid2`) 
) COMMENT='魅力值道具赠送记录';

DROP TABLE IF EXISTS `s_send_charm`;
CREATE TABLE `s_send_charm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_al` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` tinyint(2) DEFAULT '1' COMMENT '消耗金币或钻石',
  `count` int(11) DEFAULT '0',
  `charm` int(11) DEFAULT '0',
  `hot` tinyint(1) DEFAULT '0',
  `new` tinyint(1) DEFAULT NULL,
  `lamp` tinyint(1) DEFAULT '0' COMMENT '1播放跑马灯',
  `notice` tinyint(1) DEFAULT '0' COMMENT '1全服通告',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='魅力值道具';

INSERT INTO `s_send_charm` VALUES ('1', 'sports car', 'سيارة سباق ', 'gift_car', '1', '1000000', '1000000', '0', null, '1', '0');
INSERT INTO `s_send_charm` VALUES ('2', 'little devil', 'شيطان ', 'gift_evil', '25', '1500', '-1500', '0', null, '0', '0');
INSERT INTO `s_send_charm` VALUES ('3', 'Drink', 'مشروب ', 'gift_ice', '1', '30000', '30000', '0', null, '0', '0');
INSERT INTO `s_send_charm` VALUES ('4', 'kiss', 'قبلة', 'gift_kiss', '1', '100000', '100000', '0', null, '1', '0');
INSERT INTO `s_send_charm` VALUES ('5', 'streamer gun', 'مسدس الفلوس', 'gift_money', '1', '3000000', '3000000', '0', null, '0', '1');
INSERT INTO `s_send_charm` VALUES ('6', 'playing cards', 'ورق', 'gift_poker', '1', '1500000', '1500000', '0', null, '0', '1');
INSERT INTO `s_send_charm` VALUES ('7', 'ring', 'خاتم', 'gift_ring', '1', '500000', '500000', '0', null, '1', '0');
INSERT INTO `s_send_charm` VALUES ('8', 'tower', 'برج', 'gift_tower', '1', '80000', '80000', '0', null, '0', '0');