-- 464 海盗船 golden island treasure
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (464, "海盗船", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(464, "goldenislandtreasure", 0, 0.1, 0.1, "[10,50,500,5000]");
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 464, "海盗船", 1, 100);