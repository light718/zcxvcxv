-- 更新绑定fb的邮件奖励
update d_sys_mail set `attach`='[{"id":1,"num":1000000},{"id":25,"num":2000}]' where stype=19;