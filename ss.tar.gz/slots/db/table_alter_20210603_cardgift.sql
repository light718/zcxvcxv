update s_config set v=20000 where k='bankruptcoin';

DROP TABLE IF EXISTS `d_card_gift_record`;
CREATE TABLE `d_card_gift_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL COMMENT '用户id',
  `lv` int(11) DEFAULT '0' COMMENT '关卡',
  `placeid` int(11) DEFAULT '1' COMMENT '从上开始1到5',
  `lucky` tinyint(1) DEFAULT '0' COMMENT '0 未中奖 1中奖',
  `prize_stype` int(11) DEFAULT '1' COMMENT '奖品类型',
  `prize_num` int(11) DEFAULT '0' COMMENT '奖品数量',
  `prize_result` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开奖结果',
  `revive` tinyint(1) DEFAULT '0' COMMENT '0未复活 1复活',
  `take` tinyint(1) DEFAULT '0' COMMENT '0 不结束 1结束',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `uuid` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roundid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`,`uuid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡牌记录表';

DROP TABLE IF EXISTS `d_card_gift`;
CREATE TABLE `d_card_gift` (
  `uid` int(7) NOT NULL COMMENT '用户编号',
  `lv` int(11) DEFAULT '1' COMMENT '当前关卡',
  `jackpot` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '当前累计奖池',
  `end_time` int(11) DEFAULT '0' COMMENT '这轮结束时间',
  `status` tinyint(1) DEFAULT '1' COMMENT '1 正常 0 game over 2takeit',
  `uuid` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '批次',
  `roundid` int(11) DEFAULT '1' COMMENT '关卡轮次',
  PRIMARY KEY (`uid`),
  KEY `idx_uid` (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='卡牌记录状态表';

DROP TABLE IF EXISTS `s_card_gift`;
CREATE TABLE `s_card_gift` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `level` int(7) NOT NULL COMMENT '等级',
  `prize` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '奖品json',
  `weight` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '权重',
  PRIMARY KEY (`id`,`level`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='关卡奖品配置表';


INSERT INTO `s_card_gift` VALUES ('1', '1', '[[{\"s\":1,\"n\":20000}],[{\"s\":1,\"n\":60000}],[{\"s\":2,\"n\":2}],[{\"s\":11,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|50|0');
INSERT INTO `s_card_gift` VALUES ('2', '2', '[[{\"s\":1,\"n\":20000}],[{\"s\":1,\"n\":60000}],[{\"s\":3,\"n\":1800}],[{\"s\":11,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|100|50|50');
INSERT INTO `s_card_gift` VALUES ('3', '3', '[[{\"s\":1,\"n\":20000}],[{\"s\":1,\"n\":60000}],[{\"s\":2,\"n\":2}],[{\"s\":9,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|10|70');
INSERT INTO `s_card_gift` VALUES ('4', '4', '[[{\"s\":1,\"n\":20000}],[{\"s\":1,\"n\":60000}],[{\"s\":3,\"n\":1800}],[{\"s\":9,\"n\":1}],[{\"s\":11,\"n\":1}]]', '50|50|50|50|50');
INSERT INTO `s_card_gift` VALUES ('5', '5', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":2,\"n\":2}],[{\"s\":11,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|50|35');
INSERT INTO `s_card_gift` VALUES ('6', '6', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":3,\"n\":1800}],[{\"s\":11,\"n\":1}],[{\"s\":20,\"n\":1}]]', '80|80|80|5|55');
INSERT INTO `s_card_gift` VALUES ('7', '7', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":2,\"n\":5}],[{\"s\":11,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|20|80');
INSERT INTO `s_card_gift` VALUES ('8', '8', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":11,\"n\":1}],[{\"s\":9,\"n\":1}],[{\"s\":12,\"n\":1}]]', '50|50|50|50|5');
INSERT INTO `s_card_gift` VALUES ('9', '9', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":2,\"n\":5}],[{\"s\":11,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|20|70');
INSERT INTO `s_card_gift` VALUES ('10', '10', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":11,\"n\":1}],[{\"s\":9,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|25|70');
INSERT INTO `s_card_gift` VALUES ('11', '11', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":2,\"n\":5}],[{\"s\":11,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|25|70');
INSERT INTO `s_card_gift` VALUES ('12', '12', '[[{\"s\":1,\"n\":60000}],[{\"s\":1,\"n\":100000}],[{\"s\":11,\"n\":1}],[{\"s\":12,\"n\":1}],[{\"s\":13,\"n\":1}]]', '50|50|50|2|8');
INSERT INTO `s_card_gift` VALUES ('13', '13', '[[{\"s\":1,\"n\":100000}],[{\"s\":1,\"n\":200000}],[{\"s\":3,\"n\":3600}],[{\"s\":12,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|10|70');
INSERT INTO `s_card_gift` VALUES ('14', '14', '[[{\"s\":1,\"n\":100000}],[{\"s\":1,\"n\":200000}],[{\"s\":2,\"n\":10}],[{\"s\":12,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|50|20|70');
INSERT INTO `s_card_gift` VALUES ('15', '15', '[[{\"s\":1,\"n\":100000}],[{\"s\":1,\"n\":200000}],[{\"s\":12,\"n\":1}],[{\"s\":13,\"n\":1}],[{\"s\":20,\"n\":1}]]', '50|50|25|25|70');
INSERT INTO `s_card_gift` VALUES ('16', '16', '[[{\"s\":1,\"n\":100000}],[{\"s\":1,\"n\":200000}],[{\"s\":13,\"n\":1}],[{\"s\":1,\"n\":2000000}],[{\"s\":14,\"n\":1}]]', '50|50|25|1|5');

---- 商品信息

REPLACE INTO `s_shop` VALUES ('95', '复活卡5张', '5', '300000', '0.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.1', 'com.rummyfree.1', '', '0', '21', '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES ('96', '复活卡20张', '20', '920000', '2.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', '', '0', '21', '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES ('97', '复活卡40张', '40', '1600000', '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.4', '', '0', '21', '', '0', '0', '0', '0');

DROP TABLE IF EXISTS `s_card_gift_hero`;
CREATE TABLE `s_card_gift_hero` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `star` int(11) DEFAULT NULL,
  `cardid` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_star` (`star`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='抽卡碎片中奖概率';

INSERT INTO `s_card_gift_hero` VALUES ('1', '1', '1008', '25');
INSERT INTO `s_card_gift_hero` VALUES ('2', '1', '1015', '25');
INSERT INTO `s_card_gift_hero` VALUES ('3', '1', '1016', '25');
INSERT INTO `s_card_gift_hero` VALUES ('4', '1', '1037', '25');
INSERT INTO `s_card_gift_hero` VALUES ('5', '2', '1004', '20');
INSERT INTO `s_card_gift_hero` VALUES ('6', '2', '1009', '20');
INSERT INTO `s_card_gift_hero` VALUES ('7', '2', '1014', '20');
INSERT INTO `s_card_gift_hero` VALUES ('8', '2', '1020', '20');
INSERT INTO `s_card_gift_hero` VALUES ('9', '2', '1022', '20');
INSERT INTO `s_card_gift_hero` VALUES ('10', '2', '1026', '20');
INSERT INTO `s_card_gift_hero` VALUES ('11', '2', '1029', '20');
INSERT INTO `s_card_gift_hero` VALUES ('12', '2', '1033', '20');
INSERT INTO `s_card_gift_hero` VALUES ('13', '3', '1003', '20');
INSERT INTO `s_card_gift_hero` VALUES ('14', '3', '1007', '20');
INSERT INTO `s_card_gift_hero` VALUES ('15', '3', '1012', '20');
INSERT INTO `s_card_gift_hero` VALUES ('16', '3', '1018', '20');
INSERT INTO `s_card_gift_hero` VALUES ('17', '3', '1021', '20');
INSERT INTO `s_card_gift_hero` VALUES ('18', '3', '1023', '20');
INSERT INTO `s_card_gift_hero` VALUES ('19', '3', '1032', '20');
INSERT INTO `s_card_gift_hero` VALUES ('20', '3', '1036', '20');
INSERT INTO `s_card_gift_hero` VALUES ('21', '4', '1002', '20');
INSERT INTO `s_card_gift_hero` VALUES ('22', '4', '1005', '20');
INSERT INTO `s_card_gift_hero` VALUES ('23', '4', '1010', '20');
INSERT INTO `s_card_gift_hero` VALUES ('24', '4', '1011', '20');
INSERT INTO `s_card_gift_hero` VALUES ('25', '4', '1013', '20');
INSERT INTO `s_card_gift_hero` VALUES ('26', '4', '1017', '20');
INSERT INTO `s_card_gift_hero` VALUES ('27', '4', '1024', '20');
INSERT INTO `s_card_gift_hero` VALUES ('28', '4', '1025', '20');
INSERT INTO `s_card_gift_hero` VALUES ('29', '4', '1028', '20');
INSERT INTO `s_card_gift_hero` VALUES ('30', '4', '1031', '20');
INSERT INTO `s_card_gift_hero` VALUES ('31', '4', '1035', '20');
INSERT INTO `s_card_gift_hero` VALUES ('32', '5', '1001', '20');
INSERT INTO `s_card_gift_hero` VALUES ('33', '5', '1006', '20');
INSERT INTO `s_card_gift_hero` VALUES ('34', '5', '1019', '20');
INSERT INTO `s_card_gift_hero` VALUES ('35', '5', '1027', '20');
INSERT INTO `s_card_gift_hero` VALUES ('36', '5', '1030', '20');
INSERT INTO `s_card_gift_hero` VALUES ('37', '5', '1034', '20');