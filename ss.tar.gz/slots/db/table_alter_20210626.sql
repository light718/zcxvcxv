ALTER TABLE `d_offline_multi_cmd` MODIFY COLUMN `param`  varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '参数' AFTER `cmd`;
