-- 修改冰狼jackpot倍数
UPDATE `s_game` SET `jackpot` = '[5,10,500,1000,5000]' WHERE id = 479;