-- 更新vip权益配置
-- 只改了刮刮乐，商城每日赠送，
TRUNCATE TABLE `s_config_vip_upgrade`;
INSERT INTO `s_config_vip_upgrade` VALUES 
(1,1,100,'{\"slots\":0.1,\"scratch\":0.1,\"gift\":5000,\"store\":1,\"daily\":2500,\"inboxcollect\":0,\"fanpage\":1,\"turntable\":0.1}'),
(2,2,1000,'{\"slots\":0.15,\"scratch\":0.15,\"gift\":50000,\"store\":2,\"daily\":25000000,\"inboxcollect\":0,\"fanpage\":5,\"turntable\":0.25}'),
(3,3,10000,'{\"slots\":0.3,\"scratch\":0.3,\"gift\":200000,\"store\":4,\"daily\":10000000,\"inboxcollect\":1,\"fanpage\":20,\"turntable\":0.5}'),
(4,4,20000,'{\"slots\":0.5,\"scratch\":0.5,\"gift\":500000,\"store\":7,\"daily\":40000000,\"inboxcollect\":1,\"fanpage\":40,\"turntable\":1}'),
(5,5,40000,'{\"slots\":0.6,\"scratch\":0.6,\"gift\":1000000,\"store\":10,\"daily\":100000000,\"inboxcollect\":1,\"fanpage\":100,\"turntable\":2}'),
(6,6,60000,'{\"slots\":1,\"scratch\":0.8,\"gift\":2000000,\"store\":20,\"daily\":300000000,\"inboxcollect\":1,\"fanpage\":200,\"turntable\":3}'),
(7,7,100000,'{\"slots\":1,\"scratch\":1,\"gift\":2000000,\"store\":20,\"daily\":300000000,\"inboxcollect\":1,\"fanpage\":200,\"turntable\":4}'),
(8,0,0,'{\"slots\":0,\"scratch\":0,\"gift\":0,\"store\":0,\"daily\":0,\"inboxcollect\":0,\"fanpage\":0}');