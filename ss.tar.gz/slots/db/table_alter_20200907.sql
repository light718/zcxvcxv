ALTER TABLE `d_user` ADD COLUMN `fcmtoken` varchar(512) NULL COMMENT 'fcmtoken';
insert into s_game(id,title,status,ord,allincontrol) value(250, '印度拉米', 1, 100,"");
INSERT INTO `s_game_type`(gametype,gameid,title,state,hot) VALUE ('6', '250', "indrummy", '1', '100');
INSERT INTO `s_sess`(gameid,title,basecoin,mincoin,leftcoin,hot,status,ord,free,level,param1,param2,param3,param4,revenue,seat,chips) VALUE ('250', '印度拉米初级场', '1', '100', '1', '1', '1', '100', '0', '2', '50', '0', '0', '0', '5', '0', '5');
INSERT INTO `s_sess`(gameid,title,basecoin,mincoin,leftcoin,hot,status,ord,free,level,param1,param2,param3,param4,revenue,seat,chips) VALUE ('250', '印度拉米中级场', '1', '500', '1', '1', '1', '100', '0', '3', '50', '0', '0', '0', '8', '0', '5');
INSERT INTO `s_sess`(gameid,title,basecoin,mincoin,leftcoin,hot,status,ord,free,level,param1,param2,param3,param4,revenue,seat,chips) VALUE ('250', '印度拉米高级场', '1', '3000', '1', '1', '1', '100', '0', '4', '50', '0', '0', '0', '10', '0', '5');
INSERT INTO `s_sess`(gameid,title,basecoin,mincoin,leftcoin,hot,status,ord,free,level,param1,param2,param3,param4,revenue,seat,chips) VALUE ('250', '印度拉米VIP场', '1', '10000', '1', '1', '1', '100', '0', '5', '50', '0', '0', '0', '10', '0', '5');


update s_shop set productid_gp='com.rummyfree.1' where productid_gp='com.rummyslots.gold1';
update s_shop set productid_gp='com.rummyfree.2' where productid_gp='com.rummyslots.gold2';
update s_shop set productid_gp='com.rummyfree.3' where productid_gp='com.rummyslots.gold3';
update s_shop set productid_gp='com.rummyfree.4' where productid_gp='com.rummyslots.gold4';
update s_shop set productid_gp='com.rummyfree.5' where productid_gp='com.rummyslots.gold5';
update s_shop set productid_gp='com.rummyfree.6' where productid_gp='com.rummyslots.gold6';
update s_shop set productid_gp='com.rummyfree.7' where productid_gp='com.rummyslots.gold7';
update s_shop set productid_gp='com.rummyfree.8' where productid_gp='com.rummyslots.gold8';
update s_shop set productid_gp='com.rummyfree.9' where productid_gp='com.rummyslots.gold9';
update s_shop set productid_gp='com.rummyfree.10' where productid_gp='com.rummyslots.gold10';
update s_shop set productid_gp='com.rummyfree.11' where productid_gp='com.rummyslots.gold11';
update s_shop set productid_gp='com.rummyfree.12' where productid_gp='com.rummyslots.gold13';
update s_shop set productid_gp='com.rummyfree.13' where productid_gp='com.rummyslots.gold14';


ALTER TABLE `s_send_coin` ADD COLUMN `level` int(11) NULL DEFAULT 0 COMMENT '等级' AFTER `act`,ADD COLUMN `scale` float(5, 2) NULL COMMENT '奖励比例' AFTER `level`,ADD INDEX `time`(`create_time`);

update s_game_type set state=1 where gameid in (420,421,422);
update s_game_type set state=0 where gameid >=424 and gameid<=428;