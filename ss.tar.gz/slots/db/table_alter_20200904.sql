ALTER TABLE `d_user` ADD COLUMN `moneybag` bigint(20) NULL COMMENT '金猪金币数';
replace into `s_config` (id, k, v, memo) value (40, "moneybag", '{"bag":37500,"bonus":9000000,"addrate":0.008}', '金猪');
ALTER TABLE `s_shop` MODIFY COLUMN `stype` tinyint(1) NULL DEFAULT NULL COMMENT '类型1商城 2限时优惠 3转盘 4激励礼包 5等级礼包 6签到 7首充礼包 8onetimeonly 9排行榜时榜 10金猪' AFTER `appid`;
INSERT INTO `s_shop`(id,title,ocount,count,amount,vipExp,icon,discount,discountTime,`level`,ord,`status`,cuid,uuid,productid,productid_gp,appid,stype,benefit,cat) VALUE (67, '金猪', NULL, 0, 1.99, 108, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold2', 'com.rummyfree.2', 0, 10, '', 0);
ALTER TABLE `d_user_firstbuy` ADD COLUMN `stype` int(11) default 0 COMMENT '商品类型' AFTER `create_time`;