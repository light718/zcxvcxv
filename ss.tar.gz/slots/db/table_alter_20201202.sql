update d_robot set img=replace(img,'http://global.9you.net/mllm','https://jp.inter.rummyslot.com');


update s_game set jackpot='[5,10,500,5000]' where id=440;
update s_game set jackpot='[5,10,300,5000]' where id=472;