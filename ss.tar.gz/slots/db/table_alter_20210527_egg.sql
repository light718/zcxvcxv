-- 设置collect Bonus每日奖励金币数量
INSERT INTO s_config (k, v, memo) VALUES ('collect_bonus_coin', 225000, '商城每日奖励金币数量(银蛋在代码中实现)');

DROP TABLE IF EXISTS `s_egg`;
CREATE TABLE `s_egg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT '0' COMMENT '开启等级',
  `type` tinyint(1) DEFAULT NULL COMMENT '1银蛋 2金蛋',
  `rewards` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '奖励, 格式: 类型:数量:备注|类型:数量:备注, eg: 1:200000|2:50|8:1:1',
  `coin` int(11) DEFAULT '0' COMMENT '蛋的价值,用于剩余兑换',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='蛋蛋配置';

INSERT INTO `s_egg` VALUES (1, 20, 1, '1:1500000|8:1:1|3:1', 1500);
INSERT INTO `s_egg` VALUES (2, 20, 2, '1:9000000|2:50|8:1:1|8:1:2|3:2', 9000);

DROP TABLE IF EXISTS `d_egg_record`;
CREATE TABLE `d_egg_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0' COMMENT '用户uid',
  `type` tinyint(2) DEFAULT '1' COMMENT '1银锤子 2金锤子',
  `create_time` int(11) DEFAULT '0' COMMENT '获取时间',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='锤子记录获取表';

DROP TABLE IF EXISTS `d_egg_info`;
CREATE TABLE `d_egg_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT '0' UNIQUE COMMENT '用户uid',
  `end_time` int(11) DEFAULT 0 COMMENT '结束时间',
  `sliver_hammer` int(11) DEFAULT 0 COMMENT '银锤子数量',
  `gold_hammer` int(11) DEFAULT 0 COMMENT '金锤子数量',
  `sliver_hammer_record` varchar(255) DEFAULT '0|0|0|0|0|0|0' COMMENT '银锤子获得记录 0代表未获取',
  `gold_hammer_record` varchar(255) DEFAULT '0|0|0|0|0|0|0' COMMENT '银锤子获得记录 0代表未获取',
  `sliver_egg` varchar(255) DEFAULT '0|0|0|0|0|0|0' COMMENT '银蛋的信息 0代表砸完，其他代表权重表的id',
  `gold_egg` varchar(255) DEFAULT '0|0|0|0|0|0|0' COMMENT '金蛋的信息 0代表砸完，其他代表权重表的id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='每次活动蛋的信息';

DROP TABLE IF EXISTS `s_herocard_event_drop`;
CREATE TABLE `s_herocard_event_drop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cardid` int(11) NOT NULL COMMENT '卡牌ID',
  `etype` int(11) NOT NULL COMMENT '活动类型',
  `groupid` int(11) NOT NULL COMMENT '卡牌组',
  `drop_weight` int(11) NOT NULL COMMENT '掉落权重',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='特殊活动卡牌掉落概率';

-- 牌库1
INSERT INTO `s_herocard_event_drop` VALUES(1, 1008, 1, 1, 100);
INSERT INTO `s_herocard_event_drop` VALUES(2, 1015, 1, 1, 100);
INSERT INTO `s_herocard_event_drop` VALUES(3, 1016, 1, 1, 100);
INSERT INTO `s_herocard_event_drop` VALUES(4, 1037, 1, 1, 100);
INSERT INTO `s_herocard_event_drop` VALUES(5, 1003, 1, 1, 120);
INSERT INTO `s_herocard_event_drop` VALUES(6, 1007, 1, 1, 120);
INSERT INTO `s_herocard_event_drop` VALUES(7, 1012, 1, 1, 120);
INSERT INTO `s_herocard_event_drop` VALUES(8, 1018, 1, 1, 120);
INSERT INTO `s_herocard_event_drop` VALUES(9, 1021, 1, 1, 120);

-- 牌库2
INSERT INTO `s_herocard_event_drop` VALUES(10, 1023, 1, 2, 100);
INSERT INTO `s_herocard_event_drop` VALUES(11, 1032, 1, 2, 100);
INSERT INTO `s_herocard_event_drop` VALUES(12, 1036, 1, 2, 100);
INSERT INTO `s_herocard_event_drop` VALUES(13, 1002, 1, 2, 200);
INSERT INTO `s_herocard_event_drop` VALUES(14, 1005, 1, 2, 200);
INSERT INTO `s_herocard_event_drop` VALUES(15, 1010, 1, 2, 200);
INSERT INTO `s_herocard_event_drop` VALUES(16, 1011, 1, 2, 200);
INSERT INTO `s_herocard_event_drop` VALUES(17, 1013, 1, 2, 200);
INSERT INTO `s_herocard_event_drop` VALUES(18, 1017, 1, 2, 200);
INSERT INTO `s_herocard_event_drop` VALUES(19, 1001, 1, 2, 300);
INSERT INTO `s_herocard_event_drop` VALUES(20, 1006, 1, 2, 300);
INSERT INTO `s_herocard_event_drop` VALUES(21, 1019, 1, 2, 300);

-- 商品锤子
REPLACE INTO `s_shop` VALUES (82, '银锤子', null, 1, '0.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.1', 'com.rummyfree.1', '', '0', 19, '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES (83, '银锤子', null, 3, '1.99', '0', null, '0', '0', '1', '10', '1', '0', '0',  'spinxstudio.pack.2', 'com.rummyfree.2', '', '0', 19, '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES (84, '银锤子', null, 5, '2.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', '', '0', 19, '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES (85, '银锤子', null, 7, '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0','spinxstudio.pack.4', 'com.rummyfree.5', '', '0', 19, '', '0', '0', '0', '0');

REPLACE INTO `s_shop` VALUES (91, '金锤子', null, 1, '1.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', '', '0', 20, '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES (92, '金锤子', null, 3, '2.99', '0', null, '0', '0', '1', '10', '1', '0', '0',  'spinxstudio.pack.3', 'com.rummyfree.3', '', '0', 20, '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES (93, '金锤子', null, 5, '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.5', '', '0', 20, '', '0', '0', '0', '0');
REPLACE INTO `s_shop` VALUES (94, '金锤子', null, 7, '9.99', '0', null, '0', '0', '1', '10', '1', '0', '0','spinxstudio.pack.5', 'com.rummyfree.10', '', '0', 20, '', '0', '0', '0', '0');
