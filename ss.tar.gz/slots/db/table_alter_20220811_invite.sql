CREATE TABLE `d_user_invite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `playername` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usericon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invit_uid` bigint(20) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '0未领取奖励 1已领取奖励',
  `ord` int(11) DEFAULT '1' COMMENT '第N个',
  `rewards` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `invite` (`invit_uid`,`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='好友邀请列表';

