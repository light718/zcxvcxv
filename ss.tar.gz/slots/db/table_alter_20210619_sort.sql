INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    630, "阿拉丁神灯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 442;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    630, "lampofaladdin", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 442;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 630, "阿拉丁神灯", state, 500
FROM
    `s_game_type`
WHERE
    gameid = 442;


INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    631, "美人鱼", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 424;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    631, "themermaid", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 424;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 631, "美人鱼", state, 500
FROM
    `s_game_type`
WHERE
    gameid = 424;


INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    632, "吟游诗人", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 423;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    632, "theminstrel", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 423;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 632, "吟游诗人", state, 500
FROM
    `s_game_type`
WHERE
    gameid = 423;

INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    633, "青蛙王子", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 449;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    633, "thefrogprince", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 449;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 633, "青蛙王子", state, 500
FROM
    `s_game_type`
WHERE
    gameid = 449;



replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (496, "崛起的美杜莎", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(496, "risingmedush", 0, 0.1, 0.1, '[5,20,100,5000,1000]', '[4,6,9,16,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 496, "崛起的美杜莎", 1, 500);

update s_game set gametag=0 where id in (select gameid from s_game_type where gametype=2);
update s_game_type set `taghot`=0 where  taghot>0;
update s_game_type set `hot`=500 where gametype=2 and gameid>=419;
update s_game set `level`=0 where id >= 419;

update s_game set gametag = 2, `level`=0 where id in (630,633);

update s_game set gametag = 1, `level`=0 where id in (458,483);

update s_game set `level`=5 where id = 601;
update s_game set `level`=10 where id = 605;
update s_game set `level`=15 where id = 613;
update s_game set `level`=20 where id = 616;
update s_game set `level`=25 where id = 602;
update s_game set `level`=30 where id = 610;
update s_game set `level`=35 where id = 611;
update s_game set `level`=50 where id = 490;
update s_game set `level`=55 where id = 437;
update s_game set `level`=60 where id = 428;
update s_game set `level`=65 where id = 425;
update s_game set `level`=70 where id = 476;
update s_game set `level`=75 where id = 500;

update s_game set `level`=10 where id = 621;
update s_game set `level`=80 where id = 449;
update s_game set `level`=85 where id = 441;
update s_game set `level`=90 where id = 502;
update s_game set `level`=95 where id = 474;
update s_game set `level`=100 where id = 439;
update s_game set `level`=105 where id = 459;
update s_game set `level`=110 where id = 443;
update s_game set `level`=115 where id = 423;
update s_game set `level`=120 where id = 488;
update s_game set `level`=125 where id = 450;
update s_game set `level`=130 where id = 479;
update s_game set `level`=135 where id = 489;
update s_game set `level`=140 where id = 487;
update s_game set `level`=145 where id = 492;
update s_game set `level`=150 where id = 469;
update s_game set `level`=155 where id = 446;
update s_game set `level`=160 where id = 473;
update s_game set `level`=165 where id = 419;
update s_game set `level`=170 where id = 472;
update s_game set `level`=175 where id = 466;

update s_game set `level`=15 where id = 603;
update s_game set `level`=30 where id = 612;
update s_game set `level`=35 where id = 637;
update s_game set `level`=40 where id = 636;
update s_game set `level`=180 where id = 442;
update s_game set `level`=185 where id = 424;
update s_game set `level`=190 where id = 477;
update s_game set `level`=195 where id = 498;
update s_game set `level`=200 where id = 483;
update s_game set `level`=205 where id = 497;
update s_game set `level`=210 where id = 433;
update s_game set `level`=215 where id = 448;
update s_game set `level`=220 where id = 462;
update s_game set `level`=225 where id = 434;
update s_game set `level`=230 where id = 464;
update s_game set `level`=235 where id = 435;
update s_game set `level`=240 where id = 429;

update s_game set `level`=20 where id = 640;
update s_game set `level`=245 where id = 458;
update s_game set `level`=250 where id = 432;
update s_game set `level`=255 where id = 420;
update s_game set `level`=260 where id = 463;
update s_game set `level`=265 where id = 480;
update s_game set `level`=270 where id = 465;
update s_game set `level`=275 where id = 481;
update s_game set `level`=280 where id = 475;
update s_game set `level`=285 where id = 460;
update s_game set `level`=290 where id = 482;
update s_game set `level`=295 where id = 440;
update s_game set `level`=300 where id = 470;
update s_game set `level`=305 where id = 467;
update s_game set `level`=310 where id = 456;

update s_game set `level`=25 where id = 609;
update s_game set `level`=40 where id = 625;
update s_game set `level`=45 where id = 618;
update s_game set `level`=315 where id = 421;
update s_game set `level`=320 where id = 478;
update s_game set `level`=325 where id = 468;
update s_game set `level`=330 where id = 484;
update s_game set `level`=335 where id = 493;
update s_game set `level`=340 where id = 452;
update s_game set `level`=345 where id = 422;
update s_game set `level`=350 where id = 454;
update s_game set `level`=355 where id = 455;
update s_game set `level`=360 where id = 471;
update s_game set `level`=365 where id = 427;
update s_game set `level`=370 where id = 461;
update s_game set `level`=375 where id = 436;
update s_game set `level`=380 where id = 451;
update s_game set `level`=385 where id = 453;
update s_game set `level`=390 where id = 447;
update s_game set `level`=395 where id = 495;
update s_game set `level`=400 where id = 491;
update s_game set `level`=405 where id = 499;
update s_game set `level`=410 where id = 426;
update s_game set `level`=415 where id = 506;
update s_game set `level`=420 where id = 503;
update s_game set `level`=425 where id = 494;
update s_game set `level`=430 where id = 504;
update s_game set `level`=435 where id = 505;
update s_game set `level`=440 where id = 507;
update s_game set `level`=445 where id = 508;
update s_game set `level`=450 where id = 444;
update s_game set `level`=455 where id = 509;
update s_game set `level`=460 where id = 510;
update s_game set `level`=465 where id = 511;
update s_game set `level`=470 where id = 512;
update s_game set `level`=475 where id = 631;
update s_game set `level`=480 where id = 632;
update s_game set `level`=485 where id = 496;

update s_game_type set `hot`=10 where  gameid = 601;
update s_game_type set `hot`=11 where  gameid = 605;
update s_game_type set `hot`=12 where  gameid = 613;
update s_game_type set `hot`=13 where  gameid = 616;
update s_game_type set `hot`=14 where  gameid = 602;
update s_game_type set `hot`=15 where  gameid = 610;
update s_game_type set `hot`=16 where  gameid = 611;
update s_game_type set `hot`=17 where  gameid = 490;
update s_game_type set `hot`=18 where  gameid = 437;
update s_game_type set `hot`=19 where  gameid = 428;
update s_game_type set `hot`=20 where  gameid = 425;
update s_game_type set `hot`=21 where  gameid = 476;
update s_game_type set `hot`=22 where  gameid = 500;

update s_game_type set `hot`=50 where  gameid = 621;
update s_game_type set `hot`=51 where  gameid = 449;
update s_game_type set `hot`=52 where  gameid = 441;
update s_game_type set `hot`=53 where  gameid = 502;
update s_game_type set `hot`=54 where  gameid = 474;
update s_game_type set `hot`=55 where  gameid = 439;
update s_game_type set `hot`=56 where  gameid = 459;
update s_game_type set `hot`=57 where  gameid = 443;
update s_game_type set `hot`=58 where  gameid = 423;
update s_game_type set `hot`=59 where  gameid = 488;
update s_game_type set `hot`=60 where  gameid = 450;
update s_game_type set `hot`=61 where  gameid = 479;
update s_game_type set `hot`=62 where  gameid = 489;
update s_game_type set `hot`=63 where  gameid = 487;
update s_game_type set `hot`=64 where  gameid = 492;
update s_game_type set `hot`=65 where  gameid = 469;
update s_game_type set `hot`=66 where  gameid = 446;
update s_game_type set `hot`=67 where  gameid = 473;
update s_game_type set `hot`=68 where  gameid = 419;
update s_game_type set `hot`=69 where  gameid = 472;
update s_game_type set `hot`=70 where  gameid = 466;

update s_game_type set `hot`=100 where  gameid = 603;
update s_game_type set `hot`=101 where  gameid = 612;
update s_game_type set `hot`=102 where  gameid = 637;
update s_game_type set `hot`=103 where  gameid = 636;
update s_game_type set `hot`=104 where  gameid = 442;
update s_game_type set `hot`=105 where  gameid = 424;
update s_game_type set `hot`=106 where  gameid = 477;
update s_game_type set `hot`=107 where  gameid = 498;
update s_game_type set `hot`=108 where  gameid = 483;
update s_game_type set `hot`=109 where  gameid = 497;
update s_game_type set `hot`=110 where  gameid = 433;
update s_game_type set `hot`=111 where  gameid = 448;
update s_game_type set `hot`=112 where  gameid = 462;
update s_game_type set `hot`=113 where  gameid = 434;
update s_game_type set `hot`=114 where  gameid = 464;
update s_game_type set `hot`=115 where  gameid = 435;
update s_game_type set `hot`=116 where  gameid = 429;

update s_game_type set `hot`=150 where  gameid = 640;
update s_game_type set `hot`=151 where  gameid = 458;
update s_game_type set `hot`=152 where  gameid = 432;
update s_game_type set `hot`=153 where  gameid = 420;
update s_game_type set `hot`=154 where  gameid = 463;
update s_game_type set `hot`=155 where  gameid = 480;
update s_game_type set `hot`=156 where  gameid = 465;
update s_game_type set `hot`=157 where  gameid = 481;
update s_game_type set `hot`=158 where  gameid = 475;
update s_game_type set `hot`=159 where  gameid = 460;
update s_game_type set `hot`=160 where  gameid = 482;
update s_game_type set `hot`=161 where  gameid = 440;
update s_game_type set `hot`=162 where  gameid = 470;
update s_game_type set `hot`=163 where  gameid = 467;
update s_game_type set `hot`=164 where  gameid = 456;

update s_game_type set `hot`=200 where  gameid = 609;
update s_game_type set `hot`=201 where  gameid = 625;
update s_game_type set `hot`=202 where  gameid = 618;
update s_game_type set `hot`=203 where  gameid = 421;
update s_game_type set `hot`=204 where  gameid = 478;
update s_game_type set `hot`=205 where  gameid = 468;
update s_game_type set `hot`=206 where  gameid = 484;
update s_game_type set `hot`=207 where  gameid = 493;
update s_game_type set `hot`=208 where  gameid = 452;
update s_game_type set `hot`=209 where  gameid = 422;
update s_game_type set `hot`=210 where  gameid = 454;
update s_game_type set `hot`=211 where  gameid = 455;
update s_game_type set `hot`=212 where  gameid = 471;
update s_game_type set `hot`=213 where  gameid = 427;
update s_game_type set `hot`=214 where  gameid = 461;
update s_game_type set `hot`=215 where  gameid = 436;
update s_game_type set `hot`=216 where  gameid = 451;
update s_game_type set `hot`=217 where  gameid = 453;
update s_game_type set `hot`=218 where  gameid = 447;
update s_game_type set `hot`=219 where  gameid = 495;
update s_game_type set `hot`=220 where  gameid = 491;
update s_game_type set `hot`=221 where  gameid = 499;
update s_game_type set `hot`=222 where  gameid = 426;
update s_game_type set `hot`=223 where  gameid = 506;
update s_game_type set `hot`=224 where  gameid = 503;
update s_game_type set `hot`=225 where  gameid = 494;
update s_game_type set `hot`=226 where  gameid = 504;
update s_game_type set `hot`=227 where  gameid = 505;
update s_game_type set `hot`=228 where  gameid = 507;
update s_game_type set `hot`=229 where  gameid = 508;
update s_game_type set `hot`=230 where  gameid = 444;
update s_game_type set `hot`=231 where  gameid = 509;
update s_game_type set `hot`=232 where  gameid = 510;

update s_game_type set `hot`=233 where  gameid = 511;
update s_game_type set `hot`=234 where  gameid = 512;
update s_game_type set `hot`=235 where  gameid = 631;
update s_game_type set `hot`=236 where  gameid = 632;
update s_game_type set `hot`=237 where  gameid = 496;

-- hot
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=458&type=2&ord=1'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=483&type=2&ord=3'

-- new
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=630&type=2&ord=2'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=633&type=2&ord=4'
