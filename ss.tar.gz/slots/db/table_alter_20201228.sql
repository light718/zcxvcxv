replace into `s_config` (id, k, v, memo)  value (46, 'payurl_google', "http://pay.rummyslot.com/giap.php",'google支付验证地址');

--灿烂的岛屿大 splendidIslandDeluxe

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (476, "灿烂的岛屿大 ", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(476, "splendidIslandDeluxe", 0, 0.1, 0.1, '[5,20,300,1000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 476, "灿烂的岛屿大 ", 1, 100);
