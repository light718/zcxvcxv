-- pvp战斗记录表，用来记录pvp的战斗
DROP TABLE `d_pvp_record`;
CREATE TABLE `d_pvp_record`
(
    `id`  int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `a_uid` int(11) NOT NULL COMMENT '进攻方uid',
    `d_uid` int(11) NOT NULL COMMENT '防御方uid',
    `a_score` int(11) NOT NULL COMMENT '进攻方获得分数',
    `d_score` int(11) NOT NULL COMMENT '防御方获得分数',
    `createtime` int(11) NOT NULL COMMENT '创建时间',
    `result`  varchar(16000)   NOT NULL COMMENT '战斗结果'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='pvp战斗记录表';