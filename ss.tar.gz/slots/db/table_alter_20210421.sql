-- 添加遗失的游戏

-- 633 青蛙王子 The Frog Prince
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    633, "青蛙王子", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 449
LIMIT 1;
