ALTER TABLE `d_user` 
MODIFY COLUMN `coin` decimal(30, 2) NULL DEFAULT NULL COMMENT '金币数' AFTER `create_platform`;

ALTER TABLE `q_coins_log` 
MODIFY COLUMN `coin` decimal(30, 2) NULL DEFAULT NULL COMMENT '金币数' AFTER `game_identification`;