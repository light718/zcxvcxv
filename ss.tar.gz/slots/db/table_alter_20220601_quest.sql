-- 修改活跃值奖励
update s_new_activity_reward set rewards='2:5' where id=3;
update s_new_activity_reward set rewards='13:1' where id=4;

ALTER TABLE `d_new_quest` ADD `prev_quest` int NULL COMMENT '前置任务' AFTER `params`;

ALTER TABLE `s_new_quest` ADD `grade` ENUM('Low', 'Medium', 'High') DEFAULT 'LOW' COMMENT '任务难度等级' AFTER `diamond`;

-- 清理旧的数据
DELETE FROM `d_new_quest` WHERE questid<13;
-- 清理redis中的数据
-- redis-cli -n 13 -a xingC99 keys "d_new_quest:*" | xargs redis-cli -n 13 -a xingC99 del

REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (1,1,1,'Spin 30 times.','30',50,'Low',NULL,'1:20000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (2,1,14,'Bet 3 different slots.','3',50,'Low',1,'1:50000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (3,1,2,'Win a total of %d coins.','500000',100,'Medium',2,'1:80000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (4,1,7,'Bet %d in a single spin 10 times.','10,80000',100,'Medium',3,'1:100000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (5,1,4,'Get 3 big wins.','3,1',100,'High',4,'1:120000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (6,1,17,'Play any slot for 30 minutes.','30',100,'Medium',5,'1:140000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (7,1,3,'Bet a total of %d Coins.','1000000',100,'Medium',6,'1:160000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (8,1,1,'Spin 50 times.','50',100,'Medium',7,'1:200000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (9,1,4,'Get 2 huge wins.','2,2',220,'High',8,'1:300000|11:10|8:1',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (10,1,15,'Level up 1 time.','1',250,'Medium',9,'1:400000|11:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (11,1,3,'Bet a total of %d Coins.','50000000',280,'High',10,'1:500000|11:10|8:2',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (12,1,16,'Share to Facebook 1 time.','1',300,'Low',11,'1:600000|11:10|10:100',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (21,2,6,'Scratch&win 10 times.','10',100,'Low',NULL,'1:200000|12:10',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (22,2,7,'Bet %d in a single spin 40 times.','40,200000',100,'Low',NULL,'1:400000|12:10|8:1',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (23,2,5,'Get 80 fragments.','80',300,'Low',NULL,'1:500000|12:10|10:100',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (24,2,8,'Play lucky flipcard for 5 times.','5',120,'Low',NULL,'1:600000|12:10|8:2',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (25,2,9,'Win %d in a single spin 50 times.','50,200000',150,'Low',NULL,'1:500000|12:10|2:50',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (26,2,10,'Share to Facebook for 5 days.','5',200,'Low',NULL,'1:600000|12:10|10:100',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (27,2,11,'Earn 1000 hero palace points.','1000',200,'Low',NULL,'1:600000|12:10|8:2',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (28,2,1,'Spin 2500 times.','2500',100,'Low',NULL,'1:500000|12:10|8:2',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (29,2,12,'Make a purchase.','1',300,'Low',NULL,'1:1000000|12:10|8:5',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (30,2,13,'Unlock or evolve 3 heroes.','3',300,'Low',NULL,'1:1500000|12:10|25:300',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (31,2,2,'Win a total of %d coins.','4000000',250,'Low',NULL,'1:1000000|12:10|10:200',NULL);
REPLACE INTO `s_new_quest` (`id`, `type`, `kind`, `detail`, `params`, `diamond`, `grade`, `prev_quest`, `rewards`, `jump_to`) 
    VALUES (32,2,3,'Bet a total of %d coins.','6000000',250,'Low',NULL,'1:1200000|12:10|2:200',NULL);

-- 清理主线任务中的重复数据
delete from d_main_task 
where (uid, taskid, type) 
in (
    select t1.uid, t1.taskid, t1.type 
    from (
        select uid, taskid, type 
        from d_main_task 
        group by `uid`,`taskid`,`type` 
        having count(1) > 1
        ) t1
    )
and id not in (
    select id 
    from (
        select MAX(a1.id) as id, a1.uid, a1.taskid, a1.type ,a2.state
        from d_main_task a1
        left join (
                select max(state) as state, uid, taskid, type 
                from d_main_task
                group by `uid`, `taskid`, `type` 
                having count(id) > 1
            ) a2
            on a1.state=a2.state and a1.uid=a2.uid and a1.type=a2.type and a1.taskid=a2.taskid
        where a2.state is not null
        group by `uid`,`taskid`,`type`
    ) t2
);

-- 增加约束
ALTER TABLE d_main_task ADD CONSTRAINT uqx_dmt UNIQUE(`uid`,`taskid`, `type`)