-- 更改砸蛋配置，切换卡牌奖励为几星的模式
UPDATE `s_egg` SET  `rewards` = '1:1500000|8:1:2|3:1', `coin` = 1500000 WHERE `type` = 1;
UPDATE `s_egg` SET  `rewards` = '1:9000000|2:50|8:1:3|8:1:5|3:2', `coin` = 9000000 WHERE `type` = 2;

UPDATE `s_shop` SET `count` = 1800000 WHERE `stype` = 22;
UPDATE `s_shop` SET `count` = 600000, `amount` = '1.99', `productid` = 'spinxstudio.pack.2', `productid_gp` = 'com.rummyfree.2' WHERE `stype` = 23;

DROP TABLE s_herocard_event_drop;