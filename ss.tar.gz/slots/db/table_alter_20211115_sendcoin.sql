ALTER TABLE `s_send_coin`
MODIFY COLUMN `scale`  float(10,2) NULL DEFAULT NULL COMMENT '奖励比例' AFTER `level`;

ALTER TABLE `d_new_quest`
MODIFY COLUMN `need`  bigint(20) NOT NULL COMMENT '需要的数量' AFTER `params`;

ALTER TABLE `d_new_quest`
MODIFY COLUMN `count`  bigint(20) NULL DEFAULT NULL COMMENT '目前完成的数量' AFTER `need`;