-- 任务内容调整
update s_game_task set gameid=601 where taskid=2;
update s_game_task_detail set `value`=30 where taskid=4 and roundid=1 and detailid=1;
update s_game_task_detail set `value`=60 where taskid=6 and roundid=1 and detailid=1;
update s_game_task_detail set `value`=2000000 where taskid=6 and roundid=1 and detailid=3;

update s_game_task_detail set `value`=8000000 where taskid=5 and roundid=1 and detailid=1;
update s_game_task_detail set `value`=40 where taskid=5 and roundid=1 and detailid=2;

update s_game_task_detail set `value`=1, `key`=8, `param2`=null where taskid=2 and roundid=1 and detailid=1;