DROP TABLE IF EXISTS `s_herocard_common_drop`;
CREATE TABLE `s_herocard_common_drop` (
  `id` int(11) NOT NULL,
  `star` int(11) DEFAULT '0' COMMENT '星级',
  `cardid` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of s_herocard_common_drop
-- ----------------------------
INSERT INTO `s_herocard_common_drop` VALUES ('1', '1', '1001', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('2', '1', '1006', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('3', '1', '1019', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('4', '1', '1027', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('5', '1', '1030', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('6', '1', '1034', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('7', '1', '1047', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('8', '1', '1053', '20');
INSERT INTO `s_herocard_common_drop` VALUES ('9', '2', '1002', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('10', '2', '1005', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('11', '2', '1010', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('12', '2', '1011', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('13', '2', '1013', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('14', '2', '1017', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('15', '2', '1024', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('16', '2', '1025', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('17', '2', '1028', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('18', '2', '1031', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('19', '2', '1035', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('20', '2', '1041', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('21', '2', '1042', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('22', '2', '1045', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('23', '2', '1046', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('24', '2', '1050', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('25', '2', '1052', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('26', '2', '1060', '40');
INSERT INTO `s_herocard_common_drop` VALUES ('27', '3', '1003', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('28', '3', '1007', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('29', '3', '1012', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('30', '3', '1018', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('31', '3', '1021', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('32', '3', '1023', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('33', '3', '1032', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('34', '3', '1036', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('35', '3', '1039', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('36', '3', '1043', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('37', '3', '1049', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('38', '3', '1051', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('39', '3', '1059', '80');
INSERT INTO `s_herocard_common_drop` VALUES ('40', '4', '1004', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('41', '4', '1009', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('42', '4', '1014', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('43', '4', '1020', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('44', '4', '1022', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('45', '4', '1026', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('46', '4', '1029', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('47', '4', '1033', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('48', '4', '1038', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('49', '4', '1044', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('50', '4', '1054', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('51', '4', '1057', '120');
INSERT INTO `s_herocard_common_drop` VALUES ('52', '5', '1008', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('53', '5', '1015', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('54', '5', '1016', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('55', '5', '1037', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('56', '5', '1040', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('57', '5', '1048', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('58', '5', '1055', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('59', '5', '1056', '320');
INSERT INTO `s_herocard_common_drop` VALUES ('60', '5', '1058', '320');