update s_quest set missionstar=200 where id=1;
update s_quest set missionstar=200 where id=2;
update s_quest set missionstar=300 where id=3;
update s_quest set missionstar=300 where id=4;
update s_quest set missionstar=600 where id=5;

update s_quest set parm1=3, parmCnt=1 where id=2;
update s_quest set parm1=5, parmCnt=1 where id=3;

DROP TABLE IF EXISTS `s_mission_level`;
CREATE TABLE `s_mission_level` (
  `sessionid` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `star` int(11) NOT NULL,
  `rewardid1` int(11) NOT NULL,
  `rewardnum1` int(11) NOT NULL,
  `rewardid2` int(11) NOT NULL,
  `rewardnum2` int(11) NOT NULL,
  `passrewardid1` int(11) NOT NULL,
  `passrewardnum1` int(11) NOT NULL,
  `passrewardid2` int(11) NOT NULL,
  `passrewardnum2` int(11) NOT NULL,
  PRIMARY KEY (`sessionid`,`level`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `s_mission_level` VALUES (1, 1, 100, 0, 0, 0, 0, 1, 375000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 2, 100, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 3, 100, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 4, 100, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 5, 100, 1, 150000, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 6, 100, 0, 0, 0, 0, 100001, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 7, 100, 0, 0, 0, 0, 1, 575000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 8, 100, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 9, 100, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 10, 150, 1, 200000, 100011, 1, 4, 1, 100003, 1);
INSERT INTO `s_mission_level` VALUES (1, 11, 150, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 12, 150, 0, 0, 0, 0, 100011, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 13, 150, 0, 0, 0, 0, 1, 1000000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 14, 150, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 15, 150, 1, 375000, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 16, 150, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 17, 150, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 18, 150, 0, 0, 0, 0, 100021, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 19, 200, 0, 0, 0, 0, 1, 2100000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 20, 200, 1, 475000, 100021, 1, 2, 2, 100033, 1);
INSERT INTO `s_mission_level` VALUES (1, 21, 200, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 22, 200, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 23, 200, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 24, 200, 0, 0, 0, 0, 100031, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 25, 200, 1, 575000, 0, 0, 1, 2600000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 26, 200, 0, 0, 0, 0, 2, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 27, 200, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 28, 250, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 29, 250, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 30, 250, 1, 1000000, 100001, 1, 100041, 1, 100053, 1);
INSERT INTO `s_mission_level` VALUES (1, 31, 250, 0, 0, 0, 0, 1, 3000000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 32, 250, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 33, 250, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 34, 250, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 35, 250, 1, 2100000, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 36, 250, 0, 0, 0, 0, 100051, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 37, 300, 0, 0, 0, 0, 1, 3800000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 38, 300, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 39, 300, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 40, 300, 1, 2600000, 100031, 1, 4, 1, 100003, 2);
INSERT INTO `s_mission_level` VALUES (1, 41, 300, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 42, 300, 0, 0, 0, 0, 100001, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 43, 300, 0, 0, 0, 0, 1, 4500000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 44, 300, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 45, 300, 1, 3000000, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 46, 350, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 47, 350, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 48, 350, 0, 0, 0, 0, 100011, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 49, 350, 0, 0, 0, 0, 1, 5600000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 50, 350, 1, 3800000, 100041, 1, 2, 5, 100033, 2);
INSERT INTO `s_mission_level` VALUES (1, 51, 350, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 52, 350, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 53, 350, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 54, 350, 0, 0, 0, 0, 100021, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 55, 400, 1, 4500000, 0, 0, 1, 6000000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 56, 400, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 57, 400, 0, 0, 0, 0, 3, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 58, 400, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 59, 400, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 60, 400, 1, 5600000, 100051, 1, 100031, 1, 100053, 2);
INSERT INTO `s_mission_level` VALUES (1, 61, 400, 0, 0, 0, 0, 1, 6400000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 62, 400, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 63, 400, 0, 0, 0, 0, 3, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 64, 450, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 65, 450, 1, 6000000, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 66, 450, 0, 0, 0, 0, 100041, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 67, 450, 0, 0, 0, 0, 1, 8000000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 68, 450, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 69, 450, 0, 0, 0, 0, 3, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 70, 450, 1, 6400000, 100013, 1, 4, 1, 100003, 3);
INSERT INTO `s_mission_level` VALUES (1, 71, 450, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 72, 450, 0, 0, 0, 0, 100051, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 73, 500, 0, 0, 0, 0, 1, 8500000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 74, 500, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 75, 500, 1, 8000000, 0, 0, 3, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 76, 500, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 77, 500, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 78, 500, 0, 0, 0, 0, 100001, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 79, 500, 0, 0, 0, 0, 1, 10200000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 80, 500, 1, 8500000, 100023, 1, 2, 5, 100033, 3);
INSERT INTO `s_mission_level` VALUES (1, 81, 500, 0, 0, 0, 0, 3, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 82, 550, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 83, 550, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 84, 550, 0, 0, 0, 0, 100011, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 85, 550, 1, 10200000, 0, 0, 1, 11000000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 86, 550, 0, 0, 0, 0, 2, 5, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 87, 550, 0, 0, 0, 0, 3, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 88, 550, 0, 0, 0, 0, 4, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 89, 550, 0, 0, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 90, 550, 1, 11000000, 100033, 1, 100021, 1, 100053, 3);
INSERT INTO `s_mission_level` VALUES (1, 91, 600, 0, 0, 0, 0, 1, 12000000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 92, 600, 0, 0, 0, 0, 2, 10, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 93, 600, 0, 0, 0, 0, 3, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 94, 600, 0, 0, 0, 0, 4, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 95, 600, 1, 12000000, 0, 0, 5, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 96, 600, 0, 0, 0, 0, 100031, 1, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 97, 600, 0, 0, 0, 0, 1, 13500000, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 98, 600, 0, 0, 0, 0, 2, 10, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 99, 600, 0, 0, 0, 0, 3, 2, 0, 0);
INSERT INTO `s_mission_level` VALUES (1, 100, 800, 1, 13500000, 100053, 1, 4, 2, 100003, 5);
update s_mission_level set passrewardnum1 = 3600 * passrewardnum1 where passrewardid1 in (3,4);

ALTER TABLE d_quest ADD missionstar int(11) DEFAULT '0' COMMENT '星星值';

update s_shop set productid_gp='com.rummyfree.7' where productid_gp='com.rummyslots.gold7';
update s_shop set productid_huawei='a7' where productid_gp='com.rummyfree.7';
update s_shop set productid_huawei='a1', productid_gp='com.rummyfree.1' where amount=0.99;
update s_shop set productid_huawei='a3', productid_gp='com.rummyfree.3' where amount=2.99;
update s_shop set productid_huawei='a4', productid_gp='com.rummyfree.4' where amount=3.99;
update s_shop set productid_huawei='a5', productid_gp='com.rummyfree.5' where amount=4.99;
update s_shop set productid_huawei='a6', productid_gp='com.rummyfree.6' where amount=5.99;
update s_shop set productid_huawei='a8', productid_gp='com.rummyfree.8' where amount=7.99;
update s_shop set productid_huawei='a9', productid_gp='com.rummyfree.9' where amount=8.99;
update s_shop set productid_huawei='a10', productid_gp='com.rummyfree.10' where amount=9.99;
update s_shop set productid_huawei='a11', productid_gp='com.rummyfree.11' where amount=12.99;
update s_shop set productid_huawei='a12', productid_gp='com.rummyfree.12' where amount=19.99;
update s_shop set productid_huawei='a13', productid_gp='com.rummyfree.13' where amount=49.99;

ALTER TABLE `s_shop` MODIFY COLUMN `oamount` decimal(10, 2) NULL DEFAULT 0 COMMENT '原始金额' AFTER `count`;
update s_shop set oamount=6.99 where stype=11 and amount=2.99;
update s_shop set oamount=8.99 where stype=11 and amount=3.99;
update s_shop set oamount=9.99 where stype=11 and amount=4.99;
update s_shop set oamount=12.99 where stype=11 and amount=5.99;
update s_shop set oamount=14.99 where stype=11 and amount=6.99;
update s_shop set oamount=16.99 where stype=11 and amount=7.99;
update s_shop set oamount=19.99 where stype=11 and amount=8.99;
update s_shop set oamount=20.99 where stype=11 and amount=9.99;
update s_shop set oamount=25.99 where stype=11 and amount=12.99;
update s_shop set oamount=49.99 where stype=11 and amount=19.99;
update s_shop set oamount=99.99 where stype=11 and amount=49.99;