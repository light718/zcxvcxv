update s_shop set discount=200 where stype=2;

update s_shop set productid_gp='com.rummyfree.3' where amount=2.99 and stype=11;
update s_shop set productid_gp='com.rummyfree.7' where amount=6.99 and stype=11;