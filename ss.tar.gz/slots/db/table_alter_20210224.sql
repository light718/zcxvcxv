replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (488, "幸运蜜蜂", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(488, "luckybee", 0, 0.1, 0.1, '[10,25,50,100,1000]', '[4,6,9,12,16]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 488, "幸运蜜蜂", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (489, "石器时代的宝藏", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(489, "stoneagedtreasure", 0, 0.1, 0.1, '[10,25,250,3000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 489, "石器时代的宝藏", 1, 100);