--
-- Table structure for table `s_game_task`
--

DROP TABLE IF EXISTS `s_game_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_game_task` (
  `roundid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `rewardid` int(11) NOT NULL DEFAULT '0',
  `rewardnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`roundid`,`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_game_task`
--

LOCK TABLES `s_game_task` WRITE;
/*!40000 ALTER TABLE `s_game_task` DISABLE KEYS */;
INSERT INTO `s_game_task` VALUES (1,1,458,1,1000000),(1,2,437,1,1240000),(1,3,443,1,1380000),(1,4,428,1,1500000),(1,5,425,1,1700000),(1,6,433,1,3500000),(2,1,458,1,340000),(2,2,437,1,600000),(2,3,443,1,870000),(2,4,428,1,1050000),(2,5,425,1,1300000),(2,6,433,1,6000000),(3,1,458,1,700000),(3,2,437,1,1200000),(3,3,443,1,1700000),(3,4,428,1,2040000),(3,5,425,1,2550000),(3,6,433,1,12000000);
/*!40000 ALTER TABLE `s_game_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s_game_task_detail`
--

DROP TABLE IF EXISTS `s_game_task_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_game_task_detail` (
  `roundid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `detailid` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  `param1` int(11) DEFAULT NULL,
  `param2` int(11) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`roundid`,`taskid`,`detailid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_game_task_detail`
--

LOCK TABLES `s_game_task_detail` WRITE;
/*!40000 ALTER TABLE `s_game_task_detail` DISABLE KEYS */;
INSERT INTO `s_game_task_detail` VALUES (1,1,1,1,NULL,NULL,20),(1,1,2,3,NULL,NULL,212000),(1,2,1,2,NULL,NULL,12),(1,2,2,6,2,NULL,25),(1,2,3,4,NULL,NULL,1000000),(1,3,1,2,1,NULL,5),(1,3,2,3,NULL,NULL,2800000),(1,4,1,6,2,NULL,50),(1,4,2,1,1,NULL,1),(1,4,3,4,NULL,NULL,2000000),(1,5,1,6,2,NULL,60),(1,5,2,4,NULL,NULL,1600000),(1,6,1,6,2,NULL,80),(1,6,2,1,NULL,1,1),(1,6,3,4,1,NULL,2400000),(2,1,1,1,NULL,NULL,20),(2,1,2,3,NULL,NULL,2100000),(2,2,1,2,NULL,NULL,12),(2,2,2,6,2,NULL,25),(2,2,3,4,NULL,NULL,10000000),(2,3,1,2,1,NULL,5),(2,3,2,3,NULL,NULL,28200000),(2,4,1,6,2,NULL,50),(2,4,2,1,1,NULL,1),(2,4,3,4,NULL,NULL,20800000),(2,5,1,6,2,NULL,60),(2,5,2,4,NULL,NULL,16100000),(2,6,1,6,2,NULL,80),(2,6,2,1,NULL,1,1),(2,6,3,4,1,NULL,24100000),(3,1,1,1,NULL,NULL,20),(3,1,2,3,NULL,NULL,420000),(3,2,1,2,NULL,NULL,12),(3,2,2,6,2,NULL,25),(3,2,3,4,NULL,NULL,20000000),(3,3,1,2,1,NULL,5),(3,3,2,3,NULL,NULL,56400000),(3,4,1,6,2,NULL,50),(3,4,2,1,1,NULL,1),(3,4,3,4,NULL,NULL,40200000),(3,5,1,6,2,NULL,60),(3,5,2,4,NULL,NULL,32200000),(3,6,1,6,2,NULL,80),(3,6,2,1,NULL,1,1),(3,6,3,4,1,NULL,48200000);
/*!40000 ALTER TABLE `s_game_task_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `d_game_task`
--

DROP TABLE IF EXISTS `d_game_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `d_game_task` (
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `data` mediumtext COMMENT 'json数据',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户主线任务表';
/*!40101 SET character_set_client = @saved_cs_client */;