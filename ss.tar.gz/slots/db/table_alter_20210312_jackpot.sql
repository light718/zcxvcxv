-- 468  mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[10,50,100,650,2000,5000]' WHERE id = 470;