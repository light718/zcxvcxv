-- 475 摇摆迪斯科 rockingdisco  mini, minor, major, grand, maxi
UPDATE `s_game` SET `jackpot` = '[10,20,50,5000,500]' WHERE id = 475;