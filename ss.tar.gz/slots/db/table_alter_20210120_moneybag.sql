update `s_config` set v = '{"bag":750000, "maxmul":3, "addrate":0.08,"probability":0.15, "bonus":0}' where k = 'moneybag';
