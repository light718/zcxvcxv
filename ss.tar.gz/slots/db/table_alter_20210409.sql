-- 换皮游戏
---- 627 秦始皇 Double Agent
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    627, "秦始皇", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 465;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    627, "emperorqin", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 465;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 627, "秦始皇", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 465;

-- 628 魔术师 Big Duel
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    628, "魔术师", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 421;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    628, "magician", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 421;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 628, "魔术师", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 421;

-- 629 梦幻巧克力工厂  Fantasy Chocolate Factory
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    629, "梦幻巧克力工厂", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 468;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    629, "fantasychocolatefactory", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 468;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 629, "梦幻巧克力工厂", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 468;