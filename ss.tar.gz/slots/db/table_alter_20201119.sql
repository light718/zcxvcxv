
-- ----------------------------
-- Table structure for d_gift_category
-- ----------------------------
DROP TABLE IF EXISTS `d_gift_category`;
CREATE TABLE `d_gift_category` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `rewards` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`categoryid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for d_gift
-- ----------------------------
DROP TABLE IF EXISTS `d_gift`;
CREATE TABLE `d_gift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '兑换码',
  `categoryid` int(11) NOT NULL COMMENT '批次',
  `categorytime` int(11) NOT NULL COMMENT '批次时间',
  `useuid` int(11) NOT NULL DEFAULT '0' COMMENT '使用者',
  `usetime` int(11) NOT NULL DEFAULT '0' COMMENT '使用时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4;
