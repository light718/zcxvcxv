-- 美国大亨 american billionaire
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (523, "美国大亨", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(523, "americanbillionaire", 0, 0.1, 0.1, '[5,20,120,240]', '[1,3,6,9]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 523, "美国大亨", 1, 500);