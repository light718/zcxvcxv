ALTER TABLE `d_user` 
ADD COLUMN `kouuid` varchar(100) NULL DEFAULT '' COMMENT 'kochava uuid' AFTER `sysMailID`;

ALTER TABLE `d_user` 
ADD COLUMN `isbindgg` tinyint(1) NULL DEFAULT 0 COMMENT '是否绑定gg' AFTER `kouuid`;

ALTER TABLE `d_user` 
ADD COLUMN `firstbuylist` varchar(100) NULL DEFAULT '' COMMENT '已购买的商城首充翻倍id列表' AFTER `isbindgg`;