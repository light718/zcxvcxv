update s_game set jackpot='[5,10,50,200]', jp_unlock_lv='[1,1,1,1]' where id = 530;
update s_game set jp_unlock_lv='[1,1,1,1]' where id = 527;
