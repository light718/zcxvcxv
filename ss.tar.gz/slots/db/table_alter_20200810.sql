ALTER TABLE `s_game` ADD COLUMN `needbet` int(11) NULL COMMENT '开启收集的押注等级' AFTER `allincontrol`;
update s_game set needbet=10;

ALTER TABLE `s_game` ADD COLUMN `firstbet` int(11) NULL DEFAULT 10000 COMMENT '第1档押注' AFTER `needbet`;

update s_config set v=1 where k ='ginmult';


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (426, "杰克猫", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol) values(426, "pussmusketeer", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 426, "杰克猫", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (427, "传统的邦妮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol) values(427, "thelegarybonieclyde", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 427, "传统的邦妮", 1, 100);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (428, "奥林匹斯国王", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol) values(428, "kingofolympus", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 428, "奥林匹斯国王", 1, 100);

ALTER TABLE `s_send_coin` ADD INDEX `idxtime`(`create_time`);