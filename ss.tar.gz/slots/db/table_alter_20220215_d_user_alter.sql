-- 新增卡牌等级相关字段
alter table d_user add `pvp_card_exp` bigint(20) default 0 not null comment 'pvp剩余卡牌经验';
alter table d_user add `pvp_season_id` int default 0 not null comment 'pvp赛季id';
alter table d_user add `pvp_defend_team` varchar(255) default "" not null comment 'pvp防御卡牌: 1031|1032|1033|1057|1075';