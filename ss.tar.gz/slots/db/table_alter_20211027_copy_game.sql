-- 换皮游戏

-- 670 半人马 Centaur
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    670, "半人马", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 517;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    670, "centaur", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 517;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 670, "半人马", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 517;


-- 671 外星怪物 Alien Monster
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    671, "外星怪物", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 515;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    671, "alienmonster", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 515;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 671, "外星怪物", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 515;


-- 672 篮球之王 Champion
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    672, "篮球之王", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 523;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    672, "champion", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 523;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 672, "篮球之王", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 523;


-- 673 赫拉 Hera
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    673, "赫拉", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 525;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    673, "hera", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 525;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 673, "赫拉", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 525;


-- 674 麒麟 Mythical Kylin
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    674, "麒麟", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 516;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    674, "mythicalkylin", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 516;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 674, "麒麟", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 516;


-- 675 嫦娥 Chang'e
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    675, "嫦娥", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 513;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    675, "change", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 513;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 675, "嫦娥", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 513;


-- 676 豌豆公主 Princess Pea
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    676, "豌豆公主", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 520;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    676, "princesspea", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 520;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 676, "豌豆公主", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 520;


-- 677 日本歌姬 Eternal Singer
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    677, "日本歌姬", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 526;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    677, "eternalsinger", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 526;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 677, "日本歌姬", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 526;


-- 678 印第安人 Indian
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    678, "印第安人", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 527;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    678, "indian", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 527;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 678, "印第安人", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 527;


-- 679 弗丽嘉 Frigg
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    679, "弗丽嘉", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 491;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    679, "frigg", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 491;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 679, "弗丽嘉", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 491;


-- 680 阿波罗 Apollo
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    680, "阿波罗", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 530;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    680, "apollo", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 530;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 680, "阿波罗", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 530;


-- 681 狄俄倪索斯 Dionysus
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    681, "狄俄倪索斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 532;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    681, "dionysus", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 532;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 681, "狄俄倪索斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 532;
