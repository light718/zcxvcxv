update s_sign_new set prize='[{"s":22,"n":30}]' where id in (5,12,19,26);

--old
-- update s_sign_new set prize='[{"s":16,"n":30}]' where id in (5,12,19,26);