-- 更改任务轮数，将两轮改成一轮
delete from s_game_task where roundid=2;