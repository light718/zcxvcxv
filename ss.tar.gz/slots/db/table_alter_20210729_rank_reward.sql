
DROP TABLE IF EXISTS `s_rank_reward`;
CREATE TABLE `s_rank_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rtype` int(11) DEFAULT 0 COMMENT '排行榜类型, 1=总赢榜,2=总下注,3=大奖排行榜,4=卡牌数量排行榜',
  `rank` int(11) DEFAULT 0 COMMENT '排名',
  `rewards` varchar(255) DEFAULT 0 COMMENT '奖励',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='新手任务配置';

INSERT INTO `s_rank_reward` VALUES (1, 1, 1, '1:4000000|8:5|2:50');
INSERT INTO `s_rank_reward` VALUES (2, 1, 2, '1:3000000|8:4|2:30');
INSERT INTO `s_rank_reward` VALUES (3, 1, 3, '1:2000000|8:3|2:20');
INSERT INTO `s_rank_reward` VALUES (4, 1, 4, '1:1200000|8:1|2:20');
INSERT INTO `s_rank_reward` VALUES (5, 1, 5, '1:1200000|8:1|2:20');
INSERT INTO `s_rank_reward` VALUES (6, 1, 6, '1:1200000|8:1|2:20');
INSERT INTO `s_rank_reward` VALUES (7, 1, 7, '1:1200000|8:1|2:20');
INSERT INTO `s_rank_reward` VALUES (8, 1, 8, '1:1200000|8:1|2:20');
INSERT INTO `s_rank_reward` VALUES (9, 1, 9, '1:1200000|8:1|2:20');
INSERT INTO `s_rank_reward` VALUES (10, 1, 10, '1:1200000|8:1|2:20');
INSERT INTO `s_rank_reward` VALUES (11, 1, 11, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (12, 1, 12, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (13, 1, 13, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (14, 1, 14, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (15, 1, 15, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (16, 1, 16, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (17, 1, 17, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (18, 1, 18, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (19, 1, 19, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (20, 1, 20, '1:1000000|8:1|2:10');
INSERT INTO `s_rank_reward` VALUES (21, 2, 1, '1:8000000|8:5|2:20');
INSERT INTO `s_rank_reward` VALUES (22, 2, 2, '1:600000|8:4|2:15');
INSERT INTO `s_rank_reward` VALUES (23, 2, 3, '1:400000|8:3|2:10');
INSERT INTO `s_rank_reward` VALUES (24, 2, 4, '1:2400000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (25, 2, 5, '1:2400000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (26, 2, 6, '1:2400000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (27, 2, 7, '1:2400000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (28, 2, 8, '1:2400000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (29, 2, 9, '1:2400000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (30, 2, 10, '1:2400000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (31, 2, 11, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (32, 2, 12, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (33, 2, 13, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (34, 2, 14, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (35, 2, 15, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (36, 2, 16, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (37, 2, 17, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (38, 2, 18, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (39, 2, 19, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (40, 2, 20, '1:2000000|8:1|2:5');
INSERT INTO `s_rank_reward` VALUES (41, 4, 1, '1:4000000|8:10|2:20');
INSERT INTO `s_rank_reward` VALUES (42, 4, 2, '1:3000000|8:8|2:15');
INSERT INTO `s_rank_reward` VALUES (43, 4, 3, '1:2000000|8:6|2:10');
INSERT INTO `s_rank_reward` VALUES (44, 4, 4, '1:1200000|8:3|2:5');
INSERT INTO `s_rank_reward` VALUES (45, 4, 5, '1:1200000|8:3|2:5');
INSERT INTO `s_rank_reward` VALUES (46, 4, 6, '1:1200000|8:3|2:5');
INSERT INTO `s_rank_reward` VALUES (47, 4, 7, '1:1200000|8:3|2:5');
INSERT INTO `s_rank_reward` VALUES (48, 4, 8, '1:1200000|8:3|2:5');
INSERT INTO `s_rank_reward` VALUES (49, 4, 9, '1:1200000|8:3|2:5');
INSERT INTO `s_rank_reward` VALUES (50, 4, 10, '1:1200000|8:3|2:5');
INSERT INTO `s_rank_reward` VALUES (51, 4, 11, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (52, 4, 12, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (53, 4, 13, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (54, 4, 14, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (55, 4, 15, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (56, 4, 16, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (57, 4, 17, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (58, 4, 18, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (59, 4, 19, '1:1000000|8:2|2:5');
INSERT INTO `s_rank_reward` VALUES (60, 4, 20, '1:1000000|8:2|2:5');
