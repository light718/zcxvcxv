-- 修改冰狼jackpot倍数
UPDATE `s_game` SET `jackpot` = '[5,10,625,1250,5000]' WHERE id = 479;