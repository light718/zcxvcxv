delete from
    d_main_task
where
    `type` = 7;

update
    d_main_task
set
    taskid = taskid + type * 100
where
    1 = 1
    and taskid < 100;

update
    d_main_task
set
    state = 3,
    is_show = 0
where
    id in (
        select
            id
        from
            (
                select
                    id
                from
                    d_main_task t1
                    right join (
                        select
                            uid,
                            type,
                            count(*) as cnt
                        from
                            d_main_task
                        group by
                            type,
                            uid
                        having
                            cnt > 1
                    ) t2 on t2.uid = t1.uid
                    and t2.type = t1.type
                where
                    mod(t1.taskid, 100) <> t2.cnt
                    and state = 1
            ) as t
    );