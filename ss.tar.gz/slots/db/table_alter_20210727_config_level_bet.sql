/*
Navicat MySQL Data Transfer

Source Server         : 165
Source Server Version : 50646
Source Host           : 10.0.0.165:3306
Source Database       : jp_game_rummyslot

Target Server Type    : MYSQL
Target Server Version : 50646
File Encoding         : 65001

Date: 2021-07-28 14:14:55
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for s_config_level_bet
-- ----------------------------
DROP TABLE IF EXISTS `s_config_level_bet`;
CREATE TABLE `s_config_level_bet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `betcoin` bigint(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idxlevel` (`level`)
) ENGINE=MyISAM AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb4 COMMENT='slots等级押注额配置';

-- ----------------------------
-- Records of s_config_level_bet
-- ----------------------------
INSERT INTO `s_config_level_bet` VALUES ('1', '1', '10000');
INSERT INTO `s_config_level_bet` VALUES ('2', '2', '25000');
INSERT INTO `s_config_level_bet` VALUES ('3', '3', '50000');
INSERT INTO `s_config_level_bet` VALUES ('4', '4', '100000');
INSERT INTO `s_config_level_bet` VALUES ('5', '5', '150000');
INSERT INTO `s_config_level_bet` VALUES ('6', '6', '200000');
INSERT INTO `s_config_level_bet` VALUES ('7', '7', '275000');
INSERT INTO `s_config_level_bet` VALUES ('8', '8', '300000');
INSERT INTO `s_config_level_bet` VALUES ('9', '9', '350000');
INSERT INTO `s_config_level_bet` VALUES ('10', '10', '500000');
INSERT INTO `s_config_level_bet` VALUES ('11', '11', '800000');
INSERT INTO `s_config_level_bet` VALUES ('12', '12', '1000000');
INSERT INTO `s_config_level_bet` VALUES ('13', '13', '1500000');
INSERT INTO `s_config_level_bet` VALUES ('14', '14', '2000000');
INSERT INTO `s_config_level_bet` VALUES ('15', '15', '4000000');
INSERT INTO `s_config_level_bet` VALUES ('16', '16', '5000000');
INSERT INTO `s_config_level_bet` VALUES ('17', '17', '6000000');
INSERT INTO `s_config_level_bet` VALUES ('18', '18', '7000000');
INSERT INTO `s_config_level_bet` VALUES ('19', '19', '10000000');
INSERT INTO `s_config_level_bet` VALUES ('20', '20', '15000000');
INSERT INTO `s_config_level_bet` VALUES ('21', '21', '20000000');
INSERT INTO `s_config_level_bet` VALUES ('22', '22', '35000000');
INSERT INTO `s_config_level_bet` VALUES ('23', '23', '50000000');
INSERT INTO `s_config_level_bet` VALUES ('24', '24', '70000000');
INSERT INTO `s_config_level_bet` VALUES ('25', '25', '88000000');
INSERT INTO `s_config_level_bet` VALUES ('26', '26', '100000000');
INSERT INTO `s_config_level_bet` VALUES ('27', '27', '150000000');
INSERT INTO `s_config_level_bet` VALUES ('28', '28', '200000000');
INSERT INTO `s_config_level_bet` VALUES ('29', '29', '250000000');
INSERT INTO `s_config_level_bet` VALUES ('30', '30', '300000000');
INSERT INTO `s_config_level_bet` VALUES ('31', '31', '350000000');
INSERT INTO `s_config_level_bet` VALUES ('32', '32', '400000000');
INSERT INTO `s_config_level_bet` VALUES ('33', '33', '600000000');
INSERT INTO `s_config_level_bet` VALUES ('34', '34', '800000000');
INSERT INTO `s_config_level_bet` VALUES ('35', '35', '1000000000');
INSERT INTO `s_config_level_bet` VALUES ('36', '36', '1200000000');
INSERT INTO `s_config_level_bet` VALUES ('37', '37', '1500000000');
INSERT INTO `s_config_level_bet` VALUES ('38', '38', '1800000000');
INSERT INTO `s_config_level_bet` VALUES ('39', '39', '2000000000');
INSERT INTO `s_config_level_bet` VALUES ('40', '40', '2500000000');
INSERT INTO `s_config_level_bet` VALUES ('41', '41', '3000000000');
INSERT INTO `s_config_level_bet` VALUES ('42', '42', '3500000000');
INSERT INTO `s_config_level_bet` VALUES ('43', '43', '4000000000');
INSERT INTO `s_config_level_bet` VALUES ('44', '44', '4500000000');
INSERT INTO `s_config_level_bet` VALUES ('45', '45', '5000000000');
INSERT INTO `s_config_level_bet` VALUES ('46', '46', '5500000000');
INSERT INTO `s_config_level_bet` VALUES ('47', '47', '6000000000');
INSERT INTO `s_config_level_bet` VALUES ('48', '48', '6500000000');
INSERT INTO `s_config_level_bet` VALUES ('49', '49', '7000000000');
INSERT INTO `s_config_level_bet` VALUES ('50', '50', '7500000000');
INSERT INTO `s_config_level_bet` VALUES ('51', '51', '8000000000');
INSERT INTO `s_config_level_bet` VALUES ('52', '52', '8500000000');
INSERT INTO `s_config_level_bet` VALUES ('53', '53', '9000000000');
INSERT INTO `s_config_level_bet` VALUES ('54', '54', '9500000000');
INSERT INTO `s_config_level_bet` VALUES ('55', '55', '10000000000');
INSERT INTO `s_config_level_bet` VALUES ('56', '56', '10500000000');
INSERT INTO `s_config_level_bet` VALUES ('57', '57', '11000000000');
INSERT INTO `s_config_level_bet` VALUES ('58', '58', '11500000000');
INSERT INTO `s_config_level_bet` VALUES ('59', '59', '12000000000');
INSERT INTO `s_config_level_bet` VALUES ('60', '60', '12500000000');
INSERT INTO `s_config_level_bet` VALUES ('61', '61', '13000000000');
INSERT INTO `s_config_level_bet` VALUES ('62', '62', '13500000000');
INSERT INTO `s_config_level_bet` VALUES ('63', '63', '14000000000');
INSERT INTO `s_config_level_bet` VALUES ('64', '64', '14500000000');
INSERT INTO `s_config_level_bet` VALUES ('65', '65', '15000000000');
INSERT INTO `s_config_level_bet` VALUES ('66', '66', '15500000000');
INSERT INTO `s_config_level_bet` VALUES ('67', '67', '16000000000');
INSERT INTO `s_config_level_bet` VALUES ('68', '68', '16500000000');
INSERT INTO `s_config_level_bet` VALUES ('69', '69', '17000000000');
INSERT INTO `s_config_level_bet` VALUES ('70', '70', '17500000000');
INSERT INTO `s_config_level_bet` VALUES ('71', '71', '18000000000');
INSERT INTO `s_config_level_bet` VALUES ('72', '72', '18500000000');
INSERT INTO `s_config_level_bet` VALUES ('73', '73', '19000000000');
INSERT INTO `s_config_level_bet` VALUES ('74', '74', '19500000000');
INSERT INTO `s_config_level_bet` VALUES ('75', '75', '20000000000');
INSERT INTO `s_config_level_bet` VALUES ('76', '76', '20500000000');
INSERT INTO `s_config_level_bet` VALUES ('77', '77', '21000000000');
INSERT INTO `s_config_level_bet` VALUES ('78', '78', '21500000000');
INSERT INTO `s_config_level_bet` VALUES ('79', '79', '22000000000');
INSERT INTO `s_config_level_bet` VALUES ('80', '80', '22500000000');
INSERT INTO `s_config_level_bet` VALUES ('81', '81', '23000000000');
INSERT INTO `s_config_level_bet` VALUES ('82', '82', '23500000000');
INSERT INTO `s_config_level_bet` VALUES ('83', '83', '24000000000');
INSERT INTO `s_config_level_bet` VALUES ('84', '84', '24500000000');
INSERT INTO `s_config_level_bet` VALUES ('85', '85', '25000000000');
INSERT INTO `s_config_level_bet` VALUES ('86', '86', '25500000000');
INSERT INTO `s_config_level_bet` VALUES ('87', '87', '26000000000');
INSERT INTO `s_config_level_bet` VALUES ('88', '88', '26500000000');
INSERT INTO `s_config_level_bet` VALUES ('89', '89', '27000000000');
INSERT INTO `s_config_level_bet` VALUES ('90', '90', '27500000000');
INSERT INTO `s_config_level_bet` VALUES ('91', '91', '28000000000');
INSERT INTO `s_config_level_bet` VALUES ('92', '92', '28500000000');
INSERT INTO `s_config_level_bet` VALUES ('93', '93', '29000000000');
INSERT INTO `s_config_level_bet` VALUES ('94', '94', '29500000000');
INSERT INTO `s_config_level_bet` VALUES ('95', '95', '30000000000');
INSERT INTO `s_config_level_bet` VALUES ('96', '96', '30500000000');
INSERT INTO `s_config_level_bet` VALUES ('97', '97', '31000000000');
INSERT INTO `s_config_level_bet` VALUES ('98', '98', '31500000000');
INSERT INTO `s_config_level_bet` VALUES ('99', '99', '32000000000');
INSERT INTO `s_config_level_bet` VALUES ('100', '100', '32500000000');
INSERT INTO `s_config_level_bet` VALUES ('101', '101', '33000000000');
INSERT INTO `s_config_level_bet` VALUES ('102', '102', '33500000000');
INSERT INTO `s_config_level_bet` VALUES ('103', '103', '34000000000');
INSERT INTO `s_config_level_bet` VALUES ('104', '104', '34500000000');
INSERT INTO `s_config_level_bet` VALUES ('105', '105', '35000000000');
INSERT INTO `s_config_level_bet` VALUES ('106', '106', '35500000000');
INSERT INTO `s_config_level_bet` VALUES ('107', '107', '36000000000');
INSERT INTO `s_config_level_bet` VALUES ('108', '108', '36500000000');
INSERT INTO `s_config_level_bet` VALUES ('109', '109', '37000000000');
INSERT INTO `s_config_level_bet` VALUES ('110', '110', '37500000000');
INSERT INTO `s_config_level_bet` VALUES ('111', '111', '38000000000');
INSERT INTO `s_config_level_bet` VALUES ('112', '112', '38500000000');
INSERT INTO `s_config_level_bet` VALUES ('113', '113', '39000000000');
INSERT INTO `s_config_level_bet` VALUES ('114', '114', '39500000000');
INSERT INTO `s_config_level_bet` VALUES ('115', '115', '40000000000');
INSERT INTO `s_config_level_bet` VALUES ('116', '116', '40500000000');
INSERT INTO `s_config_level_bet` VALUES ('117', '117', '41000000000');
INSERT INTO `s_config_level_bet` VALUES ('118', '118', '41500000000');
INSERT INTO `s_config_level_bet` VALUES ('119', '119', '42000000000');
INSERT INTO `s_config_level_bet` VALUES ('120', '120', '42500000000');
INSERT INTO `s_config_level_bet` VALUES ('121', '121', '43000000000');
INSERT INTO `s_config_level_bet` VALUES ('122', '122', '43500000000');
INSERT INTO `s_config_level_bet` VALUES ('123', '123', '44000000000');
INSERT INTO `s_config_level_bet` VALUES ('124', '124', '44500000000');
INSERT INTO `s_config_level_bet` VALUES ('125', '125', '45000000000');
INSERT INTO `s_config_level_bet` VALUES ('126', '126', '45500000000');
INSERT INTO `s_config_level_bet` VALUES ('127', '127', '46000000000');
INSERT INTO `s_config_level_bet` VALUES ('128', '128', '46500000000');
INSERT INTO `s_config_level_bet` VALUES ('129', '129', '47000000000');
INSERT INTO `s_config_level_bet` VALUES ('130', '130', '47500000000');
INSERT INTO `s_config_level_bet` VALUES ('131', '131', '48000000000');
INSERT INTO `s_config_level_bet` VALUES ('132', '132', '48500000000');
INSERT INTO `s_config_level_bet` VALUES ('133', '133', '49000000000');
INSERT INTO `s_config_level_bet` VALUES ('134', '134', '49500000000');
INSERT INTO `s_config_level_bet` VALUES ('135', '135', '50000000000');
INSERT INTO `s_config_level_bet` VALUES ('136', '136', '50500000000');
INSERT INTO `s_config_level_bet` VALUES ('137', '137', '51000000000');
