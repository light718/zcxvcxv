-- 468  mini, minor, major, grand
UPDATE `s_game` SET `jackpot` = '[5,10,200,1000]' WHERE id = 468;