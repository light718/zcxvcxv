ALTER TABLE `d_user` ADD COLUMN `sysMailID` int(11) NOT NULL DEFAULT 0 COMMENT '系统邮件ID' AFTER `justreg`;

-- ----------------------------
-- Table structure for d_user_mail
-- ----------------------------
DROP TABLE IF EXISTS `d_user_mail`;
CREATE TABLE `d_user_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '邮件id',
  `sysMailID` int(11) NOT NULL DEFAULT '0' COMMENT '系统邮件id',
  `uid` int(11) NOT NULL COMMENT '收件人id',
  `fromuid` int(11) NOT NULL DEFAULT '0' COMMENT '发件人id',
  `title` varchar(100) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '邮件标题',
  `msg` varchar(1000) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '邮件内容',
  `attach` varchar(500) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '附件',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT '时间戳',
  `hasread` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已读',
  `hastake` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已领取附件',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='玩家邮件表';

-- ----------------------------
-- Table structure for d_sys_mail
-- ----------------------------
DROP TABLE IF EXISTS `d_sys_mail`;
CREATE TABLE `d_sys_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '邮件id',
  `title` varchar(100) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '邮件标题',
  `msg` varchar(1000) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '邮件内容',
  `attach` varchar(500) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '附件',
  `timestamp` int(11) NOT NULL DEFAULT '0' COMMENT '时间戳',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='玩家邮件表';

