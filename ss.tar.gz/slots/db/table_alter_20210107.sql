ALTER TABLE `d_friend_reward` MODIFY COLUMN `betIndex` int(11) NOT NULL DEFAULT 1;
ALTER TABLE `d_friend_reward` MODIFY COLUMN `mult` int(11) NOT NULL DEFAULT 1;