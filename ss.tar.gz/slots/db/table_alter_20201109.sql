
-- 465 辉煌的宝藏 brilliant treasures
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (465, "辉煌的宝藏", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(465, "brillianttreasures", 0, 0.1, 0.1, "[5,20,300,10000]");
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 465, "辉煌的宝藏", 1, 100);

-- 466 猛犸象  mammoth grand gems   只有minor,major,grand
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (466, "猛犸象", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(466, "mammothgrandgems", 0, 0.1, 0.1, "[5,100,1000,5000]");
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 466, "猛犸象", 1, 100);

-- 467  打鼓  hot hot drums
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (467, "打鼓", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(467, "hothotdrums", 0, 0.1, 0.1, "[10,40,1000,5000]");
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 467, "打鼓", 1, 100);

-- 468  糖果魔术大  candy magic grand   只有minor,major,grand
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (468, "糖果魔术大", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(468, "candymagicgrand", 0, 0.1, 0.1, "[5,10,200,1000]");
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 468, "糖果魔术大", 1, 100);