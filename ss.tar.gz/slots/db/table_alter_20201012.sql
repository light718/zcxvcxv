update s_quest set parm1=1,descr='Complete 1 Rummy Game' where id = 1;
update s_quest set parm1=1,descr='Complete 3 Rummy Game' where id = 2;
update s_quest set parm1=1,descr='Complete 5 Rummy Game' where id = 3;