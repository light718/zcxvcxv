-- dz
update `s_sess` set seat = 5 where gameid = 255;