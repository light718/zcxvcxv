ALTER TABLE `s_shop_order` ADD COLUMN `cat` int(11) NULL DEFAULT 0 AFTER `stype`;
ALTER TABLE `s_quest` ADD COLUMN `missionstar` int(11) NOT NULL DEFAULT 0 COMMENT '任务星星奖励' AFTER `parm2coin`;

INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 1380000, 2.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold3', 'com.rummyslots.gold3', 0, 11, '', 1, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 1880000, 3.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold4', 'com.rummyslots.gold4', 0, 11, '', 2, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 2400000, 4.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold5', 'com.rummyslots.gold5', 0, 11, '', 3, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 3000000, 5.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold6', 'com.rummyslots.gold6', 0, 11, '', 4, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 3400000, 6.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold7', 'com.rummyslots.gold7', 0, 11, '', 5, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 3800000, 7.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold8', 'com.rummyslots.gold8', 0, 11, '', 6, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 4400000, 8.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold9', 'com.rummyslots.gold9', 0, 11, '', 7, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 5040000, 9.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold10', 'com.rummyslots.gold10', 0, 11, '', 8, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 6800000, 12.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold11', 'com.rummyslots.gold11', 0, 11, '', 9, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 10800000, 19.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold12', 'com.rummyslots.gold12', 0, 11, '', 10, 0, 0);
INSERT INTO `s_shop`(`title`, `ocount`, `count`, `amount`, `vipExp`, `icon`, `discount`, `discountTime`, `level`, `ord`, `status`, `cuid`, `uuid`, `productid`, `productid_gp`, `appid`, `stype`, `benefit`, `cat`, `stamppropid`, `stamppropnum`) VALUES ('任务', NULL, 32400000, 49.99, 0, NULL, 0, 0, 1, 10, 1, 0, 0, 'com.rummyslots.gold13', 'com.rummyslots.gold13', 0, 11, '', 11, 0, 0);

-- ----------------------------
-- Table structure for d_mission
-- ----------------------------
DROP TABLE IF EXISTS `d_mission`;
CREATE TABLE `d_mission` (
  `uid` int(11) NOT NULL,
  `sessionid` int(11) NOT NULL,
  `pass` tinyint(1) NOT NULL,
  `star` int(11) NOT NULL,
  `taken` varchar(1023) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `passtaken` varchar(1023) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for s_mission_level
-- ----------------------------
DROP TABLE IF EXISTS `s_mission_level`;
CREATE TABLE `s_mission_level` (
  `sessionid` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `star` int(11) NOT NULL,
  `rewardid1` int(11) NOT NULL,
  `rewardnum1` int(11) NOT NULL,
  `rewardid2` int(11) NOT NULL,
  `rewardnum2` int(11) NOT NULL,
  `passrewardid1` int(11) NOT NULL,
  `passrewardnum1` int(11) NOT NULL,
  `passrewardid2` int(11) NOT NULL,
  `passrewardnum2` int(11) NOT NULL,
  PRIMARY KEY (`sessionid`,`level`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for s_mission_session
-- ----------------------------
DROP TABLE IF EXISTS `s_mission_session`;
CREATE TABLE `s_mission_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `begintime` int(11) NOT NULL COMMENT '开始时间',
  `endtime` int(11) NOT NULL COMMENT '结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='邮票赛季表';

-- ----------------------------
-- Records of s_mission_session
-- ----------------------------
BEGIN;
INSERT INTO `s_mission_session` VALUES (1, 1600790400, 1603382400);
INSERT INTO `s_mission_session` VALUES (2, 1603555200, 1606233600);
COMMIT;

-- ----------------------------
-- Records of s_mission_level
-- ----------------------------
BEGIN;
INSERT INTO `s_mission_level` VALUES (1, 1, 100, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 2, 100, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 3, 100, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 4, 100, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 5, 100, 1, 1, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 6, 100, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 7, 100, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 8, 100, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 9, 100, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 10, 150, 1, 1, 1, 1, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 11, 150, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 12, 150, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 13, 150, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 14, 150, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 15, 150, 1, 1, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 16, 150, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 17, 150, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 18, 150, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 19, 200, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 20, 200, 1, 1, 1, 1, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 21, 200, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 22, 200, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 23, 200, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 24, 200, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 25, 200, 1, 1, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 26, 200, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 27, 200, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 28, 250, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 29, 250, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 30, 250, 1, 1, 1, 1, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 31, 250, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 32, 250, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 33, 250, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 34, 250, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 35, 250, 1, 1, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 36, 250, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 37, 300, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 38, 300, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 39, 300, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 40, 300, 1, 1, 1, 1, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 41, 300, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 42, 300, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 43, 300, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 44, 300, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 45, 300, 1, 1, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 46, 350, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 47, 350, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 48, 350, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 49, 350, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 50, 350, 1, 1, 1, 1, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 51, 350, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 52, 350, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 53, 350, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 54, 350, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 55, 400, 1, 1, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 56, 400, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 57, 400, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 58, 400, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 59, 400, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 60, 400, 1, 1, 1, 1, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 61, 400, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 62, 400, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 63, 400, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 64, 450, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 65, 450, 1, 1, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 66, 450, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 67, 450, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 68, 450, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 69, 450, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 70, 450, 1, 1, 1, 1, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 71, 450, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 72, 450, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 73, 500, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 74, 500, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 75, 500, 1, 1, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 76, 500, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 77, 500, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 78, 500, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 79, 500, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 80, 500, 1, 1, 1, 1, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 81, 500, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 82, 550, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 83, 550, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 84, 550, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 85, 550, 1, 1, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 86, 550, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 87, 550, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 88, 550, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 89, 550, 0, 0, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 90, 550, 1, 1, 1, 1, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 91, 600, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 92, 600, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 93, 600, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 94, 600, 0, 0, 0, 0, 4, 4, 3, 3);
INSERT INTO `s_mission_level` VALUES (1, 95, 600, 1, 1, 0, 0, 5, 5, 2, 2);
INSERT INTO `s_mission_level` VALUES (1, 96, 600, 0, 0, 0, 0, 6, 6, 1, 1);
INSERT INTO `s_mission_level` VALUES (1, 97, 600, 0, 0, 0, 0, 1, 1, 6, 6);
INSERT INTO `s_mission_level` VALUES (1, 98, 600, 0, 0, 0, 0, 2, 2, 5, 5);
INSERT INTO `s_mission_level` VALUES (1, 99, 600, 0, 0, 0, 0, 3, 3, 4, 4);
INSERT INTO `s_mission_level` VALUES (1, 100, 800, 1, 1, 1, 1, 4, 4, 3, 3);
COMMIT;

-- ----------------------------
-- Table structure for s_mission_shop
-- ----------------------------
DROP TABLE IF EXISTS `s_mission_shop`;
CREATE TABLE `s_mission_shop` (
  `sessionid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `star` int(11) NOT NULL,
  `pass` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`sessionid`,`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of s_mission_shop
-- ----------------------------
BEGIN;
INSERT INTO `s_mission_shop` VALUES (1, 1, 0, 1, 0);
INSERT INTO `s_mission_shop` VALUES (1, 2, 2000, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 3, 2250, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 4, 2500, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 5, 2750, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 6, 3000, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 7, 3250, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 8, 3500, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 9, 4250, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 10, 6000, 1, 20);
INSERT INTO `s_mission_shop` VALUES (1, 11, 13500, 1, 20);
COMMIT;
