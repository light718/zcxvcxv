ALTER TABLE `s_game` ADD COLUMN `jackpot` varchar(255) default '[10,50,100,500]' COMMENT 'Slots奖池配置,前4个值分别表示mini,minor,major,grand,如果有自定义奖池,数组向后扩展';

UPDATE `s_game` SET `jackpot` = '[10,50,100,500,5000]' WHERE id = 420;
