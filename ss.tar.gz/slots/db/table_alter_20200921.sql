INSERT INTO `s_config`(`id`, `k`, `v`, `memo`, `mlrobot`) VALUES (42, 'stampalbumcoin', '10000', NULL, NULL);

-- ----------------------------
-- Table structure for d_stamp
-- ----------------------------
DROP TABLE IF EXISTS `d_stamp`;
CREATE TABLE `d_stamp` (
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '玩家id',
  `data` mediumtext COMMENT 'json数据',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户邮票表';

-- ----------------------------
-- Table structure for s_stamp
-- ----------------------------
DROP TABLE IF EXISTS `s_stamp`;
CREATE TABLE `s_stamp` (
  `sessionid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `albumid` int(11) DEFAULT NULL COMMENT '集邮册',
  `star` int(11) DEFAULT NULL COMMENT '星级',
  `lucky` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否lucky',
  `weight` int(11) DEFAULT NULL COMMENT '权重',
  `name` varchar(50) DEFAULT '' COMMENT '名字',
  `imageurl` varchar(255) DEFAULT '' COMMENT '图片路径',
  PRIMARY KEY (`sessionid`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邮票配置表';

-- ----------------------------
-- Records of s_stamp
-- ----------------------------
BEGIN;
INSERT INTO `s_stamp` VALUES (1, 2, 419, 1, 0, 10, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 3, 419, 1, 0, 10, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 4, 419, 1, 0, 10, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 5, 419, 1, 0, 10, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 6, 419, 1, 0, 10, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 7, 419, 2, 0, 20, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 8, 419, 2, 0, 20, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 9, 419, 2, 0, 20, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 10, 419, 2, 0, 20, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 11, 419, 3, 0, 30, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 12, 419, 3, 0, 20, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 13, 419, 1, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 14, 420, 1, 0, 10, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 15, 420, 1, 0, 10, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 16, 420, 1, 0, 10, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 17, 420, 2, 0, 20, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 18, 420, 2, 0, 20, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 19, 420, 3, 0, 30, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 20, 420, 3, 0, 30, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 21, 420, 3, 0, 30, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 22, 420, 4, 0, 20, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 23, 420, 4, 0, 40, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 24, 420, 4, 0, 40, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 25, 420, 2, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 26, 421, 1, 0, 10, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 27, 421, 1, 0, 10, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 28, 421, 1, 0, 10, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 29, 421, 2, 0, 20, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 30, 421, 2, 0, 20, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 31, 421, 3, 0, 30, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 32, 421, 3, 0, 30, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 33, 421, 3, 0, 30, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 34, 421, 4, 0, 20, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 35, 421, 4, 0, 40, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 36, 421, 4, 0, 40, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 37, 421, 3, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 38, 422, 1, 0, 10, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 39, 422, 1, 0, 10, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 40, 422, 1, 0, 10, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 41, 422, 2, 0, 20, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 42, 422, 2, 0, 20, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 43, 422, 2, 0, 20, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 44, 422, 3, 0, 30, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 45, 422, 3, 0, 30, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 46, 422, 4, 0, 20, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 47, 422, 4, 0, 40, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 48, 422, 5, 0, 10, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 49, 422, 3, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 50, 424, 1, 0, 10, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 51, 424, 1, 0, 10, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 52, 424, 2, 0, 20, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 53, 424, 2, 0, 20, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 54, 424, 2, 0, 20, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 55, 424, 3, 0, 30, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 56, 424, 3, 0, 30, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 57, 424, 4, 0, 40, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 58, 424, 4, 0, 20, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 59, 424, 5, 0, 10, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 60, 424, 5, 0, 50, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 61, 424, 4, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 62, 427, 1, 0, 10, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 63, 427, 2, 0, 20, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 64, 427, 2, 0, 20, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 65, 427, 2, 0, 20, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 66, 427, 3, 0, 30, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 67, 427, 3, 0, 30, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 68, 427, 4, 0, 40, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 69, 427, 4, 0, 40, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 70, 427, 4, 0, 20, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 71, 427, 5, 0, 10, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 72, 427, 5, 0, 50, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 73, 427, 4, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 74, 432, 2, 0, 20, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 75, 432, 2, 0, 20, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 76, 432, 2, 0, 20, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 77, 432, 3, 0, 30, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 78, 432, 3, 0, 30, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 79, 432, 4, 0, 40, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 80, 432, 4, 0, 40, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 81, 432, 4, 0, 20, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 82, 432, 5, 0, 50, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 83, 432, 5, 0, 50, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 84, 432, 5, 0, 10, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 85, 432, 4, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 86, 443, 2, 0, 20, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 87, 443, 2, 0, 20, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 88, 443, 3, 0, 30, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 89, 443, 4, 0, 40, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 90, 443, 4, 0, 20, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 91, 443, 4, 0, 40, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 92, 443, 5, 0, 50, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 93, 443, 5, 0, 10, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 94, 443, 5, 0, 50, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 95, 443, 5, 0, 10, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 96, 443, 5, 0, 50, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 97, 443, 5, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 98, 444, 2, 0, 20, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 99, 444, 3, 0, 30, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 100, 444, 3, 0, 30, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 101, 444, 4, 0, 40, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 102, 444, 4, 0, 20, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 103, 444, 4, 0, 40, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 104, 444, 5, 0, 50, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 105, 444, 5, 0, 10, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 106, 444, 5, 0, 50, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 107, 444, 5, 0, 50, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 108, 444, 5, 0, 10, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 109, 444, 5, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 110, 446, 3, 0, 30, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 111, 446, 3, 0, 30, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 112, 446, 3, 0, 30, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 113, 446, 4, 0, 40, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 114, 446, 4, 0, 20, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 115, 446, 4, 0, 40, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 116, 446, 5, 0, 50, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 117, 446, 5, 0, 50, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 118, 446, 5, 0, 10, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 119, 446, 5, 0, 50, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 120, 446, 5, 0, 50, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 121, 446, 5, 1, 1, NULL, 'icon12');
INSERT INTO `s_stamp` VALUES (1, 122, 458, 3, 0, 30, NULL, 'icon1');
INSERT INTO `s_stamp` VALUES (1, 123, 458, 3, 0, 30, NULL, 'icon2');
INSERT INTO `s_stamp` VALUES (1, 124, 458, 3, 0, 30, NULL, 'icon3');
INSERT INTO `s_stamp` VALUES (1, 125, 458, 4, 0, 40, NULL, 'icon4');
INSERT INTO `s_stamp` VALUES (1, 126, 458, 4, 0, 40, NULL, 'icon5');
INSERT INTO `s_stamp` VALUES (1, 127, 458, 4, 0, 20, NULL, 'icon6');
INSERT INTO `s_stamp` VALUES (1, 128, 458, 5, 0, 50, NULL, 'icon7');
INSERT INTO `s_stamp` VALUES (1, 129, 458, 5, 0, 50, NULL, 'icon8');
INSERT INTO `s_stamp` VALUES (1, 130, 458, 5, 0, 10, NULL, 'icon9');
INSERT INTO `s_stamp` VALUES (1, 131, 458, 5, 0, 50, NULL, 'icon10');
INSERT INTO `s_stamp` VALUES (1, 132, 458, 5, 0, 50, NULL, 'icon11');
INSERT INTO `s_stamp` VALUES (1, 133, 458, 5, 1, 1, NULL, 'icon12');
COMMIT;

-- ----------------------------
-- Table structure for s_stamp_album
-- ----------------------------
DROP TABLE IF EXISTS `s_stamp_album`;
CREATE TABLE `s_stamp_album` (
  `sessionid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `coin` int(11) DEFAULT NULL COMMENT '金币奖励',
  `imageurl` varchar(100) DEFAULT NULL COMMENT '图片路径',
  PRIMARY KEY (`sessionid`,`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='集邮册配置表';

-- ----------------------------
-- Records of s_stamp_album
-- ----------------------------
BEGIN;
INSERT INTO `s_stamp_album` VALUES (1, 419, 11980000, 'stamp_album_1.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 420, 23960000, 'stamp_album_2.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 421, 35940000, 'stamp_album_3.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 422, 47920000, 'stamp_album_4.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 424, 59900000, 'stamp_album_5.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 427, 155740000, 'stamp_album_6.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 432, 179700000, 'stamp_album_7.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 443, 203660000, 'stamp_album_8.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 444, 227620000, 'stamp_album_9.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 446, 275540000, 'stamp_album_10.jpg');
INSERT INTO `s_stamp_album` VALUES (1, 458, 359400000, 'stamp_album_11.jpg');
COMMIT;

-- ----------------------------
-- Table structure for s_stamp_package
-- ----------------------------
DROP TABLE IF EXISTS `s_stamp_package`;
CREATE TABLE `s_stamp_package` (
  `sessionid` int(11) NOT NULL,
  `star` int(11) NOT NULL,
  `weight` int(11) DEFAULT NULL COMMENT '权重',
  `imageurl` varchar(100) DEFAULT NULL COMMENT '图片路径',
  PRIMARY KEY (`sessionid`,`star`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邮票包裹配置表';

-- ----------------------------
-- Records of s_stamp_package
-- ----------------------------
BEGIN;
INSERT INTO `s_stamp_package` VALUES (1, 1, 1, 'stamp_package_1.jpg');
INSERT INTO `s_stamp_package` VALUES (1, 2, 1, 'stamp_package_2.jpg');
INSERT INTO `s_stamp_package` VALUES (1, 3, 1, 'stamp_package_3.jpg');
INSERT INTO `s_stamp_package` VALUES (1, 4, 1, 'stamp_package_4.jpg');
INSERT INTO `s_stamp_package` VALUES (1, 5, 1, 'stamp_package_5.jpg');
COMMIT;

-- ----------------------------
-- Table structure for s_stamp_session
-- ----------------------------
DROP TABLE IF EXISTS `s_stamp_session`;
CREATE TABLE `s_stamp_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `begintime` int(11) NOT NULL COMMENT '开始时间',
  `endtime` int(11) NOT NULL COMMENT '结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='邮票赛季表';

-- ----------------------------
-- Records of s_stamp_session
-- ----------------------------
BEGIN;
INSERT INTO `s_stamp_session` VALUES (1, 1600358400, 1602950400);
INSERT INTO `s_stamp_session` VALUES (2, 1603123200, 1605801600);
COMMIT;

-- ----------------------------
-- Table structure for s_stamp_shop
-- ----------------------------
DROP TABLE IF EXISTS `s_stamp_shop`;
CREATE TABLE `s_stamp_shop` (
  `sessionid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `price` int(11) DEFAULT NULL COMMENT '价格',
  `goodsid` int(11) DEFAULT NULL COMMENT '商品id',
  `goodsnum` int(11) DEFAULT NULL COMMENT '商品数量',
  PRIMARY KEY (`sessionid`,`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='集邮商店配置表';

-- ----------------------------
-- Records of s_stamp_shop
-- ----------------------------
BEGIN;
INSERT INTO `s_stamp_shop` VALUES (1, 1, 0, 1, 1);
INSERT INTO `s_stamp_shop` VALUES (1, 2, 100, 0, 4790000);
INSERT INTO `s_stamp_shop` VALUES (1, 3, 200, 0, 11980000);
INSERT INTO `s_stamp_shop` VALUES (1, 4, 400, 3, 1);
INSERT INTO `s_stamp_shop` VALUES (1, 5, 650, 4, 1);
INSERT INTO `s_stamp_shop` VALUES (1, 6, 1000, 10, 1);
COMMIT;
