replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (491, "糖果冲突", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(491, "candyclash", 0, 0.1, 0.1, '[10,40,100,400,1000]', '[4,6,9,12,16]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 491, "糖果冲突", 1, 100);