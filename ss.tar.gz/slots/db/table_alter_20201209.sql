DROP TABLE IF EXISTS `d_app_log`;
CREATE TABLE `d_app_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) DEFAULT '0' COMMENT 'uid',
  `act` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作类型',
  `ts` int(11) DEFAULT NULL COMMENT '操作时间',
  `ddid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备id',
  `os` tinyint(1) DEFAULT NULL COMMENT '设备类型1安卓 2ios 3web',
  `appid` int(10) DEFAULT NULL COMMENT '客户端类型',
  `appver` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '客户端版本',
  `ip` int(11) unsigned DEFAULT NULL COMMENT '客户端ip',
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家',
  `countrycn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家中文',
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市',
  `latitude` double(20,6) DEFAULT NULL COMMENT '纬度',
  `longitude` double(20,6) DEFAULT NULL COMMENT '经度',
  `gameid` int(11) DEFAULT NULL COMMENT '子游戏id',
  `ext` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '扩展',
  `create_time` int(11) DEFAULT NULL COMMENT '服务器创建时间',
  PRIMARY KEY (`id`),
  KEY `index_ts_ddid` (`ts`,`ddid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='启动日志';

update s_game set jp_unlock_lv='[5,7,11,13]' where id=423;