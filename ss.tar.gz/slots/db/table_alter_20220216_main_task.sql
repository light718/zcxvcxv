-- 新的主线任务表
DROP TABLE IF EXISTS `d_main_task`;
CREATE TABLE `d_main_task` (
    `id`  int AUTO_INCREMENT PRIMARY KEY,
    `uid` int(11) NOT NULL,
    `taskid` int(11) NOT NULL COMMENT '任务id',
    `type` int(11) NOT NULL COMMENT '任务类型(每个任务类型存放一个任务)',
    `count`  int(11) NULL COMMENT '目前完成的数量',
    `state`   int(4) NOT NULL COMMENT '任务状态',
    `createtime` int(11) NOT NULL COMMENT '创建时间',
    `is_show`  tinyint DEFAULT 1 NOT NULL COMMENT '是否显示,0=不显示, 1=显示',
    INDEX idx_main_task(`uid`, `type`, `taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主线任务记录';
