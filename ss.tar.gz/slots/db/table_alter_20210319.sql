update s_game set gametag = 1, `level`=0 where id in (481);
update s_game set gametag=0 , `level` = 85 where id=443;
update s_game_type set `hot`=45 where gameid = 481;
-- curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=481&type=2&ord=5'


ALTER TABLE `d_friend` ADD COLUMN `present_count` int(11) NULL DEFAULT 0 COMMENT '被赠送次数' AFTER `present_time`;
ALTER TABLE `d_friend` ADD COLUMN `coin` int(11) NULL COMMENT '赠送的金币' AFTER `present_count`;