CREATE TABLE `d_pack` (
	`id`  int(11) NOT NULL AUTO_INCREMENT ,
	`uid`  bigint(20) NULL DEFAULT 0 COMMENT '发布人' ,
	`packid`  bigint(20) NOT NULL ,
	`cardid`  int(11) NULL DEFAULT 0 COMMENT '卡牌id' ,
	`coin`  bigint(20) NULL DEFAULT 0 COMMENT '总金额' ,
	`current`  int(11) NULL DEFAULT 0 COMMENT '当前进度' ,
	`create_time`  int(11) NULL DEFAULT 0 COMMENT '创建时间' ,
	PRIMARY KEY (`id`),
	INDEX `idx_uid` (`uid`) ,
	UNIQUE INDEX `uniq_packid` (`packid`) ,
	INDEX `idx_time` (`create_time`) 
);

CREATE TABLE `d_pack_details` (
	`id`  int(11) NOT NULL AUTO_INCREMENT ,
	`packid`  bigint(20) NULL DEFAULT 0 COMMENT '红包id' ,
	`uid`  bigint(20) NULL DEFAULT 0 ,
	`coin`  bigint(20) NULL DEFAULT 0 COMMENT '领取的金币值' ,
	`create_time`  int(11) NULL DEFAULT 0 COMMENT '领取时间' ,
	PRIMARY KEY (`id`),
	INDEX `idx_uid` (`uid`) ,
	INDEX `idx_packid` (`packid`) 
);

ALTER TABLE `d_pack` ADD COLUMN `remaincoin`  bigint(20) NULL DEFAULT 0 COMMENT '剩余金币数' AFTER `coin`;
ALTER TABLE `d_pack` COMMENT='红包信息';
ALTER TABLE `d_pack_details` COMMENT='红包领取详情';