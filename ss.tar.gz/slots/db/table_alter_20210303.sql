ALTER TABLE `d_user` CHANGE COLUMN `evoaccount` `guide` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '新手引导步骤' AFTER `spread`;

update s_sign set `count`=10000 where id=1;

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (492, "宙斯", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(492, "zues", 0, 0.1, 0.1, '[10,20,300,5000]', '[4,6,9,12]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 492, "宙斯", 1, 100);
