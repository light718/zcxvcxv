DROP TABLE IF EXISTS `s_shop`;
CREATE TABLE `s_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `ocount` bigint(20) DEFAULT NULL COMMENT '原始金币',
  `count` bigint(20) DEFAULT '0' COMMENT '金币数量',
  `sendcoin` bigint(20) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT '0.00' COMMENT '金额 分',
  `vipExp` int(11) DEFAULT '0' COMMENT 'VIP经验值',
  `icon` varchar(100) DEFAULT NULL COMMENT '图标名',
  `discount` int(11) DEFAULT '0' COMMENT '金额折扣, 10表示10%',
  `discountTime` int(11) DEFAULT '0' COMMENT '限时折扣时间',
  `level` tinyint(1) DEFAULT '1' COMMENT '对应user中的agent',
  `ord` int(11) DEFAULT '10' COMMENT '排序 大靠前',
  `status` tinyint(1) DEFAULT '1' COMMENT '1正常购买 2禁止',
  `cuid` int(11) DEFAULT '0' COMMENT '创建人uid',
  `uuid` int(11) DEFAULT '0' COMMENT '更新人uid',
  `productid` varchar(100) DEFAULT NULL COMMENT '苹果产品id',
  `productid_gp` varchar(100) DEFAULT NULL COMMENT '谷歌产品id',
  `productid_huawei` varchar(100) DEFAULT '' COMMENT '华为商品id',
  `appid` int(11) DEFAULT '0' COMMENT 'appid',
  `stype` tinyint(1) DEFAULT NULL COMMENT '类型1商城 2限时优惠 3转盘 4激励礼包 5等级礼包 6签到 7首充礼包 8onetimeonly 9排行榜时榜 10金猪 13成长基金 14周卡 15月卡 19银锤子 20金锤子',
  `prize` varchar(255) DEFAULT '' COMMENT '礼包权益',
  `cat` int(11) DEFAULT '0' COMMENT '分组',
  `stamppropid` int(11) DEFAULT '0' COMMENT '邮包道具ID',
  `stamppropnum` int(11) DEFAULT '0' COMMENT '邮包道具数量',
  `oamount` decimal(10,2) DEFAULT '0.00' COMMENT '原始金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='商城商品列表';

INSERT INTO `s_shop` VALUES ('3', '金币88,200,000', '2100000', '4200000', '2100000', '9.99', '220', null, '200', '40', '0', '4', '1', '0', '1', 'spinxstudio.pack.5', 'com.rummyfree.10', 'a10', '0', '1', '[{\"s\":8,\"n\":9},{\"s\":10,\"n\":1000},{\"s\":2,\"n\":220},{\"s\":3,\"n\":7200}]', '0', '100043', '2', '0.00');
INSERT INTO `s_shop` VALUES ('4', '金币42,000,000', '1000000', '2000000', '1000000', '4.99', '90', null, '200', '30', '0', '3', '1', '0', '1', 'spinxstudio.pack.4', 'com.rummyfree.5', 'a5', '0', '1', '[{\"s\":8,\"n\":4},{\"s\":10,\"n\":500},{\"s\":2,\"n\":90},{\"s\":3,\"n\":7200}]', '0', '100033', '2', '0.00');
INSERT INTO `s_shop` VALUES ('5', '金币24,150,000', '575000', '1150000', '575000', '2.99', '54', null, '200', '30', '0', '2', '1', '0', '1', 'spinxstudio.pack.3', 'com.rummyfree.3', 'a3', '0', '1', '[{\"s\":8,\"n\":2},{\"s\":10,\"n\":300},{\"s\":2,\"n\":54},{\"s\":3,\"n\":7200}]', '0', '100023', '1', '0.00');
INSERT INTO `s_shop` VALUES ('6', '金币15,750,000', '375000', '750000', '375000', '1.99', '36', null, '200', '30', '0', '1', '1', '0', '1', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '1', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":7200}]', '0', '100013', '1', '0.00');
INSERT INTO `s_shop` VALUES ('16', '金币189,000,000', '4500000', '9000000', '4500000', '19.99', '720', null, '200', '30', '0', '5', '1', '0', '1', 'spinxstudio.pack.6', 'com.rummyfree.12', 'a12', '0', '1', '[{\"s\":8,\"n\":20},{\"s\":10,\"n\":2000},{\"s\":2,\"n\":600},{\"s\":3,\"n\":7200}]', '0', '100053', '3', '0.00');
INSERT INTO `s_shop` VALUES ('17', '金币567,000,000', '13500000', '27000000', '13500000', '49.99', '1500', null, '200', '30', '0', '6', '1', '0', '0', 'spinxstudio.pack.7', 'com.rummyfree.13', 'a13', '0', '1', '[{\"s\":8,\"n\":55},{\"s\":10,\"n\":5000},{\"s\":2,\"n\":1800},{\"s\":3,\"n\":7200}]', '0', '100053', '4', '0.00');
INSERT INTO `s_shop` VALUES ('18', 'limited time pack', null, '3450000', null, '2.99', '1500', null, '200', '300', '0', '6', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', 'a3', '0', '2', '[{\"s\":8,\"n\":2},{\"s\":10,\"n\":300},{\"s\":2,\"n\":54},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('19', '转盘', null, '750000', null, '1.99', '500', null, '5', '30', '0', '6', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '3', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('20', '金币5000', null, '5000', null, '1.99', '1500', null, '5', '30', '0', '6', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '6', '', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('37', '开服活动', '100', '300', null, '0.00', '0', null, '300', '0', '0', '10', '1', '0', '0', 'com.rummyslots.gold1', 'com.rummyfree.1', 'a1', '0', '7', '', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('38', 'one time only', '70000000', '70000000', null, '1.99', '0', null, '1000', '0', '0', '10', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '8', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('39', '等级礼包ingame', '375000', '1875000', null, '0.99', '0', null, '500', '10800', '1', '10', '1', '0', '0', 'spinxstudio.pack.1', 'com.rummyfree.1', 'a1', '0', '5', '[{\"s\":10,\"n\":100},{\"s\":2,\"n\":18},{\"s\":3,\"n\":3600}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('67', '金猪', null, '0', null, '1.99', '1500', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '10', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('79', '成长基金', '0', '0', null, '12.99', '0', null, '2400', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.12', 'com.rummyfree.11', '', '0', '13', '[{\"s\":8,\"n\":12},{\"s\":10,\"n\":1300},{\"s\":2,\"n\":300},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('80', '周卡', '1150000', '1150000', null, '2.99', '0', null, '800', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', 'a3', '0', '14', '[{\"s\":8,\"n\":2},{\"s\":10,\"n\":300},{\"s\":2,\"n\":54},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('81', '月卡', '1260000', '4200000', null, '9.99', '0', null, '1000', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.5', 'com.rummyfree.10', 'a10', '0', '15', '[{\"s\":8,\"n\":9},{\"s\":10,\"n\":1000},{\"s\":2,\"n\":220},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('82', '银锤子', null, '1', null, '0.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.1', 'com.rummyfree.1', 'a1', '0', '19', '[{\"s\":8,\"n\":0},{\"s\":10,\"n\":100},{\"s\":2,\"n\":18},{\"s\":3,\"n\":3600}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('83', '银锤子', null, '3', null, '1.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '19', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('84', '银锤子', null, '5', null, '2.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', 'a3', '0', '19', '[{\"s\":8,\"n\":2},{\"s\":10,\"n\":300},{\"s\":2,\"n\":54},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('85', '银锤子', null, '7', null, '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.5', 'a5', '0', '19', '[{\"s\":8,\"n\":4},{\"s\":10,\"n\":500},{\"s\":2,\"n\":90},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('88', '春季礼包1', null, '3375000', null, '1.99', '36', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '16', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":7200}]', '1', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('89', '春季礼包2', null, '5175000', null, '2.99', '54', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', 'a3', '0', '16', '[{\"s\":8,\"n\":2},{\"s\":10,\"n\":300},{\"s\":2,\"n\":54},{\"s\":3,\"n\":7200}]', '2', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('90', '春季礼包3', null, '9000000', null, '4.99', '90', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.5', 'a5', '0', '16', '[{\"s\":8,\"n\":4},{\"s\":10,\"n\":500},{\"s\":2,\"n\":90},{\"s\":3,\"n\":7200}]', '3', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('91', '金锤子', null, '1', null, '1.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '20', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":3600}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('92', '金锤子', null, '3', null, '2.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', 'a3', '0', '20', '[{\"s\":8,\"n\":2},{\"s\":10,\"n\":300},{\"s\":2,\"n\":54},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('93', '金锤子', null, '5', null, '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.5', 'a5', '0', '20', '[{\"s\":8,\"n\":4},{\"s\":10,\"n\":500},{\"s\":2,\"n\":90},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('94', '金锤子', null, '7', null, '9.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.5', 'com.rummyfree.10', 'a10', '0', '20', '[{\"s\":8,\"n\":9},{\"s\":10,\"n\":1000},{\"s\":2,\"n\":220},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('95', '复活卡5张', '5', '300000', null, '0.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.1', 'com.rummyfree.1', 'a1', '0', '21', '[{\"s\":10,\"n\":100},{\"s\":2,\"n\":18},{\"s\":3,\"n\":3600}]', '0', '0', '0', '9.99');
INSERT INTO `s_shop` VALUES ('96', '复活卡20张', '20', '920000', null, '2.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.3', 'com.rummyfree.3', 'a3', '0', '21', '[{\"s\":8,\"n\":2},{\"s\":10,\"n\":300},{\"s\":2,\"n\":54},{\"s\":3,\"n\":7200}]', '0', '0', '0', '12.99');
INSERT INTO `s_shop` VALUES ('97', '复活卡40张', '40', '1600000', null, '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.4', 'a4', '0', '21', '[{\"s\":8,\"n\":4},{\"s\":10,\"n\":500},{\"s\":2,\"n\":90},{\"s\":3,\"n\":7200}]', '0', '0', '0', '49.99');
INSERT INTO `s_shop` VALUES ('98', 'bingo增强', null, '1800000', null, '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.5', 'a5', '0', '22', '[{\"s\":8,\"n\":4},{\"s\":10,\"n\":500},{\"s\":2,\"n\":90},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('99', 'bingo礼包', null, '600000', null, '1.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.2', 'com.rummyfree.2', 'a2', '0', '23', '[{\"s\":8,\"n\":1},{\"s\":10,\"n\":200},{\"s\":2,\"n\":36},{\"s\":3,\"n\":7200}]', '0', '0', '0', '0.00');
INSERT INTO `s_shop` VALUES ('100', '超级复活卡', '1', '0', null, '0.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.1', 'com.rummyfree.1', 'a1', '0', '24', '[{\"s\":10,\"n\":100},{\"s\":2,\"n\":18},{\"s\":3,\"n\":3600}]', '0', '0', '0', '0.00');