CREATE TABLE `d_chat_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `md5` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户对key',
  `uid1` bigint(20) DEFAULT NULL,
  `uid2` bigint(20) DEFAULT NULL,
  `content` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `unread` tinyint(1) DEFAULT '1' COMMENT '未读 1  已读0',
  `received` tinyint(1) DEFAULT '0' COMMENT '未领 0  已领1',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid1`),
  KEY `uid2` (`uid2`),
  KEY `md5key` (`md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;