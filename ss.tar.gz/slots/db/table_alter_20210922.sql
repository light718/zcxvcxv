ALTER TABLE `d_friend`
ADD COLUMN `create_time`  int(11) NULL AFTER `hastake`;
