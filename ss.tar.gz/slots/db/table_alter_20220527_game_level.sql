update s_game set level=380 where id=660;
update s_game set level=385 where id=609;
update s_game set level=390 where id=630;
update s_game set level=395 where id=671;

-- 阿拉伯语的游戏放最后面
update s_game set level=400 where id=691;
update s_game set level=405 where id=692;
update s_game set level=410 where id=693;
update s_game set level=415 where id=694;
update s_game set level=420 where id=695;
update s_game set level=425 where id=696;