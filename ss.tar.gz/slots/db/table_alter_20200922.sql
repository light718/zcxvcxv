ALTER TABLE `s_config_level_upgrade` 
ADD COLUMN `stamppropid` int(11) NULL DEFAULT 0 COMMENT '邮包道具ID' AFTER `expendconsume`,
ADD COLUMN `stamppropnum` int(11) NULL DEFAULT 0 COMMENT '邮包道具数量' AFTER `stamppropid`;

ALTER TABLE `s_shop` 
ADD COLUMN `stamppropid` int(11) NULL DEFAULT 0 COMMENT '邮包道具ID' AFTER `cat`,
ADD COLUMN `stamppropnum` int(11) NULL DEFAULT 0 COMMENT '邮包道具数量' AFTER `stamppropid`;
replace into s_config(id,k,v,memo) value(43,'bankruptcoin',20000,'破产补助');
