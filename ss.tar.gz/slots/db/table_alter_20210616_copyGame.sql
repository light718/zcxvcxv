
-- 647 德墨忒尔 Demeter-Gooddes of fertility  
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    647, "德墨忒尔", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 491
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    647, "DemeterGooddes", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 491
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 647, "德墨忒尔", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 491
LIMIT 1;


-- 648 赫尔墨斯 Hermes-The Shepherd God
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    648, "赫尔墨斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 456
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    648, "Hermes", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 456
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 648, "赫尔墨斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 456
LIMIT 1;


-- 649 奥德修斯 The wise and brave Odysseus
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    649, "奥德修斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 509
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    649, "Odysseus", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 509
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 649, "奥德修斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 509
LIMIT 1;


-- 650 普罗米修斯 Prometheus-The god of SelflessForesight
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    650, "普罗米修斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 508
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    650, "Prometheus", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 508
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 650, "普罗米修斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 508
LIMIT 1;


-- 651 帕修斯 Perseus' Battlefield
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    651, "帕修斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 501
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    651, "Perseus", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 501
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 651, "帕修斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 501
LIMIT 1;


-- 652 狮身人面像 Sphinx
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    652, "狮身人面像", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 494
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    652, "Sphinx", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 494
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 652, "狮身人面像", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 494
LIMIT 1;


-- 653 曹操 Eemperor devil
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    653, "曹操", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 426
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    653, "EemperorDevil", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 426
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 653, "曹操", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 426
LIMIT 1;


-- 654 齐天大圣孙悟空 monkey king
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    654, "齐天大圣孙悟空", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 502
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    654, "MonkeyKing", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 502
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 654, "齐天大圣孙悟空", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 502
LIMIT 1;


-- 655 巨人族约尔孟甘德 Huge Anaconda
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    655, "巨人族约尔孟甘德", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 499
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    655, "Anaconda", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 499
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 655, "巨人族约尔孟甘德", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 499
LIMIT 1;


-- 656 九头鸟 Bird with Nine Heads
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    656, "九头鸟", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 498
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    656, "BirdWithNineHeads", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 498
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 656, "九头鸟", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 498
LIMIT 1;


-- 657 魔法青蛙 Magic Frog
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    657, "魔法青蛙", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 487
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    657, "MagicFrog", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 487
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 657, "魔法青蛙", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 487
LIMIT 1;


-- 658 矮人与公主 Dwarfs and Princess
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    658, "矮人与公主", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 488
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    658, "DwarfsAndPrincess", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 488
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 658, "矮人与公主", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 488
LIMIT 1;


-- 659 幸运圣诞老人 Lucky Santa
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    659, "幸运圣诞老人", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 444
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    659, "LuckySanta", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 444
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 659, "幸运圣诞老人", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 444
LIMIT 1;


-- 660 凤凰 The Phoenix
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    660, "凤凰", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 505
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    660, "ThePhoenix", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 505
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 660, "凤凰", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 505
LIMIT 1;


-- 661 侠盗罗宾逊 Robin Hood
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    661, "侠盗罗宾逊", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 511
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    661, "RobinHood", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 511
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 661, "侠盗罗宾逊", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 511
LIMIT 1;


-- 662 兔女郎 Bunny Girl
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    662, "兔女郎", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 497
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    662, "BunnyGirl", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 497
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 662, "兔女郎", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 497
LIMIT 1;


-- 663 黄金矿工 Gold Miner
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    663, "黄金矿工", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 493
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    663, "GoldMiner", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 493
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 663, "黄金矿工", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 493
LIMIT 1;


-- 664 发明之父 Father of Invention
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    664, "发明之父", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 484
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    664, "FatherOfInvention", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 484
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 664, "发明之父", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 484
LIMIT 1;


-- 665 西部牛仔 West Cowboy
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    665, "西部牛仔", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 495
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    665, "WestCowboy", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 495
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 665, "西部牛仔", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 495
LIMIT 1;


-- 666 德川家康 Rising Sun The Great King
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    666, "德川家康", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 500
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    666, "RisingSun", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 500
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 666, "德川家康", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 500
LIMIT 1;


-- 667 丰臣秀吉 Political Strategist
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    667, "丰臣秀吉", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 507
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    667, "PoliticalStrategist", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 507
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 667, "丰臣秀吉", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 507
LIMIT 1;


-- 668 花木兰 Mulan
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    668, "花木兰", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 490
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    668, "Mulan", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 490
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 668, "花木兰", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 490
LIMIT 1;


-- 669 成吉思汗 Genghis Khan
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    669, "成吉思汗", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 492
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    669, "GenghisKhan", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 492
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 669, "成吉思汗", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 492
LIMIT 1;

