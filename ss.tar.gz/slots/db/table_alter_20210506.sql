
-- 玛雅迪奥罗 jackpot值修改
UPDATE `s_game` SET `jackpot` = '[5,10,50,100,1000]' WHERE id = 500;