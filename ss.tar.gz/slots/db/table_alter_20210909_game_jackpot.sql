-- 美女与野兽奖池修改
update `s_game` set `jackpot` = '[5,20,100,500]' where `id` = 525;
