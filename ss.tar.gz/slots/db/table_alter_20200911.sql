-- delete from `s_sess` where gameid >= 429 and gameid <= 445;
-- delete from `s_game` where id >= 429 and id <= 445;
-- delete from `s_game_type` where gameid >= 429 and gameid <= 445;


-- select * from `s_sess` where gameid >= 429 and gameid <= 445;
-- select id, title from `s_game` where id >= 429 and id <= 445;
-- select * from `s_game_type` where gameid >= 429 and gameid <= 445;

--刘琴 
--429  吸烟狗  smokinghotpickes
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (429, "吸烟狗", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(429, "smokinghotpickes", 0, 0.1, 0.1, '[5,20,50,150,1000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 429, "吸烟狗", 1, 100);

--430  大双子星  grandgemini
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (430, "大双子星", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(430, "grandgemini", 0, 0.1, 0.1, '[20,50,5000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 430, "大双子星", 1, 100);

--431 怪物现金 monstercash
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (431, "怪物现金", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(431, "monstercash", 0, 0.1, 0.1, '[20,50,5000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 431, "怪物现金", 1, 100);

--432 幸运财神  fortunewilddeluxe
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (432, "幸运财神", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(432, "fortunewilddeluxe", 0, 0.1, 0.1, '[10,50,500,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 432, "幸运财神", 1, 100);

--433 丘比特  cupidiscrush
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (433, "丘比特", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(433, "cupidiscrush", 0, 0.1, 0.1, '[5,10,20,100,1000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 433, "丘比特", 1, 100);

--434 丘比特大  cupidiscrushdeluxe
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (434, "丘比特大", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(434, "cupidiscrushdeluxe", 0, 0.1, 0.1, '[5,10,20,100,1000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 434, "丘比特大", 1, 100);


--科长
--435 钻石森林 diamondforest
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (435, "钻石森林", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(435, "diamondforest", 0, 0.1, 0.1, '[10,500,5000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 435, "钻石森林", 1, 100);

-- 436 快速开火 speedyfire
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (436, "快速开火", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(436, "speedyfire", 0, 0.1, 0.1, '[5,10,500,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 436, "快速开火", 1, 100);

-- 437 华丽的埃及艳后 gorgeouscleopatra
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (437, "华丽的埃及艳后", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(437, "gorgeouscleopatra", 0, 0.1, 0.1, '[10,20,200,1000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 437, "华丽的埃及艳后", 1, 100);

-- 438 野狼 icywolf
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (438, "野狼", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(438, "icywolf", 0, 0.1, 0.1, '[5,10,600,1200,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 438, "野狼", 1, 100);

-- 439 熊猫 majesticpanda
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (439, "熊猫", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub,jackpot) values(439, "majesticpanda", 0, 0.1, 0.1, '[20,50,200,1000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 439, "熊猫", 1, 100);

-- 440 苏轼的情人 sushilover
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (440, "苏轼的情人", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(440, "sushilover", 0, 0.1, 0.1, '[10,500,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 440, "苏轼的情人", 1, 100);


--胡文良
-- 441 野马 thunderingmustang
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (441, "野马", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(441, "thunderingmustang", 0, 0.1, 0.1, '[5,10,15,20,30,50,100,500,1000,2000,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 441, "野马", 1, 100);

--442 财富精灵 fortunegenie 
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (442, "财富精灵", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(442, "fortunegenie", 0, 0.1, 0.1, '[5,10,20,50,500,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 442, "财富精灵", 1, 100);

-- 443 神龙 powerifdragon
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (443, "神龙", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(443, "powerifdragon", 0, 0.1, 0.1, '[10,20,500,1200,5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 443, "神龙", 1, 100);

-- 444 圣诞老人 bigmoneyholidayfrenzy
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (444, "圣诞老人", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(444, "bigmoneyholidayfrenzy", 0, 0.1, 0.1, '[10,20,100,500]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 444, "圣诞老人", 1, 100);

-- 445 女巫的财富 witchoffortune
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (445, "女巫的财富", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(445, "witchoffortune", 0, 0.1, 0.1, '[10,20,100,500]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 445, "女巫的财富", 1, 100);


--刘琴 
--428 奥林匹斯国王
--429  吸烟狗  smokinghotpickes
--430  大双子星  grandgemini
--431 怪物现金 monstercash
--432 幸运财神  fortunewilddeluxe
--433 丘比特  cupidiscrush
--434 丘比特大  cupidiscrushdeluxe

--科长
--435 钻石森林 diamondforest
-- 436 快速开火 speedyfire
-- 437 华丽的埃及艳后 gorgeouscleopatra
-- 438 野狼 icywolf
-- 439 熊猫 majesticpanda
-- 440 苏轼的情人 sushilover

--胡文良
-- 441 野马 thunderingmustang
--442 财富精灵 fortunegenie 
-- 443 神龙 powerifdragon
-- 444 圣诞老人 bigmoneyholidayfrenzy
-- 445 女巫的财富 witchoffortune
