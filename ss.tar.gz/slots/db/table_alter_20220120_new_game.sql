-- 巨龙钻石 Dragon Diamond
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat)
values (536, "巨龙钻石", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(536, "DragonDiamond", 0, 0.1, 0.1, '[100]', '[9]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 536, "巨龙钻石", 1, 100);
