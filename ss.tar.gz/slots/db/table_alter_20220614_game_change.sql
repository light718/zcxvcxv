-- 删除目前不用的字段
ALTER TABLE `s_game` DROP COLUMN `robotcoin`;
ALTER TABLE `s_game` DROP COLUMN `bankercoin`;
ALTER TABLE `s_game` DROP COLUMN `lv`;
ALTER TABLE `s_game` DROP COLUMN `storage`;
ALTER TABLE `s_game` DROP COLUMN `newmark`;
ALTER TABLE `s_game` DROP COLUMN `newstorage`;
ALTER TABLE `s_game` DROP COLUMN `targetstorage`;
ALTER TABLE `s_game` DROP COLUMN `targetminrate`;
ALTER TABLE `s_game` DROP COLUMN `winrate`;
ALTER TABLE `s_game` DROP COLUMN `loserate`;
ALTER TABLE `s_game` DROP COLUMN `storaterate`;
ALTER TABLE `s_game` DROP COLUMN `iscontrol`;
ALTER TABLE `s_game` DROP COLUMN `uuid`;
ALTER TABLE `s_game` DROP COLUMN `cuid`;
ALTER TABLE `s_game` DROP COLUMN `robot`;
ALTER TABLE `s_game` DROP COLUMN `isHundred`;
ALTER TABLE `s_game` DROP COLUMN `apply_coin`;
ALTER TABLE `s_game` DROP COLUMN `bet_mincoin`;
ALTER TABLE `s_game` DROP COLUMN `type`;
ALTER TABLE `s_game` DROP COLUMN `aicontrol`;
ALTER TABLE `s_game` DROP COLUMN `collector`;

-- 将状态字段从s_game_type中转移过来
UPDATE `s_game`
LEFT JOIN `s_game_type` ON `s_game`.id = `s_game_type`.gameid
SET `s_game`.status = `s_game_type`.state
WHERE 1=1;

-- 将Null字段设置成0
UPDATE `s_game` SET status=0 where status IS NULL;