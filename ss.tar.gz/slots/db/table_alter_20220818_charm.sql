UPDATE s_send_charm SET `type`=1, `count`=2000000, charm=2000000 where id=2;

UPDATE s_send_charm SET `charm`=count div 10000 where 1=1;

-- 清空已有魅力值
UPDATE d_user SET charm=0 where 1=1;


-- redis操作
-- echo "keys d_user:*" | redis-cli -a xingC99 -n 5 | xargs -I {} echo hset {} charm 0| redis-cli -a xingC99 -n 5

-- gametask 删除第五个任务
delete from s_game_task_detail where detailid=3 and taskid=5;