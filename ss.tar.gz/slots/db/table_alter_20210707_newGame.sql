-- 神龙 dragon8
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (516, "神龙", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(516, "dragon8", 0, 0.1, 0.1, '[5,10,50,250]', '[1,3,6,9]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 516, "神龙", 1, 500);