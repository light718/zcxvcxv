update s_config set v=2000000 where k='initcoin';
