-- 换皮游戏

-- 640 服部半藏 The Magic Hanzo
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    640, "服部半藏", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 471;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    640, "themagichanzo", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 471;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 640, "服部半藏", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 471;
