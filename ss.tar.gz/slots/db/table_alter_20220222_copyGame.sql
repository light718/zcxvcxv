
-- 691 波斯王子 PrinceOfPersia
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    691, "波斯王子", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 530
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    691, "princeofpersia", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 530
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 691, "波斯王子", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 530
LIMIT 1;


-- 692 弓箭手 Archer
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    692, "弓箭手", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 496
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    692, "archer", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 496
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 692, "弓箭手", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 496
LIMIT 1;


-- 693 阿里巴巴四十大盗 Alibaba
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    693, "阿里巴巴四十大盗", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 527
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    693, "alibaba", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 527
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 693, "阿里巴巴四十大盗", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 527
LIMIT 1;


-- 694 薛西斯 Xerxes
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    694, "薛西斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 528
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    694, "xerxes", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 528
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 694, "薛西斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 528
LIMIT 1;


-- 695 尼布甲尼撒二世和空中花园 HangingGarden
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    695, "尼布甲尼撒二世和空中花园", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 525
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    695, "hanginggarden", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 525
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 695, "尼布甲尼撒二世和空中花园", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 525
LIMIT 1;


-- 696 辛巴达航海冒险 Sinbad
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    696, "辛巴达航海冒险", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 529
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    696, "sinbad", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 529
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 696, "辛巴达航海冒险", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 529
LIMIT 1;

