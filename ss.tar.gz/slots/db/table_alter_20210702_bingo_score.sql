-- 修改小关卡分数奖励
UPDATE `s_bingo_reward` SET `score` = 1 WHERE `type`=1;