ALTER TABLE `d_user_login_log` ADD COLUMN `logout_level`  int(11) NULL DEFAULT 0 COMMENT '退出时等级' AFTER `logout_time`;

ALTER TABLE `d_user_login_log` ADD COLUMN `login_level`  int(11) NULL AFTER `logout_time`;

ALTER TABLE `s_shop` MODIFY COLUMN `oamount`  decimal(10,2) NULL DEFAULT 0 COMMENT '原始金额' AFTER `stamppropnum`;

update s_shop set oamount=9.99 where id=95 and amount=0.99;
update s_shop set oamount=19.99 where id=96 and amount=2.99;
update s_shop set oamount=49.99 where id=97 and amount=4.99;

ALTER TABLE `d_pack` ADD COLUMN `robot`  tinyint(1) NULL DEFAULT 0 COMMENT '是否后台机器人发放' AFTER `create_time`;