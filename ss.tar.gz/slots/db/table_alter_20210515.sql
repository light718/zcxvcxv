ALTER TABLE `d_friend` ADD COLUMN `hastake`  tinyint(1) NULL DEFAULT 0 COMMENT '是否已被领取' AFTER `coin`;
