-- 东部财富 更改jp属性
UPDATE `s_game` SET `jackpot` = '[5,20,100,300,10000]', `jp_unlock_lv` = '[4,6,9,12,16]' WHERE id = 482;