-- 感恩节派对 Thanks Giving Party
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (508, "感恩节派对", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(508, "thanksgivingparty", 0, 0.1, 0.1, '[5,10,40,150,300]', '[1,1,1,1,1]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 508, "感恩节派对", 1, 100);
