DROP TABLE IF EXISTS `s_game_task`;
CREATE TABLE `s_game_task` (
  `roundid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `gameid` int(11) NOT NULL,
  `rewardid` int(11) NOT NULL DEFAULT '0',
  `rewardnum` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`roundid`,`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `s_game_task` VALUES ('1', '1', '616', '1', '1500000');
INSERT INTO `s_game_task` VALUES ('1', '2', '611', '1', '2250000');
INSERT INTO `s_game_task` VALUES ('1', '3', '630', '1', '3375000');
INSERT INTO `s_game_task` VALUES ('1', '4', '608', '1', '4000000');
INSERT INTO `s_game_task` VALUES ('1', '5', '602', '1', '8000000');
INSERT INTO `s_game_task` VALUES ('1', '6', '664', '1', '12000000');
INSERT INTO `s_game_task` VALUES ('2', '1', '616', '1', '3750000');
INSERT INTO `s_game_task` VALUES ('2', '2', '611', '1', '5625000');
INSERT INTO `s_game_task` VALUES ('2', '3', '630', '1', '8437500');
INSERT INTO `s_game_task` VALUES ('2', '4', '608', '1', '10000000');
INSERT INTO `s_game_task` VALUES ('2', '5', '602', '1', '20000000');
INSERT INTO `s_game_task` VALUES ('2', '6', '664', '1', '30000000');

DROP TABLE IF EXISTS `s_game_task_detail`;
CREATE TABLE `s_game_task_detail` (
  `roundid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `detailid` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  `param1` int(11) DEFAULT NULL,
  `param2` int(11) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`roundid`,`taskid`,`detailid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `s_game_task_detail` VALUES ('1', '1', '1', '1', null, null, '30');
INSERT INTO `s_game_task_detail` VALUES ('1', '1', '2', '3', null, null, '2000000');
INSERT INTO `s_game_task_detail` VALUES ('1', '2', '1', '1', null, '1', '1');
INSERT INTO `s_game_task_detail` VALUES ('1', '2', '2', '3', null, null, '8000000');
INSERT INTO `s_game_task_detail` VALUES ('1', '3', '1', '2', null, null, '25');
INSERT INTO `s_game_task_detail` VALUES ('1', '3', '2', '4', null, null, '3500000');
INSERT INTO `s_game_task_detail` VALUES ('1', '4', '1', '6', '2', null, '45');
INSERT INTO `s_game_task_detail` VALUES ('1', '4', '2', '7', null, null, '80');
INSERT INTO `s_game_task_detail` VALUES ('1', '5', '1', '4', null, null, '10000000');
INSERT INTO `s_game_task_detail` VALUES ('1', '5', '2', '6', '2', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('1', '5', '3', '1', '1', null, '1');
INSERT INTO `s_game_task_detail` VALUES ('1', '6', '1', '6', '6', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('1', '6', '2', '1', null, '1', '1');
INSERT INTO `s_game_task_detail` VALUES ('1', '6', '3', '4', '1', null, '2400000');
INSERT INTO `s_game_task_detail` VALUES ('2', '1', '1', '1', null, null, '60');
INSERT INTO `s_game_task_detail` VALUES ('2', '1', '2', '3', null, null, '8000000');
INSERT INTO `s_game_task_detail` VALUES ('2', '2', '1', '1', null, '1', '1');
INSERT INTO `s_game_task_detail` VALUES ('2', '2', '2', '3', null, null, '12000000');
INSERT INTO `s_game_task_detail` VALUES ('2', '3', '1', '2', null, null, '35');
INSERT INTO `s_game_task_detail` VALUES ('2', '3', '2', '4', null, null, '10000000');
INSERT INTO `s_game_task_detail` VALUES ('2', '4', '1', '6', '2', null, '45');
INSERT INTO `s_game_task_detail` VALUES ('2', '4', '2', '7', '1', null, '1600');
INSERT INTO `s_game_task_detail` VALUES ('2', '5', '1', '4', null, null, '15000000');
INSERT INTO `s_game_task_detail` VALUES ('2', '5', '2', '6', '2', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('2', '5', '3', '1', '1', null, '1');
INSERT INTO `s_game_task_detail` VALUES ('2', '6', '1', '6', '6', null, '80');
INSERT INTO `s_game_task_detail` VALUES ('2', '6', '2', '1', null, '1', '1');
INSERT INTO `s_game_task_detail` VALUES ('2', '6', '3', '4', '1', null, '4000000');