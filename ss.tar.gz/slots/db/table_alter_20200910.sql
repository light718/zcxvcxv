ALTER TABLE `s_shop_order` ADD COLUMN `user_level` int(11) NULL DEFAULT 0 COMMENT '用户等级' AFTER `stype`;

ALTER TABLE `d_user_login_log`  ADD COLUMN `onlinetime` int(11) NULL COMMENT '在线时长' AFTER `logout_time`, ADD COLUMN `coin` double(20, 2) NULL COMMENT '金币数' AFTER `onlinetime`;

CREATE TABLE `d_bankrupt_log`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NULL COMMENT 'userid',
  `level` int(11) NULL COMMENT '等级',
  `coin` double(20, 2) NULL COMMENT '破产时候的金币',
  `create_time` int(11) NULL COMMENT '破产时间',
  PRIMARY KEY (`id`),
  INDEX `time`(`create_time`),
  INDEX `uid`(`uid`)
) COMMENT = '破产记录';

ALTER TABLE `s_shop_order` ADD COLUMN `user_coin` double(20, 2) NULL COMMENT '用户当前金币' AFTER `user_level`;

update s_sess set mincoin=10000 where gameid=252 and level=2;
update s_sess set mincoin=200000 where gameid=252 and level=3;
update s_sess set mincoin=2000000 where gameid=252 and level=4;
update s_sess set mincoin=20000000 where gameid=252 and level=5;

update s_game_type set hot=5 where gameid=422;
update s_game_type set hot=6 where gameid=420;
update s_game_type set hot=7 where gameid=421;