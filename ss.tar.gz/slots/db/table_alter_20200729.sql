DROP TABLE IF EXISTS `d_user_login_log`;
CREATE TABLE `d_user_login_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT 'uid',
  `login_type` int(11) DEFAULT NULL COMMENT '登录方式',
  `create_time` int(11) DEFAULT NULL COMMENT '登录时间',
  `channel` varchar(255) DEFAULT NULL COMMENT '客户端',
  `apkversion` varchar(100) DEFAULT NULL COMMENT 'apk_version',
  `resversion` varchar(50) DEFAULT NULL COMMENT 'res_version',
  `extr` varchar(300) DEFAULT NULL COMMENT '扩展字段',
  PRIMARY KEY (`Id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户登录日志表';
