-- 重新设置每日签到
TRUNCATE TABLE s_sign_new;
INSERT INTO s_sign_new values(1, 84000, '[{"s":2,"n":40}]');
INSERT INTO s_sign_new values(2, 168000, '[{"s":3,"n":7200}]');
INSERT INTO s_sign_new values(3, 336000, '[{"s":34,"n":1}]');
INSERT INTO s_sign_new values(4, 504000, '[{"s":9,"n":3}]');
INSERT INTO s_sign_new values(5, 840000, '[{"s":16,"n":30}]');
INSERT INTO s_sign_new values(6, 1680000, '[{"s":3,"n":14400}]');
INSERT INTO s_sign_new values(7, 2520000, '[{"s":31,"n":1},{"s":8,"n":3}]');

INSERT INTO s_sign_new values(8, 84000, '[{"s":2,"n":40}]');
INSERT INTO s_sign_new values(9, 168000, '[{"s":3,"n":7200}]');
INSERT INTO s_sign_new values(10, 336000, '[{"s":34,"n":1}]');
INSERT INTO s_sign_new values(11, 504000, '[{"s":9,"n":3}]');
INSERT INTO s_sign_new values(12, 840000, '[{"s":16,"n":30}]');
INSERT INTO s_sign_new values(13, 1680000, '[{"s":3,"n":14400}]');
INSERT INTO s_sign_new values(14, 2520000, '[{"s":31,"n":1},{"s":8,"n":3}]');

INSERT INTO s_sign_new values(15, 84000, '[{"s":2,"n":40}]');
INSERT INTO s_sign_new values(16, 168000, '[{"s":3,"n":7200}]');
INSERT INTO s_sign_new values(17, 336000, '[{"s":34,"n":1}]');
INSERT INTO s_sign_new values(18, 504000, '[{"s":9,"n":3}]');
INSERT INTO s_sign_new values(19, 840000, '[{"s":16,"n":30}]');
INSERT INTO s_sign_new values(20, 1680000, '[{"s":3,"n":14400}]');
INSERT INTO s_sign_new values(21, 2520000, '[{"s":31,"n":1},{"s":8,"n":3}]');

INSERT INTO s_sign_new values(22, 84000, '[{"s":2,"n":40}]');
INSERT INTO s_sign_new values(23, 168000, '[{"s":3,"n":7200}]');
INSERT INTO s_sign_new values(24, 336000, '[{"s":34,"n":1}]');
INSERT INTO s_sign_new values(25, 504000, '[{"s":9,"n":3}]');
INSERT INTO s_sign_new values(26, 840000, '[{"s":16,"n":30}]');
INSERT INTO s_sign_new values(27, 1680000, '[{"s":3,"n":14400}]');
INSERT INTO s_sign_new values(28, 2520000, '[{"s":31,"n":1},{"s":8,"n":3}]');