/*
 Navicat MySQL Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 80012
 Source Host           : localhost:3306
 Source Schema         : game_7075

 Target Server Type    : MySQL
 Target Server Version : 80012
 File Encoding         : 65001

 Date: 05/12/2020 10:06:10
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for s_config_level_bet
-- ----------------------------
DROP TABLE IF EXISTS `s_config_level_bet`;
CREATE TABLE `s_config_level_bet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `betcoin` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idxlevel` (`level`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COMMENT='slots等级押注额配置';

-- ----------------------------
-- Records of s_config_level_bet
-- ----------------------------
BEGIN;
INSERT INTO `s_config_level_bet` VALUES (1, 1, 10000);
INSERT INTO `s_config_level_bet` VALUES (2, 2, 20000);
INSERT INTO `s_config_level_bet` VALUES (3, 3, 50000);
INSERT INTO `s_config_level_bet` VALUES (4, 4, 100000);
INSERT INTO `s_config_level_bet` VALUES (5, 5, 150000);
INSERT INTO `s_config_level_bet` VALUES (6, 6, 200000);
INSERT INTO `s_config_level_bet` VALUES (7, 7, 300000);
INSERT INTO `s_config_level_bet` VALUES (8, 8, 400000);
INSERT INTO `s_config_level_bet` VALUES (9, 9, 500000);
INSERT INTO `s_config_level_bet` VALUES (10, 10, 600000);
INSERT INTO `s_config_level_bet` VALUES (11, 11, 700000);
INSERT INTO `s_config_level_bet` VALUES (12, 12, 800000);
INSERT INTO `s_config_level_bet` VALUES (13, 13, 900000);
INSERT INTO `s_config_level_bet` VALUES (14, 14, 1000000);
INSERT INTO `s_config_level_bet` VALUES (15, 15, 1500000);
INSERT INTO `s_config_level_bet` VALUES (16, 16, 2000000);
INSERT INTO `s_config_level_bet` VALUES (17, 17, 2500000);
INSERT INTO `s_config_level_bet` VALUES (18, 18, 3000000);
INSERT INTO `s_config_level_bet` VALUES (19, 19, 3500000);
INSERT INTO `s_config_level_bet` VALUES (20, 20, 4000000);
INSERT INTO `s_config_level_bet` VALUES (21, 21, 4500000);
INSERT INTO `s_config_level_bet` VALUES (22, 22, 5000000);
INSERT INTO `s_config_level_bet` VALUES (23, 23, 6000000);
INSERT INTO `s_config_level_bet` VALUES (24, 24, 7000000);
INSERT INTO `s_config_level_bet` VALUES (25, 25, 8000000);
INSERT INTO `s_config_level_bet` VALUES (26, 26, 9000000);
INSERT INTO `s_config_level_bet` VALUES (27, 27, 10000000);
INSERT INTO `s_config_level_bet` VALUES (28, 28, 11000000);
INSERT INTO `s_config_level_bet` VALUES (29, 29, 12000000);
INSERT INTO `s_config_level_bet` VALUES (30, 30, 13000000);
INSERT INTO `s_config_level_bet` VALUES (31, 31, 14000000);
INSERT INTO `s_config_level_bet` VALUES (32, 32, 15000000);
INSERT INTO `s_config_level_bet` VALUES (33, 33, 20000000);
INSERT INTO `s_config_level_bet` VALUES (34, 34, 30000000);
INSERT INTO `s_config_level_bet` VALUES (35, 35, 40000000);
INSERT INTO `s_config_level_bet` VALUES (36, 36, 50000000);
INSERT INTO `s_config_level_bet` VALUES (37, 37, 60000000);
INSERT INTO `s_config_level_bet` VALUES (38, 38, 70000000);
INSERT INTO `s_config_level_bet` VALUES (39, 39, 88000000);
INSERT INTO `s_config_level_bet` VALUES (40, 40, 100000000);
INSERT INTO `s_config_level_bet` VALUES (41, 41, 150000000);
INSERT INTO `s_config_level_bet` VALUES (42, 42, 200000000);
INSERT INTO `s_config_level_bet` VALUES (43, 43, 250000000);
INSERT INTO `s_config_level_bet` VALUES (44, 44, 300000000);
INSERT INTO `s_config_level_bet` VALUES (45, 45, 350000000);
INSERT INTO `s_config_level_bet` VALUES (46, 46, 380000000);
INSERT INTO `s_config_level_bet` VALUES (47, 47, 420000000);
INSERT INTO `s_config_level_bet` VALUES (48, 48, 480000000);
INSERT INTO `s_config_level_bet` VALUES (49, 49, 520000000);
INSERT INTO `s_config_level_bet` VALUES (50, 50, 560000000);
INSERT INTO `s_config_level_bet` VALUES (51, 51, 600000000);
INSERT INTO `s_config_level_bet` VALUES (52, 52, 650000000);
INSERT INTO `s_config_level_bet` VALUES (53, 53, 700000000);
INSERT INTO `s_config_level_bet` VALUES (54, 54, 750000000);
INSERT INTO `s_config_level_bet` VALUES (55, 55, 800000000);
INSERT INTO `s_config_level_bet` VALUES (56, 56, 830000000);
INSERT INTO `s_config_level_bet` VALUES (57, 57, 880000000);
INSERT INTO `s_config_level_bet` VALUES (58, 58, 920000000);
INSERT INTO `s_config_level_bet` VALUES (59, 59, 960000000);
INSERT INTO `s_config_level_bet` VALUES (60, 60, 1000000000);
INSERT INTO `s_config_level_bet` VALUES (61, 61, 1050000000);
INSERT INTO `s_config_level_bet` VALUES (62, 62, 1100000000);
INSERT INTO `s_config_level_bet` VALUES (63, 63, 1150000000);
INSERT INTO `s_config_level_bet` VALUES (64, 64, 1200000000);
INSERT INTO `s_config_level_bet` VALUES (65, 65, 1250000000);
INSERT INTO `s_config_level_bet` VALUES (66, 66, 1300000000);
INSERT INTO `s_config_level_bet` VALUES (67, 67, 1350000000);
INSERT INTO `s_config_level_bet` VALUES (68, 68, 1400000000);
INSERT INTO `s_config_level_bet` VALUES (69, 69, 1420000000);
INSERT INTO `s_config_level_bet` VALUES (70, 70, 1450000000);
INSERT INTO `s_config_level_bet` VALUES (71, 71, 1520000000);
INSERT INTO `s_config_level_bet` VALUES (72, 72, 1550000000);
INSERT INTO `s_config_level_bet` VALUES (73, 73, 1600000000);
INSERT INTO `s_config_level_bet` VALUES (74, 74, 1650000000);
INSERT INTO `s_config_level_bet` VALUES (75, 75, 1700000000);
INSERT INTO `s_config_level_bet` VALUES (76, 76, 1720000000);
INSERT INTO `s_config_level_bet` VALUES (77, 77, 1780000000);
INSERT INTO `s_config_level_bet` VALUES (78, 78, 1820000000);
INSERT INTO `s_config_level_bet` VALUES (79, 79, 1900000000);
INSERT INTO `s_config_level_bet` VALUES (80, 80, 1980000000);
INSERT INTO `s_config_level_bet` VALUES (81, 81, 2000000000);
INSERT INTO `s_config_level_bet` VALUES (82, 82, 2150000000);
INSERT INTO `s_config_level_bet` VALUES (83, 83, 2250000000);
INSERT INTO `s_config_level_bet` VALUES (84, 84, 2350000000);
INSERT INTO `s_config_level_bet` VALUES (85, 85, 2450000000);
INSERT INTO `s_config_level_bet` VALUES (86, 86, 2500000000);
INSERT INTO `s_config_level_bet` VALUES (87, 87, 2600000000);
INSERT INTO `s_config_level_bet` VALUES (88, 88, 2700000000);
INSERT INTO `s_config_level_bet` VALUES (89, 89, 2800000000);
INSERT INTO `s_config_level_bet` VALUES (90, 90, 2900000000);
INSERT INTO `s_config_level_bet` VALUES (91, 91, 3000000000);
INSERT INTO `s_config_level_bet` VALUES (92, 92, 3050000000);
INSERT INTO `s_config_level_bet` VALUES (93, 93, 3150000000);
INSERT INTO `s_config_level_bet` VALUES (94, 94, 3250000000);
INSERT INTO `s_config_level_bet` VALUES (95, 95, 3350000000);
INSERT INTO `s_config_level_bet` VALUES (96, 96, 3450000000);
INSERT INTO `s_config_level_bet` VALUES (97, 97, 3500000000);
INSERT INTO `s_config_level_bet` VALUES (98, 98, 3600000000);
INSERT INTO `s_config_level_bet` VALUES (99, 99, 3700000000);
INSERT INTO `s_config_level_bet` VALUES (100, 100, 3800000000);
INSERT INTO `s_config_level_bet` VALUES (101, 101, 3900000000);
INSERT INTO `s_config_level_bet` VALUES (102, 102, 4000000000);
INSERT INTO `s_config_level_bet` VALUES (103, 103, 4100000000);
INSERT INTO `s_config_level_bet` VALUES (104, 104, 4150000000);
INSERT INTO `s_config_level_bet` VALUES (105, 105, 4250000000);
INSERT INTO `s_config_level_bet` VALUES (106, 106, 4294967295);
INSERT INTO `s_config_level_bet` VALUES (107, 107, 4294967295);
INSERT INTO `s_config_level_bet` VALUES (108, 108, 4294967295);
INSERT INTO `s_config_level_bet` VALUES (109, 109, 4294967295);
INSERT INTO `s_config_level_bet` VALUES (110, 110, 4294967295);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
