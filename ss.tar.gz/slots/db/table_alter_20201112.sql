--刘琴 
--469  灿烂的岛屿 splendidisland
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (469, "灿烂的岛屿", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(469, "splendidisland", 0, 0.1, 0.1, '[5,10,100,1000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 469, "灿烂的岛屿", 1, 100);

--470  快速白金支付 rapidplatinumpay
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (470, "快速白金支付", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(470, "rapidplatinumpay", 0, 0.1, 0.1, '[10,50,100,650,2000,300]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 470, "快速白金支付", 1, 100);



--科长
--471 插槽塔 slotstower
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (471, "插槽塔", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot) values(471, "slotstower", 0, 0.1, 0.1, '[10,50, 500, 5000]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 471, "插槽塔", 1, 100);
