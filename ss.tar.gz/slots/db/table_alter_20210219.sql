ALTER TABLE `s_shop` MODIFY COLUMN `stype` tinyint(1) NULL DEFAULT NULL COMMENT '类型1商城 2限时优惠 3转盘 4激励礼包 5等级礼包 6签到 7首充礼包 8onetimeonly 9排行榜时榜 10金猪 13成长基金 14周卡 15月卡' AFTER `appid`;

INSERT INTO `s_shop` VALUES (80, '周卡', 1150000, 1150000, 2.99, 0, NULL, 800, 0, 1, 10, 1, 0, 0, 'spinxstudio.pack.3', 'com.rummyfree.3', '', 0, 14, '', 0, 0, 0, 0);
INSERT INTO `s_shop` VALUES (81, '月卡', 1260000, 4200000, 9.99, 0, NULL, 1000, 0, 1, 10, 1, 0, 0, 'spinxstudio.pack.5', 'com.rummyfree.10', '', 0, 15, '{\"speedy\":3}', 0, 0, 0, 0);