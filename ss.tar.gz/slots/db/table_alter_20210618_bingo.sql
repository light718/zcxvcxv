
DROP TABLE IF EXISTS `s_bingo`;
CREATE TABLE `s_bingo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT 0 COMMENT '开启等级',
  `max_ball` int(11) DEFAULT 0 COMMENT '能拥有的最大球数量',
  `start_day` int(11) DEFAULT 0 COMMENT '开启时间(周几)',
  `end_day` int(11) DEFAULT 0 COMMENT '结束时间(周几)',
  `rewards` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '通关奖励, 格式: 类型:数量:备注|类型:数量:备注, eg: 1:200000|2:50|8:1:1',
  `coin_1` int(11) DEFAULT 0 COMMENT '排名1奖励金币',
  `coin_2` int(11) DEFAULT 0 COMMENT '排名2奖励金币',
  `coin_3` int(11) DEFAULT 0 COMMENT '排名3奖励金币',
  `coin_4` int(11) DEFAULT 0 COMMENT '排名4-10奖励金币',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='bingo游戏配置';

INSERT INTO `s_bingo` VALUES (1, 20, 21, 5, 7,'1:1500000|8:1:1|3:1',1500000,1000000,500000,100000);

DROP TABLE IF EXISTS `s_bingo_reward`;
CREATE TABLE `s_bingo_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) DEFAULT 0 COMMENT '大关卡序号',
  `order_id` int(11) DEFAULT 0 COMMENT '小关卡序号',
  `rewards` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '通关奖励, 格式: 类型:数量:备注|类型:数量:备注, eg: 1:200000|2:50|8:1:1',
  `score` int(11) DEFAULT 0 COMMENT '奖励的分数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='bingo游戏奖励配置';


INSERT INTO `s_bingo_reward` VALUES (1, 1, 1, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (2, 1, 2, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (3, 1, 3, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (4, 2, 1, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (5, 2, 2, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (6, 2, 3, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (7, 3, 1, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (8, 3, 2, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);
INSERT INTO `s_bingo_reward` VALUES (9, 3, 3, '1:9000000|2:50|8:1:1|8:1:2|3:2', 5);

DROP TABLE IF EXISTS `d_bingo_record`;
CREATE TABLE `d_bingo_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT 0 COMMENT '用户uid',
  `point` int(11) DEFAULT 0 COMMENT '已收集到的点数',
  `score` int(11) DEFAULT 0 COMMENT '已获得的分数',
  `section_id` int(11) DEFAULT 1 COMMENT '大关卡序号',
  `order_id` int(11) DEFAULT 1 COMMENT '小关卡序号',
  `start_time` int(11) DEFAULT 1 COMMENT '开始时间(方便区分redis中数据的新旧)',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='游戏记录获取表';
