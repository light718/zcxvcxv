
update s_sess set mincoin=10000 where gameid=250 and level=2;
update s_sess set mincoin=200000 where gameid=250 and level=3;
update s_sess set mincoin=2000000 where gameid=250 and level=4;
update s_sess set mincoin=20000000 where gameid=250 and level=5;
