-- 换皮游戏
---- 618 间谍 Double Agent
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    618, "间谍", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 427;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    618, "doubleagent", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 427;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 618, "间谍", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 427;

-- 619 日本招财猫 Lucky Cat
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    619, "日本招财猫", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 440;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    619, "luckycat", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 440;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 619, "日本招财猫", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 440;

-- 620 佐罗 Big Duel
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    620, "佐罗", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 477;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    620, "bigduel", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 477;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 620, "佐罗", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 477;

-- 621 狮子 The Lion
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    621, "狮子", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 419;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    621, "thelion", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 419;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 621, "狮子", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 419;

-- 622 熊猫 The Panda
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    622, "熊猫", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 439;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    622, "thepanda", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 439;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 622, "熊猫", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 439;


-- 623 独角兽 The Unicorn
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    623, "独角兽", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 441;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    623, "theunicorn", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 441;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 623, "独角兽", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 441;


-- 624 幸运财神  The God of Fortune
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    624, "幸运财神", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 432;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    624, "thegodoffortune", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 432;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 624, "幸运财神", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 432;


-- 625 星际穿越  Interstellar
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    625, "星际穿越", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 455;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    625, "interstellar", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 455;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 625, "星际穿越", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 455;


-- 626 小丑  Clown
INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    626, "小丑", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 463;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    626, "clown", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 463;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 626, "小丑", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 463;
