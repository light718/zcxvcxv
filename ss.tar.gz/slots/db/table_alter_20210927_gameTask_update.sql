-- 修改任务系统任务难度
update s_game_task_detail set value = 1500000 where roundid=1 and taskid=1 and detailid=2;
update s_game_task_detail set value = 4000000 where roundid=1 and taskid=2 and detailid=2;
update s_game_task_detail set value = 18 where roundid=1 and taskid=3 and detailid=1;
update s_game_task_detail set value = 70 where roundid=1 and taskid=5 and detailid=2;

-- 增加一列默认押注
alter table s_game_task add `betcoin` bigint(20) default 0 comment '进入任务的最低下注金额';
update s_game_task set betcoin = 50000 where roundid=1 and taskid=1;
update s_game_task set betcoin = 150000 where roundid=1 and taskid=2;
update s_game_task set betcoin = 200000 where roundid=1 and taskid=3;
update s_game_task set betcoin = 275000 where roundid=1 and taskid=4;
update s_game_task set betcoin = 350000 where roundid=1 and taskid=5;
update s_game_task set betcoin = 500000 where roundid=1 and taskid=6;

update s_game_task set betcoin = 500000 where roundid=2 and taskid=1;
update s_game_task set betcoin = 1500000 where roundid=2 and taskid=2;
update s_game_task set betcoin = 2000000 where roundid=2 and taskid=3;
update s_game_task set betcoin = 2750000 where roundid=2 and taskid=4;
update s_game_task set betcoin = 3500000 where roundid=2 and taskid=5;
update s_game_task set betcoin = 5000000 where roundid=2 and taskid=6;
