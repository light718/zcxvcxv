-- 阿拉伯语的游戏直接屏蔽
update s_game_type set state=0 where gameid=691;
update s_game_type set state=0 where gameid=692;
update s_game_type set state=0 where gameid=693;
update s_game_type set state=0 where gameid=694;
update s_game_type set state=0 where gameid=695;
update s_game_type set state=0 where gameid=696;

-- 已有游戏，无卡牌, 进行屏蔽处理
update s_game_type set state=0 where gameid=539;  -- 南岛寻宝
update s_game_type set state=0 where gameid=532;  -- 啤酒嘉年华
update s_game_type set state=0 where gameid=533;  -- 西伯利亚之王
update s_game_type set state=0 where gameid=535;  -- 奥兹传奇
update s_game_type set state=0 where gameid=521;  -- 富贵树
update s_game_type set state=0 where gameid=530;  -- 双倍神力
update s_game_type set state=0 where gameid=526;  -- 金猪报喜
update s_game_type set state=0 where gameid=520;  -- 真爱永恒
update s_game_type set state=0 where gameid=527;  -- 双倍矿工
update s_game_type set state=0 where gameid=529;  -- 航海宝藏
update s_game_type set state=0 where gameid=531;  -- 花木兰

-- 开放已有卡牌的游戏
update s_game_type set state=1 where gameid=649;  -- 奥德修斯
update s_game_type set state=1 where gameid=682;  -- 释迦摩尼
update s_game_type set state=1 where gameid=677;  -- 日本歌姬
update s_game_type set state=1 where gameid=670;  -- 半人马
update s_game_type set state=1 where gameid=675;  -- 嫦娥
update s_game_type set state=1 where gameid=683;  -- 伽利略
update s_game_type set state=1 where gameid=672;  -- 篮球之王
update s_game_type set state=1 where gameid=676;  -- 豌豆公主
update s_game_type set state=1 where gameid=673;  -- 赫拉
update s_game_type set state=1 where gameid=655;  -- 巨人族约尔孟甘德
update s_game_type set state=1 where gameid=669;  -- 成吉思汗
update s_game_type set state=1 where gameid=684;  -- 巴德尔
update s_game_type set state=1 where gameid=686;  -- 赫斯提亚

-- 165上面需要跑这个脚本, 162上面不需要
update s_game set level=400 where id=649;
update s_game set level=405 where id=682;
update s_game set level=410 where id=677;
update s_game set level=415 where id=670;
update s_game set level=420 where id=675;
update s_game set level=425 where id=683;
update s_game set level=430 where id=672;
update s_game set level=435 where id=676;
update s_game set level=440 where id=673;
update s_game set level=445 where id=655;
update s_game set level=450 where id=669;
update s_game set level=455 where id=684;
update s_game set level=460 where id=686;

-- 165上面需要跑这个脚本, 162上面不需要
update s_game_type set state = 2 where gameid = 689;
update s_game_type set state = 2 where gameid = 680;
update s_game_type set state = 2 where gameid = 651;
update s_game_type set state = 2 where gameid = 685;
update s_game_type set state = 2 where gameid = 690;
update s_game_type set state = 2 where gameid = 679;
update s_game_type set state = 2 where gameid = 678;
update s_game_type set state = 2 where gameid = 647;
update s_game_type set state = 2 where gameid = 681;
