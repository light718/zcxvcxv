-- 时延统计表
CREATE TABLE `d_delay_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '序列id',
  `uid` int(11) unsigned NOT NULL COMMENT '玩家uid',
  `type` varchar(32) DEFAULT '' COMMENT '所属操作',
  `info` varchar(1024) DEFAULT '' COMMENT '附属信息',
  `ts` int(11) DEFAULT NULL COMMENT '时间戳',
  `delay1` int(11) DEFAULT NULL COMMENT '客户端到服务器接收的耗时时长(ms)',
  `delay2` int(11) DEFAULT NULL COMMENT '服务器各种业务操作的耗时时长(ms)',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='rummySlots消息时延统计';
