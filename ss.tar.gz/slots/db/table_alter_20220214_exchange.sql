DROP TABLE IF EXISTS `d_exchange_code`;
CREATE TABLE `d_exchange_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchid` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '批次',
  `code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` tinyint(1) DEFAULT '1' COMMENT '1可用 2已用 3作废',
  `create_time` int(11) DEFAULT '0',
  `type` tinyint(2) DEFAULT '1' COMMENT '1：金币 25：钻石',
  `total` int(11) DEFAULT '0' COMMENT '兑换数量',
  `consume_time` int(11) DEFAULT '0' COMMENT '使用时间',
  `uid` bigint(20) DEFAULT '0' COMMENT '使用人',
  `update_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='兑换码';