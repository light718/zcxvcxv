DELETE FROM `s_reward_online` WHERE `itemid` = 2;
