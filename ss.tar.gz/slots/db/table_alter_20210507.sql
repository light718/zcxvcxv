-- 强大的亚特兰蒂斯 Mighty Atlantis
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (504, "强大的亚特兰蒂斯", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(504, "mightyatlantis", 0, 0.1, 0.1, '[15,25,400,5000]', '[1,1,1,1]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 504, "强大的亚特兰蒂斯", 1, 100);

-- 野生大猩猩 Wild Gorilla
replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (505, "野生大猩猩", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv) values(505, "wildgorilla", 0, 0.1, 0.1, '[10,20,100,5000]', '[1,1,1,1]');
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 505, "野生大猩猩", 1, 100);