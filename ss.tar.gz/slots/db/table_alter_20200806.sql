ALTER TABLE `d_user_login_log` ADD COLUMN `logout_time`  int(11) default 0 AFTER `extr`;
ALTER TABLE `d_user_login_log` DROP INDEX `create_time` , ADD INDEX `create_time` (`create_time`, `uid`) USING BTREE ;
ALTER TABLE `s_shop_order` ADD COLUMN `user_level`  int(11) NULL DEFAULT 0 COMMENT ' 用户等级' AFTER `stype`;
