INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    674, "麒麟", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 516;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    674, "mythicalkylin", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 516;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 674, "麒麟", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 516;

INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    687, "赫菲斯托斯", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 528
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    687, "hephaestus", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 528
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 687, "赫菲斯托斯", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 528
LIMIT 1;

INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    688, "浪漫公主", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 503
LIMIT 1;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    688, "romanticprincess", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 503
LIMIT 1;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 688, "浪漫公主", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 503
LIMIT 1;

INSERT INTO `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
SELECT 
    671, "外星怪物", basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat
FROM 
    `s_sess`
WHERE 
    gameid = 515;

INSERT INTO `s_game` (id, title,allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv)
SELECT
    671, "alienmonster", allincontrol, ratefree, ratesub, jackpot, jp_unlock_lv
FROM
    `s_game`
WHERE
    id = 515;

INSERT INTO `s_game_type` (gametype, gameid, title, state, hot)
SELECT
    gametype, 671, "外星怪物", state, hot
FROM
    `s_game_type`
WHERE
    gameid = 515;

update s_game set control=null where id>=419;

update s_game set gametag=0 where id in (select gameid from s_game_type where gametype=2);
update s_game_type set `taghot`=0 where  taghot>0;
update s_game_type set `hot`=500 where gametype=2 and gameid>=419;
update s_game set `level`=0 where id >= 419;

--hot
update s_game set gametag = 1, `level`=0 where id in (611,659,636);

--new
update s_game set gametag = 2, `level`=0 where id in (631,657,614);


-- hot
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=611&type=2&ord=1'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=659&type=2&ord=3'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=636&type=2&ord=5'

curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=631&type=2&ord=2'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=657&type=2&ord=4'
curl 'http://127.0.0.1:7612/?mod=setgametagord&gameids=614&type=2&ord=6'
-- new


update s_game set `level`=5  where id = 601;
update s_game set `level`=10 where id = 605;
update s_game set `level`=15 where id = 650;
update s_game set `level`=20 where id = 668;
update s_game set `level`=25 where id = 602;
update s_game set `level`=30 where id = 613;
update s_game set `level`=35 where id = 648;
update s_game set `level`=40 where id = 616;
update s_game set `level`=45 where id = 610;
update s_game set `level`=50 where id = 652;
update s_game set `level`=55 where id = 521;

update s_game set `level`=10  where id = 621;
update s_game set `level`=60  where id = 623;
update s_game set `level`=65  where id = 619;
update s_game set `level`=70  where id = 622;
update s_game set `level`=75  where id = 635;
update s_game set `level`=80  where id = 634;
update s_game set `level`=85  where id = 633;
update s_game set `level`=90  where id = 608;
update s_game set `level`=95  where id = 660;
update s_game set `level`=100  where id = 604;
update s_game set `level`=105 where id = 656;
update s_game set `level`=110 where id = 632;
update s_game set `level`=115 where id = 513;
update s_game set `level`=120 where id = 516;
update s_game set `level`=125 where id = 517;
update s_game set `level`=130 where id = 524;
update s_game set `level`=135 where id = 518;
update s_game set `level`=140 where id = 514;
update s_game set `level`=145 where id = 526;


update s_game set `level`=15  where id = 603;
update s_game set `level`=150 where id = 646;
update s_game set `level`=155 where id = 658;
update s_game set `level`=160 where id = 620;
update s_game set `level`=165 where id = 637;
update s_game set `level`=170 where id = 661;
update s_game set `level`=175 where id = 638;
update s_game set `level`=180 where id = 612;
update s_game set `level`=185 where id = 630;
update s_game set `level`=190 where id = 496;
update s_game set `level`=195 where id = 525;

update s_game set `level`=20  where id = 640;
update s_game set `level`=200 where id = 653;
update s_game set `level`=205 where id = 519;
update s_game set `level`=210 where id = 666;
update s_game set `level`=215 where id = 667;
update s_game set `level`=220 where id = 641;
update s_game set `level`=225 where id = 639;
update s_game set `level`=230 where id = 627;
update s_game set `level`=235 where id = 624;
update s_game set `level`=240 where id = 665;
update s_game set `level`=245 where id = 663;
update s_game set `level`=250 where id = 628;
update s_game set `level`=255 where id = 617;
update s_game set `level`=260 where id = 626;
update s_game set `level`=265 where id = 523;
update s_game set `level`=270 where id = 528;
update s_game set `level`=275 where id = 520;

update s_game set `level`=25  where id = 609;
update s_game set `level`=280 where id = 615;
update s_game set `level`=285 where id = 645;
update s_game set `level`=290 where id = 644;
update s_game set `level`=295 where id = 643;
update s_game set `level`=300 where id = 642;
update s_game set `level`=305 where id = 664;
update s_game set `level`=310 where id = 654;
update s_game set `level`=315 where id = 629;
update s_game set `level`=320 where id = 625;
update s_game set `level`=325 where id = 662;
update s_game set `level`=330 where id = 618;
update s_game set `level`=335 where id = 515;
update s_game set `level`=340 where id = 527;
update s_game set `level`=345 where id = 529;
update s_game set `level`=350 where id = 531;
update s_game set `level`=355 where id = 674;
update s_game set `level`=360 where id = 687;
update s_game set `level`=365 where id = 688;
update s_game set `level`=370 where id = 671;

update s_game_type set `hot`=7  where gameid = 601;
update s_game_type set `hot`=10 where gameid = 605;
update s_game_type set `hot`=15 where gameid = 650;
update s_game_type set `hot`=20 where gameid = 668;
update s_game_type set `hot`=25 where gameid = 602;
update s_game_type set `hot`=30 where gameid = 613;
update s_game_type set `hot`=35 where gameid = 648;
update s_game_type set `hot`=40 where gameid = 616;
update s_game_type set `hot`=45 where gameid = 610;
update s_game_type set `hot`=50 where gameid = 652;
update s_game_type set `hot`=55 where gameid = 521;

update s_game_type set `hot`=59  where gameid = 621;
update s_game_type set `hot`=60  where gameid = 623;
update s_game_type set `hot`=65  where gameid = 619;
update s_game_type set `hot`=70  where gameid = 622;
update s_game_type set `hot`=71  where gameid = 635;
update s_game_type set `hot`=73  where gameid = 634;
update s_game_type set `hot`=75  where gameid = 633;
update s_game_type set `hot`=80  where gameid = 608;
update s_game_type set `hot`=85  where gameid = 660;
update s_game_type set `hot`=95  where gameid = 604;
update s_game_type set `hot`=100 where gameid = 656;
update s_game_type set `hot`=105 where gameid = 632;
update s_game_type set `hot`=110 where gameid = 513;
update s_game_type set `hot`=115 where gameid = 516;
update s_game_type set `hot`=120 where gameid = 517;
update s_game_type set `hot`=125 where gameid = 524;
update s_game_type set `hot`=130 where gameid = 518;
update s_game_type set `hot`=135 where gameid = 514;
update s_game_type set `hot`=140 where gameid = 526;


update s_game_type set `hot`=142  where gameid = 603;
update s_game_type set `hot`=145 where gameid = 646;
update s_game_type set `hot`=150 where gameid = 658;
update s_game_type set `hot`=155 where gameid = 620;
update s_game_type set `hot`=160 where gameid = 637;
update s_game_type set `hot`=165 where gameid = 661;
update s_game_type set `hot`=170 where gameid = 638;
update s_game_type set `hot`=175 where gameid = 612;
update s_game_type set `hot`=180 where gameid = 630;
update s_game_type set `hot`=185 where gameid = 496;
update s_game_type set `hot`=190 where gameid = 525;

update s_game_type set `hot`=194  where gameid = 640;
update s_game_type set `hot`=195 where gameid = 653;
update s_game_type set `hot`=200 where gameid = 519;
update s_game_type set `hot`=205 where gameid = 666;
update s_game_type set `hot`=210 where gameid = 667;
update s_game_type set `hot`=215 where gameid = 641;
update s_game_type set `hot`=220 where gameid = 639;
update s_game_type set `hot`=225 where gameid = 627;
update s_game_type set `hot`=230 where gameid = 624;
update s_game_type set `hot`=235 where gameid = 665;
update s_game_type set `hot`=240 where gameid = 663;
update s_game_type set `hot`=245 where gameid = 628;
update s_game_type set `hot`=250 where gameid = 617;
update s_game_type set `hot`=255 where gameid = 626;
update s_game_type set `hot`=260 where gameid = 523;
update s_game_type set `hot`=265 where gameid = 528;
update s_game_type set `hot`=270 where gameid = 520;

update s_game_type set `hot`=274  where gameid = 609;
update s_game_type set `hot`=275 where gameid = 615;
update s_game_type set `hot`=280 where gameid = 645;
update s_game_type set `hot`=285 where gameid = 644;
update s_game_type set `hot`=290 where gameid = 643;
update s_game_type set `hot`=295 where gameid = 642;
update s_game_type set `hot`=300 where gameid = 664;
update s_game_type set `hot`=305 where gameid = 654;
update s_game_type set `hot`=310 where gameid = 629;
update s_game_type set `hot`=315 where gameid = 625;
update s_game_type set `hot`=320 where gameid = 662;
update s_game_type set `hot`=330 where gameid = 618;
update s_game_type set `hot`=335 where gameid = 515;
update s_game_type set `hot`=340 where gameid = 527;
update s_game_type set `hot`=345 where gameid = 529;
update s_game_type set `hot`=350 where gameid = 531;
update s_game_type set `hot`=355 where gameid = 674;
update s_game_type set `hot`=360 where gameid = 687;
update s_game_type set `hot`=365 where gameid = 688;
update s_game_type set `hot`=370 where gameid = 671;