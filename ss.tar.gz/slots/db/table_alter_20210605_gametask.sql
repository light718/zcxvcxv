CREATE TABLE `d_game_task_record` (
	`id`  int(11) NOT NULL AUTO_INCREMENT ,
	`uid`  int(11) NULL ,
	`roundid`  int(11) NULL ,
	`taskid`  int(11) NULL ,
	`gameid`  int(11) NULL ,
	`level`  int(11) NULL ,
	`bet`  bigint(20) NULL ,
	`create_time`  int(11) NULL ,
	PRIMARY KEY (`id`),
	INDEX `idx_uid` (`uid`) 
) COMMENT='任务完成记录表';

ALTER TABLE `d_game_task` ADD COLUMN `gameover`  tinyint(1) DEFAULT 0 COMMENT '0未结束 1已结束' AFTER `data`;

