-- 447  珍宝丛林  treasurejungle  minor, major, grand  4个缺一不可，可以不用
UPDATE `s_game` SET `jackpot` = '[5,10,200,5000]' WHERE id = 447;