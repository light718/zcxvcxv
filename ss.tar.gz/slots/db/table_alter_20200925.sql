ALTER TABLE `s_shop` 
ADD COLUMN `productid_huawei` varchar(100) NULL DEFAULT '' COMMENT '华为商品id' AFTER `productid_gp`;

update s_shop set productid_huawei='a1' where amount=0.99;
update s_shop set productid_huawei='a2' where amount=1.99;
update s_shop set productid_huawei='a3' where amount=2.99;
update s_shop set productid_huawei='a4' where amount=3.99;
update s_shop set productid_huawei='a5' where amount=4.99;
update s_shop set productid_huawei='a6' where amount=5.99;
update s_shop set productid_huawei='a7' where amount=6.99;
update s_shop set productid_huawei='a8' where amount=7.99;
update s_shop set productid_huawei='a9' where amount=8.99;
update s_shop set productid_huawei='a10' where amount=9.99;
update s_shop set productid_huawei='a11' where amount=12.99;
update s_shop set productid_huawei='a12' where amount=19.99;
update s_shop set productid_huawei='a13' where amount=49.99;

ALTER TABLE `s_shop_order` ADD COLUMN `appid` int(11) NULL DEFAULT 0 COMMENT '渠道包id' AFTER `user_coin`;

ALTER TABLE `d_user` ADD COLUMN `appid` int(11) NULL DEFAULT 0 COMMENT '渠道包id';

ALTER TABLE `d_user` ADD COLUMN `justreg` tinyint(1) NULL DEFAULT 1 COMMENT '是否只注册';

update s_config set v='1299000000' where k='stampalbumcoin';

ALTER TABLE `s_shop` ADD COLUMN `oamount` decimal(10) NULL DEFAULT 0 COMMENT '原始金额' AFTER `count`;