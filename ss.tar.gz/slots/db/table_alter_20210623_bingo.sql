
DROP TABLE IF EXISTS `s_bingo`;
CREATE TABLE `s_bingo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) DEFAULT 0 COMMENT '开启等级',
  `max_ball` int(11) DEFAULT 0 COMMENT '能拥有的最大球数量',
  `start_day` int(11) DEFAULT 0 COMMENT '开启时间(周几)',
  `end_day` int(11) DEFAULT 0 COMMENT '结束时间(周几)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='bingo游戏配置';

INSERT INTO `s_bingo` VALUES (1, 20, 21, 5, 7);

DROP TABLE IF EXISTS `s_bingo_reward`;
CREATE TABLE `s_bingo_reward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT 0 COMMENT '类型, 1=小关卡奖励, 2=通关奖励, 3=排名奖励',
  `section_id` int(11) DEFAULT 0 COMMENT '大关卡序号',
  `order_id` int(11) DEFAULT 0 COMMENT '小关卡序号',
  `rewards` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '奖励, 格式: 类型:数量:备注|类型:数量:备注, eg: 1:200000|2:50|8:1:1',
  `score` int(11) DEFAULT 0 COMMENT '奖励的分数',
  `round_id` int(11) DEFAULT 1 COMMENT '表明哪一轮',
  `l_rank` int(11) DEFAULT 0 COMMENT '当类型是排名奖励的时候，有这个字段，表明排名左区间',
  `r_rank` int(11) DEFAULT 0 COMMENT '当类型是排名奖励的时候，有这个字段，表明排名右区间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='bingo游戏奖励配置';

-- 插入小关卡奖励配置
INSERT INTO `s_bingo_reward` VALUES (1, 1, 1, 1, '1:4900000|2:10', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (2, 1, 1, 2, '1:4760000|2:10', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (3, 1, 1, 3, '1:6860000|2:10', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (4, 1, 2, 1, '1:6720000|3:1', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (5, 1, 2, 2, '1:7000000|3:1', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (6, 1, 2, 3, '1:8820000|3:1', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (7, 1, 3, 1, '1:10500000|8:1:2', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (8, 1, 3, 2, '1:11760000|8:1:2', 1, 0, 0, 0);
INSERT INTO `s_bingo_reward` VALUES (9, 1, 3, 3, '1:12600000|8:1:2', 1, 0, 0, 0);

-- 插入轮次通关奖励配置
INSERT INTO `s_bingo_reward` VALUES (10, 2, 0, 0, '1:15250000|2:10|8:1:4', 0, 1, 0, 0);

-- 插入排名奖励
INSERT INTO `s_bingo_reward` VALUES (13, 3, 0, 0, '1:10000000', 0, 0, 1, 1);
INSERT INTO `s_bingo_reward` VALUES (14, 3, 0, 0, '1:4000000', 0, 0, 2, 2);
INSERT INTO `s_bingo_reward` VALUES (15, 3, 0, 0, '1:2000000', 0, 0, 3, 3);
INSERT INTO `s_bingo_reward` VALUES (16, 3, 0, 0, '1:580000', 0, 0, 4, 10);

DROP TABLE IF EXISTS `d_bingo_record`;
CREATE TABLE `d_bingo_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT 0 COMMENT '用户uid',
  `point` int(11) DEFAULT 0 COMMENT '已收集到的点数',
  `score` int(11) DEFAULT 0 COMMENT '已获得的分数',
  `section_id` int(11) DEFAULT 1 COMMENT '大关卡序号',
  `order_id` int(11) DEFAULT 1 COMMENT '小关卡序号',
  `start_time` int(11) DEFAULT 1 COMMENT '开始时间(方便区分redis中数据的新旧)',
  `round_id` int(11) DEFAULT 1 COMMENT '当前轮次',
  `buff` int(11) DEFAULT 0  COMMENT '是否购买礼包buff',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='游戏记录获取表';


-- 增加bingo相关商品
INSERT INTO `s_shop` VALUES (98, 'bingo增强', null, 1800000, '4.99', '0', null, '0', '0', '1', '10', '1', '0', '0', 'spinxstudio.pack.4', 'com.rummyfree.5', '', '0', 22, '', '0', '0', '0', '0');
INSERT INTO `s_shop` VALUES (99, 'bingo礼包', null, 600000, '1.99', '0', null, '0', '0', '1', '10', '1', '0', '0',  'spinxstudio.pack.2', 'com.rummyfree.2', '', '0', 23, '', '0', '0', '0', '0');
