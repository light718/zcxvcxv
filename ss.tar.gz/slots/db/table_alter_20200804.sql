
update s_config set v=50 where k='hourrank';

ALTER TABLE `s_shop` MODIFY COLUMN `stype`  tinyint(1) NULL DEFAULT NULL COMMENT '类型1商城 2限时优惠 3转盘 4激励礼包 5等级礼包 6签到 7首充礼包 8onetimeonly 9排行榜时榜' AFTER `appid`;


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (419, "老虎", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title, allincontrol) values(419, "regaltiger", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 419, "老虎", 1, 100);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (420, "火神", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title, allincontrol) values(420, "godoffire", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 420, "火神", 1, 100);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (421, "奇迹时刻", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title, allincontrol) values(421, "momentofwonder", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 421, "奇迹时刻", 1, 100);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (422, "主题公园爆炸", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol) values(422, "themeparkblast", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 422, "主题公园爆炸", 1, 100);



replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (423, "墨西哥帅哥", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol) values(423, "jadapenedelight", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 423, "墨西哥帅哥", 1, 100);

update s_game_type set state=0 where gameid in (419,420,421,422,423);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (424, "美人鱼", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol) values(424, "queenofsea", 0);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 424, "美人鱼", 1, 100);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (425, "太阳女神", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(425, "sungoddess", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 425, "太阳女神", 1, 100);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )
values (426, "杰克猫", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 1);
replace into `s_game` (id, title,allincontrol, ratefree, ratesub) values(426, "pussmusketeer", 0, 0.1, 0.1);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (2, 426, "杰克猫", 1, 100);