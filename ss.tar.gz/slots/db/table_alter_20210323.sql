-- 更改埃及崛起的jackpot解锁等级
update s_game set jp_unlock_lv='[1,3,6,9,12]' where id=494;