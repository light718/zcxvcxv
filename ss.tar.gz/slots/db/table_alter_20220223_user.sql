ALTER TABLE `d_user`
add COLUMN `charm`  bigint(20) NULL DEFAULT 0 COMMENT '魅力值' AFTER `points`;