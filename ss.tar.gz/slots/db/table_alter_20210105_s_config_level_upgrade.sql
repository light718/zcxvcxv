update s_config_level_upgrade set ratefree = 5 where level = 2;
update s_config_level_upgrade set ratefree = 4 where level = 3;
update s_config_level_upgrade set ratefree = 3 where level = 4;
update s_config_level_upgrade set ratefree = 2 where level >= 5 and level <= 14;
update s_config_level_upgrade set ratefree = 1.5 where level >= 15 and level <= 20;



