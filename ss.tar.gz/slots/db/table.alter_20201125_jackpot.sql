
--修改快速白金支付解锁等级
UPDATE `s_game` SET `jp_unlock_lv` = '[4,6,9,12,16,18]' WHERE id = 470;

-- jackpot
UPDATE `s_game` SET `jackpot` = '[10,50,100,650,2000,3000]' WHERE id = 470;
