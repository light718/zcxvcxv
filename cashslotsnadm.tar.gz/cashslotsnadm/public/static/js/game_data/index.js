$(function () {
    getOnlineData();
})

function getOnlineData() {
    var datas = {};
    sendAjax(datas,function (res) {
        if (res.code == 0){
            $("#onlineSpan").html(res.data.num);
        }else{
            layer.msg(res.msg)
        }
    },'post',"getOnlineData",function (error) {
        console.log(error)
    })
}

function renderGameData(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]
        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'uid', title: '用户编号', width: '20%'},
            {field: 'playername', title: '用户名', width: '20%'}
            , {field: 'coin', title: '金币数', width: '20%'}
            , {field: 'create_time', title: '最后登录时间', width: '20%'}
            , {field: 'id', title: '操作', width: '20%', toolbar: '#toolbarDemo'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dauRender(res);
        }
    });
}