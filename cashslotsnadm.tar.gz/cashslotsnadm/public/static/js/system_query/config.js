function renderConfigList(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'id', title: 'ID', width: 80,}
            , {field: 'k', title: '编号', width: 150}
            , {field: 'v', title: '值', width: 300}
            , {field: 'memo', title: '标题', width: 200}
            , {field: 'id', title: '操作', width: 200, toolbar: '#toolBar'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}