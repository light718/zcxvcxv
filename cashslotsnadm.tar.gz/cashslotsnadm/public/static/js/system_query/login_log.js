$(function () {

})

function renderDetailList(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            // {field: 'id', title: '玩家ID', width: '8%', sort: true}
            // , {field: 'pid', title: '玩家账号', width:  '15%'}
             {field: 'before', title: '开始金额', width: '15%'}
            , {field: 'coin', title: '变动金额', width: '20%'}
            , {field: 'after', title: '结束金额', width: '15%'}
            , {field: 'game_title', title: '游戏名称', width: '20%'}
            , {field: 'create_time', title: '日期时间', width: '15%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

function renderLog(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            // {field: 'account_id', title: '玩家ID ', width: 150, sort: true, fixed: 'left'}
            {field: 'account_pid', title: '账号', width: '30%'}
            , {field: 'ip', title: 'IP', width: '40%'}
            , {field: 'create_time', title: '最后登录时间', width: '30%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}