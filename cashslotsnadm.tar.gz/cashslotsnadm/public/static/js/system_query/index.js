$(function () {
    
})

function renderPlayer(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'uid', title: '玩家ID', width: '6%'}
            // , {field: 'playername', title: '账号', width: '10%'}
            , {field: 'playername', title: '昵称', width: '10%'}
            , {field: 'coin', title: '分数', width: '8%'}
            , {field: 'onlinestate_text', title: '在线状态', width: '8%'}
            , {field: 'status_text', title: '账号状态', width: '8%'}
            , {field: 'create_time', title: '添加时间', width: '14%'}
            , {field: 'login_time', title: '最后登录时间', width: '15%'}
            , {field: 'id', title: '操作', width: 300, toolbar: '#toolBar'}

        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

function renderTaxLog(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'id', title: 'ID', width: 150, sort: true, fixed: 'left'}
            , {field: 'balance', title: '分数', width: 100}
            , {field: 'create_time', title: '清空时间', width: 100}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}
function renderCheck(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'id', title: 'ID', width: 150, sort: true, fixed: 'left'}
            , {field: 'datetime', title: '操作时间', width: 200}
            , {field: 'desc', title: '详情', width: 400}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

/***
 * 人数
 * @param obj
 */
function renderPlayerCount(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'day', title: '日期', width: 150}
            , {field: 'dnu', title: 'DNU', width: 100}
            , {field: 'dau', title: 'DAU', width: 100}
            , {field: 'arpu', title: 'ARPU', width: 100}
            , {field: 'arppu', title: 'ARPPU', width: 100}
            , {field: 'ordernum', title: '充值笔数', width: 100}
            , {field: 'payrate', title: '付费率', width: 100}
            , {field: 'paynum', title: '付费人数', width: 100}
            , {field: 'payamount', title: '付费金额', width: 100}
            , {field: 'pay2num', title: '多次付费人数', width: 100}
            , {field: 'pay2amount', title: '多次付费金额', width: 100}
            , {field: 'payfirstamount', title: '第1次付费金额', width: 100}
            , {field: 'payfirstnum', title: '第1次付费人数', width: 100}
            , {field: 'stay1', title: '次留', width: 100}
            , {field: 'stay3', title: '3留', width: 100}
            , {field: 'stay7', title: '7留', width: 100}
            , {field: 'stay14', title: '14留', width: 100}
            , {field: 'stay30', title: '30留', width: 100}
            , {field: 'ltv1', title: '当日ltv', width: 100}
            , {field: 'ltv3', title: '3日ltv', width: 100}
            , {field: 'ltv7', title: '7日ltv', width: 100}
            , {field: 'ltv14', title: '14日ltv', width: 100}
            , {field: 'ltv30', title: '30日ltv', width: 100}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}


function renderGameToday(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: '10%', sort: true, fixed: 'left'}
            , {field: 'game_id', title: '游戏编号', width: '8%'}
            , {field: 'game_title', title: '游戏名称', width: '13%'}
            , {field: 'alltimes', title: '总次数', width: '13%'}
            , {field: 'allusers', title: '总人数', width: '13%'}
            , {field: 'allbet', title: '总下注', width: '13%'}
            , {field: 'allwin', title: '总赢钱', width: '15%'}
            , {field: 'rate', title: '回报率', width: '15%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

function renderActive(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: '10%', sort: true, fixed: 'left'}
            , {field: 'game_id', title: '游戏编号', width: '8%'}
            , {field: 'game_title', title: '游戏名称', width: '15%'}
            , {field: 'alltimes', title: '总次数', width: '8%'}
            , {field: 'allusers', title: '总人数', width: '15%'}
            , {field: 'allbet', title: '总下注', width: '15%'}
            , {field: 'allwin', title: '总赢钱', width: '20%'}
            , {field: 'rate', title: '回报率', width: '8%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

/**
 * 活跃用户领取奖励统计
 * @param obj
 */
function renderRewardActive(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: 150, sort: true, fixed: 'left'}
            , {field: 'act', title: '游戏编号', width: 150}
            , {field: 'allusers', title: '总人数', width: 150}
            , {field: 'allcoin', title: '总金币', width: 200}
            , {field: 'allcost', title: '金币价值', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

/***
 * 新用户在线时长
 * @param obj
 */
function renderUserOnline(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'day', title: '日期', width: 150, sort: true, fixed: 'left'}
            , {field: 'stype', title: '在线时长类型', width: 150}
            , {field: 'allusers', title: '总人数', width: 150}
            , {field: 'avgcoin', title: '金币平均值', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}

/***
 * 用户在线时长统计
 * @param obj
 * @returns {boolean}
 */
function renderOnline(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'stype', title: '在线时长类型', width: '50%', sort: true, fixed: 'left'}
            , {field: 'allusers', title: '总人数', width: '50%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}

/***
 * 用户等级统计
 * @param obj
 * @returns {boolean}
 */
function renderUserLevel(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'level_type', title: '等级区间', width: '20%', sort: true, fixed: 'left'}
            , {field: 'allusers', title: '人数', width: '20%'}
            , {field: 'avgcoinval', title: '金币价值', width: '20%'}
            , {field: 'allrupt', title: '总破产次数', width: '20%'}
            , {field: 'chargeamount', title: '充值总额', width: '20%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}

function renderUserOrder(obj){
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'createdate', title: '下单时间', width: 150, sort: true, fixed: 'left'}
            , {field: 'num', title: '总人数', width: 200}
            , {field: 'price', title: '总金额', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}

/***
 *
 * @param obj
 * @returns {boolean}
 */
function renderOrderList(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'uid', title: 'UID', width: 100, sort: true}
            , {field: 'user_level', title: '用户等级', width: 150}
            , {field: 'user_coin', title: '用户金币', width: 150}
            , {field: 'shopid', title: '订单商品id', width: 150}
            , {field: 'title', title: '商品名称', width: 150}
            , {field: 'amount', title: '商品价格', width: 150}
            , {field: 'create_time', title: '下单时间', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}

/***
 *
 * @param obj
 * @returns {boolean}
 */
function renderOrderRenew(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: '10%', sort: true}
            , {field: 'user1', title: '当日充值人数', width: '8%'}
            , {field: 'amount1', title: '当日充值金额', width: '8%'}
            , {field: 'user2', title: '次日充值人数', width: '8%'}
            , {field: 'amount2', title: '次日充值金额', width: '8%'}
            , {field: 'user3', title: '3日充值人数', width: '8%'}
            , {field: 'amount3', title: '3日充值金额', width: '8%'}
            , {field: 'user4', title: '4日充值人数', width: '8%'}
            , {field: 'amount4', title: '4日充值金额', width: '8%'}
            , {field: 'user5', title: '5日充值人数', width: '8%'}
            , {field: 'amount5', title: '5日充值金额', width: '8%'}
            , {field: 'user6', title: '6日充值人数', width: '8%'}
            , {field: 'amount6', title: '6日充值金额', width: '8%'}
            , {field: 'user7', title: '7日充值人数', width: '8%'}
            , {field: 'amount7', title: '7日充值金额', width: '8%'}
            , {field: 'user8', title: '8日充值人数', width: '8%'}
            , {field: 'amount8', title: '8日充值金额', width: '8%'}
            , {field: 'user9', title: '9日充值人数', width: '8%'}
            , {field: 'amount9', title: '9日充值金额', width: '8%'}
            , {field: 'user10', title: '10日充值人数', width: '8%'}
            , {field: 'amount10', title: '10日充值金额', width: '8%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}

function renderItemSort(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'shopid', title: '商品ID', width: 150, sort: true}
            , {field: 'title', title: '商品名', width: 200}
            , {field: 'total', title: '订单数', width: 200}
            , {field: 'price', title: '总金额', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
    return false;
}