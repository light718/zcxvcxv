
function renderCardTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        ,url: obj.url //数据接口toolbar
        ,cols: [[ //表头
            {field: 'campid', title: '阵营ID', width:'33%', sort: true}
            ,{field: 'name', title: ' 阵营名称', width:'33%'}
            ,{field: 'card_count', title: '卡牌数量', width:'33%',sort: true}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            console.log(res)
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            
        }
    });
}

function renderCardStarTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        ,url: obj.url //数据接口toolbar
        ,cols: [[ //表头
            {field: 'cardid', title: '卡牌ID', width:'25%'}
            ,{field: 'card_name', title: ' 卡牌名称', width:'25%' }
            ,{field: 'star', title: '卡牌星级', width:'25%'}
            ,{field: 'need_chips', title: '升星所需要的碎片', width:'25%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            
        }
    });
}

function renderCardLevelTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        ,url: obj.url //数据接口toolbar
        ,cols: [[ //表头
            {field: 'cardid', title: '卡牌ID', width:'20%'}
            ,{field: 'gameid', title: ' 子游戏ID', width:'20%'}
            ,{field: 'game_name', title: '子游戏名称', width:'20%'}
            ,{field: 'level', title: '卡牌等级', width:'20%'}
            ,{field: 'level', title: '升级所需经验', width:'20%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
        }
    });
}

function renderHeroCardTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        ,url: obj.url //数据接口toolbar
        ,cols: [[ //表头
            {field: 'cardid', title: '卡牌ID', width:'10%'}
            ,{field: 'name', title: ' 卡牌名称', width:'15%',minWidth:"15%" ,templet: function(row){
                    var row_data  = '<span>'+ row.name +'</span> &nbsp;' ;
                    row_data += "<img src='/static/hallchips/"+row.cardid+".png' style='width:60px;height: 100%;'/>"
                    return row_data;
                },style:"line-height:150px;height:150px"}
            ,{field: 'camp_name', title: '所属阵营', width:'10%'}
            ,{field: 'gameid', title: '子游戏ID', width:'10%'}
            ,{field: 'unlock_chips', title: '解锁所需碎片', width:'10%'}
            ,{field: 'init_star', title: '初始星级', width:'8%'}
            ,{field: 'max_star', title: '最大星级', width:'8%'}
            ,{field: 'unlock_awards', title: '解锁奖励金币', width:'15%'}
            ,{field: 'id', title: '操作', width: '14%', toolbar: '#toolbar'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
        }
    });
}

function renderUserHeroCardTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        ,url: obj.url //数据接口toolbar
        ,cols: [[ //表头
            {field: 'uid', title: '玩家ID', width:'10%'}
            ,{field: 'cardid', title: '卡牌ID', width:'15%'}
            ,{field: 'card_name', title: '卡牌名称', width:'15%'}
            ,{field: 'chips', title: '碎片数量', width:'10%'}
            ,{field: 'star', title: '卡牌星级', width:'15%'}
            ,{field: 'lv', title: '卡牌等级', width:'15%'}
            ,{field: 'exp', title: '当前经验', width:'15%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
        }
    });
}