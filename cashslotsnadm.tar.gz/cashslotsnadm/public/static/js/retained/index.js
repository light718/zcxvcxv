function renderLoss(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'create_times', title: '日期', width: '25%', sort: true, fixed: 'left'}
            , {field: 'dau', title: '总用户', width: '15%'}
            , {field: 'stay1', title: '次留', width: '15%', templet: (row) => row.stay1*100 + '%'}
            , {field: 'stay3', title: '3留', width: '15%', templet: (row) => row.stay3*100 + '%'}
            , {field: 'stay7', title: '7留', width: '15%', templet: (row) => row.stay7*100 + '%'}
            , {field: 'stay14', title: '14留', width: '15%', templet: (row) => row.stay14*100 + '%'}
            , {field: 'stay30', title: '30留', width: '15%', templet: (row) => row.stay30*100 + '%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            lossRender(res);
            lossRenderPercent(res)
        }
    });
}
function lossRenderPercent(result) {
    var legend = ['次留','7留','14留','30留'];
    var myChart = echarts.init(document.getElementById('loss_statics_percent'));
    var option = {
        title: {
            text: '留存统计'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: legend
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: result.datas.x_data
        },
        yAxis: {
            type: 'value',
            axisLine: {
                show: true,
                lineStyle: {
                    color: '#5470C6'
                }
            },
            axisLabel: {
                formatter: '{value} %'
            }
        },
        series: [
            {
                name: legend[0],
                type: 'line',
                stack: legend[0],
                data: result.datas.y_data2
            },
            {
                name: legend[1],
                type: 'line',
                stack: legend[1],
                data: result.datas.y_data3
            },
            {
                name: legend[2],
                type: 'line',
                stack: legend[2],
                data: result.datas.y_data4
            },
            {
                name: legend[3],
                type: 'line',
                stack: legend[3],
                data: result.datas.y_data5
            }
        ]
    };
    myChart.setOption(option);

}

function lossRender(result) {
    var legend = ['总用户','新增用户'];
    var myChart = echarts.init(document.getElementById('loss_statics'));
    var option = {
        title: {
            text: '用户统计'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: legend
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: result.datas.x_data
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                name: legend[0],
                type: 'line',
                stack: legend[0],
                data: result.datas.y_data
            },
            {
                name: legend[1],
                type: 'line',
                stack: legend[1],
                data: result.datas.y_data1
            }
        ]
    };
    myChart.setOption(option);
}

function renderNewLoss(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'create_times', title: '日期', width: '25%', sort: true, fixed: 'left'}
            , {field: 'dnu', title: '新用户', width: '25%'}
            , {field: 'flow7', title: '7流', width: '25%'}
            , {field: 'flow14', title: '14流', width: '25%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            newLossRender(res);
        }
    });
}

function newLossRender(result) {
    var legend = ['7流','14流'];
    var myChart = echarts.init(document.getElementById('new_loss_statics'));
    var option = {
        title: {
            text: '新增流失'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: legend
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: result.datas.x_data
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                name: legend[0],
                type: 'line',
                stack: '总量',
                data: result.datas.y_data
            },
            {
                name: legend[1],
                type: 'line',
                stack: '总量',
                data: result.datas.y_data1
            },
        ]
    };
    myChart.setOption(option);
}

function renderActiveLoss(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'create_times', title: '日期', width: '20%', sort: true, fixed: 'left'}
            , {field: 'dau', title: '活跃用户', width: '20%'}
            , {field: 'flow1', title: '次流', width: '20%'}
            , {field: 'flow7', title: '7流', width: '20%'}
            , {field: 'flow14', title: '14流', width: '20%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            activeLossRender(res);
        }
    });
}

function activeLossRender(result) {
    var legend = ['7流','14流'];
    var myChart = echarts.init(document.getElementById('active_loss_statics'));
    var option = {
        title: {
            text: '活跃流失'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: legend
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: result.datas.x_data
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                name: legend[0],
                type: 'line',
                stack: '总量',
                data: result.datas.y_data
            },
            {
                name: legend[1],
                type: 'line',
                stack: '总量',
                data: result.datas.y_data1
            },
        ]
    };
    myChart.setOption(option);
}