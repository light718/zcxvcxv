$(function () {

})

function renderLevelTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'title', title: '等级分布', width: '20%'}
            , {field: 'num', title: '人数', width: '40%'}
            , {field: 'rate', title: '比例', width: '40%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dataRender(res);
        }
    });
}

/***
 *  流失充值百分比分布
 * @param obj
 */
function renderRechargeTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'title', title: '充值金额分布', width: '20%'}
            , {field: 'num', title: '人数', width: '40%'}
            , {field: 'rate', title: '比例', width: '40%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log("充值金额分布数据："+JSON.stringify(res));
            // dataRender(res);
        }
    });
}

/***
 *  流失充值百分比分布
 * @param obj
 */
function renderCoinTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'title', title: '金币分布',  width: '20%'}
            , {field: 'num', title: '人数', width: '40%'}
            , {field: 'rate', title: '比例', width: '40%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dataRender(res);
        }
    });
}

/***
 *  流失最后游戏百分比分布
 * @param obj
 */
function renderDistTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'title', title: '游戏名称', width: '20%'}
            , {field: 'num', title: '人数', width: '40%'}
            , {field: 'rate', title: '比例', width: '40%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dataRender(res);
        }
    });
}

/***
 * 流失分布列表
 * @param obj
 */
function renderLossTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'uid', title: 'UID', width: 120}
            , {field: 'coin', title: '金币', width: 200}
            , {field: 'level', title: '等级', width: 100}
            , {field: 'price', title: '商城金额', width: 100}
            , {field: 'create_time', title: '注册时间', width: 250}
            , {field: 'login_time', title: '最后登录时间', width: 250}
            , {field: 'last_game_title', title: '最后游戏', width: 250}
            , {field: 'last_game_time', title: '最后游戏时间', width: 250}

        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dataRender(res);
        }
    });
}