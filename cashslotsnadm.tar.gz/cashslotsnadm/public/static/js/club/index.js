function searchUser(uid) {
    let datas = {};
    datas.user_id = uid ? uid : $("#uid").val();
    sendAjax(datas,function (res) {
        let user_data = res.data.result;
        if (res.code == 0){
            $("#avatar").html("<img src='"+user_data.usericon +"'>");
            $("#user_name").html(user_data.playername);
            $("#level").html(user_data.level);
            $("#user_id").html(user_data.uid);
            $("#coin").html(user_data.coin);
            $("#diamond").html(user_data.diamond);
            $("#points").html(user_data.points);
            $("#regist_time").html(user_data.create_time);
            $("#last_login_time").html(user_data.login_time);
            $("#pay_amount").html(user_data.totalpay  +" $");
            $("#create_platform").html(user_data.create_platform_text)
            if (!user_data.isbind) {
                $("#unbind").html("已解绑").prop('disabled', true);
            }else{
                $("#unbind").html("解绑").prop('disabled', false);
            }
            if (user_data.status == 1){
                $("#change_status").html("封号");
                $("#hide_status").val(0);
            }else{``
                $("#hide_status").val(1);
                $("#change_status").html("启用");
            }
            $("#status_text").html(user_data.status_text);
        }else {
            layer.msg(res.msg)
        }
    },'get','index',function (err) {
        console.log(err)
    });
}

/***
 *  封号
 */
function titleUser() {
    let datas = {};
    layer.confirm("你确定？",function ( ) {
        datas.user_id = $("#uid").val();
        datas.status = $("#hide_status").val();
        sendAjax(datas,function (res) {
            // let user_data = res.data.result;
            if (res.code == 0){
                var status = datas.status == 1 ? 0 : 1;
                if (status == 1){
                    $("#status_text").html("封号")
                    $("#change_status").html("启用");
                }else{
                    $("#change_status").html("封号");
                    $("#status_text").html("启用")
                }
                $("#hide_status").val(status)
                layer.msg(res.msg)
            }else {
                layer.msg(res.msg)
            }
        },'post','titleUser',function (err) {
            console.log(err)
        });
    })
}

/***
 *  解绑
 */
 function unbind() {
    let datas = {};
    layer.confirm("你确定？",function ( ) {
        datas.user_id = $("#uid").val();
        $.get('unbind?uid=' + $("#uid").val(), function(res){
            if(res.code == 0){
                $("#unbind").html("已解绑").prop('disabled', true);
            }
            layer.msg(res.msg)
        })
    })
}


function searchUsers(uid) {
    let datas = {};
    datas.user_id = uid ? uid : $("#uid").val();
    sendAjax(datas,function (res) {
        let user_data = res.data.result;
        // if (res.code == 0){
            $("#avatar",parent.document.body).html("<img src='"+user_data.usericon +"'>");
            $("#user_name",parent.document.body).html(user_data.playername);
            $("#level",parent.document.body).html(user_data.level);
            $("#user_id",parent.document.body).html(user_data.uid);
            $("#coin",parent.document.body).html(user_data.coin);
            $("#regist_time",parent.document.body).html(user_data.create_time);
            $("#last_login_time",parent.document.body).html(user_data.login_time);
            $("#pay_amount",parent.document.body).html(user_data.totalpay +" $");
            $("#create_platform",parent.document.body).html(user_data.create_platform_text)
            if (user_data.status == 1){
                $("#change_status",parent.document.body).html("封号");
                $("#hide_status",parent.document.body).val(0);
            }else{``
                $("#hide_status",parent.document.body).val(1);
                $("#change_status",parent.document.body).html("启用");
            }
            $("#status_text",parent.document.body).html(user_data.status_text);
        // }else {
        //     layer.msg(res.msg)
        // }
    },'get','index',function (err) {
        console.log(err)
    });
}

function restName() {
    let datas = {};
    layer.confirm("重置姓名？",function ( ) {
        datas.user_id = $("#uid").val();
        sendAjax(datas,function (res) {
            let user_data = res.data.result;
            if (res.code == 0){
                if (user_data.status == 1){
                    $("#change_status").html("封号");
                    $("#hide_status").val(0);
                }else{
                    $("#hide_status").val(1);
                    $("#change_status").html("启用");
                }
                $("#status_text").html(user_data.status_text)
                layer.msg(res.msg)
                searchUser(datas.user_id);

            }else {
                layer.msg(res.msg)
            }
        },'post','restName',function (err) {
            console.log(err)
        });
    })
}

function coinManage() {
    var uids = $("#uid").val();
    if (!uids){
        layer.msg("请输入用户ID");
        return;
    }
    layer.open({
        type:2,
        content:"coinEdit?uid="+uids,
        title:"金币管理",
        area:['95%','60%'],
    });

}

function saveBtn(that,uid) {
    var index = layer.load(1, {
        shade: [0.2,'#fff'] //0.1透明度的白色背景
    });
    $(that).attr("disabled","disabled")
    var datas = {};
    datas.coin = $("#amount").val();
    datas.reason = $("#reason").val();
    datas.coin_send = $("#coin_send").val();
    datas.type = $('input[name="type"]:checked').val();
    sendAjax(datas,function (res) {
        if (res.code == 0){
            searchUsers(uid);
            layer.alert(res.msg,function () {
                parent.layer.closeAll();
            })
            // parent.window.location.reload();
        }else{
            layer.closeAll('loading');
            $(that).attr("disabled",false)
            layer.msg(res.msg);
        }

    },'post','index?user_id='+uid,function (err) {
        console.log(err)
    })
}

function renderClub(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem

        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'id', title: '编号', width: 150, sort: true, fixed: 'left'},
            {field: 'owner_name', title: '管理员', width: 150}
            , {field: 'create_time', title: '日期', width: 150}
            , {field: 'member_counts', title: '人数', width: 150}
            , {field: 'name', title: '俱乐部名称', width: 150}
            , {field: 'id', title: '操作', width: 300, toolbar: '#toolbarDemo'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dauRender(res);
        }
    });
    // table.on('tool(club_table)', function(obj){ //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
    //     var data = obj.data; //获得当前行数据
    //     var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
    //     var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）
    //     console.log(data)
    //     if(layEvent === 'transfer'){ // 转移
    //         layer.open({
    //             type:1,
    //             content: $("#transfer_html"),
    //             title: '转让管理员',
    //             area: ['500px','600px']
    //         });
    //     } else if(layEvent === 'members'){ // 用户
    //         layer.open({
    //             type:2,
    //             content: 'members?id='+data.id,
    //             title: '转让管理员',
    //             area: ['500px','600px']
    //         })
    //     } else if(layEvent === 'dissolution'){ //解散
    //         layer.confirm("确定要解散此俱乐部吗？",function () {
    //             var datas = {};
    //             datas.id = data.id;
    //             sendAjax(datas,function (res) {
    //
    //             },'post','');
    //         })
    //
    //     }
    // });
}

function searchData() {
    renderClub({
        elem:"#club_table",
        url:'clubs?name='+$("#time_year").val(),
    });
}

function renderLogData(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'id', title: 'ID', width: 150, sort: true, fixed: 'left'},
            {field: 'create_time', title: '日期', width: 150},
            {field: 'operate_name', title: '操作人员', width: 150},
            {field: 'menu_name', title: '操作对象', width: 150 },
            {field: 'content', title: '操作内容', width: 500}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dauRender(res);
        }
    });
}

function searchWords() {
    renderWords({
        elem:"#words_table",
        url:'shieldWords?name='+$("#time_year").val(),
    });
}

function renderWords(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'id', title: 'ID', width: 150, sort: true, fixed: 'left'},
            {field: 'word', title: '过滤字符', width: 200}
            ,{field: 'id', title: '操作', width: 300, toolbar: '#toolbarDemo'}

        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dauRender(res);
        }
    });
}

function saveWords(id) {
    var datas = {}
    datas.id = id ;
    datas.word = $("#word").val() ;
    sendAjax(datas,function (res) {
        layer.msg(res.msg)
        if (res.code == 0){
            parent.renderWords({
                elem:"#words_table",
                url:'shieldWords?name='+$("#time_year", parent.document.body).val(),
            });
            console.log(111);
            parent.layer.closeAll();
        }
    },'post','wordEdit?id='+id,function (err) {
        console.log(err)
    })
}

function renderLog(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            // {field: 'account_id', title: '玩家ID ', width: 150, sort: true, fixed: 'left'}
            // {field: 'account_pid', title: '账号', width: '30%'}
            {field: 'ip', title: 'IP', width: '100'}
            , {field: 'create_time', title: '最后登录时间', width: '180'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

/***
 * 玩家明细
 * @param obj
 */
function renderDetailList(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            // {field: 'id', title: '玩家ID', width: '8%', sort: true}
            // , {field: 'pid', title: '玩家账号', width:  '15%'}
            {field: 'create_time', title: '时间', width: '180'}
            , {field: 'game_title', title: '游戏名 ', width: '100'}
            , {field: 'bet', title: '下注金币', width: '90'}
            , {field: 'win_coin', title: '输赢金币', width: '90'}
            // , {field: 'after', title: '结束金额', width: '15%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            console.log(res);
        }
    });
}

function renderGameData(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]
        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'uid', title: '用户ID', width: '55'},
            {field: 'playername', title: '昵称', width: '90'}
            , {field: 'coin', title: '金币', width: '100'}
            , {field: 'id', title: '操作', width: '100', toolbar: '#toolbarDemo'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dauRender(res);
        }
    });
}

function renderGameLog(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]
        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'account_id', title: '用户ID', width: '85'},
            {field: 'playername', title: '昵称', width: '90'}
            , {field: 'bet', title: '下注金币', width: '85'}
            , {field: 'win_coin', title: '输赢金币', width: '85'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dauRender(res);
        }
    })
}