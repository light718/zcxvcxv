$(function () {
    getData();
})

function getData() {
    // tableRender(layui.table);
}

function tableRender(table){
    table.render({
        elem: '#getData'
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        ,url: 'index' //数据接口toolbar
        ,cols: [[ //表头
            {field: 'day', title: '日期', width:200, sort: true, fixed: 'left'}
            ,{field: 'dau', title: '总用户', width:150}
            ,{field: 'dnu', title: '新增用户', width:150}
            ,{field: 'dau_spin', title: '新增玩牌用户', width:150 }
            ,{field: 'last_dau', title: '活跃用户', width: 200}
            ,{field: 'activeuser_spin_count', title: '活跃玩牌用户', width: 200}
            ,{field: 'paynum', title: '付费用户', width: 100}
            ,{field: 'payamount', title: '付费金额', width: 100}
            ,{field: 'bankrupt_count', title: '破产用户', width: 100}
            ,{field: 'bankrupt_pay_count', title: '破产付费用户', width: 150}
            , {field: 'dec', title: '日均次数', width: 100}
            , {field: 'daot', title: '日均时长(s)', width: 100}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            console.log(res)
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            dataRender(res);
        }
    });
}

function dataRender(result) {
        var myChart = echarts.init(document.getElementById('data_statics'));
        var colors = ['#5470C6', '#91CC75', '#EE6666'];
// 指定图表的配置项和数据
//             var option = {
//                 title: {
//                     text: '当日用户在线数据统计图'
//                 },
//                 tooltip: {},
//                 legend: {
//                     data: [ltv_text]
//                 },
//                 xAxis: {
//                     type: 'category',
//                     data: result.data.x_data
//                 },
//                 yAxis: {
//                     type: 'value'
//                 },
//                 series: [{
//                     name: ltv_text,
//                     type: 'line',
//                     data: result.data.y_data
//                 }]
//             };
        // 使用刚指定的配置项和数据显示图表。
    var option = {
        title: {
            // text: '未来一周气温变化',
            // subtext: '纯属虚构'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['总用户','新增用户']
        },
        toolbox: {
            show: true,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                dataView: {readOnly: false},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: result.datas.x_data
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value} 人'
            }
        },
        series: [
            {
                name: '总用户',
                type: 'line',
                data: result.datas.y_data1,
                markPoint: {
                    data: [
                        {type: 'max', name: '总用户'},
                        {type: 'min', name: '新增用户'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'}
                    ]
                }
            },
            {
                name: '新增用户',
                type: 'line',
                data: result.datas.y_data2,
                markPoint: {
                    data: [
                        {name: '新增用户'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                position: 'start',
                                formatter: '最大值'
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            }
        ]
    };
    try {
        if(decodeURI(document.cookie.match(/user_group_info=(.*);/)[1]) == '渠道') option.toolbox.show = false
    } catch (error) {
        
    }
    myChart.setOption(option);
}

function renderTaskData(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]
        ,url: obj.url //数据接口toolbar
        ,cols: [[ //表头
            {field: 'create_time', title: '日期', width:200, sort: true, fixed: 'left'}
            ,{field: 'uid', title: 'uid', width:150}
            ,{field: 'level', title: '等级', width:150}
            ,{field: 'roundid', title: '活动轮次', width:150 }
            ,{field: 'game_title', title: '子游戏', width: 200}
            ,{field: 'bet', title: '最后押注额', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            // dataRender(res);
        }
    });
}

function renderActiveData(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height: 700
        ,totalRow: true
        ,page:true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]
        ,url: obj.url //数据接口toolbar
        ,cols: [[ //表头
            {field: 'create_time', title: '日期', width:200, sort: true, fixed: 'left'}
            ,{field: 'uid', title: 'uid', width:150}
            ,{field: 'roundid', title: '活动轮次', width:150 }
            ,{field: 'game_title', title: '子游戏', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            // dataRender(res);
        }
    });
}