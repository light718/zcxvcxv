$(function () {
    getData();
})

function getData() {
    // tableRender(layui.table);
}

function tableRender(table) {
    table.render({
        elem: '#getData'
        , height: 700
        , totalRow: true
        , url: 'playCard' //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        , cols: [[ //表头
            {field: 'day', title: '日期', width: '20%'}
            , {field: 'dnu', title: '总新增用户', width: '28%'}
            , {field: 'dau_not_spin', title: '未游戏人数', width: '20%'}
            , {field: 'dau_spin', title: '游戏人数', width: '10%'}
            , {field: 'avg_spin', title: '人均spin', width: '20%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            dataRender(res);
        }
    });
}

function dataRender(result) {
    var myChart = echarts.init(document.getElementById('data_statics'));
    var colors = ['#5470C6', '#91CC75', '#EE6666'];
    // 指定图表的配置项和数据
    var max1 = Math.max.apply(null,result.datas.y_data)
    var max2 = Math.max.apply(null,result.datas.y_data1)
    var max_num  = (max1 > max2 ? max1 :max2) + 10;
    // 使用刚指定的配置项和数据显示图表。
    var legend = ['未游戏人数', '游戏人数', '人均spin'];
    var option = {
        color: colors,

        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross'
            }
        },
        grid: {
            right: '20%'
        },
        toolbox: {
            feature: {
                dataView: {show: true, readOnly: false},
                restore: {show: true},
                saveAsImage: {show: true}
            }
        },
        legend: {
            data: legend
        },
        xAxis: [
            {
                type: 'category',
                data: result.datas.x_data,
                axisPointer: {
                    type: 'shadow'
                }
            }
        ],
        yAxis: [
            {
                type: 'value',
                name: legend[0],
                min: 0,
                max: max_num,
                position: 'right',
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: colors[0]
                    }
                },
                axisLabel: {
                    formatter: '{value} 人'
                }
            },
            {
                type: 'value',
                name: legend[1],
                min: 0,
                max: max_num,
                position: 'right',
                offset: 80,
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: colors[1]
                    }
                },
                axisLabel: {
                    formatter: '{value} 人'
                }
            },
            {
                type: 'value',
                name: legend[2],
                min: 0,
                max: 1000,
                position: 'left',
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: colors[2]
                    }
                },
                axisLabel: {
                    formatter: '{value} 次'
                }
            }
        ],
        series: [
            {
                name: legend[0],
                type: 'bar',
                data: result.datas.y_data
            },
            {
                name: legend[1],
                type: 'bar',
                yAxisIndex: 1,
                data: result.datas.y_data1
            },
            {
                name: legend[2],
                type: 'line',
                yAxisIndex: 2,
                data: result.datas.y_data2
            }
        ]
    };
    try {
        if(decodeURI(document.cookie.match(/user_group_info=(.*);/)[1]) == '渠道') option.toolbox.show = false
    } catch (error) {
        
    }
    myChart.setOption(option);
}

function renderDau(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: '20%'}
            , {field: 'reg_fb_count', title: 'FB', width: '20%'}
            , {field: 'reg_ios_count', title: 'Ios', width: '20%'}
            , {field: 'reg_google_count', title: 'GP', width: '20%'}
            , {field: 'reg_guest_count', title: '游客', width: '20%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            dauRender(res);
        }
    });
}

function dauRender(result) {
    var myChart = echarts.init(document.getElementById('today_statics'));
    var option = {
        title: {
            text: '登录数据饼图',
            subtext: '',
            left: 'center'
        },
        tooltip: {
            trigger: 'item'
        },
        legend: {
            orient: 'vertical',
            left: 'left',
        },
        series: [
            {
                name: '访问来源',
                type: 'pie',
                radius: '50%',
                data: [
                    {value: result.datas.fb_count, name: 'FB登录数'},
                    {value: result.datas.guest_user_count, name: '游客'},
                    {value: result.datas.reg_ios_count, name: 'IOS'},
                    {value: result.datas.google_user_count, name: 'Google登录'},
                ],
                emphasis: {
                    itemStyle: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };
    myChart.setOption(option);
}


function renderSubGame(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15
        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'create_times', title: '日期', width: '10%', sort: true, fixed: 'left'}
            , {field: 'not_play_game', title: '0种', width: '10%'}
            , {field: 'played_one_game', title: '1种', width: '10%'}
            , {field: 'played_two_game', title: '2种', width: '10%'}
            , {field: 'played_three_game', title: '3种', width: '10%'}
            , {field: 'played_four_game', title: '4种', width: '10%'}
            , {field: 'played_five_game', title: '5种', width: '10%'}
            , {field: 'played_six_game', title: '6种', width: '10%'}
            , {field: 'played_more_game', title: '6+钟', width: '10%'}
            , {field: 'all_count', title: '汇总', width: '10%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            subGameRender(res);
        }
    });
}

function subGameRender(result ) {

    var legend = ['0种', '1种', '2种', '3种', '4种', '5种', '6种', '6+种', '汇总'];
    var myChart = echarts.init(document.getElementById('subGame_statics'));
    var option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        legend: {
            data: legend
        },
        grid: {
            left: '8%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: [
            {
                type: 'category',
                data: result.datas.x_data
            }
        ],
        yAxis: [
            {
                type: 'value'
            }
        ],
        series: [
            {
                name: legend[0],
                type: 'bar',
                stack: legend[0],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data
            },
            {
                name: legend[1],
                type: 'bar',
                stack: legend[1],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data1
            },
            {
                name: legend[2],
                type: 'bar',
                stack: legend[2],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data2
            },
            {
                name: legend[3],
                type: 'bar',
                stack: legend[3],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data3
            },
            {
                name: legend[4],
                type: 'bar',
                stack: legend[4],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data4
            },
            {
                name: legend[5],
                type: 'bar',
                stack: legend[5],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data5
            },
            {
                name: legend[6],
                type: 'bar',
                stack: legend[6],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data6
            },
            {
                name: legend[7],
                type: 'bar',
                stack: legend[7],
                emphasis: {
                    focus: 'series'
                },
                data: result.datas.y_data7
            },

        ]
    };
    myChart.setOption(option);
}

function renderFirstPlay(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        , cols: [[ //表头
            {field: 'create_times', title: '日期', width: '12%', sort: true, fixed: 'left'}
            , {field: 'game_title', title: '游戏名称', width: '18%'}
            , {field: 'allusers', title: '游戏人数', width: '10%'}
            , {field: 'allbet', title: '总下注', width: '10%'}
            , {field: 'allwin', title: '总发放', width: '10%'}
            , {field: 'alltimes', title: '游戏次数', width: '10%'}
            , {field: 'bet_one', title: 'bet1W', width: '10%'}
            , {field: 'bet_two', title: 'bet2W', width: '10%'}
            , {field: 'bet_other', title: 'otherBet ', width: '10%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}