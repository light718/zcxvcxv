$(function () {
    getData();
})

function getData() {
    // tableRender(layui.table);
}

function tableRender(obj){
    table.render({
        elem: obj.elem
        ,height:700
        , totalRow: true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        ,page:true
        ,url: obj.url  //数据接口toolbar
        ,cols: [[ //表头
            {field: 'create_time', title: '日期', width:150, sort: true, fixed: 'left'}
            ,{field: 'title', title: '标题', width:200,templet: function(row){
                var str = '';
                if (row.istest == 1){
                    str = " <span > [测试] </span>";
                }
                return str + " " + row.title;
            }}
            ,{field: 'amount', title: '金额', width:100}
            ,{field: 'from_channel_text', title: '下单渠道', width:100 }
            ,{field: 'status_text', title: '状态', width: 200}
            ,{field: 'uid', title: '用户编号', width: 200}
            ,{field: 'user_level', title: '付费时等级', width: 200}
            ,{field: 'user_coin', title: '用户付费时携带金币数量', width: 200, templet: function(row){
                return row.user_coin.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,')
            }}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            dataRender(res);
        }
    });
}

function dataRender(result) {
        var myChart = echarts.init(document.getElementById('data_statics'));
        var colors = ['#5470C6', '#91CC75', '#EE6666'];
// 指定图表的配置项和数据
//             var option = {
//                 title: {
//                     text: '当日用户在线数据统计图'
//                 },
//                 tooltip: {},
//                 legend: {
//                     data: [ltv_text]
//                 },
//                 xAxis: {
//                     type: 'category',
//                     data: result.data.x_data
//                 },
//                 yAxis: {
//                     type: 'value'
//                 },
//                 series: [{
//                     name: ltv_text,
//                     type: 'line',
//                     data: result.data.y_data
//                 }]
//             };
        // 使用刚指定的配置项和数据显示图表。
    var option = {
        title: {
            // text: '未来一周气温变化',
            // subtext: '纯属虚构'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['总用户','新增用户']
        },
        toolbox: {
            show: true,
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                dataView: {readOnly: false},
                magicType: {type: ['line', 'bar']},
                restore: {},
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: result.datas.x_data
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value} 人'
            }
        },
        series: [
            {
                name: '总用户',
                type: 'line',
                data: result.datas.y_data1,
                markPoint: {
                    data: [
                        {type: 'max', name: '总用户'},
                        {type: 'min', name: '新增用户'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'}
                    ]
                }
            },
            {
                name: '新增用户',
                type: 'line',
                data: result.datas.y_data2,
                markPoint: {
                    data: [
                        {name: '新增用户'}
                    ]
                },
                markLine: {
                    data: [
                        {type: 'average', name: '平均值'},
                        [{
                            symbol: 'none',
                            x: '90%',
                            yAxis: 'max'
                        }, {
                            symbol: 'circle',
                            label: {
                                position: 'start',
                                formatter: '最大值'
                            },
                            type: 'max',
                            name: '最高点'
                        }]
                    ]
                }
            }
        ]
    };
    myChart.setOption(option);
}
