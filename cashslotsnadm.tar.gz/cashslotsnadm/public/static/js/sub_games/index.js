
function subGames(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: '9%'}
            , {field: 'game_title', title: '游戏名称', width: '8%'}
            , {field: 'allusers', title: '游戏人数', width: '7%'}
            , {field: 'allbet', title: '总下注', width: '15%'}
            , {field: 'allwin', title: '总发放', width: '10%'}
            , {field: 'alltimes', title: '游戏次数', width: '10%'}
            , {field: 'bet_one', title: 'bet1W', width: '10%'}
            , {field: 'bet_two', title: 'bet2W', width: '10%'}
            , {field: 'bet_other', title: 'otherBet ', width: '10%'}
            , {field: 'bet_free', title: '免费游戏次数', width: '10%'}
        ]]
        ,initSort:{
            field:'create_time',
            type:'desc'
        }
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}