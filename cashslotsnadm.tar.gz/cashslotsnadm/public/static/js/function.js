/**
 * Created by Administrator on 2018/6/12.
 */


//关闭指定弹窗
function closeLayer(){
	var index=parent.layer.getFrameIndex(window.name);
	parent.layer.close(index);
}
