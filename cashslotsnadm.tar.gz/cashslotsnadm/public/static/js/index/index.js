$(function () {
    reloadOnlineNums();
    getEchartsData();
    window.setInterval("getEchartsData()", 60000)

})



function reloadOnlineNums() {
    $('#online_nums').text('loading');
    $.ajax({
        url: 'online_nums',
        dataType: 'json',
        type: 'POST',
        success: function (result) {
            if (result.errcode == 1001) {
                window.location.reload();
            } else if (result.code == 0) {
                $('#online_nums').text(result.data.online_nums);
                $('#fb_online_nums').text(result.data.fb_online_nums);
                $('#google_online_nums').text(result.data.google_online_nums);
                $('#guest_online_nums').text(result.data.guest_online_nums);
                $('#ios_online_nums').text(result.data.ios_online_nums);
                $('#android_online_nums').text(result.data.android_online_nums);
                let city_html = '';
                let country = result.data.country;
                for (var i = 0; i < country.length; i++) {
                    if(country[i]['val'] > 0 ) {
                        city_html += "<div class=\"col-xs-6 col-md-3\">" + country[i]['key'] + "在线: <span>" + country[i]['val'] + "</span></div>"
                    }
                }
                $('#city_list').html(city_html);

            }
        }
    });
}

/***
 * 获取统计图数据
 */
function getEchartsData() {
    $.ajax({
        url: 'get_online_count',
        dataType: 'json',
        type: 'POST',
        success: function (result) {
            if (result.errcode == 1001) {
                window.location.reload();
            } else if (result.code == 0) {
                console.log(result.data);
                var myChart = echarts.init(document.getElementById('today_online_data'));

// 指定图表的配置项和数据
                var option = {
                    title: {
                        text: '当日用户在线数据统计图'
                    },
                    tooltip: {},
                    legend: {
                        data: ['在线人数']
                    },
                    xAxis: {
                        type: 'category',
                        data: result.data.x_data
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [{
                        name: '在线人数',
                        type: 'line',
                        data: result.data.y_data
                    }]
                };
                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);

            }
        }
    });
}

function renderOtherDay(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        , cols: [[ //表头
            {field: 'day', title: '日期', width: 200, sort: true, fixed: 'left'}
            , {field: 'dnu', title: '总新增用户', width: 300}
            , {field: 'dau_not_spin', title: '未游戏人数', width: 100}
            , {field: 'dau_spin', title: '游戏人数', width: 100}
            // , {field: 'avg_spin', title: '人均spin', width: 200}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            dataRender(res);
        }
    });
}

function renderConfig(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        , cols: [[ //表头
            {field: 'id', title: '序号', width: '10%', sort: true, fixed: 'left'}
            , {field: 'id', title: '天数', width: '15%',templet:function (row) {
                return "第"+row.id + "天";
                }}
            , {field: 'count', title: '配置金币', width: '40%',templet:function (row) {
                    return "原始签到金币: "+row.count  + " 购买升级后的签到金币:"+ row.upCount ;
                }}
            , {field: 'is_force', title: '是否强制弹出', width: '10%'}
            , {field: 'sort', title: '强制弹出顺序', width: '10%'}
            , {field: 'button', title: '操作', width: '10%',templet:"#tablebar"}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}


function renderGoods(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height:700
        , totalRow: true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]
        ,page:true
        ,url: obj.url  //数据接口toolbar

        ,cols: [[ //表头
            {field: 'id', title: '序号', width:'2%',type:'numbers'}
            ,{field: 'id', title: '商品编号', width:'5%' }
            ,{field: 'title', title: '商品英文名', width:'10%'}
            ,{field: 'title', title: '商品中文名', width:'10%' }
            ,{field: 'ord', title: '顺序', width: '10%'}
            ,{field: 'status_text', title: '是否开放', width: '10%'}
            ,{field: 'stype', title: '标签数字显示', width: '10%'}
            ,{field: 'count', title: '金币数量', width: '10%'}
            ,{field: 'is_discount', title: '是否限时', width: '10%'}
            ,{field: 'discountTime', title: '显示显示剩余时间', width: '10%'}
            , {field: 'button', title: '操作', width: '10%',templet:"#goodsTablebar"}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            // dataRender(res);
        }
    });
}

function renderBonus(obj) {
    var table = layui.table;

    table.render({
        elem: obj.elem
        ,height:700
        , totalRow: true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]
        ,page:true
        ,url: obj.url  //数据接口toolbar
        ,cols: [[ //表头
            {field: '', title: '序号',type:'numbers',  width:'5%'}
            ,{field: 'id', title: '活动编号', width:'10%' }
            ,{field: 'name', title: '活动英文名', width:'15%'}
            ,{field: 'name_cn', title: '活动中文名', width:'15%' }
            ,{field: 'sort', title: '顺序', width: '15%'}
            ,{field: 'is_open', title: '是否开放', width: '15%'}
            ,{field: 'uid', title: '标签数字显示', width: '15%'}
            ,{field: 'uid', title: '是否限时', width: '15%'}
            ,{field: 'uid', title: '显示显示剩余时间', width: '15%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            dataRender(res);
        }
    });
}

function renderMission(obj) {
    var table = layui.table;

    table.render({
        elem: obj.elem
        ,height:700
        , totalRow: true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]
        ,page:true
        ,url: obj.url  //数据接口toolbar
        ,cols: [[ //表头
            {field: '', title: '序号',type:'numbers',  width:'5%'}
            ,{field: 'descr', title: '任务标题', width:'8%' }
            ,{field: 'descr', title: '任务正文', width:'12%'}
            ,{field: 'jumpTo', title: '任务跳转(界面or子游戏)', width:'12%' }
            ,{field: 'rewards', title: '任务奖励类型', width: '15%'}
            ,{field: 'count', title: '任务奖励数量(乘等级系数)', width: '12%'}
            ,{field: 'icon', title: '任务图标', width: '10%'}
            ,{field: '', title: '任务活跃点数', width: '15%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            dataRender(res);
        }
    });
}



function renderActive(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        ,height:700
        , totalRow: true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]
        ,page:true
        ,url: obj.url  //数据接口toolbar
        ,cols: [[ //表头
            {field: '', title: '序号',type:'numbers',  width:'5%'}
            ,{field: 'activity', title: '活跃点', width:'10%' }
            ,{field: 'activity_goods', title: '奖励物品', width:'15%'}
            ,{field: 'activity_num', title: '奖励数量(乘等级系数)', width:'15%' }
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        ,parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done:function (res) {
            dataRender(res);
        }
    });
}