function renderScoreLog(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 500
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'account_id', title: '用户ID', width: 80}
            , {field: 'account_name', title: '昵称', width: 100 }
            , {field: 'coin', title: '金币', width: 80}
            , {field: 'coin_send', title: '附赠金币', width: 100}
            , {field: 'createtime', title: '时间', width: 160}
            ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}


function renderStaticsData(obj){
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 400
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'account_id', title: '用户ID', width: 70}
            , {field: 'account_name', title: '用户昵称', width: 100 }
            , {field: 'coin', title: '金币', width: 85}
            , {field: 'coin_send', title: '附赠金币', width: 80}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            $("#all_score").html(res.all_score)
        }
    });
}
