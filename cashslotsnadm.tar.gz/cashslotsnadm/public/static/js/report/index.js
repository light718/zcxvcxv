$(function () {

})

function renderDataTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        ,page: true //开启分页
        ,limit: 15
        ,limits:[15,20,30,40,50,60,70,80,90]
        , cols: [[ //表头
            {field: 'game_name', title: '游戏名', width: 200, sort: true, fixed: 'left'}
            , {field: 'aux', title: 'AU', width: 150}
            , {field: 'bet_num', title: '下注次数', width: 100}
            , {field: 'bet', title: '注金', width: 150}
            , {field: 'sys_win_coin', title: '赢钱', width: 200}
            , {field: 'sys_win_ratio', title: '系统胜率', width: 200}
            , {field: 'sys_win_coin_ratio', title: '系统赢钱率', width: 200}

        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dataRender(res);
        }
    });
}

function renderTypeStatics(obj){
    var myChart = echarts.init(document.getElementById(obj.elem));
    sendAjax(obj.data,function (res) {
        if (res.code == 200){
// 指定图表的配置项和数据
            var option = {
                title: {
                    text: '库存变化'
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data: ['总库存', res.data.game_name]
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: res.data.x_data,
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name: '总库存',
                        type: 'line',
                        stack: '总库存',
                        data: res.data.y_data
                    },
                    {
                        name: res.data.game_name,
                        type: 'line',
                        stack: res.data.game_name,
                        data: res.data.y_data1
                    }
                ]
            };
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
        }else{
            layer.msg(res.msg)
        }
    },'get', obj.url,function (err) {
        console.log(err);
    })
}

function renderPoolTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 350
        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'title', title: '库存标题', width: 200, sort: true, fixed: 'left'}
            , {field: 'num', title: '库存', width: 150}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dataRender(res);
        }
    });
}

function renderPayRate(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 600
        ,page:true
        , totalRow: true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'id', title: 'GameID', width: 200}
            , {field: 'title', title: '游戏名', width: 150}
            , {field: 'bet', title: '总下注', width: 150}
            , {field: 'win', title: '总赢分', width: 150}
            , {field: 'payrate', title: '回报率', width: 150}
            , {field: 'day', title: '日期', width: 150}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            // dataRender(res);
        }
    });
}


function getPoolNormal(obj) {
    var dom = document.getElementById(obj.elem);
    var myChart = echarts.init(dom);
    $.ajax({
        url: obj.url,
        dataType: 'json',
        type: 'POST',
        success:function(result) {
            if (result.code == 0) {
                var names = [];
                var xdata = result.data.time;
                var seriesdata = [];
                // $.each(result.data.title, function(i, v) {
                //     names.push(v);
                // });
                $.each(result.data, function(i, v) {
                    seriesdata.push({
                        name: v.country,
                        value: v.total
                    });
                });

                var option = {
                    title: {
                        text: '世界地图',
                        left: 'center',
                        top: 'top'
                    },
                    visualMap: {
                        min: 0,
                        max: 1000000,
                        text:['High','Low'],
                        realtime: false,
                        calculable: true,
                        color: ['orangered','yellow','lightskyblue']
                    },
                    series: {
                        name: 'World Population (2010)',
                        type: 'map',
                        mapType: 'world',
                        roam: true,
                        itemStyle:{
                            emphasis:{label:{show:true}}
                        },
                        data: seriesdata
                    }
                };
                myChart.setOption(option, true);
            }
        }
    });
}

function renderOnineTable(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 600
        ,page:true
        , totalRow: true
        ,limit:15
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'title', title: '在线类别', width: 200}
            , {field: 'num', title: '在线人数', width: 150}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            renderOnlineStatics(res);
        }
    });
}

function renderOnlineStatics(obj) {
    var dom = document.getElementById(obj.elem);
    var myChart = echarts.init(dom);
    var option = {
        title: {
            text: '世界地图',
            left: 'center',
            top: 'top'
        },
        visualMap: {
            min: 0,
            max: 1000000,
            text:['High','Low'],
            realtime: false,
            calculable: true,
            color: ['orangered','yellow','lightskyblue']
        },
        series: {
            name: 'World Population (2010)',
            type: 'map',
            mapType: 'world',
            roam: true,
            itemStyle:{
                emphasis:{label:{show:true}}
            },
            data: seriesdata
        }
    };
    myChart.setOption(option, true);
}