$(function () {
    next_retention(1);
})
function next_retentions(datas) {

        sendAjax(datas,function (result) {
            if (result.code == 0){
                if (datas.type ==1 ){
                    var ltv_text = '次日留存率';
                    var myChart = echarts.init(document.getElementById('next_retention'));
                }else if(datas.type ==2){
                    var ltv_text = '七日留存率';
                    var myChart = echarts.init(document.getElementById('seven_retention'));
                }else{
                    var ltv_text = '三十日留存率';
                    var myChart = echarts.init(document.getElementById('thirty_retention'));
                }

                var colors = ['#5470C6', '#91CC75', '#EE6666'];
                var option = {
                    color: colors,
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'cross'
                        },
                        formatter: function(obj){
                            var str='';
                            str = obj[0].seriesName+ "" + obj[0].value +"人 &nbsp;<br/>" + obj[1].seriesName +"&nbsp;"+ obj[1].value+ "%";
                            // console.log(str);
                            return str;
                        }
                    },
                    grid: {
                        right: '20%'
                    },
                    toolbox: {
                        feature: {
                            dataView: {show: true, readOnly: false},
                            restore: {show: true},
                            saveAsImage: {show: true}
                        }
                    },
                    legend: {
                        data: [ltv_text, '新增用户']
                    },
                    xAxis: [
                        {
                            type: 'category',
                            axisTick: {
                                alignWithLabel: true
                            },
                            data: result.data.x_data
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value',
                            name: '新增用户',
                            min: 0,
                            max: 250,
                            position: 'right',
                            axisLine: {
                                show: true,
                                lineStyle: {
                                    color: colors[0]
                                }
                            },
                            axisLabel: {
                                formatter: '{value} 人'
                            }
                        },
                        {
                            type: 'value',
                            name: ltv_text,
                            min: 0,
                            max: 90,
                            position: 'left',
                            axisLine: {
                                show: true,
                                lineStyle: {
                                    color: colors[1]
                                }
                            },
                            itemStyle: {
                                normal: {
                                    label: {
                                        formatter: function (a, b, c) {
                                            console.log(a,b,c)
                                            return c + "%";
                                        }
                                    }
                                }
                            },
                            axisLabel: {
                                formatter: '{value} %'
                            }
                        }
                    ],
                    series: [
                        {
                            name: '新增用户',
                            type: 'bar',
                            data: result.data.y_data1
                        },
                        {
                            name: ltv_text,
                            type: 'line',
                            yAxisIndex: 1,
                            data: result.data.y_data,
                            // formatter:function(a,b,c){return c+"%";},
                            //
                            // itemStyle:{
                            //     normal:{
                            //         label:{
                            //             formatter:function(a,b,c){return c+"%";}
                            //         }
                            //     }
                            // }
                        }
                    ]
                };
// 指定图表的配置项和数据
//             var option = {
//                 title: {
//                     text: '当日用户在线数据统计图'
//                 },
//                 tooltip: {},
//                 legend: {
//                     data: [ltv_text]
//                 },
//                 xAxis: {
//                     type: 'category',
//                     data: result.data.x_data
//                 },
//                 yAxis: {
//                     type: 'value'
//                 },
//                 series: [{
//                     name: ltv_text,
//                     type: 'line',
//                     data: result.data.y_data
//                 }]
//             };
                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            }
        },'post','next_retention',function (error) {

        })

}

function next_retention(type) {
    var datas = {
        type:type
    };
    sendAjax(datas,function (result) {
        if (result.code == 0){
            if (type ==1 ){
                var ltv_text = '次日留存率';
                var myChart = echarts.init(document.getElementById('next_retention'));
            }else if(type ==2){
                var ltv_text = '七日留存率';
                var myChart = echarts.init(document.getElementById('seven_retention'));
            }else{
                var ltv_text = '三十日留存率';
                var myChart = echarts.init(document.getElementById('thirty_retention'));
            }

            var colors = ['#5470C6', '#91CC75', '#EE6666'];
            var option = {
                color: colors,
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'cross'
                    },
                    formatter: function(obj){
                        var str='';
                        str = obj[0].seriesName+ "" + obj[0].value +"人 &nbsp;<br/>" + obj[1].seriesName +"&nbsp;"+ obj[1].value+ "%";
                        // console.log(str);
                        return str;
                    }
                },
                grid: {
                    right: '20%'
                },
                toolbox: {
                    feature: {
                        dataView: {show: true, readOnly: false},
                        restore: {show: true},
                        saveAsImage: {show: true}
                    }
                },
                legend: {
                    data: [ltv_text, '新增用户']
                },
                xAxis: [
                    {
                        type: 'category',
                        axisTick: {
                            alignWithLabel: true
                        },
                        data: result.data.x_data
                    }
                ],
                yAxis: [
                    {
                        type: 'value',
                        name: '新增用户',
                        min: 0,
                        max: 250,
                        position: 'right',
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: colors[0]
                            }
                        },
                        axisLabel: {
                            formatter: '{value} 人'
                        }
                    },
                    {
                        type: 'value',
                        name: ltv_text,
                        min: 0,
                        max: 90,
                        position: 'left',
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: colors[1]
                            }
                        },
                        itemStyle: {
                            normal: {
                                label: {
                                    formatter: function (a, b, c) {
                                        console.log(a,b,c)
                                        return c + "%";
                                    }
                                }
                            }
                        },
                        axisLabel: {
                            formatter: '{value} %'
                        }
                    }
                ],
                series: [
                    {
                        name: '新增用户',
                        type: 'bar',
                        data: result.data.y_data1
                    },
                    {
                        name: ltv_text,
                        type: 'line',
                        yAxisIndex: 1,
                        data: result.data.y_data,
                        // formatter:function(a,b,c){return c+"%";},
                        //
                        // itemStyle:{
                        //     normal:{
                        //         label:{
                        //             formatter:function(a,b,c){return c+"%";}
                        //         }
                        //     }
                        // }
                    }
                ]
            };
// 指定图表的配置项和数据
//             var option = {
//                 title: {
//                     text: '当日用户在线数据统计图'
//                 },
//                 tooltip: {},
//                 legend: {
//                     data: [ltv_text]
//                 },
//                 xAxis: {
//                     type: 'category',
//                     data: result.data.x_data
//                 },
//                 yAxis: {
//                     type: 'value'
//                 },
//                 series: [{
//                     name: ltv_text,
//                     type: 'line',
//                     data: result.data.y_data
//                 }]
//             };
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
        }
    },'post','next_retention',function (error) {

    })
}


function pay_user() {
    var datas = {};
    sendAjax(datas,function (result) {
        if (result.code == 0){
            var myChart = echarts.init(document.getElementById('pay_user'));

// 指定图表的配置项和数据
            var option = {
                title: {
                    text: '付费用户数据统计图'
                },
                tooltip: {},
                legend: {
                    data: ['付费用户']
                },
                xAxis: {
                    type: 'category',
                    data: result.data.x_data
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    name: '付费用户',
                    type: 'line',
                    data: result.data.y_data
                }]
            };
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
        }
    },'post','pay_user',function (error) {
        console.log(error);
    })
}

function pay_rate() {
    var datas = {};
    sendAjax(datas,function (result) {
        if (result.code == 0){
            var myChart = echarts.init(document.getElementById('pay_rate'));

// 指定图表的配置项和数据
            var option = {
                title: {
                    text: '付费率数据统计图'
                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'cross'
                    },
                    formatter: function(obj){
                        var str='';
                        str = obj[0].seriesName+ "" + obj[0].value +"% &nbsp;<br/>";
                        // console.log(str);
                        return str;
                    }
                },
                legend: {
                    data: ['付费率']
                },
                xAxis: {
                    type: 'category',
                    data: result.data.x_data
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    name: '付费率',
                    type: 'line',
                    data: result.data.y_data
                }]
            };
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
        }
    },'post','pay_rate',function (error) {
        console.log(error);
    })
}

function pay_amount() {
    var datas = {};
    sendAjax(datas,function (result) {
        if (result.code == 0){
            var myChart = echarts.init(document.getElementById('pay_amount'));

// 指定图表的配置项和数据
            var option = {
                title: {
                    text: '付费金额数据统计图'
                },
                tooltip: {},
                legend: {
                    data: ['付费金额']
                },
                xAxis: {
                    type: 'category',
                    data: result.data.x_data
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    name: '付费金额',
                    type: 'line',
                    data: result.data.y_data
                }]
            };
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
        }
    },'post','pay_amount',function (error) {
        console.log(error);
    })
}

function pay_new_amount() {
    var datas = {};
    sendAjax(datas,function (result) {
        if (result.code == 0){
            var myChart = echarts.init(document.getElementById('pay_new_amount'));

// 指定图表的配置项和数据
            var option = {
                title: {
                    text: '新增付费用户数据统计图'
                },
                tooltip: {},
                legend: {
                    data: ['新增付费用户']
                },
                xAxis: {
                    type: 'category',
                    data: result.data.x_data
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    name: '新增付费用户',
                    type: 'line',
                    data: result.data.y_data
                }]
            };
            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
        }
    },'post','pay_new_amount',function (error) {
        console.log(error);
    })
}