$(function () {
})

function renderStatics(obj){
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'area', title: '概况', width: 300, sort: true, fixed: 'left'}
            , {field: 'dau', title: '用户数', width: 150}
            , {field: 'today', title: '当天', width: 150}
            , {field: 'stay1', title: '次留', width: 150}
            , {field: 'stay7', title: '7留', width: 150}
            , {field: 'stay14', title: '14留', width: 150}
            , {field: 'stay30', title: '30留', width: 150}

        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            staticsRender(res);
        }
    });
}

function staticsRender(result) {
    var legend = ['stay1','stay7','stay14','stay30'];
    var myChart = echarts.init(document.getElementById('new_loss_statics'));
    var option = {
        title: {
            text: '留存趋势概况'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: legend
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: result.datas.x_data
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                name: legend[0],
                type: 'line',
                stack: legend ,
                data: result.datas.y_data
            },
            {
                name: legend[1],
                type: 'line',
                stack: legend[1],
                data: result.datas.y_data1
            },
            {
                name: legend[2],
                type: 'line',
                stack: legend[2],
                data: result.datas.y_data2
            },   {
                name: legend[3],
                type: 'line',
                stack: legend[3],
                data: result.datas.y_data3
            },
            {
                name: legend[4],
                type: 'line',
                stack: legend[4],
                data: result.datas.y_data4
            },

        ]
    };
    myChart.setOption(option);
}

function renderShopOrder(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        ,page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , url: obj.url //数据接口toolbar
        , cols: [[ //表头
            {field: 'stype', title: 'ID', width: 150}
            , {field: 'count', title: '订单数量', width: 200}
            , {field: 'money', title: '订单金额', width: 200}
            , {field: 'pcount', title: '支付成功订单数', width: 200}
            , {field: 'pmoney', title: '支付成功订单金额', width: 200}
            , {field: 'name', title: '类别', width: 150}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
            dataRender(res);
        }
    });
}

function dataRender(result) {
    var myChart = echarts.init(document.getElementById('pay_amount'));
    var colors = ['#5470C6', '#91CC75', '#EE6666'];
    // 指定图表的配置项和数据

    // 使用刚指定的配置项和数据显示图表。
    var legend = ['订单数目', '游戏人数', '人均'];
    var option = {
        color: colors,

        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross'
            }
        },
        grid: {
            right: '20%'
        },
        toolbox: {
            feature: {
                dataView: {show: true, readOnly: false},
                restore: {show: true},
                saveAsImage: {show: true}
            }
        },
        legend: {
            data: legend
        },
        xAxis: [
            {
                type: 'category',
                data: result.datas.x_data,
                axisPointer: {
                    type: 'shadow'
                }
            }
        ],
        yAxis: [
            {
                type: 'value',
                name: legend[0],
                min: 0,
                max: 250,
                position: 'right',
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: colors[0]
                    }
                },
                axisLabel: {
                    formatter: '{value} 单'
                }
            },
            // {
            //     type: 'value',
            //     name: legend[1],
            //     min: 0,
            //     max: 250,
            //     position: 'right',
            //     offset: 80,
            //     axisLine: {
            //         show: true,
            //         lineStyle: {
            //             color: colors[1]
            //         }
            //     },
            //     axisLabel: {
            //         formatter: '{value} 人'
            //     }
            // },
            // {
            //     type: 'value',
            //     name: legend[2],
            //     min: 0,
            //     max: 30000,
            //     position: 'left',
            //     axisLine: {
            //         show: true,
            //         lineStyle: {
            //             color: colors[2]
            //         }
            //     },
            //     axisLabel: {
            //         formatter: '{value} 人'
            //     }
            // }
        ],
        series: [
            {
                name: legend[0],
                type: 'bar',
                data: result.datas.y_data
            },
            // {
            //     name: legend[1],
            //     type: 'bar',
            //     yAxisIndex: 1,
            //     data: result.datas.y_data1
            // },
            // {
            //     name: legend[2],
            //     type: 'line',
            //     yAxisIndex: 2,
            //     data: result.datas.y_data2
            // }
        ]
    };
    myChart.setOption(option);
}