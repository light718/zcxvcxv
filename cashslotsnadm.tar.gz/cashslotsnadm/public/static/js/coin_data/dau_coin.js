$(function () {

})

function renderDauCoin(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: 200, sort: true, fixed: 'left'}
            , {field: 'within_10w', title: '携带金币1w以内的人数', width: 250}
            , {field: 'within_50w', title: '携带金币1w-500w以内的人数', width: 150,default:0}
            , {field: 'within_100w', title: '携带金币500w-3kw的人数', width: 150}
            , {field: 'within_500w', title: '携带金币3kw-5kw的人数', width: 150}
            , {field: 'beyond_500w', title: '携带金币5kw以外的人数', width: 150}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}

function renderDnuCoin(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: 200, sort: true, fixed: 'left'}
            , {field: 'reg_within_10w', title: '携带金币1w以内的人数', width: 250}
            , {field: 'reg_within_50w', title: '携带金币1w-500w以内的人数', width: 150,default:0}
            , {field: 'reg_within_100w', title: '携带金币500w-3kw的人数', width: 150}
            , {field: 'reg_within_500w', title: '携带金币3kw-5kw的人数', width: 150}
            , {field: 'reg_beyond_500w', title: '携带金币5kw以外的人数', width: 150}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}