function renderCoin(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: '30%', sort: true, fixed: 'left'}
            , {field: 'back', title: '金币回收', width: '20%'}
            , {field: 'all_coin_count', title: '金币发放', width: '30%'}

            , {field: 'difference', title: '差值', width: '20%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}

function renderRealseData(obj){
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_time', title: '日期', width: 150, sort: true, fixed: 'left'}
            , {field: 'login_coin_count', title: '登录赠送', width: 150}
            , {field: 'sign_coin_count', title: '七日签到', width: 150}
            , {field: 'turntable_coin_count', title: '转盘', width: 150}
            , {field: 'bind_fb_coin_count', title: '绑定fb', width: 150}
            , {field: 'friends_fb_coin', title: '好友fb分享', width: 150}
            , {field: 'bonus_fb_coin', title: 'bonus-fb', width: 150}
            , {field: 'first_login_coin_count', title: '首次登录', width: 150}
            , {field: 'level_up_coin_count', title: '升级', width: 150}
            , {field: 'guagua_coin_count', title: '刮刮乐', width: 150}
            , {field: 'club_coin_count', title: '俱乐部发放', width: 200}
            , {field: 'gametask_coin_count', title: 'quest发放', width: 200}

            , {field: 'buy_send_coin_count', title: '购买发放', width: 200}
            , {field: 'card_lottery_coin_count', title: '幸运抽卡发放', width: 200}
            , {field: 'egg_coin_count', title: '砸蛋金币发放', width: 200}
            , {field: 'card_month_try_count', title: '月卡试用发放', width: 200}
            , {field: 'card_month_coin_count', title: '月卡发放', width: 200}
            , {field: 'card_week_coin_count', title: '周卡发放', width: 200}
            , {field: 'luack_redbag_coin_count', title: '红包发放', width: 200}
            , {field: 'hero_card_coin_count', title: '卡牌发放', width: 200}

            , {field: 'bankruptcy_coin_count', title: '破产', width: 150}
            , {field: 'mission_coin_count', title: '任务', width: 150}
            , {field: 'sonspin_coin_count', title: '子游戏spin', width: 150}
            , {field: 'firendsend_coin_count', title: '好友', width: 150}
            , {field: 'mail_coin_count', title: '邮件', width: 150}
            , {field: 'backend_send_coin', title: '后台发放', width: 150}
            , {field: 'bingo_reward_coin_count', title: 'Bingo游戏奖励', width: 150}
            // , {field: 'bingo_shop_coin_count', title: 'Bingo商品赠送', width: 150}
            // , {field: 'bingo_rank_coin_count', title: 'Bingo排行榜奖励', width: 150}
            // , {field: 'backend_send_coin', title: '后台发放', width: 150}
            , {field: 'all_coin_count', title: '汇总', width: 150}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}

function renderBackData(obj) {
    var table = layui.table;
    table.render({
        elem: obj.elem
        , height: 700
        , totalRow: true
        , url: obj.url //数据接口toolbar
        , page: true //开启分页
        ,limit: 15 //注意：请务必确保 limit 参数（默认：10）是与你服务端限定的数据条数一致
        ,limits:[15,20,30,40,50,60,70,80,90]

        , cols: [[ //表头
            {field: 'create_times', title: '日期', width: '15%', sort: true, fixed: 'left'}
            , {field: 'allbet', title: '通过下注回收的金币', width: '20%'}
            , {field: 'backend_reback_coin', title: '后台回收', width: '20%'}
            , {field: 'allbets', title: '其他途径', width: '20%',default:0}
            , {field: 'allbet', title: '回收汇总', width: '30%'}
        ]]
        , response: {
            statusCode: 200 //重新规定成功的状态码为 200，table 组件默认为 0
        }
        , parseData: function (res) { //将原始数据解析成 table 组件所规定的数据
            return {
                "code": res.code, //解析接口状态
                "msg": res.msg, //解析提示文本
                "count": res.data.count, //解析数据长度
                "data": res.data.list.data//解析数据列表
            };
        },
        done: function (res) {
        }
    });
}

