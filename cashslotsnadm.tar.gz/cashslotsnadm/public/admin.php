<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/2/3
 * Time: 13:27
 */
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2019 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

// [ 应用入口文件 ]
namespace think;
// echo '666';exit;
require __DIR__ . '/../vendor/autoload.php';
define('CMF_ROOT', dirname(__DIR__) . '/');

define('APP_PATH',  CMF_ROOT.'app/admin');

// 执行HTTP应用并响应
$http = (new  App())->http;
$response = $http->name('admin')->run();
$response->send();
$http->end($response);

