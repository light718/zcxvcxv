<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StateSlotsPayrate extends Model
{
    //

    public static function getListData($limit =15,$is_export= 1){
        if ($is_export){
            $query = self::where([])->order('id desc')->select()->toArray();
        }else{
            $query = self::where([])->order('id desc')->paginate($limit);
        }
        return $query;
    }
}
