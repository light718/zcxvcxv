<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StatGameData extends Model
{
    //
    public $dateFormat = "Y-m-d";
    public $type  = [
        'create_time' => 'timestamp'
    ];

}
