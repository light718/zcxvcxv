<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;
use think\Request;

/**
 * @mixin \think\Model
 */
class StatOnlineGame extends Model
{
    //
    /**
     * 获取系统报表
     * 5分钟
     * Tax池存量
     * @param int $time
     * @param int $time2
     */
    public static function getStat5minGameOnlinePlayer($time_arr){
        $list = self::whereBetween('datetime',$time_arr)->order('id asc')->select();
        foreach ($list as &$one){
            $one['timestamp'] = strtotime($one['datetime']);
        }
        return $list;
    }

    /**
     * @param $value
     * @return mixed
     */
    public function getCountsAttr($value){
        if (is_array($value)){
            return json_decode($value,true);
        }else{
            return $value;
        }
    }
}
