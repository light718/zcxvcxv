<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class SysGlobalnotice extends Model
{
    //
    protected $type = [
        'create_time' => 'timestamp',
    ];
    protected $dateFormat = 'Y-m-d H:i:s';
}
