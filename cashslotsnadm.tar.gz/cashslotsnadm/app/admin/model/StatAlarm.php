<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StatAlarm extends Model
{
    //
    protected $dateFormat = 'Y-m-d H:i:s';
    protected $type = [
        'datetime' => 'timestamp'
    ];
}
