<?php

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class CoinsPlayer extends Model
{
    //
    protected $dateFormat = 'Y-m-d';

    /**
     * 获取总赢钱
     * @param  integer $startTime
     * @param  integer $endTime
     * @return [type]
     */
    public static function getTotalWin($startTime = 0, $endTime = 0)
    {
        $db = new self();
        if ($startTime && $endTime) {
            $db = $db->whereBetween('create_time', [$startTime, $endTime]);
        }
        // 3 下注，4 赢钱，5 bigbang，6 红包
        $db->whereIn('type', [3, 4, 5, 6]);
        $rs = $db->sum( 'coin');
        return format_money($rs);
    }

}
