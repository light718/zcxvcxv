<?php
declare (strict_types=1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class SNickname extends Model
{
    const STATE_NORMAL = 0;
    const STATE_FORBID = 1;

    const STATE_ARR = [
        self::STATE_NORMAL => '禁用',
        self::STATE_FORBID => '启用',
    ];
    //
    protected $connection = 'game';


    public function getStateTextAttr($val, $data)
    {
        if (isset(self::STATE_ARR[$data['state']])) {
            return self::STATE_ARR[$data['state']];
        }
        return lang('unknown');
    }

}
