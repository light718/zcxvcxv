<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class PoolTax extends Model
{
    //

    /**
     * 获取总抽水
     * @param  integer $startTime
     * @param  integer $endTime
     * @return [type]
     */
    public static function getTotalPoolTax($startTime = 0, $endTime = 0)
    {
        $db = self::where('type', 1);
        if ($startTime && $endTime) {
            $db = $db->whereBetween('create_time', [$startTime, $endTime] );
        }
        $rs = $db->sum( 'coin');
        return format_money($rs);
    }
}
