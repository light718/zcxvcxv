<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/2/26
 * Time: 13:50
 */
namespace app\admin\model;
use think\Model;

class Account extends Model{

    protected $table = 'account';
    protected $dateFormat = 'Y-m-d H:i:s';
    protected $type = [
        'login_time'=>'timestamp',
    ];
    const STATUS_NORMAL = 1;
    const STATUS_FORBIDDEN = 0;

    /***
     * @param $id
     * @return array|null|Model
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public static function getAccountById($id){
        $res = self::where(compact('id'))->find();
        return $res;
    }

    /***
     * 获取上级
     * @return Model|\think\model\relation\HasOne
     */
    public function getParents(){
        return $this->hasOne(Account::class,'id','parent_id');
    }

    /***
     * 获取最上级的用户
     * @return \think\model\relation\HasOne
     */
    public function getLastParent(){
        return $this->hasOne(Account::class,'id','parent_agent_first_id');
    }

    public function access(){
        return $this->hasOne(AuthGroupAccess::class,'uid','id');
    }

    public static function getUserPwdById($id = '' ,$username = '',$pwd ='',$salt = ''){
        if ($id){
            $account_re = self::where(compact('id'))->find();
            $password = md5($account_re['username'].md5($account_re['password']).$account_re['salt']);
        }else{
            $password = md5($username.md5($pwd).$salt);
        }
        return $password;
    }

    public function getCoinAttr($val){
        return intval($val);
    }
}