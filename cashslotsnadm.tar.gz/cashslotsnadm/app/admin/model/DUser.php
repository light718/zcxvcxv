<?php

namespace app\admin\model;

use think\db\Query;
use think\facade\Db;
use think\Model;

/**
 * @mixin \think\Model
 */
class DUser extends Model
{
    protected $connection = 'game';
    //

    protected $dateFormat = 'Y-m-d H:i:s';
    protected $type = [
        'create_time' => 'timestamp',
        'login_time' => 'timestamp',
    ];

    /***
     * 获取dnu
     * @return int
     */
    public static function getDNU()
    {
        $todayStamp = strtotime(date('Y-m-d'));
        $num = self::where('create_time', '>=', $todayStamp)->count('uid');
        return $num;

    }

    /*** 获取dau
     * @return int
     */
    public static function getDAU()
    {
        $todayStamp = strtotime(date('Y-m-d'));
        $num = DUserLoginLog::where('create_time', '>=', $todayStamp)->count('distinct uid');
        return $num;
    }

    public function getCreatePlatformTextAttr($val, $data)
    {
        switch ($data['create_platform']) {
            case 12:
                $create_plateform = 'FB';
                break;
            case 1:
                $create_plateform = 'Guest';
                break;
            case 10:
                $create_plateform = 'Google';
                break;
            case 11:
                $create_plateform = 'Ios';
                break;
            default:
                $create_plateform = 'Guest';
                break;

        }
        return $create_plateform;
    }

    /***
     * 获取状态
     * @param $val
     * @param $data
     * @return mixed|string
     */
    public function getStatusTextAttr($val, $data)
    {
        $status_arr = [0 => '封号', 1 => '正常'];
        return isset($status_arr[$data['status']]) ? $status_arr[$data['status']] : '未知';
    }

    public function getOnlinestateTextAttr($val, $data)
    {
        $status_arr = [0 => '离线', 1 => '在线'];
        return isset($status_arr[$data['onlinestate']]) ? $status_arr[$data['onlinestate']] : '未知';
    }

    /***
     * @param int $startDate
     * @param int $endDate
     * @return array
     */
    public static function getLevelList($startTime, $endTime)
    {

        //注册用户的等级分布及奖励比例
        $sql = "select a.uid, a.`level`, a.coin, b.scale from d_user a left join s_config_level_upgrade b on a.level = b.level where a.create_time>={$startTime} and a.create_time<{$endTime}";
        $ret = Db::connect('game')->query($sql);
        $level_data = [];
        foreach ($ret as $row) {
            $key = self::getLevelType($row['level']);
            if (!isset($level_data[$key])) {
                $level_data[$key] = [];
            }
            if ($row['scale'] == 0) {
                $level_data[$key][] = 0;
            } else {
                $level_data[$key][] = $row['coin'] / $row['scale']; //金币价值
            }
        }

        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $now = time();
        //这段时间内注册的人充值总额
        $sql = "select sum(amount) as totalamount, level_type from (select amount, (CASE WHEN user_level=1 THEN  '1' WHEN user_level=2 THEN  '2' WHEN user_level=3 THEN  '3' WHEN user_level=4 THEN  '4' WHEN user_level=5 THEN  '5' WHEN user_level=6 THEN  '6' WHEN user_level=7 THEN  '7' WHEN user_level=8 THEN  '8' WHEN user_level=9 THEN  '9' WHEN user_level=10 THEN  '10' WHEN user_level>=11 AND user_level<=20 THEN '11' WHEN user_level>20 AND user_level<=30 THEN '12' WHEN user_level>30 AND user_level<=50 THEN '13' ELSE '14' END ) as level_type from s_shop_order where create_time>={$startTime} and create_time<{$now} and `status`=2 and uid not in (". implode(',', $testAccount).")) a group by level_type";
        $ret = Db::connect('game')->query($sql);
        $charge_data = [];
        foreach ($ret as $row) {
            $charge_data[$row['level_type']] = $row['totalamount'];
        }

        //这段时间内注册的人的破产次数
        $sql = "select count(*) as alltimes, level_type from (select id, (CASE WHEN level=1 THEN  '1' WHEN level=2 THEN  '2' WHEN level=3 THEN  '3' WHEN level=4 THEN  '4' WHEN level=5 THEN  '5' WHEN level=6 THEN  '6' WHEN level=7 THEN  '7' WHEN level=8 THEN  '8' WHEN level=9 THEN  '9' WHEN level=10 THEN  '10' WHEN level>=11 AND level<=20 THEN '11' WHEN level>20 AND level<=30 THEN '12' WHEN level>30 AND level<=50 THEN '13' ELSE '14' END) as level_type from d_bankrupt_log where create_time>={$startTime} and create_time<{$now} and uid not in (". implode(',', $testAccount).")) a group by level_type";
        $ret = Db::connect('game')->query($sql);
        $bankrupt_data = [];
        foreach ($ret as $row) {
            $bankrupt_data[$row['level_type']] = $row['alltimes'];
        }
        $return_data = [];
        foreach ($level_data as $k => $v) {
            $totalUsers = count($v);
            $total_coinvalue = 0;
            foreach ($v as $row) {
                $total_coinvalue += $row;
            }
            $return_data[] = [
                'level_type' => $k,
                'allusers' => $totalUsers, //人数
                'avgcoinval' => $total_coinvalue / $totalUsers, //金币价值平均数
                'chargeamount' => isset($charge_data[$k]) ? $charge_data[$k] : 0, //充值总额
                'allrupt' => isset($bankrupt_data[$k]) ? $bankrupt_data[$k] : 0, //总破产次数
                'create_time' => $startTime,
            ];
        }
        return $return_data;
    }

    /***
     * 获取用户等级
     * @param int $level
     * @return int
     */
    protected static function getLevelType($level)
    {
        if ($level <= 10) {
            return $level;
        } elseif ($level >= 11 && $level <= 20) {
            return 11;
        } elseif ($level > 20 && $level <= 30) {
            return 12;
        } elseif ($level > 30 && $level <= 50) {
            return 13;
        } else {
            return 14;
        }
    }

    /***
     * 获取级别
     * @param $startTime
     * @param $endTime
     * @return array
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public static function getLevelDistribution($startTime, $endTime)
    {   
        $lossTime = time() - 60*60*48;
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $results = self::field('uid,`level`')
            ->whereBetween('create_time', [$startTime, $endTime])
            ->where('uid', 'not in', $testAccount)
            ->where('login_time', '<', $lossTime)
            ->select();
        $total = 0;
        $data = [];
        $data[1] = 0;//1级
        $data[2] = 0;//2级
        $data[3] = 0;//3级
        $data[4] = 0;//4级
        $data[5] = 0;//5级
        $data[6] = 0;//6级
        $data[7] = 0;//7
        $data[8] = 0;//8
        $data[9] = 0;//9
        $data[10] = 0;//10
        $data[11] = 0;//11-20
        $data[12] = 0;//20-30
        $data[13] = 0;//30-50
        $data[14] = 0;//大于50级
        foreach ($results as $v) {
            $level = intval($v['level']);
            $total++;
            if ($level <= 10) {
                $data[$level]++;
            } elseif ($level >= 11 && $level <= 20) {
                $data[11]++;
            } elseif ($level > 20 && $level <= 30) {
                $data[12]++;
            } elseif ($level > 30 && $level <= 50) {
                $data[13]++;
            } else {
                $data[14]++;
            }
        }
        $dict = [
            1 => '1级',
            2 => '2级',
            3 => '3级',
            4 => '4级',
            5 => '5级',
            6 => '6级',
            7 => '7级',
            8 => '8级',
            9 => '9级',
            10 => '10级',
            11 => '11~20级',
            12 => '20~30级',
            13 => '30~50级',
            14 => '50级+',
        ];
        $res = [];
        foreach ($data as $k => $v) {
            if ($total == 0) {
                $rate = '0%';
            } else {
                $rate = round($v / $total * 100, 2) . '%';
            }

            $res[$k] = [
                'num' => $v,
                'rate' => $rate,
                'title' => $dict[$k]
            ];
        }
        return $res;
    }

    public static function getRechargeDistribution($startTime,$endTime)
    {
        $lossTime = time() - 60*60*48;
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $sql = "select sum(a.amount) as price, a.uid from s_shop_order a join (select uid from d_user where create_time>={$startTime} and create_time<={$endTime} and login_time < $lossTime and uid not in (". implode(',', $testAccount).") ) b on a.uid =b.uid where a.status=2 group by a.uid";
        $results = Db::connect('game')->query($sql);
        $total = count($results);
        $data = [];
        $data[1] = 0;//1美元
        $data[2] = 0;//1美元-10美元
        $data[3] = 0;//10美元-20美元
        $data[4] = 0;//20美元-50美元
        $data[5] = 0;//大于50美元
        foreach ($results as $v) {
            $coin = intval($v['price']);
            if ($coin < 1) {
                $data[1]++;
            } elseif ($coin >= 1 && $coin < 10) {
                $data[2]++;
            } elseif ($coin >= 10 && $coin < 20) {
                $data[3]++;
            } elseif ($coin >= 20 && $coin < 50) {
                $data[4]++;
            } else {
                $data[5]++;
            }
        }
        $dict = [
            1 => '1美元',
            2 => '1美元~10美元',
            3 => '10美元~20美元',
            4 => '20美元~50美元',
            5 => '>=50美元'
        ];
        $res = [];
        foreach ($data as $k => $v) {
            if ($total == 0) {
                $rate = '0%';
            } else {
                $rate = round($v / $total * 100, 2) . '%';
            }

            $res[$k] = [
                'num' => $v,
                'rate' => $rate,
                'title' => $dict[$k]
            ];
        }
        return $res;
    }

    /**
     * 流失存量金币百分比分布
     * @param $startTime
     * @param $endTime
     * @return array
     */
    public static function getCoinDistribution($startTime,$endTime){
        $lossTime = time() - 60*60*48;
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $sql = "select uid, coin,level from d_user where create_time>={$startTime} and create_time<={$endTime} and login_time < {$lossTime} and uid not in (". implode(',', $testAccount).")";
        $results = Db::connect('game')->query($sql);
        $levelCfg = Db::connect('game')->name('s_config_level_upgrade')->column('scale', 'level');
        $total = 0;
        $data = [];
        $data[1] = 0;//10万内
        $data[2] = 0;//10万-50万
        $data[3] = 0;//50万-100万
        $data[4] = 0;//100万-200万
        $data[5] = 0;//200万-300万
        $data[6] = 0;//300万-400万
        $data[7] = 0;//400万-500万
        $data[8] = 0;//500万-1000万
        $data[9] = 0;//1000万-2000万
        $data[10] = 0;//2000万+
        foreach ($results as $v) {
            $coin = intval($v['coin'])/($levelCfg[$v['level']] ?? $levelCfg[count($levelCfg) - 1]);
            $total++;
            if ($coin < 100000) {
                $data[1]++;
            } elseif($coin>=100000 && $coin <500000) {
                $data[2]++;
            } elseif($coin>=500000 && $coin <1000000) {
                $data[3]++;
            } elseif($coin>=1000000 && $coin <2000000) {
                $data[4]++;
            }elseif($coin>=2000000 && $coin <3000000) {
                $data[5]++;
            }elseif($coin>=3000000 && $coin <4000000) {
                $data[6]++;
            }elseif($coin>=4000000 && $coin <5000000) {
                $data[7]++;
            }elseif($coin>=5000000 && $coin <10000000) {
                $data[8]++;
            }elseif($coin>=10000000 && $coin <20000000) {
                $data[9]++;
            }else {
                $data[10]++;
            }
        }
        $dict = [
            1 => '10万内',
            2 => '10万-50万',
            3 => '50万-100万',
            4 => '100万-200万',
            5 => '200万-300万',
            6 => '300万-400万',
            7 => '400万-500万',
            8 => '500万-1000万',
            9 => '1000万-2000万',
            10 => '2000万+',
        ];
        $res = [];
        foreach($data as $k=>$v) {
            if($total == 0) {
                $rate = '0%';
            } else {
                $rate =round( $v/$total * 100 , 2) .'%';
            }

            $res[$k] = [
                'num' => $v,
                'rate' => $rate,
                'title' => $dict[$k]
            ];
        }
        return $res;
    }

    public static function getGameLostDist($startTime,$endTime){
        $lossTime = time() - 60*60*48;
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $sql = "select uid  from d_user where create_time>={$startTime} and create_time<={$endTime} and login_time < {$lossTime} and uid not in (". implode(',', $testAccount).")";
        $userLists = Db::connect('game')->query($sql);

        $lastgameid = [];
        $uids_arr = [];
        $gamelog_total = 0;
        foreach($userLists as $row) {
            $uids_arr[] = $row['uid'];
        }
        if(!empty($uids_arr)) {
            $sql = "select a.game_id, a.account_id from gameserver_gamelog a join (select max(create_time) as create_time, account_id from gameserver_gamelog where account_id in (". implode(',', $uids_arr). ") and create_time>={$startTime} and create_time<={$endTime} and game_id <=1000 group by account_id) b on a.account_id = b.account_id and a.create_time = b.create_time where a.create_time>={$startTime} and a.create_time<={$endTime} and a.game_id<1000";
            $lastGameResult = Db::query($sql);
            $gamelog_total = count($lastGameResult);
            foreach($lastGameResult as $row) {
                if(!isset($lastgameid[$row['game_id']])) {
                    $lastgameid[$row['game_id']] = 0;
                }
                $lastgameid[$row['game_id']]++;
            }
        }

        $total = count($userLists); //总人数
        $res = [];
        foreach($lastgameid as $k=>$v) {
            if($total == 0) {
                $rate = '0%';
            } else {
                $rate =round( $v/$total * 100 , 2) .'%';
            }

            $res[$k] = [
                'game_id' => $k,
                'num' => $v,
                'rate' => $rate,
                'title' => ''
            ];

            $game = Db::connect('game')
                ->name('s_game')
                ->where('id','=',$k)->field("title")->select()->toArray();
//            file_put_contents("/tmp/duser.txt", json_encode($game)."\r\n", FILE_APPEND);
            if($game){
                $res[$k]['title'] = $game[0]['title'];
            }
        }
        if ($gamelog_total < $total) {
            if($total == 0) {
                $rate = '0%';
            } else {
                $num = ($total - $gamelog_total);
                $rate =round( $num/$total * 100 , 2) .'%';
            }
            $res[1000] = [
                'game_id' => 1000,
                'num' => ($total - $gamelog_total),
                'rate' => $rate,
                'title' => '未玩游戏'
            ];
        }

        return $res;
    }
}


