<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;
use think\facade\Db;

/**
 * @mixin \think\Model
 */
class SShopOrder extends Model
{

    const STATUS_SUCCESS = 2;
    protected $dateFormat = 'Y-m-d H:i:s';
    //
    protected $connection = 'game';
    //获取今日下单人数
    public static function getTodayPayNum() {
        $todayStamp = strtotime(date('Y-m-d'));
        $condition = [
            ['create_time','>=', $todayStamp ],
            ['status','=', 2 ],
        ];
        $num = self::where($condition)->count('distinct uid');
        return $num;
    }

    //今日下单成功的金额
    public static function getTodayPayAmount()
    {
        $todayStamp = strtotime(date('Y-m-d'));
        $condition = [
            ['create_time','>=', $todayStamp ],
            ['status','=', 2 ],
        ];
        $num = self::where($condition)->sum('amount');
        return $num;
    }

    /***
     * 注册当天付费人数和金额统计
     * @param $startDate
     * @param $endDate
     * @return mixed
     */
    public static function getRegStateData($startTime, $endTime) {
        $condition = [];
//        $condition[] = ['date(from_unixtime(a.create_time))','=','b.createdate'];
        $condition[] = ['a.create_time','between',[$startTime,$endTime]];
        $condition[] = ['status','=',2];
        $fields = 'count(distinct a.uid) as num, sum(a.amount) as price, date(from_unixtime(a.create_time)) as createdate';
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');

        $list = SShopOrder::alias('a')->field($fields)->where($condition    )
            ->join("(select uid, date(from_unixtime(create_time)) as createdate from d_user where create_time>={$startTime} and create_time<{$endTime} and uid not in (". implode(',', $testAccount). ")) b",
                " a.uid = b.uid and date(from_unixtime(a.create_time)) = b.createdate")
            ->group('date(from_unixtime(a.create_time))')->order('a.create_time desc')->select();
        return $list;
    }

    /**
     * 关联s shop
     * @return \think\model\relation\HasOne
     */
    public function shop(){
        return $this->hasOne(SShop::class,'id','shopid');
    }

    public function user(){
        return $this->hasOne(DUser::class,'uid','uid');
    }
}
