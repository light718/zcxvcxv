<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class CardRedpack extends Model
{
    //
    const NOT_SEND = 0;
    const SENT = 1 ;
    const SEND_FAIL  = 2 ;

    protected $dateFormat = 'Y-m-d H:i:s';
    protected $type = [
        'create_time' => 'timestamp',
        'send_time' => 'timestamp',
    ];
    /***
     * 关联createor
     * @return \think\model\relation\HasOne
     */
    public function sender(){
        return $this->hasOne(Account::class,'id','create_id');
    }

    /***
     * @param $val
     * @param $data
     * @return mixed
     */
    public function getStatusTextAttr($val,$data){
        $arr = [
            self::NOT_SEND => lang('not send'),
            self::SENT => lang('had send'),
            self::SEND_FAIL => lang('send fail')

        ];
        if (isset($arr[$data['status']])){
            return $arr[$data['status']];
        }
        return lang('unkown');
    }

}
