<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class DSysMail extends Model
{
    //
    protected $connection = 'game';
    protected $dateFormat = 'Y-m-d H:i:s';
    protected $type = [
        'timestamp' => 'timestamp',
    ];
}
