<?php
declare (strict_types = 1);

namespace app\admin\model;

use org\Curl;
use think\Model;

/**
 * @mixin \think\Model
 */
class SGameType extends Model
{
    //
    protected $connection = 'game';

//    public static function getGameList($uniq = 1,$lang = ''){
//        $curl = new Curl();
//        $gamelist_jsonstr = $curl->simple_get($curl->_game_server_host.'?mod=getgamelist&uniq=' . $uniq . '&lang=' . $lang, [], ['PORT'=> $this->_game_server_port, 'TIMEOUT'=> 5]);
//        $result = json_decode($gamelist_jsonstr, true);
//        if (isset($result['data']) && $result['data'])
//        {
//            $this->models->rediscli_model->getDb()->setEx($cache_key, 300, $gamelist_jsonstr);
//            return $result['data'];
//        }
//
//    }
}
