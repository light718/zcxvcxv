<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StatMainpoll extends Model
{
    //
    protected $dateFormat = 'Y-m-d';
    protected $type = [
        'dtime' => 'timestamp'
    ];
    /***
     * @param $value
     * @return mixed
     */
    public function getDataAttr($value){
        return json_decode($value,true);
    }
}
