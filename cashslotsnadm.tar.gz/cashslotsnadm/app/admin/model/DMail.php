<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * 邮箱系统
 * @mixin \think\Model
 */
class DMail extends Model
{
    //
    protected $connection = 'game';

    /***
     * 我的
     * @param $value
     * @return mixed
     */
    public function getMsgAttr($value){
        if ($msg = json_decode($value,true)){
            return $msg;
        }
        return $value;
    }

}
