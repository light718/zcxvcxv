<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class ClubOperateLog extends Model
{
    //
    protected $dateFormat = 'Y-m-d H:i:s';
    protected $type = [
        'create_time' => 'timestamp'
    ];

    protected $connection = 'club';

    /***
     * 创建日志
     * @param string $log_data
     * @param $type_text
     * @return bool
     */
    public static function createLog(string $log_data,$type_text){
        $data = [];
        $data['account_id'] = session('user_info.id');
        $data['create_time'] = time();
        $data['content'] = $log_data;
        $data['operate_name'] = session('user_info.username');
        $data['menu_name'] = $type_text;
        return self::create($data);

    }
}
