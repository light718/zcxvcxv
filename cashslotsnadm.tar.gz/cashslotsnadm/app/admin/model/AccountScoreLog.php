<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\db\Query;
use think\Model;

/**
 * @mixin \think\Model
 */
class AccountScoreLog extends Model
{
    protected $dateFormat = "Y-m-d H:i:s";
    protected $autoWriteTimestamp = true;
    protected $createTime = 'createtime';
    protected $type = [
        'createtime' => 'timestamp',
    ];
    //

    public static function insertLog($log_data){
        $current = new self();
        return $current->save($log_data);
    }

    public static function getListById($id,$limit =15){
        return self::with(['creator'=>function(Query $query){
            $query->field('id,username');
        }])->where(compact('id'))->paginate($limit);
    }

    public function creator(){
        return $this->hasOne(Account::class,'id','account_id');
    }

}
