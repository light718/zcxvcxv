<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StatAppLogAreastartapp extends Model
{
    //
    protected $table = 'stat_app_log_areastartapp';
    protected $dateFormat = 'Y-m-d';
    protected $type = [
        'day' => 'timestamp'
    ];

    public static function getAllStartTimes($startTime, $endTime){
        return self::select()->toArray();
    }
}
