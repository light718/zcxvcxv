<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class GameserverGamelog extends Model
{
    protected $dateFormat = "Y-m-d H:i:s";
    protected $type = [
        'create_time' => 'timestamp',
    ];
    //

    public function game(){
    }

    public function getBetAttr($val){
        return intval($val);
    }

    public function getWinAttr($val){
        return intval($val);
    }

}
