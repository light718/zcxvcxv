<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StatShopOrder extends Model
{
    //
    const STYPE_SHOP = 1;
    const STYPE_DIS  = 2;
    const STYPE_TURN = 3;
    const STYPE_BAG = 4;
    const STYPE_LEVEL = 5;
    const STYPE_SIGN = 6;

    const STYPE_FIRST = 7;
    const STYPE_TIMEONLY = 8;
    const STYPE_TOP = 9;
    const STYPE_PIG = 10;
    const STYPE_FUND = 13;
    const STYPE_WEEKEND = 14;
    const STYPE_MONTH = 15;
    const STYPE_SHAMMER  = 19;
    const STYPE_GHAMMER = 20;
    const STYPE_ARR = [
        self::STYPE_SHOP => '商城',
        self::STYPE_DIS => '限时优惠',
        self::STYPE_TURN => '转盘',
        self::STYPE_BAG => '激励礼包',
        self::STYPE_LEVEL => '等级礼包',
        self::STYPE_SIGN => '签到',
        self::STYPE_FIRST => '首充礼包',
        self::STYPE_TIMEONLY => 'onetimeonly',
        self::STYPE_TOP => '排行榜时榜',
        self::STYPE_PIG => '金猪',
        self::STYPE_FUND => '成长基金',
        self::STYPE_WEEKEND => '周卡',
        self::STYPE_MONTH => '月卡',
        self::STYPE_SHAMMER => '银锤子',
        self::STYPE_GHAMMER => '金锤子'

    ];
    protected $dateFormat  = 'Y-m-d H:i:s';
    protected $type = [
        'create_time'=> 'timestamp'
    ];

    public function getStypeTextAttr($val,$data){
        if (isset(self::STYPE_ARR[$data['stype']]))
        {
            return self::STYPE_ARR[$data['stype']];
        }
        return '';

    }
}
