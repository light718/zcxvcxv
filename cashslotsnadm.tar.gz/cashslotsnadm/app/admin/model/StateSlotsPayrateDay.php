<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StateSlotsPayrateDay extends Model
{
    //
    /***
     * 获取总体数据列表
     * @param $start_time
     * @param $end_time
     * @return array
     */
    public static function getListData($time_arr,$is_export =0,$limit= 15){
        $query = self::whereBetween('day',$time_arr)->order('id desc');
        if ($is_export){
            $list = $query->select()->toArray();
        }else{
            $list = $query->paginate($limit);
        }
        return $list;
    }
}
