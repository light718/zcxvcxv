<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class SShop extends Model
{
    //
    protected $connection = 'game';

    /***
     * 获取状态
     * @param $val
     * @param $data
     * @return mixed|string
     */
    public function getStatusTextAttr($val, $data)
    {
        $status_arr = [0 => '未知', 1 => '正常购买','2'=>'禁止'];
        return isset($status_arr[$data['status']]) ? $status_arr[$data['status']] : '未知';
    }

    public function getIsDiscountAttr($val,$data){
        if ($data['discountTime']){
            return '限时';
        }else{
            return '不限时';
        }
    }
}
