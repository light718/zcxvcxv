<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class ScoreLog extends Model
{
    //
    /***
     *
     * @param $account_id
     * @param $startTime
     * @param $endTime
     * @return mixed
     */
    public static function getDirectlyAgentTotalReload($account_id,$startTime,$endTime){
        $db = self::alias( 's')->withJoin('account', 'LEFT')->where('account.parent_id', $account_id)->whereBetween('score_log.create_time', [$startTime, $endTime]);
        $num = $db->where('score_log.coin', '>', 0)->sum( 'score_log.coin');
        return $num;
    }

    /***
     * @return \think\model\relation\HasOne
     */
    public function account(){
        return $this->hasOne(Account::class,'id','account_id');
    }

    /**
     * 获取所有玩家的总上下分
     * @param  integer $startTime
     * @param  integer $endTime
     * @return [type]
     */
    public static function getAllPlayerTotalScore($startTime = 0, $endTime = 0)
    {
        $db = new self();
        $db->where('agent', 0)->field('type, SUM(coin) AS coin');
        if ($startTime && $endTime) {
            $db = $db->whereBetween('create_time', [$startTime, $endTime]);
        }
        $rs = $db->group('type')->select();
        $rs = collect($rs)->toArray();
        $rs = array_column($rs, 'coin', 'type');
        return [
            'reload' => format_money(isset($rs[1]) && $rs[1] ? $rs[1] : 0),
            'withdraw' => format_money(isset($rs[2]) && $rs[2] ? abs($rs[2]) : 0)
        ];
    }


}
