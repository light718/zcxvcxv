<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class SSign extends Model
{
    //
    protected $connection = 'game';

    public static function getList($condition = []){
        return self::where($condition)->select();
    }
}
