<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class StatMarketDay extends Model
{
    //
    protected $dateFormat = "Y-m-d";
    protected $type = [
        'create_time' => 'timestamp',
    ];

    /***
     *  修改Day
     * @param $val
     * @return false|string
     */
    public function getDayAttr($val){
        return date('Y-m-d',strtotime($val));
    }

    public function getFlow1Attr($value,$data){
        return round(1 - $data['stay1'],2);
    }

    public function getFlow3Attr($value,$data){
        return round( 1 - $data['stay3'],2);
    }

    public function getFlow7Attr($value,$data){
        return round( 1 - $data['stay7'],2);
    }

    public function getFlow14Attr($value,$data){
        return round( 1 - $data['stay14'],2);
    }

    public function getFlow30Attr($value,$data){
        return round( 1 - $data['stay30'],2);
    }


}
