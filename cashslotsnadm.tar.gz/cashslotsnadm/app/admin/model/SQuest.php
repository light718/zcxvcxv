<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class SQuest extends Model
{
    //
    protected $connection = 'game';
    const TYPE_COIN = 1;

    const TYPE_VIP_COUNT = 2;

    const TYPE_LEVEL_EXP = 3;
    const TYPE_LEVEL_REWARD = 4;
    const TYPE_TABLE = 5;
    const TYPE_ACTIVITY = 6;
    const TYPE_MISSION = 7;
    const TYPE_CARD = 8;
    const TYPE_ARR = [
        self::TYPE_COIN =>'金币',
        self::TYPE_VIP_COUNT =>'VIP点数',
        self::TYPE_LEVEL_EXP =>'双倍等级经验',
        self::TYPE_LEVEL_REWARD =>'双倍等级奖励',
        self::TYPE_TABLE =>' 在线转盘',
        self::TYPE_ACTIVITY =>'活跃值',
        self::TYPE_MISSION =>'mission star',
        self::TYPE_CARD => '英雄卡牌',
    ];

    public function getRewardsAttr($value){
        $rewards_str = '';
        $reward_arr = explode("|",$value);
        foreach ($reward_arr as $value){
            $rewards_val = explode(':',$value);
            if (isset($rewards_val[0]) && isset(self::TYPE_ARR[$rewards_val[0]])){
                $rewards_str .= "奖励 ".self::TYPE_ARR[$rewards_val[0]]." 数目 :".$rewards_val[1]." ";
            }
        }
        return $rewards_str;
    }
}
