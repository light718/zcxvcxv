<?php
declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

/**
 * @mixin \think\Model
 */
class TestAccount extends Model
{
    //
    protected $dateFormat = 'Y-m-d H:i:s';
    protected $autoWriteTimestamp = true;
    protected $createTime = 'create_time';
    protected $type = [
        'create_time' => 'timestamp',
    ];
}
