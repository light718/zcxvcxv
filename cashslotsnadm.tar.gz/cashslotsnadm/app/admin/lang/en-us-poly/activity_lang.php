<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['value_setting'] = 'Value Settings';

$lang['lucky_redbag'] = 'Share Angpow';
$lang['lucky_redbag_title'] = 'Lucky Angpow Value';
$lang['lucky_redbag_min'] = 'Min. value';
$lang['lucky_redbag_max'] = 'Max. value';
$lang['lucky_redbag_prob'] = 'Probability (%)';
$lang['lucky_redbag_add'] = 'Add new';
$lang['lucky_redbag_tips_01'] = 'Min. value must be smaller than max. value';
$lang['lucky_redbag_tips_02'] = 'The sum of probabilities must equal to 100';
$lang['lucky_redbag_tips_03'] = 'Parameters must be in numbers only';

$lang['rainy_redbag'] = 'Angpow Rain';
$lang['rainy_redbag_title'] = 'Angpow Rain Value';
$lang['rainy_redbag_min'] = 'Min. value';
$lang['rainy_redbag_max'] = 'Max. value';
$lang['rainy_redbag_prob'] = 'Probability (%)';
$lang['rainy_redbag_min_prob'] = 'Min. probability value (%)';
$lang['rainy_redbag_max_prob'] = 'Max. probability value (%)';
$lang['rainy_redbag_other_prob'] = 'Others probability value';
$lang['rainy_redbag_add'] = 'Add new';
$lang['rainy_redbag_tips_01'] = 'Min. value must be smaller than max. value';
$lang['rainy_redbag_tips_02'] = 'The sum of probabilities must equal to 100';
$lang['rainy_redbag_tips_03'] = 'Parameters must be in numbers';
$lang['rainy_redbag_tips_04'] = 'Sum of probabilities value must be equal to 100';

$lang['rainy_redbag_setting_title'] = 'Angpow Settings';
$lang['rainy_redbag_setting_send_time'] = 'Blasting Time';
$lang['rainy_redbag_setting_prob'] = 'Winning Probability';
$lang['rainy_redbag_setting_total'] = 'Total Amount';
$lang['rainy_redbag_setting_status'] = 'Status';
$lang['rainy_redbag_setting_status_01'] = 'In Progress';
$lang['rainy_redbag_setting_status_02'] = 'Terminated';
$lang['rainy_redbag_setting_status_03'] = 'Ended';
$lang['rainy_redbag_setting_create_time'] = 'Time Created';
$lang['rainy_redbag_setting_remark'] = 'Remarks';
$lang['rainy_redbag_setting_add_time'] = 'Time Extension';
$lang['rainy_redbag_setting_pool'] = 'Activity Pool Balance';
$lang['rainy_redbag_setting_record'] = 'Setting Logs';
$lang['rainy_redbag_setting_tips_01'] = 'Start time must be earlier than end time';
$lang['rainy_redbag_setting_tips_02'] = 'Winning probabilities must be between 0 to 100';
$lang['rainy_redbag_setting_tips_03'] = 'Angpow Rain is in progress';
$lang['rainy_redbag_setting_tips_04'] = 'Insufficient of balance in activity pool';

$lang['activity_jackpot_title'] = "Activity Pool top up";
$lang['activity_jackpot_add_value'] = "Top up value";
$lang['activity_jackpot_tips_01'] = "Insufficient fund in activity pool";

$lang['lucky_redbag_share_title'] = 'Number of Share';
$lang['lucky_redbag_share_nums'] = 'Number of Share';
$lang['lucky_redbag_redbag_nums'] = 'Angpow Quantity';

$lang['growth_value_setting_title'] = 'Value of Growth';
$lang['growth_value_setting_star'] = 'Quantity of Stars';
$lang['growth_value_setting_growth_value'] = 'Value of growth';
$lang['growth_value_setting_type'] = 'Rewards types';
$lang['growth_value_setting_type_1'] = 'Free Game';
$lang['growth_value_setting_type_2'] = 'Lucky Box';
$lang['growth_value_setting_free_game_id'] = 'Free Game ID';
$lang['growth_value_setting_free_game_nums'] = 'Number of Free Game';
$lang['growth_value_setting_free_game_desc'] = 'Free Game Descriptions';

$lang['lucky_box'] = 'Lucky Box';
$lang['lucky_box_setting_title'] = 'Lucky Box Value';
$lang['lucky_box_setting_coin'] = 'Points';
$lang['lucky_box_setting_prob'] = 'Winning Probability';
$lang['lucky_box_setting_tips_01'] = 'Sum of winning probabilities much be equal to 100';

$lang['setting_title'] = 'Activity Settings';
$lang['setting_lucky_redbag_switch'] = 'Lucky Box Switch';
$lang['setting_growth_value_ratio'] = 'Growth Value Ratio';
$lang['setting_growth_value_switch'] = 'Growth Value Switch';
$lang['setting_tip_01'] = 'Growth Value has not been set';
$lang['setting_tip_02'] = 'Growth Value Ratio has not been set';
$lang['setting_tip_03'] = 'Lucky Box Value has not been set';

$lang['stat_title'] = 'Statistics';
$lang['stat_lucky_redbag_share_nums'] = 'Number of Shared';
$lang['stat_lucky_redbag_user_nums'] = 'Number of Claimed';
$lang['stat_lucky_redbag_send_nums'] = 'Sent Quantity';
$lang['stat_lucky_redbag_total_coin'] = 'Sent Amount';
$lang['stat_rainy_redbag_send_nums'] = 'Number of Blast';
$lang['stat_rainy_redbag_user_nums'] = 'Number of Claimed';
$lang['stat_rainy_redbag_total_coin'] = 'Total Claimed Amount';
$lang['stat_lucky_box_user_nums'] = 'Number of Claimed';
$lang['stat_lucky_box_total_coin'] = 'Total Claimed Amount';