<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['report_title'] = 'Report';
$lang['report_title_tips'] = 'System administrator report';
$lang['report_sub_title_01'] = 'Game data summary';
$lang['report_sub_title_02'] = 'Big Player';
$lang['report_sub_title_03'] = 'Big Winner';
$lang['report_sub_title_04'] = 'Jackpot State';

$lang['report_condition_01'] = '1 hour data';
$lang['report_condition_02'] = '24 hours data';
$lang['report_condition_03'] = '7 days data';
$lang['report_condition_04'] = '30 days data';

$lang['report_column_game_name'] = 'Game Name';
$lang['report_column_au'] = 'AU';
$lang['report_column_bet_number'] = 'Bet Times';
$lang['report_column_bet'] = 'Bet';
$lang['report_column_win'] = 'Win';
$lang['report_column_system_win_rate'] = 'System win rate';
$lang['report_column_system_win_coin_rate'] = 'System won poin rate';
$lang['report_column_last_login_time'] = 'Last login';
$lang['report_column_value_never_login'] = 'Never logged';
$lang['report_column_btn_game_log'] = 'Game record';

$lang['report_pool_normal'] = 'Ordinary prize pool stock';
$lang['report_pool_jackpot'] = 'Grand prize pool stock';
$lang['report_pool_jackpot_baseline'] = 'Jackpot lottery line';
$lang['report_pool_tax'] = 'Pumping pool score';
$lang['report_pool_tax_baseline'] = 'System set pumping limit';

$lang['report_tips_01'] = 'The last 24 hours of ordinary prize pool inventory';
$lang['report_tips_02'] = 'Stock chart of stock changes in the last 24 hours of the regular prize pool, one data point in 5 minutes';
$lang['report_tips_03'] = 'The last 24 hours of the jackpot pool (Jackpot)';
$lang['report_tips_04'] = 'The stock change histogram of the last 24 hours of the Grand Prize Pool, one data point for 5 minutes.';
$lang['report_tips_05'] = 'The latest 24 hours of pumping conditions';
$lang['report_tips_06'] = 'The last 24 hours of the pumping pool score change histogram, 5 minutes a data point.';

$lang['report_tips_name_01'] = 'Ordinary prize pool stock';
$lang['report_tips_name_02'] = 'Grand prize pool stock';
$lang['report_tips_name_03'] = 'Pumping situation';
$lang['report_tips_name_04'] = 'Game inventory changes';
$lang['report_tips_name_05'] = 'Total number of game bets';

$lang['stocks'] = 'Total inventory';
$lang['all_online_num'] = 'Real-time online players';

$lang['startapp_all_userdata'] = '总启动次数';
$lang['startapp_new_userdata'] = '新用户启动次数';

$lang['payrate_gameid'] = 'GameID';
$lang['payrate_title'] = '游戏名';
$lang['payrate_bet'] = '总下注';
$lang['payrate_win'] = '总赢分';
$lang['payrate_val'] = '回报率';
$lang['payrate_day'] = '日期';
$lang['payrate_createtime'] = '创建时间';

$lang['payrate_ord'] = '排序';
$lang['payrate_uid'] = '账号';
$lang['payrate_wincoin'] = '输赢分';
