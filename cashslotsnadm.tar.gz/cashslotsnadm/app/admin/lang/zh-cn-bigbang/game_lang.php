<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = '游戏配置';
$lang['sub_title'] = '对游戏中的核心参数进行配置';
$lang['consume_coin'] = '系统抽水';
$lang['consume_coin_tips'] = '玩家每次下注时系统抽取的税收';
$lang['history_consume_coin'] = '历史抽水';
$lang['today_consume_coin'] = '今日抽水';
$lang['seven_day_consume_coin'] = '最近七日抽水';
$lang['month_consume_coin'] = '本月抽水';
$lang['history_add_coin'] = '历史上分';
$lang['history_sub_coin'] = '历史下分';
$lang['history_total_coin'] = '总上下分差';

$lang['consume_coin_title'] = '抽水设置';
$lang['consume_coin_sub_title'] = '玩家每次下注时系统抽取的税收的规则';
$lang['consume_coin_ratio'] = '抽水率';
$lang['consume_coin_ratio_tips'] = '玩家每次下注时抽取税收的比率，0.0 ~ 100.0';
$lang['consume_coin_max'] = '抽水上限';
$lang['consume_coin_max_tips'] = '当抽水达到抽水上限设定后，系统将会停止从玩家下注中抽取税收';
$lang['consume_coin_pospar'] = '桌游抽水率';
$lang['consume_coin_pospar_tips'] = '百家乐等按方位下注的游戏抽水方式采用每局结算后按系统赢钱金额的比例进行抽水。系统赢钱金额抽水率：0.0～100.0';
$lang['cur_consume_coin_ratio'] = '当前抽水率';
$lang['cur_consume_coin_max_setting'] = '当前抽水上限设定';
$lang['cur_consume_coin'] = '当前抽水';
$lang['cur_normal'] = '当前普通奖池';
$lang['btn_empty_normal'] = '清空';
$lang['empty_normal_tips'] = '确认清空么？';

$lang['reset_time_interval'] = '重置时间间隔';
$lang['reset_time_interval_tips01'] = '当抽水达到抽水上限设定后，系统将会停止从玩家下注中抽取税收';
$lang['reset_time_interval_tips02'] = '允许设置范围：60～43200分钟（1小时～30天）';
$lang['next_time_interval'] = '距离下一次重置';

$lang['jackpot_title'] = '大奖池（Jackpot）设置';
$lang['jackpot'] = '大奖池（Jackpot）';
$lang['jackpot_tips'] = '玩家赢的拉霸、捕鱼类游戏的大奖时，加开的大奖';
$lang['jackpot_setting'] = '开奖水位设定';
$lang['jackpot_setting_tips'] = '当大奖池的水位达到开奖水位设定时，大奖池才会开奖';
$lang['jackpot_limit_tips_01'] = '单次开奖的幅度设定，用户所得奖金占大奖池实际奖金的百分比范围';
$lang['jackpot_limit_tips_02'] = '下限超过上限时大奖池无法开奖，1.0～100.0';
$lang['jackpot_limit_max'] = '单次开奖上限';
$lang['jackpot_limit_min'] = '单次开奖下限';
$lang['jackpot_cur_pos'] = '当前奖池水位';
$lang['jackpot_btn_record'] = '历史开奖记录';
$lang['jackpot_base_tips'] = '显示基准值，自设定起，每个游戏界面中的大奖池分数将从这个值开始浮动';
$lang['jackpot_base'] = '显示基准值';
$lang['jackpot_change_tips_01'] = '大奖池分数显示值以每个游戏实际的下注为时机进行波动';
$lang['jackpot_change_tips_02'] = '每次下注行为将会向该游戏的大奖池增加以下设定分数';
$lang['jackpot_change'] = '波动额';
$lang['jackpot_decline_tips'] = '大奖池分数显示值每隔一段时间发生一次下降';
$lang['jackpot_decline_time_interval'] = '下降间隔时间';
$lang['jackpot_decline_ratio'] = '下降率';
$lang['jackpot_ratio'] = 'Jackpot比率';
$lang['jackpot_ratio_tips'] = '拉霸、捕鱼类游戏，玩家在下注时，除去系统抽水后，进入JP奖池的分数比率设置。如：玩家下注100分，抽水设置10%，Jackpot比率设置5%时：10分会被系统抽水，(100-10 = 90) * 5% = 4.5分会进入JP奖池，剩余的85.5分会进入普通奖池。0.0～100.0%';

$lang['packet'] = '救济红包设置';
$lang['packet_tips'] = '当用户分数花完返回大厅时发放给用户的救济红包';
$lang['packet_total_award'] = '累积已发放分数';
$lang['packet_status'] = '发放状态';
$lang['packet_status_tips'] = '单独改变发放状态，不会修改其他参数';
$lang['packet_status_open'] = '发放中';
$lang['packet_status_close'] = '不发放';
$lang['packet_max'] = '发放红包上限';
$lang['packet_min'] = '发放红包下限';
$lang['packet_limit_tips'] = '单个红包的上下限，下限超过上限时红包不会发放，1 ～ 100';
$lang['packet_condition_coin'] = '用户余额小于';
$lang['packet_condition_seven_coin'] = '7日分差 >=';
$lang['packet_condition_tips_01'] = '当用户符合以下条件时才有可能得到红包';
$lang['packet_condition_tips_02'] = '7日分差 = 单一用户最近7日的总上分-总下分';
$lang['packet_send_condition'] = '在用户余额小于';
$lang['packet_send_condition_tips'] = '时发放';
$lang['packet_seven_coin'] = '被发放用户7日上下分差超过';
$lang['packet_btn_record'] = '历史发放记录';
$lang['packet_btn_open'] = '开始发放';
$lang['packet_btn_close'] = '停止发放';

$lang['vip'] = 'VIP玩家设置';
$lang['vip_tips'] = '累积上分达到多少的玩家标记为VIP玩家';
$lang['vip_standard'] = '当前VIP认证标准';
$lang['vip_base_tips'] = '累积上分达到后，系统后台自动将其标记为VIP';
$lang['vip_base'] = '认证标准';

$lang['notice_01'] = '正数：系统赢钱 ； 负数：系统亏损';
$lang['notice_02'] = '当前抽水达到当前抽水上限设定后，系统将会停止从玩家下注中抽取税收';
$lang['notice_03'] = '重置时间到达后，当前抽水数值将会重置为【0.00】';
$lang['notice_04'] = '按下【设定】按钮后，当前正在进行的抽水将会被立即重置！';
$lang['notice_05'] = '符合上述条件的用户，当红包处于发放中状态时，每24小时最多可领取一个随机分数的救济红包';
$lang['notice_06'] = '按下【设定】按钮后，系统将会重置所有游戏的大奖池显示值，每个游戏都会根据上述设定计算出一个随机的初始值。每个游戏每次的波动额都是随机的。每个游戏每次发生奖池下降的时间间隔都是随机的，每次下降的下降幅度也都是随机的。';
$lang['notice_07'] = '按下【设定】按钮后，系统不会重置当前已经被标记为VIP的玩家，也不会将已经达成新标准的玩家自动标记为VIP。';
$lang['notice_08'] = '只有在玩家被上分时，他的VIP标记才会被重算。';

$lang['client_notice_title'] = '客户端公告';
$lang['client_notice_sub_title'] = '当你的直属玩家登录游戏时会看到的弹窗公告';
$lang['client_notice_tips'] = '公告内容';
$lang['client_notice_error'] = '公告内容不能超过100个字';

$lang['system_notice_title'] = '系统公告配置';
$lang['system_notice_sub_title'] = '各级代理上线后可以在welcome看到的公告';

// 跑马灯
$lang['marquee_title'] = '跑马灯配置';
$lang['marquee_title_tips'] = '配置游戏中的跑马灯公告';
$lang['marquee_btn_all'] = '所有公告';
$lang['marquee_btn_open'] = '生效中的公告';
$lang['marquee_btn_cancel'] = '取消的公告';
$lang['marquee_btn_add'] = '新增公告';
$lang['marquee_btn_detail'] = '详情';
$lang['marquee_column_add_time'] = '添加时间';
$lang['marquee_column_content'] = '公告文字';
$lang['marquee_column_open_time'] = '生效时间';
$lang['marquee_column_status'] = '生效状态';
$lang['marquee_column_hz'] = '公告频率';
$lang['marquee_status'] = '公告状态';
$lang['marquee_status_open'] = '生效中';
$lang['marquee_status_cancel'] = '已取消';
$lang['marquee_status_complete'] = '已完成';

$lang['marquee_add_title'] = '新增公告';
$lang['marquee_add_title_tips'] = '新增一个跑马灯公告';
$lang['marquee_add_start_time'] = '开始时间';
$lang['marquee_add_send_times'] = '发送次数';
$lang['marquee_add_send_times_unit'] = '次';
$lang['marquee_add_send_times_tips_01'] = '同样的公告可以仅在指定时间发送1次';
$lang['marquee_add_send_times_tips_02'] = '也可以从该时间开始多次重复发送相同的公告（1～99）';
$lang['marquee_add_send_space_time'] = '发送间隔';
$lang['marquee_add_send_space_time_unit'] = '分钟';
$lang['marquee_add_send_space_time_tips_01'] = '仅对发送次数超过1次公告有效，每隔几分钟重复发送1次';
$lang['marquee_add_send_space_time_tips_02'] = '发送间隔支持1～60分钟';
$lang['marquee_add_content'] = '公告内容';
$lang['marquee_add_content_tips'] = '公告内容最长200个字，所有的回车换行将被替换成空格';
$lang['marquee_add_notice_01'] = '公告一旦发送无法更改！无法更改！无法更改！';
$lang['marquee_add_notice_01'] = '还未发送的公告可以撤回，但无法保证撤回的及时性！';
$lang['marquee_status'] = '公告状态';
$lang['marquee_status_00'] = '等待中';
$lang['marquee_status_10'] = '生效中';
$lang['marquee_status_20'] = '已完成';
$lang['marquee_status_30'] = '已撤回';

$lang['marquee_detail_title'] = '公告详情';
$lang['marquee_detail_title_tips'] = '查看一个公告的具体配置，如果该公告仍然生效，可以撤回';
$lang['marquee_detail_notice'] = '公告撤回功能仅对还未发出的公告有效，比如一个公告已经发送了2次，还有3次未发送，撤回功能有机会可以终止剩下的3次的发送。';

// Poly大奖池（Poly Jackpot）
$lang['bigbang_title'] = 'Poly大奖池（Poly Jackpot）';
$lang['bigbang_title_tips'] = '作为系统活动开设的奖池';
$lang['bigbang_today_total_award'] = '今天累积开奖';
$lang['bigbang_seven_day_total_award'] = '最近7天累积开奖';
$lang['bigbang_three_month_total_award'] = '最近3个月累积开奖';
$lang['bigbang_column_time'] = '时间';
$lang['bigbang_jackpot_username'] = '账号';
$lang['bigbang_first_proxy_username'] = '一级代理ID';
$lang['bigbang_first_proxy_nickname'] = '一级代理昵称';
$lang['bigbang_award_coin'] = '分数';
$lang['bigbang_award_status'] = '开奖状态';
$lang['bigbang_award_status_waitting'] = '等待开奖';
$lang['bigbang_award_status_success'] = '已开奖';
$lang['bigbang_award_status_fail'] = '开奖失败';

$lang['bigbang_jackpot_title'] = 'Poly Jackpot 开奖';
$lang['bigbang_jackpot_open_username'] = '中奖账号';
$lang['bigbang_jackpot_seven_day_total_add_coin'] = '最近7日累积上分';
$lang['bigbang_jackpot_seven_day_total_sub_coin'] = '最近7日累积下分';
$lang['bigbang_jackpot_award_range'] = '允许开奖分数';
$lang['bigbang_jackpot_award'] = '开奖分数';
$lang['bigbang_jackpot_notice_01'] = '按下【开奖】按钮后，系统将会在1分钟内对该用户的在线状态进行确认，且玩家要在拉霸游戏中下注后，玩家才能获得奖励，否则开奖失败。';
$lang['bigbang_jackpot_notice_02'] = '确定开奖？';

$lang['bigbang_setting_title'] = 'Poly Jackpot 设置';
$lang['bigbang_setting_title_tips'] = 'Poly Jackpot的显示设置';
$lang['bigbang_setting_base_value'] = '显示基准值';
$lang['bigbang_setting_base_value_tips'] = '显示基准值，自设定起，大厅界面中的BBJP奖池分数将从这个值开始浮动';
$lang['bigbang_setting_change_value'] = '波动额';
$lang['bigbang_setting_change_value_tips_01'] = '显示基准值，自设定起，大厅界面中的BBJP奖池分数将从这个值开始浮动';
$lang['bigbang_setting_decline_time_interval'] = '下降间隔时间';
$lang['bigbang_setting_decline_ratio'] = '下降率';
$lang['bigbang_setting_decline_tips'] = 'BBJP奖池分数显示值每隔一段时间发生一次下降';
$lang['bigbang_setting_notice'] = '按下【设定】按钮后，系统将会重置BBJP奖池显示值。每次的波动额都是随机的。次发生奖池下降的时间间隔都是随机的，每次下降的下降幅度也都是随机的。';

$lang['return_error_01'] = '抽水率取值范围0.0 ~ 100.0';
$lang['return_error_02'] = '重置时间间隔取值范围60 ~ 43200分钟';
$lang['return_error_03'] = '单次开奖上限取值范围1.0 ~ 100.0';
$lang['return_error_04'] = '单次开奖下限取值范围1.0 ~ 100.0';
$lang['return_error_05'] = '发放红包上限取值范围1 ~ 100';
$lang['return_error_06'] = '发放红包下限取值范围1 ~ 100';
$lang['return_error_07'] = '发送次数填写错误';
$lang['return_error_08'] = '时间间隔填写错误';
$lang['return_error_09'] = '公告内容填写错误';
$lang['return_error_10'] = '用户余额小于取值范围0.00 ~ 5.00';
$lang['return_error_11'] = '7日分差取值不能小于5';
$lang['return_error_12'] = '方位游戏抽水率取值范围0.0 ~ 100.0';
$lang['return_error_13'] = '抽水上限取值范围1.00 ~ 999,999,999,999.99';
$lang['return_error_14'] = '开奖水位设定取值范围10,000.00 ~ 999,999,999,999.99';
$lang['return_error_15'] = '抽水上限取值范围1.00 ~ 999,999,999,999.99';
$lang['return_error_16'] = 'Jackpot比率取值范围0.0 ~ 100.0%';
$lang['return_error_17'] = '显示基准值取值范围1,000.00 ~ 999,999,999,999.99';
$lang['return_error_18'] = '波动额取值范围-100.00 ~ 100.00';
$lang['return_error_19'] = '下降间隔时间取值范围3 ~ 1440';
$lang['return_error_20'] = '下降率取值范围1.0 ~ 65.0%';
$lang['return_error_21'] = '认证标准取值范围100.00 ~ 999,999,999.99';
$lang['return_error_22'] = '方位游戏抽水率取值范围0.0 ~ 100.0';
$lang['return_error_23'] = '开奖分数取值范围10.00 ~ 10,000.00';
$lang['return_error_24'] = '红包上限值必须大于下限值';

$lang['game_switch_title'] = '游戏开关';
$lang['game_switch_status_normal'] = '正常';
$lang['game_switch_status_off'] = '游戏维护中';
$lang['game_switch_uid_whitelist'] = 'UID白名单';
$lang['game_switch_content'] = '停服公告';
$lang['game_switch_tips'] = '以英文逗号分隔uid';
$lang['game_switch_tips_01'] = '确认开服？';
$lang['game_switch_tips_02'] = '确认停服？';

$lang['game_status'] = '小游戏开关';
$lang['game_status_column_id'] = '游戏ID';
$lang['game_status_column_name'] = '游戏名称';
$lang['game_status_column_status'] = '当前状态';
$lang['game_status_normal'] = '正常';
$lang['game_status_close'] = '维护中';
$lang['game_status_btn_open'] = '开启游戏';
$lang['game_status_btn_close'] = '关闭游戏';
$lang['game_status_tips_01'] = '确认开启该游戏？';
$lang['game_status_tips_02'] = '确认关闭该游戏？';

$lang['server_list'] = '服务器列表';
$lang['server_list_type'] = '类型';
$lang['server_list_name'] = '名称';
$lang['server_list_status'] = '状态';
$lang['server_list_status_start'] = 'start';
$lang['server_list_status_run'] = 'run';
$lang['server_list_status_full'] = 'full';
$lang['server_list_status_weihu'] = 'weihu';
$lang['server_list_status_stop'] = 'stop';
$lang['server_list_btn_close_server'] = '关服';
$lang['server_list_tips_01'] = '确认关闭当前服务器？';

$lang['game_switch_total_online'] = '总在线人数';

$lang['major'] = '争霸彩';
$lang['major_setting'] = '争霸彩设置';
$lang['minor'] = '双龙彩';
$lang['minor_setting'] = '双龙彩设置';
$lang['major_base_value'] = '显示基准值';
$lang['major_decline_rate'] = '下降率';
$lang['major_falling_interval'] = '下降间隔时间';
$lang['major_fluctuation'] = '波动额';
