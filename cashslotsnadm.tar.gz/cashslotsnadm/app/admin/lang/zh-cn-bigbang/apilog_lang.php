<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['agent_management'] = '代理管理';
$lang[md5('功能授权成功')] = '功能授权成功';
$lang[md5('功能删除成功')] = '功能删除成功';
$lang[md5('账号管理')] = '账号管理';
$lang['game_setting'] = '游戏配置';
