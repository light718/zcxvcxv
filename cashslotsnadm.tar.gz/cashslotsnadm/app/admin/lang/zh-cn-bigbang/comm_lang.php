<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['site_title'] = 'Poly管理后台';
$lang['site_title_root_agent'] = 'Poly管理后台';
$lang['site_title_general_agent'] = 'Poly代理后台';

$lang['menu'] = '菜单';
$lang['btn_refresh'] = '刷新';
$lang['btn_back'] = '返回';
$lang['btn_search'] = '查询';
$lang['btn_handle'] = '操作';
$lang['btn_close'] = '关闭';
$lang['btn_cancel'] = '取消';
$lang['btn_add'] = '新增';
$lang['btn_coin_search'] = '查账';
$lang['btn_coin_change'] = '上下分';
$lang['btn_coin_change_record'] = '上下分记录';
$lang['btn_edit'] = '编辑';
$lang['btn_status_disable'] = '禁用';
$lang['btn_status_enable'] = '启用';
$lang['btn_add_coin'] = '上分';
$lang['btn_sub_coin'] = '下分';
$lang['btn_setting'] = '设置';
$lang['btn_setting_02'] = '设定';
$lang['btn_logout'] = '退出';
$lang['btn_detail'] = '明细';
$lang['btn_rollback'] = '撤回';
$lang['btn_lottery'] = '开奖';
$lang['btn_change_pwd'] = '密码修改';
$lang['btn_confirm'] = '确认';
$lang['btn_sure'] = '确定';
$lang['btn_save'] = '保存';
$lang['btn_copy'] = '复制';
$lang['copy_success'] = '复制成功';

$lang['start_date'] = '开始日期';
$lang['end_date'] = '结束日期';
$lang['date'] = '日期';
$lang['time'] = '时间';

$lang['search_start_date'] = '开始日';
$lang['search_end_date'] = '结束日（含）';
$lang['search_start_time'] = '开始时间';
$lang['search_end_time'] = '结束时间';
$lang['search_today'] = '今天';
$lang['search_yesterday'] = '昨天';
$lang['search_recent_seven_day'] = '最近7天';
$lang['search_week'] = '本周';
$lang['search_month'] = '本月';
$lang['search_pre_week'] = '上周';
$lang['search_range'] = '筛选分数变化范围';
$lang['search_placeholder_username_nickname'] = 'ID/昵称';
$lang['search_placeholder_username_nickname_player'] = '账号/昵称';
$lang['search_placeholder_username_nickname_agent'] = '代理ID/昵称';
$lang['total_coin'] = '总输赢';

$lang['return_success'] = '操作成功';
$lang['return_fail'] = '操作失败';
$lang['return_up_coin_lack'] = '上分失败。额度不足';
$lang['return_down_coin_lack'] = '下分失败。额度不足';
$lang['return_password_not_same'] = '两次密码不一致';
$lang['return_empty'] = '请输入完整的信息';

$lang['username'] = '账号';
$lang['password'] = '密码';
$lang['nickname'] = '昵称';
$lang['old_password'] = '原始密码';
$lang['new_password'] = '新密码';
$lang['player_uid'] = '玩家ID';
$lang['player_username'] = '账号';
$lang['player_username_01'] = '玩家账号';
$lang['player_nickname'] = '玩家昵称';
$lang['player_status'] = '玩家状态';
$lang['player_status_online'] = '在线';
$lang['player_status_offline'] = '离线';
$lang['player_coin'] = '玩家分数';
$lang['game_name'] = '游戏名称';

$lang['proxy_username'] = '代理ID';
$lang['proxy_nickname'] = '代理昵称';
$lang['direct_agent'] = '直属代理';
$lang['packet_btn_open'] = '开始发放';


$lang['table_column_search'] = '查询';
$lang['table_column_handle'] = '操作';
$lang['table_column_date'] = '日期';
$lang['table_column_time'] = '时间';
$lang['table_column_bet'] = '注金';
$lang['table_column_room_id'] = '房间号';
$lang['table_column_username'] = '账号';
$lang['table_column_nickname'] = '昵称';
$lang['table_column_win_coin'] = '输赢';
$lang['table_column_child_win_coin'] = '下级输赢';
$lang['table_column_total_win_coin'] = '总输赢';
$lang['table_column_bigbang'] = 'Poly';

$lang['minute'] = '分钟';
$lang['second'] = '秒';
$lang['times'] = '次';

$lang['menu_home'] = '首页';
$lang['menu_subaccount'] = '子账号管理';
$lang['menu_account'] = '代理管理';
$lang['menu_agent_total_report'] = '代理总账';
$lang['menu_player_total_report'] = '玩家总账';
$lang['menu_user'] = '玩家管理';
$lang['menu_client_notice'] = '客户端公告';
$lang['menu_general_agent_report'] = '总代报表';
$lang['menu_game'] = '游戏配置';
$lang['menu_prob'] = '概率控制';
$lang['menu_userredpacket'] = '系统红包';
$lang['menu_marquee'] = '跑马灯配置';
$lang['menu_level_search'] = '分级查询';
$lang['menu_report'] = '报表';
$lang['menu_system_notice'] = '系统公告配置';
$lang['menu_bigbang'] = 'Poly';
$lang['menu_game_prob'] = '游戏概率';
$lang['menu_game_switch'] = '游戏开关';
$lang['menu_game_status'] = '小游戏开关';
$lang['menu_system_search'] = '系统查询';
$lang['menu_player_login_log'] = '玩家登录日志';
$lang['menu_player_game_log'] = '玩家游戏记录';
$lang['menu_player_list'] = '玩家列表';
$lang['menu_player_detail_list'] = '玩家明细列表';
$lang['menu_agent_list'] = '代理列表';
$lang['menu_agent_score_log'] = '代理上下分记录';
$lang['menu_system_win'] = '系统输赢';
$lang['menu_stat_report'] = '统计报表';
$lang['menu_report'] = '报表';
$lang['menu_bet_nums'] = '下注次数';
$lang['menu_mainpool'] = '库存变化';
$lang['menu_selfmainpool'] = '游戏服子库存';
$lang['menu_online'] = '在线统计';
$lang['menu_player_ip'] = '查询玩家IP';
$lang['menu_player_win'] = '玩家输赢';
$lang['menu_operation_log'] = '操作日志';
$lang['menu_server_list'] = '服务器列表';
$lang['menu_tax_empty_log'] = '税池清空列表';
$lang['menu_bigbang_list'] = 'Bigbang查询';
$lang['menu_check_accounts'] = '查账';
$lang['menu_search_account'] = '搜索账号';
$lang['menu_system_setting'] = '系统设置';
$lang['menu_promote'] = '推广员分佣设置';
$lang['menu_transfer'] = '转账记录';

$lang['input'] = '请输入';
$lang['chinese'] = '中文';
$lang['english'] = 'English';
$lang['no_data'] = '暂无相关数据';

$lang['bet'] = '下注';
$lang['win'] = '中奖';
$lang['select_game'] = '请选择游戏';
$lang['tips'] = '提示';

$lang['refresh_list'] = '刷新列表';

$lang['error_msg_account_reached_maxnum'] = "账号个数已达到上限";
$lang['error_msg_account_repeat'] = "ID已存在";
$lang['error_msg_marquee_add'] = "开始时间必须大于当前时间";

$lang['title'] = '欢迎';
$lang['my_coin'] = '我的分数';
$lang['today_proxy_total_add_coin'] = '今日代理总上分';
$lang['today_proxy_total_add_coin_tips'] = '今日直属代理的上分合计';
$lang['today_player_total_add_coin'] = '今日玩家总上分';
$lang['today_player_total_add_coin_tips'] = '今日全系统所有玩家的上分合计';
$lang['today_player_total_sub_coin'] = '今日玩家总下分';
$lang['today_player_total_sub_coin_tips'] = '今日全系统所有玩家的下分合计';
$lang['today_total_sub_coin'] = '今日总抽水';
$lang['today_total_sub_coin_tips'] = '今日全系统的抽水合计';
$lang['today_total_win_coin'] = '今日总输赢';
$lang['today_total_win_coin_tips'] = '今日全系统的输赢合计';
$lang['yesterday'] = '昨日';
$lang['change_pwd'] = '密码修改';
$lang['confirm_pwd'] = '确认密码';
$lang['logout_tips'] = '确定退出么？';
$lang['logout_title'] = '&nbsp;';
$lang['sub_title_01'] = '最近24小时在线';
$lang['sub_title_01_tips_01'] = '在线人数';
$lang['sub_title_02'] = '最近24小时玩家分数存量';
$lang['sub_title_02_tips_01'] = '玩家分数';

$lang['game_tag'] = '标签';
$lang['game_tag_0'] = '普通';
$lang['game_tag_1'] = '最热';
$lang['game_tag_2'] = '最新';
$lang['batch_tag'] = '批量打标签';
$lang['select'] = '请选择操作';
$lang['red_envelope'] = '救济红包';

$lang['add_account_tips_01'] = '代理ID字数限制为 3 - 12 个字母或数字，不限大小字';
$lang['add_account_tips_02'] = '密码限制为 4 - 12 个字母和数字，不限大小字';
$lang['add_account_tips_03'] = '名字限制为 4 - 12 个字母和数字，不限大小字';

$lang['search_account_tips'] = '请输入代理ID或玩家账号';
$lang['agent'] = '代理';
$lang['input_username'] = '请输入账号';

# 地区配置
$lang['region_hongkong'] = '香港';
$lang['region_indonesia'] = '印度尼西亚';
$lang['region_malaysia'] = '马来西亚';
$lang['region_myanmar'] = '缅甸';
$lang['region_thailand'] = '泰国';
$lang['region_vietnam'] = '越南';