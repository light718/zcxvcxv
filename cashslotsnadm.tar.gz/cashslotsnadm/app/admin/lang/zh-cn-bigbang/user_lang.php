<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = '玩家管理';
$lang['sub_title'] = '你的直属玩家';
$lang['search'] = '查询';
$lang['add_user'] = '添加玩家';
$lang['action_coin_search'] = '查账';
$lang['action_coin_log'] = '上下分记录';
$lang['action_game_log'] = '游戏记录';
$lang['action_copy_login_info'] = '复制快速登录信息';
$lang['action_edit'] = '编辑';
$lang['action_status_forbidden'] = '禁/踢';
$lang['action_change_coin'] = '上下分';
$lang['action_status_normal'] = '启用';
$lang['column_username'] = 'ID';
$lang['column_nickname'] = '昵称';
$lang['column_coin'] = '分数余额';
$lang['column_last_login'] = '上次登录';
$lang['column_search'] = '查询';
$lang['column_handle'] = '操作';
$lang['user_list'] = '玩家列表';

// 新增玩家
$lang['add_title'] = '新增玩家';
$lang['add_sub_title'] = '新增一个或多个你的直属玩家';
$lang['user_number'] = '新增玩家数量';
$lang['username'] = '账号';
$lang['password'] = '密码';
$lang['nickname'] = '昵称';
$lang['user_number_tips01'] = '输入本次要新增的玩家数量，单次最多新增20名玩家';
$lang['user_number_tips02'] = '每位代理最多可管理5,000名玩家';
$lang['password_tips'] = '玩家初次登录游戏时会要求玩家修改密码';
$lang['nickname_tips01'] = '只有你能看到的昵称，玩家自己不会看到这个设定';
$lang['nickname_tips02'] = '为了区分你不同批次生成的玩家，请一定要设定昵称';
$lang['add_notice01'] = '玩家一旦创建，无法删除，但是可以禁用';
$lang['add_notice02'] = '注意！';
$lang['add_notice03'] = '玩家的账号为系统自动生成的12位数字';
$lang['add_notice04'] = '玩家登录游戏时，ID中间的[-]符号不影响登录';
$lang['add_notice05'] = '你可以协助直属玩家重新设定他的密码';
$lang['add_notice06'] = '你可以随时修改直属玩家的昵称';
$lang['add_success'] = '成功新增玩家';
$lang['add_success_message'] = 'Your account is ready!<br>Access https://xxx.xxxxxxxxx.xxx/xxxx by a Browser such as Chrom, IE etc. to manage your Players.<br>User name: {%username%}<br>Password: {%password%}';
$lang['add_success_notice'] = '上面的ID为系统自动生成，并已经按照你的输入为他们设定了昵称';
$lang['add_btn_save'] = '新增';
$lang['add_btn_close'] = '关闭';
$lang['add_empty'] = '请输入完整的信息';
$lang['add_number_error_max'] = '单次最多新增20名玩家';
$lang['add_number_error_max_all'] = '最多添加5,000名玩家';

// 编辑玩家
$lang['edit_title'] = '编辑玩家';

// 上下分记录
$lang['coin_record_title'] = '上下分记录';
$lang['coin_record_username'] = '账号';
$lang['coin_record_nickname'] = '玩家昵称';
$lang['coin_record_user_status'] = '玩家状态';
$lang['coin_record_status_online'] = '在线';
$lang['coin_record_status_offline'] = '离线';
$lang['coin_record_coin'] = '玩家分数';
$lang['coin_record_start_time'] = '开始日';
$lang['coin_record_end_time'] = '结束日（含）';
$lang['coin_record_today'] = '今天';
$lang['coin_record_yesterday'] = '昨天';
$lang['coin_record_week'] = '最近7天';
$lang['coin_record_month'] = '本月';
$lang['coin_record_search'] = '查询';
$lang['coin_record_close'] = '关闭';
$lang['coin_record_total_coin'] = '总上下分差';
$lang['coin_record_column_time'] = '时间';
$lang['coin_record_column_change_coin'] = '上下分';
$lang['coin_record_column_before_coin'] = '上分前';
$lang['coin_record_column_after_coin'] = '上分后';

// 上下分
$lang['change_coin_title'] = '上下分';
$lang['add_coin'] = '上分';
$lang['sub_coin'] = '下分';
$lang['recent_record'] = '最近10条上下分记录';
$lang['off_line'] = '踢下线10秒';
$lang['off_line_error'] = '正在游戏里 不能扣分.';

// 禁用玩家
$lang['status_title'] = '禁用玩家';
$lang['status_notice01'] = '玩家将回到登录界面，并在10秒内无法登录';
$lang['status_notice02'] = '玩家将回到登录界面，在解除禁用前无法登录';
$lang['status_notice03'] = '解除玩家禁用状态';
$lang['status_btn_offline'] = '踢下线10秒';
$lang['status_btn_forbidden'] = '禁用并踢下线';
$lang['status_btn_normal'] = '解除禁用';
$lang['status_btn_cancel'] = '取消';

// 复制快速登录信息
$lang['copy_title'] = '复制快速登录信息';
$lang['copy_notice01'] = '玩家快速登录信息';
$lang['copy_notice02'] = '【Fastpass for Poly】Your Username is {%username%}.';
$lang['copy_notice03'] = '将上述信息和密码分别发给玩家，帮助玩家快速登录游戏。';

// 游戏记录
$lang['game_log_title'] = '游戏记录';
$lang['game_log_column_date_time'] = '日期时间';
$lang['game_log_column_table_id'] = '桌子ID';
$lang['game_log_column_bet'] = '押注';
$lang['game_log_column_win'] = '赢钱';
$lang['game_log_column_change'] = '变动金额';
$lang['game_log_column_before'] = '开始金额';
$lang['game_log_column_after'] = '结束金额';
$lang['game_log_column_game_name'] = '游戏名称';
$lang['game_log_column_note'] = '备注';
$lang['game_log_free_game'] = '自由转';
$lang['game_log_double_loss'] = '猜大小=输';
$lang['game_log_double_win'] = '猜大小=赢';
$lang['game_log_bonus_game'] = 'BONUS GAME';
$lang['game_log_detail'] = '游戏详情';

$lang['user_not_exist'] = 'ID不存在';

$lang['btn_disable_all_player'] = '禁用所有玩家';
$lang['btn_enable_all_player'] = '解禁所有玩家';
$lang['disable_all_player_tips'] = '确认禁用所有玩家？';
$lang['enable_all_player_tips'] = '确认解禁所有玩家？';
$lang['comfirm_off_line'] = '确认将玩家踢下线60秒？';
$lang['comfirm_forbidden'] = '确认禁用玩家？';
$lang['comfirm_offline'] = '确认解禁玩家？';

$lang['player_total_report'] = '玩家总账';
$lang['red_envelope_setting'] = '送免费分设置';
$lang['red_envelope_setting_tips01'] = '在开启此功能情况下，创建新账号时给账号发放一个红包，新账号在登录后自动弹出领取';
$lang['red_envelope_setting_tips02'] = '您已开启红包活动，将从您的分数中扣除红包的分数';
$lang['red_envelope_setting_switch'] = '开关';
$lang['red_envelope_setting_range'] = '红包范围';

$lang['red_packet_setting'] = '总代红包设置';
$lang['red_packet_setting_tips01'] = '所有在游戏内的玩家(不包括真人视讯)都会收到一次指定金额的红包';
$lang['red_packet_setting_tips02'] = '提交设定时，会立即发送';
$lang['red_packet_setting_tips03'] = '接收红包的账号，用英文逗号隔开。如果不填写，默认所有在游戏内(不包括真人视讯)的玩家都会收到红包。';
$lang['red_packet_account'] = '接收账号';


$lang['red_envelope_record'] = '红包记录';
$lang['red_envelope_record_coin'] = '发放分数';
$lang['red_envelope_record_time'] = '发放时间';
$lang['red_envelope_num'] = '红包';

$lang['profit'] = '收益';
$lang['register_time'] = '注册时间';
$lang['divide_record'] = '分成记录';
$lang['tree_depth'] = '层级';
$lang['total_flows'] = '玩家总流水';
$lang['flows'] = '总流水';