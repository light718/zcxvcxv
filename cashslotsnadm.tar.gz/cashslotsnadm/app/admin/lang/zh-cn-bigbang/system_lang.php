<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['player_login_log_title'] = '玩家登录日志';
$lang['player_login_log_uid'] = 'UID';
$lang['player_login_log_pid'] = '玩家ID';
$lang['player_login_log_time'] = '登录时间';

$lang['agent_list_title'] = '代理列表';
$lang['agent_list_column_username'] = '代理ID';
$lang['agent_list_column_nickname'] = '昵称';
$lang['agent_list_column_parent_agent'] = '上级代理ID';
$lang['agent_list_column_first_agent'] = '一级代理ID';
$lang['agent_list_column_coin'] = '分数余额';
$lang['agent_list_column_create_time'] = '注册时间';
$lang['agent_list_column_last_login_time'] = '最后登录时间';

$lang['agent_score_log_title'] = '代理上下分记录';
$lang['agent_score_log_column_username'] = '代理ID';
$lang['agent_score_log_column_nickname'] = '昵称';
$lang['agent_score_log_column_coin'] = '上下分';
$lang['agent_score_log_column_before'] = '上分前';
$lang['agent_score_log_column_after'] = '上分后';
$lang['agent_score_log_column_create_time'] = '时间';

$lang['player_game_log_title'] = '玩家游戏记录';
$lang['player_game_log_game_name'] = '游戏名字(Game)';
$lang['player_game_log_type'] = '下注or中奖';
$lang['player_game_log_coin'] = '金币变化';
$lang['player_game_log_coin_before'] = '变化前金币';
$lang['player_game_log_coin_after'] = '变化后金币';
$lang['player_game_log_time'] = '时间';

$lang['system_win_title'] = '系统输赢';
$lang['system_win_date'] = '日期';
$lang['system_win_sysout'] = '系统上分';
$lang['system_win_sysin'] = '系统下分';
$lang['system_win_player'] = '玩家总分数';
$lang['system_win_agent'] = '代理总分数';

$lang['player_ip_title'] = '玩家登入IP查询';
$lang['player_ip_tips'] = '显示最新10条记录';

$lang['player_win_column_id'] = '玩家ID';
$lang['player_win_column_name'] = '账号';
$lang['player_win_nickname'] = '昵称';
$lang['player_win_total'] = '总输赢';
$lang['player_win_reload'] = '总上分';
$lang['player_win_ratio'] = '输赢比例';
$lang['player_win_select_all'] = '全部玩家';
$lang['player_win_select_control'] = '控制过的玩家';
$lang['player_win_select_not_control'] = '未控制过的玩家';

$lang['player_list_title'] = '玩家列表';
$lang['player_list_column_id'] = 'UID';
$lang['player_list_column_pid'] = '玩家ID';
$lang['player_list_column_nickname'] = '昵称';
$lang['player_list_column_coin'] = '分数';
$lang['player_list_column_online'] = '在线状态';
$lang['player_list_column_status_ban'] = '账号状态';
$lang['player_list_column_create_time'] = '添加时间';
$lang['player_list_column_last_login_time'] = '最后登录时间';

$lang['operation_log_title'] = '操作日志';
$lang['operation_log_column_id'] = '#';
$lang['operation_log_column_admin_id'] = 'ID';
$lang['operation_log_column_admin_username'] = '账号';
$lang['operation_log_column_ip'] = '操作IP';
$lang['operation_log_column_os'] = '操作系统';
$lang['operation_log_column_browser'] = '浏览器';
$lang['operation_log_column_menu'] = '动作类型';
$lang['operation_log_column_detail'] = '详情';
$lang['operation_log_column_create_time'] = '操作时间';

$lang['red_envelope'] = '救济红包';

$lang['tax_empty_title'] = '税池清空日志';
$lang['tax_empty_column_id'] = 'ID';
$lang['tax_empty_column_oin'] = '分数';
$lang['tax_empty_column_create_time'] = '清空时间';

$lang['promote_setting'] = '推广员分佣设置';
$lang['promote_switch'] = '开关';
$lang['promote_ratio'] = '佣金返比';
$lang['promote_level_ratio'] = '各层级返比';

$lang['transfer_from_pid'] = '转出账号';
$lang['transfer_to_pid'] = '转入账号';
$lang['transfer_coin'] = '转出分数';
$lang['transfer_time'] = '转账时间';