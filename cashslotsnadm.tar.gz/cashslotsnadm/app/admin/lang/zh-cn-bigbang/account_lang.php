<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = '代理管理';
$lang['sub_title'] = '你的直属代理';
$lang['btn_add_account'] = '添加代理';
$lang['agent_list'] = '代理列表';
$lang['parent_agent'] = '上级代理';
$lang['subaccount_list'] = '子帐号列表';

$lang['table_column_username'] = '代理ID';
$lang['table_column_nickname'] = '昵称';
$lang['table_column_coin'] = '分数余额';
$lang['table_column_time'] = '时间';
$lang['table_column_coin_change'] = '上下分';
$lang['table_column_coin_change_before'] = '上分前';
$lang['table_column_coin_change_after'] = '上分后';
$lang['table_column_permission'] = '权限';
$lang['table_column_last_login'] = '上次登录';


// 新增代理
$lang['add_title'] = '新增代理';
$lang['add_sub_title'] = '新增一个你的直属代理';
$lang['username'] = '代理ID';
$lang['password'] = '密码';
$lang['nickname'] = '昵称';
$lang['upcoin'] = '上分';
$lang['username_tips'] = '下级代理商用于登录本后台的代理ID，无法修改';
$lang['password_tips'] = '下级代理商用于登录本后台的密码，他自己可以修改';
$lang['nickname_tips'] = '只有你能看到的昵称，下级代理自己不会看到这个设定';
$lang['upcoin_tips'] = '直接给下级代理商上分';
$lang['add_notice01'] = '代理商一旦创建，无法删除，但是可以禁用';
$lang['add_notice02'] = '注意！';
$lang['add_notice03'] = '代理ID无法修改！！';
$lang['add_notice04'] = '你可以协助下级代理重新设定他的密码';
$lang['add_notice05'] = '你可以随时修改下级代理的昵称';
$lang['add_success'] = '成功新增代理';
$lang['add_success_message'] = '代理账号 {%username%} 已创建！<br>可通过浏览器访问 {%url%}。<br>用户名：{%username%}<br>密码：{%password%}';
$lang['add_success_notice'] = '将上面的文字贴给你的代理，邀请他们登录后台立即开始一起赚钱吧';
$lang['add_btn_save'] = '新增';
$lang['add_btn_close'] = '关闭';
$lang['add_empty'] = '请输入完整的信息';
$lang['username_empty'] = '账号必须填写';
$lang['password_empty'] = '密码必须填写';
$lang['nickname_empty'] = '名字必须填写';

// 编辑代理
$lang['edit_title'] = '编辑代理';

// 上下分记录
$lang['coin_record_title'] = '上下分记录';
$lang['coin_record_username'] = '代理ID';
$lang['coin_record_nickname'] = '代理昵称';
$lang['coin_record_total_coin'] = '总上下分差';
$lang['coin_record_column_time'] = '时间';
$lang['coin_record_column_change_coin'] = '上下分';
$lang['coin_record_column_before_coin'] = '上分前';
$lang['coin_record_column_after_coin'] = '上分后';

// 上下分
$lang['change_coin_title'] = '上下分';
$lang['add_coin'] = '上分';
$lang['sub_coin'] = '下分';
$lang['recent_record'] = '最近10条上下分记录';

// 禁用代理
$lang['status_title'] = '禁用代理';
$lang['status_notice01'] = '禁用代理将会';
$lang['status_notice02'] = '禁用代理及其所有子账号，并踢下线';
$lang['status_notice03'] = '禁用代理其下所有玩家，并踢下线';
$lang['status_notice04'] = '禁用代理其下的所有下级代理';
$lang['status_notice05'] = '解除代理禁用状态';
$lang['status_btn_forbidden'] = '禁用并踢下线';
$lang['status_btn_normal'] = '解除禁用';

// 子账号管理
$lang['subaccount_title'] = '子账号管理';
$lang['subaccount_title_tips'] = '协助你进行日常管理工作的账号';
$lang['subaccount_btn_add'] = '添加子账号';
$lang['subaccount_btn_edit'] = '编辑子账号';
$lang['subaccount_tips_01'] = '子账号ID只能使用英文字母和数字 5～30位';
$lang['subaccount_tips_011'] = '密码只能使用英文字母和数字 5～30位';
$lang['subaccount_tips_02'] = '使用子账号ID登录时不区分大小写';
$lang['subaccount_tips_03'] = '用于登录本后台的密码，他自己可以修改';
$lang['subaccount_tips_04'] = '昵称仅对你可见，用户自身无法看到自己的昵称';
$lang['subaccount_tips_05'] = '权限（可多选）';
$lang['subaccount_tips_06'] = '子账号将回到登录界面，在解除禁用前无法登录';
$lang['subaccount_tips_07'] = '解除子账号禁用状态';
$lang['subaccount_permission_5_title'] = '财务';
$lang['subaccount_permission_5_desc'] = '查询直属代理信息及查账';
$lang['subaccount_permission_6_title'] = '代理管理';
$lang['subaccount_permission_6_desc'] = '可添加、管理直属代理';
$lang['subaccount_permission_7_title'] = '点控';
$lang['subaccount_permission_7_desc'] = '可查询玩家信息及控制概率';
$lang['subaccount_permission_8_title'] = '代理查询';
$lang['subaccount_permission_8_desc'] = '查询直属代理信息及查账';
$lang['subaccount_permission_9_title'] = '代理管理';
$lang['subaccount_permission_9_desc'] = '可添加、管理直属代理';
$lang['subaccount_permission_10_title'] = '玩家查询';
$lang['subaccount_permission_10_desc'] = '查询直属玩家信息及查账';
$lang['subaccount_permission_11_title'] = '玩家管理';
$lang['subaccount_permission_11_desc'] = '可添加、管理直属玩家';
$lang['subaccount_username'] = '子帐号ID';
$lang['subaccount_nickname'] = '子账号昵称';

// 总代报表
$lang['general_agent_report_title'] = '总代报表';
$lang['general_agent_report_title_tips'] = '结算报表';
$lang['general_agent_report_total_add_coin'] = '总上分';
$lang['general_agent_report_total_sub_coin'] = '总下分';
$lang['general_agent_report_total_diff_coin'] = '上下分差';
$lang['table_column_agent_total_add_coin'] = '代理总上分';
$lang['table_column_agent_total_sub_coin'] = '代理总下分';
$lang['table_column_player_total_add_coin'] = '玩家总上分';
$lang['table_column_player_total_sub_coin'] = '玩家总下分';
$lang['table_column_bigbang'] = 'Bigbang';

// 分级查询
$lang['level_search_title'] = '分级查询';
$lang['level_search_title_tips'] = '各个级别的代理的活跃状况查询';
$lang['level_search_btn_condition_01'] = '1小时数据';
$lang['level_search_btn_condition_02'] = '24小时数据';
$lang['level_search_btn_condition_03'] = '7天数据';
$lang['level_search_btn_condition_04'] = '30天数据';
$lang['table_column_au'] = 'AU';
$lang['table_column_bets'] = '注金';
$lang['level_search_btn_parent'] = '上级';
$lang['level_search_btn_expand'] = '展开';

$lang['agent_general_tips'] = '他的直属玩家以及他的直属代理的输赢状况';

$lang['comfirm_forbidden'] = '确认禁用账号？';
$lang['comfirm_offline'] = '确认解禁账号？';
$lang['agent_total_report'] = '代理总账';