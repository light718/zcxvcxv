<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = '欢迎';
$lang['my_coin'] = '我的分数';
$lang['today_proxy_total_add_coin'] = '今日代理总上分';
$lang['today_proxy_total_add_coin_tips'] = '今日直属代理的上分合计';
$lang['today_player_total_add_coin'] = '今日玩家总上分';
$lang['today_player_total_add_coin_tips'] = '今日全系统所有玩家的上分合计';
$lang['today_player_total_sub_coin'] = '今日玩家总下分';
$lang['today_player_total_sub_coin_tips'] = '今日全系统所有玩家的下分合计';
$lang['today_total_sub_coin'] = '今日总抽水';
$lang['today_total_sub_coin_tips'] = '今日全系统的抽水合计';
$lang['today_total_win_coin'] = '今日总输赢';
$lang['today_total_win_coin_tips'] = '今日全系统的输赢合计';
$lang['yesterday'] = '昨日';
$lang['change_pwd'] = '密码修改';
$lang['confirm_pwd'] = '确认密码';
$lang['logout_tips'] = '确定退出么？';
$lang['logout_title'] = '&nbsp;';
$lang['sub_title_01'] = '最近24小时在线';
$lang['sub_title_01_tips_01'] = '在线人数';
$lang['sub_title_02'] = '最近24小时玩家分数存量';
$lang['sub_title_02_tips_01'] = '玩家分数';