<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['date_time'] = 'DateTime';
$lang['game_name'] = 'GameName';
$lang['game_event'] = 'Event';
$lang['bank_player'] = 'Bank/Player/Tie';
$lang['total_jackpot'] = 'Jackpot';
$lang['line'] = 'LINE NAME';
$lang['bet'] = 'BET';
$lang['win'] = 'WIN';
$lang['info'] = 'Info';
$lang['place'] = 'Odds';
$lang['scatter_num'] = 'SCATTER NUM';
$lang['niuniu_tip_01'] = 'Ten point bet';
$lang['niuniu_tip_02'] = 'Ten point win';
$lang['bet_info'] = 'BET POINT';
$lang['bet_coin'] = 'BET MONEY';
$lang['game_bet'] = 'Game Bet';
$lang['game_win'] = 'Game Win';
$lang['total'] = 'Total';
$lang['all_total'] = 'Total';
$lang['red_envelope'] = 'Red Envelope';
$lang['double_loss'] = 'Double loss';
$lang['double_win'] = 'Double win';
$lang['player_card'] = 'Player Card';
$lang['banker_card'] = 'Bank Card';
$lang['player_bet'] = 'Player Bet';
$lang['dogfall_bet'] = 'Tie Bet';
$lang['banker_bet'] = 'Banker Bet';
$lang['player_pair'] = 'Player Pair Bet';
$lang['banker_pair'] = 'Banker Pair Bet';
$lang['big'] = 'Big Bet';
$lang['small'] = 'Small Bet';
$lang['any_pair'] = 'Any Pair Bet';
$lang['perfect_pair'] = 'Perfect Pair Bet';
$lang['bank_card'] = 'Banker Card';

$lang['bureau_bet'] = 'This Round Bet';
$lang['bureau_win'] = 'This Round Win';
$lang['banker_cardtype'] = 'Banker Point';
$lang['banker_blackjack'] = 'Banker is BlackJack?';
$lang['player_cardtype'] = 'Player Point';
$lang['player_blackjack'] = 'Player is BlackJack?';
$lang['issafe'] = 'Is Insurance';
$lang['haddouble'] = 'Is Double';

$lang['total_bet'] = 'Total Bet';
$lang['total_win'] = 'Total Win';
$lang['bet_and_win'] = 'Bet and Win';
$lang['community_card'] = 'Public Card';

$lang['aa_bet'] = 'AA注';
$lang['side_bet'] = '旁注';
$lang['follow_bet'] = '跟注';
$lang['card_one'] = '牌1';
$lang['card_two'] = '牌2';
$lang['card_type'] = '牌型';
$lang['card_type_null'] = '无牌型';
$lang['discard'] = '弃牌';
$lang['aa_bet_win'] = 'AA注赢';
$lang['side_bet_win'] = '旁注赢';
$lang['follow_bet_win'] = '跟注赢';

$lang['long_card'] = 'DRAGON CARD';
$lang['hu_card'] = 'TIGER CARD';
$lang['long_bet'] = 'DRAGON BET';
$lang['hu_bet'] = 'TIGER BET';
$lang['he_bet'] = 'TIE BET';

$lang['bank_5_card'] = 'Banker five card';
$lang['player_5_card'] = 'Player five card';
$lang['bank_card_01'] = 'Banker card type';
$lang['player_card_01'] = 'Player card type';

$lang['duizi_bet_win'] = '对子注及赢钱';
$lang['bank_3_card'] = 'Banker three card';
$lang['pang_bet_win'] = '旁注及赢钱';
$lang['follow_bet_win'] = '跟注及赢钱';
$lang['card'] = 'Card';

$lang['ranking'] = 'Rank';
$lang['gold'] = 'Gold';
$lang['out'] = 'Out';

$lang['banker_bets'] = 'BankerBet';
$lang['player_bets'] = 'PlayerBet';
$lang['tie_bets'] = 'TieBet';

$lang['free_ele'] = 'FreeEle';