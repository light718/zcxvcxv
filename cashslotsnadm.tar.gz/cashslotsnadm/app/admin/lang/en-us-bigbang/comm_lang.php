<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['site_title'] = 'Poly Admin';
$lang['site_title_root_agent'] = 'Poly Admin';
$lang['site_title_general_agent'] = 'Poly Agent';

$lang['menu'] = 'Menu';
$lang['btn_refresh'] = 'Refresh';
$lang['btn_back'] = 'Back';
$lang['btn_search'] = 'Search';
$lang['btn_handle'] = 'Operate';
$lang['btn_close'] = 'Close';
$lang['btn_cancel'] = 'Cancel';
$lang['btn_add'] = 'Add';
$lang['btn_coin_search'] = 'Win/Lose';
$lang['btn_coin_change'] = 'Reload/Withdraw';
$lang['btn_coin_change_record'] = 'Score log';
$lang['btn_edit'] = 'Edit';
$lang['btn_status_disable'] = 'Disable';
$lang['btn_status_enable'] = 'Activate';
$lang['btn_add_coin'] = 'Reload';
$lang['btn_sub_coin'] = 'Withdraw';
$lang['btn_setting'] = 'SET';
$lang['btn_setting_02'] = 'SET';
$lang['btn_logout'] = 'Logout';
$lang['btn_detail'] = 'Detail';
$lang['btn_rollback'] = 'Recall';
$lang['btn_lottery'] = 'DROP';
$lang['btn_change_pwd'] = 'Password change';
$lang['btn_confirm'] = 'Confirm';
$lang['btn_sure'] = 'Confirm';
$lang['btn_save'] = 'Save';
$lang['btn_copy'] = 'Copy';
$lang['copy_success'] = 'Copy success';

$lang['start_date'] = 'Start date';
$lang['end_date'] = 'End date';
$lang['date'] = 'Date';
$lang['time'] = 'Time';

$lang['search_start_date'] = 'Start date';
$lang['search_end_date'] = 'End date';
$lang['search_start_time'] = 'Start time';
$lang['search_end_time'] = 'End time';
$lang['search_today'] = 'Today';
$lang['search_yesterday'] = 'Yesterday';
$lang['search_recent_seven_day'] = 'Recent 7 days';
$lang['search_week'] = 'This week';
$lang['search_month'] = 'This month';
$lang['search_pre_week'] = 'Last week';
$lang['search_range'] = 'Coin change filter';
$lang['search_placeholder_username_nickname'] = 'ID/Nickname';
$lang['search_placeholder_username_nickname_player'] = 'ID/Nickname';
$lang['search_placeholder_username_nickname_agent'] = 'ID/Nickname';
$lang['total_coin'] = 'Total win/lose';

$lang['return_success'] = 'Operation is successful';
$lang['return_fail'] = 'The operation failure';
$lang['return_up_coin_lack'] = 'Reload fail, not enough credit.';
$lang['return_down_coin_lack'] = 'Withdraw fail,player not enough credit.';
$lang['return_password_not_same'] = 'The passwords do not match';
$lang['return_empty'] = 'Please enter the complete information';

$lang['username'] = 'ID';
$lang['password'] = 'Password';
$lang['nickname'] = 'Nickname';
$lang['old_password'] = 'Original password';
$lang['new_password'] = 'New Password';
$lang['player_uid'] = 'Player ID';
$lang['player_username'] = 'Player account';
$lang['player_username_01'] = 'Player account';
$lang['player_nickname'] = 'Player Nickname';
$lang['player_status'] = 'Player Status';
$lang['player_status_online'] = 'Online';
$lang['player_status_offline'] = 'Offline';
$lang['player_coin'] = 'Player Credit';
$lang['game_name'] = 'Game Name';

$lang['proxy_username'] = 'Agent ID';
$lang['proxy_nickname'] = 'Agent Nickname';
$lang['direct_agent'] = 'Direct Agent';
$lang['packet_btn_open'] = 'Send';

$lang['table_column_search'] = 'Search';
$lang['table_column_handle'] = 'Operate';
$lang['table_column_date'] = 'Date';
$lang['table_column_time'] = 'Time';
$lang['table_column_bet'] = 'Bet';
$lang['table_column_room_id'] = 'Room ID';
$lang['table_column_username'] = 'ID';
$lang['table_column_nickname'] = 'Nickname';
$lang['table_column_win_coin'] = 'Win/lose';
$lang['table_column_child_win_coin'] = 'Direct win/lost';
$lang['table_column_total_win_coin'] = 'Total win/lost';
$lang['table_column_bigbang'] = 'Poly';

$lang['minute'] = 'Minute';
$lang['second'] = 'Second';
$lang['times'] = 'Times';

$lang['menu_home'] = 'Home';
$lang['menu_subaccount'] = 'Agent-sub account';
$lang['menu_account'] = 'Agent Management';
$lang['menu_agent_total_report'] = 'Agent total report';
$lang['menu_player_total_report'] = 'Player total report';
$lang['menu_user'] = 'Player management';
$lang['menu_client_notice'] = 'Announcement';
$lang['menu_general_agent_report'] = 'Agent report';
$lang['menu_game'] = 'Game Setting';
$lang['menu_prob'] = 'Probability control';
$lang['menu_userredpacket'] = 'System RedPacket';
$lang['menu_marquee'] = 'Signboard setting';
$lang['menu_level_search'] = 'Hierarchical query';
$lang['menu_report'] = 'Report';
$lang['menu_system_notice'] = 'System announcement';
$lang['menu_bigbang'] = 'BIGBANG';
$lang['menu_game_prob'] = 'Game Prob';
$lang['menu_game_switch'] = 'Game Switch';
$lang['menu_game_status'] = 'Game Status';
$lang['menu_system_search'] = 'System Search';
$lang['menu_player_login_log'] = 'Player Login Log';
$lang['menu_player_game_log'] = 'Player Game Log';
$lang['menu_player_list'] = 'Player List';
$lang['menu_player_detail_list'] = 'Player Detail List';
$lang['menu_agent_list'] = 'Agent List';
$lang['menu_agent_score_log'] = 'Agent Score Log';
$lang['menu_system_win'] = 'System win/lose';
$lang['menu_stat_report'] = 'Stat and report';
$lang['menu_report'] = 'Report';
$lang['menu_bet_nums'] = 'Bet nums';
$lang['menu_mainpool'] = 'Pool change';
$lang['menu_selfmainpool'] = 'Game self pool';
$lang['menu_online'] = 'Online';
$lang['menu_player_ip'] = 'Player login ip';
$lang['menu_player_win'] = 'Player win/lose';
$lang['menu_operation_log'] = 'Operation log';
$lang['menu_server_list'] = 'Server List';
$lang['menu_tax_empty_log'] = 'Tax empty log';
$lang['menu_bigbang_list'] = 'Bigbang search';
$lang['menu_check_accounts'] = 'Check Accounts';
$lang['menu_search_account'] = 'search user';
$lang['menu_system_setting'] = 'System setting';
$lang['menu_promote'] = 'Promote commission';
$lang['menu_transfer'] = 'Transfer log';

$lang['input'] = 'Please enter';
$lang['chinese'] = 'Chinese';
$lang['english'] = 'English';
$lang['no_data'] = 'No data';

$lang['bet'] = 'Bet';
$lang['win'] = 'Win';
$lang['select_game'] = 'Select Game';
$lang['tips'] = 'Tips';

$lang['refresh_list'] = 'Refresh table';

$lang['error_msg_account_reached_maxnum'] = "The number of accounts has reached the maximum";
$lang['error_msg_account_repeat'] = "ID already exists";
$lang['error_msg_marquee_add'] = "The start time must be greater than the current time";

$lang['title'] = 'WELCOME';
$lang['my_coin'] = 'Credit';
$lang['today_proxy_total_add_coin'] = 'Today agent total reload';
$lang['today_proxy_total_add_coin_tips'] = 'Today direct agent total reload';
$lang['today_player_total_add_coin'] = 'Today player total reload';
$lang['today_player_total_add_coin_tips'] = 'Today all player total reload';
$lang['today_player_total_sub_coin'] = 'Today player total withdraw';
$lang['today_player_total_sub_coin_tips'] = 'Today all player total withdraw';
$lang['today_total_sub_coin'] = 'Today total commission';
$lang['today_total_sub_coin_tips'] = 'Today total commission';
$lang['today_total_win_coin'] = 'Today total win/lose';
$lang['today_total_win_coin_tips'] = 'Today total Win/Lose';
$lang['yesterday'] = 'Yesterday';
$lang['change_pwd'] = 'Change password';
$lang['confirm_pwd'] = 'Confirm password';
$lang['logout_tips'] = 'Are you sure?';
$lang['logout_title'] = '&nbsp;';
$lang['sub_title_01'] = 'Recent 24 hours online';
$lang['sub_title_01_tips_01'] = 'Online';
$lang['sub_title_02'] = 'Recent 24 hours coins';
$lang['sub_title_02_tips_01'] = 'Coins';

$lang['game_tag'] = 'Tag';
$lang['game_tag_0'] = 'Normal';
$lang['game_tag_1'] = 'Hot';
$lang['game_tag_2'] = 'New';
$lang['batch_tag'] = 'Batch tag';
$lang['select'] = 'Please select';
$lang['red_envelope'] = 'Red envelope';

$lang['add_account_tips_01'] = 'Agent ID must be 3 to 12 alphanumeric characters, including capital letters';
$lang['add_account_tips_02'] = 'Password must be 4 to 12 alphanumeric characters, including capital letters';
$lang['add_account_tips_03'] = 'Name must be 4 to 12 alphanumeric characters, including capital letters';

$lang['search_account_tips'] = 'Please input agent id or player id';
$lang['agent'] = 'Agent';
$lang['input_username'] = 'please input username';

# 地区配置
$lang['region_hongkong'] = 'Hong Kong';
$lang['region_indonesia'] = 'Indonesia';
$lang['region_malaysia'] = 'Malaysia';
$lang['region_myanmar'] = 'Myanmar';
$lang['region_thailand'] = 'Thailand';
$lang['region_vietnam'] = 'Vietnam';