<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = 'WELCOME';
$lang['my_coin'] = 'Credit';
$lang['today_proxy_total_add_coin'] = 'Today agent total reload';
$lang['today_proxy_total_add_coin_tips'] = 'Today direct agent total reload';
$lang['today_player_total_add_coin'] = 'Today player total reload';
$lang['today_player_total_add_coin_tips'] = 'Today all player total reload';
$lang['today_player_total_sub_coin'] = 'Today player total withdraw';
$lang['today_player_total_sub_coin_tips'] = 'Today all player total withdraw';
$lang['today_total_sub_coin'] = 'Today total commission';
$lang['today_total_sub_coin_tips'] = 'Today total commission';
$lang['today_total_win_coin'] = 'Today total win/lose';
$lang['today_total_win_coin_tips'] = 'Today total Win/Lose';
$lang['yesterday'] = 'Yesterday';
$lang['change_pwd'] = 'Change password';
$lang['confirm_pwd'] = 'Confirm password';
$lang['logout_tips'] = 'Are you sure?';
$lang['logout_title'] = '&nbsp;';
$lang['sub_title_01'] = 'Recent 24 hours online';
$lang['sub_title_01_tips_01'] = 'Online';
$lang['sub_title_02'] = 'Recent 24 hours coins';
$lang['sub_title_02_tips_01'] = 'Coins';