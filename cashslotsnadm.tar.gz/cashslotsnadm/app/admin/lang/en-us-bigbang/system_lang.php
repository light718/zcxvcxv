<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['player_login_log_title'] = 'Player Login Log';
$lang['player_login_log_uid'] = 'UID';
$lang['player_login_log_pid'] = 'Player ID';
$lang['player_login_log_time'] = 'Time';

$lang['agent_list_title'] = 'Agent List';
$lang['agent_list_column_username'] = 'Agent ID';
$lang['agent_list_column_nickname'] = 'Nickname';
$lang['agent_list_column_parent_agent'] = 'Parent ID';
$lang['agent_list_column_first_agent'] = 'First Agent ID';
$lang['agent_list_column_coin'] = 'Coin';
$lang['agent_list_column_create_time'] = 'Register Time';
$lang['agent_list_column_last_login_time'] = 'Last Login Time';

$lang['agent_score_log_title'] = 'Agent Score Log';
$lang['agent_score_log_column_username'] = 'Agent ID';
$lang['agent_score_log_column_nickname'] = 'Nickname';
$lang['agent_score_log_column_coin'] = 'Coins Change';
$lang['agent_score_log_column_before'] = 'Before Change';
$lang['agent_score_log_column_after'] = 'After Change';
$lang['agent_score_log_column_create_time'] = 'Time';

$lang['player_game_log_title'] = 'Player Game Log';
$lang['player_game_log_game_name'] = 'Game Name';
$lang['player_game_log_type'] = 'Bet or  Win';
$lang['player_game_log_coin'] = 'Coins Change';
$lang['player_game_log_coin_before'] = 'Before Change';
$lang['player_game_log_coin_after'] = 'After Change';
$lang['player_game_log_time'] = 'Time';

$lang['system_win_title'] = 'System win/lose';
$lang['system_win_date'] = 'Date';
$lang['system_win_sysout'] = 'Sys reload';
$lang['system_win_sysin'] = 'Sys withdraw';
$lang['system_win_player'] = 'Player total coin';
$lang['system_win_agent'] = 'Agent total coin';

$lang['player_ip_title'] = 'Search player login ip';
$lang['player_ip_tips'] = 'Latest 10 records';

$lang['player_win_column_id'] = 'UID';
$lang['player_win_column_name'] = 'ID';
$lang['player_win_nickname'] = 'Nickname';
$lang['player_win_total'] = 'Total win/lose';
$lang['player_win_reload'] = 'Total reload';
$lang['player_win_ratio'] = 'Ratio';
$lang['player_win_select_all'] = 'all player';
$lang['player_win_select_control'] = 'controlled player';
$lang['player_win_select_not_control'] = 'no controlled player';

$lang['player_list_title'] = 'Player List';
$lang['player_list_column_id'] = 'UID';
$lang['player_list_column_pid'] = 'PlayerID';
$lang['player_list_column_nickname'] = 'Nickname';
$lang['player_list_column_coin'] = 'score';
$lang['player_list_column_online'] = 'Online State';
$lang['player_list_column_status_ban'] = 'Account State';
$lang['player_list_column_create_time'] = 'Add Time';
$lang['player_list_column_last_login_time'] = 'last login time';

$lang['operation_log_title'] = 'Operate History';
$lang['operation_log_column_id'] = '#';
$lang['operation_log_column_admin_id'] = 'ID';
$lang['operation_log_column_admin_username'] = 'Username';
$lang['operation_log_column_ip'] = 'IP';
$lang['operation_log_column_os'] = 'Operating system';
$lang['operation_log_column_browser'] = 'Browser';
$lang['operation_log_column_menu'] = 'Action';
$lang['operation_log_column_detail'] = 'Details';
$lang['operation_log_column_create_time'] = 'Operating time';

$lang['red_envelope'] = 'Red envelope';

$lang['tax_empty_title'] = 'Tax empty log';
$lang['tax_empty_column_id'] = 'ID';
$lang['tax_empty_column_oin'] = 'Coin';
$lang['tax_empty_column_create_time'] = 'Time';

$lang['promote_setting'] = 'Poly promoted commission setting';
$lang['promote_switch'] = 'On/Off';
$lang['promote_ratio'] = 'Commission rate';
$lang['promote_level_ratio'] = 'Commission level';

$lang['transfer_from_pid'] = 'Transfer out';
$lang['transfer_to_pid'] = 'Transfer in';
$lang['transfer_coin'] = 'Transfer out credit';
$lang['transfer_time'] = 'Transfer time';
$lang['input_username'] = 'Please input username';