<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = 'RummySlots';
$lang['title_root_agent'] = 'RummySlots';
$lang['title_general_agent'] = 'RummySlots';
$lang['username'] = '账号';
$lang['password'] = '密码';
$lang['vercode'] = '验证码';
$lang['login'] = '登 入';
$lang['captcha_empty'] = '请输入验证码';
$lang['captcha_error'] = '验证码错误';
$lang['username_empty'] = '请输入ID';
$lang['username_password_error'] = 'ID或密码错误';
$lang['login_ip_error'] = '账号不允许在这个ip登录';
$lang['login_forbidden'] = '账号已被禁用 请联系管理员解锁';
$lang['password_empty'] = '请输入密码';
$lang['login_success'] = '登入成功';
$lang['chinese'] = '中文';
$lang['english'] = 'English';
$lang['select'] = '请选择语言';

$lang['account_lock'] = '无法登录，稍等{%seconds%}再试';