<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['date_time'] = '日期时间';
$lang['game_name'] = '游戏名称';
$lang['game_event'] = '游戏事件';
$lang['bank_player'] = '庄/闲/和';
$lang['total_jackpot'] = '累计彩金';

$lang['game_send'] = '送灯编号';
$lang['game_fire'] = '金凤凰赔率';

$lang['line'] = '线';
$lang['bet'] = '押注';
$lang['win'] = '赢钱';
$lang['info'] = '信息';
$lang['place'] = '赔率';
$lang['scatter_num'] = '神个数';
$lang['niuniu_tip_01'] = '10个点的押注';
$lang['niuniu_tip_02'] = '10个点的赢钱';
$lang['bet_info'] = '押注信息';
$lang['bet_mult'] = '押注倍数';
$lang['bet_coin'] = '押注金额';
$lang['game_bet'] = '游戏下注';
$lang['game_win'] = '游戏赢';
$lang['total'] = '总计';
$lang['all_total'] = '所有总计';
$lang['red_envelope'] = '红包';
$lang['double_loss'] = 'Double loss';
$lang['double_win'] = 'Double win';
$lang['player_card'] = '玩家牌';
$lang['banker_card'] = '庄家牌';
$lang['player_bet'] = '玩家下注';
$lang['dogfall_bet'] = '和下注';
$lang['banker_bet'] = '庄家下注';
$lang['player_pair'] = '玩家对子';
$lang['banker_pair'] = '庄家对子';
$lang['big'] = '大';
$lang['small'] = '小';
$lang['any_pair'] = '任何对子';
$lang['perfect_pair'] = '完美对子';
$lang['bank_card'] = '庄家牌型';

$lang['bureau_bet'] = '本局押注';
$lang['bureau_win'] = '本局赢钱';
$lang['banker_cardtype'] = '庄家点数';
$lang['banker_blackjack'] = '庄家是否黑杰克?';
$lang['player_cardtype'] = '玩家点数';
$lang['player_blackjack'] = '玩家是否黑杰克?';
$lang['issafe'] = '是否买保险';
$lang['haddouble'] = '是否翻倍';

$lang['total_bet'] = '总押注';
$lang['total_win'] = '总赢钱';
$lang['bet_and_win'] = '押注和赢钱';
$lang['community_card'] = '公共牌';

$lang['aa_bet'] = 'AA注';
$lang['side_bet'] = '旁注';
$lang['follow_bet'] = '跟注';
$lang['card_one'] = '牌1';
$lang['card_two'] = '牌2';
$lang['card_type'] = '牌型';
$lang['card_type_null'] = '无牌型';
$lang['discard'] = '弃牌';
$lang['aa_bet_win'] = 'AA注赢';
$lang['side_bet_win'] = '旁注赢';
$lang['follow_bet_win'] = '跟注赢';

$lang['long_card'] = '龙';
$lang['hu_card'] = '虎';
$lang['long_bet'] = '龙押注';
$lang['hu_bet'] = '虎押注';
$lang['he_bet'] = '和押注';

$lang['bank_5_card'] = '庄家5张牌';
$lang['player_5_card'] = '玩家5张牌';
$lang['bank_card_01'] = '庄家牌型';
$lang['player_card_01'] = '玩家牌型';

$lang['duizi_bet_win'] = '对子注及赢钱';
$lang['bank_3_card'] = '庄家3张牌';
$lang['pang_bet_win'] = '旁注及赢钱';
$lang['follow_bet_win'] = '跟注及赢钱';
$lang['card'] = '牌';

$lang['ranking'] = '名次';
$lang['gold'] = '金色';
$lang['out'] = '出局';

$lang['banker_bets'] = '庄押注';
$lang['player_bets'] = '闲押注';
$lang['tie_bets'] = '和押注';

$lang['free_ele'] = '送灯编号';