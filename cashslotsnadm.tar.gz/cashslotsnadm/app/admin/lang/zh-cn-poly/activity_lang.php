<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['value_setting'] = '数值设置';

$lang['lucky_redbag'] = '分享红包';
$lang['lucky_redbag_title'] = '幸运红包数值';
$lang['lucky_redbag_min'] = '最小值';
$lang['lucky_redbag_max'] = '最大值';
$lang['lucky_redbag_prob'] = '触发概率（%）';
$lang['lucky_redbag_add'] = '添加一行';
$lang['lucky_redbag_tips_01'] = '最小值必须小于最大值';
$lang['lucky_redbag_tips_02'] = '触发概率总和必须等于100';
$lang['lucky_redbag_tips_03'] = '参数必须是数字';

$lang['rainy_redbag'] = '红包雨';
$lang['rainy_redbag_title'] = '红包雨数值';
$lang['rainy_redbag_min'] = '最小值';
$lang['rainy_redbag_max'] = '最大值';
$lang['rainy_redbag_prob'] = '触发概率（%）';
$lang['rainy_redbag_min_prob'] = '最小值概率（%）';
$lang['rainy_redbag_max_prob'] = '最大值概率（%）';
$lang['rainy_redbag_other_prob'] = '其他值概率（%）';
$lang['rainy_redbag_add'] = '添加一行';
$lang['rainy_redbag_tips_01'] = '最小值必须小于最大值';
$lang['rainy_redbag_tips_02'] = '触发概率总和必须等于100';
$lang['rainy_redbag_tips_03'] = '参数必须是数字';
$lang['rainy_redbag_tips_04'] = '值的概率总和必须等于100';

$lang['rainy_redbag_setting_title'] = '红包雨设置';
$lang['rainy_redbag_setting_send_time'] = '发送时间';
$lang['rainy_redbag_setting_prob'] = '中奖概率';
$lang['rainy_redbag_setting_total'] = '总金额';
$lang['rainy_redbag_setting_status'] = '状态';
$lang['rainy_redbag_setting_status_01'] = '进行中';
$lang['rainy_redbag_setting_status_02'] = '已撤回';
$lang['rainy_redbag_setting_status_03'] = '已结束';
$lang['rainy_redbag_setting_create_time'] = '添加时间';
$lang['rainy_redbag_setting_remark'] = '备注';
$lang['rainy_redbag_setting_add_time'] = '添加时间段';
$lang['rainy_redbag_setting_pool'] = '活动奖池余额';
$lang['rainy_redbag_setting_record'] = '设置记录';
$lang['rainy_redbag_setting_tips_01'] = '开始时间必须小于结束时间';
$lang['rainy_redbag_setting_tips_02'] = '中奖概率在0-100之间';
$lang['rainy_redbag_setting_tips_03'] = '红包雨正在进行中';
$lang['rainy_redbag_setting_tips_04'] = '活动奖池余额不足';

$lang['activity_jackpot_title'] = "活动奖池充值";
$lang['activity_jackpot_add_value'] = "充值额度";
$lang['activity_jackpot_tips_01'] = "普通奖池余额不足";

$lang['lucky_redbag_share_title'] = '分享次数';
$lang['lucky_redbag_share_nums'] = '分享次数';
$lang['lucky_redbag_redbag_nums'] = '红包个数';

$lang['growth_value_setting_title'] = '成长值数值';
$lang['growth_value_setting_star'] = '星星数量';
$lang['growth_value_setting_growth_value'] = '成长值';
$lang['growth_value_setting_type'] = '奖励类型';
$lang['growth_value_setting_type_1'] = '免费游戏';
$lang['growth_value_setting_type_2'] = '幸运宝箱';
$lang['growth_value_setting_free_game_id'] = '免费游戏ID';
$lang['growth_value_setting_free_game_nums'] = '免费游戏次数';
$lang['growth_value_setting_free_game_desc'] = '免费游戏描述';

$lang['lucky_box'] = '幸运宝箱';
$lang['lucky_box_setting_title'] = '幸运宝箱数值';
$lang['lucky_box_setting_coin'] = '分数';
$lang['lucky_box_setting_prob'] = '中奖概率';
$lang['lucky_box_setting_tips_01'] = '中奖概率总和必须等于100';

$lang['setting_title'] = '活动设置';
$lang['setting_lucky_redbag_switch'] = '幸运宝箱开关';
$lang['setting_growth_value_ratio'] = '成长值比例';
$lang['setting_growth_value_switch'] = '成长值开关';
$lang['setting_tip_01'] = '成长值数值未设定';
$lang['setting_tip_02'] = '成长值比例未设定';
$lang['setting_tip_03'] = '幸运宝箱数值未设定';

$lang['stat_title'] = '数据统计';
$lang['stat_lucky_redbag_share_nums'] = '分享次数';
$lang['stat_lucky_redbag_user_nums'] = '领取人数';
$lang['stat_lucky_redbag_send_nums'] = '发放数量';
$lang['stat_lucky_redbag_total_coin'] = '发放数额';
$lang['stat_rainy_redbag_send_nums'] = '触发次数';
$lang['stat_rainy_redbag_user_nums'] = '领取人数';
$lang['stat_rainy_redbag_total_coin'] = '发放数额';
$lang['stat_lucky_box_user_nums'] = '领取人数';
$lang['stat_lucky_box_total_coin'] = '领取总额';