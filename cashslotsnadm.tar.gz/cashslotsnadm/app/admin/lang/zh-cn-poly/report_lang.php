<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['report_title'] = '报表';
$lang['report_title_tips'] = '系统管理员专用的报表';
$lang['report_sub_title_01'] = '分游戏数据汇总';
$lang['report_sub_title_02'] = '大玩家';
$lang['report_sub_title_03'] = '大赢家';
$lang['report_sub_title_04'] = '奖池状态';

$lang['report_condition_01'] = '1小时数据';
$lang['report_condition_02'] = '24小时数据';
$lang['report_condition_03'] = '7天数据';
$lang['report_condition_04'] = '30天数据';

$lang['report_column_game_name'] = '游戏名';
$lang['report_column_au'] = 'AU';
$lang['report_column_bet_number'] = '下注次数';
$lang['report_column_bet'] = '注金';
$lang['report_column_win'] = '赢钱';
$lang['report_column_system_win_rate'] = '系统胜率';
$lang['report_column_system_win_coin_rate'] = '系统赢钱率';
$lang['report_column_last_login_time'] = '上次登录';
$lang['report_column_value_never_login'] = '从未登录';
$lang['report_column_btn_game_log'] = '游戏记录';

$lang['report_pool_normal'] = '普通奖池库存';
$lang['report_pool_jackpot'] = '大奖池库存';
$lang['report_pool_jackpot_baseline'] = '当前系统设定的Jackpot开奖线';
$lang['report_pool_tax'] = '抽水池分数';
$lang['report_pool_tax_baseline'] = '当前系统设定的抽水上限';

$lang['report_tips_01'] = '最近24小时普通奖池库存';
$lang['report_tips_02'] = '最近24小时普通奖池的库存变化柱状图，5分钟一个数据点';
$lang['report_tips_03'] = '最近24小时大奖池库存（Jackpot）';
$lang['report_tips_04'] = '最近24小时大奖池的库存变化柱状图，5分钟一个数据点。';
$lang['report_tips_05'] = '最近24小时抽水池状况';
$lang['report_tips_06'] = '最近24小时抽水池分数变化柱状图，5分钟一个数据点。';

$lang['report_tips_name_01'] = '普通奖池库存';
$lang['report_tips_name_02'] = '大奖池库存';
$lang['report_tips_name_03'] = '抽水池状况';
$lang['report_tips_name_04'] = '每个游戏的库存变化情况';
$lang['report_tips_name_05'] = '每个游戏的下注总次数';

$lang['stocks'] = '总库存';
$lang['all_online_num'] = '全服实时在线人数';


$lang['startapp_all_userdata'] = '总启动次数';
$lang['startapp_new_userdata'] = '新用户启动次数';

$lang['payrate_gameid'] = 'GameID';
$lang['payrate_title'] = '游戏名';
$lang['payrate_bet'] = '总下注';
$lang['payrate_win'] = '总赢分';
$lang['payrate_val'] = '回报率';
$lang['payrate_day'] = '日期';
$lang['payrate_createtime'] = '创建时间';

$lang['payrate_ord'] = '排序';
$lang['payrate_uid'] = '账号';
$lang['payrate_wincoin'] = '输赢分';