<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/2/18
 * Time: 17:56
 */
use \think\facade\Route;
Route::get('captcha/[:config]','\\think\\captcha\\CaptchaController@index');