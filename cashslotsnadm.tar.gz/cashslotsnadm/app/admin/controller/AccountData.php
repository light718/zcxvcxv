<?php
namespace app\admin\controller;
use app\admin\model\DGameTask;
use app\admin\model\DGameTaskRecord;
use app\admin\model\SGame;
use app\admin\model\SGameType;
use app\admin\model\StatGameData;
use app\admin\model\StatGameDetailToday;
use app\admin\model\StatLoginData;
use app\admin\model\StatMarketDay;
use app\admin\model\StatUserCoinData;
use app\admin\model\StatUserOnlineData;
use think\App;
use think\db\Query;
use think\Request;

/***
 * 数值统计数据
 * Class AccountData
 * @package app\admin\controller
 */
class AccountData extends Base
{
    protected $notNeedRight = ['dauData', 'subGame', 'firstPlay', 'active_data'];
    /***
     * @param Request $request
     * @return string
     */
    public function index(Request $request){
        $start_time = strtotime($request->get('start_time'))?:0;
        if (!$start_time){
            $day = $request->get('day',30);
            $start_time = date('Ymd',strtotime("-{$day} days"));
        }else{
            $start_time = date('Ymd',$start_time);
        }
        $limit = $request->get('limit/d',15);
        $end_time = date('Ymd',strtotime($request->get('end_time'))?:time());
        $query = StatMarketDay::whereBetween('day',[$start_time,$end_time]);
        // 破产记录表
        if ($request->get('is_export')){
            $list = $query->order('day desc')->select();

            foreach ($list as &$value){
                $value['day'] = date("Y-m-d",strtotime($value['day']));
            }
            $name = '数据统计';
            $format = 'xls';
            $newExcel = new \PHPExcel();  //
            $phpexcel = $newExcel->getActiveSheet();  //

            $phpexcel->setTitle($name);
            $newExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
            $newExcel->getActiveSheet()->getColumnDimension('B')->setWidth(50);
            $newExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
            $newExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
            $newExcel->getActiveSheet()->getColumnDimension('J')->setWidth(100);

            $newExcel->getActiveSheet()->getColumnDimension('K')->setWidth(100);
            $phpexcel->setCellValue('A1', 'ID')
                ->setCellValue('B1', lang('date'))
                ->setCellValue('C1', lang('dau'))
                ->setCellValue('D1', lang('market_dnu'))
                ->setCellValue('E1', lang('market_dnu_spin')) //新增玩牌用户
                ->setCellValue('F1', lang('market_dau'))
                ->setCellValue('G1', lang('market_active_spin_count'))
                ->setCellValue('H1', lang('pay_user'))
                ->setCellValue('I1', lang('pay_amount'))
                ->setCellValue('J1', lang('market_banrupt'))
                ->setCellValue('K1', lang('market_pay_banrupt'));
            $phpexcel->getStyle('B1')->getAlignment()->setWrapText(true);
            foreach ($list as $k => $v){
                $phpexcel->setCellValue('A' . ($k + 2), $v->Id."\t");
                $phpexcel->setCellValue('B' . ($k + 2), $v->day);
                $phpexcel->setCellValue('C' . ($k + 2), $v->dau);
                $phpexcel->setCellValue('D' . ($k + 2), $v->dnu);
                $phpexcel->setCellValue('E' . ($k + 2), $v->dau_spin);
                $phpexcel->setCellValue('F' . ($k + 2), $v->last_dau);
                $phpexcel->setCellValue('G' . ($k + 2), $v->activeuser_spin_count);
                $phpexcel->setCellValue('H' . ($k + 2), $v->paynum);
                $phpexcel->setCellValue('I' . ($k + 2), $v->payamount);
                $phpexcel->setCellValue('J' . ($k + 2), $v->bankrupt_count);
                $phpexcel->setCellValue('K' . ($k + 2), $v->bankrupt_pay_count);
            }
            ob_end_clean();
            header('Content-Type: application/vnd.ms-excel');
            header("Content-Disposition: attachment;filename=" . $name . date('Y-m-d') . '.' . strtolower($format));
            header('Cache-Control: max-age=0');
            $res_excel = \PHPExcel_IOFactory::createWriter($newExcel, 'Excel5');
            $res_excel->save('php://output');
        }

        if ($request->isAjax()){
            $list_stat = $query->order('day asc')->select()->toArray();

            $lists = StatMarketDay::whereBetween('day',[$start_time,$end_time])->order('day desc')->paginate($limit,false,['query'=>$request->param()]);
            $y_data2 = array_column($list_stat,'dnu');
            $x_data =  array_column($list_stat,'day');
            $y_data1 = array_column($list_stat,'dau');
            $list = $list_stat;
            return json(['code' => 200, 'datas' => compact('list','x_data' ,'y_data1','y_data2'),'data'=>$lists->items(), 'count' => $lists->total(), 'msg' => lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 玩牌数据统计
     * @param Request $request
     * @return string
     */
    public function playCard(Request $request){
        $start_time = strtotime($request->get('start_time'))?:0;
        $limit = $request->get('limit/d',15);
        if (!$start_time){
            $day = $request->get('day',30);
            $start_time = strtotime("-{$day} days");
        }
        $start_time = date('Ymd',$start_time);
        $end_time =  date('Ymd',strtotime($request->get('end_time'))?:time());
        $query = StatMarketDay::whereBetween('day',[$start_time,$end_time]);
        // 破产记录表
        if ($request->get('is_export')){
            $list = $query->select();
            foreach ($list as &$value){
                if ($value['dnu']){
                    $value['avg_spin'] = floor($value['reg_spin_count'] /$value['dnu'] ) ;
                }else{
                    $value['avg_spin'] = 0 ;
                }
            }
            $list_key = [
                'day',
                'dnu',
                'dau_not_spin',
                'dau_spin',
                'avg_spin',
            ];
            $this->export($list_key,$list);
        }

        if ($request->isAjax()){
            $lists = $query->order('day asc')->select();
            $lists_stat = StatMarketDay::whereBetween('day',[$start_time,$end_time])->order('day desc')->paginate($limit,false,['query'=>$request->param()]);
            foreach ($lists as &$value){
                if ($value['dnu']){
                    $value['avg_spin'] = floor($value['reg_spin_count'] /$value['dnu'] ) ;
                }else{
                    $value['avg_spin'] = 0 ;
                }
            }
            foreach ($lists_stat as &$val){
                if ($val['dnu']){
                    $val['avg_spin'] = floor($val['reg_spin_count'] /$val['dnu'] ) ;
                }else{
                    $val['avg_spin'] = 0 ;
                }
            }
            $list = $lists->toArray();
            $y_data = array_column($list, 'dau_not_spin');

            $y_data1 = array_column($list, 'dau_spin');

            $y_data2 = array_column($list, 'avg_spin'); //

            $x_data = array_column($list, 'day');
            return json(['code' => 200, 'datas' => compact('list','x_data' ,'y_data','y_data1','y_data2'),'data'=>$lists_stat->items(), 'count' => $lists_stat->total(), 'msg' => lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 导出excel
     * @param $list_key key=> 中文value
     * @param $list
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    protected function export($list_key,$list){
        $newExcel = new \PHPExcel();  //
        $phpexcel = $newExcel->getActiveSheet();  //
        $name = '数据统计';
        $phpexcel->setTitle($name);
        $newExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('B')->setWidth(100)->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('J')->setWidth(200);
        $key_arr = range("A","Z");
        $newExcel->getActiveSheet()->getColumnDimension('K')->setWidth(200);
        foreach ($list_key as $key =>$value){
            $i = floor($key/26) + 1;
            $phpexcel =  $phpexcel->setCellValue( $key_arr[$key].$i,lang($value));
        }

        $phpexcel->getStyle('B1')->getAlignment()->setWrapText(true);
        foreach ($list as $k => $v){
            $i = 0;
//            foreach ($v as $key => $value){
            foreach ($list_key as $kk =>$key_val){
                $phpexcel->setCellValue($key_arr[$i] . ($k + 2), $v[$key_val]."\t");
                $i += 1;
            }
        }
        ob_end_clean();
        header('Content-Type: application/vnd.ms-excel');
        header("Content-Disposition: attachment;filename=" . $name . date('Y-m-d') . '.' . strtolower("xls"));
        header('Cache-Control: max-age=0');
        $res_excel = \PHPExcel_IOFactory::createWriter($newExcel, 'Excel5');
        $res_excel->save('php://output');
    }

    /***
     *  新增登录用户数据
     * @param Request $request
     * @return \think\response\Json
     */
    public function dauData(Request $request)
    {
        if ($request->isAjax()) {
            $start_time = strtotime($request->get('start_time')) ?: 0;
            if (!$start_time) {
                $day = $request->get('day', 30);
                $start_time = strtotime(date('Y-m-d',strtotime("-{$day} days")));
            }
            $end_time =strtotime($request->get('end_time'))?: time();
            $limit = $request->get('limit/d');
            $query = StatLoginData::field("*")->whereBetween('create_time', [$start_time, $end_time]);
            $list = $query->select()->toArray();
            $fb_count = array_sum(array_column($list, 'reg_fb_count'));
            $guest_user_count = array_sum(array_column($list, 'reg_guest_count'));
            $google_user_count = array_sum(array_column($list, 'reg_google_count'));
            $reg_ios_count = array_sum(array_column($list, 'reg_ios_count'));
            $query = StatLoginData::field("*")->whereBetween('create_time', [$start_time, $end_time]);
            $lists = $query->order('create_time desc')->paginate($limit);
            return json(['code' => 200, 'datas' => compact('list', 'guest_user_count','reg_ios_count', 'google_user_count', 'fb_count'), 'data' => $lists->items(), 'count' => $lists->total(), 'msg' => lang('return_success')]);
        }
    }

    /***
     * 子游戏数据
     * @param Request $request
     */
    public function subGame(Request $request){

        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time'))?:0;
            if (!$start_time){
                $day = $request->get('day',30);
                $start_time = strtotime("-{$day} days");
            }
            $limit = $request->get('limit/d');
            $end_time = strtotime(strtotime($request->get('end_time')))? :time();
            $condition = [];
            $condition[] = ['create_time','>=',$start_time];
            $condition[] = ['create_time','<',$end_time];
            $query = StatGameData::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,create_time,all_count,not_play_game,played_one_game,played_two_game,played_three_game,played_four_game,dau_count,played_five_game,played_six_game,played_more_game")->where($condition);
            $list = $query->select()->toArray();
//            ->toArray();
            $query = StatGameData::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,create_time,all_count,not_play_game,played_one_game,played_two_game,played_three_game,played_four_game,dau_count,played_five_game,played_six_game,played_more_game")->where($condition);
            $lists = $query->order('create_time desc')->paginate($limit);
            $y_data = array_column($list,'not_play_game');
            $y_data1 = array_column($list,'played_one_game');
            $y_data2 = array_column($list,'played_two_game');
            $y_data3 = array_column($list,'played_three_game');
            $y_data4 = array_column($list,'played_four_game');
            $y_data5 = array_column($list,'played_five_game');
            $y_data6 = array_column($list,'played_six_game');
            $y_data7 = array_column($list,'played_more_game');

            $x_data = array_column($list,'create_times');
            $data = $lists->items();
            foreach ($data as &$val){
//                $val['play_count'] = $val['']
            }
            return json(['code' => 200, 'datas' => compact('y_data','y_data1','y_data2','y_data3','y_data4','y_data5','y_data6','y_data7','x_data'),'data'=>$data, 'count' => $lists->total(), 'msg' => lang('return_success')]);
        }
    }

    /***
     *  子游戏数据
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function firstPlay(Request $request){
        $start_time = strtotime($request->get('start_time'))?:0;
        $limit = $request->get('limit/d');
        if (!$start_time){
            $day = $request->get('day',30);
            $start_time = strtotime("-{$day} days");
        }
        $game_id_arr = SGame::where('gametag','>',0)->column('id');
        $end_time = strtotime(strtotime($request->get('end_time')))? :time();

        $list = StatGameDetailToday::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,game_title,allusers,allbet,allwin,alltimes,bet_one,bet_two,bet_other")->whereBetween('create_time',[$start_time,$end_time])
            ->whereIn('game_id',$game_id_arr)->order('create_time desc')->paginate($limit);
        $data  = $list->items();

        return json(['code' => 200,'data'=>$data, 'count' => $list->total(), 'msg' => lang('return_success')]);

    }

    /***
     * quest 数据统计
     * @param Request $request
     * @return string
     */
    public function quest(Request $request){

        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time'))?:strtotime("-1 month");
            $end_time = strtotime($request->get('end_time'))?:time();
            $limit = $request->get('limit/d',15);

            $list= DGameTaskRecord::with(['game'=>function(Query $query){
                $query->field('title,gameid');
            }])->whereBetween('create_time',[$start_time,$end_time])->paginate($limit);

            $data = $list->items();
            foreach ( $data as &$val){
                $val['game_title'] = $val['game']['title'];
            }
            return json(['code' => 200,'data'=>$data, 'count' => $list->total(), 'msg' => lang('return_success')]);
        }
        return $this->fetch();

    }

    /***
     * @param Request $request
     * @return \think\response\Json
     */
    public function active_data(Request $request){
        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time'))?:strtotime("-1 month");
            $end_time = strtotime($request->get('end_time'))?:time();
            $limit = $request->get('limit/d',15);
            $uid_arr = DGameTask::where(['gameover'=>1])->column('DISTINCT uid');
            $list = DGameTaskRecord::with(['game'=>function(Query $query){
                $query->field('title,gameid');
            }])->whereIn('uid',$uid_arr)->whereBetween('create_time',[$start_time,$end_time])->order('create_time desc')->group('uid')->paginate($limit);
//            $limit
            $data = $list->items();
            foreach ( $data as &$val){
                $val['game_title'] = $val['game']['title'];
            }
            return json(['code' => 200,'data'=>$data, 'count' => $list->total(), 'msg' => lang('return_success')]);
        }
    }

}