<?php
namespace app\admin\controller;


use app\admin\model\AccountScoreLog;
use app\admin\model\DUser;
use app\admin\model\GameserverGamelog;
use app\admin\model\LogLoginPlayer;
use app\admin\model\SFilterWord;
use app\admin\model\SGameType;
use app\admin\model\SShopOrder;
use org\Curl;
use org\Helper;
use org\RedisKey;
use think\App;
use think\facade\Db;
use think\Request;
use app\admin\model\Clubs;
use app\admin\model\ClubMembers;
use app\admin\model\ClubOperateLog;

/***
 * 邮件管理
 * Class Email
 * @package app\admin\controller
 */
class Club extends Base
{
    protected $notNeedRight = ['titleUser', 'coinEdit', 'addDiamond', 'addPoints', 'restName','transfer_user', 'setUserLevel','wordEdit', 'wordDelete','unbind'];

    /***
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $uid = $request->get('user_id',0,'trim');

            if (!$uid){
                return $this->jsonReturn(EXIT_ERROR,lang('input_member_id'));
            }

            $result = DUser::where(compact('uid'))->find();
            if (!$result){
                return $this->jsonReturn(EXIT_ERROR,lang('user not exsits'));
            }
            $result['totalpay'] = SShopOrder::where(compact('uid'))->where(['status'=>SShopOrder::STATUS_SUCCESS])->sum('amount');
            if ($request->isPost()){
                $type = $request->post('type',1); // 1 增加 2：减
                $coin = $request->post('coin',0);
                $param = $request->param();
                $coin_send = $request->post('coin_send',0,'abs');
                $coin += $coin_send;
                $reason = $request->post('reason', '');
                if (!$coin){
                    return $this->jsonReturn(EXIT_ERROR,lang('coin_min_0'));
                }
                $user_id = session('user_info.id');
                if ($coin <0 && ($user_id != 1000 )) {
                    return $this->jsonReturn(EXIT_ERROR,lang('cant reduce coin'));
                }
                $user_coin = \app\admin\model\Account::where(['id'=>$user_id])->value('coin');
                if ($type == 2 ){
                    $coin *= -1;
                    $log_data = "用户id（%s）减少金币（%s），原因（%s）";
                }else{
                    $log_data = "用户id（%s）增加金币（%s），原因（%s）";
                }
                if ($user_coin < $coin && $this->is_agent){
                    return $this->jsonReturn(EXIT_ERROR,lang('coin_not_enough'));
                }
                $data = [
                    'mod'=>'coin',
                    'act'=>'add',
                    'uid'=>$uid,
                    'coin'=>$coin,
                ];
                if ($this->is_agent && $coin <0){
                    return $this->jsonReturn(EXIT_ERROR,lang('account_cant_reset_coin'));
                }
                $curl = new Curl();
                if ($coin <0){
                    $res = $curl->player_offline($uid);
                    sleep(3);
                }
                $res = $curl->resetName($data);

                if ($res){
                    $log_datas = [
                        'coin' => $param['coin'],
                        'coin_before' => $result['coin'],
                        'change_desc' => lang('agent_change_coin'),
                        'account_id' => $uid,
                        'create_id' => session('user_info.id'),
                        'coin_send' => $param['coin_send']
                    ];
                    \app\admin\model\Account::where(['id'=>$log_datas['create_id']])->dec('coin',$coin)->update();
                    AccountScoreLog::insertLog($log_datas);
                    error_reporting(E_ALL);
                    $this->record('金币加减记录',$log_data,[$uid,$coin,""]);
                    return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
                }else{
                    return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
                }
            }
            $result['coin'] = intval($result['coin']);
            $result['create_platform_text'] = $result->create_platform_text;
            $result['status_text'] = $result->status_text;
            $result['isbind'] = Db::connect('game')->name('d_user_bind ')->where('uid', $uid)->count();

            if ($result){
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'),compact('result'));
            }else{
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
            }
        }
        $uid = $request->get('uid');
        return $this->fetch(__FUNCTION__,compact('uid'));
    }

    /***
     * 封号
     * @param Request $request
     * @return string
     */
    public function titleUser(Request $request){
        if ($request->isAjax()){

            $user_id = $request->post('user_id');
            $status = $request->post('status',0);
            if (!$user_id){
                return $this->jsonReturn(EXIT_ERROR,lang('input_member_id'));
            }
            if ($status){
                $update_data = compact('status');
                $re = DUser::where(['uid'=>$user_id])->update($update_data);
            }else{
                $update_data = compact('status');
                $re = DUser::where(['uid'=>$user_id])->update($update_data);
            }
            $curl = new Curl();
            $curl->player_offline($user_id);
            $redis_obj = $this->getRedisObj();
            $pars = RedisKey::DUSER.$user_id;
            $redis_obj->hSet($pars,'status',$status);
            if($status == 0){
                $title = '';
                $log_data = "用户（%s）被管理员封号";
            }else{
                $log_data = "用户（%s）被管理员解封";

            }
//            $curl = new Curl();
//            $res = $curl->resetName($data);
            if ($re){
                $res = $this->record('用户封号记录',$log_data,[$user_id]);
//                ClubOperateLog::createLog($log_data,'玩家信息');
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
            }else{
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
            }
        }
    }


    //解绑
    public function unbind(Request $request){
        $uid = $request->get('uid', false);
        if ($uid) {
            $rs = Db::connect('game')->name('d_user_bind')->where('uid', $uid)->delete();
            if($rs){
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
            } 
        }
        return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
    }

    /***
     * @param Request $request
     * @return string
     */
    public function coinEdit(Request $request){
        $uid = $request->get('uid');
        if (!$uid){
            $this->error(lang('input_member_id'));
        }
        $this->assign('uid',$uid);
        $member_coin = DUser::where(compact('uid'))->value('coin');
        $user_coin = \app\admin\model\Account::where(['id'=>session('user_info.id')])->value('coin');
        $this->assign('member_coin',$member_coin);
        $this->assign('user_coin',$user_coin);
        return $this->fetch();
    }

    //添加钻石
    public function addDiamond(){
        $param = $this->request->post();
        $curl = new Curl();
        $curl->resurrectionAdd($param, 'diamond');
        $this->record('添加钻石',"用户uid（%s）添加钻石数量（%s)", [$param['uid'], $param['num']]);
        $this->success('操作成功');
    }

    //添加富豪厅点数
    public function addPoints(){
        $param = $this->request->post();
        $curl = new Curl();
        $curl->resurrectionAdd($param, 'points');
        $this->record('添加富豪厅点数',"用户uid（%s）添加富豪厅点数数量（%s)", [$param['uid'], $param['num']]);
        $this->success('操作成功');
    }

    /***
     * 重置用户名
     * @param Request $request
     * @return string
     */
    public function restName(Request $request){
        if ($request->isAjax()){
            $user_id = $request->post('user_id');

            if (!$user_id){
                return $this->jsonReturn(EXIT_ERROR,lang('input_member_id'));
            }
            $name_arr = ['Kevin','Rose','Jose','John','Nick'];
            $playername = $name_arr[rand(0,count($name_arr)-1)] ;
            $update_re = DUser::where(['uid'=>$user_id])->update(['playername'=>$playername]);

            $data  = [
                'mod'=>'user',
                'act'=>'update',
                'uid'=>$user_id,
            ];
            $curl = new Curl();

            $res = $curl->resetName($data);
            $redis = $this->getRedisObj();
            $redis->hSet("d_user:".$user_id,'playername',$playername);
            if ($res|| $update_re){
//                ClubOperateLog::createLog("重置用户{$user_id} 的用户名成功",'玩家信息');
                $res = $this->record('姓名重置',"重置用户（%s）的用户名为（%s）",[$user_id,$playername]);
                $user_re = DUser::where(['uid'=>$user_id])->find();
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'),['result'=>$user_re]);
            }else{
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));

            }
        }
    }

    /**
     * 俱乐部界面
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DbException
     */
    public function clubs(Request $request){
        if ($request->isAjax()){
            $condition = [];
            if ($menu_name = $request->get('name')){
                $condition[] = ['name','like',"%".$menu_name."%"];
            }
            $limit = $request->get('limit/d');

            $list = Clubs::where($condition)->order('create_time desc')->paginate($limit);
            $member_count = [];
            $club_ids = array_column($list->items(),'id');
            $club_members = ClubMembers::field('count(user_id) as t,club_id')->whereIn('club_id',$club_ids)->group('club_id')->select();
            foreach ($club_members as $val){
                $member_count[$val['club_id']] = $val['t'];
            }
            foreach ($list as &$value){
                $current_count = isset($member_count[$value['id']]) ? $member_count[$value['id']] :0;
                $value['member_counts'] = $current_count. '/50';
                $value['owner_name'] = DUser::where( ['uid'=>$value['owner_id']])->value('playername');
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total()]);exit;
        }
        return $this->fetch();
    }

    /***
     *
     * @param Request $request
     */
    public function members(Request $request){
        $id = $request->get('id');

        $list = ClubMembers::where(['club_id'=>$id])->select()->toArray();

        return $this->fetch(__FUNCTION__,compact('list'));
    }

    /***
     * 操作记录
         * @param Request $request
     * @return string
     */
    public function operateLog(Request $request){
        if ($request->isAjax()){
            $condition = [];
            if ($menu_name = $request->get('menu_name','','url_decode')){
                $condition[] = ['menu_name','=',$menu_name];
            }
            $limit = $request->get('limit',15);
            $start_time = strtotime( $request->get('start_time') ) ?: 0 ;
            $end_time = strtotime($request->get('end_time'))?:time();
            $time_arr = [$start_time,$end_time];

            $list = ClubOperateLog::where($condition)->whereBetween('create_time', $time_arr)->paginate($limit);

            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total()]);
        }
        return $this->fetch();

    }

    /***
     *  转让管理员
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function transfer(Request $request){
        $club_id = $request->post('club_id');
        $uid = $request->post('uid');
        $exsits = DUser::where(['uid'=>$uid])->find();
        if (!$exsits){
            return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }

        $res = Clubs::where(['id'=>$club_id])->find();
        if (!$res){
            return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }

        $res = Clubs::where(['id'=>$club_id])->update(['owner_id'=>$uid]);
        if ($res){
            $res= ClubOperateLog::createLog('管理员'.session('user_info.id')."转让俱乐部{$club_id}给用户:{$uid}",'俱乐部');
            return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
        }else{
            return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }
    }

    /***
     * 解散俱乐部
     * @param Request $request
     * @return string
     */
    public function dissolution(Request $request){

        $club_id = $request->post('club_id');
        if (!$club_id){
            return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }

        $res = Clubs::where(['id'=>$club_id])->delete();
        if ($res){
//            $res= ClubOperateLog::createLog('管理员'.session('user_info.id')."解散俱乐部:{$club_id}",'俱乐部');
            return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
        }else{
            return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }
    }

    /***
     * @method get 屏蔽词界面
     * @method post 新增/修改屏蔽词
     * @param Request $request
     * @return string
     */
    public function shieldWords(Request $request){
        if ($request->isAjax()){
            $condition = [];
            if ($name = $request->get('name','','trim')){
                $condition[] = ['word','like','%'.$name."%"];
            }
            $limit = $request->get('limit');
            $list = SFilterWord::where($condition)->order('id desc')->paginate($limit);
            return json(['code'=>200,'data'=>$list->items(),'msg'=>lang('return_success'),'count'=>$list->total()]);exit;
        }
        return $this->fetch();
    }

    /***
     * 编辑关键词
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function wordEdit(Request $request){
        $id = $request->get('id');
        $word_model = new SFilterWord();
        if ($request->isAjax()){
            $word = $request->post('word');
            if ($id){
                $res = $word_model->where(compact('id'))->update(compact('word'));
            }else{
                $res = $word_model->save(compact('word'));
            }
            $id = $id ? : $word_model->id;
            if ($res){
                $res= ClubOperateLog::createLog('管理员'.session('user_info.id')."操作关键词:{$id}--{$word}",'屏蔽词');
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
            }else{
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
            }
        }

        $result = SFilterWord::where(compact('id'))->find();

        $this->assign('result',$result);

        return $this->fetch();
    }

    /***
     * 删除屏蔽词语
     * @param Request $request
     * @return string
     */
    public function wordDelete(Request $request){
        $id = $request->post('id');
        $res = SFilterWord::where(compact('id'))->delete();
        if ($res){
            $res= ClubOperateLog::createLog('管理员'.session('user_info.id')."删除关键词:{$id}",'屏蔽词');
            return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
        }else{
            return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }
    }

    /*****
     * 转让管理员
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function transfer_user(Request $request){
        if ($request->isAjax()){
            $club_id = $request->post('club_id');
            $uid = $request->post('uid');
            $exsits = DUser::where(['uid'=>$uid])->find();
            if (!$exsits){
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
            }

            $res = Clubs::where(['id'=>$club_id])->find();
            if (!$res){
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
            }

            $res = Clubs::where(['id'=>$club_id])->update(['owner_id'=>$uid]);
            if ($res){
//                $res= ClubOperateLog::createLog('管理员'.session('user_info.id')."转让俱乐部{$club_id}给用户:{$uid}",'俱乐部');
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
            }else{
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
            }
        }
        $club_id = $request->get('club_id');
        return $this->fetch(__FUNCTION__,compact('club_id'));
    }

    /***
     * 设置用户等级
     * @param Request $request
     * @return string
     */
    public function setUserLevel(Request $request){
        $level = $request->post('level/d',1);
        $user_id = $request->param('uid/d');
        if ($level<1){
            return $this->jsonReturn(EXIT_ERROR,lang('等级必须大于1级'));
        }
        if (!$user_id){
            return $this->jsonReturn(EXIT_ERROR,lang('请输入用户编号'));
        }
        $user_re =  DUser::where(['uid'=>$user_id])->find();
        Db::startTrans();
        $update_data = compact('level');
        $re = DUser::where(['uid'=>$user_id])->update($update_data);
        $redis_obj = $this->getRedisObj();
        $pars = RedisKey::DUSER.$user_id;
        $redis_obj->hSet($pars,'level',$level);
        if ($re){
            Db::commit();
            $this->record('用户等级设置变动','将用户（%s）从（%s）等级变为（%s）级', [$user_id,$user_re['level'],$level]);
            return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
        }else{
            Db::rollback();
            return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }
    }

    /***
     * 登录日志
     * @param Request $request
     * @return string
     */
    public function login_log(Request $request){
        if ($request->isAjax()){
            $post_param = $request->param();
            if (isset($post_param['start_time'])){
                $start_time = strtotime($post_param['start_time']);
                $end_time  = strtotime($post_param['end_time'])?:time();
            }else{
                $start_time = 0;
                $end_time = time();
            }
            $time_arr =  [$start_time,$end_time];
            $uid = $request->get('uid');
            $limit = $post_param['limit'];
            $lists = LogLoginPlayer::whereBetween('create_time',$time_arr)->where(['account_id'=>$uid])->order('create_time desc')->paginate($limit);
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }

        $uid = $request->get('uid');
        return $this->fetch(__FUNCTION__,compact('uid'));
    }


    /***
     * 玩家明细列表
     * @param Request $request
     * @return string
     */
    public function player_detail_list(Request $request ){
        if($request->isAjax()){
            $post_param =  $request->param();
            if (isset($post_param['start_time'])){
                $start_time = strtotime($post_param['start_time'])?:strtotime('-1 month');

                $end_time  = strtotime($post_param['end_time'])?:time();
            }else{
                $start_time = 0;
                $end_time = time();
            }
            $time_arr =  [$start_time,$end_time];
            $uid = $post_param['uid'];
            $limit = $request->get('limit',15);
            $lists = GameserverGamelog::where(['account_id'=>$uid])->where([['game_id','>=',419],['game_id','<',1000]])->whereBetween('create_time',$time_arr)->order('create_time desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['game_title'] = SGameType::where(['gameid'=>$val['game_id']])->value('title');
                $val['win_coin'] = $val['bet'] - $val['win'];
            }
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }
        $uid = $request->get('uid');
        return $this->fetch(__FUNCTION__,compact('uid'));
    }



}
