<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

class PlayerSpin extends Base
{
    protected $notNeedRight = [];

    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * @param Request $request
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            $uid = $this->request->get('uid', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);

            $data = Db::name('gameserver_gamelog')
                ->where(function($query) use ($uid){
                    if($uid){
                        $query->whereIn('account_id', $uid);
                    }
                })
                ->whereTime('create_time', 'between', [$start, $end])
                ->group("LEFT(FROM_UNIXTIME(create_time), 10)")
                ->field("LEFT(FROM_UNIXTIME(create_time), 10) day, count(1) total_spin, count(if(game_id = 614, 1, null)) manual_total, count(if(game_id = 614, null, 1)) auto_total")
                ->order('day desc')
                ->select()->toArray();
            $this->success('', '', $data);
        }
        return $this->fetch();
    }

    public function percentage(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);

            $subSql = Db::name('gameserver_gamelog')
                ->whereTime('create_time', 'between', [$start, $end])
                ->group('account_id')
                ->field('account_id, count(1) total_spin, count(if(game_id = 614, 1, null)) manual_total, count(if(game_id = 614, null, 1)) auto_total')
                ->having('total_spin > 50')
                ->buildSql();
            
            $data = Db::table($subSql . ' a')
                ->field("count(1) total,
                    count(if(a.auto_total/a.total_spin * 100 > 0 and a.auto_total/a.total_spin * 100 <= 10, 1, null)) '0~10%',
                    count(if(a.auto_total/a.total_spin * 100 > 10 and a.auto_total/a.total_spin * 100 <= 20, 1, null)) '10~20%',
                    count(if(a.auto_total/a.total_spin * 100 > 20 and a.auto_total/a.total_spin * 100 <= 30, 1, null)) '20~30%',
                    count(if(a.auto_total/a.total_spin * 100 > 30 and a.auto_total/a.total_spin * 100 <= 40, 1, null)) '30~40%',
                    count(if(a.auto_total/a.total_spin * 100 > 40 and a.auto_total/a.total_spin * 100 <= 50, 1, null)) '40~50%',
                    count(if(a.auto_total/a.total_spin * 100 > 50 and a.auto_total/a.total_spin * 100 <= 60, 1, null)) '50~60%',
                    count(if(a.auto_total/a.total_spin * 100 > 60 and a.auto_total/a.total_spin * 100 <= 70, 1, null)) '60~70%',
                    count(if(a.auto_total/a.total_spin * 100 > 70 and a.auto_total/a.total_spin * 100 <= 80, 1, null)) '70~80%',
                    count(if(a.auto_total/a.total_spin * 100 > 80 and a.auto_total/a.total_spin * 100 <= 90, 1, null)) '80~90%',
                    count(if(a.auto_total/a.total_spin * 100 > 90 and a.auto_total/a.total_spin * 100 <= 100, 1, null)) '90~100%'
                ")->select()->toArray();

            $result = [];
            $idx = 0;
            $total = $data[0]['total'];
            if($total>0){
                foreach ($data[0] as $key => $value) {
                    if($key == 'total') continue;
                    $idx++;
                    $arr = [
                        'idx' => $idx,
                        "name" => $key,
                        "nu" => $value,
                        "percentage" => round($value/$total * 100, 2) . '%'
                    ];

                    $result[] = $arr;
                }
            }
            $this->success('', '', $result);
        }
        return $this->fetch();
    }
}