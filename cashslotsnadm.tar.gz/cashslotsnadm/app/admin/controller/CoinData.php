<?php

namespace app\admin\controller;

use app\admin\model\StatCoinLog;
use app\admin\model\StatGame;
use app\admin\model\StatGameData;
use app\admin\model\StatGameDetail;
use app\admin\model\StatGameDetailToday;
use app\admin\model\StatGamePlayLog;
use app\admin\model\StatMarketDay;
use think\App;
use think\Exception;
use think\Request;
use app\admin\model\StatUserCoinData;

/***
 * 金币数据
 * Class AccountData
 * @package app\admin\controller
 */
class CoinData extends Base
{
    protected $notNeedRight = ['ajax_release_data', 'ajax_coin_log'];
    /***
     * 金币数据首页
     * @method
     * @param Request $request
     * @return string
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time')) ?: 0;
            if (!$start_time) {
                $day = $request->get('day', 30);
                $start_time = strtotime(date('Y-m-d',strtotime("-{$day} days")));
            }
            $end_time = strtotime($request->get('end_time')) ?: time();

            $time_arr = [$start_time,$end_time];
            $limit = $request->get('limit');
            $log_list = StatCoinLog::whereBetween('create_time',$time_arr)->order('create_time desc')->paginate($limit);

            $time_arr = [$start_time,$end_time];
            $detail_list = StatGameDetail::field("sum(allbet) as allbet, FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times")->whereBetween('create_time',$time_arr)->group("FROM_UNIXTIME(create_time,'%Y-%m-%d')")->order('create_time desc')->paginate($limit);
            $detail_list_today = StatGameDetailToday::field("sum(allbet) as allbet, FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times")->whereBetween('create_time',$time_arr)->group("FROM_UNIXTIME(create_time,'%Y-%m-%d')")->order('create_time desc')->select();
            foreach ($detail_list as &$val) {
                foreach ($detail_list_today as $value) {
                    if (date('Y-m-d', strtotime($val['create_times'])) == date('Y-m-d', strtotime($value['create_times']))) {
                        $val['allbet'] += $value['allbet'];
                    }
                }
            }
            $list = [];

            foreach ($log_list as &$value){
                $value['back'] = 0 ;
                foreach ($detail_list as $val){
                    if ( date('Y-m-d',strtotime($value['create_time'])) == date('Y-m-d',strtotime($val['create_times']))){
                        $value['back'] = $val['allbet']+ $value['backend_reback_coin'];
                    }
                }
                $value['difference'] = number_format($value['all_coin_count']-$value['back'],0);
                if((int)$value['back']){
                    $value['back'] = number_format($value['back'],0);
                }
                if ((int)$value['all_coin_count']){
                    $value['all_coin_count'] = number_format($value['all_coin_count'],0);
                }
                $list[] = $value ;
            }
            echo json_encode(['code'=>200,'data'=>$list,'count'=>$log_list->total(),'msg'=>lang('return_success')]);exit;
        }
        return $this->fetch();
    }
//    public function
    public function ajax_release_data(Request $request){
        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time')) ?: 0;
            if (!$start_time) {
                $day = $request->get('day', 30);
                $start_time = strtotime(date('Y-m-d',strtotime("-{$day} days")));
            }

            $end_time = strtotime($request->get('end_time')) ?: time();
            $limit = $request->get('limit/d');

            $time_arr = [$start_time,$end_time];
            $detail_list = StatCoinLog::whereBetween('create_time',$time_arr)->order('create_time desc')->paginate($limit);
            $detail_lists = StatGameDetail::field("sum(allbet) as allbet,sum(allwin) as allwin, FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times")->whereBetween('create_time',$time_arr)->group("FROM_UNIXTIME(create_time,'%Y-%m-%d')")->order('create_time desc')->paginate($limit);
            $detail_list_today = StatGameDetailToday::field("sum(allbet) as allbet,sum(allwin) as allwin,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times")->whereBetween('create_time',$time_arr)->group("FROM_UNIXTIME(create_time,'%Y-%m-%d')")->order('create_time desc')->select();
            foreach ($detail_lists as &$v) {
                foreach ($detail_list_today as $value) {
                    if (date('Y-m-d', strtotime($v['create_times'])) == date('Y-m-d', strtotime($value['create_times']))) {
                        $v['allbet'] += $value['allbet'];
                        $v['allwin'] += $value['allwin'];
                    }
                }
            }

            foreach ($detail_list as &$val){
                foreach ($detail_lists as $v){
                    if ( date('Y-m-d',strtotime($val['create_time'])) == date('Y-m-d',strtotime($v['create_times']))){
                        $val['sonspin_coin_count'] = number_format($v['allwin'],0);
                    }
                }
                $val['friends_fb_coin'] = number_format($val['friends_fb_coin'],0);
                $val['bonus_fb_coin'] = number_format($val['bonus_fb_coin'],0);
                $val['gametask_coin_count'] = number_format($val['gametask_coin_count'],0);
                $val['backend_send_coin'] = number_format(intval($val['backend_send_coin']),0);
                $val['login_coin_count'] = number_format(intval($val['login_coin_count']),0);
                $val['sign_coin_count'] = number_format(intval($val['sign_coin_count']),0);
                $val['turntable_coin_count'] = number_format(intval($val['turntable_coin_count']),0);
                $val['bind_fb_coin_count'] = number_format(intval($val['bind_fb_coin_count']),0);
                $val['first_login_coin_count'] = number_format(intval($val['first_login_coin_count']),0);
                $val['level_up_coin_count'] = number_format(intval($val['level_up_coin_count']),0);
                $val['guagua_coin_count'] = number_format(intval($val['guagua_coin_count']),0);
                $val['bankruptcy_coin_count'] = number_format(intval($val['bankruptcy_coin_count']),0);
                $val['mission_coin_count'] = number_format(intval($val['mission_coin_count']),0);
                $val['firendsend_coin_count'] = number_format(intval($val['firendsend_coin_count']),0);
                $val['firendprize_coin_count'] = number_format(intval($val['firendprize_coin_count']),0);
                $val['mail_coin_count'] = number_format(intval($val['mail_coin_count']),0);
                $val['special_coin_count'] = number_format(intval($val['special_coin_count']),0);
                $val['all_coin_count'] = number_format(intval($val['all_coin_count']),0);
                $val['club_send'] = number_format(intval($val['club_send']),0);
                $val['quest_send'] = number_format(intval($val['quest_send']),0);
                $val['card_lottery_coin_count'] = number_format(intval($val['card_lottery_coin_count']),0);
                $val['egg_coin_count'] = number_format(intval($val['egg_coin_count']),0);
                $val['card_month_coin_count'] = number_format(intval($val['card_month_coin_count']),0);
                $val['luack_redbag_coin_count'] = number_format(intval($val['luack_redbag_coin_count']),0);
                $val['hero_card_coin_count'] = number_format(intval($val['hero_card_coin_count']),0);
                $val['bingo_reward_coin_count'] = number_format(intval($val['bingo_reward_coin_count']),0);
                $val['bingo_shop_coin_count'] = number_format(intval($val['bingo_shop_coin_count']),0);
                $val['bingo_rank_coin_count'] = number_format(intval($val['bingo_rank_coin_count']),0);
            }
            echo json_encode(['code'=>200,'data'=>$detail_list->items(),'count'=>$detail_list->total(),'msg'=>lang('return_success')]);exit;
        }
    }

    public function ajax_coin_log(Request $request){
         if ($request->isAjax()){
             $start_time = strtotime($request->get('start_time')) ?: 0;
             if (!$start_time) {
                 $day = $request->get('day', 30);
                 $start_time = strtotime(date('Y-m-d',strtotime("-{$day} days")));
             }
             $limit = $request->get('limit/d',15);
             $end_time = strtotime($request->get('end_time')) ?: time();

             $time_arr = [$start_time,$end_time];
             $detail_list = StatGameDetail::field("sum(allbet) as allbet, FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times")->whereBetween('create_time',$time_arr)->group("FROM_UNIXTIME(create_time,'%Y-%m-%d')")->order('create_time desc')->paginate($limit);
             $detail_list_today = StatGameDetailToday::field("sum(allbet) as allbet, FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times")->whereBetween('create_time',$time_arr)->group("FROM_UNIXTIME(create_time,'%Y-%m-%d')")->order('create_time desc')->select();
             $log_list = StatCoinLog::field('create_time,backend_reback_coin')->whereBetween('create_time',$time_arr)->order('create_time desc')->select();

             foreach ($detail_list as &$val){
                 $val['backend_reback_coin'] = intval($val['backend_reback_coin']);
                 foreach ($detail_list_today as $value){
                     if (date('Y-m-d',strtotime($val['create_times'])) == date('Y-m-d',strtotime($value['create_times']))){
                         $val['allbet'] += $value['allbet'];
                     }
                 }
                 $val['create_time'] = date('Y-m-d',strtotime($val['create_time']));
                 foreach ($log_list as $value){
                     if (date('Y-m-d',strtotime($val['create_times'])) == date('Y-m-d',strtotime($value['create_time']))){
                         $val['backend_reback_coin'] = $value['backend_reback_coin'];
                         $val['allbet'] += $value['backend_reback_coin'];
                     }
                 }
                 $val['allbet'] = number_format(intval($val['allbet']),0);
                 $val['backend_reback_coin'] = number_format(intval($val['backend_reback_coin']),0);
             }
             echo json_encode(['code'=>200,'data'=>$detail_list->items(),'count'=>$detail_list->total(),'msg'=>lang('return_success')]);exit;

         }
    }
    /***
     *  金币统计数据
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function dauCoin(Request $request){
        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time')) ?: strtotime('-30 days');
            $end_time = strtotime($request->get('end_time')) ?: time() ;
            $limit = $request->get('limit/d',15);
            $list = StatUserCoinData::whereBetween('create_time',[$start_time,$end_time])->order('create_time desc')->paginate($limit) ;
            return json(['code' => 200,'data'=>$list->items(), 'count' => $list->total(), 'msg' => lang('return_success')]);
        }
        return $this->fetch();
    }
    /***
     *  注册用户携带金币统计数据
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function dnuCoin(Request $request){
        return $this->fetch();
    }
}