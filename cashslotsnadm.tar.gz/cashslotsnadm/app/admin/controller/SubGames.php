<?php

namespace app\admin\controller;

use app\admin\model\StatGameData;
use app\admin\model\StatGameDetail;
use app\admin\model\StatGameDetailToday;
use app\admin\model\StatGamePlayLog;
use app\admin\model\StatMarketDay;
use think\App;
use think\Request;

/***
 * 数值统计数据
 * Class AccountData
 * @package app\admin\controller
 */
class SubGames extends Base
{
    public function index(Request $request){
        if ($request->get('is_export')){
            $start_time = strtotime($request->get('start_time')) ?: 0;
            if (!$start_time) {
                $day = $request->get('day', 30);
                $start_time = strtotime(date('Y-m-d',strtotime("-{$day} days")));
            } else {

            }
            $end_time = strtotime($request->get('end_time')) ?: time();
//            $end_time = strtotime($request->get('end_time')." 23:59:59") ?: time();

            $time_arr = [$start_time,$end_time];

            $detail_list = StatGameDetail::whereBetween('create_time', $time_arr)->order('create_time desc')->select();

            // $today_list = StatGameDetailToday::whereBetween('create_time', $time_arr)->order('create_time desc')->select();

            // foreach ($detail_list as &$value){
            //     foreach ($today_list as $val){
            //         if ($value['game_id'] == $val['game_id'] && $value['create_time'] == $val['create_time']){
            //             $value['allusers'] += $val['allusers'];
            //             $value['allbet'] += $val['allbet'];
            //             $value['allwin'] += $val['allwin'];
            //             $value['alltimes'] += $val['alltimes'];
            //             $value['bet_one'] += $val['bet_one'];
            //             $value['bet_two'] += $val['bet_two'];
            //             $value['bet_free'] += $val['bet_free'];
            //             $value['bet_other'] += $val['bet_other'];
            //         }
            //     }
            // }
            $list_key =[
                'create_time',
                'game_title',
                'allusers',
                'allbet',
                'allwin',
                'alltimes',
                'bet_one',
                'bet_two',
                'bet_other',
            ];
            $lang_key = [
                'create_time' =>'日期',
                'game_title' =>'游戏名称',
                'allusers' =>'游戏人数',
                'allbet' =>'总下注',
                'allwin' =>'总发放',
                'alltimes' =>'游戏次数',
                'bet_one' =>'首次登录',
                'bet_two' =>'升级',
                'bet_other' =>'刮刮乐',
            ];
            $this->exportExcel($list_key,$detail_list,'子游戏数据',$lang_key);
        }
        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time')) ?: 0;
            if (!$start_time) {
                $day = $request->get('day', 30);
                $start_time = strtotime(date('Y-m-d',strtotime("-{$day} days")));
            } else {

            }
            $end_time = strtotime($request->get('end_time')) ?: time();

            $time_arr = [$start_time,$end_time];
            $limit = $request->get('limit/d');

            $detail_list = StatGameDetail::whereBetween('create_time', $time_arr)->order('create_time desc')->paginate($limit);
            $allber = 0;
            // $today_list = StatGameDetailToday::whereBetween('create_time', $time_arr)->order('create_time desc')->select();

            // foreach ($detail_list as &$value){

            //     foreach ($today_list as $val){
            //         if ($value['game_id'] == $val['game_id'] && $value['create_time'] == $val['create_time']){
            //             $value['allusers'] += $val['allusers'];
            //             $value['allbet'] += $val['allbet'];
            //             $value['allwin'] += $val['allwin'];
            //             $value['alltimes'] += $val['alltimes'];
            //             $value['bet_one'] += $val['bet_one'];
            //             $value['bet_two'] += $val['bet_two'];
            //             $value['bet_free'] += $val['bet_free'];
            //             $value['bet_other'] += $val['bet_other'];
            //             $allber +=$value['allbet'];
            //         }
            //     }
            // }
            return json(['code' => 200,'data' => $detail_list->items(), 'count' => $detail_list->total(), 'msg' => lang('return_success')]);
        }
        return $this->fetch();
    }
}