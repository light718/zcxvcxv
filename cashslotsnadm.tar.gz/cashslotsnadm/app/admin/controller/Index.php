<?php
namespace app\admin\controller;

use app\admin\model\CoinsPlayer;
use app\admin\model\DUser;
use app\admin\model\PoolTax;
use app\admin\model\SActivityReward;
use app\admin\model\ScoreLog;
use app\admin\model\SQuest;
use app\admin\model\SShop;
use app\admin\model\SShopOrder;
use app\admin\model\SSign;
use app\admin\model\StatMarketDay;
use app\admin\model\StatMarketDayAndroid;
use app\admin\model\StatMarketDayIos;
use app\admin\model\StatUserOnlineData;
use app\BaseController;
use org\Auth;
use org\Curl;
use org\RedisKey;
use think\App;
use think\Lang;
use think\Request;
use think\facade\View;

class Index extends Base
{
    protected $notNeedRight = ['online_nums','get_online_count', 'index', 'map'];

    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * 首页
     * @return string
     */
    public function index()
    {
        return View::fetch();
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }

    //统计数据
    public function getMarketData()
    {
        $data = [
            'dnu' => 0,
            'dau' => 0,
            'paynum' => 0,
            'payamount' => 0,
        ];
        $paynum = SShopOrder::getTodayPaynum();
        $payamount = SShopOrder::getTodayPayAmount();
        $data['dnu'] = DUser::getDNU();
        $data['dau'] = DUser::getDAU();
        $data['paynum'] = $paynum;
        $data['payamount'] = $payamount;
        return $data;
    }

    /***
     * 框架首页
     * @return string
     */
    public function map(){
        $market = $this->getMarketData();
        $data = $this->getWelcome();
        $auth = new Auth();
        $groups = $auth->getGroups(session('user_info.id'));
        $groups = collect($groups)->toArray();
        if (!$groups || $groups[0]['id'] == 1){

            return View::fetch(__FUNCTION__,compact('market','data'));
        }else{
            return View::fetch('welcome',compact('market','data'));
        }
    }

    /****
     * 在线人数
     * @param Request $request
     */
    public function online_nums(Request $request){
        if ($request->isAjax()){
            $curl = new Curl();

//            online_nums
            $online_data = $curl->getOnlineData();
            $nums = $online_data['all'];

            $fb_user_count = $online_data['logintype']['fb'];
            $guest_user_count = $online_data['logintype']['guest'];
            $google_user_count = $online_data['logintype']['google'];
            $ios_count = $online_data["platform"]['ios'];
            $android_count = $online_data['platform']['android'];
            $country_data = [];
            $redis = $this->getRedisObj();
            $online_all_country_list = $redis->sMembers("online_all_country_list");
            foreach ($online_all_country_list as $country) {
                $country_data[] = [
                    'key' => $country,
                    'val' => $redis->sCard('online_country_' . $country),
                ];
            }
            $data = [];
            $data['online_nums'] = $nums;
            $data['fb_online_nums'] = $fb_user_count;
            $data['google_online_nums'] = $google_user_count;
            $data['guest_online_nums'] = $guest_user_count;
            $data['ios_online_nums'] = $ios_count;
            $data['android_online_nums'] = $android_count;
            $data['country'] = $country_data;
            $this->jsonReturn(EXIT_SUCCESS,'',$data);
        }
    }

    /***
     *  获取在线人数
     */
    public function get_online_count(){
        $now_time = time();
        $start_time = strtotime(date("Y-m-d 00:00:00"));
        $list = StatUserOnlineData::field("FROM_UNIXTIME(create_time,'%Y-%m-%d %H:%i') as dates ,online_user_count,fb_user_count,ios_count,android_count,google_user_count,guest_user_count,country_data")->whereBetween('create_time',[$start_time,$now_time])->select();
        $list = collect($list)->toArray();
        $x_data = array_column($list, 'dates');
        $y_data = array_column($list, 'online_user_count');
        $this->jsonReturn(EXIT_SUCCESS, lang('return_success'), compact('x_data', 'y_data'));
    }

    /*** 获取数据
     * @return array
     */
    public function getWelcome()
    {
        $result = [
            'today_agent_total_add_coin' => '0.0000',
            'yesterday_agent_total_add_coin' => '0.0000',
            'today_player_total_add_coin' => '0.0000',
            'yesterday_player_total_add_coin' => '0.0000',
            'today_player_total_sub_coin' => '0.0000',
            'yesterday_player_total_sub_coin' => '0.0000',
            'today_total_consume_coin' => '0.0000',
            'yesterday_total_consume_coin' => '0.0000',
            'today_total_win_coin' => '0.0000',
            'yesterday_total_win_coin' => '0.0000',
            'total_reload' => '0.0000',
            'total_withdraw' => '0.0000',
            'total_win' => '0.0000'
        ];

        $todayStartTime = strtotime(date('Y-m-d'));
        $todayEndTime = $todayStartTime + 86399;
        $yesterdayStartTime = strtotime(date('Y-m-d', strtotime('-1 day')));
        $yesterdayEndTime = $yesterdayStartTime + 86399;


        // 今日直属代理的上分合计
        // 昨日直属代理的上分合计

        $result['today_agent_total_add_coin'] = ScoreLog::getDirectlyAgentTotalReload(\session('user_info.id'), $todayStartTime, $todayEndTime);
        $result['yesterday_agent_total_add_coin'] = ScoreLog::getDirectlyAgentTotalReload(\session('user_info.id'), $yesterdayStartTime, $yesterdayEndTime);

        // 今日玩家总上分
        // 昨日玩家总上分
        // 今日玩家总下分
        // 昨日玩家总下分
        $today = ScoreLog::getAllPlayerTotalScore($todayStartTime, $todayEndTime);
        $yesterday = ScoreLog::getAllPlayerTotalScore($yesterdayStartTime, $yesterdayEndTime);

        $result['today_player_total_add_coin'] = $today['reload'];
        $result['yesterday_player_total_add_coin'] = $yesterday['reload'];;
        $result['today_player_total_sub_coin'] = $today['withdraw'];
        $result['yesterday_player_total_sub_coin'] = $yesterday['withdraw'];

        // 今日总抽水
        // 昨日总抽水
        $result['today_total_consume_coin'] = PoolTax::getTotalPoolTax($todayStartTime, $todayEndTime);
        $result['yesterday_total_consume_coin'] = PoolTax::getTotalPoolTax($yesterdayStartTime, $yesterdayEndTime);

        // 今日总赢钱
        // 昨日总赢钱
        $result['today_total_win_coin'] = CoinsPlayer::getTotalWin($todayStartTime, $todayEndTime);
        $result['yesterday_total_win_coin'] = CoinsPlayer::getTotalWin($yesterdayStartTime, $yesterdayEndTime);

        // 历史总上分
        // 历史总下分
        // 历史总赢钱
        $totalScore = ScoreLog::getAllPlayerTotalScore();
        $result['total_reload'] = $totalScore['reload'];
        $result['total_withdraw'] = $totalScore['withdraw'];
        $result['total_win'] = CoinsPlayer::getTotalWin();
        return $result;
    }

    /***
     * 按天查看
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function show_other_day(Request $request){
        $channel = $request->get('channel');
        $start_time = date('Ymd',strtotime($request->get('start_time')));
        $end_time = date('Ymd',strtotime($request->get('end_time')));
        $limit = $request->get('limit/d',15);
        switch ($channel){
            case 1:
                $model = new StatMarketDayAndroid();
                break;
            case 2:
                $model = new StatMarketDayIos();
                break;
            default:
                $model = new StatMarketDay();
                break;
        }
        $list = $model->whereBetween('day',[$start_time,$end_time])->order('create_time desc')->paginate($limit);
        foreach ($list as &$val){
            $val['day'] = date('Y-m-d',strtotime($val['day']));
            if ($val['dnu']){
                $val['avg_spin'] = floor($val['reg_spin_count'] /$val['dnu'] ) ;
            }else{
                $val['avg_spin'] = 0 ;
            }
        }
        return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
    }

    /***
     *  七日签到
     */
    public function signConfig(){
        $list = SSign::getList();
        $redis_obj = $this->getRedisObj();
        foreach ($list as &$value){
            $is_force = $redis_obj->get(RedisKey::SEVEN_FORCE_PROPMT);
            $value['is_force'] = '否';
            if ($is_force){
                $value['is_force'] = '是';
            }
            $value['sort'] = $redis_obj->get(RedisKey::SEVEN_FORCE_SROT.$value['id'])?:0;
        }
        return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
    }

    /***
     * 七日签到编辑
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function config_edit(Request $request){
        $id = $request->get('id');
        $redis_obj = $this->getRedisObj();

        if ($request->isPost()){
            $post_param = $request->post();
            $update_data = [
                'count' => $post_param['count'],
                'upCount' => $post_param['upCount']
            ];
            SSign::where(compact('id'))->update($update_data);
            $redis_obj->set(RedisKey::SEVEN_FORCE_PROPMT,$post_param['is_force']);
            $redis_obj->set(RedisKey::SEVEN_FORCE_SROT.$id,$post_param['sort']);
            $this->success(lang('return_success'));
        }
        $res = SSign::where(compact('id'))->find();
        $res['is_force'] = $redis_obj->get(RedisKey::SEVEN_FORCE_PROPMT);
        $res['sort'] = $redis_obj->get(RedisKey::SEVEN_FORCE_SROT.$id)?:0;

        return $this->fetch(__FUNCTION__,compact('res','id'));
    }

    public function render_bonus(Request $request){
        $redis_obj = $this->getRedisObj();
        $bonus_list = json_decode( $redis_obj->get('bonuslist'),true);
        $daily_bonus = ['1'=>'Daily Bonus','2'=>'online Bonus','3'=>'daily task','4'=>'mission task','5'=>'fb share','6'=>'stamp','11 '=>'Quest task'];
        $bonus_arr  = [];
        foreach ($bonus_list as $key=>$value){
            $name = isset($daily_bonus[$value]) ? $daily_bonus[$value] :"";
            $bonus_arr[] = [
                'name'=>$name,
                'id'=>$value,
                'sort'=>$key+1,
                'name_cn'=>lang($name),
                'is_open' => '显示'
            ];
        }
        $exist_arr = array_column($bonus_arr,'id');
        foreach ($daily_bonus as $k=>$val){
            if (!in_array(intval($k),$exist_arr)){
                $bonus_arr[] = [
                    'name'=>$val,
                    'id'=>$k,
                    'sort'=>(int)$k + 1,
                    'name_cn'=>lang($val),
                    'is_open' => '不显示'
                ];
            }
        }
        return json(['code'=>200,'data'=>$bonus_arr,'count'=>count($bonus_arr),'msg'=>lang('return_success')]);

    }

    /***
     * 商城商品列表
     * @return \think\response\Json
     */
    public function render_goods(Request $request){
        $condition = [];
        $limit = $request->get('limit/d',15);
        $goods_list = SShop::where($condition)->paginate($limit);
        foreach ($goods_list as &$value){
            $value->status_text = $value->status_text;
            $value->is_discount = $value->is_discount;
        }
        return json(['code'=>200,'data'=>$goods_list->items(),'count'=>$goods_list->total(),'msg'=>lang('return_success')]);
    }

    /***
     * 物品编辑
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function goods_edit(Request $request){
        $id = $request->get('id');
        if($request->isPost()){
            $update_data = $request->param();
            $res = SShop::where(compact('id'))->update($update_data);
            if ($res){
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_fail'));
            }
        }
        $res =  SShop::where(compact('id'))->find();
        return $this->fetch(__FUNCTION__,compact('id','res'));
    }

    /***
     * 任务配置界面
     * @param Request $request
     * @return \think\response\Json
     */
    public function render_mission(Request $request){
        $limit = $request->get('limit/d',15);
        $condition = [];
        $mission_list = SQuest::where($condition)->paginate($limit);
        return json(['code'=>200,'data'=>$mission_list->items(),'count'=>$mission_list->total(),'msg'=>lang('return_success')]);
    }

    /***
     *
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function render_active(Request $request){
        $limit = $request->get('limit/d',15);
        $condition = [];
        $mission_list = SActivityReward::where($condition)->paginate($limit);
        foreach ($mission_list as &$value){
            $value['activity_goods'] = $value->rewards_goods;
            $value['activity_num'] = $value->rewards_num;
        }
        return json(['code'=>200,'data'=>$mission_list->items(),'count'=>$mission_list->total(),'msg'=>lang('return_success')]);

    }

    /***
     * 获取语言包
     * @return \think\response\Json
     */
    public function langs(Request $request){

        header('Content-Type: application/javascript');
        header("Cache-Control: public");
        header("Pragma: cache");

        $offset = 30 * 60 * 60 * 24; // 缓存一个月
        header("Expires: " . gmdate("D, d M Y H:i:s", time() + $offset) . " GMT");

        $controllername = input("controllername");
        //默认只加载了控制器对应的语言名，你还根据控制器名来加载额外的语言包
        $this->loadlang($controllername,$request);

        return json(['code'=>200,'lang'=>\think\facade\Lang::get()]);
    }
}
