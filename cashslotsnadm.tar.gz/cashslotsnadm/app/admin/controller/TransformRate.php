<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

class TransformRate extends Base
{
    protected $notNeedRight = [];

    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * @param Request $request
     */
    public function index(Request $request){
        if ($request->isPost()){
            $dayRange = $this->request->post('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $end = $end . ' 23:59:59';

            //所有用户
            $act_list = [
                'startApp' => '启动app人数',
                'loadHotUpdate' => '开始热更',
                'hotupdate_pro_check' => '检查热更',
                'hotupdate_pro_enter' => '进入热更',
                'hotupdate_pro_checkresult' => '热更开始',
                'endLoadHot' => '热更结束',
                'showLogin' => '到达登陆页'
            ];
            $all_user = Db::connect('game')->name('d_app_log')
                ->whereTime('ts', 'between', [$start, $end])
                ->where("act in ('" . implode("','", array_keys($act_list)) . "')")
                ->group('act')
                ->field('act,count(distinct ddid) c')
                ->select()->toArray();

            $table_all_user = array_column($all_user, 'c', 'act');
            $all_user = array_column($all_user, null, 'act');
            $data = [];
            foreach ($act_list as $key => $value) {
                $arr = [
                    "name" => $value,
                    "value" => isset($all_user[$key]) ? $all_user[$key]['c'] : 0
                ];
                $data[1][] = $arr;
            }


            //新用户 stat_new_players_direction 统计表中查
            $start = date('Ymd', strtotime($start));
            $end = date('Ymd', strtotime($end));
            $new_user = Db::name('stat_new_players_direction')
                ->where('day', 'between', [$start, $end])
                ->field('sum(startapp) startApp, sum(loadhotupdate) loadHotUpdate, sum(hotupdate_pro_check) hotupdate_pro_check, sum(hotupdate_pro_enter) hotupdate_pro_enter, sum(hotupdate_pro_checkresult) hotupdate_pro_checkresult, sum(endloadhot) endLoadHot, sum(showlogin) showLogin')
                ->select()->toArray()[0];

            foreach ($new_user as $key => $value) {
                $arr = [
                    "name" => $act_list[$key],
                    "value" => (int)$value
                ];
                $data[0][] = $arr;
            }

            return json([$data, [$new_user + ['title' => '新用户'], $table_all_user + ['title' => '所有用户']]]);
        }
        return $this->fetch();
    }

}