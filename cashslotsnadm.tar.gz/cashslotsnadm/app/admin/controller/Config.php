<?php
namespace app\admin\controller;

use think\App;
use think\Exception;
use think\Request;
use app\admin\model\StatUserCoinData;
use think\facade\Cache;
use think\cache\driver\Redis;
use think\facade\Config as cfg;
/***
 * 金币数据
 * Class AccountData
 * @package app\admin\controller
 */
class Config extends Base
{
    public function index(Request $req)
    {
        $redis = Cache::store('redis')->handler();
        $json['server_config']="0";
        $json['server_time']="00:00:00 - 00:00:00";
        $json['en']="0";
        $json['pt']="0";
        $json['es']="0";
        $json['server_date']="";
        //json 是默认值 
        $data =  $redis->get('server_config');
        if($data){
           $this->assign('result',json_decode($data),true);
           return $this->fetch();
        }else{
           $redis->set('server_config',json_encode($json)); 
           $this->assign('result',$json);
           return $this->fetch();
        }
        
    }
    
    public function getOnlineData(){
             $redis = Cache::store('redis')->handler();
             $data = $redis->get('server_config');
        return json(['code'=>200,'data'=>json_decode($data,true),'msg'=>lang('return_success')]);
    }
    
    public function save(Request $req)
    {
        $param = $req->post();
        $json['server_config'] = $param['server_config'] ?? 0;
        $json['en'] = $param['en'] ?? 0;
        $json['es'] = $param['es'] ?? 0;
        $json['pt'] = $param['pt'] ?? 0;
        $json['server_time'] = $param['server_time'];
        $json['server_date'] = $param['server_date']??null;
         $redis = Cache::store('redis')->handler();
         if($redis->set('server_config',json_encode($json))){
             $this->success();
         }
         $this->error();
         
    }
}

