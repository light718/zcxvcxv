<?php
namespace app\admin\controller;

use app\admin\model\AppPush as model;
use app\admin\model\AppPushContent as modelContent;
use org\Curl;
use think\App;
use think\Request;

/***
 * APP推送
 * Class Email
 * @package app\admin\controller
 */
class AppPush extends Base
{
    protected $notNeedRight = ['add', 'edit', 'delete', 'add_content', 'edit_content', 'delete_content'];
    protected $cond = [
        1 => "quest活动是否通关（4级解锁，解锁后的3天内）",
        2 => "功能是否全部解锁完",
        3 => "子游戏是否全部解锁",
        4 => "daily mission是否已解锁&未完成（9级解锁）",
        5 => "daily bonus是否未签到",
        6 => "是否已解锁砸金蛋&未砸蛋（27级解锁）",
        7 => "FB是否绑定",
        8 => "激励升级——不需要判断",
        9 => "bingo是否已解锁（21级解锁）",
        10 => "卡牌系统是否已解锁（35级解锁）",
        11 => "是否有好友获得大奖",
        12 => "幸运翻卡是否已解锁（35级解锁）",
        13 => "是否领取过刮刮乐",
        14 => "玩家是否已进行了排行榜押注",
        15 => "早晚安提醒——不需要判断",
        16 => "用户是否有新朋友",
        17 => "抽卡是否已解锁（35级解锁）",
        18 => "当天store bonus是否未领取（商城银锤子，16级解锁才有）",
        19 => "玩家是否未达到20级（提示送免费金猪）",
        20 => "离线奖励——不需要判断",
        21 => "提示玩家升级领取奖励——不需要判断",
        22 => "骑士的探险已解锁（21级解锁）",
    ];

    /*** app消息推送列表
     * @return string
     */
    public function index(Request $request){
        $condition = [];
        if ($grade = $request->get('grade','','trim')){
            $condition[] = ['grade','=', $grade];
        }
        if ($login = $request->get('login','','trim')){
            $condition[] = ['login','=', $login];
        }        
        if ($week = $request->get('week','','trim')){
            $condition[] = ['week','=', $week];
        }
        if ($push_time = $request->get('push_time','','trim')){
            $condition[] = ['push_time','=', $push_time];
        }
        if ($cond = $request->get('cond','','trim')){
            $condition[] = ['cond','=', $cond];
        }

        $list = model::where($condition)->paginate(15);
        $data = modelContent::select()->toArray();
        $data = array_column($data, NUll, 'id');
        foreach($list as &$value){
            $content_ids = explode(',', $value['error_content_ids']);
            $arr = [];
            foreach($content_ids as $k){
                $arr[] = @$data[$k];
            }
            $value['error_content_ids'] = $arr;

            $content_ids = explode(',', $value['correct_content_ids']);
            $arr = [];
            foreach($content_ids as $k){
                $arr[] = @$data[$k];
            }
            $value['correct_content_ids'] = $arr;
        }
        return $this->fetch(__FUNCTION__,['list'=>$list, 'cond' => $this->cond]);
    }

    //添加
    public function add(Request $request){
        if ($request->isPost()){
            $data = $request->param();
            $model = new model();
            $result = $model->save($data);

            if ($result){
                $this->record('新增','app推送消息编号（%s）',[$model->id], false);
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_error'));
            }
        }
        $data = modelContent::select();
        $result = [];
        foreach($data as $value){
            $result[] = [
                "name" => $value['title'],
                "value" => $value['id'],
                "content" => $value['content']
            ];
        }
        return $this->fetch(__FUNCTION__, ['result' => $result, 'cond' => $this->cond]);
    }

    //编辑
    public function edit(Request $request){
        $id = $request->param('id');
        $model = new model();
        $row = $model->find($id);
        if(!$row){
            $this->error();
        }

        if ($request->isPost()){
            $data = $request->param();
            $re = $model->update($data);
            if ($re){
                $this->record('更新','app推送消息编号（%s）',[$id], false);
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_error'));
            }
        }

        $data = modelContent::select();
        $result = [];
        foreach($data as $value){
            $result[] = [
                "name" => $value['title'],
                "value" => $value['id'],
                "content" => $value['content']
            ];
        }
        $this->assign('row', $row);
        return $this->fetch(__FUNCTION__, ['row' => $row, 'result' => $result, 'cond' => $this->cond]);
    }


    //删除
    public function delete(Request $request){
        $id =$request->get('id');

        if (!$id){
            $this->error(lang( 'please_input_id'));
        }
        $delete_re = model::where(compact('id'))->delete();
        if ($delete_re){
            $this->record('删除','app推送消息删除编号（%s）',[$id],false);
            $this->success(lang('return_success'));
        }else{
            $this->error(lang('return_error'));
        }
    }



      /*** 消息内容列表
     * @return string
     */
    public function index_content(Request $request){
        $condition = [];
        if ($id = $request->get('id','','trim')){
            $condition[] = ['id', '=', $id];
        }
        if ($type = $request->get('type','','trim')){
            $condition[] = ['type','=', $type];
        }
        if ($content = $request->get('content','','trim')){
            $condition[] = ['content', 'like', '%' . $content . '%'];
        }
        if ($title = $request->get('title','','trim')){
            $condition[] = ['title', 'like', '%' . $title . '%'];
        }
        $list = modelContent::where($condition)->paginate(15);
        $this->assign('id', $id);
        $this->assign('type', $type);
        $this->assign('content', $content);
        $this->assign('title', $title);
        return $this->fetch(__FUNCTION__,['list'=>$list]);
    }

    //添加
    public function add_content(Request $request){
        if ($request->isPost()){
            $data = $request->param();

            $model = new modelContent();
            $result = $model->save($data);

            if ($result){
                $this->record('新增','app推送消息内容编号（%s）',[$model->id], false);
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_error'));
            }
        }

        return $this->fetch(__FUNCTION__);
    }

    //编辑
    public function edit_content(Request $request){
        $id = $request->param('id');
        $model = new modelContent();
        $row = $model->find($id);
        if(!$row){
            $this->error();
        }

        if ($request->isPost()){
            $data = $request->param();
            $re = $model->update($data);
            if ($re){
                $this->record('更新','app推送消息内容编号（%s）',[$id], false);
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_error'));
            }
        }

        $this->assign('row', $row);
        return $this->fetch(__FUNCTION__);
    }


    //删除
    public function delete_content(Request $request){
        $id =$request->get('id');

        if (!$id){
            $this->error(lang( 'please_input_id'));
        }
        $delete_re = modelContent::where(compact('id'))->delete();
        if ($delete_re){
            $this->record('删除','app推送消息内容删除编号（%s）',[$id],false);
            $this->success(lang('return_success'));
        }else{
            $this->error(lang('return_error'));
        }
    }
}