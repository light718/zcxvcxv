<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/3/11
 * Time: 11:02
 */

namespace app\admin\controller;

use app\admin\model\DHerocard;
use app\admin\model\DUser;
use app\admin\model\ResurrectionCardLog;
use app\admin\model\SGame;
use app\admin\model\SGameType;
use app\admin\model\SHerocard;
use app\admin\model\StatGame;
use app\admin\model\StatGames;
use app\admin\model\SysSetting;
use app\admin\model\CardRedpack;
use org\Curl;
use org\EncryptString;
use org\RedisKey;
use think\App;
use think\db\Query;
use think\facade\Lang;
use think\Request;

class GameOpreate extends Base
{
    protected $notNeedRight = ['edit', 'getOnlineData','editStatus','batchTag','sub_game_edit', 'resurrection_card_add'];

    /***
     * 子游戏开关
     * @return string
     */
    public function index()
    {
        $list = SysSetting::whereIn('skey', ['game_swl_content', 'game_swl_contenten', 'game_swl', 'game_swl_ip', 'game_switch'])->select()->toArray();
        $result = [];
        foreach ($list as $value) {
            $result[$value['skey']] = $value['sval'];
        }
        return $this->fetch(__FUNCTION__, compact('result'));
    }

    /***
     * 编辑子游戏
     * @method post
     * @param Request $request
     */
    public function edit(Request $request)
    {
        if ($request->isPost()) {
            $post_param = $request->post();
            $gameSwitch = $post_param['game_switch'];
            $gameSwl = $post_param['game_swl'];
            $gameSwlIp = $post_param['game_swl_ip'];
            $gameSwlContent = $post_param['game_swl_content'];
            $gameSwlContenten = $post_param['game_swl_contenten'];
            if ($gameSwitch == '') {
                return $this->jsonReturn(EXIT_ERROR,\lang('return_empty'),[]);
            }
            $str = "game_switch[@kv@]{$gameSwitch}[@par@]game_swl[@kv@]{$gameSwl}[@par@]game_swl_ip[@kv@]{$gameSwlIp}[@par@]game_swl_content[@kv@]{$gameSwlContent}[@par@]game_swl_contenten[@kv@]{$gameSwlContenten}";
            $encrypt_string = new EncryptString();

            $str = $encrypt_string->encode($str);
            $_parstr = $encrypt_string->decode($str);
            $_parstr = array_filter(explode("[@par@]", $_parstr));

            $_datas = [];

            foreach ($_parstr as $_par) {
                list($_key, $_val) = explode("[@kv@]", $_par);
                $_datas[$_key] = $_val;
            }
            foreach ($post_param as $k => $value) {
                $res = SysSetting::where(['skey' => $k])->update(['sval' => $value]);
            }
            $curl = new Curl();
            $redis = $this->getRedisObj();
            $result = $curl->requestSetting($_datas,$redis);

//            $this->_resetRedisSystemParameters();
            if ($result) {
                $this->record('编辑', '游戏开关 ', [session('user_info.id')], false);
                $this->success(lang('return_success'));
            } else {
                $this->error(lang('return_fail'));
            }
        }
        $result = [];
        return $this->fetch(__FUNCTION__, compact('result'));
    }

    /***
     * 子游戏开关
     * @return string
     */
    public function sub_game(Request $request)
    {
        $tag_arr = [
            ['id' => 0, 'name' => lang('game_tag_0')],
            ['id' => 1, 'name' => lang('game_tag_1')],
            ['id' => 2, 'name' => lang('game_tag_2')],
            ['id' => 3, 'name' => lang('game_tag_3')],
        ];
        $s_game_type = SGameType::select();
        $level_arr = [];
        foreach ($s_game_type as $value){
            $level_arr[$value['gameid']] = $value['level'];
        }
        if ($request->isAjax()) {
            $curl = new Curl();
            $lang = Lang::defaultLangSet() == 'zh-cn' ? 1 : 2;
            $uniq = 1;
            $list = $curl->getGameLists($lang, $uniq);
            $total = count($list);
            foreach ($list as &$value) {
                if ($value['status'] == 1) {

                    $value['status_text'] = lang('game_status_normal');
                } else {
                    $value['status_text'] = lang('game_status_close');
                }
                foreach ($tag_arr as $v) {
                    $v['id'] == $value['tag'] && $value['tag_name'] = $v['name'];
                }
                $value['level'] = isset($level_arr[$value['id']]) ? $level_arr[$value['id']] : '';
            }
            if ($list) {
                return json(['code' => 200, 'data' => $list, 'count' => $total, 'msg' => lang('return_success')]);
            } else {
                return json(['code' => 500, 'data' => $list, 'count' => $total, 'msg' => lang('return_fail')]);
            }
        }

        return $this->fetch();
    }

    /***
     * 子游戏开关编辑
     * @method post
     * @param Request $request
     * @return string
     */
    public function sub_game_edit(Request $request)
    {
        $id = $gameid = $request->get('id');
        $data = [];
        $type = 1;
        $uniq = 1;
        $lang = Lang::defaultLangSet() == 'zh-cn' ? 1 : 2;
        $uniq != 1 && $uniq = 0;
        $curl = new Curl();
        if ($request->isPost()) {

            $gametype = $request->post('type');
            $level = $request->post('level');
            $tag = $request->post('tagHot');
            $ord = $request->post('ord');
            $update_data = [
                'gametype' => $gametype,
                'level' => $level,
            ];
            // 更新游戏等级
            $game_re = SGameType::where(compact('gameid'))->find();

            $res = SGameType::where(compact('gameid'))->update($update_data);
            // 更新标签 以及状态


            $result1 = $curl->pushGameTag($gameid,$tag);
            if ($result1){
                $tag = lang('game_tag_'.$tag);
                $this->record("游戏标签修改","（%s）标签更改更改为（%s）",[$game_re['title'],$tag]);
            }

            $result2 = $curl->putGameLevel($gameid, $level);
            if ($result2){
                $this->record("解锁等级修改","修改（%s）等级（%s） 更改为（%s）",[$game_re['title'],$game_re['level'],$level]);
            }
            $result3 = $curl->putGameSort($gameid, 2 ,$ord);
            if ($result3 ){
                $this->record("修改游戏排序","修改（%s）的排序修改为（%s）",[$game_re['title'],$ord]);
            }
            if ($res || $result1 || $result2 || $result3){
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_fail'));
            }
        } else {
            $gameLists = $curl->getGameLists($lang, $uniq);
            if ($type > 0) {
                $data['game_list'] = [];
                foreach ($gameLists as $row) {
                    if ($type == $row['type']) {
                        $data['game_list'][] = $row;
                    }
                }
            } else {
                $data['game_list'] = $gameLists;
            }
            $result = [];
            foreach ($gameLists as $key => $val) {
                if ($val['id'] == $id) {
                    $res = SGameType::where(compact('gameid'))->find();
                    $val['level'] = $res['level'];
                    $val['game_type'] = $res['gametype'];
                    $result = $val;
                }
            }
            return $this->fetch(__FUNCTION__, compact('id', 'result'));
        }
    }

    /**
     * 服务器列表
     * @return string
     */
    public function severList(Request $request)
    {
        $curl = new Curl();
        $list = $curl->getGameServerList();
        $data = [];
        $status = [
            0 => lang('server_list_status_start'),
            1 => lang('server_list_status_run'),
            2 => lang( 'server_list_status_full'),
            3 => lang( 'server_list_status_weihu'),
            4 => lang( 'server_list_status_stop')
        ];

        foreach ($list['servers'] as $type => $server) {
            foreach ($server as $row) {
                $tmp = [];
                $tmp['type'] = $type;
                $tmp['name'] = $row['name'];
                $tmp['status'] = $status[$row['status']];
                $data[] = $tmp;
            }
        }
        return $this->fetch(__FUNCTION__,compact('data'));
    }

    /***
     * 获取在线数据
     * @return string
     */
    public function getOnlineData()
    {
        $curl = new Curl();
        $num = $curl->getOnlineUser();
        return $this->jsonReturn(EXIT_SUCCESS, lang('return_success'), compact('num'));
    }

    public function editStatus(Request $request){

        if ($this->request->isAjax()) {
            $gameId = $request->post('id');
            $status = $request->post('status');
            $params = array(
                'id' => $gameId
            );
            $curl = new Curl();
            $result = $curl->pushSystemSettingGameStatus($gameId);
            if ($result) {
                if ($status == 1) {
                    $post_param = [];
                    $data = $curl->reloadsess($post_param);
                    $this->record('游戏开关-小游戏开关', "（%s）关服成功", [$gameId]);
                } else {
                    $this->record('游戏开关-小游戏开关', "（%s）开服成功", [$gameId]);
                }
                return $this->jsonReturn(EXIT_SUCCESS,\lang('return_success'));
            } else {
                if ($status == 1) {
                    $this->record('游戏开关-小游戏开关', "（%s）关服失败", [$gameId]);
                } else {
                    $this->record('游戏开关-小游戏开关', "（%s）开服失败", [$gameId]);
                }
                return $this->jsonReturn(EXIT_ERROR,\lang('return_FAIL'));
            }
        }

    }

    /***
     * 批量打标签
     * @param Request $request
     */
    public function batchTag(Request $request){
        if ($request->isAjax()){
            $id_arr = $request->post('ids');
            $tagid = $request->post('tagid');
            if (is_array($id_arr)){
                $ids = implode(',',$id_arr);
            }else{
                $ids = $id_arr;
            }
            $curl = new Curl();
            $result = $curl->pushGameTag($ids,$tagid);
            if ($result){
                $this->record('标签', '批量打标签');
                return $this->jsonReturn(EXIT_SUCCESS,\lang('return_success'));
            }
            return $this->jsonReturn(EXIT_ERROR,\lang('return_FAIL'));

        }
    }
    public function _resetRedisSystemParameters() :bool
    {
        //游戏数据统计 -- 获取所有游戏列表
        $_games = $this->getGameList(1);
        $redis = $this->getRedisObj();
        if (is_array($_games) && count($_games) && isset($_games[0]['id'])) {
            foreach ($_games as $g) {
                //将游戏列表缓存到redis
                $redis->hMSet("{bigbang}:game:list:hash:" . $g['id'], [
                    'type' => $g['type'],
                    'name' => $g['name'],
                    'id' => $g['id'],
                    'status' => $g['status'],
                    'ord' => $g['ord'] ?? '0',
                    'collector' => $g['collector'] ?? '0',
                    'tag' => $g['tag']
                ]);
                $res = StatGames::where(['game_id'=>$g['id']])->field();
                $stat_game = new StatGames();
                if (!$res){
                    $data =  [
                        'game_id'=> $g['id'],
                        'num_favorite'=> $g['collector'] ?? '0'
                    ];
                    $stat_game->save($data);
                }else{
                    $data =  [
                        'num_favorite'=> $g['collector'] ?? '0'
                    ];
                    $stat_game->where(['game_id'=>$g['id']])->save($data);
                }
            }

        }

        //获取系统参数数组
        $_settings = $this->getSystemPars();
        if (
            $redis->set(RedisKey::SYSTEM_SETTING, json_encode($_settings, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))/* 设置OpenApiGameUrl */) {
            return true;
        }

        return false;
    }

    /***
     * 卡牌红包发放
     * @param Request $request
     * @return string
     */
    public function redpack(Request $request){
        if ($request->isAjax()){
            $condition = [];
            $limit = $request->get('limit/d',15);
            $start_time = strtotime($request->param('start_time')) ? :strtotime("-1 month");
            $end_time = strtotime($request->param('end_time')) ? :time();
            $uid = $request->param('keyword');
            $condition[] = ['create_time','between',[$start_time,$end_time]];
            if ($uid){
                $condition[] = ['uid|card_id','=',$uid];
            }
//            ->paginate($limit);
            $lists = CardRedpack::with(['sender'=>function(Query $query){
                $query->field('id,username');
            }])->where($condition)->order('create_time desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['sender_username'] = $val['sender']['username'];
                $val['card_name'] = SHerocard::where(['cardid'=>$val['card_id']])->value('name');
                $val['username'] = DUser::where(['uid'=>$val['uid']])->value('playername');
                $val['status_text'] = $val->status_text;
            }
            return json(['code'=>200, 'data'=>$lists->items(), 'count' => $lists->total(),'msg'=>\lang('return_success') ]);
        }
        return $this->fetch();
    }

    /***
     * 编辑修改
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function redpack_add(Request $request){
        $id = $request->get('id');
        if ($request->isPost()){
            $uid = $request->post('uid');
            $card_id = $request->post('card_id');
            $account_re = DUser::where(compact('uid'))->find();
            if (!$account_re){
                return $this->jsonReturn(EXIT_ERROR,\lang('account not exists'));
            }
            $card_re = SHerocard::where(['cardid'=>$card_id])->find();
            if (!$card_re){
                return $this->jsonReturn(EXIT_ERROR,\lang('herocard not exists'));
            }
            $post_param = $request->post();
            if($id){
                $update_data = [
                    'uid'=> $uid,
                    'card_id'=>$card_id,
                    'send_time' => strtotime($post_param['send_time'])
                ];
                $update_re = CardRedpack::where(compact('id'))->update($update_data);
                $this->record(\lang('cardredpack edit'),"%s 修改红包发放记录%s",[session('user_info.username'),$id]);
            }else{
                $data  = [
                    'uid'=> $uid,
                    'card_id'=>$card_id,
                    'send_time' => strtotime($post_param['send_time']),
                    'create_id' => session('user_info.id'),
                ];
                $this->record(\lang('cardredpack add'),"%s 新增红包发放记录 ",[session('user_info.username')]);
                $card_pack = new CardRedpack();
                $update_re = $card_pack->save($data);
            }
            if ($update_re){

                return $this->jsonReturn(EXIT_SUCCESS,\lang('return_success'));
            }else{
                return $this->jsonReturn(EXIT_ERROR,\lang('return_fail'));
            }
        }
        $result = CardRedpack::where(compact('id'))->find();
        return $this->fetch(__FUNCTION__,compact('id','result'));
    }

    /***
     * 红包 删除
     * @param Request $request
     * @return string
     */
    public function redpack_del(Request $request){
        $id = $request->param('id');
        $del_re = CardRedpack::where(compact('id'))->delete();
        if ($del_re){
            $this->record(\lang('cardredpack delete'),"%s 删除红包发放记录 %s",[session('user_info.username'),$id]);
            return $this->jsonReturn(EXIT_SUCCESS,\lang('return_success'));
        }
        return $this->jsonReturn(EXIT_ERROR,\lang('return_fail'));
    }

    /***
     * 加复活卡
     * @param Request $request
     * @return string
     *
     */
    public function resurrection_card_add(Request $request){
        if ($request->isPost()){
            $uid = $request->post('uid');
            $num = $request->post('num');
            $type = $request->post('type');

            $user_re = DUser::where(compact('uid'))->find();
            if (!$user_re){
                return $this->jsonReturn(EXIT_ERROR,\lang('user_not_exists'));
            }
            $data = compact('uid','num');
            $curl = new Curl();
            $curl->resurrectionAdd($data, $type ? 'cardgift' : 'bosscardgift');
            $insert_data = [
                'uid' => $uid,
                'num' => $num,
                'type' => $type,
                'create_id'=>session('user_info.id')
            ];
            $card_log = new ResurrectionCardLog();
            $card_log->save($insert_data);
            $this->record('发送复活卡',"给用户ID: %s 发送 %s 张复活卡",[$uid,$num]);
            return $this->jsonReturn(EXIT_SUCCESS,\lang('return_success'));
        }

        return $this->fetch();

    }

    /***
     * 历史记录
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function resurrection_card(Request $request){
        if ($request->isAjax()){
            $condition = [];
            $keyword = $request->get('keyword');
            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');
            $end_time = strtotime($request->get('end_time'))? : time();
            if ($keyword){
                $condition[] = ['uid','=',$keyword];
            }

            $condition[] = ['create_time','between',[$start_time,$end_time]];
            $limit = $request->get('limit/d',15);

            $lists = ResurrectionCardLog::with(['sender'=>function(Query $query){
                $query->field('id,username');
            }])->where($condition)->order('create_time desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['username'] = DUser::where(['uid'=>$val['uid']])->value('playername');
                $val['send_username'] = $val['sender']['username'];
                $val['type'] = $val['type'] == 1 ? '复活卡' : '超级复活卡';
            }
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total()]);
        }
        return $this->fetch();

    }

}