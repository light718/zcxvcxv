<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/3/2
 * Time: 17:30
 */
namespace app\admin\controller;

use app\admin\model\SysRollingnotice;
use think\App;
use think\Exception;
use think\Request;

class LanternConfig extends Base
{

    protected $notNeedRight = ['edit', 'delete'];

    /***
     *  跑马灯配置列表
     */
    public function index(Request $request){
        $param = $request->param();
        $condition  = [];
        $status = input('status',-1);
        if ($status >= 0){
            $condition[] = ['status','=',$status];
        }
        if ($contenten = input('keyword','','trim')){
            $condition[] = ['content','like',"%".$contenten."%"];
        }
        $time = time();
        $list = SysRollingnotice::where($condition)->order('create_time desc')->paginate(15);

        foreach ($list as &$value){
            $value['start_time'] = strtotime($value['start_time']);
            $value['next_time'] = strtotime($value['next_time']);
            $value['revoke_time'] = strtotime($value['revoke_time']);
            if ($value['status'] == 1) {
                try{
                    $times = ceil(($value['revoke_time'] - $value['start_time']) / ($value['interval'] * 60));

                }catch (Exception $exception){

                }
                $status = lang('marquee_status_30')  . '<br>' . $times . '/' . $value['counts'];
            } else {
                if ($value['start_time'] > $time) {
                    $status = lang('marquee_status_00');
                } else if ($value['start_time'] + (($value['counts'] - 1) * $value['interval'] * 60) < $time) {
                    $status = lang( 'marquee_status_20') . '<br>' . $value['counts'] . '/' . $value['counts'];
                } else {
                    $times = ceil(($time - $value['start_time']) / ($value['interval'] * 60));
                    $status = lang('marquee_status_10') . '<br>' . ($times) . '/' . $value['counts'];
                }
            }
            $value['status_text'] = $status;
        }
        return $this->fetch(__FUNCTION__,compact('list','contenten'));
    }

    /***
     * 编辑跑马灯配置
     * @param Request $request
     * @return string
     */
    public function edit(Request $request){
        $id = $request->get('id');
        if ($request->isPost()){
            $post_param = $request->param();
            $now_time = time();
            if($id){
                $update_data = [
                    'content' =>$post_param['content'],
                    'contenten' =>$post_param['contenten'],
                    'start_time' => strtotime($post_param['start_time'])?: $now_time,
                    'counts' => $post_param['counts'],
                    'interval' => $post_param['interval'],
                    'status' =>$post_param['status'],
                    'next_time' => strtotime($post_param['start_time']) + $post_param['interval'],
                ];

                $save_re = SysRollingnotice::where(compact('id'))->update($update_data);
            }else{
                $save_data = [
                    'content' =>$post_param['content'],
                    'contenten' =>$post_param['contenten'],
                    'start_time' => strtotime($post_param['start_time'])?: $now_time,
                    'counts' => $post_param['counts'],
                    'interval' => $post_param['interval'],
                    'status' =>$post_param['status'],
                    'next_time' => strtotime($post_param['start_time']) + $post_param['interval'],
                    'create_time'=>$now_time,
                ];
                $model = new SysRollingnotice();
                $save_re = $model->save($save_data);
            }
            if ($save_re){
                $this->success(lang('success'));
            }else{
                $this->error(lang('error'));
            }
        }



        $result = SysRollingnotice::find($id);
        return $this->fetch(__FUNCTION__,compact('id','result'));
    }

    /***
     * 删除跑马灯配置
     * @param Request $request
     */
    public function delete(Request $request){
        $id = $request->get('id');
        $res = SysRollingnotice::where(compact('id'))->delete();
        $this->record('删除','删除（%s）跑马灯配置',[session('user_info.username')],false);
        if ($res){
            $this->success(lang('success'));
        }else{
            $this->error(lang('error'));
        }
    }
}