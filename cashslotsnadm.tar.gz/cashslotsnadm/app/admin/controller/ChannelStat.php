<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

/***
 * 渠道类型数据统计
 */
class ChannelStat extends Base
{
    protected $notNeedRight = [];
    private $channelArr = [1 => '游客', 10 => '谷歌', 11 => '苹果', 12 => 'FB', 13 => '华为'];


    /*** 渠道ltv
     * @return string
     */
    public function channel_ltv(Request $request){
        $condition = [];
        if ($channel = $request->get('channel','','trim')){
            $condition[] = ['channel','=', $channel];
        }
  
        if($startTime = $request->get('start_time', false)){
            list($start, $end) = explode(' - ', $startTime);
            $start = date('Ymd', strtotime($start));
            $end = date('Ymd', strtotime($end . ' 23:59:59'));
            $condition[] = ['day', 'between', [$start, $end]];
        }
        $list = Db::name('stat_channel_day')->where($condition)
                ->order('day', 'desc')
                ->paginate(15);

        $data = $list->items();
        $stat = ['day' => '平均值', 'channel' => '全部'];
        foreach($data as $key => &$value){
            $value['channel'] = $this->channelArr[$value['channel']];
            foreach($value as $k => $v){
                if ($k != 'day' && $k != 'channel' ) {
                    if (isset($stat[$k])) {
                        $stat[$k] = $stat[$k] + $v;
                    }else{
                        $stat[$k] = $v;    
                    }
                }
            }
        }
        $cnt = count($data);
        if ($cnt > 0) {
            foreach ($stat as $k => &$value) {
                if ($k != 'day' && $k != 'channel' ) {
                    $value = number_format($value / $cnt, 2);
                }
            }
            $data[] = $stat;
        }

        return $this->fetch(__FUNCTION__,['list'=>$list, 'data' => $data]);
    }


    /*** 渠道数据列表
     * @return string
     */
    public function channel_list(Request $request){
        $condition = [];
        if ($channel = $request->get('channel','','trim')){
            $condition[] = ['channel','=', $channel];
        }
  
        if($startTime = $request->get('start_time', false)){
            list($start, $end) = explode(' - ', $startTime);
            $start = date('Ymd', strtotime($start));
            $end = date('Ymd', strtotime($end . ' 23:59:59'));
            $condition[] = ['day', 'between', [$start, $end]];
        }

        $list = Db::name('stat_channel_day')->where($condition)
                ->order('day', 'desc')
                ->paginate(15);

        $data = $list->items();
        $stat = ['day' => '数据汇总', 'channel' => '全部'];
        foreach($data as $key => &$value){
            $value['channel'] = $this->channelArr[$value['channel']];
            foreach($value as $k => $v){
                if ($k != 'day' && $k != 'channel' ) {
                    if (isset($stat[$k])) {
                        $stat[$k] = $stat[$k] + $v;
                    }else{
                        $stat[$k] = $v;    
                    }
                }
            }
            $value['dnu_pay_rate'] = $value['dnu_pay_rate']  * 100 . '%';
            $value['pay_rate'] = $value['pay_rate']  * 100 . '%';
            $value['stay1'] = $value['stay1']  * 100 . '%';
            $value['stay3'] = $value['stay3']  * 100 . '%';
            $value['stay7'] = $value['stay7']  * 100 . '%';
        }
        $cnt = count($data);
        if ($cnt > 0) {
            $stat['dnu_pay_rate'] = $stat['dnu_pay_rate'] / $cnt * 100 . '%';
            $stat['pay_rate'] = $stat['pay_rate'] / $cnt * 100 . '%';
            $stat['stay1'] = $stat['stay1'] / $cnt * 100 . '%';
            $stat['stay3'] = $stat['stay3'] / $cnt * 100 . '%';
            $stat['stay7'] = $stat['stay7'] / $cnt * 100 . '%';
            $data[] = $stat;
        }

   
        return $this->fetch(__FUNCTION__,['list'=>$list, 'data' => $data]);
    }

}