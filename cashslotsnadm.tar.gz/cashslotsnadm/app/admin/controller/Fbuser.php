<?php

namespace app\admin\controller;

use think\App;
use think\facade\Db;

/***
 * FB用户
 * Class Fbuser
 * @package app\admin\controller
 */
class Fbuser extends Base
{
    public function index(){
        if($this->request->isajax()){
            $limit = $this->request->get('limit');
            $day = $this->request->get('day', 1);
            if(strpos($day, '-')){
                //时间范围
                $timeRange = [strtotime(explode(' - ', $day)[0]), strtotime(explode(' - ', $day)[1])];
            }else{
                if($day == 1){
                    $timeRange = [strtotime(date('Y-m-d 00:00:00')), time()];
                }else{
                    $timeRange = [date("Y-m-d H:i:s",strtotime("-{$day} day")), time()];
                }
            }

            $list = Db::connect('game')
                ->name('d_user')
                ->where('uid', 'IN', function ($query) {
                   $query->name('d_user_bind ')->where('platform', 12)->field('uid');
                })
                ->whereTime('create_time', 'between', $timeRange)
                ->field("uid,playername,usericon,coin, level, from_unixtime(create_time) as create_time,create_platform, from_unixtime(login_time) as login_time")
                ->paginate($limit);

            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total()]);
        }

        return $this->fetch();
    }
}