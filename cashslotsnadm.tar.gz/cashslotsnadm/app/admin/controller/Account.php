<?php
namespace app\admin\controller;

use app\admin\model\AccountGroup;
use app\admin\model\AccountScoreLog;
use app\admin\model\AuthGroupAccess;
use think\App;
use app\admin\model\Account as AccountModel;
use think\Request;

class Account extends Base
{
    protected $notNeedRight = ['edit', 'grant', 'delete'];
    protected $account_model;
    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->account_model =  new AccountModel();
    }

    /***
     * 我的账户列表首页
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function index(Request $request){
        $condition = [];
        if ($username = input('name')){
            $condition[] = ['username','like',"%".$username."%"];
        }
        if ($type = input('type')){
            $condition[] = ['agent','=',$type];
        }else{
            $condition[] = ['agent','=',2];
        }
        $condition[] = ['status','=',AccountModel::STATUS_NORMAL];
        $limit = $request->get('limit/d');
        $list = $this->account_model->with(['access'])->where($condition)->paginate($limit);
        foreach ($list as &$value){
            if ($value['access']){
                $value['access_name'] = AccountGroup::where(['id'=>$value['access']['group_id']])->value('name');
            }else{
                $value['access_name'] = lang('not_grant');
            }
        }
        return $this->fetch(__FUNCTION__,compact('list'));
    }

    /**
     * 添加/添加 管理员
     * @return mixed
     */
    public function edit(Request $request)
    {
        $id = $request->get('id');
        $is_account = session('user_info.id');
        if ($request->isPost()){
            $id = $request->post('id');
            $post_param =  $request->post();
            $group_id = $this->request->post('group_id');
            $account_re = \app\admin\model\Account::where(compact('id'))->find();
            $group_access = new AuthGroupAccess();
            $is_exist = $group_access->where(['uid'=>$id])->find();
            $password = $request->post('password');
            $confirm_password = $request->post('confirm_password');
            if ( $password != trim($confirm_password)){
                $this->error(lang('password_can_empty'));
            }
            if($is_exist){
                $re  =$group_access->where(['uid'=>$id])->update(compact('group_id'));
            }else{
                $uid = $id;
                $re = $group_access->save(compact('group_id','uid'));
            }

            if ($id){


                $params = [];

                if(!empty($password)) {
                    $post_param['password'] = md5(strtolower(trim($account_re['username'])).md5($password).$account_re['salt']);
                    $params['password'] = $post_param['password'];
                }
                $post_param['nickname'] && $params['nickname'] =  $post_param['nickname'];
                $post_param['phone'] && $params['phone'] = $post_param['phone'];
                $post_param['remark'] && $params['remark'] =  $post_param['remark'];

                $update_re = $this->account_model->where(compact('id'))->update($params);
//                if ($update_re) {
                    $this->record('代理管理', "编辑代理（%s）成功", [$account_re['username']]);
                    $this->success(lang('return_success'));
//                } else {      //只修改权限组只会修改权限组使用表 账户表不会修改  注释点判断
//                    $this->record('代理管理', "编辑代理（%s）失败", [$account_re['username']]);
//                    $this->error(lang('error'));
//                }
            }else{
                $salt = rand(111111,999999);
                $params = array(
                    'region_id' => 0,
                    'prefix_username' => '',
                    'username' => $post_param['username'],
                    'password' => md5(strtolower(trim($post_param['username'])).md5($password).$salt),
                    'nickname' => $post_param['nickname'],
                    'coin' => $request->post('coin',0),
                    'phone' => $post_param['phone'],
                    'remark' => $post_param['remark'],
                    'ipaddr' => $this->request->ip(),
                    'salt'=>  $salt,
                    'parent_id' => session('user_info.id'),
                    'parent_agent_first_id' => session('user_info.parent_agent_first_id')
                );
                if ($this->account_model->where(['username'=>$params['username']])->find()){
                    $this->error(lang('account_exists'));
                }
                if (false){
                    $result = $this->requestApi('/account/general', 'POST', $params);
                }

                $post_param =  $request->post();
                $post_param['agent'] = 2;
                $post_param['password'] =  $params['password'];
                $post_param['coin'] =  $params['coin'];
                $post_param['parent_id'] = 10000;
                $post_param['salt'] = $salt;
                $this->account_model->save($post_param);
                $group_id = $this->request->post('group_id');
                $group_access = new AuthGroupAccess();
                $uid = $this->account_model->id;
                $re = $group_access->save(compact('group_id','uid'));
                $this->success('操作成功');
            }
        }

        $account = $this->account_model->with(['access','getParents','getLastParent'])->where(compact('id'))->find();

        $rule_list = AccountGroup::select()->toArray() ;

        return $this->fetch('edit',compact('account','rule_list','id'));
    }

    /***
     * 授权
     * @return string
     */
    public function grant($id){

        $rule_list = AccountGroup::select()->toArray() ;
        if ($this->request->isPost()){
            $group_id = $this->request->post('group_id');
            $group_access = new AuthGroupAccess();
            $is_exist = $group_access->where(['uid'=>$id])->find();
            if($is_exist){
                $re  =$group_access->where(['uid'=>$id])->update(compact('group_id'));
            }else{
                $uid = $id;
                $re = $group_access->save(compact('group_id','uid'));
            }
            if ($re){
                $this->success(lang('success'));
            }else{
                $this->error(lang('error'));
            }
        }
        $account = \app\admin\model\Account::where(compact('id'))->with(['access'])->find();
        return $this->fetch(__FUNCTION__,compact('rule_list','account','id'));
    }

    /***
     * 修改密码
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function changPwd(Request $request){
        if ($request->isPost()){
            $param = $request->post();
            $account_re = \app\admin\model\Account::where(['id'=>\session('user_info.id')])->find();
            if ($account_re['password'] != md5($account_re['username'].md5($param['old_pwd']).$account_re['salt'])){
                $this->error(lang('password_error'));
            }
            if ($param['password'] != $param['confirm_password']){
                $this->error('password_check_error');
            }
            $update_data = [
                'password' => AccountModel::getUserPwdById('',$account_re['username'],$param['password'],$account_re['salt'])
            ];
            $update_re = AccountModel::where(['id'=>session('user_info.id')])->update($update_data);
            $this->record('修改', "代理（%s）密码", [$account_re['username']], false);
            if($update_re){
                $this->success(lang('success'));
            }else{
                $this->error(lang('error'));
            }
        }else{
            return $this->fetch();
        }
    }

    /***
     * 上分
     * @param Request $request
     * @return string
     */
    public function top_score(Request $request){
        $id = $request->get('id/d');
        $result = \app\admin\model\Account::where(compact('id'))->find();
        $account_re = \app\admin\model\Account::where(['id'=>session('user_info.id')])->find();
        $post_param = $request->param();
        if ($request->isPost()){
            $coin = abs($post_param['coin']);
            $coin_send = abs($post_param['coin_send']);
            $coin += $coin_send;
            if ($account_re['coin']< $coin && $this->is_agent){
                $this->error(lang('coin_not_enough'));
            }
            $update_re = \app\admin\model\Account::where(compact('id'))->inc('coin',$coin)->update();
            $update_re = \app\admin\model\Account::where(['id'=>session('user_info.id')])->dec('coin',$coin)->update();

            $this->record('上分', "代理（%s）上分", [$result['username']], false);
            $log_data = [
                'coin' => $post_param['coin'],
                'coin_before' => $result['coin'],
                'change_desc' => lang('代理上分'),
                'account_id' => $id,
                'create_id' => session('user_info.id'),
                'coin_send' => $coin_send
            ];
            $insert_re = AccountScoreLog::insertLog($log_data);
            if($update_re){
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_fail'));
            }
        }
        $user_coin = $account_re['coin'];
        return $this->fetch(__FUNCTION__,compact('result','id','user_coin'));
    }

    /***
     * 上分记录
     * @param Request $request
     * @return string|\think\response\Json
     */
    public function score_log(Request $request){
        $id = $request->get('id/d');
        $limit = $request->get('limit/d',15);
        if ($request->isAjax()){
            $log_list = AccountScoreLog::getListById($id,$limit);
            return json(['code'=>200,'msg'=>lang('return_success'),'list'=>$log_list->items(),'total'=>$log_list->total()]);
        }
        return $this->fetch();

    }

    public function delete(Request $request)
    {
        $user = \app\admin\model\Account::where(['id'=>session('user_info.id')])->find();
        if($user['group_id'] != 1) {
            $this->error('权限不足！请联系系统管理员！');
        }

        $id = $request->get('id/d');
        if(!$id) {
            $this->error('参数错误,id不存在');
        }
        $white_list = [1000, 1001, 1024]; //超管不允许禁用
        if(in_array($id, $white_list)) {
            $this->error('此账号不允许禁用');
        }

        $account_re = \app\admin\model\Account::where(['id'=>$id])->find();
        $update_data = [
            'status' => AccountModel::STATUS_FORBIDDEN,
        ];
        $update_re = AccountModel::where(['id'=>$id])->update($update_data);
        $this->record('禁用', "禁止（%s）登录", [$account_re['username']], false);
        if($update_re){
            $this->success(lang('success'));
        }else{
            $this->error(lang('error'));
        }
    }
}