<?php
namespace app\admin\controller;

use app\admin\model\DSysMail;
use app\admin\model\SShopOrder;
use app\admin\model\TestAccount;
use org\Curl;
use think\App;
use think\Request;

/***
 * 邮件管理
 * Class Email
 * @package app\admin\controller
 */
class Payment extends Base
{
    protected $notNeedRight = [];
    public function index(Request $request){
        $condition = [];
        if (($status = $request->get('status',-1 ))>0){
            $condition[] = ['status','=',$status ];
        }
        $test_uids = TestAccount::column('uid');
        $condition[] = ['uid','not in',$test_uids];
        if ($day = $request->get('day')){
            $start_time = strtotime("-{$day} days");
        }else{
            $start_time = strtotime($request->get('start_time'))?:0;
        }
        $end_time = strtotime($request->get('start_time'))?:time();

        $query = SShopOrder::whereBetween('create_time',[$start_time,$end_time])->where($condition)->order('create_time desc');
        if ($request->get('is_export')){
            $list = $query->select()->toArray();
            $arr = ['安卓','ios'];

            foreach ($list as &$data) {
                $data['create_platform_text'] = isset($arr[$data['create_platform']]) ? $arr[$data['create_platform']] : '未知';
                if ($data['login_type'] == 12) {
                    $data['from_channel_text'] = 'Fb';
                } elseif ($data['login_type'] == 10) {
                    $data['from_channel_text'] = 'Google';
                } elseif ($data['login_type'] == 1) {
                    $data['from_channel_text'] = 'Guest';
                } elseif ($data['login_type'] == 11) {
                    $data['from_channel_text'] = 'ios';
                } else {
                    $data['from_channel_text'] = '未知';
                }
                if ($data['status'] == 0) {
                    $data['status_text'] = '未支付';
                } else if ($data['status'] == 1) {
                    $data['status_text'] = '支付中';
                } else if ($data['status'] == 2) {
                    $data['status_text'] = '支付成功';
                } else {
                    $data['status_text'] = '交易关闭';
                }
                if ($data['istest'] == 1){
                    $data['title'] = '[测试]'.$data['title'];
                }
            }
            $list_key = [
                'create_time',
                'title',
                'amount',
                'from_channel_text',
                'status_text',
                'uid',
                'user_level',
                'user_coin'
            ];
            $this->export($list_key,$list);

        }
        if ($request->isAjax()){
            $limit = $request->get('limit/d');

            $list = $query->paginate($limit);
            $arr = ['安卓','ios'];
            foreach ($list as &$data) {
//                $data['create_time'] = date('Y-m-d H:i:s', $data['create_time']);
                $data['create_platform_text'] = isset($arr[$data['create_platform']]) ? $arr[$data['create_platform']] : '未知';
                if ($data['login_type'] == 12) {
                    $data['from_channel_text'] = 'Fb';
                } elseif ($data['login_type'] == 10) {
                    $data['from_channel_text'] = 'Google';
                } elseif ($data['login_type'] == 1) {
                    $data['from_channel_text'] = 'Guest';
                } elseif ($data['login_type'] == 11) {
                    $data['from_channel_text'] = 'ios';
                } else {
                    $data['from_channel_text'] = '未知';
                }
                if ($data['status'] == 0) {
                    $data['status_text'] = '未支付';
                } else if ($data['status'] == 1) {
                    $data['status_text'] = '支付中';
                } else if ($data['status'] == 2) {
                    $data['status_text'] = '支付成功';
                } else {
                    $data['status_text'] = '交易关闭';
                }
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>'']);
        }
        return $this->fetch();

    }

    /***
     * 导出excel
     * @param $list_key key=> 中文value
     * @param $list
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    protected function export($list_key,$list){
        $newExcel = new \PHPExcel();  //
        $phpexcel = $newExcel->getActiveSheet();  //
        $name = '付费数据导出';
        $phpexcel->setTitle($name);
        $newExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('B')->setWidth(100)->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('J')->setWidth(200);
        $key_arr = range("A","Z");
        $newExcel->getActiveSheet()->getColumnDimension('K')->setWidth(200);
        foreach ($list_key as $key =>$value){
            $i = floor($key/26) + 1;
            $phpexcel =  $phpexcel->setCellValue( $key_arr[$key].$i,lang($value));
        }

        $phpexcel->getStyle('B1')->getAlignment()->setWrapText(true);
        foreach ($list as $k => $v){
            $i = 0;
            foreach ($list_key as $kk =>$key_val){
                $phpexcel->setCellValue($key_arr[$i] . ($k + 2), $v[$key_val]."\t");
                $i += 1;
            }
        }
        ob_end_clean();
        header('Content-Type: application/vnd.ms-excel');
        header("Content-Disposition: attachment;filename=" . $name . date('Y-m-d') . '.' . strtolower("xls"));
        header('Cache-Control: max-age=0');
        $res_excel = \PHPExcel_IOFactory::createWriter($newExcel, 'Excel5');
        $res_excel->save('php://output');
    }

}