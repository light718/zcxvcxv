<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/3/2
 * Time: 17:30
 */
namespace app\admin\controller;

use app\admin\model\SysGlobalnotice;
use think\App;
use app\admin\model\Account as AccountModel;
use think\Request;
use org\Curl;
use think\facade\Db;
use think\facade\Cache;

class Abtest extends Base
{
    protected $notNeedRight = ['delete'];
    protected $account_model;

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->account_model = new AccountModel();
    }

    /***
     * 系统公告配置列表
     * @param Request $request
     */
    public function index(Request $request)
    {
        $list = Db::name('abtest_rule')->select()->toArray();

        foreach ($list as $key => &$value) {
            $value['game_player'] = $value['game_player'] == '0' ? '新注册玩家' : ($value['game_player'] == '1' ? '所有玩家' : '老玩家');
            $value['rtp'] = $value['rtp'] == '0' ? '低RTP' : ($value['rtp'] == '1' ? '中RTP' : '高RTP');
            $value['login_pop'] = $value['login_pop'] ? '每次登陆都弹出付费弹窗' : '上线不弹出付费弹窗';
            $value['subgame_pop'] = $value['subgame_pop'] ? '每次登陆第一次进入子游戏都弹出付费弹窗' : '进入子游戏不弹出付费弹窗';
            $value['login_subgame_pop'] = $value['login_subgame_pop'] ? '每次登陆都弹出子游戏推荐弹窗' : '登陆不弹出子游戏推荐弹窗';
            $value['start_time'] = date('Y-m-d H:i:s', $value['start_time']);
            $value['end_time'] = date('Y-m-d H:i:s', $value['end_time']);
            $value['is_use'] = $value['is_use'] ? '是' : '否';
            $value['create_time'] = date('Y-m-d H:i:s', $value['create_time']);
        }

        if($request->isPost()){
            $parms = $request->post();
            try {
                $data = array(
                    'game_player' => $parms['game_player'],
                    'userid_tail' => isset($parms['userid_tail']) && $parms['userid_tail'] ? '[' . $parms['userid_tail'] . ']' : '',
                    'userid' => isset($parms['userid']) && $parms['userid'] ? '[' . $parms['userid'] . ']' : '',
                    'rtp' => $parms['rtp'],
                    'login_pop' => $parms['login_pop'],
                    'subgame_pop' => $parms['subgame_pop'],
                    'login_subgame_pop' => $parms['login_subgame_pop'],
                    'start_time' => strtotime($parms['start_time']),
                    'end_time' => strtotime($parms['end_time']),
                    'create_time' => time()
                );
                $oldData = Db::name('abtest_rule')->where('(start_time <=' . $data['start_time'] .' and end_time >= ' . $data['start_time'] . ') or (start_time <=' . $data['end_time'] .' and end_time >= ' . $data['end_time'] . ')')->select()->toArray();
  
            } catch (\Throwable $e) {
                $this->error($e->getMessage());
            }

            if($data['start_time'] > $data['end_time']){
                $this->error('开始时间大于结束时间');
            }

            if(!empty($oldData)){
                $this->error('存在时间重合数据，添加失败！');
            }

            $result = Db::name('abtest_rule')->insertGetId($data);
            if($result){

                $now = time();
                if($data['start_time'] <= $now && $data['end_time'] >= $now){ //符合当前时间 设置当条规则应用
                    Cache::store('redis')->hmset('abtest', 
                        [
                            'game_player'       => $data['game_player'],
                            'userid'            => $data['userid'],
                            'userid_tail'       => $data['userid_tail'],
                            'rtp'               => $data['rtp'],
                            'login_pop'         => $data['login_pop'],
                            'subgame_pop'       => $data['subgame_pop'],
                            'login_subgame_pop' => $data['login_subgame_pop'],
                            'start_time'        => $data['start_time'],
                            'end_time'          => $data['end_time'],
                        ]
                    );
                
                    if(!$data['userid']) Cache::store('redis')->hdel('abtest', 'userid');
                    if(!$data['userid_tail']) Cache::store('redis')->hdel('abtest', 'userid_tail');
                
                    Db::query('update abtest_rule set is_use = case id when ' . $result . ' then 1 else 0 end');
                }
                $this->success('操作成功');
            }else{  
                $this->error('操作失败');
            }
        }

        return $this->fetch(__FUNCTION__, compact('list'));
    }


    //删除
    public function delete(Request $request){
        $id = $request->get('id');

        if (!$id){
            $this->error(lang( 'please_input_id'));
        }
        $row = Db::name('abtest_rule')->find($id);

        if($request->isPost()){
            $delete_re = Db::name('abtest_rule')->where(compact('id'))->delete();
            if ($delete_re){
                if($row['is_use']){ //删除的是有效规则
                    Cache::store('redis')->del('abtest');
                }
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_error'));
            }

        }
    }
}