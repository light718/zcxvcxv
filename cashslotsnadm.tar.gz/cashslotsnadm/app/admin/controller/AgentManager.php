<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/6/1
 * Time: 15:44
 */

namespace app\admin\controller;
use app\admin\model\AccountGroup;
use app\admin\model\AccountScoreLog;
use app\admin\model\AuthGroupAccess;
use app\admin\model\DUser;
use app\admin\model\GameserverGamelog;
use think\App;
use think\db\Query;
use think\Request;

/***
 * 金币数据
 * Class AccountData
 * @package app\admin\controller
 */
class AgentManager extends Base
{
    protected $account_model;
    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->account_model =  new \app\admin\model\Account();
    }
    /***
     *
     * 金币数据首页
     * @method
     * @param Request $request
     * @return string
     */
    public function index(Request $request)
    {
        $condition = [];

        $limit = $request->get('limit/d');

        $condition['parent_id|parent_agent_first_id'] = session('user_info.id');
        $keyword = $request->get('name');
        if ($keyword){
            $condition['id'] = $keyword;
        }
        $condition['status'] = \app\admin\model\Account::STATUS_NORMAL;
        $list = \app\admin\model\Account::with(['access'])->where($condition)->paginate($limit);
        foreach ($list as &$value){
            if ($value['access']){
                $value['access_name'] = AccountGroup::where(['id'=>$value['group_id']])->value('name');
            }else{
                $value['access_name'] = lang('not_grant');
            }
        }
        $is_third = 1;
        $parent_id = \app\admin\model\Account::where(['id'=>session('user_info.id')])->value('parent_id');
        $parent_ids = \app\admin\model\Account::where(['id'=>$parent_id])->value('parent_id');
        if($parent_ids && $parent_ids != 1000){
            $is_third = 0;
        }
        return $this->fetch(__FUNCTION__,compact('list','is_third'));
    }

    /***
     * 游戏数据
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function game_data(Request $request){
        if ($request->isAjax()){
            $condition = [];
            if ($account_id = $request->get('keyword')){
                $condition['account_id'] = $account_id;
            }
            $limit = $request->get('limit/d',15);

            $create_id = session('user_info.id');

            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');

            $end_time = strtotime($request->get('end_time'))? : time();

            $account_id_arr = AccountScoreLog::where(['create_id'=>$create_id])->where($condition)->whereBetween('createtime',[$start_time,$end_time])->column('distinct account_id');
            $user_list = DUser::whereIn('uid',$account_id_arr)->paginate($limit);
            foreach ($user_list as &$value){
                $value['coin'] = intval($value['coin']);
            }
            return json(['code'=>200,'data'=>$user_list->items(),'count'=>$user_list->total()]);
        }

        return $this->fetch();
    }


    /**
     * 添加/添加 管理员
     * @return mixed
     */
    public function edit(Request $request)
    {
        $id = $request->get('id');
        $is_account = session('user_info.id');
        if ($request->isPost()){
            $id = $request->post('id');
            $post_param =  $request->post();
            $group_id = $this->request->post('group_id');
            $account_re = \app\admin\model\Account::where(compact('id'))->find();
            $group_access = new AuthGroupAccess();
            $is_exist = $group_access->where(['uid'=>$id])->find();
            $password = $request->post('password');
            $confirm_password = $request->post('confirm_password');
            if ( $password != trim($confirm_password)){
                $this->error(lang('password_can_empty'));
            }
            if (empty($post_param['username']) && $account_re){
                $post_param['username'] = $account_re['username'];
            }
            if($is_exist){
                $re  =$group_access->where(['uid'=>$id])->update(compact('group_id'));
            }else{
                $uid = $id;
                $re = $group_access->save(compact('group_id','uid'));
            }

            if ($id){
                $post_param['password'] = md5(strtolower(trim($post_param['username'])).md5($password).$account_re['salt']);
                unset($post_param['confirm_password']);
                $update_re = $this->account_model->where(compact('id'))->update($post_param);
                $params = [];
                $params['username'] = $post_param['username'];
                $params['password'] = $post_param['password'];
                $post_param['nickname'] && $params['nickname'] =  $post_param['nickname'];
                $post_param['phone'] && $params['phone'] = $post_param['phone'];
                $post_param['remark'] && $params['remark'] =  $post_param['remark'];
                if ($update_re) {
                    $this->record('代理管理', "编辑代理（%s）成功", [$post_param['username']]);
                    $this->success(lang('return_success'));
                } else {
                    $this->record('代理管理', "编辑代理（%s）失败", [$post_param['username']]);
                    $this->error(lang('error'));
                }
            }else{
                $salt = rand(111111,999999);
                $params = array(
                    'region_id' => 0,
                    'prefix_username' => '',
                    'username' => $post_param['username'],
                    'password' => md5(strtolower(trim($post_param['username'])).md5($password).$salt),
                    'nickname' => $post_param['nickname'],
                    'coin' => $request->post('coin',0),
                    'phone' => $post_param['phone'],
                    'remark' => $post_param['remark'],
                    'ipaddr' => $this->request->ip(),
                    'salt'=>  $salt,
                    'parent_id' => session('user_info.id'),
                    'parent_agent_first_id' => session('user_info.parent_agent_first_id')
                );
                if ($this->account_model->where(['username'=>$params['username']])->find()){
                    $this->error(lang('account_exists'));
                }


                $post_param =  $params;
                $post_param['group_id'] = $group_id;
                $post_param['agent'] = 2;
                $post_param['password'] =  $params['password'];
                $post_param['coin'] =  $params['coin'];
                $post_param['parent_id'] = session('user_info.id');
                $post_param['parent_agent_first_id'] = session('user_info.parent_agent_first_id');
                $post_param['salt'] = $salt;
                $this->account_model->save($post_param);
                $group_id = $this->request->post('group_id');
                $group_access = new AuthGroupAccess();
                $uid = $this->account_model->id;
                $re = $group_access->save(compact('group_id','uid'));
                $this->success('操作成功');
            }
        }

        $account = $this->account_model->with(['access','getParents','getLastParent'])->where(compact('id'))->find();

        $rule_list = AccountGroup::select()->toArray() ;

        return $this->fetch('edit',compact('account','rule_list','id'));
    }

    /***
     * 游戏用户数据
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function gamelog(Request $request){
        if ($request->isAjax()){
            $keyword = $request->post('keyword');
            $start_time = strtotime($request->get('start_time'))?:strtotime('-30 days');
            $end_time = strtotime($request->get('end_time'))?:time();
            $limit = $request->get('limit/d',15);
            $create_id = session('user_info.id');
            $account_id_arr = AccountScoreLog::where(['create_id'=>$create_id])->column('distinct account_id');
            $condition = [];
            if ($keyword){
                $condition[] = ['account_id','=',$keyword];
            }else{
                $condition[] = ['account_id','in',$account_id_arr];
            }
            $condition[] = ['create_time','between',[$start_time,$end_time]];
            $lists = GameserverGamelog::where($condition)->group('account_id')->order('create_time desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['win_coin'] = intval($val['bet']-$val['win']);
                $val['playername'] = DUser::where(['uid'=>$val['account_id']])->value('playername');
            }
            return json(['code'=>200,'msg'=>lang('return_success'),'data'=>$lists->items(),'count' =>$lists->total()]);
        }
        return $this->fetch();
    }

    /***
     *
     * @param Request $request
     * @return string
     */
    public function delete(Request $request){
        if ($request->isAjax()){
            $account_id = $request->post('account_id');
            $delete_re = \app\admin\model\Account::where(['id'=>$account_id])->update(['status'=>\app\admin\model\Account::STATUS_FORBIDDEN]);
            if ($delete_re){
                $this->success(lang('return_success'));
            }
            $this->error(lang('return_fail'));
        }
        return $this->fetch();
    }

    /***
     * 上分记录
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function score_log(Request $request){
        $condition = [];
        $keyword = $request->get('keyword');
        if ($request->get('is_export/d',0)){
            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');
            if ($keyword){
                $condition['account_id'] = $keyword;
            }
            $end_time = strtotime($request->get('end_time'))?: time();
            $time_arr = [
                $start_time,
                $end_time,
            ];
            $lists = AccountScoreLog::with(['creator'=>function(Query $query){
            }])->where(['create_id'=>session('user_info.id')])->where($condition)->whereBetween('createtime',$time_arr)->order('createtime desc')->select();
            $list_key = [
                'account_id',
                'account_name',
                'coin',
                'coin_send',
                'createtime',
            ];
            $lang_key = [
                'account_id' => lang('account_id'),
                'account_name' => lang('account_name'),
                'coin' => lang('coin_score_log'),
                'coin_send' => lang('coin send'),
                'createtime' => lang('createtime'),
            ];
            foreach ($lists as &$val){
                $val['account_name'] = $val['creator']['username']?:DUser::where(['uid'=>$val['account_id']])->value('playername');
            }
            $this->exportExcel($list_key,$lists,'上分记录',$lang_key);
        }
        if ($request->isAjax()){

            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');
            if ($keyword){
                $condition['account_id'] = $keyword;
            }
            $end_time = strtotime($request->get('end_time'))?: time();
            $time_arr = [
                $start_time,
                $end_time,
            ];
            $limit = $request->get('limit/d',15);
            $lists = AccountScoreLog::with(['creator'=>function(Query $query){
            }])->where(['create_id'=>session('user_info.id')])->where($condition)->whereBetween('createtime',$time_arr)->order('createtime desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['account_name'] = $val['creator']['username']?:DUser::where(['uid'=>$val['account_id']])->value('playername');
            }
            return json(['code'=>200,'msg'=>lang('return_success'),'data'=>$lists->items(),'count' =>$lists->total()]);
        }
        return $this->fetch();
    }

    /***
     * 统计数据
     * @param Request $request
     * @return \think\response\Json
     */
    public function statics_data(Request $request){
        $condition = [];
        $keyword = $request->get('keyword');
        if ($request->get('is_export/d',0)){

            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');

            $end_time = strtotime($request->get('end_time'))?: time();
            $time_arr = [
                $start_time,
                $end_time,
            ];
            if ($keyword){
                $condition['account_id'] = $keyword;
            }
            $lists = AccountScoreLog::field("sum(coin) as coin,sum(coin_send) as coin_send,account_id,createtime")->with(['creator'=>function(Query $query){

            }])->where(['create_id'=>session('user_info.id')])->where($condition)->whereBetween('createtime',$time_arr)->group('account_id')->order('createtime desc')->select();
            $list_key = [
                'account_id',
                'account_name',
                'coin',
                'coin_send'
            ];
            $lang_key = [
                'account_id' => lang('account_id'),
                'account_name' => lang('account_name'),
                'coin' => lang('coin_score_log'),
                'coin_send' => lang('coin send'),
            ];
            foreach ($lists as &$val){
                $val['account_name'] = $val['creator']['username']?:DUser::where(['uid'=>$val['account_id']])->value('playername');
            }
            $this->exportExcel($list_key,$lists,'上分记录统计',$lang_key);

        }
        if ($request->isAjax()){

            $limit = $request->get('limit/d',15);

            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');

            $end_time = strtotime($request->get('end_time'))?: time();

            $time_arr = [
                $start_time,
                $end_time,
            ];
            if ($keyword){
                $condition['account_id'] = $keyword;
            }
            $lists = AccountScoreLog::field("sum(coin) as coin,sum(coin_send) as coin_send,account_id,createtime")->with(['creator'=>function(Query $query){

                }])->where(['create_id'=>session('user_info.id')])->where($condition)->whereBetween('createtime',$time_arr)->group('account_id ')->order('createtime desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['account_name'] = $val['creator']['username']?:DUser::where(['uid'=>$val['account_id']])->value('playername');
            }
            return json(['code'=>200,'msg'=>lang('return_success'),'data'=>$lists->items(),'count' =>$lists->total(),'all_score'=>array_sum(array_column($lists->items(),'coin'))]);
        }
    }

    public function my_log(Request $request){
        $condition = [];
        $condition['create_id'] = session('user_info.id');
        $keyword = $request->get('keyword');
        if ($request->get('is_export/d',0)){
            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');
            $condition['account_id'] = session('user_info.id');
            $end_time = strtotime($request->get('end_time'))?: time();
            $time_arr = [
                $start_time,
                $end_time,
            ];
            $lists = AccountScoreLog::with(['creator'=>function(Query $query){
            }])->where($condition)->whereBetween('createtime',$time_arr)->order('createtime desc')->select();
            $list_key = [
                'account_id',
                'account_name',
                'coin',
                'coin_send',
                'createtime',
            ];
            $lang_key = [
                'account_id' => lang('account_id'),
                'account_name' => lang('account_name'),
                'coin' => lang('coin_score_log'),
                'coin_send' => lang('coin send'),
                'createtime' => lang('createtime'),
            ];
            foreach ($lists as &$val){
                $val['account_name'] = $val['creator']['username']?:DUser::where(['uid'=>$val['account_id']])->value('playername');
            }
            $this->exportExcel($list_key,$lists,'上分记录',$lang_key);
        }
        if ($request->isAjax()){

            $start_time = strtotime($request->get('start_time'))?:strtotime('-1 month');

            $end_time = strtotime($request->get('end_time'))?: time();
            $time_arr = [
                $start_time,
                $end_time,
            ];
            $limit = $request->get('limit/d',15);
            $lists = AccountScoreLog::with(['creator'=>function(Query $query){
            }])->where($condition)->whereBetween('createtime',$time_arr)->order('createtime desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['account_name'] = $val['creator']['username']?:DUser::where(['uid'=>$val['account_id']])->value('playername');
            }
            return json(['code'=>200,'msg'=>lang('return_success'),'data'=>$lists->items(),'count' =>$lists->total()]);
        }
        return $this->fetch();

    }
}