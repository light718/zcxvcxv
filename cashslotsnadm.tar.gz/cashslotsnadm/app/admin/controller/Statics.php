<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/3/2
 * Time: 17:30
 */
namespace app\admin\controller;

use app\admin\model\SShopOrder;
use app\admin\model\StatMarketDay;
use app\admin\model\StatShopOrder;
use think\App;
use app\admin\model\Account as AccountModel;
use think\Request;
use think\facade\Db;

class Statics extends Base
{
    protected $notNeedRight = [];
    protected $account_model;

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->account_model = new AccountModel();
    }

    /***
     * @param Request $request
     */
    public function index(Request $request){
        if ($request->isPost()){

        }
        return $this->fetch();
    }

    /***
     * 次日留存
     * @param Request $request
     */
    public function next_retention(Request $request){

        $is_export = $request->get('is_export');
        $start_times = $request->param('start_time');
        $start_time = explode('~',$start_times);
        if ($start_times){
            $time_arr = [date('Ymd',strtotime($start_time[0])),date('Ymd',strtotime($start_time[1]))];
        }else{
            $time_arr = [date('Ymd',strtotime('-14 days')),date('Ymd')];
        }
        if ($is_export){
            $type = $request->get('type/d',1);
            $list_key = ['create_timess','dnu'];
            if ($type == 1){
                $title = '次日留存';
                $list_key[] = 'stay1';
            }elseif($type == 2){
                $title = '七日留存';
                $list_key[] = 'stay7';
            }else{
                $title = '14日留存';
                $list_key[] = 'stay14';
            }
            $list = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,stay1,stay7,stay14,ltv7,ltv30,dnu,day")->whereBetween('day',$time_arr)->select();

            $list = collect($list)->toArray();
            foreach ($list as &$value){
                $value['stay1'] = ($value['stay1'] *= 100)."%";
                $value['stay7'] = ($value['stay7'] *= 100)."%";
                $value['stay14'] = ($value['stay14'] *= 100)."%";
                $value['create_timess'] = date('Y-m-d',strtotime($value['day']));
            }
            $this->exportExcel(
                $list_key,$list,$title,['create_timess'=>'日期']
            );
            return false;
        }

        $type = $request->post('type');
        $list = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,stay1,stay7,stay14,ltv7,ltv30,dnu,day")->whereBetween('day',$time_arr)->group('create_times')->select();

        $list = collect($list)->toArray();
        foreach ($list as &$value){
            $value['stay1'] = round($value['stay1'] *= 100,2);
            $value['stay7'] = round($value['stay7'] *= 100,2);
            $value['stay14'] = round($value['stay14'] *= 100,2);
            $value['create_timess'] = date('Y-m-d',strtotime($value['day']));
        }
        $x_data = array_column($list,'create_timess');
        if ($type == 1){
            $y_data = array_column($list,'stay1');
        }elseif ($type == 2){
            $y_data = array_column($list,'stay7');
        }else{
            $y_data = array_column($list,'stay14');
        }
        $y_data1 = array_column($list,'dnu');
        return $this->jsonReturn(EXIT_SUCCESS,lang('success'),compact('y_data', 'x_data','y_data1'));
    }

    /***
     * 付费率数据
     */
    public function pay_rate(){
        $data = StatMarketDay::field("day as create_times,payrate")->select();
        foreach ($data as &$val){
            $val['create_times'] =date('Y-m-d',strtotime($val['create_times']));
        }
        $list = collect($data)->toArray();
        $x_data = array_column($list, 'create_times');
        $y_data = array_column($list,'payrate');
        foreach ($y_data as &$val){
            $val *= 100;
        }
        return $this->jsonReturn(EXIT_SUCCESS,lang('success'),compact('y_data', 'x_data'));
    }

    /***
     * 付费用户
     * @return string
     */
    public function pay_user(){
        $data = StatMarketDay::field("day as create_times,paynum")->select();

        foreach ($data as &$val){
            $val['create_times'] =date('Y-m-d',strtotime($val['create_times']));
        }
        $list = collect($data)->toArray();
        $x_data = array_column($list, 'create_times');
        $y_data = array_column($list,'paynum');
        return $this->jsonReturn(EXIT_SUCCESS,lang('success'),compact('y_data', 'x_data'));
    }

    /***
     * 付费金额
     */
    public function pay_amount(){
        $data = StatMarketDay::field("day as create_times,payamount")->select();
        foreach ($data as &$val){
            $val['create_times'] =date('Y-m-d',strtotime($val['create_times']));
        }
        $list = collect($data)->toArray();
        $x_data = array_column($list, 'create_times');
        $y_data = array_column($list,'payamount');
        return $this->jsonReturn(EXIT_SUCCESS,lang('success'),compact('y_data', 'x_data'));
    }

    /***
     *  新增付费用户
     */
    public function pay_new_amount(){
        $data = StatMarketDay::field("day as create_times,payfirstnum")->select();
        foreach ($data as &$val){
            $val['create_times'] =date('Y-m-d',strtotime($val['create_times']));
        }
        $list = collect($data)->toArray();
        $x_data = array_column($list, 'create_times');
        $y_data = array_column($list,'payfirstnum');
        return $this->jsonReturn(EXIT_SUCCESS,lang('success'),compact('y_data', 'x_data'));
    }

    /***
     * 留存率统计
     * @param Request $request
     * @return string
     */
    public function stayStatics(Request $request){
        if($request->isAjax()){
            $post_param = $request->param();
            $list = [];
            return json(['code'=>200,'data'=>[],'datas'=>[]]);
        }
        return $this->fetch();
    }

    public function shop_order(Request $request){
        if ($request->isAjax()){
            $is_export = $request->get('is_export');
            $start_times = $request->param('start_time');
            $start_time = explode('~',$start_times);
            $day = $request->get('day/d',30);
            $limit = $request->get('limit/d',15);
            if ($start_times){
                $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
            }else{
                $time_arr = [strtotime("-".$day.' days'),time()];
            }
            if ($is_export){
                $type = $request->get('type/d',1);
                $list_key = ['create_timess','dnu'];
                if ($type == 1){
                    $title = '次日留存';
                    $list_key[] = 'stay1';
                }elseif($type == 2){
                    $title = '七日留存';
                    $list_key[] = 'stay7';
                }else{
                    $title = '14日留存';
                    $list_key[] = 'stay14';
                }

                $list = collect($list)->toArray();
                foreach ($list as &$value){
                    $value['stay1'] = ($value['stay1'] *= 100)."%";
                    $value['stay7'] = ($value['stay7'] *= 100)."%";
                    $value['stay14'] = ($value['stay14'] *= 100)."%";
                    $value['create_timess'] = date('Y-m-d',strtotime($value['day']));
                }
            }else{
                $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');

                $order_list = SShopOrder::field('count(id) as t, sum(amount) as money, stype ')
                                        ->whereBetween('create_time',$time_arr)
                                        ->where('istest', '0')
                                        ->where('uid', 'not in', $testAccount)
                                        ->group('stype')
                                        ->order('stype desc')
                                        ->select();

                //支付成功的订单
                $paid_order_list = SShopOrder::field('count(id) as t, sum(amount) as money, stype ')
                                    ->whereBetween('create_time',$time_arr)
                                    ->where('status', '2')
                                    ->where('istest', '0')
                                    ->where('uid', 'not in', $testAccount)
                                    ->group('stype')
                                    ->order('stype desc')
                                    ->select();
                $paid_data = [];
                foreach($paid_order_list as $row) {
                    $paid_data[$row['stype']] = $row;
                }

                $y_data = StatShopOrder::STYPE_ARR;

                $data_arr = [];

                foreach ($y_data as $key => $v){
                     $data_arr[] = ['stype'=>$key,'count'=>0,'name'=>$v,'pcount'=>0,'pmoney'=>0];
                }
                $lists = [];

                foreach ($order_list as $value){
                    foreach ($data_arr as &$v ){
                        if ($v['stype'] == $value['stype']){
                            $v['count'] = $value['t'];
                            $v['money'] = $value['money'];
                            if (isset($paid_data[$value['stype']])) {
                                $v['pcount'] = $paid_data[$value['stype']]['t'];
                                $v['pmoney'] = $paid_data[$value['stype']]['money'];
                            }
                            $lists[] = $v;
                        }
                    }
                }

                $y_data = array_column($data_arr,'count');
                $x_data = array_values(StatShopOrder::STYPE_ARR);
                return json(['code'=>200,'data'=>$lists,'datas'=>compact('x_data','y_data'),'total'=>count($lists),'msg'=>lang('return_success')]);
            }
        }
        return $this->fetch();

    }
}