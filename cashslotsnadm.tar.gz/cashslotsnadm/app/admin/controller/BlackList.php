<?php
namespace app\admin\controller;

use app\admin\model\DSysMail;
use app\admin\model\SNickname;
use org\Curl;
use think\App;
use think\Request;

/***
 * 昵称导入
 * Class Email
 * @package app\admin\controller
 */
class BlackList extends Base
{

    /***
     * 昵称列表
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $lists = SNickname::where([])->order('id desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['state_text'] = $val->state_text;
            }
            return json(['code'=>200,'msg'=>lang('return_success'),'count'=>$lists->total() ,'data'=>$lists->items()]);
        }

        return $this->fetch();

    }

    /***
     * 导入昵称
     * @param Request $request
     * @return string
     */
    public function import_nickname(Request $request){
        if ($request->isPost()){

            $file = $request->file("file");
            $ext = $file->extension();
            if (!in_array($ext,['xls','xlxs','csv'])){
                $this->jsonReturn(EXIT_SUCCESS,'请上传excel');
            }
            $data_arr = $this->readFile($file);
            $title_arr = SNickname::where([])->column('title');
            $title_list = array_filter($data_arr,function ($val) use($title_arr){
               if (in_array($val,$title_arr) ){
                   return false;
               }
               return true;
            });
            $data = [];
            foreach ($title_list as $val){
                $data[] = ['title'=>$val,'state'=>1] ;
            }
            $s_nick = new SNickname();
            $res = $s_nick->saveAll($data);
            $curl = new Curl();
            $curl->reloadNickName();
            if ($res){
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
            }
            return $this->jsonReturn(EXIT_ERROR,lang('return_error'));
        }

        return $this->fetch();

    }


}