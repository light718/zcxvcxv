<?php

namespace app\admin\controller;

use app\admin\model\SGame;
use app\admin\model\StatAppLogStartappAppver;
use app\admin\model\StatGameData;
use app\admin\model\StatGameDetail;
use app\admin\model\StatGamePlayLog;
use app\admin\model\StatLoginData;
use app\admin\model\StatMarketDay;
use app\admin\model\StatUserloginAppver;
use app\admin\model\StatUserOnlineData;
use think\App;
use think\Request;

/***
 * 数值统计数据
 * Class AccountData
 * @package app\admin\controller
 */
class ActiveUser extends Base
{
    protected $notNeedRight = ['playCard', 'login_version_data', 'dauData', 'subGame', 'firstPlay'];

    /***
     * @param Request $request
     * @return string
     */
    public function index(Request $request)
    {
        $start_time = strtotime($request->get('start_time')) ?: 0;
        if (!$start_time) {
            $day = $request->get('day', 30);
            $start_time = strtotime(date('Y-m-d', strtotime("-{$day} days")));
        }
        $start_time = date('Ymd', $start_time);
        $end_time = date('Ymd', strtotime($request->get('end_time')) ?: time());
        $query = StatMarketDay::whereBetween('day', [$start_time, $end_time])->order('day desc');
        // 破产记录表
        if ($request->get('is_export')) {
            $list = StatMarketDay::whereBetween('day', [$start_time, $end_time])->order('day asc')->select();
            foreach ($list as &$value) {
                $y_data2[] = $value['dnu'];
                $x_data[] = $value['day'];
                $y_data1[] = $value['dau'];
            }
            $name = '数据统计';
            $format = 'xls';
            $newExcel = new \PHPExcel();  //
            $phpexcel = $newExcel->getActiveSheet();  //

            $phpexcel->setTitle($name);
            $newExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
            $newExcel->getActiveSheet()->getColumnDimension('B')->setWidth(50);
            $newExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
            $newExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
            $newExcel->getActiveSheet()->getColumnDimension('J')->setWidth(100);

            $newExcel->getActiveSheet()->getColumnDimension('K')->setWidth(100);
            $phpexcel->setCellValue('A1', 'ID')
                ->setCellValue('B1', lang('date'))
                ->setCellValue('C1', lang('dau'))
                ->setCellValue('D1', lang('market_dnu'))
                ->setCellValue('E1', lang('market_dnu_spin'))//新增玩牌用户
                ->setCellValue('F1', lang('market_dau'))
                ->setCellValue('G1', lang('market_active_spin_count'))
                ->setCellValue('H1', lang('pay_user'))
                ->setCellValue('I1', lang('pay_amount'))
                ->setCellValue('J1', lang('market_banrupt'))
                ->setCellValue('K1', lang('market_pay_banrupt'));
            $phpexcel->getStyle('B1')->getAlignment()->setWrapText(true);
            foreach ($list as $k => $v) {
                $phpexcel->setCellValue('A' . ($k + 2), $v->Id . "\t");
                $phpexcel->setCellValue('B' . ($k + 2), $v->day);
                $phpexcel->setCellValue('C' . ($k + 2), $v->dau);
                $phpexcel->setCellValue('D' . ($k + 2), $v->dnu);
                $phpexcel->setCellValue('E' . ($k + 2), $v->dau_spin);
                $phpexcel->setCellValue('F' . ($k + 2), $v->last_dau);
                $phpexcel->setCellValue('G' . ($k + 2), $v->active_spin_count);
                $phpexcel->setCellValue('H' . ($k + 2), $v->paynum);
                $phpexcel->setCellValue('I' . ($k + 2), $v->payamount);
                $phpexcel->setCellValue('J' . ($k + 2), $v->bankrupt_count);
                $phpexcel->setCellValue('K' . ($k + 2), $v->bankrupt_pay_count);
            }
            ob_end_clean();
            header('Content-Type: application/vnd.ms-excel');
            header("Content-Disposition: attachment;filename=" . $name . date('Y-m-d') . '.' . strtolower($format));
            header('Cache-Control: max-age=0');
            $res_excel = \PHPExcel_IOFactory::createWriter($newExcel, 'Excel5');
            $res_excel->save('php://output');
        }

        if ($request->isAjax()) {
            $limit = $request->get('limit/d');

            $lists = $query->paginate($limit);
            $y_data1 = [];
            $y_data2 = [];
            $x_data = [];
            foreach ($lists as &$value) {
                $y_data2[] = $value['dnu'];
                $x_data[] = $value['day'];
                $y_data1[] = $value['dau'];
            }
            $list = $lists->items();
            return json(['code' => 200, 'datas' => compact('list', 'x_data', 'y_data1', 'y_data2'), 'data' => $list, 'count' => $lists->total(), 'msg' => lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 玩牌数据统计
     * @param Request $request
     * @return string
     */
    public function playCard(Request $request)
    {
        $start_time = strtotime($request->get('start_time')) ?: 0;

        if (!$start_time) {
            $day = $request->get('day', 7);
            $start_time = strtotime(date('Y-m-d', strtotime("-{$day} days")));
        }
        $end_time = strtotime($request->get('end_time')) ?: time();
        $time_arr = [date('Ymd', $start_time), date('Ymd', $end_time)];
        $query = StatMarketDay::whereBetween('day', $time_arr)->order('day desc');

        $log_list = StatGamePlayLog::whereBetween('create_time', [$start_time, $end_time])->order('create_time desc')->select();
        // 破产记录表
        if ($request->get('is_export')) {
            $list = $query->select();
            foreach ($list as &$value) {
                $value['spin_one'] = 0;
                $value['spin_two'] = 0;
                $value['spin_three'] = 0;
                $value['spin_four'] = 0;
                $value['spin_five'] = 0;
                $value['spin_six'] = 0;
                foreach ($log_list as $v) {
                    if ($value['create_time'] == date('Y-m-d', strtotime($v['create_time']))) {
                        $json_data = json_decode($v['json_data'], true);
                        if ($json_data) {
                            $value['spin_one'] = $json_data[0]['t'];
                            $value['spin_two'] = $json_data[1]['t'];
                            $value['spin_three'] = $json_data[2]['t'];
                            $value['spin_four'] = $json_data[3]['t'];
                            $value['spin_five'] = $json_data[4]['t'];
                            $value['spin_six'] = $json_data[5]['t'];
                        }
                    }
                }
                $value['active_not_spin_count_percent'] = ($value['active_not_spin_count'] >0 && $value['last_dau'] > 0 ) ? round($value['active_not_spin_count']/$value['last_dau'],4) * 100  :  0;
                $value['activeuser_spin_count_percent'] = ($value['activeuser_spin_count'] >0 && $value['last_dau'] > 0 ) ? round($value['activeuser_spin_count']/$value['last_dau'],4) * 100   :  0;
                if ($value['last_dau']) {
                    $value['avg_spin'] = floor($value['active_spin_count'] / $value['last_dau']);
                } else {
                    $value['avg_spin'] = 0;
                }
            }
            $list_key = [
                'day',
                'dau',
                'active_not_spin_count',
                'activeuser_spin_count',
                'avg_spin',
            ];
            $this->export($list_key, $list);
        }

        if ($request->get()) {
            $limit = $request->get('limit/d');

            $lists = $query->paginate($limit);
            $list_stat = StatMarketDay::whereBetween('day', $time_arr)->order('day asc')->select()->toArray();
            foreach ($lists as &$value) {
                $value['spin_one'] = 0;
                $value['spin_two'] = 0;
                $value['spin_three'] = 0;
                $value['spin_four'] = 0;
                $value['spin_five'] = 0;
                $value['spin_six'] = 0;
                foreach ($log_list as $v) {
                    $json_data = json_decode($v['json_data'], true);
                    if ($value['create_time'] == date('Y-m-d', strtotime($v['create_time']))) {
                        $value['avg_count'] = $v['avg_count'];
                        if ($json_data) {
                            $value['spin_one'] = $json_data[0]['t'];
                            $value['spin_two'] = $json_data[1]['t'];
                            $value['spin_three'] = $json_data[2]['t'];
                            $value['spin_four'] = $json_data[3]['t'];
                            $value['spin_five'] = $json_data[4]['t'];
                            $value['spin_six'] = $json_data[5]['t'];
                        }
                    }
                }
                if ($value['last_dau']) {
                    $value['avg_spin'] = floor($value['active_spin_count'] / $value['last_dau']);
                } else {
                    $value['avg_spin'] = 0;
                }
                $value['active_not_spin_count_percent'] = ($value['active_not_spin_count'] >0 && $value['last_dau'] > 0 ) ? round($value['active_not_spin_count']/$value['last_dau'],4) * 100  :  0;
                $value['activeuser_spin_count_percent'] = ($value['activeuser_spin_count'] >0 && $value['last_dau'] > 0 ) ? round($value['activeuser_spin_count']/$value['last_dau'],4) * 100   :  0;
            }
            foreach ($list_stat as &$value) {
                {
                    $value['spin_one'] = 0;
                    $value['spin_two'] = 0;
                    $value['spin_three'] = 0;
                    $value['spin_four'] = 0;
                    $value['spin_five'] = 0;
                    $value['spin_six'] = 0;
                    foreach ($log_list as $v) {
                        if ($value['create_time'] == date('Y-m-d', strtotime($v['create_time']))) {
                            $json_data = json_decode($v['json_data'], true);
                            $value['avg_count'] = $v['avg_count'];
                            if ($json_data) {
                                $value['spin_one'] = $json_data[0]['t'];
                                $value['spin_two'] = $json_data[1]['t'];
                                $value['spin_three'] = $json_data[2]['t'];
                                $value['spin_four'] = $json_data[3]['t'];
                                $value['spin_five'] = $json_data[4]['t'];
                                $value['spin_six'] = $json_data[5]['t'];
                            }
                        }
                    }
                    if ($value['last_dau']) {
                        $value['avg_spin'] = floor($value['active_spin_count'] / $value['last_dau']);
                    } else {
                        $value['avg_spin'] = 0;
                    }
                    $active_not_spin_count = $value['active_not_spin_count'] > 0 && $value['last_dau'] > 0 ? round($value['active_not_spin_count'] / $value['last_dau'], 4) * 100 : 0;
                    $activeuser_spin_count_percent = ($value['activeuser_spin_count'] > 0 && $value['last_dau'] > 0) ? round($value['activeuser_spin_count'] / $value['last_dau'], 4) * 100 : 0;
                    $value['active_not_spin_count_percent'] = round($active_not_spin_count, 2);
                    $value['activeuser_spin_count_percent'] = round($activeuser_spin_count_percent, 2);
                }
            }
            $y_data = array_column($list_stat, 'active_not_spin_count_percent');

            $y_data1 = array_column($list_stat, 'activeuser_spin_count_percent');

            $y_data2 = array_column($list_stat, 'avg_spin'); //

            $x_data = array_column($list_stat, 'day');
            $list = $list_stat;

            return json(['code' => 200, 'datas' => compact('list', 'x_data', 'y_data', 'y_data1', 'y_data2'), 'data' => $lists->items(), 'count' => $lists->total(), 'msg' => lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 导出excel
     * @param $list_key key=> 中文value
     * @param $list
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    protected
    function export($list_key, $list)
    {
        $newExcel = new \PHPExcel();  //
        $phpexcel = $newExcel->getActiveSheet();  //
        $name = '活跃用户数据统计';
        $phpexcel->setTitle($name);
        $newExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('B')->setWidth(100)->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('J')->setWidth(200);
        $key_arr = range("A", "Z");
        $newExcel->getActiveSheet()->getColumnDimension('K')->setWidth(200);
        foreach ($list_key as $key => $value) {
            $i = floor($key / 26) + 1;
            $phpexcel = $phpexcel->setCellValue($key_arr[$key] . $i, lang($value));
        }

        $phpexcel->getStyle('B1')->getAlignment()->setWrapText(true);
        foreach ($list as $k => $v) {
            $i = 0;
//            foreach ($v as $key => $value){
            foreach ($list_key as $kk => $key_val) {
                $phpexcel->setCellValue($key_arr[$i] . ($k + 2), $v[$key_val] . "\t");
                $i += 1;
            }
        }
        ob_end_clean();
        header('Content-Type: application/vnd.ms-excel');
        header("Content-Disposition: attachment;filename=" . $name . date('Y-m-d') . '.' . strtolower("xls"));
        header('Cache-Control: max-age=0');
        $res_excel = \PHPExcel_IOFactory::createWriter($newExcel, 'Excel5');
        $res_excel->save('php://output');
    }

    /***
     * 登录数据
     * @param Request $request
     */
    public function dauData(Request $request)
    {
        if ($request->isAjax()) {
            $start_time = strtotime($request->get('start_time')) ?: 0;

            if (!$start_time) {
                $day = $request->get('day', 30);
                $start_time = strtotime(date('Y-m-d', strtotime("-{$day} days")));
            }
            $end_time = strtotime($request->get('end_time')) ?: time();

            $query = StatLoginData::field("*")->whereBetween('create_time', [$start_time, $end_time]);
            $list = $query->order('create_time desc')->select()->toArray();
            $fb_count = array_sum(array_column($list, 'fb_count'));
            $google_user_count = array_sum(array_column($list, 'google_count'));
            $guest_user_count = array_sum(array_column($list, 'guest_count'));
            $ios_user_count= array_sum(array_column($list,'ios_count'));
            $query = StatLoginData::field("*")->whereBetween('create_time', [$start_time, $end_time]);
            $limit = $request->get('limit/d');

            $lists = $query->order('create_time desc')->paginate($limit);
            return json(['code' => 200, 'datas' => compact('guest_user_count','ios_user_count', 'google_user_count', 'fb_count'), 'data' => $lists->items(), 'count' => $lists->total(), 'msg' => lang('return_success')]);
        }
    }

    /***
     * 子游戏数据
     * @param Request $request
     */
    public function subGame(Request $request)
    {

        if ($request->isAjax()) {
            $start_time = strtotime($request->get('start_time')) ?: 0;
            if (!$start_time) {
                $day = $request->get('day', 30);
                $start_time = strtotime(date('Y-m-d', strtotime("-{$day} days")));
            }

            $end_time = strtotime(strtotime($request->get('end_time'))) ?: time();
            $condition = [];
            $condition[] = ['create_time', '>=', $start_time];
            $condition[] = ['create_time', '<', $end_time];
            $query = StatGameData::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,create_time,all_count,active_one_game,active_two_game,active_three_game,active_four_game,active_not_played_game,active_five_game,active_six_game,active_more_game")->where($condition);
            $list = $query->select()->toArray();
//            ->toArray();
            $limit = $request->get('limit/d');

            $query = StatGameData::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,create_time,all_count,active_one_game,active_two_game,active_three_game,active_four_game,active_not_played_game,active_five_game,active_six_game,active_more_game")->where($condition);
            $lists = $query->paginate($limit);
            $y_data = array_column($list, 'dau_count');
            $y_data1 = array_column($list, 'active_one_game');
            $y_data2 = array_column($list, 'active_two_game');
            $y_data3 = array_column($list, 'active_three_game');
            $y_data4 = array_column($list, 'active_four_game');
            $y_data5 = array_column($list, 'active_five_game');
            $y_data6 = array_column($list, 'active_six_game');
            $y_data7 = array_column($list, 'active_more_game');
            $x_data = array_column($list, 'create_times');
            $data = $lists->items();
            foreach ($data as &$val) {
//                $val['play_count'] = $val['']
            }
            return json(['code' => 200, 'datas' => compact('y_data', 'y_data1', 'y_data2', 'y_data3', 'y_data4', 'y_data5', 'y_data6', 'y_data7', 'x_data'), 'data' => $data, 'count' => $lists->total(), 'msg' => lang('return_success')]);
        }
    }

    /***
     *  子游戏数据
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function firstPlay(Request $request)
    {
        $start_time = strtotime($request->get('start_time')) ?: 0;
        if (!$start_time) {
            $day = $request->get('day', 30);
            $start_time = strtotime(date('Y-m-d', strtotime("-{$day} days")));
        }
        $limit = $request->get('limit/d');

        $end_time = strtotime(strtotime($request->get('end_time'))) ?: time();
        $game_id_arr = SGame::where('gametag', '>', 0)->column('id');
        $list = StatGameDetail::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,game_title,allusers,allbet,allwin,alltimes,bet_one,bet_two,bet_other")->whereIn('game_id', $game_id_arr)->whereBetween('create_time', [$start_time, $end_time])->order('create_time desc')->paginate($limit);
        $data = $list->items();

        return json(['code' => 200, 'data' => $data, 'count' => $list->total(), 'msg' => lang('return_success')]);

    }

    /***
     *
     * @param Request $request
     * @return string
     */
    public function coinEdit(Request $request)
    {

        $uid = $request->get('uid');

        if ($request->isPost()) {

        } else {
            return $this->fetch();
        }
    }

    /**
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function login_version_data(Request $request)
    {
        $start_time = strtotime($request->get('start_time')) ?: 0;
        $end_time = strtotime($request->get('end_time')) ?: time();

        $time_arr = [$start_time, $end_time];

        $limit = $request->get('limit/d', 15);

        $lists = StatUserloginAppver::field('user_count as counts,appver as version,create_time')->whereBetween('create_time', $time_arr)->order('create_time desc')->paginate($limit);

        return json(['code' => 200, 'data' => $lists->items(), 'count' => $lists->total(), 'msg' => lang('return_success')]);
    }
}