<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

class PeopleCounting extends Base
{
    protected $notNeedRight = ['system_use', 'new_players_direction', 'loss_players', 'appver', 'new_user_appver', 'act_stat'];
    protected $tree = [
        ["id" => 1, "pid" => 0, "name" => "Buy", "act" => "menu_buy"],
        ["id" => 2, "pid" => 0, "name" => "heroes", "act" => "menu_poker"],
        ["id" => 3, "pid" => 0, "name" => "slots", "act" => "menu_slots"],
        ["id" => 4, "pid" => 0, "name" => "bonus", "act" => "menu_bonus"],
        ["id" => 5, "pid" => 0, "name" => "social", "act" => "menu_friend"],
        ["id" => 6, "pid" => 3, "name" => "点击头像", "act" => "open_head"],
        ["id" => 7, "pid" => 6, "name" => "关闭头像", "act" => "close_head"],
        ["id" => 8, "pid" => 6, "name" => "点CONNECT", "act" => "head_contact"],
        ["id" => 9, "pid" => 6, "name" => "点CONTACT US", "act" => "head_contactus"],
        ["id" => 10, "pid" => 3, "name" => "打开邮件", "act" => "open_mail"],
        ["id" => 11, "pid" => 10, "name" => "关闭邮件", "act" => "close_mail"],
        ["id" => 12, "pid" => 10, "name" => "点击COLLECT ALL", "act" => "mail_collectall"],
        ["id" => 13, "pid" => 10, "name" => "点击单个邮件", "act" => "open_mailitem"],
        ["id" => 14, "pid" => 10, "name" => "关闭单个邮件弹窗", "act" => "close_mailitem"],
        ["id" => 15, "pid" => 10, "name" => "点击单个邮件弹窗上COLLECT", "act" => "mailitem_collect"],
        ["id" => 16, "pid" => 3, "name" => "打开兑换码弹窗", "act" => "open_redeem"],
        ["id" => 17, "pid" => 16, "name" => "关闭兑换码弹窗", "act" => "open_redeem"],
        ["id" => 18, "pid" => 16, "name" => "点击Confirm按钮", "act" => "open_redeem"],
        ["id" => 19, "pid" => 3, "name" => "打开VIP弹窗", "act" => "open_vip"],
        ["id" => 20, "pid" => 19, "name" => "关闭VIP弹窗", "act" => "close_vip"],
        ["id" => 21, "pid" => 19, "name" => "点击VIP界面上的问号", "act" => "vip_help"],
        ["id" => 22, "pid" => 3, "name" => "打开Event弹窗", "act" => "open_event"],
        ["id" => 23, "pid" => 22, "name" => "关闭Event弹窗", "act" => "close_event"],
        ["id" => 24, "pid" => 22, "name" => "点击CONTACT US", "act" => "event_contact"],
        ["id" => 25, "pid" => 3, "name" => "打开菜单", "act" => "open_menu"],
        ["id" => 26, "pid" => 25, "name" => "关闭菜单", "act" => "close_menu"],
        ["id" => 27, "pid" => 25, "name" => "MUSIC按钮打开", "act" => "open_menu_music"],
        ["id" => 28, "pid" => 25, "name" => "MUSIC按钮关闭", "act" => "close_menu_music"],
        ["id" => 29, "pid" => 25, "name" => "SOUND按钮打开", "act" => "open_menu_sound"],
        ["id" => 30, "pid" => 25, "name" => "SOUND按钮关闭", "act" => "close_menu_sound"],
        ["id" => 31, "pid" => 25, "name" => "RATE US按钮", "act" => "menu_rateus"],
        ["id" => 32, "pid" => 25, "name" => "点击Settings按钮", "act" => "open_set"],
        ["id" => 33, "pid" => 32, "name" => "点击settings面板SOUND打开", "act" => "open_set_sound"],
        ["id" => 34, "pid" => 32, "name" => "点击settings面板SOUND关闭", "act" => "close_set_sound"],
        ["id" => 35, "pid" => 32, "name" => "点击settings面板MUSIC打开", "act" => "open_set_music"],
        ["id" => 36, "pid" => 32, "name" => "点击settings面板MUSIC关闭", "act" => "close_set_music"],
        ["id" => 37, "pid" => 32, "name" => "点击settings面板contact us", "act" => "set_contact"],
        ["id" => 38, "pid" => 32, "name" => "点击settings面板fan page", "act" => "set_fan"],
        ["id" => 39, "pid" => 32, "name" => "点击settings面板privacy policy", "act" => "set_policy"],
        ["id" => 40, "pid" => 32, "name" => "点击settings面板LOGOUT", "act" => "logout"],
        ["id" => 41, "pid" => 1, "name" => "点开金猪", "act" => "open_pig"],
        ["id" => 42, "pid" => 41, "name" => "关闭金猪", "act" => "close_pig"],
        ["id" => 43, "pid" => 41, "name" => "点击弹窗上PURCHASE BENEFITS", "act" => "open_pig_benefits"],
        ["id" => 44, "pid" => 41, "name" => "关闭PURCHASE BENEFITS弹窗", "act" => "close_pig_benefits"],
        ["id" => 45, "pid" => 1, "name" => "点击打开ONE TIME PASS 活动弹窗", "act" => "open_one_time"],
        ["id" => 46, "pid" => 45, "name" => "关闭ONE TIME PASS活动弹窗", "act" => "close_one_time"],
        ["id" => 47, "pid" => 4, "name" => "打开Daily Bonus弹窗", "act" => "open_signin"],
        ["id" => 48, "pid" => 47, "name" => "关闭Daily Bonus弹窗", "act" => "close_signin"],
        ["id" => 49, "pid" => 47, "name" => "从Daily Bonus领取一天签到金币", "act" => "signin_1"],
        ["id" => 50, "pid" => 47, "name" => "从Daily Bonus领取二天签到金币", "act" => "signin_2"],
        ["id" => 51, "pid" => 47, "name" => "从Daily Bonus领取三天签到金币", "act" => "signin_3"],
        ["id" => 52, "pid" => 47, "name" => "从Daily Bonus领取四天签到金币", "act" => "signin_4"],
        ["id" => 53, "pid" => 47, "name" => "从Daily Bonus领取五天签到金币", "act" => "signin_5"],
        ["id" => 54, "pid" => 47, "name" => "从Daily Bonus领取六天签到金币", "act" => "signin_6"],
        ["id" => 55, "pid" => 4, "name" => "打开Online Bonus弹窗", "act" => "open_online"],
        ["id" => 56, "pid" => 55, "name" => "关闭Online Bonus弹窗", "act" => "close_online"],
        ["id" => 57, "pid" => 55, "name" => "领取刮刮乐", "act" => "未知"],
        ["id" => 58, "pid" => 4, "name" => "打开Daily Task弹窗", "act" => "open_dailytask"],
        ["id" => 59, "pid" => 58, "name" => "关闭Daily Task弹窗", "act" => "close_dailytask"],
        ["id" => 60, "pid" => 58, "name" => "点击任务一完成按钮", "act" => "dailytask_1"],
        ["id" => 61, "pid" => 58, "name" => "点击任务二完成按钮", "act" => "dailytask_2"],
        ["id" => 62, "pid" => 58, "name" => "点击任务三完成按钮", "act" => "dailytask_3"],
        ["id" => 63, "pid" => 58, "name" => "点击任务四完成按钮", "act" => "dailytask_4"],
        ["id" => 64, "pid" => 58, "name" => "点击任务五完成按钮", "act" => "dailytask_5"],
        ["id" => 65, "pid" => 4, "name" => "打开Mission Pass弹窗", "act" => "open_mission"],
        ["id" => 66, "pid" => 65, "name" => "关闭Mission Pass弹窗", "act" => "close_mission"],
        ["id" => 67, "pid" => 65, "name" => "点击UNLOCK MISSION PASS", "act" => "open_mission_pass"],
        ["id" => 68, "pid" => 65, "name" => "关闭UNLOCK MISSION PASS", "act" => "close_mission_pass"],
        ["id" => 69, "pid" => 4, "name" => "打开Share弹窗", "act" => "open_share"],
        ["id" => 70, "pid" => 69, "name" => "关闭Share弹窗", "act" => "close_share"],
    ];

    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * @param Request $request
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            $pid = $this->request->get('pid', 0);

            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $actStr = "";
            foreach ($this->tree as $key => $value) {
                if($value['pid'] == $pid){
                    $actStr .= $value['act'] . ",";
                }
            }
            $data = Db::connect('game')
                    ->name('d_statistics')
                    ->whereTime('ts', 'between', [$start, $end])
                    ->whereIn('act', rtrim($actStr, ','))
                    ->where('uid', 'not in', Db::name('test_account')->where('uid is not null')->column('uid'))
                    ->group('act')
                    ->field("act, count(uid) times, count(distinct uid) people_nu")
                    ->select()->toArray();

            $data = array_column($data, NULL, 'act');
            $result = [];
            foreach ($this->tree as &$value) {
                if(isset($value['act']) && isset($data[$value['act']])){
                    $value['times'] = $data[$value['act']]['times'];
                    $value['people_nu'] = $data[$value['act']]['people_nu'];
                    $result[] = $value;
                }else{
                    $value['times'] = '0';
                    $value['people_nu'] = '0';
                }
            }
            $this->success('', '', $pid ? $result : $this->tree);
        }
        return $this->fetch();
    }

    //系统使用概率
    public function system_use(Request $request){
        if ($request->isAjax()){
            $act = [
                    'menu_poker' => '大厅卡牌按钮', 
                    'menu_slots' => '大厅slots按钮', 
                    'menu_bonus' => '大厅bonus按钮', 
                    'hall_wheel_enter' => '大厅中间转盘', 
                    'menu_buy' => '大厅商城按钮', 
                    'menu_friend' => '大厅社交按钮', 
                    'open_palace' => '大厅富豪厅按钮', 
                    'open_mail' => '大厅邮箱按钮', 
                    'open_ranklist' => '大厅排行榜按钮', 
                    'open_vip' => '大厅VIP按钮', 
                    'tab_bonus_dailybonus' => '日常任务主界面', 
                    'frienzy_collect' => '刮刮乐主界面', 
                    'bingo' => 'bingo主界面', 
                    'tab_bonus_sharefb' => 'share主界面', 
                    'tab_bonus_luckcard' => '幸运翻卡主界面', 
                    'hero_detail_pop' => '任意卡牌详情界面',
                    'tab_bonus_lucksmach' => '砸金蛋主界面', 
                    'questmain_enter' => 'quest主界面'
                ];
            $dayRange = $this->request->get('day_range', false);

            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $data = Db::connect('game')
                ->name('d_statistics')
                ->whereTime('ts', 'between', [$start, $end])
                ->whereIn('act', array_keys($act))
                ->where('uid', 'not in', Db::name('test_account')->where('uid is not null')->column('uid'))
                ->group('act')
                ->field("act, count(uid) times, count(distinct uid) people_nu")
                ->select()->toArray();
            
            foreach ($data as &$value) {
                $value['title'] = $act[$value['act']];
                unset($act[$value['act']]);
            }

            foreach ($act as $k => $v) {
                $arr = [
                    'title' => $v,
                    'act' => $k,
                    'times' => 0,
                    'people_nu' => 0
                ];
                $data[] = $arr;
            }
            $this->success('', '', $data);
        }

    }

    //新玩家人群去向
    public function new_players_direction(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $end = $end . ' 23:59:59';
            $data = Db::connect('game')
                ->name('d_user')
                ->whereTime('create_time', 'between', [$start, $end])
                ->where('uid', 'not in', Db::name('test_account')->where('uid is not null')->column('uid'))
                ->field("uid, level, FROM_UNIXTIME(create_time, '%Y%m%d') day")
                ->select();

            $result = [];
            foreach ($data as $key => $value) {
                $day = $value['day'];
                $result[$day] = $result[$day] ?? [];
                for ($i = 1; $i <= $value['level']; $i++) { 
                    $result[$day]['level_' . $i] =  isset($result[$day]['level_' . $i]) ? $result[$day]['level_' . $i] + 1 : 1;
                    // if($i == 50) break;  //只统计到50级
                }
         
            }

            $start = date("Ymd", strtotime($start));
            $end = date("Ymd", strtotime($end));
            $stat_data = Db::name('stat_new_players_direction')
                ->where('day', 'between', [$start, $end])
                ->column('startapp, hotupdate_pro_check, load_start, load_end, entry_main, showlogin, new_user_200w_pop, new_user_200w', 'day');
            //把定时任务统计的数据合并到查询数据
            foreach ($stat_data as $key => $value) {
                $result[$key] = $result[$key] ?? [];
                $result[$key] = array_merge($result[$key], $value);
            }
            
            //补充没有的字段为0
            foreach ($result as $key => &$value) {
                $value['day'] = $value['day'] ?? $key;
                $value['startapp'] = $value['startapp'] ?? 0;
                $value['hotupdate_pro_check'] = $value['hotupdate_pro_check'] ?? 0;
                $value['load_start'] = $value['load_start'] ?? 0;
                $value['load_end'] = $value['load_end'] ?? 0;
                $value['entry_main'] = $value['entry_main'] ?? 0;
                $value['showlogin'] = $value['showlogin'] ?? 0;
                $value['new_user_200w_pop'] = $value['new_user_200w_pop'] ?? 0;
                $value['new_user_200w'] = $value['new_user_200w'] ?? 0;
                for ($i = 1; $i <= 100; $i++) { 
                    $value['level_' . $i] = $value['level_' . $i] ?? 0;
                }
            }
            return json(['code'=>200,'data'=> array_values($result),'count'=> count($result)]);
        }
    }


    //流失玩家统计
    public function loss_players(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $end = $end . ' 23:59:59';
            $data = Db::connect('game')
                ->name('d_user')
                ->whereTime('create_time', 'between', [$start, $end])
                ->where('uid', 'not in', Db::name('test_account')->where('uid is not null')->column('uid'))
                ->where('login_time', '<', time() - 60*60*48) //48小时未登录算流失
                ->group('FROM_UNIXTIME(create_time, "%Y%m%d")')
                ->field('FROM_UNIXTIME(create_time, "%Y%m%d") day, group_concat(uid) uids')
                ->select();

            $result = [];
            foreach ($data as $key => $value) {
                $subSql = Db::connect('game')
                    ->name('d_statistics')
                    ->where('uid', 'in', $value['uids'])
                    ->group('uid')
                    ->field('max(id)')
                    ->buildSql();

                $act_arr = Db::connect('game')
                    ->name('d_statistics')
                    ->where('id in ' . $subSql)
                    ->column('act');
                    // echo Db::connect('game')->getLastSql();
                    // exit;

                $result[] = $this->checkAct($act_arr, $value['day']);
            }
            return json(['code'=>200,'data'=>$result,'count'=>count($result)]);
        }
    }

    //用户版本统计
    public function appver(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $end = $end . ' 23:59:59';

            $data = Db::connect('game')
                ->name('d_user_login_log')
                ->whereTime('create_time', 'between', [$start, $end])
                ->where('uid', 'not in', Db::name('test_account')->where('uid is not null')->column('uid'))
                ->group('resversion')
                ->field('resversion, count(distinct uid) nu')
                ->order('resversion desc')
                ->select()->toArray();

            foreach ($data as $key => &$value) {
                $value['index'] = $key + 1;
            }
            return json(['code'=>200,'data'=>$data,'count'=>count($data)]);
        }
    }

    //新用户版本统计
    public function new_user_appver(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $end = $end . ' 23:59:59';

            $data = Db::connect('game')
                ->name('d_app_log')
                ->whereTime('ts', 'between', [$start, $end])
                ->where('uid', '0')
                ->where('act', 'showLogin')
                ->group('appver')
                ->field('appver, count(distinct ddid) nu')
                ->order('appver desc')
                ->select()->toArray();
            // echo Db::connect('game')->getLastSql();exit;

            foreach ($data as $key => &$value) {
                $value['index'] = $key + 1;
            }
            return json(['code'=>200,'data'=>$data,'count'=>count($data)]);
        }
    }

    
    //新用户app启动统计
    public function act_stat(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $start = date("Ymd", strtotime($start));
            $start = date("Ymd", strtotime($start));
            $end = date('Ymd', strtotime($end . ' 23:59:59'));

            $data = Db::name('stat_new_players_direction')
                ->where('day', 'between', [$start, $end])
                ->order('day', 'desc')
                ->select();

            return json(['code'=>200,'data'=>$data,'count'=>count($data)]);
        }
    }




    //统计act页面分布
    private function checkAct($act_arr, $day){
        $data = [
            'day' => $day,
            'act_1' => 0,
            'act_2' => 0,
            'act_3' => 0,
            'act_4' => 0,
            'act_5' => 0,
            'act_6' => 0,
            'act_7' => 0,  
            'act_8' => 0,  
            'act_9' => 0,  
            'act_10' => 0,  
            'act_11' => 0,  
            'act_12' => 0,  
            'act_13' => 0,  
            'act_14' => 0,  
            'act_15' => 0,  
            'act_16' => 0,  
            'act_17' => 0,  
            'act_18' => 0,  
            'act_19' => 0,
            'act_20' => 0,  
            'act_21' => 0,  
            'act_22' => 0,  
            'act_23' => 0,  
            'act_24' => 0,  
            'act_25' => 0
        ];
        foreach ($act_arr as $key => $value) {
            //大厅slots界面
            if(in_array($value, ['Entry_Main', 'menu_slots', 'click_initgift', 'onetimeonly_pop', 'open_menu', 'open_purchase'])){ 
                $data['act_1']++;
            }//大厅商城界面
            elseif(in_array($value, ['menu_buy', 'buy_click_onetimeonly', 'buy_growth_fund', 'buy_click_pigbank', 'buy_click_weekcard', 'buy_click_monthcard', 'buy_inbox_coin','buy_level_package', 'buy_tab_sale', 'buy_tab_coin', 'buy_coin_list', 'heropalace_pointui_buy'])){ 
                $data['act_2']++;
            }//大厅英雄界面
            elseif(in_array($value, ['menu_poker', 'hero_camp_change'])){
                $data['act_3']++;
            }//大厅bonus界面
            elseif(in_array($value, ['menu_bonus', 'questmain_enter'])){
                $data['act_4']++;
            }//大厅socail界面
            elseif(in_array($value, ['menu_friend'])){ 
                $data['act_5']++;
            } //子游戏内
            elseif(in_array($value, ['subgame_loading_succ', 'up_bet', 'down_bet', 'maxbet', 'subgame_exp', 'ingame_task', 'subgame_stop_spin']) or in_array(substr($value, 4),["JOIN", "EXIT"])){
                $data['act_6']++;
            }//单独卡牌详情界面
            elseif(in_array($value, ['hero_detail_pop', 'hero_detail_close', 'hero_detail_allscreen', 'hero_detail_existall', 'hero_detail_change'])){ 
                $data['act_7']++;
            }//卡牌抽卡界面
            elseif(in_array($value, ['luckycard_pop', 'luckycard_heart_buy', 'luckycard_buy_pop', 'luckycard_buy_close', 'luckycard_close'])){ 
                $data['act_8']++;
            }//卡牌碎片转盘界面
            elseif(in_array($value, ['unknown'])){ //没找到打点
                $data['act_9']++;
            }//卡牌成就奖励界面
            elseif(in_array($value, ['unknown'])){ //没找到打点
                $data['act_10']++;
            }//富豪厅界面
            elseif(in_array($value, ['open_palace', 'heropalace_earningpoint'])){ 
                $data['act_11']++;
            } //邮箱界面
            elseif(in_array($value, ['open_mail', 'mail_collect', 'mail_collectall'])){
                $data['act_12']++;
            }//排行榜界面
            elseif(in_array($value, ['open_rank', 'rank_totalwin', 'rank_totalbet'])){
                $data['act_13']++;
            }//VIP界面
            elseif(in_array($value, ['open_vip', 'mail_go_vip'])){
                $data['act_14']++;
            }//个人信息界面
            elseif(in_array($value, ['open_head', 'edit_headpic', 'sure_headpic', 'head_contactus'])){
                $data['act_15']++;
            }//在线转盘界面
            elseif(in_array($value, ['hall_wheel_enter'])){ 
                $data['act_16']++;
            }//刮刮乐界面
            elseif(in_array($value, ['tab_bonus_onlinereward','frienzy_collect', 'get_online'])){ 
                $data['act_17']++;
            }//每日登陆奖励界面
            elseif(in_array($value, ['tab_bonus_dailybonus'])){ 
                $data['act_18']++;
            }//每日任务界面
            elseif(in_array($value, ['tab_bonus_dailymission'])){ 
                $data['act_19']++;
            }//bingo界面 
            elseif(in_array($value, ['unknown'])){ //没找到打点
                $data['act_20']++;
            }//FB分享界面
            elseif(in_array($value, ['tab_bonus_sharefb'])){ 
                $data['act_21']++;
            }//幸运抽卡界面
            elseif(in_array($value, ['tab_bonus_luckcard'])){ 
                $data['act_22']++;
            }//social内好友界面
            elseif(in_array($value, ['present', 'social_friends', 'social_delfriends_out', 'social_addfriends_close', 'social_addfriends_out', 'social_addfriends_add', 'add_friend_byuid', 'social_delfriends_select_out', 'remove_friend', 'mail_go_friend'])){ 
                $data['act_23']++;
            }//世界聊天界面
            elseif(in_array($value, ['menu_friend', 'social_addme', 'social_hi', 'social_send', 'social_chat'])){ 
                $data['act_24']++;
            }
            else{ //其他界面
                $data['act_25']++;
            }
            
        }
 
        return $data;
    }

}