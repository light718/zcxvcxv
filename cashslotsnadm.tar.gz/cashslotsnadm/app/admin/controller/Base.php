<?php

namespace app\admin\controller;

use app\admin\model\SysSetting;
use app\BaseController;
use app\common\model\AuthRule;
use org\Auth;
use org\Curl;
use org\RedisKey;
use think\App;
use think\facade\Db;
use think\facade\Env;
use think\facade\Lang;
use think\facade\Session;
use think\facade\View;
use app\admin\model\SystemLog as SystemLogModel;

/***
 * Class Base
 * @package app\admin\controller
 * @property $auth Rbac 类
 */
class Base extends BaseController
{
    protected $auth = null;
    protected $notNeedRight = [];
    protected $notNeedLogin = [];
    protected $token = '';
    protected $account = [];
    protected $is_agent = 0;
    public function initialize()
    {
        define('EXIT_SUCCESS', Env::get('EXIT_SUCCESS'));
        define('EXIT_ERROR', Env::get('EXIT_ERROR'));
        define('EXIT_CONFIG', Env::get('EXIT_CONFIG'));
        define('EXIT_UNKNOWN_FILE', Env::get('EXIT_UNKNOWN_FILE'));
        define('EXIT_UNKNOWN_CLASS', Env::get('EXIT_UNKNOWN_CLASS'));
        define('EXIT_UNKNOWN_METHOD', Env::get('EXIT_UNKNOWN_METHOD'));
        define('EXIT_USER_INPUT', Env::get('EXIT_USER_INPUT'));
        define('EXIT_DATABASE', Env::get('EXIT_DATABASE'));
        define('EXIT__AUTO_MIN', Env::get('EXIT__AUTO_MIN'));
        define('EXIT__AUTO_MAX', Env::get('EXIT__AUTO_MAX'));
        define('EXIT_INVALID_TOKEN', Env::get('EXIT_INVALID_TOKEN'));
        define('EXIT_COIN_LACK', Env::get('EXIT_COIN_LACK'));
        define('EXIT_LOGIN_FORBIDDEN', Env::get('EXIT_LOGIN_FORBIDDEN'));
        define('EXIT_ACCOUNT_REPEAT', Env::get('EXIT_ACCOUNT_REPEAT'));
        define('EXIT_ACCOUNT_IP', Env::get('EXIT_ACCOUNT_IP'));
        define('CSS_VERSION', Env::get('CSS_VERSION'));
        define('API_URL_BASE', Env::get('API_URL_BASE'));
        $domain = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'www.bigbangadmin.com';
        define('DOMAIN', $domain);
    }

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->auth = new Auth();
        $this->checkLogin();
        $admin_id = Session::get('user_info.id');

        // 判断是否需要验证权限
        $modulename = app('http')->getName();
        $controllername = $this->request->controller();
        $actionname = strtolower($this->request->action());
        $path = $modulename . '/' . str_replace('.', '/', $controllername) . '/' . $actionname;
        if (!$this->auth->match($this->notNeedRight)) {
            // 判断控制器和方法是否有对应权限
            if (!$this->auth->check($path, $admin_id) && $admin_id != 1000) {
                exit("你没有权限");
            }
        }
        $config = $this->getConfig();
        $userInfo = Session::get('user_info');
        $menu = $this->getMenu();
        View::assign('auth', $this->auth);
        View::assign('config', $config);
        if ($userInfo) {

            $this->token = $userInfo['token'];
        } else {
            $this->token = '';
        }
        $groups = $this->auth->getGroups($admin_id);
        $groups = collect($groups)->toArray();
        if ($groups && $groups[0]['id'] == 2 ){
            $this->is_agent = 1;
        }else{
            $this->is_agent = 0;
        }
        $this->account = $userInfo;
        $user_coin = \app\admin\model\Account::where(['id'=>\session('user_info.id')])->value('coin');
        $this->assign('user_coin',$user_coin);
        $this->assign('is_agent', $this->is_agent);
        $this->assign('lang', Lang::getLangSet());
        $this->assign('controller_name',$this->request->controller());
        $this->app->loadLangPack($this->app->lang->getLangSet());
        $this->assign('menu', $menu);
    }

    /*** 获取站点配置
     * @return array
     */
    public function getConfig()
    {
        $config = [
            'site_title' => 'Cash Hero Admin',
            'company_lost' => '',
        ];
        return $config;
    }

    /***
     * 获取菜单配置
     * @return array
     */
    public function getMenu()
    {
        $menu = [];
        $admin_id = Session::get('user_info.id');
        $auth = new Auth();
        $auth_rule_model = new AuthRule();
        $auth_rule_list = $auth_rule_model->where('status', 1)->order(['sort' => 'DESC', 'id' => 'ASC'])->select();
        $auth_rule_list = ($auth_rule_list)->toArray();
        foreach ($auth_rule_list as $key=>$value) {
            if (($key == 0&& $value == "#")){
                $menu[] = $value;
            }else{
                if (($auth->check($value['name'], $admin_id) || $admin_id == 1000) ) {
                    $menu[] = $value;
                }
            }
        }
        $is_third = 1;
        $parent_id = \app\admin\model\Account::where(['id'=>session('user_info.id')])->value('parent_id');
        $parent_ids = \app\admin\model\Account::where(['id'=>$parent_id])->value('parent_id');
        if($parent_ids && $parent_ids != 1000){
            $is_third = 0;
        }
        foreach ($menu as $key => &$value){
             if ($value['id'] == 93 && !$is_third){
                 unset($menu[$key]);
             }
        }
        if (!empty($menu)) {
            $menu = array2tree($menu);
        } else {
            $menu = [];
        }


        $groups = $auth->getGroups($admin_id);
        $groups = collect($groups)->toArray();
        foreach ($menu as $key=>$value){
            if ($value['name'] == '#' && !$value['children']) {
                unset($menu[$key]);

            }
            if ($groups &&$groups[0]['id'] == 2){
                if ($value['id'] == 30){
                    unset($menu[$key]);
                }
            }


        }
        $this->assign('menu', $menu);

        return $menu;
    }

    /**
     * 权限检查
     * @return bool
     */
    //权限小处理，rabc权限
    protected function checkAuth()
    {
        $module = app('http')->getName();
        $controller = $this->request->controller();
        $action = $this->request->action();
        // 排除权限
        $not_check = [];
        foreach ($this->notNeedRight as $value) {
            $not_check[] = strtolower($value);
        }
        if (!in_array($module . '/' . $controller . '/' . $action, $not_check) && !in_array(strtolower($action), $not_check) && !in_array('*', $not_check)) {
            $auth = $this->auth;
            $admin_id = Session::get('user_info.id');
            if (!$auth->check($module . '/' . $controller . '/' . $action, $admin_id) && $admin_id != 1 && !in_array('*', $not_check)) {
                $this->error('没有权限', 'login/index');
            }
        }
    }

    /***
     * @param $variable
     * @param $val
     */
    protected function assign($variable, $val)
    {
        View::assign($variable, $val);
    }

    /***
     * @param $template
     * @param $data
     * @return string
     */
    protected function fetch($template = '', $data = [])
    {
        return View::fetch($template, $data);
    }

    /*** 系统日志
     * @param string $info
     * @param string $type
     * @return bool
     */
    public function action_log($info = '', $type = '')
    {
        $systemlog = new SystemLogModel();
        $data = array();
        $data['log_user_id'] = Session::get('user_info.id') ?: 1;
        $data['log_user_name'] = Session::get('user_info.name') ?: '测试哦哦哦';
        $data['log_content'] = $info;
        $data['log_ip'] = $this->request->ip();
        $data['log_time'] = time();
        $data['type'] = $type;
        return $systemlog->save($data);
    }

    /***
     * 验证登录方法
     */
    public function checkLogin()
    {
        $action = $this->request->action();
        if (!session('user_info') && !in_array($action, $this->notNeedLogin) && !in_array('*', $this->notNeedLogin)) {
            $this->error('请先登录', url('login/index'));
        }

        if ($token = \session('user_info.token')) {
            $account_re = \app\admin\model\Account::where(['id' => \session('user_info.id')])->find();
            if ($account_re['token'] != $token) {
                Session::set('user_info', null);
                Session::set('user_info_db', null);
                Session::set('user_account_pwd', null);
                $this->error(\lang('login_in_other_way'), url('login/index'));
            }
        }
    }

    /***
     * @param int $errcode
     * @param string $errmsg
     * @param array $data
     * @return string
     */
    public function jsonReturn($errcode = EXIT_SUCCESS, $errmsg = '', $data = array())
    {
        header('Content-type:application/json');
        echo json_encode(array('code' => $errcode, 'msg' => $errmsg, 'data' => $data));
        exit;
    }

    /***
     *  获取语言包
     * @return string
     */
    public function getLang()
    {
    }

    public function requestApi($uri, $method, $params = array(), $list = false)
    {
        $apiUrl = API_URL_BASE;
        // bigbang需要切换地区，不同地区对应的api地址不同
        if (config('domain.css_version') === 'bigbang') {
            $selectRegion = Session::get('select_region');
            $regionconf = config('regionconf');
            if ($regionconf) {
                if ($selectRegion) {
                    $apiUrl = isset($regionconf[$selectRegion]) ? $regionconf[$selectRegion] : $apiUrl;
                }/* else { //默认选择第一个
                    $apiUrl = array_values($regionconf)[0];
                }*/
            }
        }
        foreach ($params as $key => $val) {
            if ($val === NULL || $val === '') {
                unset($params[$key]);
            } else {
                $params[$key] = trim($val);
            }
        }
        if (strstr($uri, 'http')) {
            $url = $uri;
        } else {
            $url = $apiUrl . $uri;
        }
        if ($method == 'GET') {
            if ($this->token) {
                $params['token'] = $this->token;
            }
            $url = $url . '?' . http_build_query($params);
        } else {
            if ($this->token) {
                $url = $url . '?token=' . $this->token;
            }
        }
        $result = $this->uCurl($url, $method, $params);
        if ($result['errcode'] == EXIT_INVALID_TOKEN) { // token无效
            // 销毁当前session
            Session::delete('user_info');

            if ($this->request->isAjax()) {
                $this->jsonReturn(EXIT_INVALID_TOKEN);
                exit();
            } else {
                $this->redirect("login/index ");
            }
        }

        if ($list && $result['errcode'] != 0) {
            $result['data']['list'] = [];
            $result['data']['total'] = 0;
        }

        return $result;
    }

    public function uCurl($url, $method, $params = array(), $header = '')
    {
        $curl = curl_init();//初始化CURL句柄
        $timeout = 15;
        curl_setopt($curl, CURLOPT_URL, $url);//设置请求的URL
        curl_setopt($curl, CURLOPT_HEADER, false);// 不要http header 加快效率
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); //设为TRUE把curl_exec()结果转化为字串，而不是直接输出

        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);    // https请求 不验证证书和hosts
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);

        if ($header == '') {
            $header = array("Accept-Language: zh-CN;q=0.8");
            curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
        } else {
            curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
        }

        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, $timeout);//设置连接等待时间
        switch ($method) {
            case "GET" :
                curl_setopt($curl, CURLOPT_HTTPGET, true);
                break;
            case "POST":
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_NOBODY, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $params);//设置提交的信息
                break;
            case "PUT" :
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Length: ' . strlen(http_build_query($params))));
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
                break;
            case "DELETE":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
                curl_setopt($curl, CURLOPT_POSTFIELDS, $params);
                break;
        }

        $data = curl_exec($curl);//执行预定义的CURL
        $debugStr = '';
        $debugStr .= $url . ' ' . $method . '<br>';
        $debugStr .= json_encode($params, JSON_UNESCAPED_UNICODE) . '<br>';
        $debugStr .= $data;
        $status = curl_getinfo($curl);//获取http返回值
        curl_close($curl);
        $res = json_decode($data, true);

        return $res;
    }

    public function record($title, $detail, $tpls = [], $flag = true)
    {
        $tpls_cn = [];
        $tpls_en = [];

        //拆分参数中的中英文
        foreach ($tpls as $tpl) {
            if (strpos($tpl, "|||") !== false && is_array($l = explode("|||", $tpl)) && count($l) == 2) {
                $tpls_cn[] = $l[0];
                $tpls_en[] = $l[1];
            } else {
                $tpls_cn[] = $tpl;
                $tpls_en[] = $tpl;
            }
        }

//        if ($flag && function_exists("fastcgi_finish_request")) { // yii或yaf默认不会立即输出，加上此句即可（前提是用的fpm）
//            fastcgi_finish_request(); // 响应完成, 立即返回到前端,关闭连接
//        }
        $ip = $this->request->ip();
        $os = $this->getOS();
        $browser = $this->browserInfo();
        $time = time();
        // file_put_contents('/tmp/log.txt', $detail, FILE_APPEND);
        $data = [
            'account_agent' => $this->account['agent'],
            'account_id' => $this->account['id'],
            'account_vid' => isset($this->account['vid']) ? $this->account['vid'] : 0,
            'ip' => $ip,
            'os' => $os,
            'browser' => $browser,
            't' => lang('cn_' . md5($title)),
            't2' => lang('en_' . md5($title)),
            'detail' => sprintf(lang('cn_' . md5($detail)), ...$tpls_cn),
            'detail2' => sprintf(lang('en_' . md5($detail)), ...$tpls_en),
            'create_time' => $time
        ];
        return Db::name('log_api_backoffice')->insert($data);
    }

    public function getOS()
    {
        if (!empty($_SERVER['HTTP_USER_AGENT'])) {
            $os = $_SERVER['HTTP_USER_AGENT'];
            if (preg_match('/win/i', $os)) {
                $os = 'Windows';
            } else if (preg_match('/mac/i', $os)) {
                $os = 'MAC';
            } else if (preg_match('/linux/i', $os)) {
                $os = 'Linux';
            } else if (preg_match('/unix/i', $os)) {
                $os = 'Unix';
            } else if (preg_match('/bsd/i', $os)) {
                $os = 'BSD';
            } else {
                $os = 'Other';
            }
            return $os;
        } else {
            return 'unknow';
        }
    }

    /**
     * 获得访问者浏览器
     */
    public function browserInfo()
    {
        if (!empty($_SERVER['HTTP_USER_AGENT'])) {
            $br = $_SERVER['HTTP_USER_AGENT'];
            if (preg_match('/MSIE/i', $br)) {
                $br = 'MSIE';
            } else if (preg_match('/Firefox/i', $br)) {
                $br = 'Firefox';
            } else if (preg_match('/Chrome/i', $br)) {
                $br = 'Chrome';
            } else if (preg_match('/Safari/i', $br)) {
                $br = 'Safari';
            } else if (preg_match('/Opera/i', $br)) {
                $br = 'Opera';
            } else {
                $br = 'Other';
            }
            return $br;
        } else {
            return 'unknow';
        }
    }

    /***
     * 获取redis 对象
     * @return \Redis
     */
    protected function getRedisObj()
    {
        $redis = new \Redis();
        $redis->connect(Env::get('redis.hostname'), Env::get('redis.port'));
        $redis->auth(Env::get('redis.password'));
        $redis->select(Env::get('redis.select'));
        return $redis;
    }

    /***
     * 导出excel
     * @param $list_key
     * @param $list
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    protected function exportExcel($list_key, $list,$name = '',$lang_key = [])
    {
        $newExcel = new \PHPExcel();  //
        $phpexcel = $newExcel->getActiveSheet();  //
        $name = $name ?: time();
        $phpexcel->setTitle($name);
        $newExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('B')->setWidth(100)->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $newExcel->getActiveSheet()->getColumnDimension('J')->setWidth(200);
        $key_arr = range("A", "Z");
        $newExcel->getActiveSheet()->getColumnDimension('K')->setWidth(200);
        foreach ($list_key as $key => $value) {
            $i = floor($key / 26) + 1;
            $phpexcel = $phpexcel->setCellValue($key_arr[$key] . $i, isset($lang_key[$value]) ?$lang_key[$value]:lang($value));
        }

//        $phpexcel->getStyle('B1')->getAlignment()->setWrapText(true);
        foreach ($list as $k => $v) {
            $i = 0;
//            foreach ($v as $key => $value){
            foreach ($list_key as $kk => $key_val){
                $phpexcel->setCellValue($key_arr[$i] . ($k + 2), $v[$key_val] . "\t");
                $i += 1;
            }
        }
        ob_end_clean();
        header('Content-Type: application/vnd.ms-excel');
        header("Content-Disposition: attachment;filename=" . $name . date('Y-m-d') . '.' . strtolower("xls"));
        header('Cache-Control: max-age=0');
        $res_excel = \PHPExcel_IOFactory::createWriter($newExcel, 'Excel5');
        $res_excel->save('php://output');
    }

    /***
     * 获取游戏名称
     * @param $gameid
     * @return bool|mixed
     */
    public function getActGameName($gameid){
        $dict = [];
        $dict[10000] = '上分';
        $dict[20000] = '下分';
        $dict[30000] = 'EVO视讯';
        $dict[50000] = 'BIGBANG';
        $dict[60000] = 'REDBAG';
        $dict[80000] = '升级奖励';
        $dict[70000] = 'BB幸运转盘';
        $dict[90000] = '幸运红包';
        $dict[100000] = '红包雨';
        $dict[110000] = '成长系统的宝箱';
        $dict[120000] = '在线奖励';
        $dict[130000] = '玩家注册奖励';
        $dict[140000] = '玩家转盘奖励';
        $dict[150000] = '邮件附件';
        $dict[160000] = '任务奖励';
        $dict[170000] = '标签页奖励';
        $dict[180000] = '集邮商城奖励';
        $dict[180001] = '集邮奖励';
        $dict[190000] = '破产补助';
        if(!isset($dict[$gameid])) {
            return false;
        }
        return $dict[$gameid];
    }

    /***
     * 获取游戏列表
     * @param int $uniq
     * @return bool|number
     */
    public function getGameList($uniq = 1){
        $curl = new Curl();
        $lang = $curl->getLang(Lang::getLangSet());
        $list = $curl->getGameLists($lang,$uniq);
        return $list;
    }

    /***
     * 获取浮点型
     * @param $newspay
     * @param $newsuser
     * @param int $isPercent
     * @return float|int|string
     */
    protected function _getFloat($newspay, $newsuser, $isPercent = 0)
    {
        $floatNum = 0;
        if (!empty($newspay) && !empty($newsuser)) {
            $floatNum = round($newspay / $newsuser, 2);
        }
        if ($isPercent == 1) {
            return ($floatNum * 100) . '%';
        }
        return $floatNum;
    }

    /***
     * @param string $keystr
     * @return array|\think\Collection
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    protected function getSystemPars($keystr = ''){
        $result = [];

        $_keys = array_filter(explode("|", $keystr));
        $list  = SysSetting::whereIn('skey',$_keys)->field('skey,sval')->select();
        foreach ($list as $v){
            $result[$v['skey']] = $v['sval'];
        }
        return $result;
    }

    public function setUser($uid = '',$status = 0)
    {


        return $result;
    }

    public function getLuaSha1s($key = '') : string
    {
        $tables = TableManager ::getInstance()->get('table.redis.LuaSHa1s');

        return $tables->get($key, 'sha1');
    }

    public function loadlang($name,$request)
    {
        $langset = Lang::detect($request);
        Lang::load([$this->app->getThinkPath() . 'lang' . DIRECTORY_SEPARATOR .$name.DIRECTORY_SEPARATOR. $langset . '.php',]);
        return true;
    }

    /**
     * 读取excel
     * @param $file
     * @return array
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */
    public function readFile($file){
        $objPHPExcel = \PHPExcel_IOFactory::load($file);
        $sheetCount = $objPHPExcel->getSheetCount();

        $sheetSelected = 0;$objPHPExcel->setActiveSheetIndex($sheetSelected);

        $rowCount = $objPHPExcel->getActiveSheet()->getHighestRow();

        $columnCount = $objPHPExcel->getActiveSheet()->getHighestColumn();
        for ($row = 2; $row <= $rowCount; $row++){
            for ($column = 'A'; $column <= $columnCount; $column++) {

                $dataArr[] = $objPHPExcel->getActiveSheet()->getCell($column.$row)->getValue();

            }
        }

        return $dataArr;
    }
}