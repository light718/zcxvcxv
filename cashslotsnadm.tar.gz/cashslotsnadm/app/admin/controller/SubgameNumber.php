<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

class SubgameNumber extends Base
{
    protected $notNeedRight = [];

    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * @param Request $request
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $limit = $this->request->get('limit');
            $dayRange = $this->request->get('day_range', false);
            $gameid = $this->request->get('gameid', false);
            
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $start = date('Ymd', strtotime($start));
            $end = date('Ymd', strtotime($end));

            $list = Db::name('stat_subgame_number')
                ->where('day', 'between', [$start, $end])
                ->where(function($query) use ($gameid){
                    if($gameid){
                        $query->where('gameid', $gameid);
                    }
                })
                ->field("day, gameid, game_name, http_subgame_hotupdate_start, http_subgame_hotupdate_process, http_subgame_hotupdate_result, `join:*` `join`, games_number")
                ->paginate($limit);

            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total()]);
        }
        return $this->fetch();
    }

}