<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/3/2
 * Time: 17:30
 */
namespace app\admin\controller;

use app\admin\model\SysGlobalnotice;
use think\App;
use app\admin\model\Account as AccountModel;
use think\Request;
use org\Curl;

class Notice extends Base
{
    protected $notNeedRight = ['add', 'delete'];
    protected $account_model;

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->account_model = new AccountModel();
    }

    /***
     * 系统公告配置列表
     * @param Request $request
     */
    public function index(Request $request)
    {

        $list = SysGlobalnotice::select();
        $dict = [
            "1" => '不可关闭',
            "2" => '玩家点击界面关闭',
            "3" => '展示 xx 秒后自动关闭',
            "4" => '展示 xx 秒后自动关闭，且玩家可以点击关闭'
        ];
        foreach ($list as $key => &$value) {
            $value['type'] = $dict[$value['type']];
            $value['type'] = str_replace('xx', $value['close'], $value['type']);
        }

        return $this->fetch(__FUNCTION__, compact('list'));
    }

    /***
     *
     * @return string
     */
    public function add(Request $request){
        if ($request->isPost()){
            $param = $request->param();
            $param['create_time'] = time();
            $res = SysGlobalnotice::insertGetId($param);

            if ($res){
                $this->imme_return(['code' => 1, "msg" => "操作成功"], 60*30);
                $idx = 1;
                while (true) {
                    $curl = new Curl();
                    $curl->system_notice(http_build_query([
                        'type' => $param['type'],
                        'close' => $param['type'] == 1 ? 9999 : ($param['type'] == 2 ? $param['interval'] + 2 : $param['close']),
                        'title' => $param['title'],
                        'count' => $param['count'],
                        'interval' => $param['interval']
                    ]), ['msg'=> $param['msg']]);

                    // file_put_contents('test_' . $idx . '.txt', $idx . '===' . time());
                    if($idx >= $param['count']) break;
                    sleep($param['interval']);
                    $idx ++;
                }
            }else{
                $this->error('操作失败');
            }
        }

        return $this->fetch();
    }

    //删除
    public function delete(Request $request){
        $id = $request->get('id');

        if (!$id){
            $this->error(lang( 'please_input_id'));
        }
        $delete_re = SysGlobalnotice::where(compact('id'))->delete();
        if ($delete_re){
            $this->success(lang('return_success'));
        }else{
            $this->error(lang('return_error'));
        }
    }


    //提前返回
   private function imme_return($data ='',$set_time_limit=20)
   {
       $str=is_string($data)  ? $data : json_encode($data);
       echo $str;
       if(function_exists('fastcgi_finish_request')){			//Nginx使用
           fastcgi_finish_request();		//后面输出客户端获取不到
       }else {			//apache 使用
           $size = ob_get_length();
           header("Content-length: $size");
           header('Connection:close');
           ob_end_flush();
           //ob_flush();       //加了没效果
           flush();         
       }
       ignore_user_abort(true);
       set_time_limit($set_time_limit);
       return true;
   }

}