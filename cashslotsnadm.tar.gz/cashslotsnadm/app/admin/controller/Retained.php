<?php
namespace app\admin\controller;

use app\admin\model\StatMarketDay;
use think\App;
use app\admin\model\Account as AccountModel;
use think\Request;

class Retained extends Base
{
    protected $notNeedRight = ['new_loss','active_loss'];
    protected $account_model;

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->account_model = new AccountModel();
    }

    /****
     * 留存/流失率统计
     * @param Request $request
     * @return string|\think\response\Json
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $start_time = strtotime($request->get('start_time'))?:strtotime('-14 days');

            $end_time = strtotime($request->get('end_time')) ?: time();

            $time_arr = [$start_time,$end_time];
            $limit = $request->get('limit/d');

            $query = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,stay1,stay3,stay7,stay14,stay30,dau,dnu,last_dau")->whereBetween('create_time',$time_arr)->order('create_time desc');

            $list = $query->paginate($limit);
            $query = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,stay1,stay3,stay7,stay14,stay30,dau,dnu,last_dau")->whereBetween('create_time',$time_arr)->order('create_time asc');
            $lists = $query->select()->toArray();

            foreach ($lists as &$val){
                $val['stay1'] = round($val['stay1'] * 100,2);
                $val['stay7'] = round($val['stay7'] * 100,2);
                $val['stay14'] = round($val['stay14'] * 100,2);
                $val['stay30'] = round($val['stay30'] * 100,2);
            }

            $x_data = array_column($lists,'create_times');
            $y_data = array_column($lists,'dau'); //总用户
            $y_data1 = array_column($lists,'dnu'); // 新增用户
            $y_data2 = array_column($lists,'stay1');
            $y_data3 = array_column($lists,'stay7');
            $y_data4 = array_column($lists,'stay14');
            $y_data5 = array_column($lists,'stay30');

            return json(['code'=>200,'datas'=>compact('y_data5', 'y_data4','y_data3','y_data2','y_data1', 'y_data','x_data'),'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
            }
        return $this->fetch();
    }

    /****
     * 新增用户流失
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function new_loss(Request $request){
        $start_time = strtotime($request->get('start_time'))?:0;

        $end_time = strtotime($request->get('end_time')) ?: time();

        $time_arr = [$start_time,$end_time];

        $query = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,stay1,dnu,ltv7,ltv14,stay7,stay14,stay30,stay1,stay3,stay7")->append(['flow1','flow7','flow14','flow30'])->whereBetween('create_time',$time_arr)->order('create_time desc');
        $limit = $request->get('limit/d');

        $list = $query->paginate($limit);
        foreach ($list as &$value){
            $value['all_count'] = $value['dnu'];
        }
        $query = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,stay1,dnu,ltv7,ltv14,stay7,stay14,stay30,stay1,stay3,stay7")->append(['flow1','flow7','flow14','flow30'])->whereBetween('create_time',$time_arr)->order('create_time asc');

        $lists = $query->select()->toArray();

        $x_data = array_column($lists,'create_times');
        $y_data = array_column($lists,'flow7');
        $y_data1 = array_column($lists,'flow14');
        return json(['code'=>200,'datas'=>compact('y_data1', 'y_data','x_data'),'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
    }

    /***
     * 活跃流失
     * @param Request $request
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function active_loss(Request $request){
        $start_time = strtotime($request->get('start_time'))?:strtotime( '-30day');

        $end_time = strtotime($request->get('end_time')) ?: time();

        $time_arr = [$start_time,$end_time];

        $query = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,dau,ltv7,ltv14,stay14,stay30,stay1,stay3,stay7")->append(['flow1','flow7','flow14','flow30'])->whereBetween('create_time',$time_arr)->order('create_time desc');

        $limit = $request->get('limit/d');

        $list = $query->paginate($limit);

        $query = StatMarketDay::field("FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times,dau,ltv7,ltv14,stay14,stay30,stay1,stay3,stay7")->append(['flow1','flow7','flow14','flow30'])->whereBetween('create_time',$time_arr)->order('create_time asc');

        $lists = $query->select()->toArray();


        $x_data = array_column($lists,'create_times');
        $y_data = array_column($lists,'flow7');
        $y_data1 = array_column($lists,'flow14');
        return json(['code'=>200,'datas'=>compact('y_data1', 'y_data','x_data'),'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
    }

}