<?php
namespace app\admin\controller;

use app\admin\model\DUser;
use org\Curl;
use think\App;
use think\facade\Db;
use think\facade\Lang;
use think\Request;

class System extends Base
{
    protected $notNeedRight = [];

    /***
     * 流失等级百分比分布
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function state_level_dist(Request $request){
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [strtotime('-30 day '),time()];
        }
        $list = DUser::getLevelDistribution($time_arr[0], $time_arr[1]);
        if ($request->get('is_export')){
            $list_key = [
                'title',
                'num',
                'rate',
            ];
            $lang_key = [
                'title' => '等级',
                'num' => '人数',
                'rate'=>'百分比'
            ];
            $this->exportExcel($list_key,$list,'流失等级百分比分布',$lang_key);
            return false;
        }

        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 流失充值百分比分布
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function state_recharge_dist(Request $request){
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $export = $request->get('export');
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{

            $time_arr = [strtotime('-30 days'),time()];
        }
        $list = DUser::getRechargeDistribution($time_arr[0], $time_arr[1]);
        if ($request->get('is_export')){
            $list_key = [
                'num',
                'rate',
                'title',
            ];
            $key_list= [
                'title' =>\lang('charge_title'),
                'num' => '人数',
                'rate'=>'百分比'
            ];
            $this->exportExcel($list_key,$list,'流失充值百分比分布',$key_list);
            return false;
        }

        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 流失金币百分比分布
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function state_coin_dist(Request $request){
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [strtotime('-30 days'),time()];
        }
        $list = DUser::getCoinDistribution($time_arr[0],$time_arr[1]);
        if ($request->get('is_export')){
            $list_key = [
                'num',
                'rate',
                'title',
            ];
            $key_list= [
                'title' => lang('coin_title'),
                'num' => '人数',
                'rate'=>'百分比'
            ];
            $this->exportExcel($list_key,$list,'流失金币百分比分布',$key_list);
            return false;
        }

        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 流失最后游戏百分比分布
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function state_gameloss_dist(Request $request){
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [strtotime('-30 days'),time()];
        }
        $list = DUser::getGameLostDist($time_arr[0], $time_arr[1]);
        $curl = new Curl();
        $lang = Lang::defaultLangSet() == 'zh-cn' ? 1 :2;
        $gameLists = $curl->getGameLists($lang,1);
        foreach($list as $k=>&$v) {
            $v['title'] = isset($gameLists[$k]) ? $gameLists[$k]['name'] : '';
        }
        if ($request->get('is_export')){
            $list_key = [
                'num',
                'rate',
                'title',
            ];
            $lang_key = [
                'title' => \lang('game_title'),
                'num' => '人数',
                'rate'=>'百分比'
            ];
            $list = array_values($list);
            $this->exportExcel($list_key,$list,'流失最后游戏百分比分布',$lang_key);
            return false;
        }

        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 流失分布列表
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function state_gameloss_list(Request $request){
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export/d',0);
        $limit = $request->get('limit/d');
        $uids = $request->get('uid', '');

        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{

            $time_arr = [strtotime('-30 days'),time()];
        }
        $condition = [];
        $condition[] = ['create_time','>=',$time_arr[0]];
        $condition[] = ['create_time','<=',$time_arr[1]];
        if($uids) $condition[] = ['uid', 'in', $uids];
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $query = DUser::where($condition)->where('uid', 'not in', $testAccount)->order('login_time desc');
        if ($is_export){
            $list = $query->select();
        }else{
            $list = $query->paginate($limit);
        }

        $sql = "select sum(a.amount) as price, a.uid from s_shop_order a join (select uid from d_user where create_time>={$time_arr[0]} and login_time<={$time_arr[1]}) b on a.uid =b.uid where a.status=2 group by a.uid";
//        $field = 'uid, coin, from_unixtime(create_time) as create_time, level, from_unixtime(login_time) as login_time';

        $shopLists = Db::connect('game')->query($sql);

        $shopUids = [];
        foreach($shopLists as $row) {
            $shopUids[$row['uid']] = $row['price'];
        }
        $lastgameid = [];
        $uids_arr = [];
        foreach($list as $row) {
            $uids_arr[] = $row['uid'];
        }
        if(!empty($uids_arr)) {
            $sql = "select a.game_id, a.create_time, a.account_id from gameserver_gamelog a join (select max(create_time) as create_time, account_id from gameserver_gamelog where account_id in (". implode(',', $uids_arr). ") and create_time>={$time_arr[0]} and create_time<={$time_arr[1]} and game_id <=1000 group by account_id) b on a.account_id = b.account_id and a.create_time = b.create_time where a.create_time>={$time_arr[0]} and a.create_time<={$time_arr[1]} and game_id <=1000";

            $lastGameResult = Db::query($sql);
            foreach($lastGameResult as $row) {
                $lastgameid[$row['account_id']] = [
                    'gameid' => $row['game_id'],
                    'gametime' => date('Y-m-d H:i:s', $row['create_time'])
                ];
            }
            // file_put_contents("/tmp/gamelists.txt", "\r\n lastgameid \r\n" . json_encode($lastgameid)."\r\n", FILE_APPEND);
        }
        $curl = new Curl();
        $lang = Lang::defaultLangSet() == 'zh-cn' ? 1 :2;

        $gameLists = $curl->getGameLists($lang,1);
        // file_put_contents("/tmp/gamelists.txt", "\r\n gameLists \r\n" . json_encode($gameLists)."\r\n", FILE_APPEND);
        foreach($list as &$v) {
            $v['price'] = isset($shopUids[$v['uid']]) ? $shopUids[$v['uid']] : 0; //购买总金额
            $v['last_game_id'] = isset($lastgameid[$v['uid']]) ? $lastgameid[$v['uid']]['gameid'] : 0;
            $v['last_game_title'] =  isset($gameLists[$v['last_game_id']]) ? $gameLists[$v['last_game_id']]['name'] : '';
            $v['last_game_time'] = isset($lastgameid[$v['uid']]) ? $lastgameid[$v['uid']]['gametime'] : '';
        }
        if ($is_export){
            $list_key = [
                'uid',
                'coin',
                'level',
                'price',
                'create_time',
                'login_time',
                'last_game_title',
                'last_game_time'
            ];
            $this->exportExcel($list_key,$list,'流失充值百分比分布');
            return false;
        }

        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }

        return $this->fetch();
    }
}