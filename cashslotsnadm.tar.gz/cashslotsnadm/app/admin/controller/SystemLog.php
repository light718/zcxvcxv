<?php
namespace app\admin\controller;

use app\admin\model\LogApiBackoffice;
use think\App;
use think\Request;

class SystemLog extends Base
{
    protected $notNeedRight = [];

    /**
     * 操作记录
     * @param Request $request
     * @return string
     */
    public function index(Request $request){
        $condition = [];
        $list = [];
        if ($keyword = input('keyword','','trim')){
            $condition[] = ['ac.username|lbo.t','like',"%".$keyword."%"];
        }
        $time_arr = [];
        $time_arr[] =  strtotime(input('start_time')) ?:0;
        $time_arr[] = strtotime(input('end_time',date('Y-m-d'))." H:i:s")?:time();

        $condition[] = ['lbo.create_time','between',$time_arr];

        $list = LogApiBackoffice::field('lbo.*,ac.username as account_username')->alias('lbo')->join('account ac','lbo.account_id =ac.id')->where($condition)->order('create_time desc')->paginate(20);

        return $this->fetch(__FUNCTION__ ,compact('list'));
    }

}