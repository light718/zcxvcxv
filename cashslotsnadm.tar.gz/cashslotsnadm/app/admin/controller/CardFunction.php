<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/3/11
 * Time: 11:02
 */

namespace app\admin\controller;
use app\admin\model\DHerocard;
use app\admin\model\SGameType;
use app\admin\model\SHerocamp;
use app\admin\model\SHerocard;
use app\admin\model\SHerocardCardDrop;
use app\admin\model\SHerocardGameDrop;
use app\admin\model\SHerocardLevel;
use app\admin\model\SHerocardSkill;
use app\admin\model\SHerocardStar;
use think\App;
use think\db\Query;
use think\Request;

class CardFunction extends Base
{
    protected $notNeedRight = ['edit', 'getOnlineData', 'editStatus', 'batchTag', 'hero_card_show'];

    /***
     * 英雄阵营列表
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function index(Request $request){
        $condition = [];
        $query = SHerocamp::with(['get_card'=>function(Query $query){
            $query->field('count(id) as t,campid')->group('campid');
        }])->where($condition)->order('id desc');

        if ($request->get('is_export/d')){
            $list = $query->select();
            foreach ($list as &$value){
                $value['card_count'] = $value['get_card']['t'];
            }
            $list_key = [
                'id',
                'campid',
                'name',
                'card_count',
            ];
            $this->exportExcel($list_key,$list,'英雄阵营列表',[
                'id'=>'编号',
                'campid'=>'阵营编号',
                'name'=>'阵营名称',
                'card_count' =>'卡牌数量'
            ]);
        }
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $list = $query->paginate($limit);
            foreach ($list as &$value){
                $value['card_count'] = $value['get_card']['t'];
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>\lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 卡牌星级
     * @param Request $request
     * @return string
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function card_star(Request $request){
        $condition = [];
        $query = SHerocardStar::with(['get_card'=>function(Query $query){
            $query->field('name,cardid');
        }])->where($condition)->order('id desc');
        if ($request->get('is_export/d')){
            $list = $query->select();
            foreach ($list as &$value){
                $value['card_name'] = $value['get_card']['name'];
            }
            $list_key = [
                'cardid',
                'star',
                'need_chips',
                'card_name',
            ];
            $this->exportExcel($list_key,$list,[
                'cardid'=>'卡牌名称',
                'star'=>'卡牌星级',
                'need_chips' =>'升星所需要的碎片',
                'card_name' => '卡牌名称',
            ]);
        }
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $list = $query->paginate($limit);
            foreach ($list as &$value){
                $value['card_name'] = $value['get_card']['name'];
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>\lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 卡牌升级
     * @param Request $request
     * @return string
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function card_level(Request $request){
        $condition = [];
        $query = SHerocardLevel::with(['get_game'=>function(Query $query){
            $query->field('title,gameid');
        }])->where($condition)->order('id desc');
        if ($request->get('is_export/d')){
            $list = $query->select();
            foreach ($list as &$value){
                $value['game_name'] = $value['get_game']['title'];
            }
            $list_key = [
                'cardid',
                'gameid',
                'level',
                'need_exp',
                'game_name'
            ];
            $this->exportExcel($list_key,$list,[
                'cardid'=>'卡牌ID',
                'gameid'=>'子游戏ID',
                'game_name' =>'子游戏名称',
                'level' => '卡牌等级',
                'need_exp' => '升级所需经验',
            ]);
        }
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $list = $query->paginate($limit);
            foreach ($list as &$value){
                $value['game_name'] = $value['get_game']['title'];
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>\lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 英雄卡牌列表
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function hero_card(Request $request){
        $condition = [];
        if ($campid = $request->get('campid')){
            $condition['campid'] = $campid;
        }

        if ($gameid = $request->get('gameid')){
            $condition['gameid'] = $gameid;
        }
        $query = SHerocard::with(['camp'=>function(Query $query){
            $query->field('campid,name');
        }])->where($condition)->order('id desc');
        if ($request->get('is_export/d')){
            $list = $query->select();
            foreach ($list as &$value){
                $value['camp_name'] = $value['camp']['name'];
            }
            $list_key = [
                'cardid',
                'name',
                'camp_name',
                'gameid',
                'unlock_chips',
                'init_star',
                'max_star',
                'unlock_awards'
            ];
            $lang_key = [
                'cardid'=>'卡牌ID',
                'name'=>'卡牌名称',
                'camp_name' =>'所属阵营',
                'gameid' => '子游戏ID',
                'unlock_chips' =>'解锁所需碎片',
                'init_star' => '初始星级',
                'max_star' =>'最大星级',
                'unlock_awards' => '解锁奖励金币',
            ];
            $this->exportExcel($list_key,$list,'英雄卡牌列表-'.date("Y-m-d"),$lang_key);
        }
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $list = $query->paginate($limit);
            foreach ($list as &$value){
                $value['camp_name'] = $value['camp']['name'];
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>\lang('return_success')]);
        }
        $camp_list = SHerocamp::select();
        $game_list = SGameType::select();
        $this->assign('camp_list',$camp_list);
        $this->assign('game_list',$game_list);
        return $this->fetch();
    }

    public function herocard_skill(Request $request){
        return $this->fetch();
    }

    /***
     * 玩家英雄卡列表
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function user_herocard(Request $request){
        $condition = [];
        if ($uid = $request->get('uid')){
            $condition['uid'] = $uid;
        }
        $query = DHerocard::with(['get_card'=>function(Query $query){
            $query->field('cardid,name');
        }])->where($condition)->order('cardid desc');
        if ($request->get('is_export/d')){
            $list = $query->select();
            foreach ($list as &$value){
                $value['card_name'] = $value['get_card']['name'];
            }
            $list_key = [
                'uid',
                'cardid',
                'card_name',
                'chips',
                'star',
                'lv',
                'exp',
            ];
            $lang_key = [
                'uid'=>'玩家ID',
                'cardid'=>'卡牌ID',
                'chips' =>'碎片数量',
                'star' => '卡牌星级',
                'lv' =>'卡牌等级',
                'exp' => '当前经验',
                'card_name' =>'卡牌名称',
            ];
            $this->exportExcel($list_key,$list,'玩家英雄卡列表'.date('Y-m-d'),$lang_key);
        }
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $list = $query->paginate($limit);
            foreach ($list as &$value){
                $value['card_name'] = $value['get_card']['name'];
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>\lang('return_success')]);
        }

        return $this->fetch();
    }

    /**hero_card_show
     * 玩家英雄卡牌统计
     * @param Request $request
     * @return string
     */
    public function herocard_statics(Request $request ){
        $card_top_list = DHerocard::field('count(*) as t,uid')->group('uid')->select();
        $card_list = DHerocard::field("count(uid) as user_count, cardid, sum(chips) as total")->with(['get_card'=>function(Query $query){
             $query->field('cardid ,name');
        }])->group('cardid,uid')->order('total desc')->select();

        $this->assign('card_top_list',$card_top_list);
        $this->assign('card_list',$card_list);
        return $this->fetch();
    }

    public function hero_card_show($id){
        $row = SHerocard::with(['camp'=>function(Query $query){
            $query->field('campid,name');
        }])->where(compact('id'))->find();
        $row['skill'] = SHerocardSkill::where(['skillid'=>$row['skillid']])->find();
        $row['star'] = SHerocardStar::find();
        $row['level'] = SHerocardLevel::find();
        $row['game_drop'] = SHerocardGameDrop::with(['game'=>function(Query $query){
            $query->field('gameid,title');
        }])->where(['gameid'=>$row['gameid']])->find();
        $row['card_drop'] = SHerocardCardDrop::where(['cardid'=>$row['cardid'],'gameid'=>$row['gameid']])->find();
        $this->assign('row',$row);
        return $this->fetch();
    }
}