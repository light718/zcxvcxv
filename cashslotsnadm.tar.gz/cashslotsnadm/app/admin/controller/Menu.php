<?php
namespace app\admin\controller;

use app\common\model\AuthRule as AuthRuleModel;
use think\App;
use think\Request;

class Menu extends Base
{
    protected $notNeedRight = ['add', 'edit', 'delete'];
    protected $auth_rule_model;

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->auth_rule_model = new AuthRuleModel();
        $admin_menu_list       = $this->auth_rule_model->order('sort DESC,id => ASC')->select();

        $this->menu_level_list =$admin_menu_level_list = array2level($admin_menu_list);

        $this->assign('admin_menu_level_list', $admin_menu_level_list);
    }
    /***
     * 首页
     * @return string
     */
    public function index(Request $request)
    {
        $this->auth_rule_model = new AuthRuleModel();
        return $this->fetch();
    }

    /***
     * @param Request $request
     * @return string
     */
    public function add(Request $request){
        $id = $request->get('id');
        $pid = $request->get('pid');
        if ($request->isPost()){
            $post_param = $request->param();
            if ($id){
                $re = $this->auth_rule_model->update($post_param,compact('id'));
            }else{
                $re = $this->auth_rule_model->save($post_param);
            }
            if($re){
                response('操作成功');
            }else{
                response('操作失败');
            }
        }
        $auth_re = $this->auth_rule_model->find($id);

        return $this->fetch(__FUNCTION__,compact('auth_re','id','pid'));
    }

    public function edit($id)
    {
        $admin_menu = $this->auth_rule_model->find($id);
        return $this->fetch('edit', ['admin_menu' => $admin_menu,'id'=>$id,'admin_menu_level_list'=>$this->menu_level_list]);
    }

    public function delete($id)
    {
        $sub_menu = $this->auth_rule_model->where(['pid' => $id])->find();
        if (!empty($sub_menu)) {
            $this->error('此菜单下存在子菜单，不可删除');
        }
        if ($this->auth_rule_model->destroy($id)) {
            //操作日志
            $this->action_log('删除菜单,[菜单编号:'.$id.']');
            $this->success(lang('return_success'));
        } else {
            $this->error(lang('return_fail'));
        }
    }
}
