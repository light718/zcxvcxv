<?php

namespace app\admin\controller;

use app\admin\model\AccountGroup as AccountGroupModel;
use app\admin\model\AccountGroup;
use app\admin\model\AuthRule as AuthRuleModel;
use think\db\exception\DbException;

/**
 * 权限组
 * Class AuthGroup
 * @package app\admin\controller
 */
class AuthGroup extends Base
{
    protected $notNeedRight = ['getJson', 'edit', 'auth', 'delete', 'updateAuthGroupRule'];
    protected $account_group_model;
    protected $auth_rule_model;

    public function initialize()
    {
        parent::initialize();
        $this->account_group_model = new AccountGroupModel();
        $this->auth_rule_model = new AuthRuleModel();
    }

    /**
     * 权限组
     * @return mixed
     */
    public function index()
    {
        //对的看属于自己的账号

        $auth_group_list = $this->account_group_model->select();
//        $auth_group_list = collect($auth_group_list)->toArray();
        return $this->fetch('index', ['auth_group_list' => $auth_group_list]);
    }

    /**
     * 添加权限组
     * 添加权限组
     * @return mixed
     */
    public function add()
    {
        return $this->fetch();
    }

    /**
     * 保存权限组
     */
    public function save()
    {
        if ($this->request->isPost()) {
            $data = $this->request->post();
            if (isset($data['type'])) {
                if ($data['type'] == 1) {
                    $data['belong'] = 0;

                } else {
                    $data['belong'] = session('org');


                }

            }
            if ($belong = input('post.belong')) {
                $data['belong'] = $belong;
            }
            unset($data['type']);
            if ($data['level'] < (new \app\common\model\Account())->getMemberLevel() && $data['level'] >= 1/*&&$data['belong'] ==session('org')*/ && session('admin_id') != 1) {
                $this->error('没有权限去增加等级比你大的权限组');
            }

            if ($this->auth_group_model->save($data) !== false) {
                //操作日志
                $this->action_log('添加权限组,[权限组编号:' . $this->auth_group_model->id . ']');
                $this->success('保存成功', 'index');
            } else {
                $this->error('保存失败');
            }
        }
    }

    /**
     * 编辑权限组
     * @param $id
     * @return mixed
     */
    public function edit()
    {
        $id = input('id');
        $post_param = $this->request->post();
        if ($this->request->isPost()){
            if (input('post.id')){
                $re = $this->account_group_model->allowField(['appid','name','subject','dec','agent'])->where(compact('id'))->update($post_param);

            }else{
                $re = $this->account_group_model->allowField(['appid','name','subject','dec','agent'])->save($post_param);
            }
            if ($re){
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('error'));
            }
        }

        $auth_group = $this->account_group_model->find($id);

        return $this->fetch('edit', ['auth_group' => $auth_group]);
    }

    /**
     * 更新权限组
     * @param $id
     */
    public function update()
    {
        $id = input('id');
        $id or $this->error('请输入角色id,没有绑定角色');
        if ($this->request->isPost()) {
            $data = $this->request->post();

            if ($id == 1 && $data['status'] != 1) {
                $this->error('超级管理组不可禁用');
            }
            if ($data['level'] < (new \app\common\model\Account())->getMemberLevel() && $data['level'] >= 1 && session('admin_id') != 1) {
                $this->error('没有权限去增加等级比你大的权限组');
            }
            if (session('admin_id') != 1) {
                unset($data['level']);
            }
            if ($this->auth_group_model->save($data, $id) !== false) {
                //操作日志
                $this->action_log('更新权限组,[权限组编号:' . $id . ']');
                $this->success('更新成功');
            } else {
                $this->error('更新失败');
            }
        }
    }

    /**
     * 删除权限组
     * @param $id
     */
//    public function delete($id)
//    {
//        if ($id == 1) {
//            $this->error('超级管理组不可删除');
//        }
//        if ($this->auth_group_model->destroy($id)) {
//            //操作日志
//            $this->action_log('删除权限组,[权限组编号:'.$id.']');
//            $this->success('删除成功');
//        } else {
//            $this->error('删除失败');
//        }
//    }

    /**
     * 授权
     * @param $id
     * @return mixed
     */
    public function auth()
    {
        if (!$id = input('id')) {
            $this->error('账户没有绑定角色');
        }
        return $this->fetch('auth', ['id' => $id]);
    }

    /**
     * AJAX获取规则数据
     * @param $id
     * @return mixed
     */
    public function getJson($id)
    {

        $auth_group_data = $this->account_group_model->find($id)->toArray();
        $auth_rules = explode(',', $auth_group_data['rules']);
        $list = [];
        foreach ($auth_rules as $key => $val) {
            $list[] = $val;
        }

        $auth_rule_list = $this->auth_rule_model->field('id,pid,title')->select();

        foreach ($auth_rule_list as $key => $value) {
            in_array($value['id'], $auth_rules) && $auth_rule_list[$key]['checked'] = true;
        }

        echo json_encode($auth_rule_list);
        exit;
    }

    /**
     * 更新权限组规则
     * @param $id
     * @param $auth_rule_ids
     */
    public function updateAuthGroupRule($id, $auth_rule_ids = '')
    {

        if ($this->request->isPost()) {
            if ($id) {
                $group_data = [];
                $group_data['rules'] = is_array($auth_rule_ids) ? implode(',', $auth_rule_ids) : '';
                $update_re = $this->account_group_model->where(compact('id'))->update($group_data);
                if ($update_re) {
                    return $this->jsonReturn(EXIT_SUCCESS, lang('success'));
                } else {
                    return $this->jsonReturn(EXIT_ERROR, lang('error'));
                }

            }
        }
    }

    /***
     * @return string
     * @throws DbException
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function delete()
    {
        $id = input('id');
        $del_re =  $this->account_group_model->where(compact('id'))->delete();
        if ($del_re){
            $this->success(lang('success'));
        }else{
            $this->error(lang('error'));
        }
    }
}