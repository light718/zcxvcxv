<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

/***
 * 平台类型数据统计
 */
class PlatformStat extends Base
{
    protected $notNeedRight = [];
    private $platformArr = [4 => '谷歌', 6 => '华为', 7 => '苹果'];

    /*** 平台ltv
     * @return string
     */
    public function platform_ltv(Request $request){
        $condition = [];
        if ($platform = $request->get('platform','','trim')){
            $condition[] = ['platform','=', $platform];
        }
  
        if($startTime = $request->get('start_time', false)){
            list($start, $end) = explode(' - ', $startTime);
            $start = date('Ymd', strtotime($start));
            $end = date('Ymd', strtotime($end . ' 23:59:59'));
            $condition[] = ['day', 'between', [$start, $end]];
        }
        $list = Db::name('stat_platform_day')->where($condition)
                ->order('day', 'desc')
                ->paginate(15);

        $data = $list->items();
        $stat = ['day' => '平均值', 'platform' => '全部'];
        foreach($data as $key => &$value){
            $value['platform'] = $this->platformArr[$value['platform']];
            foreach($value as $k => $v){
                if ($k != 'day' && $k != 'platform' ) {
                    if (isset($stat[$k])) {
                        $stat[$k] = $stat[$k] + $v;
                    }else{
                        $stat[$k] = $v;    
                    }
                }
            }
        }
        $cnt = count($data);
        if ($cnt > 0) {
            foreach ($stat as $k => &$value) {
                if ($k != 'day' && $k != 'platform' ) {
                    $value = number_format($value / $cnt, 2);
                }
            }
            $data[] = $stat;
        }

        return $this->fetch(__FUNCTION__,['list'=>$list, 'data' => $data]);
    }


    /*** 平台数据列表
     * @return string
     */
    public function platform_list(Request $request){
        $condition = [];
        if ($platform = $request->get('platform','','trim')){
            $condition[] = ['platform','=', $platform];
        }
  
        if($startTime = $request->get('start_time', false)){
            list($start, $end) = explode(' - ', $startTime);
            $start = date('Ymd', strtotime($start));
            $end = date('Ymd', strtotime($end . ' 23:59:59'));
            $condition[] = ['day', 'between', [$start, $end]];
        }

        $list = Db::name('stat_platform_day')->where($condition)
                ->order('day', 'desc')
                ->paginate(15);

        $data = $list->items();
        $stat = ['day' => '数据汇总', 'platform' => '全部'];
        foreach($data as $key => &$value){
            $value['platform'] = $this->platformArr[$value['platform']];
            foreach($value as $k => $v){
                if ($k != 'day' && $k != 'platform' ) {
                    if (isset($stat[$k])) {
                        $stat[$k] = $stat[$k] + $v;
                    }else{
                        $stat[$k] = $v;    
                    }
                }
            }
            $value['dnu_pay_rate'] = $value['dnu_pay_rate']  * 100 . '%';
            $value['pay_rate'] = $value['pay_rate']  * 100 . '%';
            $value['stay1'] = $value['stay1']  * 100 . '%';
            $value['stay3'] = $value['stay3']  * 100 . '%';
            $value['stay7'] = $value['stay7']  * 100 . '%';
        }
        $cnt = count($data);
        if ($cnt > 0) {
            $stat['dnu_pay_rate'] = $stat['dnu_pay_rate'] / $cnt * 100 . '%';
            $stat['pay_rate'] = $stat['pay_rate'] / $cnt * 100 . '%';
            $stat['stay1'] = $stat['stay1'] / $cnt * 100 . '%';
            $stat['stay3'] = $stat['stay3'] / $cnt * 100 . '%';
            $stat['stay7'] = $stat['stay7'] / $cnt * 100 . '%';
            $data[] = $stat;
        }
   
        return $this->fetch(__FUNCTION__,['list'=>$list, 'data' => $data]);
    }

}