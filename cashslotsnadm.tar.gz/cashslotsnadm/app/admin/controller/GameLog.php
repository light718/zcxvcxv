<?php
namespace app\admin\controller;

use app\admin\model\GameserverGamelog;
use app\admin\model\GameserverGamelogEvo;
use app\admin\model\SGame;
use app\admin\model\SGameType;
use think\App;
use think\Request;

class GameLog extends Base
{
    protected $notNeedRight = [];

    /**
     * 操作记录
     * @param Request $request
     * @return string
     */
    public function index(Request $request){
        $condition = [];
        $list = [];
        $type = $request->get('type/d',1);
        if ($type == 1){
            $model = new GameserverGamelog();
        }else{
            $model = new GameserverGamelogEvo();
        }
        if ($keyword = input('keyword','','trim')){
            $condition[] = ['gml.account_id','=',$keyword];
        }
        $time_arr = [];
        $time_arr[] =  strtotime(input('start_time')) ?:0;
        $time_arr[] = strtotime(input('end_time',date('Y-m-d H:i:s')));

        $condition[] = ['gml.create_time','between',$time_arr];
        $condition[] = ['gml.game_id','<=',1000];
        $type_list = SGameType::field('gameid,title')->select();

        $list_arr = [];
        foreach ($type_list as $value){
            $list_arr[$value['gameid']] = $value['title'];
        }
        if ($request->get('is_export/d')){
            $list = $model->alias('gml')->field('gml.*')->where($condition)->order('create_time desc')->select()->toArray();

            foreach ($list as &$value){
                $value['game_name'] = isset($list_arr[$value['game_id']]) ? $list_arr[$value['game_id']] :"";
                $value['bet'] = intval($value['bet']);
                $value['win'] = intval($value['win']);
                $value['before'] = intval($value['before']);
                $value['after'] = intval($value['after']);
            }
            $list_key = [
                'game_name',
                'account_id',
                'bet',
                'win',
                'before',
                'after',
                'create_time',
            ];
            $lang_key = [
                'game_name' => '游戏名称',
                'account_id' => '会员id',
                'bet' => '押注',
                'win' => '开始金额',
                'before' => '开始金额',
                'after' => '结束金额',
                'create_time' => '日期时间',
            ];
            $this->exportExcel($list_key,$list,'游戏记录导出'.date('Y-m-d'),$lang_key);
            exit;
        }
        $list = $model->alias('gml')->field('gml.*')->where($condition)->order('create_time desc')->paginate(['query'=>$request->param(),'list_rows'=>20],false);
        foreach ($list as &$value){
            $value['game_name'] = isset($list_arr[$value['game_id']]) ? $list_arr[$value['game_id']] :"";
            $value['bet'] = intval($value['bet']);
            $value['win'] = intval($value['win']);
            $value['before'] = intval($value['before']);
            $value['after'] = intval($value['after']);
        }
        return $this->fetch(__FUNCTION__ ,compact('list'));
    }

    /***
     * 详情
     * @param Request $request
     * @return string
     */
    public function detail(Request $request){
        $id = $request->get('log_id');
        if (!$id){
            $this->error(lang('return_fail'));
        }

        $res = GameserverGamelog::where(compact('id'))->find();
        $game_re = SGameType::where(['gameid'=>$res['game_id']])->find();

        $rlt = json_decode($res['rlt'],true);
        return $this->fetch(__FUNCTION__,compact('res','game_re','rlt'));
    }
}