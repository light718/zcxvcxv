<?php

namespace app\admin\controller;

use app\admin\model\DUser;
use app\admin\model\GameserverGamelog;
use app\admin\model\PoolNormal;
use app\admin\model\SGameType;
use app\admin\model\StatAppLogAreastartapp;
use app\admin\model\StateSlotsPayrate;
use app\admin\model\StateSlotsPayrateDay;
use app\admin\model\StatMainpoll;
use app\admin\model\StatOnlineGame;
use org\Curl;
use think\App;
use think\Exception;
use think\facade\Db;
use think\facade\Lang;
use think\Request;

class Report extends Base
{
    protected $notNeedRight = ['big_player'];

    /***
     * 分类数据
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function game_data(Request $request)
    {
        $start_times = $request->get('start_time');
        $start_time = explode('~', $start_times);
        $is_export = $request->get('is_export');
        $limit = $request->get('limit/d', 15);
        if ($start_times) {
            $time_arr = [strtotime($start_time[0]), strtotime($start_time[1])];
        } else {
            $time_arr = [strtotime('-30 day '), time()];
        }
        $fields = 'game_id, COUNT(DISTINCT account_id) AS aux, COUNT(1) AS bet_num, SUM(bet) AS bet, SUM(bet-win) as sys_win_coin, SUM(IF(win<bet,1,0)) as sys_win_num';
        $query = GameserverGamelog::field($fields)->whereBetween('create_time', $time_arr)->group('game_id')->order('aux desc');

        if ($is_export) {
            $list = $query->select();
        } else {
            $list = $query->paginate($limit);
        }
        $curl = new Curl();
        $lang = $curl->getLang(Lang::defaultLangSet());
        $gameLists = $curl->getGameLists($lang, 1);
        foreach ($list as &$one) {

            $one['game_name'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['name'] : '';
            if (empty($one['game_name'])) {
                $one['game_name'] = $this->getActGameName($one['game_id']);
            }
            if (empty($one['game_name']) || !$one['game_name']) {
                $one['game_name'] = $one['game_id'];
            }
            $one['sys_win_ratio'] = ($one['bet_num'] > 0.1 && $one['sys_win_num'] > 0) ? ($one['sys_win_num'] / $one['bet_num']) : 0;
            $one['sys_win_coin_ratio'] = (intval($one['bet']) > 1 && $one['sys_win_coin'] > 0) ? ($one['sys_win_coin'] / $one['bet']) : 0;
            $one['bet'] = formatMoney($one['bet']);
            $one['sys_win_coin'] = formatMoney($one['sys_win_coin']);

        }
        if ($is_export) {
            $list_key = [
                'game_name',
                'aux',
                'bet_num',
                'bet',
                'sys_win_coin',
                'sys_win_ratio',
                'sys_win_coin_ratio',
            ];
            $this->exportExcel($list_key, $list, '流失等级百分比分布');
            return false;
        }

        if ($request->isAjax()) {
            return json(['code' => 200, 'data' => $list->items(), 'count' => $list->total(), 'msg' => lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 当天输赢最大的50列表
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function game_win_list(Request $request)
    {
        $startDate = $request->get('start_time',date('Y-m-d'));

        $redis = $this->getRedisObj();
        $preKey = 'gameWinList_';
        $cacheKey = $preKey . $startDate;
        $lostList = $redis->zRangeByScore($cacheKey, '-inf', '+inf', array('withscores' => true, 'limit' => array(0, 50)));
        asort($lostList);
        $loseData = [];
        $i = 1;
        foreach ($lostList as $k => $v) {
            $item = [
                'id' => $i,
                'uid' => $k,
                'wincoin' => $v,
            ];
            $loseData[] = $item;
            $i++;
        }
        $winList = $redis->zRevRangeByScore($cacheKey, '+inf', '-inf', array('withscores' => true, 'limit' => array(0, 50)));
        arsort($winList);
        $winData = [];
        $i = 1;
        foreach ($winList as $k => $v) {
            $item = [
                'id' => $i,
                'uid' => $k,
                'wincoin' => $v,
            ];
            $winData[] = $item;
            $i++;
        }
        $winlist = $winData;
        $lostlist = $loseData;
        return $this->fetch(__FUNCTION__, compact('winlist', 'lostlist', 'count'));
    }

    /***
     * 当天slots游戏的回报率
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function game_payrate_today(Request $request)
    {
        $start_times = $request->get('start_time');
        $start_time = explode('~', $start_times);
        if ($start_times) {
            $time_arr = [strtotime($start_time[0]), strtotime($start_time[1])];
        } else {
            $time_arr = [strtotime('-30 days'), time()];
        }
        $is_export = input('is_export/d', 0);
        $limit = input('limit/d', 15);
        $list = StateSlotsPayrateDay::getListData($time_arr, $is_export, $limit);
        $gameList = $this->getGameList(1);
        foreach ($list as &$value) {
            if (isset($gameList[$value['game_id']])) {
                $value['title'] = $gameList[$value['game_id']]['name'];
            }
            $value['payrate'] = $this->_getFloat($value['win'], $value['bet'], 1);
            $value['day'] = date('Y-m-d', $value['day']);
        }
        if ($request->get('is_export')) {
            $list_key = [
                'id',
                'title',
                'bet',
                'win',
                'payrate',
                'day',
            ];

            $key_list = [
                'title' => lang('coin_title')
            ];
            $this->exportExcel($list_key, $list, '当天slots游戏的回报率', $key_list);
            return false;
        }

        if ($request->isAjax()) {
            return json(['code' => 200, 'data' => $list->items(), 'count' => $list->total(), 'msg' => lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 老虎机游戏回报率(总)
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function game_payrate(Request $request)
    {
        $start_times = $request->get('start_time');
        $start_time = explode('~', $start_times);
        if ($start_times) {
            $time_arr = [strtotime($start_time[0]), strtotime($start_time[1])];
        } else {
            $time_arr = [strtotime('-30 days'), time()];
        }
        $is_export = input('is_export/d', 0);
        $limit = input('limit/d', 15);
        $list = StateSlotsPayrate::getListData($time_arr, $is_export, $limit);
        $gameList = $this->getGameList(1);
        foreach ($list as &$value) {
            if (isset($gameList[$value['game_id']])) {
                $value['title'] = $gameList[$value['game_id']]['name'];
            }
            $value['payrate'] = $this->_getFloat($value['win'], $value['bet'], 1);
            $value['day'] = date('Y-m-d', $value['day']);
        }
        if ($request->get('is_export')) {
            $list_key = [
                'id',
                'title',
                'bet',
                'win',
                'payrate',
                'day',
            ];
            $key_list = [
                'title' => lang('coin_title')
            ];
            $this->exportExcel($list_key, $list, '老虎机游戏回报率(总)', $key_list);
            return false;
        }

        if ($request->isAjax()) {
            return json(['code' => 200, 'data' => $list->items(), 'count' => $list->total(), 'msg' => lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 流失分布列表
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function big_player(Request $request)
    {
        $start_times = $request->get('start_time');
        $start_time = explode('~', $start_times);
        $is_export = $request->get('is_export/d', 0);
        $limit = $request->get('limit/d');

        $start_times = $request->get('start_time');
        $start_time = explode('~', $start_times);
        if ($start_times) {
            $time_arr = [strtotime($start_time[0]), strtotime($start_time[1])];
        } else {

            $time_arr = [strtotime('-30 days'), time()];
        }
        $condition = [];
        $condition[] = ['create_time', '>=', $time_arr[0]];
        $condition[] = ['login_time', '<=', $time_arr[1]];
        $query = DUser::where($condition)->order('login_time desc');
        if ($is_export) {
            $list = $query->select();
        } else {
            $list = $query->paginate($limit);
        }

        $sql = "select sum(a.amount) as price, a.uid from s_shop_order a join (select uid from d_user where create_time>={$time_arr[0]} and login_time<={$time_arr[1]}) b on a.uid =b.uid where a.status=2 group by a.uid";
//        $field = 'uid, coin, from_unixtime(create_time) as create_time, level, from_unixtime(login_time) as login_time';

        $shopLists = Db::connect('game')->query($sql);

        $shopUids = [];
        foreach ($shopLists as $row) {
            $shopUids[$row['uid']] = $row['price'];
        }
        $lastgameid = [];
        $uids_arr = [];
        foreach ($list as $row) {
            $uids_arr[] = $row['uid'];
        }
        if (!empty($uids_arr)) {
            $sql = "select a.game_id, a.create_time, a.account_id from gameserver_gamelog a join (select max(create_time) as create_time, account_id from gameserver_gamelog where account_id in (" . implode(',', $uids_arr) . ") and create_time>={$time_arr[0]} and create_time<={$time_arr[1]} and game_id <=1000 group by account_id) b on a.account_id = b.account_id and a.create_time = b.create_time where a.create_time>={$time_arr[0]} and a.create_time<={$time_arr[1]}";

            $lastGameResult = Db::query($sql);
            foreach ($lastGameResult as $row) {
                $lastgameid[$row['account_id']] = [
                    'gameid' => $row['game_id'],
                    'gametime' => date('Y-m-d H:i:s', $row['create_time'])
                ];
            }
        }
        $curl = new Curl();
        $lang = Lang::defaultLangSet() == 'zh-cn' ? 1 : 2;

        $gameLists = $curl->getGameLists($lang, 1);
        foreach ($list as &$v) {
            $v['price'] = isset($shopUids[$v['uid']]) ? $shopUids[$v['uid']] : 0; //购买总金额
            $v['last_game_id'] = isset($lastgameid[$v['uid']]) ? $lastgameid[$v['uid']]['gameid'] : 0;
            $v['last_game_title'] = isset($gameLists[$v['last_game_id']]) ? $gameLists[$v['last_game_id']]['name'] : '';
            $v['last_game_time'] = isset($lastgameid[$v['uid']]) ? $lastgameid[$v['uid']]['gametime'] : '';
        }
        if ($is_export) {
            $list_key = [
                'uid',
                'coin',
                'level',
                'price',
                'create_time',
                'login_time',
                'last_game_title',
                'last_game_time'
            ];
            $this->exportExcel($list_key, $list, '流失充值百分比分布');
            return false;
        }

        if ($request->isAjax()) {
            return json(['code' => 200, 'data' => $list->items(), 'count' => $list->total(), 'msg' => lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 下注次数
     * @param Request $request
     * @return string
     */
    public function bet_nums(Request $request)
    {
        if ($request->isAjax()) {
            $type = $request->get('type/d', 1);

        }

        return $this->fetch();
    }

    /***
     *
     * @param Request $request
     * @return \think\response\Json
     */
    public function game_mainpool_by_day(Request $request)
    {
        $limit = $request->get('limit/d', 15);
        $startTime = strtotime($request->get('start_time', date('Y-m-d')));
        $endTime = $startTime + (60 * 60 * 24);
        $condition = [];
        $condition[] = ['create_time', 'between', [$startTime, $endTime]];
        $condition[] = ['type', 'in', [1, 2]];
        $list = PoolNormal::field("game_id,SUM(coin) AS coin")->group('game_id')->select()->toArray();
        if ($list) {
            $list = array_column($list, 'coin', 'game_id');
        }
        $list[0] = array_sum($list); // 总库存
        foreach ($list as &$one) {
            $one = format_money($one);
        }
        $todayData = $list;
        $gameList = $this->getGameList(1);
        $totalCoin = 0;
        $data = [];
        $data[] = ['title' => \lang('total'), 'num' => $list[0]];
        foreach ($gameList as $row) {
            $tmp = [];
            $tmp['title'] = $row['name'];
            $coin = isset($todayData[$row['id']]) ? $todayData[$row['id']] : 0;
            $totalCoin += $coin;
            if ($coin >= 0) {
                $tmp['color_css'] = 'stc_' . explode(',', $row['type'])[0];
            } else {
                $tmp['color_css'] = 'stc_6';
            }
            $tmp['num'] = formatMoney($coin);
            $data[] = $tmp;
        }
        return json(['code' => 200, 'data' => $data, 'msg' => '']);

    }

    /***
     * 库存变化
     * @param Request $request
     * @return string
     */
    public function game_mainpool(Request $request)
    {
        if ($request->isAjax()) {
            $game_id = $request->get('game_id');

            $gameIds[] = 0; // 总库存
            $gameIds[] = $game_id; // 总库存

            $endTime = strtotime(date('Y-m-d', strtotime('-1 day')));
            $startTime = $endTime - 86400 * 6;
            $data = [];
            $condition = [];
            $condition[] = ['dtime', 'between', [$startTime, $endTime]];
            $list = StatMainpoll::field('dtime,data')->where($condition)->select()->toArray();
            $y_data = [];
            $y_data1 = [];
            $x_data = array_column($list, 'dtime');
            foreach ($list as $row) {
                foreach ($gameIds as $key => $game) {
                    $counts = isset($row['data'][$game]) ? $row['data'][$game] : '0.00';
                    if ($key == 1) {
                        $y_data[] = $counts;
                    } else {
                        $y_data1[] = $counts;
                    }
                }
            }
            $game_name = SGameType::where(['gameid' => $game_id])->value('title');
            return json(['code' => 200, 'data' => compact('x_data', 'y_data', 'y_data1', 'game_name')]);
        }
        $game_list = $this->getGameList(1);
        return $this->fetch(__FUNCTION__, compact('game_list'));
    }

    /***
     * 在线统计
     * @param Request $request
     * @return string
     */
    public function online(Request $request)
    {
        if ($request->isAjax()){
            $type =$request->get('type',1);
            $gameLists = $this->getGameList(1);
            $games = [];
            foreach ($gameLists as $row) {
                if ($type == $row['type']) {
                    $games[] = $row;
                }
            }
            $data = [];
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = array_column($games, 'name');
            $endTime = time();
            $startTime = $endTime - 86400;
            $params = array(
                date('Y-m-d H:i:00',$startTime),
                date('Y-m-d H:i:00',$endTime)
            );
            $x_data = [];
            $lists = StatOnlineGame::getStat5minGameOnlinePlayer($params);
            $list = [];

            foreach ($lists as &$row) {
                $gameData = $row['counts'];
                $x_data[] = date('m-d H:i', strtotime($row['datetime']));
                foreach ($games as $key => $game) {
                    if (isset($gameData[$game['id']]) ){
                        $list[] = ['title'=>$game['title'],'count'=>$gameData[$game['id']]];
                    }else{
                        $list[] = ['title'=>$game['title'],'count'=>0 ];
                    }
                    $data['data'][$key][] = isset($gameData[$game['id']]) ? $gameData[$game['id']] : '0.00';
                }
            }
            return json(['code'=>200,'msg'=> \lang('return_success'),'data'=>$list,'datas'=>compact('x_data')]);
        }
        return $this->fetch();
    }

    /***
     * App 启动次数分布
     * @param Request $request
     * @return string
     */
    public function startapp_data(Request $request)
    {
        if ($request->isAjax()){
            $type = $request->get('type/d',1);
            $startTime = $endTime = 0;
            $endTime = time();
            if ($type == 1) {
                $startTime = $endTime - 3600;
            } else if ($type == 2) {
                $startTime = $endTime - 86400;
            } else if ($type == 3) {
                $startTime = $endTime - 86400*7;
            } else if ($type == 4) {
                $startTime = $endTime - 86400*30;
            }
            $params = [
                'time' => $startTime,
                'time2' => $endTime
            ];
            $lists = StatAppLogAreastartapp::getAllStartTimes($startTime,$endTime );
            $result = [];
            $result['status'] = true;
            $result['namemap'] = $this->getCountryName();

            $data_list = [];
            foreach ($lists as $k=>$v) {
                if(!isset($data_list[$v['country']])) {
                    $data_list[$v['country']] = [
                        'name' => $v['countrycn'],
                        'value' => 0,
                    ];
                }
                $data_list[$v['country']]['value'] = $data_list[$v['country']]['value'] + $v['total'];
            }
            $result['dataArr'] = $data_list;

            $count = count($result);
            return json(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }
        return $this->fetch();
    }

    public function state_gameloss_list(Request $request)
    {

        return $this->fetch();
    }

    private function getCountryName() {
        return [
            "Afghanistan"=> "阿富汗",
            "Angola"=> "安哥拉",
            "Albania"=> "阿尔巴尼亚",
            "Algeria"=> "阿尔及利亚",
            "Argentina"=> "阿根廷",
            "Armenia"=> "亚美尼亚",
            "Australia"=> "澳大利亚",
            "Austria"=> "奥地利",
            "Azerbaijan"=> "阿塞拜疆",
            "Bahamas"=> "巴哈马",
            "Bangladesh"=> "孟加拉国",
            "Belgium"=> "比利时",
            "Benin"=> "贝宁",
            "Burkina Faso"=> "布基纳法索",
            "Burundi"=> "布隆迪",
            "Bulgaria"=> "保加利亚",
            "Bosnia and Herz."=> "波斯尼亚和黑塞哥维那",
            "Belarus"=> "白俄罗斯",
            "Belize"=> "伯利兹",
            "Bermuda"=> "百慕大群岛",
            "Bolivia"=> "玻利维亚",
            "Brazil"=> "巴西",
            "Brunei"=> "文莱",
            "Bhutan"=> "不丹",
            "Botswana"=> "博茨瓦纳",
            "Cambodia"=> "柬埔寨",
            "Cameroon"=> "喀麦隆",
            "Canada"=> "加拿大",
            "Central African Rep."=> "中非共和国",
            "Chad"=> "乍得",
            "Chile"=> "智利",
            "China"=> "中国",
            "Colombia"=> "哥伦比亚",
            "Congo"=> "刚果",
            "Costa Rica"=> "哥斯达黎加",
            "Côte d'Ivoire"=> "科特迪瓦",
            "Croatia"=> "克罗地亚",
            "Cuba"=> "古巴",
            "Cyprus"=> "塞浦路斯",
            "Czech Rep."=> "捷克共和国",
            "Dem. Rep. Korea"=> "韩国",
            "Dem. Rep. Congo"=> "民主刚果",
            "Denmark"=> "丹麦",
            "Djibouti"=> "吉布提",
            "Dominican Rep."=> "多米尼加共和国",
            "Ecuador"=> "厄瓜多尔",
            "Egypt"=> "埃及",
            "El Salvador"=> "萨尔瓦多",
            "Eq. Guinea"=> "赤道几内亚",
            "Eritrea"=> "厄立特里亚",
            "Estonia"=> "爱沙尼亚",
            "Ethiopia"=> "埃塞俄比亚",
            "Falkland Is."=> "福克兰群岛",
            "Fiji"=> "斐济",
            "Finland"=> "芬兰",
            "France"=> "法国",
            "French Guiana"=> "法属圭亚那",
            "Fr. S. Antarctic Lands"=> "法属南部领地",
            "Gabon"=> "加蓬",
            "Gambia"=> "冈比亚",
            "Germany"=> "德国",
            "Georgia"=> "佐治亚州",
            "Ghana"=> "加纳",
            "Greece"=> "希腊",
            "Greenland"=> "格陵兰",
            "Guatemala"=> "危地马拉",
            "Guinea"=> "几内亚",
            "Guinea-Bissau"=> "几内亚比绍",
            "Guyana"=> "圭亚那",
            "Haiti"=> "海地",
            "Heard I. and McDonald Is."=> "赫德岛和麦克唐纳群岛",
            "Honduras"=> "洪都拉斯",
            "Hungary"=> "匈牙利",
            "Iceland"=> "冰岛",
            "India"=> "印度",
            "Indonesia"=> "印度尼西亚",
            "Iran"=> "伊朗",
            "Iraq"=> "伊拉克",
            "Ireland"=> "爱尔兰",
            "Israel"=> "以色列",
            "Italy"=> "意大利",
            "Ivory Coast"=> "象牙海岸",
            "Jamaica"=> "牙买加",
            "Japan"=> "日本",
            "Jordan"=> "乔丹",
            "Kashmir"=> "克什米尔",
            "Kazakhstan"=> "哈萨克斯坦",
            "Kenya"=> "肯尼亚",
            "Kosovo"=> "科索沃",
            "Kuwait"=> "科威特",
            "Kyrgyzstan"=> "吉尔吉斯斯坦",
            "Laos"=> "老挝",
            "Lao PDR"=> "老挝人民民主共和国",
            "Latvia"=> "拉脱维亚",
            "Lebanon"=> "黎巴嫩",
            "Lesotho"=> "莱索托",
            "Liberia"=> "利比里亚",
            "Libya"=> "利比亚",
            "Lithuania"=> "立陶宛",
            "Luxembourg"=> "卢森堡",
            "Madagascar"=> "马达加斯加",
            "Macedonia"=> "马其顿",
            "Malawi"=> "马拉维",
            "Malaysia"=> "马来西亚",
            "Mali"=> "马里",
            "Mauritania"=> "毛里塔尼亚",
            "Mexico"=> "墨西哥",
            "Moldova"=> "摩尔多瓦",
            "Mongolia"=> "蒙古",
            "Montenegro"=> "黑山",
            "Morocco"=> "摩洛哥",
            "Mozambique"=> "莫桑比克",
            "Myanmar"=> "缅甸",
            "Namibia"=> "纳米比亚",
            "Netherlands"=> "荷兰",
            "New Caledonia"=> "新喀里多尼亚",
            "New Zealand"=> "新西兰",
            "Nepal"=> "尼泊尔",
            "Nicaragua"=> "尼加拉瓜",
            "Niger"=> "尼日尔",
            "Nigeria"=> "尼日利亚",
            "Korea"=> "朝鲜",
            "Northern Cyprus"=> "北塞浦路斯",
            "Norway"=> "挪威",
            "Oman"=> "阿曼",
            "Pakistan"=> "巴基斯坦",
            "Panama"=> "巴拿马",
            "Papua New Guinea"=> "巴布亚新几内亚",
            "Paraguay"=> "巴拉圭",
            "Peru"=> "秘鲁",
            "Republic of the Congo"=> "刚果共和国",
            "Philippines"=> "菲律宾",
            "Poland"=> "波兰",
            "Portugal"=> "葡萄牙",
            "Puerto Rico"=> "波多黎各",
            "Qatar"=> "卡塔尔",
            "Republic of Seychelles"=> "塞舌尔共和国",
            "Romania"=> "罗马尼亚",
            "Russia"=> "俄罗斯",
            "Rwanda"=> "卢旺达",
            "Samoa"=> "萨摩亚",
            "Saudi Arabia"=> "沙特阿拉伯",
            "Senegal"=> "塞内加尔",
            "Serbia"=> "塞尔维亚",
            "Sierra Leone"=> "塞拉利昂",
            "Slovakia"=> "斯洛伐克",
            "Slovenia"=> "斯洛文尼亚",
            "Solomon Is."=> "所罗门群岛",
            "Somaliland"=> "索马里兰",
            "Somalia"=> "索马里",
            "South Africa"=> "南非",
            "S. Geo. and S. Sandw. Is."=> "南乔治亚和南桑德威奇群岛",
            "S. Sudan"=> "南苏丹",
            "Spain"=> "西班牙",
            "Sri Lanka"=> "斯里兰卡",
            "Sudan"=> "苏丹",
            "Suriname"=> "苏里南",
            "Swaziland"=> "斯威士兰",
            "Sweden"=> "瑞典",
            "Switzerland"=> "瑞士",
            "Syria"=> "叙利亚",
            "Tajikistan"=> "塔吉克斯坦",
            "Tanzania"=> "坦桑尼亚",
            "Thailand"=> "泰国",
            "The Kingdom of Tonga"=> "汤加王国",
            "Timor-Leste"=> "东帝汶",
            "Togo"=> "多哥",
            "Trinidad and Tobago"=> "特立尼达和多巴哥",
            "Tunisia"=> "突尼斯",
            "Turkey"=> "土耳其",
            "Turkmenistan"=> "土库曼斯坦",
            "Uganda"=> "乌干达",
            "Ukraine"=> "乌克兰",
            "United Arab Emirates"=> "阿拉伯联合酋长国",
            "United Kingdom"=> "大不列颠联合王国",
            "United Republic of Tanzania"=> "坦桑尼亚联合共和国",
            "United States"=> "美国",
            "United States of America"=> "美利坚合众国",
            "Uruguay"=> "乌拉圭",
            "Uzbekistan"=> "乌兹别克斯坦",
            "Vanuatu"=> "瓦努阿图",
            "Venezuela"=> "委内瑞拉",
            "Vietnam"=> "越南",
            "West Bank"=> "西岸",
            "W. Sahara"=> "西撒哈拉",
            "Yemen"=> "也门",
            "Zambia"=> "赞比亚",
            "Zimbabwe"=> "津巴布韦"
        ];
    }

}