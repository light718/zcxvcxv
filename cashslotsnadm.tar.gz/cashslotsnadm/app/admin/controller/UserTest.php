<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/3/19
 * Time: 16:54
 */
namespace app\admin\controller;
use app\admin\model\TestAccount;
use think\App;
use think\Request;

class UserTest extends Base
{
    protected $notNeedRight = ['edit','delete'];

    /***
     * 测试用户管理
     * @param Request $request
     * @return string
     */
    public function index(Request $request){

        $condition = [];
        $limit = $request->get('limit/d');
        if($uids = $request->get('uid', false)){
            $condition[] = ['uid', 'in', $uids];
        }

        $list = TestAccount::where($condition)->paginate($limit);

        return $this->fetch(__FUNCTION__,compact('list'));
    }

    /***
     * 新增测试用户
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function edit(Request $request){
        $id = $request->get('id');
        if ($request->isPost()){
            $post_param = $request->post();
            $data = [];
            $data['uid'] = $post_param['uid'];
            $data['user_name'] = $post_param['user_name'];
            $data['worker_name'] = $post_param['worker_name'];
            if ($id){

            }else{

            }
            $account_model = new TestAccount();
            $res = $account_model->save($data);
            if ($res){
                $this->record('新增', "测试用户（%s）", [session('user_info.username')], false);
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_fail'));
            }
        }
        $result = TestAccount::where(compact('id'))->find();

        return $this->fetch(__FUNCTION__,compact('id','result'));
    }

    /***
     * 删除测试用户
     * @param Request $request
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function delete(Request $request){
        $id = $request->get('id');
        $account_re = TestAccount::where(compact('id'))->find();
        if (!$account_re){
            $this->error(lang('not_exists'));
        }
        $res = $account_re->delete();
        if ($res){
            $this->record('删除', "测试用户（%s）", [session('user_info.username')], false);
            $this->success(lang('return_success'));
        }else{
            $this->error(lang('return_fail'));
        }
    }
}