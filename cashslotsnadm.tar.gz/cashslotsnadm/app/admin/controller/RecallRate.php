<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

class RecallRate extends Base
{
    protected $notNeedRight = [];

    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * @param Request $request
     */
    public function index(Request $request){
        if ($request->isAjax()){
            $dayRange = $this->request->get('day_range', false);
            if(!$dayRange) $this->error('错误请求');
            list($start, $end) = explode(' - ', $dayRange);
            $dayList = $this->getRangeDay($start, $end);

            Db::query('SET SESSION group_concat_max_len=102400');  //修改group_concat限制长度
            $data = Db::name('app_push_log')
                ->whereTime('createtime', 'between', [$start, $end])
                ->group("left(createtime, 10)")
                ->field("left(createtime, 10) day, count(distinct uid) uid_total, group_concat(distinct uid) uid_list")
                ->select()->toArray();

            foreach($data as &$value){
                $loginTotal = Db::connect('game')
                    ->name('d_user_login_log')
                    ->where("FROM_UNIXTIME(create_time, '%Y-%m-%d') = '{$value['day']}'")
                    ->whereIn('uid', $value['uid_list'])
                    ->count('distinct uid');
                $value['login_total'] = $loginTotal;
            }
            $data = array_column($data, NULL, 'day');
            $result = [];
            foreach($dayList as $value){
                $result[] = [
                    "day" => $value,
                    "user_total" => $data[$value]['uid_total'] ?? 0,
                    "login_total" => $data[$value]['login_total'] ?? 0
                ];
            }
 
            $this->success('', '', $result);
        }
        return $this->fetch();
    }

    //获取两日期之间所有天数列表
    private function getRangeDay($start, $end){
        $dayList = [];
        $dt_start = strtotime($start);
        $dt_end = strtotime($end);
        while ($dt_start <= $dt_end){
            $dayList[] = date("Y-m-d", $dt_start);
            $dt_start = strtotime('+1 day', $dt_start);
        }
        return $dayList;
    }

}