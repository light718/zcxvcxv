<?php
namespace app\admin\controller;

use think\App;
use think\facade\View;

class Map extends Base
{


    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * 首页
     * @return string
     */
    public function index()
    {
        return View::fetch();
    }

    public function hello($name = 'ThinkPHP6')
    {
        return 'hello,' . $name;
    }

    /***
     * 框架首页
     * @return string
     */
    public function map(){
        return View::fetch();
    }

}
