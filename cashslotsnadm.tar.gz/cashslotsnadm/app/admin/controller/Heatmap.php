<?php
namespace app\admin\controller;

use think\App;
use think\Request;
use think\facade\Db;

class Heatmap extends Base
{
    protected $notNeedRight = [];

    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    /***
     * @param Request $request
     */
    public function index(Request $request){
        if ($request->isPost()){
            $act = $request->post('act', []);
            $timeRanger = [];
            $day = $this->request->get('day', 30);
            if(strpos($day, '-')){
                //时间范围
                $timeRanger = [strtotime(explode(' - ', $day)[0]), strtotime(explode(' - ', $day)[1])];
            }else{
                //往前推几天
                $timeRanger = [strtotime("-{$day} day"), time()];
            }
            $data = Db::connect('game')
                    ->name('d_statistics')
                    ->where('uid', 'not in', Db::name('test_account')->where('uid is not null')->column('uid'))
                    ->whereTime('ts', 'between', $timeRanger)
                    ->whereIn('act', $act)
                    ->group('act')
                    ->field('act, count(1) total')
                    ->select();
            return $this->success('', '', $data);
        }
        return $this->fetch();
    }

}