<?php

namespace app\admin\controller;

use think\App;
use think\facade\Db;

/***
 * 用户卡牌统计
 * Class Usercard
 * @package app\admin\controller
 */
class Usercard extends Base
{
    public function index(){
        if($this->request->isajax()){
            $limit = $this->request->get('limit');
            $uid = $this->request->get('uid', false);
            $where = "";
            if($uid) $where = "uid in ({$uid})";

            $list = Db::name('stat_card')
                    ->where($where)
                    ->paginate($limit);
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total()]);
        }

        return $this->fetch();
    }
}