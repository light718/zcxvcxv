<?php
namespace app\admin\controller;

use app\admin\model\CoinsPlayer;
use app\admin\model\DUser;
use app\admin\model\DUserLoginLog;
use app\admin\model\LogApiBackoffice;
use app\admin\model\LogLoginPlayer;
use app\admin\model\PoolTaxReset;
use app\admin\model\SConfig;
use app\admin\model\ScoreLog;
use app\admin\model\SGameType;
use app\admin\model\SShopOrder;
use app\admin\model\StatAlarm;
use app\admin\model\StatGameDetail;
use app\admin\model\StatGameDetailToday;
use app\admin\model\StatMarketDay;
use app\admin\model\StatReward;
use app\admin\model\StatShopRenew;
use app\admin\model\StatSyswin;
use app\admin\model\StatUserOnline;
use org\Curl;
use think\App;
use think\facade\Db;
use think\db\Query;
use think\Request;
use think\facade\Cache;

class SystemQuery extends Base
{
    protected $notNeedRight =['out_line', 'login_log', 'player_detail_list', 'add_hide_rank', 'config_edit', 'next_activity'];
    /***
     * 玩家列表
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function playerList(Request $request){
        if ($request->isAjax()){
            $limit = $request->get('limit');
            $condition = [];
            if ($uid = $request->get('uid')){
                $condition[] = ['uid','=',$uid];
            }
            $list = DUser::field('uid,create_time,login_time, playername,coin,onlinestate,playername,status')->where($condition)->order('create_time desc')->paginate($limit);
            foreach ($list as &$value){
                $value['status_text'] = $value->status_text;
                $value['onlinestate_text'] = $value->onlinestate_text;
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 用户登录日志
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function login_log(Request $request){
        if ($request->isAjax()){
            $post_param = $request->param();
            if (isset($post_param['start_time'])){
                $start_times = explode('~',$post_param['start_time']);
                $start_time = strtotime($start_times[0]);
                $end_time  = strtotime($start_times[1]);
            }else{
                $start_time = 0;
                $end_time = time();
            }
            $time_arr =  [$start_time,$end_time];
            $uid = $request->get('uid');
            $limit = $post_param['limit'];
            $lists = LogLoginPlayer::whereBetween('create_time',$time_arr)->where(['account_id'=>$uid])->order('create_time desc')->paginate($limit);

            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }

        $uid = $request->get('uid');
        return $this->fetch(__FUNCTION__,compact('uid'));
    }

    /***
     * 玩家明细列表
     * @param Request $request
     * @return string
     */
    public function player_detail_list(Request $request ){
        if($request->isAjax()){
            $post_param =  $request->param();
            if (isset($post_param['start_time'])){
                $start_times = explode('~',$post_param['start_time']);
                $start_time = strtotime($start_times[0]);

                $end_time  = strtotime($start_times[1]);
            }else{
                $start_time = 0;
                $end_time = time();
            }
            $time_arr =  [$start_time,$end_time];
            $uid = $post_param['uid'];
            $limit = $request->get('limit',15);
            $lists = CoinsPlayer::alias('a')->field("ac.id,ac.pid,a.coin,a.before,a.after,a.type,a.game_id,a.create_time")->join('account ac','a.account_id = ac.id')->where(['a.account_id'=>$uid])->whereBetween('a.create_time',$time_arr)->order('a.create_time desc')->paginate($limit);
            foreach ($lists as &$val){
                $val['game_title'] = SGameType::where(['gameid'=>$val['game_id']])->value('title');
            }
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }
        $uid = $request->get('uid');
        return $this->fetch(__FUNCTION__,compact('uid'));
    }

    /***
     * 代理列表
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function agentList(Request $request){
        if ($request->isAjax()){
            $condition = [];
            $keyword = $request->get('keyword');
            $times = $request->get('start_time');

            if($keyword){
                $condition[] = ['username|nickname','like','%'.$keyword."%"];
            }
            if ($times){
                $condition[] = ['create_time','between',$times];
            }
            $limit = $request->get('limit',15);
            $condition[] = ['agent','in',[1,2]];
            $fields = 'id,parent_id,parent_agent_first_id,username,nickname,coin,create_time,login_time';
            $list = \app\admin\model\Account::with(['getParents'=>function(Query $query){
                $query->field('id,username,nickname');
            },'getLastParent'=>function(Query $query){
                $query->field('id,username,nickname');
            }])->field($fields)->where($condition)->order('create_time desc')->paginate($limit);
            foreach ($list as &$value){
                $value['parent_id_name'] = $value['getParents']['username'];
                $value['parent_agent_first_id_name'] = $value['getParents']['username'];
            }
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 代理进分记录
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function agent_score_log(Request $request){
        $uid = $request->get('id');

        if ($request->isAjax()){
            $condition = [];
            $condition[] = ['account_id','=',$uid];
            $fields = 'account_id, `before`, `after`, coin, create_time';
            $limit = $request->get('limit',15);

            $lists = ScoreLog::field($fields)->where($condition)->order('create_time desc')->paginate($limit);

            $uid_arr = array_unique(array_column($lists->items(),'account_id'));

            $account_list = \app\admin\model\Account::field('id, username, nickname')->whereIn('id',$uid_arr)->select();

            foreach ($lists as &$value){
                foreach ($account_list as $v){
                    if ($value['account_id'] == $v['id']){
                        $one['username'] = $v['username'];
                        $one['nickname'] = $v['nickname'];
                        $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                    }
                }
            }

            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }

        return $this->fetch(__FUNCTION__,compact('uid'));
    }

    /***
     * 系统输赢
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function system_win(Request $request ){
        if ($request->isAjax()){
            $start_times = $request->get('start_time');
            $time_arr = [];
            $limit = $request->get('limit/d',15);
            if ($start_times){
                $start_time = explode('~',$start_times);
                $time_arr= [$start_time[0],$start_time[1]];
            }else{
                $time_arr= [date('Y-m-d',0),date('Y-m-d')];
            }
            $lists = StatSyswin::whereBetween('date',$time_arr)->order('id desc')->paginate($limit);
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 税收统计
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function tax_empty_log(Request $request){
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $lists = PoolTaxReset::order('create_time desc')->paginate($limit);
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 查账
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function check_accounts(Request $request){
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $start_times = $request->get('start_time');
            $start_time = explode('~',$start_times);
            $time_arr = [];
            if ($start_times){
                $time_arr = [$start_time[0],$start_time[1]];
            }else{
                $time_arr = [0,time()];
            }
            $lists = StatAlarm::where([])->order('datetime desc')->paginate($limit);
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     *
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function state_player_count(Request $request){

        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);

        if ($start_times){
            $time_arr = [date('Ymd',strtotime($start_time[0])),date('Ymd',strtotime($start_time[1]))];
        }else{
            $time_arr = [0,date('Ymd')];
        }
        $query = StatMarketDay::whereBetween('day',$time_arr)->order('create_time desc');
        if ($request->get('is_export')){
            $list = $query->select();
            $list_key = [
                'day',
                'dau',
                'arpu',
                'arrpu',
                'ordernum',
                'payrate',
                'paynum',
                'payamount',
                'pay2amount',
                'payfirstamount',
                'payfirstnum                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ',
                'stay1',
                'stay3',
                'stay7',
                'stay14',
                'stay30',
                'ltv1',
                'ltv3',
                'ltv7',
                'ltv14',
                'ltv30',
            ];
            $this->exportExcel($list_key,$list,'人数统计');
            return false;
        }

        if ($request->isAjax()){
            $lists = $query->paginate($limit);
            $list = $lists->items();

            return json(['code'=>200,'data'=>$list,'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * @param Request $request
     * @return string
     */
    public function state_game_today(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);

        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $query = StatGameDetailToday::whereBetween('create_time',$time_arr)->order('create_time desc');
        if ($request->get('is_export')){
            $lists = $query->select();
            foreach ($lists as &$v){
                if ($v['allbet'] > 0 ) {
                    $v['rate'] = round( ($v['allwin'] / $v['allbet']) * 100,2) . '%';
                } else {
                    $v['rate'] = '0%';
                }
            }
            $fields = [
                'create_time',
                'game_id',
                'alltimes',
                'allusers',
                'allbet',
                'allwin',
                'game_title',
                'rate'
            ];

            $this->exportExcel($fields,$lists,'新用户游戏数据统计');
            return false;
        }

        if ($request->isAjax()){
            $lists = $query->paginate($limit);

            foreach ($lists as &$v){
                if ($v['allbet'] > 0 ) {
                    $v['rate'] = round( ($v['allwin'] / $v['allbet']) * 100,2) . '%';
                } else {
                    $v['rate'] = '0%';
                }
            }
            return json(['code'=>200,'data'=>$lists->items(),'count'=>$lists->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 活跃用户游戏数据统计
     * @param Request $request
     * @return string
     */
    public function state_game_active(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);

        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $query = StatGameDetail::whereBetween('create_time',$time_arr)->order('create_time desc');
        if ($request->get('is_export')){
            $list = $query->select();
        }else{
            $list = $query->paginate($limit);
        }
        foreach ($list as &$v){
            if ($v['allbet'] > 0 ) {
                $v['rate'] = round( ($v['allwin'] / $v['allbet']) * 100,2) . '%';
            } else {
                $v['rate'] = '0%';
            }
        }
        if ($request->get('is_export')){
            $list_key = [
                'create_time',
                'game_id',
                'alltimes',
                'allusers',
                'allbet',
                'allwin',
                'rate',
            ];
            $this->exportExcel($list_key,$list,'活跃用户游戏数据统计');
            return false;
        }
        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 活跃用户领取奖励统计
     * @param Request $request
     * @return string
     */
    public function state_reward_active(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $query = StatReward::whereBetween('create_time',$time_arr)->order('create_time desc');

        if ($is_export){
            $list = $query->select();
        }else{
            $list = $query->paginate($limit);
        }
        foreach ($list as &$value){
            $value['allcoin'] = number_format($value['allcoin'],0);
            $value['allcost'] = number_format($value['allcost'],0);
        }
        if ($is_export){
            $list_key = [
                'create_time',
                'act',
                'allusers',
                'allcoin',
                'allcost',
            ];
            $this->exportExcel($list_key,$list,'活跃用户领取奖励统计');
            return false;
        }
        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 新用户在线时长
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function state_newuser_online(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        if ($start_times){
            $startTime = strtotime($start_time[0]);
            $endTime = strtotime($start_time[1]);
        }else{
            $startTime = 0;
            $endTime = time();
        }
        $sql = "select count(uid) as allusers, onlinetype from (
select a.uid, (CASE WHEN onlinetime<=30 THEN  '1' WHEN onlinetime>=31 AND onlinetime<60 THEN '2' WHEN onlinetime>=60 AND onlinetime<180 THEN '3' WHEN onlinetime>=180 AND onlinetime<600 THEN '4'
 WHEN onlinetime>=600 AND onlinetime<1800 THEN '5' WHEN onlinetime>=1800 AND onlinetime<3600 THEN '6' WHEN onlinetime>=3600 AND onlinetime<7200 THEN '7'  ELSE '8' END) as onlinetype 
 from d_user_login_log a join (select uid, max(create_time) create_time from d_user_login_log where create_time>={$startTime} and create_time<{$endTime} group by uid) b on a.uid = b.uid and a.create_time = b.create_time and  a.create_time>={$startTime} and a.create_time<{$endTime}) c group by onlinetype";

        $list = Db::connect('game')->query($sql);
        $dict=[];
        $dict[1] = '30s';
        $dict[2] = '31~60s';
        $dict[3] = '1~3min';
        $dict[4] = '3~10min';
        $dict[5] = '10~30min';
        $dict[6] = '30min~1h';
        $dict[7] = '1h~2h';
        $dict[8] = '2h+';
        foreach ($list as &$v){
            $v['stype'] = isset($dict[$v['onlinetype']]) ? $dict[$v['onlinetype']] : '未知';
        }
        if ($is_export){
            $list_key = [
                'stype',
                'allusers',
            ];
            $this->exportExcel($list_key,$list,'新用户在线时长');
            return false;
        }
        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
        }

        return $this->fetch();
    }

    /***
     * 用户在线时长统计
     * @param Request $request
     * @return string
     */
    public function state_user_online(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $query = StatUserOnline::whereBetween('create_time',$time_arr)->order('create_time desc');

        if ($is_export){
            $list = $query->select();
        }else{
            $list = $query->paginate($limit);
        }
        $dict = [];
        $dict[1] = '30s';
        $dict[2] = '31~60s';
        $dict[3] = '1~3min';
        $dict[4] = '3~10min';
        $dict[5] = '10~30min';
        $dict[6] = '30min~1h';
        $dict[7] = '1h~2h';
        $dict[8] = '2h+';
        foreach ($list as &$v) {
            $v['day'] = date('Y-m-d',strtotime($v['create_time']));
            $v['stype'] = isset($dict[$v['stype']]) ? $dict[$v['stype']] : '未知';
        }
        if ($is_export){
            $list_key = [
                'id',
                'allusers',
                'stype',
                'avgcoin',
                'day',
            ];
            $this->exportExcel($list_key,$list,'用户在线时长统计');
            return false;
        }
        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 用户等级统计
     * @param Request $request
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function state_user_level(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }

        $list = DUser::getLevelList($time_arr[0],$time_arr[1]);
        $dict = [];
        $dict[1] = '1级';
        $dict[2] = '2级';
        $dict[3] = '3级';
        $dict[4] = '4级';
        $dict[5] = '5级';
        $dict[6] = '6级';
        $dict[7] = '7级';
        $dict[8] = '8级';
        $dict[9] = '9级';
        $dict[10] = '10级';
        $dict[11] = '11~20级';
        $dict[12] = '20~30级';
        $dict[13] = '30~50级';
        $dict[14] = '50级+';
        foreach ($list as &$v) {
            $v['level_type'] = isset($dict[$v['level_type']]) ? $dict[$v['level_type']] : '未知';
            $v['avgcoinval'] = round($v['avgcoinval'],2);
        }
        if($is_export){
            $list_key = [
                'level_type',
                'allusers',
                'avgcoinval',
                'allrupt',
                'chargeamount',
            ];
            $this->exportExcel($list_key,$list,'用户等级统计');
            return false;
        }
        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 注册当天首充订单统计
     * @param Request $request
     * @return string
     */
    public function state_user_order(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $condition = [];
        $condition[] = ['status','=',2];
        $condition[] = ['isfirst','=',1];
        $list = SShopOrder::getRegStateData($time_arr[0],$time_arr[1]);

        if ($is_export){
            $list_key = [
                'createdate',
                'num',
                'price',
            ];
            $this->exportExcel($list_key,$list,'注册当天首充订单统计');
            return false;
        }
        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list,'count'=>count($list),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /**
     * 注册当天首充订单
     * @param Request $request
     * @return string
     */
    public function state_user_orderlist(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $condition = [];
        $condition[] = ['status','=',2];
        $condition[] = ['isfirst','=',1];
        $condition[] = ['uid','not in',$testAccount];

        $query = SShopOrder::whereBetween('create_time',$time_arr)->where($condition)->order('id desc');
        if ($is_export){
            $list = $query->select();
        }else{
            $list = $query->paginate($limit);
        }
        if ($is_export){
            $list_key = [
                'uid',
                'level',
                'user_coin',
                'shopid',
                'title',
                'amount',
                'create_time',
            ];
            $this->exportExcel($list_key,$list,'注册当天首充订单');
            return false;
        }
        if ($request->isAjax()){
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 充值物品排名
     * @param Request $request
     * @return string
     */
    public function state_shopitem_sort(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        $field = 'count(*) as total, sum(amount) as price, shopid';
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $testAccount = Db::name('test_account')->where('uid is not null')->column('uid');
        $query = SShopOrder::with(['shop'=>function(Query $query){
            $query->field('id,title');
        }])->field($field)->whereBetween('create_time',$time_arr)->where('uid', 'not in', $testAccount)->group('shopid')->order('total desc');

        if ($is_export){
            $list = $query->select();
        }else{
            $list = $query->paginate($limit);
        }
        foreach ($list as &$value){
            $value['title'] = $value['shop']['title'];
        }
        if ($is_export){
            $list_key = [
                'shopid',
                'title' ,
                'total',
                'price',
            ];
            $this->exportExcel($list_key,$list,'充值物品牌名');
            return false;
        }
        if($request->isAjax()){
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 首充后续充
     * @param Request $request
     * @return bool|string|\think\response\Json
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * @throws \PHPExcel_Writer_Exception
     */
    public function state_shoporder_renew(Request $request){
        $limit = $request->get('limit/d',15);
        $start_times = $request->get('start_time');
        $start_time = explode('~',$start_times);
        $is_export = $request->get('is_export');
        $field = 'count(*) as total, sum(amount) as price,shopid';
        if ($start_times){
            $time_arr = [strtotime($start_time[0]),strtotime($start_time[1])];
        }else{
            $time_arr = [0,time()];
        }
        $query = StatShopRenew::whereBetween('create_time',$time_arr)->order('id desc');
        if ($is_export){
            $list = $query->select();
        }else{
            $list = $query->paginate($limit);
        }

        if ($is_export){
            $list_key = [
                'id',
                'create_time',

                'amount1',
                'users1',

                'amount2',
                'users2',

                'amount3',
                'users3',

                'amount4',
                'users4',

                'amount5',
                'users5',

                'amount6',
                'users6',

                'amount7',
                'users7',

                'amount8',
                'users8',

                'amount9',
                'users9',

                'amount10',
                'users10',

            ];
            $this->exportExcel($list_key,$list,'首充后续');
            return false;
        }
        if($request->isAjax()){
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 下线
     * @param Request $request
     */
    public function out_line(Request $request){
        $uid = $request->param('uid/d');
        if (!$uid){
            $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
        }
        $curl = new Curl();
        $res = $curl->player_offline($uid);
        if ($res) {
            $this->jsonReturn(EXIT_SUCCESS, lang('return_success'));
            $this->record('玩家管理', "玩家（%s）踢下线成功", [session('user_info.username')]);
        } else {
            $this->jsonReturn(EXIT_ERROR, lang('return_fail'));
            $this->record('玩家管理', "玩家（%s）踢下线失败", [session('user_info.username')]);
        }
    }

    /***
     * 配置列表
     * @param Request $request
     * @return string|\think\response\Json
     * @throws \think\db\exception\DbException
     */
    public function configList(Request $request){
        if ($request->isAjax()){
            $limit = $request->get('limit/d',15);
            $list = SConfig::where([])->paginate($limit);
            return json(['code'=>200,'data'=>$list->items(),'count'=>$list->total(),'msg'=>lang('return_success')]);
        }
        return $this->fetch();
    }

    /***
     * 编辑配置
     * @param Request $request
     * @return string
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function config_edit(Request $request){
        $id = $request->get('id');
        if ($request->isPost()){
            $post_param = $request->post();

            $update_data = [
                'k' =>$post_param['k'],
                'v' =>$post_param['v'],
                'memo' =>$post_param['memo'],
//                'mlrobot' =>$post_param['mlrobot'],
            ];
            Db::startTrans();
            $res = SConfig::where(['id' =>$id])->update($update_data);
            $curl  = new Curl();
            $res1 = $curl->reloadCondfig();
            if($res1 && $res){
                Db::commit();
            }else{
                Db::rollback();
            }
            $this->record('配置管理', "管理（%s）编辑 %s 配置", [session('user_info.username'), $post_param['k']]);
            return $this->jsonReturn(EXIT_SUCCESS, lang('return_success'));
        }
        $res = SConfig::where(compact('id'))->find();

        return $this->fetch(__FUNCTION__,compact('res','id'));
    }

    public  function reload_config(){
        $curl = new  Curl();
        $res = $curl->reloadCondfig();
        if ($res){
            return $this->jsonReturn(EXIT_SUCCESS, lang('return_success'));
        }
        return $this->jsonReturn(EXIT_ERROR , lang('return_fail'));
    }

    public  function add_hide_rank(Request $request){
        if($request->isPost()){
            $post_param = $request->post();

            $uid = $post_param['uid'];
            $curl = new Curl();
            $res = $curl->addHideRank(compact('uid'));
            if ($res){
                return $this->jsonReturn(EXIT_SUCCESS,lang('return_success'));
            }else{
                return $this->jsonReturn(EXIT_ERROR,lang('return_fail'));
            }
        }

        return $this->fetch();

    }


    //下周活动控制
    public function next_activity(Request $request){
        if($request->isPost()){
            $result = Cache::store('redis')->hset('subgame:info', 'nextGame', $request->post('nextGame'));
            if($result){
                $this->success('操作成功');
            }else{
                $this->success('操作失败');
            }

        }
        $nextGame = Cache::store('redis')->hget('subgame:info','nextGame');
        $this->jsonReturn('success', '', ['nextGame' => $nextGame]);
    }
}