<?php

namespace app\admin\controller;

use app\admin\model\Account;
use think\App;
use think\facade\Db;
use think\facade\Cookie;
use think\facade\Env;
use think\facade\Session;
use think\facade\Lang;
use think\facade\View;
use think\Request;

class Login extends Base
{

    protected $notNeedLogin = ['*'];
    protected $notNeedRight = ['*'];

    /***
     * 首页
     * @return string
     */

    public function index(Request $request)
    {
        if ($request->isPost()) {
            $param = $request->param();
            if (Env::get('CSS_VERSION')) {
                $lang = $this->request->get('lang', Lang::defaultLangSet());
                Cookie::set('think_lang', $lang . '_' . CSS_VERSION);
            }

            $username = $this->request->post('username');
            $username = strtolower($username); //一律小写
            $password = $this->request->post('password');
            if (empty($username)) {
                return $this->jsonReturn(EXIT_ERROR, lang('username_empty'));
            }
            if (empty($password)) {
                return $this->jsonReturn(EXIT_ERROR, lang('password_empty'));
            }

            $params = array(
                'username' => $username,
                'pwdmd5' => md5($password),
                'ip' => $this->request->ip(),
            );
            if (false) {
                $result = $this->requestApi(API_URL_BASE . '/account/login', 'GET', $params);
                    if ($result['errcode'] === 0) { //登录成功
                    // 判断域名是否对应
                    $auth_re = Db::name('auth')->where(['id' => $result['data']['account']['agent']])->find();
                    $admin_domains = explode(',', $auth_re['url_domain']);
                    if (!in_array(DOMAIN, $admin_domains) && $auth_re['url_domain'] != '') {
                        return $this->jsonReturn(EXIT_ERROR, lang('username_password_error'));
                    }
                    session('user_info', $result['data']);
                    $account_info = Account::getAccountById($result['data']['account']['id']);
                    Session::set('user_info_db', $account_info);
                    // 用户账号密码保存到session，用户地区
                    Session::set('user_account_pwd', $params);
                    $token = $result['data']['token'];
                    $account = $result['data']['account'];
                    // 清除登录地区
                    Session::set('select_region', null);
                    Session::save();
                    $this->record('登录', "代理（%s）登录成功", [$username], false);
                    return $this->jsonReturn(EXIT_SUCCESS, lang('login_success'));
                } else {
                    if ($result['errcode'] == EXIT_LOGIN_FORBIDDEN) {
                        $this->jsonReturn(EXIT_ERROR, lang('login_forbidden'));
                    } elseif (in_array($result['errcode'], array('30050001', '30050021', '30050051', '30050101', '30050201', '30056001', '30050021')) && isset($result['data']['locksec'])) {
                        $locksec = $result['data']['locksec'];
                        if (floor($locksec / 60) > 1) {
                            $seconds = ceil($locksec / 60) . lang('minute');
                        } else {
                            $seconds = $locksec . lang('second');
                        }
                        $this->jsonReturn(EXIT_ERROR, str_replace("{%seconds%}", $seconds, lang('account_lock')));
                    } elseif ($result['errcode'] == EXIT_ACCOUNT_IP) {
                        return $this->jsonReturn(EXIT_SUCCESS, lang('login_ip_error'));
                    } else {
                        return $this->jsonReturn(EXIT_ERROR, lang('username_password_error'));
                    }
                }
            }else{
                $account_re = Account::where(compact('username'))->find();
                if (!$account_re){
                    return $this->jsonReturn(EXIT_ERROR, lang('user_not_exists'));
                }

                if ($account_re['status'] != Account::STATUS_NORMAL){
                    return $this->jsonReturn(EXIT_ERROR, lang('account can login'));
                }
                $password = md5(strtolower($username).md5($password). $account_re['salt']);
                if ($password != $account_re['password']){
                    return $this->jsonReturn(EXIT_ERROR, lang('username_password_error'));
                }
                $auth_re = Db::name('auth')->where(['id' => $account_re['agent']])->find();
                if($auth_re){
                    $admin_domains = explode(',', $auth_re['url_domain']);
                    if (!in_array(DOMAIN, $admin_domains) && $auth_re['url_domain'] != '') {
                        return $this->jsonReturn(EXIT_ERROR, lang('username_password_error'));
                    }
                }

                $token = md5(time());
                $update_re = Account::where(['id'=>$account_re['id']])->update(compact('token'));
                $this->account = $account_re;
                $account_re['token'] = $token;
                session('user_info', $account_re);
                // 用户账号密码保存到session，用户地区
                Session::set('user_info_db', $account_re);

                Session::set('user_account_pwd', $params);
                // 清除登录地区
                Session::set('select_region', null);
                Session::save();

                $groupInfo = Db::name('auth_group_access')
                    ->leftJoin('account_group', 'auth_group_access.group_id = account_group.id' )
                    ->where('uid', $account_re['id'])->field('account_group.id,account_group.name')->find();
                Cookie::set('user_group_info', $groupInfo['name'] ?? '');
                Cookie::save();

                $this->record('登录', "代理（%s）登录成功", [$username], false);
                return $this->jsonReturn(EXIT_SUCCESS, lang('login_success'));
            }
        }
        $lang = $this->request->get('lang', Lang::defaultLangSet());
        $this->assign('lang', $lang);
        return $this->fetch();
    }

    /***
     * 登出
     */
    public function logout()
    {
        if (false){
            $this->requestApi('/account/logout', 'GET', array());
        }
        Session::set('user_info', null);
        Session::set('user_account_pwd', null);
        Session::save();
        $this->success(lang('logout_success'), 'login/index');
    }

    public function isPlayerUsername(string $str = '') : bool
    {
        return preg_match('/^[A-Za-z0-9\@]{6,12}$/i', $str) && ! is_numeric($str) ? true : false;
    }
}