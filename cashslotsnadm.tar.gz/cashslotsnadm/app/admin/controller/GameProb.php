<?php
/**
* Created by PhpStorm.
* User: 9you
* Date: 2021/3/2
* Time: 17:30
*/
namespace app\admin\controller;
use org\Curl;
use think\App;
use think\facade\Env;
use think\facade\Lang;
use think\Request;

class GameProb extends Base
{
    protected $notNeedRight = ['edit','getProb','prob'];
    protected $_game_server_host = '';
    protected $_game_server_port = '';

    public function __construct(App $app)
    {
        parent::__construct($app);
        $this->_game_server_host = Env::get('GAMESERVER_HOST');
        $this->_game_server_port = Env::get('GAMESERVER_PORT');
    }

    /***
     *
     * @param Request $request
     */
    public function index(Request $request){
        $result = [1 => lang('prob_1'),2 => lang('prob_2'), 3 => lang('prob_3'), 4 => lang('prob_4'), 5 => lang('prob_5')];
        $game_list = $this->getGameList() ?: [];
        return $this->fetch(__FUNCTION__, compact('result','game_list'));
    }

    /***
     * 保存编辑配置
     * @param Request $request
     */
    public function edit(Request $request){
        $param = $request->param();
    }

    /***
     * 获取游戏列表
     * @return string
     */
    public function gameLists()
    {
        $type = input('type');
        $uniq = input('uniq');
        $uniq != 1 && $uniq = 0;
        $gameLists = $this->getGameList($uniq);
        if ($type > 0) {
            $data['game_list'] = [];
            foreach ($gameLists as $row) {
                if ($type == $row['type']) {
                    $data['game_list'][] = $row;
                }
            }
        } else {
            $data['game_list'] = $gameLists;
        }
        return $this->jsonReturn(EXIT_SUCCESS, '', $data);
    }

    /***
     * 获取prob
     * @param Request $request
     * @return string
     */
    public function getProb(Request $request){
        $gameId =   $request->post('id');
        $type = $request->post('type');
        $type = 1;
        $curl = new Curl();
        $result = $curl->simple_get($this->_game_server_host.'?mod=getgamerateconf&gameid=' . $gameId . '&type=' . $type, [], ['PORT'=> $this->_game_server_port, 'TIMEOUT'=> 5]);
        $result = json_decode($result,true);
        $prob = isset($result['data']) ? $result['data'] : json_encode([]);
        return $this->jsonReturn(EXIT_SUCCESS,\lang('success'),compact('prob'));
    }
    /**
     * 从游戏服务器获取游戏列表
     * @param int $uniq 去掉重复的
     * @return array
     */
    public function getGameList($uniq = 1)
    {
        $lang = Lang::defaultLangSet();
        if ($lang == 'zh-cn'){
            $lang = 1;
        }else{
            $lang = 2;
        }
        $curl = new Curl();
        $gamelist_jsonstr = $curl->simple_get($this->_game_server_host.'?mod=getgamelist&uniq=' . $uniq . '&lang=' . $lang, [], ['PORT'=> $this->_game_server_port, 'TIMEOUT'=> 5]);
        $gameLists = json_decode($gamelist_jsonstr,true);
        if (!isset($gameLists['data'])) return [];
        $gameLists = $gameLists['data'];
        $ids_arr = array_column($gameLists, 'id');
        array_multisort($ids_arr,SORT_ASC,$gameLists);
        return $gameLists;
    }

    /***
     * 修改游戏配置
     * @param Request $request
     */
    public function prob(Request $request){
        if ($request->isPost()){
            $post_param = $request->post();
            $id = $request->post('id');
            $prob = $request->post('prob');
            $type = $request->post('type');
            if ($id == '' || $prob == '{}' || empty($prob) || $prob == '[]' || $type == '') {
                $this->jsonReturn(EXIT_ERROR, \lang('return_empty'));
                exit();
            }
            $params = array(
                'id' => $id,
                'type' => $type,
                'prob' => $prob
            );
            $curl = new Curl();
            $result = $curl->simple_post($this->_game_server_host.'?mod=setgamerateconf&gameid=' . $id . '&type=' . $type, $prob, ['PORT'=> $this->_game_server_port, 'TIMEOUT'=> 5]);
            if ($result == "succ") {
                $this->record('游戏概率', "设定（%s）概率成功", [$id]);
                return $this->jsonReturn(EXIT_SUCCESS, \lang('return_success'));
            } else {
                $this->record('游戏概率', "设定（%s）概率失败", [$id]);
                return $this->jsonReturn(EXIT_ERROR, lang('return_fail'));
            }
        }

    }

}