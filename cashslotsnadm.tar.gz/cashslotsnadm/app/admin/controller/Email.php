<?php
namespace app\admin\controller;

use app\admin\model\DSysMail;
use org\Curl;
use think\App;
use think\Request;

/***
 * 邮件管理
 * Class Email
 * @package app\admin\controller
 */
class Email extends Base
{

    protected $notNeedRight = ['edit','delete'];

    /***
     * @return string
     */
    public function index(Request $request){
        $condition = [];
        if ($keyword = $request->get('keyword','','trim')){
            $condition[] = ['title','like','%'.$keyword."%"];
        }
        $list = DSysMail::where($condition)->paginate( 15);
        return $this->fetch(__FUNCTION__,['list'=>$list]);
    }

    public function edit(Request $request){
        $id = $request->get('id');

        if ($request->isPost()){
            $uids = $request->post('uids');

            $mail_data = [
                'mod' => 'mail',
                'act' => 'sendMail',
                'uids' => $uids,
                'title' => $request->post('email_title'),
                'msg' => $request->post('content'),
                'type' =>  $request->post('mail_type'),
                'attach_id' => $request->post('bonus_type'),
                'attach_count' => $request->post('bonus_amount'),
            ];
            $curl = new Curl();
            $send_re = $curl->sendMail($mail_data);
            if ($send_re){
                $this->success(lang('return_success'));
            }else{
                $this->error(lang('return_error'));
            }
        }

        return $this->fetch(__FUNCTION__);
    }

    public function delete(Request $request){
        $id =$request->get('id');

        if (!$id){
            $this->error(lang( 'please_input_id'));
        }
        $delete_re = DSysMail::where(compact('id'))->delete();
        if ($delete_re){
            $this->record('删除','代理删除邮件编号（%s）',[$id],false);
            $this->success(lang('return_success'));
        }else{
            $this->error(lang('return_error'));
        }
    }
}