<?php
namespace app\common\model;

use think\Db;
use think\Model;

class AuthRule extends Model
{
    // 关闭自动写入时间戳
    protected $autoWriteTimestamp = false;
}