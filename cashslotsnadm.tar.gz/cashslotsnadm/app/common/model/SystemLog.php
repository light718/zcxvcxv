<?php
namespace app\common\model;

use think\Model;

class SystemLog extends Model
{
    // 关闭自动写入时间戳
    protected $autoWriteTimestamp = false;


    //默认时间格式
    protected $dateFormat = 'Y-m-d H:i:s';

    //设置时间戳类型（整型）
    protected $type       = [
        'log_time'     => 'timestamp',
    ];
}