<?php
// 应用公共文件
if (!function_exists('array2level')) {
    function array2level($array, $pid = 0, $level = 1)
    {
        static $list = [];
        foreach ($array as $v) {
            if ($v['pid'] == $pid) {
                $v['level'] = $level;
                $list[] = $v;

                array2level($array, $v['id'], $level + 1);
            }
        }
        return $list;
    }
}
function formatMoney($money = 0)
{
    if (!$money) {
        return number_format(0, 0);
    }
    return number_format($money, 0);
//    if (!$money) {
//        return number_format(0, 2);
//    }
//    return number_format($money, 2);
}
function generateIconName($id)
{
    return '0x' . str_pad(strtoupper(dechex($id)), 2, 0, STR_PAD_LEFT) . '.png';
}
function array2tree(&$array, $pid_name = 'pid', $child_key_name = 'children')
{

    $counter = array_children_count($array, $pid_name);
    if (!isset($counter[0]) || $counter[0] == 0) {
        return $array;
    }

    $tree = [];
//    while (isset($counter[0]) && $counter[0] > 0) {
    foreach ($array as $temp){
        if ($temp[$pid_name] == 0) {
            $list = array3level($array,$temp['id'],0);
            $temp[$child_key_name] = $list;
            $tree[] = $temp;
        }
    }
    return $tree;
}

function array3level($array, $pid = 0, $level = 1,$lists = [])
{
    foreach ($array as $v) {
        if ($v['pid'] == $pid) {
            $v['level'] = $level;
            $lists[]     = $v;
            array2level($array, $v['id'], $level + 1,$lists);
        }
    }
    return $lists;
}

/**
 * 子元素计数器
 * @param array $array
 * @param int   $pid
 * @return array
 */
function array_children_count($array, $pid)
{
    $counter = [];
    foreach ($array as $item) {
        $count = isset($counter[$item[$pid]]) ? $counter[$item[$pid]] : 0;
        $count++;
        $counter[$item[$pid]] = $count;
    }

    return $counter;
}

function format_money($money = 0, $format='%.5f') :string
{
    return substr(sprintf($format, $money), 0, -1);
}