<?php /*a:2:{s:65:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\email\index.html";i:1640308700;s:58:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\base.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlentities($config['site_title']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" >
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <!--<link rel="stylesheet" href="/static/js/layui/css/global.css" media="all">未知CSS-->
    
    <style>
        .layui-laypage {
            display: inline-block;
            vertical-align: middle;
            font-size: 0;
            margin: 10px auto;
            box-sizing: content-box;
        }
        .layui-laypage ul li{
            float:left
        }
        .layui-laypage a, .layui-laypage span {
            display: inline-block;
            vertical-align: middle;
            padding: 0 15px;
            height: 28px;
            line-height: 28px;
            margin: 0 -1px 5px 0;
            background-color: #fff;
            color: #333;
            font-size: 12px;
        }

        .layui-laypage .active span{
            background-color: #009688; color: #fff;;
        }
    </style>
    
    <script src="/static/js/html5shiv.min.js"></script>
    <script src="/static/js/respond.min.js"></script>
</head>

<script src="/static/layuiadmin/layui/layui.all.js"></script>

<script src="/static/js/function.js"></script>
<script src="/static/js/my.js" type="text/javascript"></script>
<script type="text/javascript">
    var lang_set = {};
    $(function () {
        $.get("<?php echo url('index/langs'); ?>?controllername=<?php echo htmlentities($controller_name); ?>",function (res) {
            lang_set = res;
        });

    });
    function __(name) {
        return lang_set[name];
    }
</script>

<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-card-header">
            <div class="layui-btn-group">
            </div>
        </div>
        <form class="layui-form" action="<?php echo url('email/index'); ?>" method="get" id="myform">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <label class="layui-form-label">邮件标题</label>
                    <div class="layui-input-block">
                        <input type="text" name="keyword" id="keyword" placeholder="邮件标题" value="<?php echo input('keyword','','trim'); ?>" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn "> <i class="layui-icon layui-icon-search"></i>搜索</button>
                    <button class="layui-btn layui-btn-primary" type="button" onclick="addEmail()"> <i class="layui-icon layui-icon-add-1"></i>新增</button>
                </div>
            </div>
        </form>
        <div class="layui-card-body">
            <table class="layui-table">
                <thead>
                <tr>
                    <th>#</th>
                    <th>ID</th>
                    <th>邮件标题	</th>
                    <th>邮件内容	</th>
                    <th>创建时间	</th>
                    <!--<th>邮件类别	</th>-->
                    <!--<th>奖励类别	</th>-->
                    <!--<th>封面图片	</th>-->
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $k=>$vo): ?>
                <tr>
                    <td><?php echo htmlentities($k+1); ?></td>
                    <td><?php echo htmlentities($vo['id']); ?></td>
                    <td><?php echo htmlentities($vo['title']); ?></td>
                    <td><?php echo htmlentities($vo['msg']); ?></td>
                    <td><?php echo htmlentities($vo['timestamp']); ?></td>
                    <!--<td><?php echo htmlentities($vo['stype_text']); ?></td>-->
                    <!--<td><?php echo htmlentities($vo['bonus_type_text']); ?></td>-->
                    <!--<td><?php echo htmlentities($vo['cover_img']); ?></td>-->
                    <td>
                        <button class="layui-btn layui-btn-primary " onclick="delMail('<?php echo htmlentities($vo['id']); ?>')" type="button">删除</button>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                </tbody>
            </table>
            <div class="layui-laypage" id="demo0">
                <?php echo $list; ?>
            </div>
        </div>
    </div>
    

    <script>
        // 定义全局JS变量
        var GV = {
            current_controller: "admin/<?php echo htmlentities((isset($controller) && ($controller !== '')?$controller:'')); ?>/",
            base_url: "/static"
        };
        layui.use(['upload','layer','form'],function () {
            var layer = layui.layer,
                element = layui.element,
                form = layui.form;
        })
        $("#type").val("<?php echo input('type'); ?>");
        var form = layui.form;
        form.render();
        function showForm(id,type) {
            if (type == 1) {
                layer.open({
                    type: 2 //此处以iframe举例
                    ,title: '会员充值'
                    ,area: ['600px', '500px']
                    ,shade: 0
                    ,maxmin: true
                    ,content:"<?php echo url('admin_user/userCharge'); ?>?id="+id
                    ,zIndex: layer.zIndex //重点1
                    ,success: function(layero){
                        layer.setTop(layero); //重点2
                    }
                });
            }else{
                layer.open({
                    type: 2 //此处以iframe举例
                    ,title: '会员充值'
                    ,area: ['600px', '500px']
                    ,shade: 0
                    ,maxmin: true
                    ,content:"<?php echo url('admin_user/showList'); ?>?accountId="+id
                    ,zIndex: layer.zIndex //重点1
                    ,success: function(layero){
                        layer.setTop(layero); //重点2
                    }
                });
            }

        }
        function showCard(account_id) {
            layer.open({
                type: 2 //此处以iframe举例
                ,title: '管理员卡列表'
                ,area: ['700px', '500px']
                ,shade: 0
                ,maxmin: true
                ,content:"<?php echo url('admin_user/cardList'); ?>?accountId="+account_id
                ,zIndex: layer.zIndex //重点1
                ,success: function(layero){
                    layer.setTop(layero); //重点2
                }
            });
        }

        function delMail(id) {
            layer.confirm('<?php echo lang("confirm_delete"); ?>',function () {
                window.location.href = "<?php echo url('email/delete'); ?>?id="+id;
            })
        }
        
        function addEmail() {
            layer.open({
                type:2,
                content:'<?php echo url("email/edit"); ?>',
                title:'<?php echo lang("sys_mail_add"); ?>',
                area:['60%','80%'],
            })
        }
    </script>
    
<!--页面JS脚本-->

</body>
</html>