<?php /*a:2:{s:78:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\system_query\player_list.html";i:1640308700;s:58:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\base.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlentities($config['site_title']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" >
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <!--<link rel="stylesheet" href="/static/js/layui/css/global.css" media="all">未知CSS-->
    
    <style>
        .layui-laypage {
            display: inline-block;
            vertical-align: middle;
            font-size: 0;
            margin: 10px auto;
            box-sizing: content-box;
        }
        .layui-laypage ul li{
            float:left
        }
        .layui-laypage a, .layui-laypage span {
            display: inline-block;
            vertical-align: middle;
            padding: 0 15px;
            height: 28px;
            line-height: 28px;
            margin: 0 -1px 5px 0;
            background-color: #fff;
            color: #333;
            font-size: 12px;
        }

        .layui-laypage .active span{
            background-color: #009688; color: #fff;;
        }
    </style>
    
    <script src="/static/js/html5shiv.min.js"></script>
    <script src="/static/js/respond.min.js"></script>
</head>

<script src="/static/layuiadmin/layui/layui.all.js"></script>

<script src="/static/js/function.js"></script>
<script src="/static/js/my.js" type="text/javascript"></script>
<script type="text/javascript">
    var lang_set = {};
    $(function () {
        $.get("<?php echo url('index/langs'); ?>?controllername=<?php echo htmlentities($controller_name); ?>",function (res) {
            lang_set = res;
        });

    });
    function __(name) {
        return lang_set[name];
    }
</script>


<div class="layui-card">
    <div class="layui-card-header"></div>
    <div class="layui-card-body">
        <label><?php echo lang('uid_or_account'); ?>:</label>
        <div class="layui-inline">
            <input type="text" name="uid" id="uid" autocomplete="off" class="layui-input" value="" placeholder="<?php echo lang('uid_or_account'); ?>">
        </div>
        <div class="layui-inline">
            <button type="button" onclick="searchData()" class="layui-btn layui-btn-primary"><i class="layui-icon layui-icon-search"></i>搜索</button>
            <?php if(app('request')->cookie('user_group_info') != '渠道'): ?>
            <button type="button" onclick="addHideRank()" class="layui-btn layui-btn-primary">添加排行榜黑名单</button>
            <?php endif; ?>
        </div>
        <div class="layui-tab-item layui-show">
            <table class="layui-table" id="playerTable" lay-filter="playerTable"></table>
        </div>
    </div>

</div>



<script type="text/html" id="toolBar">
    <a class="layui-btn layui-btn-xs" lay-event="login_log">登录日志</a>
    <a class="layui-btn layui-btn-xs" lay-event="player_detail_list">明细列表</a>
    <?php if(app('request')->cookie('user_group_info') != '渠道'): ?>
    <a class="layui-btn layui-btn-xs" lay-event="out_line">T人</a>
    <a class="layui-btn layui-btn-xs" lay-event="edit">编辑</a>
    <?php endif; ?>
</script>
<script src="/static/layuiadmin/layui/layui.js"></script>
<script src="/static/js/echarts.js"></script>
<script src="/static/js/system_query/index.js?<?php echo time(); ?>"></script>
<script>
    layui.config({
        base: '/static/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use('index');
    layui.use(['upload', 'layer', 'form', 'table', 'laydate'], function () {
        var layer = layui.layer,
            element = layui.element,
            form = layui.form
            , laydate = layui.laydate;
        var table = layui.table;
        form.render();
        var obj = {
            elem:"#playerTable",
            url:"playerList",
        }
        renderPlayer(obj);
        table.on('tool(playerTable)',function (obj) {
            var data = obj.data;
            var event = obj.event;
            if (event == 'login_log'){
                layer.open({
                    type:2,
                    content:'login_log?uid='+data.uid,
                    title:"<?php echo lang('menu_player_login_log'); ?>",
                    area:['60%','80%'],
                })
            }else if(event == 'player_detail_list'){
                layer.open({
                    type:2,
                    content:'player_detail_list?uid='+data.uid,
                    title:"<?php echo lang('menu_player_detail_list'); ?>",
                    area:['60%','80%'],
                })
            }else if (event == 'out_line'){
                layer.confirm('确认踢下线',function () {
                    sendAjax({
                        uid:data.uid,
                    },function (res) {
                        layer.msg(res.msg)
                        if(res.code == 1){
                            layer.closeAll();
                        }
                    },'post','out_line',function (err) {
                        console.log(err)
                    })
                })
            }else{
                layer.open({
                    type:2,
                    content:'<?php echo url("club/index"); ?>?uid='+data.uid,
                    title:"编辑",
                    area:['60%','80%'],
                })
            }
        })
    });
    function searchData() {
        var query_string = "?uid="+$("#uid").val();
        var obj = {
            elem:"#playerTable",
            url:"playerList"+query_string,
        }
        renderPlayer(obj);
    }

    function addHideRank() {
        layer.prompt({title: '<?php echo lang("input uid"); ?>' , formType: 3 }, function(val, index){
            var datas = {}
            datas.uid = val; 
            sendAjax(datas,function (res) {
                if (res.code == 0){
                    layer.alert(res.msg,function () {
                        layer.closeAll();
                    })
                }else{
                    layer.msg(res.msg);
                }

            },'post',"add_hide_rank",function (err) {
                
            })
        });

    }
</script>

<!--页面JS脚本-->

</body>
</html>