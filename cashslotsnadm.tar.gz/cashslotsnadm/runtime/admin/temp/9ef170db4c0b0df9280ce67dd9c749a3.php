<?php /*a:2:{s:67:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\account\index.html";i:1640308700;s:58:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\base.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlentities($config['site_title']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" >
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <!--<link rel="stylesheet" href="/static/js/layui/css/global.css" media="all">未知CSS-->
    
    <style>
        .layui-laypage {
            display: inline-block;
            vertical-align: middle;
            font-size: 0;
            margin: 10px auto;
            box-sizing: content-box;
        }
        .layui-laypage ul li{
            float:left
        }
        .layui-laypage a, .layui-laypage span {
            display: inline-block;
            vertical-align: middle;
            padding: 0 15px;
            height: 28px;
            line-height: 28px;
            margin: 0 -1px 5px 0;
            background-color: #fff;
            color: #333;
            font-size: 12px;
        }

        .layui-laypage .active span{
            background-color: #009688; color: #fff;;
        }
    </style>
    
    <script src="/static/js/html5shiv.min.js"></script>
    <script src="/static/js/respond.min.js"></script>
</head>

<script src="/static/layuiadmin/layui/layui.all.js"></script>

<script src="/static/js/function.js"></script>
<script src="/static/js/my.js" type="text/javascript"></script>
<script type="text/javascript">
    var lang_set = {};
    $(function () {
        $.get("<?php echo url('index/langs'); ?>?controllername=<?php echo htmlentities($controller_name); ?>",function (res) {
            lang_set = res;
        });

    });
    function __(name) {
        return lang_set[name];
    }
</script>

<div class="layui-fluid">
    <div class="layui-card">


        <div class="layui-card-header">
            <div class="layui-btn-group">
                <a class="layui-btn layui-btn-sm layui-btn-normal" href="<?php echo url('admin/account/index'); ?>">管理员列表</a>
                <a class="layui-btn layui-btn-sm layui-btn-primary" href="<?php echo url('admin/account/edit'); ?>">添加管理员</a>
            </div>
        </div>
        <form class="layui-form" action="<?php echo url('account/index'); ?>" method="get" id="myform">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <label class="layui-form-label">用户名称</label>
                    <div class="layui-input-block">
                        <input type="text" name="name" id="name" placeholder="用户名称" value="<?php echo input('name'); ?>" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <label class="layui-form-label">账户类别</label>
                    <div class="layui-input-block">
                        <select name="type" id="type">
                            <option value="">请选择</option>
                            <option value="1">系统管理员</option>
                            <option value="2">玩家列表</option>
                        </select>
                    </div>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn "> <i class="layui-icon layui-icon-search"></i>搜索</button>
                </div>
            </div>
        </form>
        <div class="layui-card-body">

            <table class="layui-table">
                <thead>
                <tr>
                    <th>#</th>
                    <th>ID</th>
                    <th>账号</th>
                    <th>分数</th>
                    <th>名字</th>
                    <th>电话	</th>
                    <th>角色组</th>
                    <th>备注	</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $k=>$vo): ?>
                <tr>
                    <td><?php echo htmlentities($k); ?></td>
                    <td><?php echo htmlentities($vo['id']); ?></td>
                    <td><?php echo htmlentities($vo['username']); ?></td>
                    <td><?php echo htmlentities($vo['coin']); ?></td>
                    <td><?php echo htmlentities($vo['nickname']); ?></td>
                    <td><?php echo htmlentities($vo['tel']); ?></td>
                    <td><?php echo htmlentities($vo['access_name']); ?></td>
                    <td><?php echo htmlentities($vo['remark']); ?></td>
                    <td>
                        <a href="<?php echo url('admin/account/edit',['id'=>$vo['id']]); ?>" class="layui-btn layui-btn-normal layui-btn-sm">编辑</a>
                        <a href="<?php echo url('admin/account/grant',['id'=>$vo['id']]); ?>" class="layui-btn layui-btn-normal layui-btn-sm">授权</a>
                        <a href="<?php echo url('admin/account/delete',['id'=>$vo['id']]); ?>" class="layui-btn layui-btn-danger layui-btn-sm">禁用</a>
                    </td>
                </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                </tbody>
            </table>
            <div class="layui-laypage" id="demo0">
                <?php echo $list; ?>
            </div>
        </div>
    </div>
    

    <script>
        // 定义全局JS变量
        var GV = {
            current_controller: "admin/<?php echo htmlentities((isset($controller) && ($controller !== '')?$controller:'')); ?>/",
            base_url: "/static"
        };
        layui.use(['upload','layer','form'],function () {
            var layer = layui.layer,
                element = layui.element,
                form = layui.form;
        })
        $("#type").val("<?php echo input('type'); ?>");
        var form = layui.form;
        form.render();
        function showForm(id,type) {
            if (type == 1) {
                layer.open({
                    type: 2 //此处以iframe举例
                    ,title: '会员充值'
                    ,area: ['600px', '500px']
                    ,shade: 0
                    ,maxmin: true
                    ,content:"<?php echo url('admin_user/userCharge'); ?>?id="+id
                    ,zIndex: layer.zIndex //重点1
                    ,success: function(layero){
                        layer.setTop(layero); //重点2
                    }
                });
            }else{
                layer.open({
                    type: 2 //此处以iframe举例
                    ,title: '会员充值'
                    ,area: ['600px', '500px']
                    ,shade: 0
                    ,maxmin: true
                    ,content:"<?php echo url('admin_user/showList'); ?>?accountId="+id
                    ,zIndex: layer.zIndex //重点1
                    ,success: function(layero){
                        layer.setTop(layero); //重点2
                    }
                });
            }

        }
        function showCard(account_id) {
            layer.open({
                type: 2 //此处以iframe举例
                ,title: '管理员卡列表'
                ,area: ['700px', '500px']
                ,shade: 0
                ,maxmin: true
                ,content:"<?php echo url('admin_user/cardList'); ?>?accountId="+account_id
                ,zIndex: layer.zIndex //重点1
                ,success: function(layero){
                    layer.setTop(layero); //重点2
                }
            });
        }
    </script>
    
<!--页面JS脚本-->

</body>
</html>