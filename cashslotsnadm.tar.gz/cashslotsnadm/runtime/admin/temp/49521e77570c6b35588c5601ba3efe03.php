<?php /*a:2:{s:70:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\auth_group\index.html";i:1640308700;s:58:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\base.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlentities($config['site_title']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" >
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <!--<link rel="stylesheet" href="/static/js/layui/css/global.css" media="all">未知CSS-->
    
    <style>
        .layui-laypage {
            display: inline-block;
            vertical-align: middle;
            font-size: 0;
            margin: 10px auto;
            box-sizing: content-box;
        }
        .layui-laypage ul li{
            float:left
        }
        .layui-laypage a, .layui-laypage span {
            display: inline-block;
            vertical-align: middle;
            padding: 0 15px;
            height: 28px;
            line-height: 28px;
            margin: 0 -1px 5px 0;
            background-color: #fff;
            color: #333;
            font-size: 12px;
        }

        .layui-laypage .active span{
            background-color: #009688; color: #fff;;
        }
    </style>
    
    <script src="/static/js/html5shiv.min.js"></script>
    <script src="/static/js/respond.min.js"></script>
</head>

<script src="/static/layuiadmin/layui/layui.all.js"></script>

<script src="/static/js/function.js"></script>
<script src="/static/js/my.js" type="text/javascript"></script>
<script type="text/javascript">
    var lang_set = {};
    $(function () {
        $.get("<?php echo url('index/langs'); ?>?controllername=<?php echo htmlentities($controller_name); ?>",function (res) {
            lang_set = res;
        });

    });
    function __(name) {
        return lang_set[name];
    }
</script>


<div class="layui-fluid">
	<div class="layui-card">
		<div class="layui-card-header">
			<a class="layui-btn layui-btn-sm layui-btn-radius" href="<?php echo url('admin/auth_group/index'); ?>">角色列表</a>
			<a class="layui-btn layui-btn-sm layui-btn-radius layui-btn-primary" href="<?php echo url('admin/auth_group/edit'); ?>">添加角色</a>
		</div>	
	
		<div class="layui-card-body">
			<table class="layui-table">
				<thead>
				<tr>
					<th style="width: 30px;">ID</th>
					<th>名称</th>
					<th>单元名称</th>
					<th>备注</th>
					<th>操作</th>
				</tr>
				</thead>
				<tbody>
				<?php if(is_array($auth_group_list) || $auth_group_list instanceof \think\Collection || $auth_group_list instanceof \think\Paginator): if( count($auth_group_list)==0 ) : echo "" ;else: foreach($auth_group_list as $key=>$vo): ?>
				<tr>
					<td><?php echo htmlentities($vo['id']); ?></td>
					<td><?php echo htmlentities($vo['name']); ?></td>
					<td><?php echo htmlentities($vo['subject']); ?></td>
					<td><?php echo htmlentities($vo['dec']); ?></td>
					<td>
						<a href="<?php echo url('admin/auth_group/auth',['id'=>$vo['id']]); ?>" class="layui-btn layui-btn-sm">授权</a>
						<a href="<?php echo url('admin/auth_group/edit',['id'=>$vo['id']]); ?>" class="layui-btn layui-btn-normal layui-btn-sm">编辑</a>
						<a onclick="delId('<?php echo htmlentities($vo['id']); ?>')" class="layui-btn layui-btn-normal layui-btn-sm">删除</a>
					</td>
				</tr>
				<?php endforeach; endif; else: echo "" ;endif; ?>
				</tbody>
			</table>
        </div>
    </div>
</div>

<script type="text/javascript">
	function delId(id) {
		layer.confirm('确认删除吗？',function () {
            window.location.href="<?php echo url('admin/auth_group/delete'); ?>?id="+id;
        })
    }
	
</script>


<script>
    // 定义全局JS变量
    var GV = {
        current_controller: "admin/<?php echo htmlentities((isset($controller) && ($controller !== '')?$controller:'')); ?>/",
        base_url: "/static"
    };
    layui.use(['upload','layer','form','laypage'],function () {
        var layer = layui.layer,
            element = layui.element,
            form = layui.form,
            laypage = layui.laypage;
        form.render();

    })
    var form = layui.form;
    var layer = layui.layer;


</script>
<script src="/static/layuiadmin/layui/layui.js"></script>
<script type="text/javascript" src="/static/js/laytpl.js"></script>

<!--页面JS脚本-->

</body>
</html>