<?php /*a:2:{s:65:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\index\index.html";i:1640308700;s:59:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\bases.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
	</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    
<script src="/static/layuiadmin/layui/layui.js"></script>
<script>
    layui.config({
        base: '/static/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use('index');
</script>

    
    <style>
        .message-title{
            padding-top: 2px;
            background: white;
            height: 40px;
            line-height: 20px;
            font-size: 10px;
            color: #000000;
            text-indent: 20px;
        }
        .message-time{
            float: left;
            padding-top: 3px;
            color: #8e8e93;
            font-size: 10px;
            /*text-indent: 20px;*/
        }
        .message_btn{
            float: right;
            padding-top: -2px;
            text-indent: 1px;
        }

        .msg_box{
            border: 1px solid #e0e0e0;
            overflow-y: scroll;
            position: absolute;
            top: 51px;
            right: 1px;
            width: 25rem ;
            height: 20rem;
            display: none;
        }
        .msg_box_header{
            background: #e0e0e0;
            width: 100%;
            height: 2.5rem;
        }
        .msg_box_body{
            width: 100%;
            height: 100%;
            background: #f2f2f2;
        }
    </style>

</head>


<body class="layui-layout-body">
<div id="LAY_app">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <!-- 头部区域 -->
            <ul class="layui-nav layui-layout-left">
                <li class="layui-nav-item layadmin-flexible" lay-unselect>
                    <a href="javascript:;" layadmin-event="flexible" title="侧边伸缩">
                        <i class="layui-icon layui-icon-shrink-right" id="LAY_app_flexible"></i>
                    </a>
                </li>
                <li class="layui-nav-item" lay-unselect>
                    <a href="javascript:;" layadmin-event="refresh" title="刷新">
                        <i class="layui-icon layui-icon-refresh-3"></i>
                    </a>
                </li>
            </ul>

            <ul class="layui-nav layui-layout-right" lay-filter="layadmin-layout-right">


                <li class="layui-nav-item layui-hide-xs" lay-unselect>
                    <a href="javascript:;" layadmin-event="theme">
                        <i class="layui-icon layui-icon-theme"></i>
                    </a>
                </li>

                <li class="layui-nav-item layui-hide-xs" lay-unselect>
                    <a href="javascript:;" layadmin-event="fullscreen">
                        <i class="layui-icon layui-icon-screen-full"></i>
                    </a>
                </li>
                <li class="layui-nav-item" lay-unselect>
                    <a href="javascript:;">
                        <cite><?php echo session('user_info.username'); ?></cite>
                    </a>
                    <dl class="layui-nav-child">
                        <dd><a lay-href="/index.php/admin/account/changPwd">修改密码</a></dd>
                        <hr>
                        <dd style="text-align: center;"><a href="<?php echo url('login/logout'); ?>">退出</a></dd>
                    </dl>
                </li>
            </ul>
        </div>

        <!-- 侧边菜单 -->
        <div class="layui-side layui-side-menu">
            <div class="layui-side-scroll">
                <li class="layui-nav-item ">
                    <a href="javascript:;"><i class="" style="width: 18px;"></i> </a>
                    <dl class="layui-nav-child">
                        <dd><a href=""> </a></dd>
                    </dl>
                </li>
                <div class="layui-logo" href="index/map.html"> </div>
                <ul class="layui-nav layui-nav-tree" lay-shrink="all" id="LAY-system-side-menu" lay-filter="layadmin-system-side-menu">
                    <li data-name="home" class="layui-nav-item ">
                        <a href="javascript:;" lay-href="<?php echo url('index/map'); ?>" lay-tips="首页" lay-direction="2">
                            <i class="layui-icon layui-icon-home"></i>
                            <cite>首页</cite>
                        </a>
                    </li>
                    <?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): if( count($menu)==0 ) : echo "" ;else: foreach($menu as $key=>$vo): ?>
                        <li data-name="home" class="layui-nav-item ">
                            <?php if(!empty($vo['children'])): ?>
                            <a href="javascript:;"  lay-tips="<?php echo htmlentities($vo['title']); ?>" lay-direction="2">
                                <i class="<?php echo htmlentities($vo['icon']); ?>"></i>
                                <cite><?php echo htmlentities($vo['title']); ?></cite>
                            </a>
                            <?php else: ?>
                            <a lay-href="<?php echo url($vo['name']); ?>" title="<?php echo url($vo['name']); ?>"  lay-tips="<?php echo htmlentities($vo['title']); ?>" lay-direction="2">
                                <i class="<?php echo htmlentities($vo['icon']); ?>"></i>
                                <cite><?php echo htmlentities($vo['title']); ?></cite>
                            </a>
                            <?php endif; if(!empty($vo['children'])): ?>
                            <dl class="layui-nav-child">
                                <?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): if( count($vo['children'])==0 ) : echo "" ;else: foreach($vo['children'] as $key=>$v): ?>
                                <dd data-name="console">
                                    <a lay-href="<?php echo url($v['name']); ?>" title="<?php echo url($v['name']); ?>"><?php echo htmlentities($v['title']); ?></a>
                                </dd>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </dl>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; endif; else: echo "" ;endif; ?>

                    <li data-name="get" class="layui-nav-item">
                        <a onclick="logoutConfirm()" lay-tips="登出" lay-direction="2">
                            <i class="layui-icon layui-icon-auz"></i>
                            <cite>登出</cite>
                        </a>
                    </li>
                </ul>


            </div>
        </div>

        

<!-- 页面标签 -->
<div class="layadmin-pagetabs" id="LAY_app_tabs">
    <div class="layui-icon layadmin-tabs-control layui-icon-prev" layadmin-event="leftPage"></div>
    <div class="layui-icon layadmin-tabs-control layui-icon-next" layadmin-event="rightPage"></div>
    <div class="layui-icon layadmin-tabs-control layui-icon-down">
        <ul class="layui-nav layadmin-tabs-select" lay-filter="layadmin-pagetabs-nav">
            <li class="layui-nav-item" lay-unselect>
                <a href="javascript:;"></a>
                <dl class="layui-nav-child layui-anim-fadein">
                    <dd layadmin-event="closeThisTabs"><a href="javascript:;">关闭当前标签页</a></dd>
                    <dd layadmin-event="closeOtherTabs"><a href="javascript:;">关闭其它标签页</a></dd>
                    <dd layadmin-event="closeAllTabs"><a href="javascript:;">关闭全部标签页</a></dd>
                </dl>
            </li>
        </ul>
    </div>

    <div class="layui-tab" lay-unauto lay-allowClose="true" lay-filter="layadmin-layout-tabs">
        <ul class="layui-tab-title" id="LAY_app_tabsheader">
            <li lay-id="home/console.html" lay-attr="home/console.html" class="layui-this"><i class="layui-icon layui-icon-home"></i></li>
        </ul>
    </div>
</div>
<!-- 主体内容 -->
<div class="layui-body" id="LAY_app_body">
    <div class="layadmin-tabsbody-item layui-show">
        <iframe src="<?php echo url('index/map'); ?>" frameborder="0" class="layadmin-iframe"></iframe>
    </div>
</div>

<!-- 辅助元素，一般用于移动设备下遮罩 -->
<div class="layadmin-body-shade" layadmin-event="shade"></div>
</div>
</div>

    </div>
</div>
<script type="text/javascript" src="/static/js/jquery-3.2.1.js"></script>
<script type="text/javascript" src="/static/js/my.js"></script>
<script type="text/javascript">
    $(function () {
        $("#badge-dot").hide();
        console.log("<?php echo htmlentities($lang); ?>")
    })
    function select_lang(that) {
        var lang = $(that).val();
        console.log(lang)
        window.location.href = "<?php echo url('index/index'); ?>?lang="+lang ;
    }
    function logoutConfirm() {
        layer.confirm("确认退出吗？",function () {
            window.location.href="<?php echo url('login/logout'); ?>"
        })
    }
</script>
</body>

</html>