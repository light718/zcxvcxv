<?php /*a:1:{s:65:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\login\index.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cash Hero</title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    <script src="/static/layuiadmin/layui/layui.js"></script>
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <link rel="stylesheet" href="/static/layuiadmin/style/login.css"/>
    <script type="text/javascript" src="/static/js/my.js"></script>
    <style >

    </style>
</head>
<body>
<div class="layui-form language_form" >
    <div class="layui-form-item language_select">
        <div class="layui-input-inline layui-clear" style="width: 6rem;float:right" >
            <!--<select  id="lang_select" class="layui-select layui-clear" lay-filter="lang_select" lay-filter="lang_select">-->
                <!--<option value="zh-cn"><?php echo lang('chinese'); ?></option>-->
                <!--<option value="en-us"><?php echo lang('english'); ?></option>-->
            <!--</select>-->
        </div>

    </div>
</div>

<div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login">


    <div class="layadmin-user-login-main">
        <div class="layadmin-user-login-box layadmin-user-login-header">
            <p></p>
        </div>
        <div class="layadmin-user-login-box layadmin-user-login-body layui-form">
            <div class="layui-form-item">
                <label class="layadmin-user-login-icon layui-icon layui-icon-username"
                       for="LAY-user-login-username"></label>
                <input type="text" name="username" id="LAY-user-login-username" lay-verify="required" placeholder="<?php echo lang('username'); ?>"
                       class="layui-input">
            </div>
            <div class="layui-form-item">
                <label class="layadmin-user-login-icon layui-icon layui-icon-password"
                       for="LAY-user-login-password"></label>
                <input type="password" name="password" id="LAY-user-login-password" lay-verify="required"
                       placeholder="<?php echo lang('password'); ?>" class="layui-input">
            </div>
            <!--<div class="layui-form-item">-->
            <!--<label class="text-primary"><?php echo lang('select'); ?></label>-->
            <!--<a href="javascript:void(0);" class="layui-btn <?php if(($lang != 'zh_cn')): ?> layui-btn-primary <?php else: ?> layui-btn-normal <?php endif; ?>" id="chinese">-->
            <!--<img class="img-thumbnail img-responsive img-selectLang" src="/static/images/cn.png" title="<?php echo lang('chinese'); ?>">-->
            <!--</a>-->
            <!--<a href="javascript:void(0);" class="layui-btn <?php if(($lang != 'english')): ?>layui-btn-primary <?php else: ?> layui-btn-normal <?php endif; ?>" id="english">-->
            <!--<img class="img-thumbnail img-responsive img-selectLang" src="/static/images/en.png" title="<?php echo lang('english'); ?>">-->
            <!--</a>-->
            <!--</div>-->
            <div class="layui-form-item">
                <button class="layui-btn layui-btn-fluid" lay-submit lay-filter="LAY-user-login-submit"><?php echo lang('login'); ?> </button>
            </div>
        </div>
    </div>

    <div class="layui-trans layadmin-user-login-footer">
    </div>
</div>
<script>
    layui.config({
        base: '/static/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'user'], function () {
        var $ = layui.$
            , setter = layui.setter
            , admin = layui.admin
            , form = layui.form
            , router = layui.router()
            , search = router.search;
        $("#lang_select").val('<?php echo htmlentities($lang); ?>');
        form.render();

        //提交
        form.on('submit(LAY-user-login-submit)', function (obj) {
            sendAjax(obj.field,function (res ) {
                layer.msg(res.msg);
                if (res.code == 0){
                    setTimeout(function () {
                        if (parent.window){
                            parent.window.location.href= "<?php echo url('index/index'); ?>";
                        }else{
                            window.location.href= "<?php echo url('index/index'); ?>";
                        }
                    },1000)
                }
            },'post','<?php echo url("login/index"); ?>',function (err) {
                console.log( err );
            })
            //请求登入接口
            //     admin.req({
            //     type: 'post',
            //     url: "<?php echo url('login/index'); ?>" //实际使用请改成服务端真实接口
            //     , data: obj.field
            //     , success: function (datas) {
            //         if (datas.errcode == 200) {
            //             window.location.href = '<?php echo url("index/index"); ?>';
            //         }
            //     }
            //     , done: function (res) {
            //         if (res.errcode == 1) {
            //             layer.msg('登入成功', {
            //                 offset: '15px'
            //                 , icon: 0
            //                 , time: 3000
            //             }, function () {
            //                 window.location.href = '<?php echo url("index/index"); ?>'; //后台主页
            //             });
            //         } else {
            //             layer.msg(res.msg);
            //         }
            //     }
            // });
        });
        form.on('select(lang_select)',function (item) {
            window.location.href = "?lang="+item.value
        })

    });

</script>
</body>
</html>