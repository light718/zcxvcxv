<?php /*a:2:{s:71:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\club\shield_words.html";i:1640308700;s:58:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\base.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlentities($config['site_title']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" >
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <!--<link rel="stylesheet" href="/static/js/layui/css/global.css" media="all">未知CSS-->
    
    <style>
        .layui-laypage {
            display: inline-block;
            vertical-align: middle;
            font-size: 0;
            margin: 10px auto;
            box-sizing: content-box;
        }
        .layui-laypage ul li{
            float:left
        }
        .layui-laypage a, .layui-laypage span {
            display: inline-block;
            vertical-align: middle;
            padding: 0 15px;
            height: 28px;
            line-height: 28px;
            margin: 0 -1px 5px 0;
            background-color: #fff;
            color: #333;
            font-size: 12px;
        }

        .layui-laypage .active span{
            background-color: #009688; color: #fff;;
        }
    </style>
    
    <script src="/static/js/html5shiv.min.js"></script>
    <script src="/static/js/respond.min.js"></script>
</head>

<script src="/static/layuiadmin/layui/layui.all.js"></script>

<script src="/static/js/function.js"></script>
<script src="/static/js/my.js" type="text/javascript"></script>
<script type="text/javascript">
    var lang_set = {};
    $(function () {
        $.get("<?php echo url('index/langs'); ?>?controllername=<?php echo htmlentities($controller_name); ?>",function (res) {
            lang_set = res;
        });

    });
    function __(name) {
        return lang_set[name];
    }
</script>

<div class="layui-card " style="width: 90%">
    <div class="layui-card-header"></div>
    <div class="layui-card-body layui-container">
        <div class="layui-inline">
            <input type="text" name="start_time" id="time_year" autocomplete="off" class="layui-input-inline layui-input" placeholder="<?php echo lang('input_member_id'); ?>" value="">
        </div>
        <div class="layui-inline">

        <button type="button" class="layui-btn layui-btn-primary" onclick="searchWords()">搜索</button>
            <button type="button" class="layui-btn layui-btn-primary" onclick="addWords()"><?php echo lang('add_shield_words'); ?></button>

        </div>
        <div class="layui-tab-item layui-show ">
            <table class="layui-table" id="words_table" lay-filter="words_table"></table>
        </div>
    </div>
</div>
<div>

</div>


<script type="text/html" id="toolbarDemo">
    <a class="layui-btn layui-btn-xs" lay-event="edit"><?php echo lang('edit'); ?></a>
    <a class="layui-btn layui-btn-xs" lay-event="delete"><?php echo lang('delete'); ?></a>
</script>
<script src="/static/layuiadmin/layui/layui.js"></script>
<script src="/static/js/echarts.js"></script>
<script src="/static/js/club/index.js?<?php echo time(); ?>"></script>
<script>
    layui.config({
        base: '/static/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use('index');
    layui.use(['upload', 'layer', 'form', 'table', 'laydate'], function () {
        var layer = layui.layer,
            element = layui.element,
            form = layui.form
            , laydate = layui.laydate,
            table = layui.table;
            form.render();
        searchWords();
        table.on('tool(words_table)', function(obj){ //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）
            console.log(data)
            if(layEvent == 'edit'){ // 转移
                layer.open({
                    type:2,
                    content:'wordEdit?id='+data.id,
                    title:"编辑："+data.id ,
                    area:['30%','50%'],
                })
            } else if(layEvent == 'delete'){ // 用户
                layer.confirm("<?php echo lang('confirm_delete'); ?>",function () {
                    var datas = {};
                    datas.id = data.id;
                    sendAjax( datas,function (res) {
                        layer.msg(res.msg);
                        if (res.code == 0){
                            searchWords();
                        }
                    },'post','wordDelete',function (err) {
                        console.log(err)
                    });
                })

            }
        });
    });

    function addWords() {
        layer.open({
            type:2,
            content:'wordEdit',
            title:"新增",
            area:['30%','50%'],
        })
    }
</script>

<!--页面JS脚本-->

</body>
</html>