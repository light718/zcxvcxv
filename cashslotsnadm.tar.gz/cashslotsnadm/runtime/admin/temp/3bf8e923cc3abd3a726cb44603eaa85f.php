<?php /*a:2:{s:63:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\index\map.html";i:1640308700;s:58:"D:\phpWorkspace\njp.adm.rummyslot.com\view\admin\base.html";i:1640308700;}*/ ?>
<!DOCTYPE html>
<html >
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlentities($config['site_title']); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script src="/static/js/jquery-3.2.1.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/static/layuiadmin/layui/css/layui.css" >
    <link rel="stylesheet" href="/static/layuiadmin/style/admin.css" media="all">
    <!--<link rel="stylesheet" href="/static/js/layui/css/global.css" media="all">未知CSS-->
    
    <style>
        .layui-laypage {
            display: inline-block;
            vertical-align: middle;
            font-size: 0;
            margin: 10px auto;
            box-sizing: content-box;
        }
        .layui-laypage ul li{
            float:left
        }
        .layui-laypage a, .layui-laypage span {
            display: inline-block;
            vertical-align: middle;
            padding: 0 15px;
            height: 28px;
            line-height: 28px;
            margin: 0 -1px 5px 0;
            background-color: #fff;
            color: #333;
            font-size: 12px;
        }

        .layui-laypage .active span{
            background-color: #009688; color: #fff;;
        }
    </style>
    
    <script src="/static/js/html5shiv.min.js"></script>
    <script src="/static/js/respond.min.js"></script>
</head>

<script src="/static/layuiadmin/layui/layui.all.js"></script>

<script src="/static/js/function.js"></script>
<script src="/static/js/my.js" type="text/javascript"></script>
<script type="text/javascript">
    var lang_set = {};
    $(function () {
        $.get("<?php echo url('index/langs'); ?>?controllername=<?php echo htmlentities($controller_name); ?>",function (res) {
            lang_set = res;
        });

    });
    function __(name) {
        return lang_set[name];
    }
</script>

<style type="text/css">
    .layui-row {
        margin-top: 5px;
    }
</style>
<div class="layui-tab">
    <ul class="layui-tab-title">
        <li class="layui-this" onclick="reloadOnlineNums()"><?php echo lang('market_data'); ?></li>
        <li onclick="subGames();"><?php echo lang('game_operation_tools'); ?></li>
        <li><?php echo lang('launch_basic_data'); ?></li>
        <li><?php echo lang('loss_analysis'); ?></li>
        <li><?php echo lang('online_duration_analysis'); ?></li>
        <li><?php echo lang('sub_game_analysis'); ?></li>
        <li><?php echo lang('utilization_analysis'); ?></li>
    </ul>
    <div class="layui-tab-content">
        <div class="layui-tab-item layui-show">
            <div class="layui-tab">
                <ul class="layui-tab-title">
                    <li class="layui-this" onclick="reloadOnlineNums()"><?php echo lang('current_day_data'); ?></li>
                    <li onclick="showOtherDay()"><?php echo lang('show_other_day'); ?></li>
                </ul>
                <div class="layui-tab-content">
                    <div class="layui-tab-item layui-show">
                        <div role="tabpanel" class="tab-pane active" id="current_day_data">
                            <div class="layui-row" style="height: 3rem;background-color: #d9edf7;line-height: 3rem">
                                <div class="layui-col-xs4 layui-col-sm7 layui-col-md3">
                                    <?php echo lang('total_online'); ?> ：<span class="badge bg-gray ui-autocomplete-input"
                                                                   id="online_nums"></span>
                                </div>
                                <div class="layui-col-xs4 layui-col-sm7 layui-col-md3">
                                    <?php echo lang('fb_online'); ?> : <span id="fb_online_nums"></span>
                                </div>
                                <div class="layui-col-xs4 layui-col-sm7 layui-col-md3">
                                    <?php echo lang('google_online'); ?> : <span id="google_online_nums"></span>
                                </div>
                                <div class="layui-col-xs4 layui-col-sm7 layui-col-md3">
                                    <?php echo lang('guest_online'); ?> : <span id="guest_online_nums"></span>
                                </div>
                            </div>
                            <div class="layui-row" style="background-color: #d9edf7;line-height: 3rem"
                                 id="city_list"></div>

                            <div class="layui-row" style="background-color: #d9edf7;line-height: 3rem">
                                <div class="layui-col-md3 grid-demo grid-demo-bg2"><?php echo lang('ios_online'); ?>: <span
                                        id="ios_online_nums"></span>
                                </div>
                                <div class="layui-col-md3 grid-demo grid-demo-bg2">
                                    <?php echo lang('android_online'); ?>
                                    : <span
                                        id="android_online_nums"></span>
                                </div>
                            </div>
                            <div class="layui-row" style="width: 100%">
                                <div id="today_online_data" class="col-xs-12 col-sm-12 col-md-12"
                                     style="height: 400px;"></div>
                            </div>

                        </div>
                        <table class="layui-table">
                            <thead>
                            <tr>
                                <th><?php echo lang('welcome_type'); ?></th>
                                <th><?php echo lang('welcome_score'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><?php echo lang('welcome_total_reload'); ?></td>
                                <td><?php echo htmlentities($data['today_player_total_add_coin']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('welcome_total_withdraw'); ?></td>
                                <td><?php echo htmlentities($data['today_player_total_sub_coin']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('welcome_total_win'); ?></td>
                                <td><?php echo htmlentities($data['today_total_win_coin']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('welcome_reload_history'); ?></td>
                                <td><?php echo htmlentities($data['today_total_win_coin']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('welcome_withdraw_history'); ?></td>
                                <td><?php echo htmlentities($data['total_withdraw']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('welcome_win_history'); ?></td>
                                <td><?php echo htmlentities($data['total_win']); ?></td>
                            </tr>
                            </tbody>
                        </table>
                        <table class="layui-table">
                            <thead>
                            <tr>
                                <th>今日统计</th>
                                <th>数据</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td><?php echo lang('market_dnu'); ?></td>
                                <td><?php echo htmlentities($market['dnu']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('market_dau'); ?></td>
                                <td><?php echo htmlentities($market['dau']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('market_paynum'); ?></td>
                                <td><?php echo htmlentities($market['paynum']); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo lang('market_payamount'); ?></td>
                                <td><?php echo htmlentities($market['payamount']); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="layui-tab-item">
                        <div class="layui-form">
                            <label>渠道：</label>
                            <div class='layui-form-item layui-input-inline'>
                                <select name="channel" class="layui-select " id="channel">
                                    <option value="">全部渠道</option>
                                    <option value="1">安卓</option>
                                    <option value="2">IOS</option>

                                </select>
                            </div>
                            <label>起始时间：</label>
                            <!--指定 date标记-->
                            <div class="layui-inline">
                                <input type='text' autocomplete="off" class="layui-input-inline layui-input" id='start_time'/>
                            </div>
                            <label>终止时间：</label>
                            <!--指定 date标记-->
                            <div class="layui-inline">
                                <input type='text' autocomplete="off" class="layui-input-inline layui-input"
                                       id='end_time'/>
                            </div>
                            <button type="button" class="layui-btn layui-btn-primary"
                                    onclick="searchOnline()">搜索
                            </button>
                        </div>
                        <div class="table-responsive" style="width:100%;overflow-x: scroll">
                            <table class="table table-bordered table-striped" id="other_day_table">

                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="layui-tab-item">
            <div class="layui-tab">
                <ul class="layui-tab-title">
                    <li class="layui-this" onclick="slotsGame()"><?php echo lang('slots子游戏功能'); ?></li>
                    <li onclick="shopGoods()"><?php echo lang('商城商品陈列'); ?></li>
                    <li onclick="bonusList()"><?php echo lang('BONUS界面陈列'); ?></li>
                    <li onclick="missionConfig()"><?php echo lang('任务界面配置'); ?></li>
                    <li onclick="signConfig()"><?php echo lang('7日签到'); ?></li>
                </ul>
                <div class="layui-tab-content">
                    <div class="layui-tab-item layui-show"></div>
                    <div class="layui-tab-item">
                        <table class="layui-table" id="render_goods" lay-filter="render_goods"></table>
                    </div>
                    <div class="layui-tab-item">
                        <table class="layui-table" id="render_bonus" lay-filter="render_bonus"></table>
                    </div>
                    <div class="layui-tab-item">
                        <table class="layui-table" id="render_mission" lay-filter="render_mission"></table>
                        <table class="layui-table" id="render_active" lay-filter="render_active"></table>
                    </div>
                    <div class="layui-tab-item">
                        <table class="layui-table" id="render_config" lay-filter="render_config"></table>
                    </div>
                </div>
            </div>

        </div>
        <div class="layui-tab-item">内容3</div>
        <div class="layui-tab-item">内容4</div>
        <div class="layui-tab-item">内容5</div>
    </div>


</div>



<script src="/static/layuiadmin/layui/layui.js"></script>
<script src="/static/js/index/index.js?<?php echo time(); ?>"></script>
<script src="/static/js/echarts.simple.js"></script>
<script type="text/html" id="tablebar">
    <a class="layui-btn layui-btn-xs" lay-event="edit"><?php echo lang('edit'); ?></a>
</script>
<script type="text/html" id="goodsTablebar">
    <a class="layui-btn layui-btn-xs" lay-event="edit"><?php echo lang('edit'); ?></a>
</script>
<script>
    layui.config({
        base: '/static/layuiadmin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use('index');
    layui.use(['upload', 'layer', 'form', 'table', 'laydate'], function () {
        var layer = layui.layer,
            element = layui.element,
            table = layui.table ,
            form = layui.form
            , laydate = layui.laydate;

        laydate.render({
            elem:"#start_time",
            type:'datetime',
        })
        laydate.render({
            elem:"#end_time",
            type:'datetime',
            value:'<?php echo date("Y-m-d H:i:s"); ?>'
        })
        table.on('tool(render_config)', function(obj) { //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）
            console.log(data)
            if (layEvent === 'edit') { // 转移

                layer.open({
                    type:2,
                    title: '編輯',
                    content:"<?php echo url('index/config_edit'); ?>?id="+data.id,
                    area:['60%','80%'],
                });
            }
        });
        table.on('tool(render_goods)', function(obj) { //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）
            if (layEvent === 'edit') { // 转移
                layer.open({
                    type:2,
                    title: '編輯',
                    content:"<?php echo url('index/goods_edit'); ?>?id="+data.id,
                    area:['60%','80%'],
                });
            }
        });
    });
    function searchOnline() {
        var query_string = "?channel="+$("#channel").val()+"&start_time=" +$("#start_time").val()+"&end_time="+$("#end_time").val();
        renderOtherDay({
            elem:"#other_day_table",
            url:"show_other_day"+query_string,
        })
    }

    function showOtherDay(){
        renderOtherDay({
            elem:"#other_day_table",
            url:"show_other_day",
        })
    }
    
    function signConfig() {
        renderConfig({
            elem:"#render_config",
            url:"signConfig",
        })
    }

    function shopGoods() {
        renderGoods({
            elem:"#render_goods",
            url:"render_goods",
        })
    }
    function bonusList() {
        renderBonus({
            elem:"#render_bonus",
            url:"render_bonus",
        })
    }
    function missionConfig(){
        renderMission({
            elem:"#render_mission",
            url:"render_mission",
        })
        renderActive({
            elem:"#render_active",
            url:"render_active",
        })
    }

</script>

<!--页面JS脚本-->

</body>
</html>