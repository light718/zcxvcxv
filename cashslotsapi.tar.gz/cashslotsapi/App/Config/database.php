<?php
return [
    'host'=>'127.0.0.1',
    'user'=>'es3',
    'password'=>'123456',
    'database'=>'es3'
];