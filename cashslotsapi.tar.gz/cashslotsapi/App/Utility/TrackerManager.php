<?php
namespace App\Utility;

use EasySwoole\Component\Singleton;

class TrackerManager extends \EasySwoole\Trace\TrackerManager
{
    use Singleton;
}