<?php
namespace App\Rpc;

use EasySwoole\Component\Singleton;
use EasySwoole\Rpc\Rpc;

class RpcServer extends Rpc
{
    use Singleton;

}