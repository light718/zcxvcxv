basepath=$(cd `dirname $0`; pwd)
cd $basepath
php easyswoole start d

