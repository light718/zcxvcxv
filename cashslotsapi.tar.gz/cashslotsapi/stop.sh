basepath=$(cd `dirname $0`; pwd)
cd $basepath
php easyswoole stop
pkill -f 'CASH hero A'
