<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    public $token = '';
    public $account = array();
    public $selectedLang = 'zh_cn';

    function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('lang')) {
            $this->selectedLang = $this->session->userdata('lang');
        }
        
        //hao.liu 加载语言包
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('bolog_lang');
        
        $this->check_login();
    }

    protected function is_post()
    {
        return $this->input->method(TRUE) === 'POST' ? TRUE : FALSE;
    }

    protected function is_ajax()
    {
        return $this->input->is_ajax_request();
    }

    //判断是否登录
    protected function _is_login()
    {
        if (!$this->session->userdata('user_info')) {
            return false;
        }
        $userInfo = $this->session->userdata('user_info');
        $this->token = $userInfo['token'];
        $this->account = $userInfo['account'];
        if (!in_array($this->router->fetch_class(), ['passport', 'welcome'])) {
            session_write_close();
        }
        return true;
    }

    //检查登陆
    protected function check_login()
    {
        $classname = $this->router->class;
        if (!$this->_is_login() && !in_array(strtolower($classname), ['passport', 'card'])) {
            if ($this->is_ajax()) {
                jsonReturn(EXIT_INVALID_TOKEN,'1');
            } else {
                redirect(config_item('admin_url') . "/passport/login");
            }
        }
    }

    protected function getActGameName($gameid) {
        $dict = [];
        $dict[10000] = '上分';
        $dict[20000] = '下分';
        $dict[30000] = 'EVO视讯';
        $dict[50000] = 'BIGBANG';
        $dict[60000] = 'REDBAG';
        $dict[80000] = '升级奖励';
        $dict[70000] = 'BB幸运转盘';
        $dict[90000] = '幸运红包';
        $dict[100000] = '红包雨';
        $dict[110000] = '成长系统的宝箱';
        $dict[120000] = '在线奖励';
        $dict[130000] = '玩家注册奖励';
        $dict[140000] = '玩家转盘奖励';
        $dict[150000] = '邮件附件';
        $dict[160000] = '任务奖励';
        $dict[170000] = '标签页奖励';
        $dict[180000] = '集邮商城奖励';
        $dict[180001] = '集邮奖励';
        $dict[190000] = '破产补助';
        if(!isset($dict[$gameid])) {
            return false;
        }
        return $dict[$gameid];
    }

    public function render($view, $data)
    {
        if ($this->account) {
            $this->account['coin'] = formatMoney($this->account['coin']);
            if (CSS_VERSION === 'poly') {
                $language = $this->lang->language;
                $menu = config_item('menu_poly');
                $myMenu = array();
                $auth = explode(',', $this->account['auth_id']);
                $result = $this->requestApi('/account/current', 'GET', array());
                if (isset($this->account['vid']) && $this->account['vid']) { //子账号
                    $data['right_name'] = $result['data']['account_username'];
                    $gid = explode(',', $result['data']['virtual_group_id']);
                    foreach ($menu as $row) {
                        // if (strstr($row['name'], 'bigbang') && CSS_VERSION != 'bigbang') {
                        //     continue;
                        // }
                        $row['name'] = $language['menu_' . $row['name']];
                        if (isset($row['auth']) && !in_array($row['auth'], $auth)) {
                            continue;
                        }
                        if (array_intersect($gid, $row['child']) || in_array(0, $row['child'])) {
                            if (ltrim($row['url'], '/') == $this->uri->uri_string()) {
                                $row['selected'] = 1;
                            } else {
                                $row['selected'] = 0;
                            }
                            $myMenu[] = $row;
                        }
                    }
                } else {
                    foreach ($menu as $row) {
                        if (isset($row['auth']) && !in_array($row['auth'], $auth)) {
                            continue;
                        }
                        // if (strstr($row['name'], 'bigbang') && CSS_VERSION != 'bigbang') {
                        //     continue;
                        // }
                        $row['name'] = $language['menu_' . $row['name']];
                        $childFlag = 0;
                        if (isset($row['submenu'])) {
                            foreach ($row['submenu'] as $key => $submenu) {
                                if (isset($submenu['auth']) && !in_array($submenu['auth'], $auth)) {
                                    unset($row['submenu'][$key]);
                                }
                                if (in_array($this->account['agent'], $submenu['visible'])) {
                                    $row['submenu'][$key] = $submenu;
                                    if (ltrim($submenu['url'], '/') == $this->uri->uri_string()) {
                                        $childFlag = 1;
                                        $row['submenu'][$key]['selected'] = 1;
                                    } else {
                                        $row['submenu'][$key]['selected'] = 0;
                                    }
                                    $row['submenu'][$key]['name'] = $language['menu_' . $submenu['name']];
                                } else {
                                    unset($row['submenu'][$key]);
                                }
                            }
                        }
                        if (in_array($this->account['agent'], $row['visible'])) {
                            if ($childFlag == 1 || ltrim($row['url'], '/') == $this->uri->uri_string()) {
                                $row['selected'] = 1;
                            } else {
                                $row['selected'] = 0;
                            }
                            $myMenu[] = $row;
                        }
                    }
                    if ($this->account['agent'] == ADMIN_SYSTEM) {
                        $data['right_name'] = 'Sys Admin';
                    } else if ($this->account['agent'] == ADMIN_PROXY_GENERAL) {
                        $data['right_name'] = 'General agent';
                    } else if ($this->account['agent'] == ADMIN_PROXY_NORMAL) {
                        $data['right_name'] = $this->account['username'];
                    }
                }
                $data['menu'] = $myMenu;
            } elseif (CSS_VERSION === 'bigbang') {
                $language = $this->lang->language;
                $regionconf = config_item('regionconf');
                $selectRegion = [];
                foreach ($regionconf as $key => $value) {
                    $selectRegion[$key] = $language['region_' . $key];
                }
                $data['select_region'] = $selectRegion;
                $selectRegion = $this->session->userdata('select_region');
                if ($selectRegion) {
                    $data['select_region_key'] = $selectRegion;
                    $data['select_region_name'] = $language['region_' . $selectRegion];
                } else { //默认选择第一个
                    $data['select_region_key'] = array_keys($regionconf)[0];
                    $data['select_region_name'] = $language['region_' . $data['select_region_key']];
                }
            }
            
        }
        $data['lang'] = $this->selectedLang;
        $data['account'] = $this->account;
        $data['admin_url'] = config_item('admin_url');
        $data['css_version'] = CSS_VERSION;
        $view = CSS_VERSION . '/' . $view;
        return $this->load->view($view, $data);
    }

    public function requestApi($uri, $method, $params = array(), $list = false)
    {
        $apiUrl = API_URL_BASE;
        // bigbang需要切换地区，不同地区对应的api地址不同
        if (CSS_VERSION === 'bigbang') {
            $selectRegion = $this->session->userdata('select_region');
            $regionconf = config_item('regionconf');
            if ($regionconf) {
                if ($selectRegion) {
                    $apiUrl = isset($regionconf[$selectRegion]) ? $regionconf[$selectRegion] : $apiUrl;
                }/* else { //默认选择第一个
                    $apiUrl = array_values($regionconf)[0];
                }*/
            }
        }
        foreach ($params as $key => $val) {
            if ($val === NULL || $val === '') {
                unset($params[$key]);
            } else {
                $params[$key] = trim($val);
            }
        }
        if (strstr($uri, 'http')) {
            $url = $uri;
        } else {
            $url = $apiUrl . $uri;
        }
        if ($method == 'GET') {
            if ($this->token) {
                $params['token'] = $this->token;
            }
            $url = $url . '?' . http_build_query($params);
        } else {
            if ($this->token) {
                $url = $url . '?token=' . $this->token;
            }
        }
        // echo($url);exit;
        $result = uCurl($url, $method, $params);
        if ($result['errcode'] == EXIT_INVALID_TOKEN) { // token无效
            // 销毁当前session
            $this->session->unset_userdata('user_info');
            if ($this->is_ajax()) {
                jsonReturn(EXIT_INVALID_TOKEN,$result['error']);
                exit();
            } else {
                redirect(config_item('admin_url') . "/passport/login");
            }
        }

        if ($list && $result['errcode'] != 0) {
            $result['data']['list'] = [];
            $result['data']['total'] = 0;
        }

        return $result;
    }

    public function record($title, $detail, $tpls = [], $flag = true)
    {
        $tpls_cn = [];
        $tpls_en = [];
        
        //拆分参数中的中英文
        foreach ($tpls as $tpl) {
            if (strpos($tpl, "|||") !== false && is_array($l = explode("|||", $tpl)) && count($l) == 2 ) {
                $tpls_cn[] = $l[0];
                $tpls_en[] = $l[1];
            } else {
                $tpls_cn[] = $tpl;
                $tpls_en[] = $tpl;
            }
        }
        
        if ($flag && function_exists("fastcgi_finish_request")) { // yii或yaf默认不会立即输出，加上此句即可（前提是用的fpm）
            echo $this->output->get_output();
            fastcgi_finish_request(); // 响应完成, 立即返回到前端,关闭连接
        }
        $ip = getIp();
        $os = getOS();
        $browser = browserInfo();
        $time = time();
        // file_put_contents('/tmp/log.txt', $detail, FILE_APPEND);
        $data = [
            'account_agent' => $this->account['agent'],
            'account_id' => $this->account['id'],
            'account_vid' => isset($this->account['vid']) ? $this->account['vid'] : 0,
            'ip' => $ip,
            'os' => $os,
            'browser' => $browser,
            't' => $this->lang->language['cn_'.md5($title)],
            't2' => $this->lang->language['en_'.md5($title)],
            'detail' => sprintf($this->lang->language['cn_'.md5($detail)], ...$tpls_cn),
            'detail2' => sprintf($this->lang->language['en_'.md5($detail)], ...$tpls_en),
            'create_time' => $time
        ];

        $this->requestApi('/system/log_agent_api', 'POST', $data);
    }

    /**
     * 从游戏服务器获取游戏列表
     * @param int $uniq 去掉重复的
     * @return array
     */
    protected function getGameList($uniq = 1)
    {
        $result = $this->requestApi('/system/games', 'GET', array('uniq' => $uniq, 'lang' => ($this->selectedLang === 'english' ? 2 : 1)));
        $gameLists = isset($result['data']['list']) ? $result['data']['list'] : array();
        if ($uniq == 1) {
            $gameLists = array_column($gameLists, null, 'id');
        }
        return $gameLists;
    }

    protected function _getFloat($newspay, $newsuser, $isPercent = 0)
    {
        $floatNum = 0;
        if (!empty($newspay) && !empty($newsuser)) {
            $floatNum = round($newspay / $newsuser, 2);
        }
        if ($isPercent == 1) {
            return ($floatNum * 100) . '%';
        }
        return $floatNum;
    }

    //直接使用原生redis对象
    protected function getRedisObj()
    {
        $config = $this->config->item('redis_default');
        $redis = new \Redis();
        $redis->connect($config['host'], $config['port']); 
        $redis->auth($config['password']); 
        $redis->select($config['db']); 
        return $redis;
    }

}