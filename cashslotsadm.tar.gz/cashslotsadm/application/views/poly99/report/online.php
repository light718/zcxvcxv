<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['report_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
        }
        body{overflow-y: scroll;}
        .stbox{
            margin:0px;
            padding:20px;
            text-align: center;
            border-radius: 6px;
        }
        .stbox .title{
            font-size: 16px;
        }
        .stbox .value{
            font-size: 36px;
            font-weight: bold;
        }
        .stc_1{
            background: #3278b3;
            color:#FFF;
        }
        .stc_2{
            background: #23b7e5;
            color:#FFF;
        }
        .stc_3{
            background: #edbc6c;
            color:#FFF;
        }
        .stbox>p{
            overflow: hidden;
            white-space: nowrap;
        }
        .display {
            background-image: url('/backend/images/display.png');
        }
        .none {
            background-image: url('/backend/images/none.png');
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-inline" style="width: 200px;">
                    <select name="game_type" lay-filter="game-type" id="game-type">
                        <?php foreach ($game_type as $row) : ?>
                        <option value="<?php echo $row['type']; ?>" <?php if ($type == $row['type']) : ?>selected<?php endif; ?>><?php echo $row['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="text-contain" style="overflow: hidden;max-height: 250px;">
        <div class="layui-row layui-col-space20 top-div" style="padding:20px;">
            <div class="layui-col-xs2">
                <div class="stbox stc_1">
                    <p class="title"><?php echo $language['all_online_num']; ?></p>
                    <p class="value"><?php echo $all_nums; ?></p>
                </div>
            </div>
            <div id="online-data" class="layui-col-space20">
                <?php foreach ($list as $row) : ?>
                <div class="layui-col-xs2">
                    <div class="stbox stc_2">
                        <p class="title"><?php echo $row['name']; ?></p>
                        <p class="value"><?php echo $row['online_nums']; ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div></div>
        <div class="layui-row" style="text-align:center;margin-top: 5px;"><a id="display" style="display: none;" title="展开"><img id="display-img" src="/backend/images/display.png" width="20px;"></a></div>
    </div>
    <div class="layui-card">
        <div class="layui-card-body">
            <div id="online-container" style="height: 500px;"></div>
        </div>
    </div>
    <script src="/backend/layui/layui.js"></script>
    <script type="text/javascript" src="/backend/lib/extend/jquery.min.js"></script>
    <script type="text/javascript" src="/backend/lib/extend/echarts.min.js"></script>
    <script type="text/javascript" src="/backend/modules/report/online.js?v=1.011"></script>
    <script type="text/javascript">
        var type = "<?php echo $type; ?>";
        if ($('.top-div').height()>=270) {
            $('#display').show();
        } else {
           $('#display').hide();
        }
        $('#display').click(function() {
            if ($('#display').attr('title') == '收起') {
                $('.text-contain').css('max-height', '250px');
                $('#display').attr('title', '展开');
                $('#display-img').attr('src', '/backend/images/display.png');
            } else {
                $('.text-contain').css('max-height', '1000px');
                $('#display').attr('title', '收起');
                $('#display-img').attr('src', '/backend/images/none.png');
            }
        });
    </script>
</div>
</body>
</html>