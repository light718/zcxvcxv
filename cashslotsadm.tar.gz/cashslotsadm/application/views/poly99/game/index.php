<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
            padding-left: 15px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-card-header {
            height: 25px;
            line-height: 25px;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <fieldset class="layui-elem-field">
        <legend><h2><b><?php echo $language['title']; ?></b></h2></legend>
        <div class="layui-field-box">
            <?php echo $language['sub_title']; ?>
        </div>
    </fieldset>
    <fieldset class="layui-elem-field">
        <legend><h3><b><?php echo $language['consume_coin']; ?></b></h3></legend>
        <div class="layui-field-box">
            <div class="layui-form-item" style="margin: 10px 0 10px 0px;">
                <div class="layui-input-block">
                    <span style="width: 250px;display: inline-block;"><?php echo $language['consume_coin_tips']; ?></span>
                    <button class="layui-btn" style="width: 100px;margin-left: 20px;" id="consume-coin-setting"><?php echo $language['btn_setting']; ?></button>
                </div>
            </div>
            <div class="layui-form-item" style="margin: 10px 0 10px 0;">
                <div class="layui-input-block">
                    <b id="commission" style="width: 250px;display: inline-block;"><?php echo $language['history_consume_coin']; ?>：<?php echo $coin['sys_tax']; ?></b>
                    <button class="layui-btn layui-btn-normal btn-commission" type="1" style="margin-left: 20px;"><?php echo $language['history_consume_coin']; ?></button>
                    <button class="layui-btn layui-btn-primary btn-commission" type="2" style="margin-left: 20px;"><?php echo $language['today_consume_coin']; ?></button>
                    <button class="layui-btn layui-btn-primary btn-commission" type="3" style="margin-left: 20px;"><?php echo $language['seven_day_consume_coin']; ?></button>
                    <button class="layui-btn layui-btn-primary btn-commission" type="4" style="margin-left: 20px;"><?php echo $language['month_consume_coin']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['history_add_coin']; ?>：<?php echo $coin['reload']; ?></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['history_sub_coin']; ?>：<?php echo $coin['withdraw']; ?></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['history_total_coin']; ?>：<?php echo $coin['total_diff']; ?></b>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 20px;">
                <div class="layui-input-block">
                    <h5><?php echo $language['notice_01']; ?></h5>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['cur_consume_coin_ratio']; ?>：<?php echo $data['pool_tax_par']; ?>%</b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['cur_consume_coin_max_setting']; ?>：<?php echo $data['pool_tax_limitup']; ?></b>
                </div>
            </div>
            <div class="layui-form-item" style="margin: 10px 0 10px 0px;">
                <div class="layui-input-block">
                    <b style="color: red;width: 250px;display: inline-block;"><?php echo $language['cur_consume_coin']; ?>：<span id="cur_tax"><?php echo $cur['cur_tax']; ?> (<?php echo $cur['tax_ratio']; ?>)</span></b>
                    <button class="layui-btn btn-empty" type="1" style="width: 100px;margin-left: 20px;"><?php echo $language['btn_empty_normal']; ?></button>
                </div>
            </div>
            <div class="layui-form-item" style="margin: 10px 0 10px 0px;">
                <div class="layui-input-block">
                    <b style="color: red;width: 250px;display: inline-block;"><?php echo $language['cur_normal']; ?>：<span id="cur_normal"><?php echo $cur['normal']; ?></span></b>
                    <button class="layui-btn btn-empty" type="2" style="width: 100px;margin-left: 20px;"><?php echo $language['btn_empty_normal']; ?></button>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 20px;">
                <div class="layui-input-block">
                    <?php echo $language['notice_02']; ?>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                   <b><?php echo $language['reset_time_interval']; ?>：<?php echo $data['pool_tax_interval'] . $language['minute']; ?></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b style="color: red;"><?php echo $language['next_time_interval']; ?>：<span id="minutes"><?php echo $cur['minutes']; ?> <?php echo $cur['reset_time']; ?></span></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <?php echo $language['notice_03']; ?>
                </div>
            </div>
        </div>
    </fieldset>
    <fieldset class="layui-elem-field">
        <legend><h3><b><?php echo $language['jackpot']; ?></b></h3></legend>
        <div class="layui-field-box">
            <div class="layui-form-item" style="margin: 10px 0 10px 0px;">
                <div class="layui-input-block">
                    <?php echo $language['jackpot_tips']; ?>
                    <button class="layui-btn change-coin" style="margin-left: 20px;width: 100px;" type="sub" id="jackpot-setting"><?php echo $language['btn_setting']; ?></button>
                    <button class="layui-btn layui-btn-primary" id="jp-history" style="width: 180px;margin-left: 20px;"><?php echo $language['jackpot_btn_record']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['jackpot_setting']; ?>：<?php echo $data['pool_jp_outline']; ?></b>
                </div>
            </div>
            <div class="layui-form-item" style="margin: 10px 0 10px 0px;">
                <div class="layui-input-block">
                    <b style="color: red;"><?php echo $language['jackpot_cur_pos']; ?>：<span id="jackpot"><?php echo $cur['jackpot']; ?> (<?php echo $cur['jackpot_ratio']; ?>)</span></b><button class="layui-btn btn-empty" type="3" style="width: 100px;margin-left: 20px;"><?php echo $language['btn_empty_normal']; ?></button>
                </div>
            </div>
        </div>
    </fieldset>
    <fieldset class="layui-elem-field">
        <legend><h3><b><?php echo $language['packet']; ?></b></h3></legend>
        <div class="layui-field-box">
            <div class="layui-form-item" style="margin: 10px 0 10px 0px;">
                <div class="layui-input-block">
                    <?php echo $language['packet_tips']; ?>
                    <button class="layui-btn change-coin" style="margin-left: 20px;width: 100px;" type="sub" id="packet-setting"><?php echo $language['btn_setting']; ?></button>
                    <button class="layui-btn layui-btn-primary" id="rb-history" style="margin-left: 20px;width: 150px;"><?php echo $language['packet_btn_record']; ?></button>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <b style="color: red;"><?php echo $language['packet_total_award']; ?>：<span id="redbag"><?php echo $cur['redbag']; ?></span></b>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <b><?php echo $language['packet_status']; ?>：<?php if ($data['pool_rb_isopen'] == 1) : ?><?php echo $language['packet_status_open']; ?><?php else : ?><?php echo $language['packet_status_close']; ?><?php endif; ?></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['packet_max']; ?>：<?php echo $data['pool_rb_limitup']; ?></b>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <b><?php echo $language['packet_min']; ?>：<?php echo $data['pool_rb_limitdown']; ?></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['packet_send_condition']; ?>：<?php echo $data['pool_rb_coinless']; ?><?php echo $language['packet_send_condition_tips']; ?></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['packet_seven_coin']; ?>：<?php echo $data['pool_rb_7daycoindiff']; ?></b>
                </div>
            </div>
        </div>
    </fieldset>
    <fieldset class="layui-elem-field">
        <legend><h3><b><?php echo $language['vip']; ?></b></h3></legend>
        <div class="layui-field-box">
            <div class="layui-form-item" style="margin: 10px 0 10px 0px;">
                <div class="layui-input-block">
                    <?php echo $language['vip_tips']; ?><button class="layui-btn change-coin" style="margin-left: 20px;width: 100px;" type="sub" id="vip-setting"><?php echo $language['btn_setting']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <b><?php echo $language['vip_standard']; ?>：<?php echo $data['player_vipbaseline']; ?></b>
                </div>
            </div>
        </div>
    </fieldset>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'user_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$;
            $(document).on('click', '#consume-coin-setting', function() {
                layer.open({
                    type: 2,
                    title: language.consume_coin_title,
                    content: "/game/consumeCoin",
                    maxmin: !0,
                    area: ['100%', '100%'],
                    btn:[]
                })
            });
            $(document).on('click', '#jackpot-setting', function() {
                layer.open({
                    type: 2,
                    title: language.jackpot_title,
                    content: "/game/jackpot",
                    maxmin: !0,
                    area: ['100%', '100%'],
                    btn:[]
                })
            });
            $(document).on('click', '#packet-setting', function() {
                layer.open({
                    type: 2,
                    title: language.packet,
                    content: "/game/packet",
                    maxmin: !0,
                    area: ['100%', '100%'],
                    btn:[]
                })
            });
            $(document).on('click', '#vip-setting', function() {
                layer.open({
                    type: 2,
                    title: language.vip,
                    content: "/game/vip",
                    maxmin: !0,
                    area: ['100%', '100%'],
                    btn:[]
                })
            });
            $(document).on('click', '#jp-history', function() {
                layer.open({
                    type: 2,
                    title: language.jackpot_btn_record,
                    content: "/game/jpHistory",
                    maxmin: !0,
                    area: ['100%', '100%'],
                    btn:[]
                })
            });
            $(document).on('click', '#rb-history', function() {
                layer.open({
                    type: 2,
                    title: language.packet_btn_record,
                    content: "/game/rbHistory",
                    maxmin: !0,
                    area: ['100%', '100%'],
                    btn:[]
                })
            });
            $(document).on('click', '.btn-commission', function() {
                $('.btn-commission').removeClass('layui-btn-primary').removeClass('layui-btn-normal').addClass('layui-btn-primary');
                $(this).removeClass('layui-btn-primary').addClass('layui-btn-normal');
                $.ajax({
                    url: "/game/commission",
                    dataType: 'json',
                    type: 'POST',
                    data: {type: $(this).attr('type')},
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            $('#commission').html(result.data.commission);
                        }
                    }
                });
            })

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.window.location.reload();
                parent.layer.close(index);
            });

            $(document).on('click', '.btn-empty', function() {
                var type = $(this).attr('type');
                layer.confirm("<?php echo $language['empty_normal_tips']; ?>", {title:'<?php echo $language['btn_empty_normal']; ?>', btn: ['<?php echo $language['btn_sure']; ?>','<?php echo $language['btn_cancel']; ?>']}, function(index, layero) {
                    $.ajax({
                        url: "/game/emptyPool",
                        dataType: 'json',
                        type: 'POST',
                        data: {type: type},
                        success:function(result) {
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.close(index);
                                getCurData();
                            }
                        }
                    });
                });
            })

            window.setInterval(function() {
                getCurData();
            }, 10000);

            function getCurData() {
                $.ajax({
                    url: "/game/curData",
                    dataType: 'json',
                    type: 'POST',
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            $('#cur_tax').html(result.data.cur.cur_tax + ' (' + result.data.cur.tax_ratio + ')');
                            $('#minutes').html(result.data.cur.minutes + ' ' + result.data.cur.reset_time);
                            $('#jackpot').html(result.data.cur.jackpot + ' (' + result.data.cur.jackpot_ratio + ')');
                            $('#redbag').html(result.data.cur.redbag);
                            $('#cur_normal').html(result.data.cur.normal);
                        }
                    }
                });
            }
        });
</script>
</body>

</html>