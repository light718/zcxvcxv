<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['bigbang_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 130px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 400px;padding: 0px 0px 9px 15px;color: #858585;">
                    <?php echo $language['bigbang_title_tips']; ?>
                </label>
                <div class="layui-input-inline" style="line-height: 25px;">
                    <button style="width: 150px;height: 25px;line-height: 25px;" class="layui-btn layuiadmin-btn-list" lay-submit lay-filter="btn-bigbang-setting" id="btn-bigbang-setting">
                        <?php echo $language['btn_setting']; ?>
                    </button>
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b><?php echo $language['bigbang_today_total_award']; ?>：<?php echo $acc['today']; ?></b>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <b><?php echo $language['bigbang_seven_day_total_award']; ?>：<?php echo $acc['seven_day']; ?></b>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <b><?php echo $language['bigbang_three_month_total_award']; ?>：<?php echo $acc['three_month']; ?></b>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_start_date']; ?>：</b></label>
                <div class="layui-input-inline" style="width: 300px;">
                    <input type="text" class="layui-input" name="start_time" id="start_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['today']; ?>">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_end_date']; ?>：</b></label>
                <div class="layui-input-inline" style="width: 300px;">
                    <input type="text" class="layui-input" name="end_time" id="end_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['today']; ?>">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-radius date-time" start_time="<?php echo $date_time['today']; ?>" end_time="<?php echo $date_time['today']; ?>"><?php echo $language['search_today']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start_time="<?php echo $date_time['yesterday']; ?>" end_time="<?php echo $date_time['yesterday']; ?>"><?php echo $language['search_yesterday']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start_time="<?php echo $date_time['week']; ?>" end_time="<?php echo $date_time['today']; ?>"><?php echo $language['search_recent_seven_day']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start_time="<?php echo $date_time['month']; ?>" end_time="<?php echo $date_time['today']; ?>"><?php echo $language['search_month']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start_time="<?php echo $date_time['pre_week_start']; ?>" end_time="<?php echo $date_time['pre_week_end']; ?>"><?php echo $language['search_pre_week']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['username']; ?>：</b></label>
                <div class="layui-input-inline" style="width: 300px;">
                    <input type="text" class="layui-input" name="keywords" id="keywords" placeholder="" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list" lay-submit lay-filter="bigbang-record-list-search" id="bigbang-record-list-search">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
                <div class="layui-inline" style="float: right;">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list lottery">
                        <?php echo $language['btn_lottery']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="bigbang-record-list" lay-filter="bigbang-record-list">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'game_list', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form,
                laydate = layui.laydate;

            <?php if ($lang == 'english') : ?>
            laydate.render({
                elem: '#start_time'
                ,lang: 'en'
            });
            laydate.render({
                elem: '#end_time'
                ,lang: 'en'
            });
            <?php else : ?>
            laydate.render({
                elem: '#start_time'
            });
            laydate.render({
                elem: '#end_time'
            });
            <?php endif; ?>

            //监听搜索
            form.on('submit(bigbang-record-list-search)',
                function(data) {
                    var field = data.field;

                    //执行重载
                    table.reload('bigbang-record-list', {
                        url: "/game/bigbangRecordLists",
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });
                });

            var $ = layui.$;
            $(document).on('click', '.date-time', function() {
                $(this).removeClass('layui-btn-warm');
                $(this).parent().siblings().find('.date-time').removeClass('layui-btn-warm').addClass('layui-btn-warm');
                $('#start_time').val($(this).attr('start_time'));
                $('#end_time').val($(this).attr('end_time'));
            });
            $(document).on('click', '#btn-bigbang-setting', function() {
                layer.open({
                    type: 2,
                    title: language.bigbang_setting_title,
                    content: "/game/bigbangSetting",
                    maxmin: true,
                    area: ['100%', '100%'],
                    btn:[]
                });
            });

            $('#bigbang-record-list-search').click();

            $(document).on('click', '.lottery', function() {
                layer.open({
                    type: 2,
                    title: language.bigbang_jackpot_title,
                    content: "/game/addBigbang",
                    maxmin: true,
                    area: ['100%', '100%'],
                    btn:[]
                });
            });
        });
</script>
</body>

</html>