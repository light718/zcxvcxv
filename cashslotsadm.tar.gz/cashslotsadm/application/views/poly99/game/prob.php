<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link href="/backend/lib/extend/jsoneditor/jsoneditor.css" rel="stylesheet" type="text/css">
    <script src="/backend/lib/extend/jsoneditor/jsoneditor.js?v=1.62"></script>
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        #jsoneditor {
            /*width: 800px;*/
        }
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-inline" style="width: 300px;">
                    <select name="game" lay-filter="game" id="game">
                        <option value=""><?php echo $language['select_game']; ?></option>
                    </select>
                </div>
                <div class="layui-input-inline" style="width: 100px;">
                    <select name="type" lay-filter="type" id="type">
                        <option value="">Select</option>
                    </select>
                </div>
                <div class="layui-input-inline">
                    <button style="width: 150px;margin-left: 50px;" class="layui-btn" lay-submit="" lay-filter="setting" id="setting"><?php echo $language['btn_save']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <div id="jsoneditor"></div>
            </div>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var type = JSON.parse('<?php echo json_encode($prob); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'user_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$;

            var editor = new JSONEditor(document.getElementById('jsoneditor'));

            $.ajax({
                url: '/game/gameLists',
                dataType: 'json',
                type: 'POST',
                success:function(result) {
                    if (result.errcode == 1001) {
                        parent.window.location.reload();
                    } else if (result.errcode == 0) {
                        $.each(result.data.game_list, function(i, v) {
                            $('#game').append('<option value="'+v.id+'">'+v.name+'</option>')
                        })
                        form.render('select');
                    }
                }
            });
            var select_game_id = 0;
            form.on('select(game)', function(data) {
                select_game_id = data.value;
                var strHtml = '<option value="">Select</option>';    
                $.each(type, function(i, v) {
                    strHtml += '<option value="'+i+'">'+v+'</option>';
                })
                $('#type').html(strHtml);
                form.render('select');
                form.on('select(type)', function(data) {
                    layerIndex = layer.load(0, {offset:  ['300px', '400px'],shade: false});
                    $.ajax({
                        url: '/game/getProb',
                        dataType: 'json',
                        data: {id: select_game_id, type: data.value},
                        type: 'POST',
                        success:function(result) {
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                editor.setText(result.data.prob);
                                editor.expandAll();
                                layer.close(layerIndex);
                            }
                        }
                    });
                });
            });

            form.on('submit(setting)', function(data) {
                var game_id = data.field.game;
                var type = data.field.type;
                var prob = editor.getText();
                if (!game_id || prob == '{}') {
                    return false;
                }
                layerIndex = layer.load(0, {offset:  ['300px', '400px'],shade: false});
                $('#setting').prop('disabled', true);
                $.ajax({
                    url: '/game/prob',
                    dataType: 'json',
                    data: {id: game_id, prob: prob, type: type},
                    type: 'POST',
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            layer.msg(result.errmsg, {
                                    offset: ['300px', '400px'],
                                    icon: 1,
                                    time: 1000
                                });
                        } else {
                            layer.msg(result.errmsg);
                        }
                        layer.close(layerIndex);
                        $('#setting').prop('disabled', false);
                    }
                });
                return false;
            });
        });
</script>
</body>

</html>