<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['marquee_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
            /*line-height: 56px;*/
            /*font-size:14px;*/
            /*padding:0 5px;*/
            /*height:auto;*/
            /*overflow:visible;*/
            /*text-overflow:inherit;*/
            /*white-space:normal;*/
            /*word-break: break-all;*/
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <label class="layui-form-label" style="width: 100%;"><?php echo $language['marquee_title_tips']; ?></label>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list layui-btn-primary status-search" status="all">
                        <?php echo $language['marquee_btn_all']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list layui-btn-primary status-search" status="open">
                        <?php echo $language['marquee_btn_open']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list layui-btn-primary status-search" status="cancel">
                        <?php echo $language['marquee_btn_cancel']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list" data-type="add">
                        <?php echo $language['marquee_btn_add']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="marquee-list" lay-filter="marquee-list">
            </table>
            <script type="text/html" id="toolbar-marquee-list-search">
                <a class="layui-btn layui-btn-xs" lay-event="marquee_detail"><?php echo $language['marquee_btn_detail']; ?></a>
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'game_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$,
                active = {
                    add: function() {
                        layer.open({
                            type: 2,
                            title: "<?php echo $language['marquee_add_title']; ?>",
                            content: '/game/addMarquee',
                            maxmin: true,
                            area: ['100%', '100%'],
                            btn:[]
                        });
                    },
                };

            $('.status-search').on('click', function() {
                var status = $(this).attr('status');
                table.reload('marquee-list', {
                    where: {status: status, page: 1},
                    page: {
                        curr: 1,
                        layout: ['prev', 'page', 'next'],
                        theme: '#1E9FFF',
                        groups: 9,
                    },
                });
            })

            $('.layui-btn.layuiadmin-btn-list').on('click',
                function() {
                    var type = $(this).data('type');
                    active[type] ? active[type].call(this) : '';
                });

        });
</script>
</body>

</html>