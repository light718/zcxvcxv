<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['bigbang_setting_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 0px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body>
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">
            <?php echo $language['bigbang_setting_title_tips']; ?>
        </label>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
            <?php echo $language['bigbang_setting_base_value_tips']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['bigbang_setting_base_value']; ?>：</b>
        </label>
        <div class="layui-input-inline" style="width: 240px;">
            <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');" name="bb_disbaseline" id="bb_disbaseline" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['bb_disbaseline']; ?>">
        </div>
        <div class="layui-input-inline" style="width:50px;padding: 9px 0px;">
            <b>+- 50%</b>
        </div>
    </div>


    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
            <?php echo $language['bigbang_setting_change_value_tips_01']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['bigbang_setting_change_value']; ?>：</b>
        </label>
        <div class="layui-input-inline" style="width: 240px;">
            <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="this.value=this.value.replace(/[^0-9]+/,'');" name="bb_wave_val" id="bb_wave_val" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['bb_wave_val']; ?>">
        </div>
        <div class="layui-input-inline" style="width:50px;padding: 9px 0px;">
            <b>+- 50%</b>
        </div>
    </div>


    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;color: #858585;">
            <?php echo $language['bigbang_setting_decline_tips']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['bigbang_setting_decline_time_interval']; ?>：</b>
        </label>
        <div class="layui-input-inline" style="width: 240px;">
            <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="this.value=this.value.replace(/[^0-9]+/,'');" name="bb_valdown_time" id="bb_valdown_time" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['bb_valdown_time']; ?>">
        </div>
        <div class="layui-input-inline" style="width: 100px;padding: 9px 0px;">
            <b><?php echo $language['minute']; ?> +- 50%</b>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['bigbang_setting_decline_ratio']; ?>：</b>
        </label>
        <div class="layui-input-inline" style="width: 240px;">
            <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="this.value=this.value.replace(/[^0-9]+/,'');" name="bb_valdown_parl" id="bb_valdown_parl" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['bb_valdown_parl']; ?>">
        </div>
        <div class="layui-input-inline" style="width: 70px;padding: 9px 0px;">
            <b>% +- 50%</b>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 15px 0px 9px 15px;color: red;">
            <b><?php echo $language['bigbang_setting_notice']; ?></b>
        </label>
    </div>
    <div class="layui-form-item" style="margin-top: 20px;">
        <div class="layui-input-block">
            <button style="width: 100px;" class="layui-btn layui-btn-danger" lay-submit="" lay-filter="setting" id="setting"><?php echo $language['btn_setting_02']; ?></button>
            <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js">
</script>
<script>
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;

            //监听提交
            form.on('submit(setting)',
                function(data) {
                    layerIndex = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#setting').prop('disabled', true);
                    $.ajax({
                        url: '/game/bigbangSetting',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            layer.close(layerIndex);
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        offset: ['190px', "250px"],
                                        icon: 1,
                                        time: 1000
                                    },
                                    function() {
                                        var index = parent.layer.getFrameIndex(window.name);
                                        parent.window.location.reload();
                                        parent.layer.close(index);
                                    });
                            } else {
                                layer.close(layerIndex);
                                layer.msg(result.errmsg);
                                $('#setting').prop('disabled', false);
                            }
                        }
                    });
                });
            $(document).on('click','.close',function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.window.location.reload();
                parent.layer.close(index);
            });
        })
</script>
</body>
</html>