<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['game_switch_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
    <div class="layui-card-body" pad15="">
        <div class="layui-form" lay-filter="">
            <div class="layui-form-item">
                <label class="layui-form-label"><?php echo $language['game_switch_title']; ?></label>
                <div class="layui-input-block">
                    <div class="layui-inline">
                        <input type="radio" style="margin: 0 10px 0 0;" name="game_switch" value="1" title="<?php echo $language['game_switch_status_normal']; ?>" <?php if ($data['game_switch'] == 1) : ?>checked=""<?php endif; ?>>
                    </div>
                    <div class="layui-inline">
                        <input type="radio" style="margin: 0 10px 0 0;" name="game_switch" value="0" title="<?php echo $language['game_switch_status_off']; ?>" <?php if ($data['game_switch'] == 0) : ?>checked=""<?php endif; ?>>
                    </div>
                    <div class="layui-inline" style="margin-top: 3px;">
                        <b><?php echo $language['game_switch_total_online']; ?>：<?php echo $all_nums; ?></b>
                    </div>
                </div>
            </div>
            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label"><?php echo $language['game_switch_uid_whitelist']; ?></label>
                <div class="layui-input-block">
                    <textarea name="game_swl" placeholder="<?php echo $language['game_switch_tips']; ?>" class="layui-textarea"><?php echo $data['game_swl']; ?></textarea>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button style="width: 100px;" class="layui-btn layui-btn-danger" lay-submit="" lay-filter="setting" id="setting"><?php echo $language['btn_setting_02']; ?></button>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'table'],
        function() {
            var form = layui.form;

            var $ = layui.$;

            form.on('submit(setting)', function(data) {
                var field = data.field;
                var msg = "<?php echo $language['game_switch_tips_02']; ?>";
                if (field.game_switch == 1) {
                    msg = "<?php echo $language['game_switch_tips_01']; ?>";
                }
                layer.confirm(msg, {title:'<?php echo $language['game_switch_title']; ?>', btn: ['<?php echo $language['btn_sure']; ?>','<?php echo $language['btn_cancel']; ?>']}, function(e) {
                    layerIndex = layer.load(0, {shade: false});
                    $('#setting').prop('disabled', true);
                    $.ajax({
                        url: '/game/switch',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        icon: 1,
                                        time: 1000
                                    });
                            } else {
                                layer.msg(result.errmsg, {
                                        icon: 1,
                                        time: 1000
                                    });
                            }
                            layer.close(layerIndex);
                            $('#setting').prop('disabled', false);
                        }
                    });
                    return false;
                })
            });
        });
</script>
</body>

</html>