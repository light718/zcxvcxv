<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['coin_record_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b><?php echo $language['proxy_username']; ?>：<?php echo $username; ?></b>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <b><?php echo $language['proxy_nickname']; ?>：<?php echo $nickname; ?></b>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_start_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="start_time" id="start_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['week']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_end_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="end_time" id="end_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['today']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" data="<?php echo $date_time['today']; ?>"><?php echo $language['search_today']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" data="<?php echo $date_time['yesterday']; ?>"><?php echo $language['search_yesterday']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-radius date-time" data="<?php echo $date_time['week']; ?>"><?php echo $language['search_recent_seven_day']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" data="<?php echo $date_time['month']; ?>"><?php echo $language['search_month']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list" lay-submit lay-filter="coin-record-list-search" id="coin-record-list-search" style="width: 100px;">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-primary layuiadmin-btn-list close" style="width: 100px;">
                        <?php echo $language['btn_close']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <div class="layui-row" style="border: 1px solid rgb(230, 230, 230);text-align: center;height: 30px;line-height: 30px;width: 200px;margin-bottom: 10px;">
                <b><?php echo $language['coin_record_total_coin']; ?>：</b><span id="cointotal">0.00</span>
            </div>
            <table id="coin-record-list" lay-filter="coin-record-list">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form,
                laydate = layui.laydate;

            <?php if ($lang == 'english') : ?>
            laydate.render({
                elem: '#start_time'
                ,lang: 'en'
            });
            laydate.render({
                elem: '#end_time'
                ,lang: 'en'
            });
            <?php else : ?>
            laydate.render({
                elem: '#start_time'
            });
            laydate.render({
                elem: '#end_time'
            });
            <?php endif; ?>

            //监听搜索
            form.on('submit(coin-record-list-search)',
                function(data) {
                    var field = data.field;

                    //执行重载
                    table.reload('coin-record-list', {
                        url: "/account/coinRecordLists?username=<?php echo $username; ?>",
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });
                });

            var $ = layui.$;
            $(document).on('click', '.date-time', function() {
                $(this).removeClass('layui-btn-warm');
                $(this).parent().siblings().find('.date-time').removeClass('layui-btn-warm').addClass('layui-btn-warm');
                $('#start_time').val($(this).attr('data'));
                $('#end_time').val("<?php echo $date_time['today']; ?>");
            });

            $('#coin-record-list-search').click();

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                parent.layui.table.reload('proxy-list'); //重载表格
                parent.layer.close(index); //再执行关闭
            });
        });
</script>
</body>