<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['level_search_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
            /*line-height: 56px;*/
            /*font-size:14px;*/
            /*padding:0 5px;*/
            /*height:auto;*/
            /*overflow:visible;*/
            /*text-overflow:inherit;*/
            /*white-space:normal;*/
            /*word-break: break-all;*/
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <label class="layui-form-label" style="width: 100%;"><?php echo $language['level_search_title_tips']; ?></label>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=1" class="layui-btn <?php if ($type == 1) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>">
                        <?php echo $language['level_search_btn_condition_01']; ?>
                    </a>
                </div>
                <div class="layui-inline">
                    <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=2" class="layui-btn <?php if ($type == 2) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>">
                        <?php echo $language['level_search_btn_condition_02']; ?>
                    </a>
                </div>
                <div class="layui-inline">
                    <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=3" class="layui-btn <?php if ($type == 3) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>">
                        <?php echo $language['level_search_btn_condition_03']; ?>
                    </a>
                </div>
                <div class="layui-inline">
                    <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=4" class="layui-btn <?php if ($type == 4) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>">
                        <?php echo $language['level_search_btn_condition_04']; ?>
                    </a>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table lay-filter="cur-data">
                <thead>
                    <tr>
                        <th lay-data="{field:'username', minWidth: 150, align: 'center'}"><?php echo $language['username']; ?></th>
                        <th lay-data="{field:'nickname', minWidth: 150, align: 'center'}"><?php echo $language['nickname']; ?></th>
                        <th lay-data="{field:'agent_add_coin', minWidth: 200, align: 'center'}"><?php echo $language['table_column_coin']; ?></th>
                        <th lay-data="{field:'agent_sub_coin', minWidth: 200, align: 'center'}"><?php echo $language['table_column_au']; ?></th>
                        <th lay-data="{field:'player_add_coin', minWidth: 200, align: 'center'}"><?php echo $language['table_column_bets']; ?></th>
                        <th lay-data="{field:'player_sub_coin', minWidth: 200, align: 'center'}"><?php echo $language['table_column_win_coin']; ?></th>
                        <th lay-data="{field:'parent', minWidth: 100, align: 'center', fixed: 'right'}"><?php echo $language['table_column_handle']; ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($cur_data) : ?>
                    <tr>
                        <td><?php echo $cur_data['username']; ?></td>
                        <td><?php echo $cur_data['nickname']; ?></td>
                        <td><?php echo $cur_data['coin']; ?></td>
                        <td><?php echo $cur_data['au']; ?></td>
                        <td><?php echo $cur_data['bets']; ?></td>
                        <td><?php echo $cur_data['win']; ?></td>
                        <td>
                            <a href="/account/levelSearch?account_id=<?php echo $cur_data['parent']; ?>&type=<?php echo $type; ?>" class="layui-btn layui-btn-xs <?php if ($cur_data['parent'] == 0) : ?>layui-btn-disabled<?php endif; ?>">
                                <?php echo $language['level_search_btn_parent']; ?>
                            </a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="layui-card-body">
            <div class="layui-row" style="margin-bottom: 10px;border: 1px solid rgb(230, 230, 230);text-align: center;height: 30px;line-height: 30px;width: 200px;">
                <b><?php echo $language['direct_agent']; ?>：</b>
            </div>
            <table id="level-search-list" lay-filter="level-search-list">
            </table>
            <script type="text/html" id="toolbar-level-search-handle">
                {{#  if(d.id != "<?php echo $cur_data['id']; ?>") { }}
                <a class="layui-btn layui-btn-xs" lay-event="expand"><?php echo $language['level_search_btn_expand']; ?></a>
                {{# } else { }}
                <a class="layui-btn layui-btn-xs layui-btn-disabled"><?php echo $language['level_search_btn_expand']; ?></a>
                {{# } }}
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var type = "<?php echo $type; ?>";
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.3'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$;

            table.init('cur-data', {
            });

            table.reload('level-search-list', {
                url: "/account/levelSearch?account_id=<?php echo $cur_data['id']; ?>&type=<?php echo $type; ?>",
                page: {
                    curr: 1,
                    layout: ['prev', 'page', 'next'],
                    theme: '#1E9FFF',
                    groups: 9,
                },
            });

            $('.layui-btn.layuiadmin-btn-list').on('click',
                function() {
                    var type = $(this).data('type');
                    active[type] ? active[type].call(this) : '';
                });

        });
</script>
</body>

</html>