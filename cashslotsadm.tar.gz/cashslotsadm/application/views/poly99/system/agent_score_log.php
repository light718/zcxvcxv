<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['agent_score_log_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 130px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" name="keywords" placeholder="ID/昵称" autocomplete="new-password" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <button style="width: 100px;margin-right: 100px;" class="layui-btn layuiadmin-btn-list" lay-submit="" lay-filter="agent-score-log-search" id="agent-score-log-search">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="agent-score-log" lay-filter="agent-score-log">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/system/agent_score_log.js?v=1.212"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
</script>
</body>
</html>