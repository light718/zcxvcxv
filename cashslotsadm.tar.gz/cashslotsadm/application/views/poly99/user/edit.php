<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['edit_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-input-inline {
            width: 250px !important;
        }
    </style>
</head>

<body>
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;">
                <b><?php echo $language['username']; ?>：<?php echo formatPlayerUsername($player['account_pid']); ?></b>
                <input type="hidden" name="username" value="<?php echo $player['account_pid']; ?>">
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['password']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="text" name="password" style="width: 200px;" id="password" placeholder="" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['nickname']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="text" name="nickname" style="width: 200px;" value="<?php echo $player['account_nickname']; ?>" id="nickname" placeholder="" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item" style="text-align: center;margin-top: 20px;">
            <div class="layui-input-block">
                <button style="width: 100px;" class="layui-btn" lay-submit="" lay-filter="save" id="save"><?php echo $language['btn_edit']; ?></button>
                <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
            </div>
        </div>
</div>


<script src="/backend/layui/layui.js">
</script>
<script>
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;

            //监听提交
            form.on('submit(save)',
                function(data) {
                    var index = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#save').prop('disabled', true);
                    $.ajax({
                        url: '/user/edit',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            layer.close(index);
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        offset: '30px',
                                        icon: 1,
                                        time: 1000
                                    },
                                    function() {
                                        var parentLayer = parent.layer.getFrameIndex(window.name);
                                        parent.layui.table.reload('player-list');
                                        parent.layer.close(parentLayer);
                                    });
                            } else {
                                layer.msg(result.errmsg);
                                $('#save').prop('disabled', false);
                            }
                        }
                    });
                });
            $(document).on('click','.close',function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.layui.table.reload('player-list');
                parent.layer.close(index);
            });
        })
</script>
</body>
</html>