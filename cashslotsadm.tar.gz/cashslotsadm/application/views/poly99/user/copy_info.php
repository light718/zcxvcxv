<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['copy_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b><?php echo $language['coin_record_username']; ?>：</b><?php echo $username; ?>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <b><?php echo $language['coin_record_nickname']; ?>：</b><?php echo $nickname; ?>
                </label>
            </div>
            <div class="layui-form-item">
                <div class="layui-row">
                    <div class="layui-col-xs10 layui-col-sm6 layui-col-md2">
                        <div class="layui-row">
                            <div class="layui-col-xs12">
                                <label class="layui-form-label" style="width: 150px;padding: 0px 0px 2px 15px;">
                                    <b><?php echo $language['coin_record_user_status']; ?>：</b>
                                    <span id="status">
                                    </span>
                                </label>
                            </div>
                        </div>
                        <div class="layui-row">
                            <div class="layui-col-xs12">
                                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                                    <b><?php echo $language['coin_record_coin']; ?>：</b>
                                    <span id="coin"></span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-xs2 layui-col-sm6 layui-col-md10">
                        <a id="refresh" style="display: inline-block;width: 30px;margin-right: 10px;"><i class="layui-icon layui-icon-refresh-3" style="font-size: 28px; width:30px; height:30px;color: #1E9FFF;"></i></a>
                    </div>
                </div>
            </div>
            <div class="layui-row" style="margin-bottom: 10px;padding-left: 15px;">
                <div class="layui-row" style="margin-bottom: 10px;"><b><?php echo $language['copy_notice01']; ?></b>：<button class="layui-btn copy" data-clipboard-text="<?php echo $language['copy_notice02']; ?>" style="margin-left: 10px;"><?php echo $language['btn_copy']; ?></button></div>
                <div class="layui-row">
                    <blockquote class="layui-elem-quote layui-quote-nm">
                        <?php echo $language['copy_notice02']; ?>
                    </blockquote>
                </div>
                <div class="layui-row">
                    <b><?php echo $language['copy_notice03']; ?></b>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button class="layui-btn layui-btn-primary" style="width: 100px;" id="close"><?php echo $language['add_btn_close']; ?></button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="/backend/layui/layui.js"></script>
<script src="/backend/lib/extend/clipboard.min.js"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index'],
        function() {
            var $ = layui.$;
            $(document).on('click','#close',function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                parent.layer.close(index); //再执行关闭
            });

            var clipboard = new ClipboardJS('.copy');
            clipboard.on('success', function(e) {
                var that = $('.copy');
                layer.tips(language.copy_success, that, {
                    tips: [2, '#FF5722'], //还可配置颜色
                    time: 1000
                });
            });

            $(document).on('click', '#refresh', function() {
                $(this).prop('disabled', true);
                var index = layer.load(1, {
                    shade: [0.1,'#fff'], //0.1透明度的白色背景
                    offset: ['90px', "150px"]
                });
                $.ajax({
                    url: "/user/getUserInfo",
                    dataType: 'json',
                    type: 'POST',
                    data: {username: "<?php echo $username; ?>"},
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            if (result.data.player.player_online == 1) {
                                $('#status').html("<?php echo $language['coin_record_status_online']; ?>");
                            } else {
                                $('#status').html("<?php echo $language['coin_record_status_offline']; ?>");
                            }
                            $('#coin').html(result.data.player.player_coin);
                            layer.close(index);
                            $('#refresh').prop('disabled', false);
                        }
                    }
                });
            });
            $('#refresh').click();
        });
</script>
</body>
</html>