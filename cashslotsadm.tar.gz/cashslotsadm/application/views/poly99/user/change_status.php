<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['status_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-row {
            color: #333;
            margin: 20px 0 20px 20px;
        }
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-row">
            <div class="layui-col-xs12">
                <b><?php echo $language['coin_record_username']; ?>：</b><?php echo $username; ?>
            </div>
            <div class="layui-col-xs12">
                <b><?php echo $language['coin_record_nickname']; ?>：</b><?php echo $nickname; ?>
            </div>
        </div>
        <div class="layui-row">
            <div class="layui-col-xs10 layui-col-sm6 layui-col-md2">
                <div class="layui-col-xs12">
                    <b><?php echo $language['coin_record_user_status']; ?>：</b>
                    <span id="status">
                    <?php if ($status == 1) : ?>
                        <?php echo $language['coin_record_status_online']; ?>
                    <?php else : ?>
                        <?php echo $language['coin_record_status_offline']; ?>
                    <?php endif; ?>
                    </span>
                </div>
                <div class="layui-col-xs12">
                    <b><?php echo $language['coin_record_coin']; ?>：</b>
                    <span id="coin"><?php echo $coin; ?></span>
                </div>
            </div>
            <div class="layui-col-xs2 layui-col-sm6 layui-col-md10">
                <a id="refresh" style="display: inline-block;width: 30px;height: 30px;"><i class="layui-icon layui-icon-refresh-3" style="font-size: 28px; width:30px; height:30px;color: #1E9FFF;"></i></a>
            </div>
        </div>
        <?php if ($status == 0) : ?>
            <div class="layui-row">
                <b><?php echo $language['status_notice01']; ?></b>
            </div>
            <div class="layui-row">
                <button class="layui-btn change_status layui-btn-normal" type="offline"><?php echo $language['status_btn_offline']; ?></button>
            </div>
            <div class="layui-row">
                <b><?php echo $language['status_notice02']; ?></b>
            </div>
            <div class="layui-row">
                <button class="layui-btn layui-btn-danger change_status" type="forbidden"><?php echo $language['status_btn_forbidden']; ?></button>
            </div>
        <?php else : ?>
            <div class="layui-row">
                <b><?php echo $language['status_notice03']; ?></b>
            </div>
            <div class="layui-row">
                <button class="layui-btn change_status" type="normal"><?php echo $language['status_btn_normal']; ?></button>
            </div>
        <?php endif; ?>
        <div class="layui-row">
            <button class="layui-btn layui-btn-primary close"><?php echo $language['status_btn_cancel']; ?></button>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'user_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$;
            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.layer.close(index);
            });

            $(document).on('click', '.change_status', function() {
                var obj = $(this);
                $(obj).prop('disabled', true);
                var type = $(this).attr('type');
                var index = layer.load(0, {shade: false});
                $.ajax({
                    url: "/user/changeStatus",
                    dataType: 'json',
                    type: 'POST',
                    data: {username: "<?php echo $username; ?>", type: type},
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            window.location.reload();
                        } else {
                            layer.close(index);
                            layer.msg(result.errmsg);
                            $(obj).prop('disabled', false);
                        }
                    }
                });
            });

            $(document).on('click', '#refresh', function() {
                $(this).prop('disabled', true);
                var index = layer.load(1, {
                    shade: [0.1,'#fff'], //0.1透明度的白色背景
                    offset: ['90px', "150px"]
                });
                $.ajax({
                    url: "/user/getUserInfo",
                    dataType: 'json',
                    type: 'POST',
                    data: {username: "<?php echo $username; ?>"},
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            if (result.data.player.player_online == 1) {
                                $('#status').html("<?php echo $language['coin_record_status_online']; ?>");
                            } else {
                                $('#status').html("<?php echo $language['coin_record_status_offline']; ?>");
                            }
                            $('#coin').html(result.data.player.player_coin);
                            layer.close(index);
                            $('#refresh').prop('disabled', false);
                        }
                    }
                });
            });
        });
</script>
</body>

</html>