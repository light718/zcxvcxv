<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['add_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/poly.css" media="all">
    <style>
        .layui-form-label {
            width: 200px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 230px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body>
    <input type="text" style="display: none;">
    <input type="password" style="display: none;">
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">
            <?php echo $language['add_sub_title']; ?>
        </label>
    </div>
    <div class="add">
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;color: #858585;">
                <?php echo $language['user_number_tips01']; ?>
            </label>
        </div>
<!--        <div class="layui-form-item">-->
<!--            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">-->
<!--                --><?php //echo $language['user_number_tips02']; ?>
<!--            </label>-->
<!--        </div>-->
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['user_number']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="text" name="number" id="number" placeholder="" autocomplete="new-password" class="layui-input">
            </div>
        </div>
        <!-- <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
                <?php echo $language['password_tips']; ?>
            </label>
        </div> -->
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['password']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="password" name="password" id="password" placeholder="" autocomplete="new-password" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
                <?php echo $language['nickname_tips01']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: red;">
                <?php echo $language['nickname_tips02']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['nickname']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="text" name="nickname" id="nickname" placeholder="" autocomplete="new-password" class="layui-input">
            </div>
        </div>
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-header"></div>
                <div class="layui-card-body">
                    <?php echo $language['add_notice01']; ?><br>
                    <?php echo $language['add_notice02']; ?><br>
                    <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<span style="color: red;"><?php echo $language['add_notice03']; ?></span><br>
                    <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<span style="color: red;"><?php echo $language['add_notice04']; ?></span><br>
                    <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<?php echo $language['add_notice05']; ?><br>
                    <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<?php echo $language['add_notice06']; ?>
                </div>
            </div>
        </div>
        <div class="layui-form-item" style="margin-top: 20px;">
            <div class="layui-input-block">
                <button style="width: 100px;" class="layui-btn" lay-submit="" lay-filter="add-user" id="add-user"><?php echo $language['add_btn_save']; ?></button>
                <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['add_btn_close']; ?></button>
            </div>
        </div>
    </div>
    <div class="success" style="display: none;">
        <div class="layui-card">
            <div class="layui-card-header" style="text-align: center;"><b><?php echo $language['add_success']; ?></b></div>
            <div class="layui-card-body">
                <blockquote class="layui-elem-quote layui-quote-nm" scrolling="yes" id="uids">

                </blockquote>
                <b><?php echo $language['add_success_notice']; ?></b>
            </div>
        </div>
        <div style="text-align: center;">
            <button class="layui-btn layui-btn-primary close"><?php echo $language['add_btn_close']; ?></button>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js">
</script>
<script>
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;
            var layerIndex;

            //监听提交
            form.on('submit(add-user)',
                function(data) {
                    layerIndex = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#add-user').prop('disabled', true);
                    $.ajax({
                        url: '/user/save',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.close(layerIndex);
                                $('.add').hide();
                                $('#uids').html(result.data.uids);
                                $('.success').show();
                            } else {
                                layer.close(layerIndex);
                                layer.msg(result.errmsg);
                                $('#add-user').prop('disabled', false);
                            }
                        }
                    });
                });
            $(document).on('click','.close',function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.layui.table.reload('player-list');
                parent.layer.close(index);
            });
        })
</script>
</body>
</html>