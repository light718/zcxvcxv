<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['add_title']; ?></title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['add_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['add_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['parent_agent']; ?></label>
                            <p><span class="badge bg-gray" id="agent" style="font-size: 1em;"><?php echo $account['username']; ?></span></p>
                        </div>
                        <?php if ($account['agent'] == 2) : ?>
                        <div class="form-group" id="c_region_id">
                            <label><?php echo $language['region']; ?></label>
                            <select class="form-control select2" id="region_id">
                                <option value=""><?php echo $language['select_region']; ?></option>
                            </select>
                            <p id="p_region_id"></p>
                        </div>
                        <div class="form-group" id="c_prefix_username">
                            <label><?php echo $language['prefix_username']; ?></label>
                            <input type="text" class="form-control" id="prefix_username" maxlength="5">
                            <p id="p_prefix_username"></p>
                        </div>
                        <?php endif; ?>
                        <div class="form-group" id="c_username">
                            <label><?php echo $language['username']; ?></label>
                            <input type="text" class="form-control" id="username" maxlength="16">
                            <p id="p_username"></p>
                        </div>
                        <div class="form-group" id="c_password">
                            <label><?php echo $language['password']; ?></label>
                            <input type="text" class="form-control" id="password" maxlength="15">
                            <p id="p_password"></p>
                        </div>
                        <div class="form-group" id="c_score">
                            <label><?php echo $language['set_coin']; ?></label><span id="maxValue"><span class="badge bg-red" style="margin-left:8px;"><?php echo $language['max_value']; ?>: <?php if ($account['agent'] == 3) { echo 100000000; } else { echo $max_value; } ?></span></span></span>
                            <input type="text" class="form-control" id="score">
                            <p id="p_score"></p>
                        </div>
                        <div class="form-group" id="c_nickname">
                            <label><?php echo $language['nickname']; ?></label>
                            <input type="text" class="form-control" id="nickname" maxlength="20">
                        </div>
                        <div class="form-group" id="c_tel">
                            <label><?php echo $language['tel']; ?></label>
                            <input type="text" class="form-control" id="tel" maxlength="20">
                        </div>
                        <div class="form-group" id="c_note">
                            <label><?php echo $language['note']; ?></label>
                            <textarea rows="2" class="form-control" id="note"></textarea>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                        <button type="button" class="btn btn-default" style="margin-left: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/plugins/select2/js/select2.full.min.js"></script>
    <script src="/poly/js/account/add.js"></script>
    <script type="text/javascript">
        var maxValue = "<?php echo $max_value; ?>".replace(/,/g, "");
    </script>
</html>