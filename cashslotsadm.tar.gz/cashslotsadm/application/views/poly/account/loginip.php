<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['edit_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
<div class="wrapper">
    <header class="main-header">
        <?php require APPPATH . "/views/poly/common/header.php"; ?>
    </header>

    <aside class="main-sidebar">
        <?php require APPPATH . "/views/poly/common/menu.php"; ?>
    </aside>

    <div class="main-footer hidden-xs bg-gray-light">
        <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
    </div>

    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content-header">
            <h1 class="hidden-xs"><?php echo $language['edit_title']; ?>
                <small style="margin-left: 8px; margin-right: 8px;">
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                </small>
            </h1>
            <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                <li>
                    <?php echo $language['loginip_title']; ?>&nbsp;&nbsp;&nbsp;
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                        <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                    </a>
                </li>
            </ol>
        </section>
        <section class="content">
            <div class="box box-default">
                <div class="box-body">
                    <div class="form-group">
                        <label><?php echo $language['username']; ?></label>
                        <p><span class="badge bg-gray" id="username" style="font-size:1em;"><?php echo $username; ?></span>
                        </p>
                    </div>
                    <div class="form-group">
                        <label>状态</label> <br/>
                        <input type="radio" name="state" value="1" <?php if(isset($loginip['status']) && $loginip['status'] == 1) { echo 'checked' ; } ; ?>/> 开启 <br/>
                        <input type="radio" name="state" value="2" <?php if(isset($loginip['status']) && $loginip['status'] != 1) { echo 'checked' ; } ; ?>/> 关闭 <br/>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>IP</th>
                                <th>操作</th>
                            </tr>
                            </thead>
                            <tbody id="list">
                            <?php
                            if(isset($loginip['ipjson'])) {
                                foreach($loginip['ipjson'] as $k => $v) {
                                    ?>
                                <tr>
                                    <td><?php echo $k; ?></td>
                                    <td><?php echo $v['ip']; ?></td>
                                    <td><a class="btn btn-warning btn-xs btn-edit" data-type="normal" target="_self"  onfocus="this.blur();" data-ip="<?php echo $v['ip']; ?>" href="#">编辑</a>
                                        <a class="btn btn-warning btn-xs btn-del" data-type="normal" target="_self" onfocus="this.blur();" data-ip="<?php echo $v['ip']; ?>" href="#">删除</a>
                                    </td>
                                </tr>
                            <?php
                                }
                            }?>
                            </tbody>
                        </table>
                    </div>
                    <div class="form-group">
                        <label>登录IP</label>
                        <input type="text" class="form-control" id="ip" maxlength="100" value=""/>
                        <input type="hidden" name="act" id="act" value="addip" />
                        <input type="hidden" id="sip" value="" />
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-primary" id="btn-add-ip"><?php echo $language['btn_sure']; ?></button>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/js/account/loginip.js?t=22"></script>
</html>