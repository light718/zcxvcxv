<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['search_account']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['search_account']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['search_account']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-body">
                        <div class="input-group input-group-lg">
                            <input type="text" id="username" maxlength="17" class="form-control text-bold text-blue" value="<?php echo $username; ?>">
                            <span class="input-group-btn">
                                <button type="button" id="btn-sure" class="btn btn-info btn-flat"><?php echo $language['btn_sure']; ?></button>
                            </span>
                        </div>
                    </div>
                    <div class="box-body" id="tb_player" style="display: none;">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th><?php echo $language['username']; ?></th>
                                        <th><?php echo $language['online']; ?></th>
                                        <th><?php echo $language['agent']; ?></th>
                                        <th><?php echo $language['search_account_score']; ?></th>
                                        <th><?php echo $language['nickname']; ?></th>
                                        <th><?php echo $language['tel']; ?></th>
                                        <th><?php echo $language['note']; ?></th>
                                        <th><?php echo $language['btn_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="tb_player_data">
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
                <div class="box box-primary" id="tb_agent" style="display: none;">
                    <div class="box-header with-border">
                        <h3 class="box-title text-bold" id="tip_agent"></h3>
                        <i class="fa fa-angle-double-right"></i>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-body" style="display: block;">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th><?php echo $language['username']; ?></th>
                                        <th><?php echo $language['search_account_score']; ?></th>
                                        <th><?php echo $language['nickname']; ?></th>
                                        <th><?php echo $language['agent']; ?></th>
                                        <th><?php echo $language['tel']; ?></th>
                                        <th><?php echo $language['note']; ?></th>
                                        <th><?php echo $language['btn_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="tb_agent_data">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="box box-primary" id="tb_agentlist" style="display: none;">
                    <div class="box-header with-border">
                        <h3 class="box-title text-bold" id="tip_agentlist"></h3>
                        <i class="fa fa-angle-double-right"></i>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-body" style="display: block;">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                <tr>
                                    <th><?php echo $language['username']; ?></th>
                                    <th><?php echo $language['search_account_score']; ?></th>
                                    <th><?php echo $language['nickname']; ?></th>
                                    <th><?php echo $language['agent']; ?></th>
                                    <th><?php echo $language['tel']; ?></th>
                                    <th><?php echo $language['note']; ?></th>
                                    <th><?php echo $language['btn_handle']; ?></th>
                                </tr>
                                </thead>
                                <tbody id="tb_agentlist_data">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/plugins/layer/layer.m.js"></script>
    <script type="text/javascript">
        $(function () {
            $("input").keydown(function (a) {
                13 == a.keyCode && $("#btn-sure").click();
            });
            $("#btn-sure").on('click', function () {
                if ($.trim($("#username").val()).length <= 0) {
                    webTips(language.empty_user_name);
                    return false;
                }
                doSearch($("#username").val());
            })
            <?php if ($username) : ?>
                doSearch("<?php echo $username; ?>");
            <?php endif; ?>
        });

        function doSearch(username) {
            var pagei;
            $('#tb_agent,#tb_agentlist,#tb_player').hide();
            $.ajax({
                url: "/account/search",
                type: "post",
                dataType: "json",
                data: {
                    username: username
                },
                success: function (json) {
                    if (json.code == 0 && json.data.account ) {
                        var account = json.data.account;
                        if(undefined == json.data.account) {
                            var strHtml = '<tr><td  colspan="7"> No account</td></tr>';
                            $("#tb_player_data").html(strHtml);
                            $('#tb_player').show();
                        } else {

                            if (account.agent == 0) {
                                strHtml = '<tr>';
                                strHtml += '<td><span class="text-bold">' + account.pid + '</span></td>';
                                if (account.login_time != "") {
                                    if (Math.floor(account.online) == 1) {
                                        strHtml += '<td><span class="badge bg-green">Yes</span></td>';
                                    } else {
                                        strHtml += '<td><span class="badge bg-gray"> ' + language.player_status_offline + ': ' + account.offline_time + ' ' + language.day + ' </span></td>';
                                    }
                                } else {
                                    strHtml += '<td><span class="badge bg-gray">N/A</span></td>';
                                }

                                strHtml += '<td>' + account.parent_username + '</td>';
                                strHtml += '<td>' + account.coin + '</td>';
                                strHtml += '<td>' + account.nickname + '</td>';
                                strHtml += '<td>' + account.phone + '</td>';
                                strHtml += '<td>' + account.remark + '</td>';
                                strHtml += '<td nowrap="nowrap" class="text-left">';
                                <?php if (!isset($permission) || array_intersect(array(2), $permission)) : ?>
                                strHtml += '<a class="btn btn-warning btn-xs ' + (account.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + account.pid + '" onfocus="this.blur();" href="/user/coin?username=' + account.pid + '&nickname=' + account.nickname + '">' + language.btn_coin_change + '</a>';
                                <?php endif; ?>
                                strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + account.pid + '" onfocus="this.blur();" href="/user/coinRecord?username=' + account.pid + '&nickname=' + account.nickname + '">' + language.action_coin_log + '</a>';
                                <?php if (!isset($permission) || array_intersect(array(5), $permission)) : ?>
                                strHtml += '<a class="btn btn-warning btn-xs ' + (account.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + account.pid + '" onfocus="this.blur();" href="/user/edit?username=' + account.pid + '">' + language.btn_edit + '</a>';
                                <?php endif; ?>
                                <?php if (!isset($permission) || array_intersect(array(1), $permission)) : ?>
                                strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + account.pid + '" onfocus="this.blur();" href="/user/searchCoin?username=' + account.pid + '&nickname=' + account.nickname + '">' + language.action_coin_search + '</a>';
                                <?php endif; ?>
                                strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + account.pid + '" onfocus="this.blur();" href="/user/gameRecord?username=' + account.pid + '&nickname=' + account.nickname + '">' + language.action_game_log + '</a>';
                                <?php if (!isset($permission) || array_intersect(array(4), $permission)) : ?>
                                if (account.banby_id == 0) {
                                    strHtml += '<a class="btn btn-warning btn-xs" data-type="forbidden" target="_self" title="' + account.pid + '" onfocus="this.blur();" onclick="changePlayerStatus(\'' + account.pid + '\', this)">' + language.btn_status_disable + '</button>';
                                } else {
                                    strHtml += '<a class="btn btn-danger btn-xs" data-type="normal" target="_self" title="' + account.pid + '" onfocus="this.blur();" onclick="changePlayerStatus(\'' + account.pid + '\', this)">' + language.btn_status_enable + '</button>';
                                }
                                <?php endif; ?>
                                strHtml += '</td>';
                                strHtml += '</tr>';
                                $("#tb_player_data").html(strHtml);
                                $('#tb_player').show();
                                var agentlist = json.data.agentlist;
                                if (agentlist) {
                                    var strHtml = '';
                                    for (var i = 0; i < agentlist.length; i++) {
                                        var item = agentlist[i];
                                        strHtml += '<tr>';
                                        strHtml += '<td><a href="/account?id=' + item.username + '" target="_self"><span class="text-red">' + item.username + '</span></a></td>';
                                        strHtml += '<td>' + item.coin + '</td>';
                                        strHtml += '<td>' + item.nickname + '</td>';
                                        strHtml += '<td>' + item.parent_username + '</td>';
                                        strHtml += '<td>' + item.phone + '</td>';
                                        strHtml += '<td>' + item.remark + '</td>';

                                        strHtml += '<td nowrap="nowrap" class="text-left">';
                                        <?php if (!isset($permission) || array_intersect(array(2), $permission)) : ?>
                                        strHtml += '<a class="btn btn-warning btn-xs ' + (item.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/coin?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_coin_change + '</a>';
                                        <?php endif; ?>
                                        strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/user/coinRecord?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_coin_change_record + '</a>';
                                        <?php if (!isset($permission) || array_intersect(array(5), $permission)) : ?>
                                        strHtml += '<a class="btn btn-warning btn-xs ' + (item.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/edit?username=' + item.username + '">' + language.btn_edit + '</a>';
                                        <?php endif; ?>
                                        <?php if (!isset($permission) || array_intersect(array(1), $permission)) : ?>
                                        strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/searchCoin?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_coin_search + '</a>';
                                        <?php endif; ?>
                                        <?php if (!isset($permission) || array_intersect(array(4), $permission)) : ?>
                                        if (item.banby_id == 0) {
                                            strHtml += '<a class="btn btn-warning btn-xs" date-type="forbidden" target="_self" title="' + item.username + '" onfocus="this.blur();" onclick="changeAgentStatus(\'' + item.username + '\', this)">' + language.btn_status_disable + '</button>';
                                        } else {
                                            strHtml += '<a class="btn btn-danger btn-xs" date-type="normal" target="_self" title="' + item.username + '" onfocus="this.blur();" onclick="changeAgentStatus(\'' + item.username + '\', this)">' + language.btn_status_enable + '</button>';
                                        }
                                        strHtml += '<a class="btn btn-warning btn-xs" data-type="normal" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/loginip?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_login_ip + '</button>';
                                        <?php endif; ?>
                                        strHtml += '</td>';
                                        strHtml += '</tr>';
                                    }
                                    $('#tb_agentlist_data').html(strHtml);
                                    $("#tip_agentlist").html(account.username + " " + language.agent_list);
                                    $('#tb_agentlist').show();
                                }
                            } else {
                                strHtml = '<tr>';
                                strHtml += '<td><a href="/account?id=' + account.username + '" target="_self"><span class="text-red">' + account.username + '</span></a></td>';
                                strHtml += '<td>' + account.coin + '</td>';
                                strHtml += '<td>' + account.nickname + '</td>';
                                strHtml += '<td>' + account.parent_username + '</td>';
                                strHtml += '<td>' + account.phone + '</td>';
                                strHtml += '<td>' + account.remark + '</td>';
                                strHtml += '<td nowrap="nowrap" class="text-left">';
                                <?php if (!isset($permission) || array_intersect(array(2), $permission)) : ?>
                                strHtml += '<a class="btn btn-warning btn-xs ' + (account.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + account.username + '" onfocus="this.blur();" href="/account/coin?username=' + account.username + '&nickname=' + account.nickname + '">' + language.btn_coin_change + '</a>';
                                <?php endif; ?>
                                strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + account.username + '" onfocus="this.blur();" href="/user/coinRecord?username=' + account.username + '&nickname=' + account.nickname + '">' + language.btn_coin_change_record + '</a>';
                                <?php if (!isset($permission) || array_intersect(array(5), $permission)) : ?>
                                strHtml += '<a class="btn btn-warning btn-xs ' + (account.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + account.username + '" onfocus="this.blur();" href="/account/edit?username=' + account.username + '">' + language.btn_edit + '</a>';
                                <?php endif; ?>
                                <?php if (!isset($permission) || array_intersect(array(1), $permission)) : ?>
                                strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + account.username + '" onfocus="this.blur();" href="/account/searchCoin?username=' + account.username + '&nickname=' + account.nickname + '">' + language.btn_coin_search + '</a>';
                                <?php endif; ?>
                                <?php if (!isset($permission) || array_intersect(array(4), $permission)) : ?>
                                if (account.banby_id == 0) {
                                    strHtml += '<a class="btn btn-warning btn-xs" date-type="forbidden" target="_self" title="' + account.username + '" onfocus="this.blur();" onclick="changeAgentStatus(\'' + account.username + '\', this)">' + language.btn_status_disable + '</button>';
                                } else {
                                    strHtml += '<a class="btn btn-danger btn-xs" date-type="normal" target="_self" title="' + account.username + '" onfocus="this.blur();" onclick="changeAgentStatus(\'' + account.username + '\', this)">' + language.btn_status_enable + '</button>';
                                }
                                <?php endif; ?>
                                strHtml += '</td>';
                                strHtml += '</tr>';
                                $('#tb_agent_data').html(strHtml);
                                $("#tip_agent").html(account.username + " " + language.agent_list),
                                    $('#tb_agent').show();

                                var agentlist = json.data.agentlist;
                                if (agentlist) {
                                    var strHtml = '';
                                    for (var i = 0; i < agentlist.length; i++) {
                                        var item = agentlist[i];
                                        strHtml += '<tr>';
                                        strHtml += '<td><a href="/account?id=' + item.username + '" target="_self"><span class="text-red">' + item.username + '</span></a></td>';
                                        strHtml += '<td>' + item.coin + '</td>';
                                        strHtml += '<td>' + item.nickname + '</td>';
                                        strHtml += '<td>' + item.parent_username + '</td>';
                                        strHtml += '<td>' + item.phone + '</td>';
                                        strHtml += '<td>' + item.remark + '</td>';

                                        strHtml += '<td nowrap="nowrap" class="text-left">';
                                        <?php if (!isset($permission) || array_intersect(array(2), $permission)) : ?>
                                        strHtml += '<a class="btn btn-warning btn-xs ' + (item.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/coin?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_coin_change + '</a>';
                                        <?php endif; ?>
                                        strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/user/coinRecord?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_coin_change_record + '</a>';
                                        <?php if (!isset($permission) || array_intersect(array(5), $permission)) : ?>
                                        strHtml += '<a class="btn btn-warning btn-xs ' + (item.is_direct === 0 ? 'disabled' : '') + '" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/edit?username=' + item.username + '">' + language.btn_edit + '</a>';
                                        <?php endif; ?>
                                        <?php if (!isset($permission) || array_intersect(array(1), $permission)) : ?>
                                        strHtml += '<a class="btn btn-warning btn-xs" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/searchCoin?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_coin_search + '</a>';
                                        <?php endif; ?>
                                        <?php if (!isset($permission) || array_intersect(array(4), $permission)) : ?>
                                        if (item.banby_id == 0) {
                                            strHtml += '<a class="btn btn-warning btn-xs" date-type="forbidden" target="_self" title="' + item.username + '" onfocus="this.blur();" onclick="changeAgentStatus(\'' + item.username + '\', this)">' + language.btn_status_disable + '</button>';
                                        } else {
                                            strHtml += '<a class="btn btn-danger btn-xs" date-type="normal" target="_self" title="' + item.username + '" onfocus="this.blur();" onclick="changeAgentStatus(\'' + item.username + '\', this)">' + language.btn_status_enable + '</button>';
                                        }
                                        strHtml += '<a class="btn btn-warning btn-xs" data-type="normal" target="_self" title="' + item.username + '" onfocus="this.blur();" href="/account/loginip?username=' + item.username + '&nickname=' + item.nickname + '">' + language.btn_login_ip + '</button>';
                                        <?php endif; ?>
                                        strHtml += '</td>';
                                        strHtml += '</tr>';
                                    }
                                    $('#tb_agentlist_data').html(strHtml);
                                    $("#tip_agentlist").html(account.username + " " + language.agent_list);
                                    $('#tb_agentlist').show();
                                }
                            }
                        }
                    } else {
                        webTips(language.game_log_no_data_01);
                    }
                },
                beforeSend: function () {
                    $("#btn-sure").attr("disabled", "disabled"),
                    pagei = layer.open({
                        type: 2,
                        content: language.please_waiting_01
                    })
                },
                complete: function () {
                    layer.close(pagei);
                    $("#btn-sure").removeAttr("disabled")
                }
            })
        }
    </script>
</body>
</html>