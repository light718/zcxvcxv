<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['change_coin_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['set_coin']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;"><a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a></small>
                    <small style="margin-right: 8px;"><a href="javascript:window.location.reload()" target="_self"><i class="fa fa-refresh"></i> <?php echo $language['btn_refresh']; ?></a></small>
                    <small class="logQuery"><a href="javascript:void(0);" onclick="javascript:reloadList()"><i class="fa fa-history"></i> <?php echo $language['set_coin_log']; ?></a></small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li><?php echo $language['set_coin']; ?>
                        &nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                        &nbsp;&nbsp;&nbsp;<a href="javascript:window.location.reload()" target="_self"><i class="fa fa-refresh"></i> <?php echo $language['btn_refresh']; ?></a>
                        &nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" onclick="javascript:reloadList()" class="logQuery"><i class="fa fa-history"></i> <?php echo $language['set_coin_log']; ?></a></li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header with-border">
                        <h3 class="box-title text-bold text-muted" id="username"><?php echo $username; ?></h3>
                        <i class="fa fa-angle-double-right" style="margin-left: 8px;"></i>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['cur_coin']; ?></label><span class="badge bg-yellow" id="curNum" style="margin-left: 8px;"></span><span id="state_loading_1" style="display: none;"><img alt="Loading..." src="/poly/images/loading_1.gif" align="absmiddle" style="margin-left: 10px;" /></span>
                        </div>

                        <div class="form-group">
                            <label><?php echo $language['set_coin']; ?></label>
                            <span class="badge bg-red" id="maxValue"></span><span id="state_loading_2" style="display: none;">
                                <img alt="Loading..." src="/poly/images/loading_1.gif" align="absmiddle" style="margin-left: 10px;" /></span>
                            <input type="text" class="form-control" id="txt_scoreNum">
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-sure"><?php echo $language['btn_sure']; ?></button>
                        <button type="button" class="btn btn-default" style="margin-left: 15px; margin-right: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                    </div>
                </div>

                <div class="box box-primary" id="table" style="display: none;">
                    <div class="box-header with-border">
                        <h3 class="box-title text-bold"><span id="total" class="badge bg-yellow"></span></h3>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo $language['table_column_from_username']; ?></th>
                                        <th><?php echo $language['table_column_to_username']; ?></th>
                                        <th><?php echo $language['table_column_coin_change']; ?></th>
                                        <th><?php echo $language['table_column_coin_change_before']; ?></th>
                                        <th><?php echo $language['table_column_coin_change_after']; ?></th>
                                        <th><?php echo $language['table_column_ip']; ?></th>
                                        <th><?php echo $language['table_column_time']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="list"></tbody>
                            </table>
                        </div>
                        <div id="pager" class="pull-left"></div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/js/account/change_coin.js"></script>
</html>