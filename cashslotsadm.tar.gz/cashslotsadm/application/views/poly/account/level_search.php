<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['level_search_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['level_search_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['level_search_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h6 class="box-title" id="d_tip_1" style="font-size:0.9em;">
                            <?php if ($cur_data) : ?>
                            <a class="hidden-xs hidden-sm <?php if ($type == 1) : ?>btn-success<?php endif; ?>" href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=1" target="_self"><?php echo $language['level_search_btn_condition_01']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm <?php if ($type == 2) : ?>btn-success<?php endif; ?>" href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=2" target="_self"><?php echo $language['level_search_btn_condition_02']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm <?php if ($type == 3) : ?>btn-success<?php endif; ?>" href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=3" target="_self"><?php echo $language['level_search_btn_condition_03']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm <?php if ($type == 4) : ?>btn-success<?php endif; ?>" href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=4" target="_self"><?php echo $language['level_search_btn_condition_04']; ?></a>
                            <div class="margin visible-xs visible-sm">
                                <div class="btn-group">
                                    <button class="btn btn-default btn-flat" type="button"><?php echo $language['level_search_btn_condition_0' . $type]; ?></button>
                                    <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                        <span class="caret"></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul role="menu" class="dropdown-menu">
                                        <li>
                                            <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=1" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['level_search_btn_condition_01']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=2" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['level_search_btn_condition_02']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=3" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['level_search_btn_condition_03']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="/account/levelSearch?account_id=<?php echo isset($cur_data['id']) ? $cur_data['id'] : 0; ?>&type=4" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['level_search_btn_condition_04']; ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <?php endif; ?>
                        </h6>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-body" style="display: block;">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="tb_agent">
                                <thead>
                                    <tr>
                                        <th><?php echo $language['username']; ?></th>
                                        <th><?php echo $language['nickname']; ?></th>
                                        <th><?php echo $language['table_column_coin']; ?></th>
                                        <th><?php echo $language['table_column_au']; ?></th>
                                        <th><?php echo $language['table_column_bets']; ?></th>
                                        <th><?php echo $language['table_column_win_coin']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($cur_data) : ?>
                                    <tr>
                                        <td><?php echo $cur_data['username']; ?></td>
                                        <td><?php echo $cur_data['nickname']; ?></td>
                                        <td><?php echo $cur_data['coin']; ?></td>
                                        <td><?php echo $cur_data['au']; ?></td>
                                        <td><?php echo $cur_data['bets']; ?></td>
                                        <td><?php echo $cur_data['win']; ?></td>
                                        <td class="text-left">
                                            <?php if ($cur_data['parent'] == 0) : ?>
                                            <a href="javascript:void(0);" class="btn btn-default btn-xs disabled">
                                                <?php echo $language['level_search_btn_parent']; ?>
                                            </a>
                                            <?php else: ?>
                                            <a href="/account/levelSearch?account_id=<?php echo $cur_data['parent']; ?>&type=<?php echo $type; ?>" class="btn btn-xs btn-warning">
                                                <?php echo $language['level_search_btn_parent']; ?>
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="box box-primary">
                    <div class="box-body" style="display: block;">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="tb_agent">
                                <thead>
                                    <tr>
                                        <th><?php echo $language['username']; ?></th>
                                        <th><?php echo $language['nickname']; ?></th>
                                        <th><?php echo $language['table_column_coin']; ?></th>
                                        <th><?php echo $language['table_column_au']; ?></th>
                                        <th><?php echo $language['table_column_bets']; ?></th>
                                        <th><?php echo $language['table_column_win_coin']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="level-search">
                                </tbody>
                            </table>
                        </div>
                        <div id="pager" class="pull-left"></div>
                    </div>
                    <div class="overlay" id="overlay" style="display: none;">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
            </section>
            <?php if ($cur_data) : ?>
            <input type="hidden" id="account_id" value="<?php echo $cur_data['id']; ?>">
            <input type="hidden" id="type" value="<?php echo $type; ?>">
            <?php endif; ?>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/js/account/level_search.js"></script>
</body>
</html>