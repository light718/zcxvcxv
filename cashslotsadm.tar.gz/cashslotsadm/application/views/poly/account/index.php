<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_account']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['account_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                    <small>
                        <a href="javascript:void(0);" target="_self" onclick="javascript:reloadAgentList();javascript:reloadPlayerList();"><i class="fa fa-refresh"></i> <?php echo $language['btn_refresh']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['account_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                        <a href="javascript:void(0);" onclick="javascript:reloadAgentList();javascript:reloadPlayerList();" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_refresh']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h6 class="box-title" id="d_tip_1" style="font-size:0.9em;">
                            <span class="badge bg-red"><span class="agent_username"><?php echo $account['username']; ?></span> - <?php echo $language['agent_list']; ?></span>
                            <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(3), $permission))) : ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm"  href="/account/add" target="_self"><?php echo $language['add_agent_title']; ?></a>
                            <?php endif; ?>
                            <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(1), $permission))) : ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="/account/agentTotalReport<?php if ($id) { echo '?username=' . $id; } ?>" target="_self"><?php echo $language['agent_total_report']; ?></a>
                            <?php endif; ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="javascript:void(0);" onclick='javascript:reloadAgentList();' target="_self"><?php echo $language['refresh_list']; ?></a>
                            <?php if ($account['agent'] == 2) : ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="/account/auth" target="_self"><?php echo $language['auth']; ?></a>
                            <?php endif; ?>
                            <div class="margin visible-xs visible-sm">
                                <div class="btn-group">
                                    <button class="btn btn-default btn-flat" type="button"><?php echo $language['agent_list_menu']; ?></button>
                                    <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                        <span class="caret"></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul role="menu" class="dropdown-menu">
                                        <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(3), $permission))) : ?>
                                        <li>
                                            <a href="/account/add" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['add_agent_title']; ?></span>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <li class="divider"></li>
                                        <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(1), $permission))) : ?>
                                        <li>
                                            <a href="/account/agentTotalReport<?php if ($id) { echo '?username=' . $id; } ?>" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['agent_total_report']; ?></span>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" onclick='javascript:reloadAgentList();' target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['refresh_list']; ?></span>
                                            </a>
                                        </li>
                                        <?php if ($account['agent'] == 2) : ?>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="/account/auth" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['auth']; ?></span>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </h6>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-footer">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="tb_agent">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo $language['table_column_username']; ?></th>
                                        <th><?php echo $language['prefix']; ?></th>
                                        <th><?php echo $language['table_column_coin']; ?></th>
                                        <th><?php echo $language['table_column_nickname']; ?></th>
                                        <th><?php echo $language['tel']; ?></th>
                                        <th><?php echo $language['note']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                        <th class="visible-xs"><?php echo $language['table_column_username']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="agent-list"></tbody>
                            </table>

                        </div>
                        <!--Pager-->
                        <div id="agent-pager" class="pull-left"></div>
                    </div>
                    <div class="overlay" id="agent-overlay" style="display: none;">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
                <div class="box box-warning">
                    <div class="box-header with-border">
                        <h6 class="box-title" id="d_tip_1" style="font-size:0.9em;">
                            <span class="badge bg-red"><span class="agent_username"><?php echo $account['username']; ?></span> - <?php echo $language['user_list']; ?></span>
                            <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(3), $permission))) : ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm"  href="/user/add" target="_self"><?php echo $language['add_user']; ?></a>
                            <?php endif; ?>
                            <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(1), $permission))) : ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm"  href="/user/playerTotalReport<?php if ($id) { echo '?username=' . $id; } ?>" target="_self"><?php echo $language['player_total_report']; ?></a>
                            <?php endif; ?>
                            <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(4), $permission))) : ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm btn-change-status"  href="javascript:void(0);" target="_self" data-status="2"><?php echo $language['btn_enable_all_player']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm btn-change-status"  href="javascript:void(0);" target="_self" data-status="1"><?php echo $language['btn_disable_all_player']; ?></a>
                            <?php endif; ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="javascript:void(0);" onclick='javascript:reloadPlayerList();' target="_self"><?php echo $language['reload_player_list']; ?></a>
                            <div class="margin visible-xs visible-sm">
                                <div class="btn-group">
                                    <button class="btn btn-default btn-flat" type="button"><?php echo $language['player_list_menu']; ?></button>
                                    <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                        <span class="caret"></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul role="menu" class="dropdown-menu">
                                        <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(3), $permission))) : ?>
                                        <li>
                                            <a href="/user/add" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['add_user']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <?php endif; ?>
                                        <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(1), $permission))) : ?>
                                        <li>
                                            <a href="/user/playerTotalReport<?php if ($id) { echo '?username=' . $id; } ?>" target="_self" id="disable">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['player_total_report']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <?php endif; ?>
                                        <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(4), $permission))) : ?>
                                        <li>
                                            <a href="javascript:void(0);" target="_self" id="enable">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['btn_enable_all_player']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" target="_self" id="disable">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['btn_disable_all_player']; ?></span>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" onclick='javascript:reloadPlayerList();' target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['reload_player_list']; ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </h6>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-footer">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo $language['player_username']; ?></th>
                                        <th><?php echo $language['column_nickname']; ?></th>
                                        <th><?php echo $language['tel']; ?></th>
                                        <th><?php echo $language['note']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="player-list"></tbody>
                            </table>

                        </div>
                        <!--Pager-->
                        <div id="player-pager" class="pull-left"></div>
                    </div>
                    <div class="overlay" id="player-overlay" style="display: none;">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <input type="hidden" value="<?php echo $id; ?>" id="agentId">
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/js/account/agent_list.js?v=1.2"></script>
    <script src="/poly/js/user/user_list.js"></script>
    <script type="text/javascript">
        var searchCoin = 0;
        <?php if (!isset($permission) || array_intersect(array(1), $permission)) : ?>
            searchCoin = 1
        <?php endif; ?>

        var setCoin = 0;
        <?php if (!isset($permission) || array_intersect(array(2), $permission)) : ?>
            setCoin = 1
        <?php endif; ?>

        var enable = 0;
        <?php if (!isset($permission) || array_intersect(array(4), $permission)) : ?>
            enable = 1
        <?php endif; ?>

        var editAccount = 0;
        <?php if (!isset($permission) || array_intersect(array(5), $permission)) : ?>
            editAccount = 1
        <?php endif; ?>
    </script>
</body>
</html>