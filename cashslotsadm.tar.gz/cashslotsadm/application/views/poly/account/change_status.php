<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['status_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['status_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['status_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header with-border">
                        <h4>
                            <label><?php echo $language['proxy_username']; ?>：</label>
                            <span class="text-success badge bg-gray" id="username" style="font-size: 1em;"><?php echo $username; ?></span>
                        </h4>
                        <h4>
                            <label><?php echo $language['proxy_nickname']; ?>：</label>
                            <span class="text-success badge bg-gray" id="nickname" style="font-size: 1em;"><?php echo $nickname; ?></span>
                        </h4>
                    </div>
                    <?php if ($status == 0) : ?>
                    <div class="box-body">
                        <h4>
                            <label><?php echo $language['status_notice01']; ?></label>
                        </h4>
                        <ul>
                            <li><?php echo $language['status_notice02']; ?></li>
                            <li><?php echo $language['status_notice03']; ?></li>
                            <li><?php echo $language['status_notice04']; ?></li>
                        </ul>
                    </div>
                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-sure" data-type="forbidden"><?php echo $language['status_btn_forbidden']; ?></button>
                    </div>
                    <?php else : ?>
                    <div class="box-body">
                        <h4>
                            <label><?php echo $language['status_notice05']; ?></label>
                        </h4>
                    </div>
                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-sure" data-type="normal"><?php echo $language['status_btn_normal']; ?></button>
                    </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/js/account/change_status.js"></script>
</html>