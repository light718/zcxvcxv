<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/plugins/sweetalert/sweetalert.css">
    <script type="text/javascript">
        var local_lang = localStorage.getItem('local_lang');
        if (!local_lang || local_lang === 'zh_cn') {
            local_lang = "<?php echo $lang; ?>";
            localStorage.setItem('local_lang', local_lang);
        }
        if ("<?php echo $lang; ?>" === 'zh_cn' && local_lang === 'english') {
            window.location.href = '/passport/login?lang=english';
        }
    </script>
    <style type="text/css">
        .img-selectLang {
            cursor: pointer;
        }

        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            -ms-box-sizing: border-box;
            -o-box-sizing: border-box;
            box-sizing: border-box;
        }

        html {
            width: 100%;
            height: 100%;
            overflow: hidden;
        }

        body {
            width: 100%;
            height: 100%;
            font-family: 'Open Sans', sans-serif;
            background: #605ca8;
            background: -webkit-gradient(linear, 0 0, 0 100%, from(#605ca8), to(#8B1C62));
            background: -webkit-linear-gradient(left, #605ca8, #8B1C62);
            background: -moz-linear-gradient(left, #FF7F00, #8B1C62);
            background: -o-linear-gradient(left, #FF7F00, #8B1C62);
            background: -ms-linear-gradient(left, #FF7F00, #8B1C62);
            background: linear-gradient(left, #FF7F00, #8B1C62);
            filter: progid:DXImageTransform.Microsoft.gradient(GradientType = 1, startColorstr = #605ca8, endColorstr = #8B1C62);
        }
    </style>
</head>

<body class="login-body">
    <input type="text" style="display: none;">
    <input type="password" style="display: none;">
    <div class="login-box">
        <div class="login-box-body">
            <div class="text-center" style="height: 60px;">
                <h2>
                    <?php 
                        if (DOMAIN === SYS_ADMIN_DOMAIN) {
                            echo $language['title'];  
                        } elseif (DOMAIN === ROOT_ADMIN_DOMAIN) {
                            echo $language['title_root_agent'];
                        } else {
                            echo $language['title_general_agent'];
                        }
                    ?>
                </h2>
            </div>
            <form role="form" class="layui-form">
                <div class="form-group">
                    <input style="display:none">
                    <input class="form-control input-lg" placeholder="<?php echo $language['username']; ?>" id="username" name="username" type="text" readonly="readonly" autofocus="">
                </div>
                <div class="form-group">
                    <input class="form-control input-lg" placeholder="<?php echo $language['password']; ?>" id="password" name="password" type="password" readonly="readonly">
                </div>
                <button lay-submit lay-filter="user-login-submit" id="user-login-submit" type="button" class="btn btn-success btn-lg btn-block"><?php echo $language['login']; ?></button>
            </form>
            <div class="social-auth-links text-center">
                <p class="text-primary">- <?php echo $language['select']; ?> -</p>
                <a href="javascript:void(0);" class="layui-btn <?php if ($lang != 'zh_cn') : ?>layui-btn-primary<?php else: ?>layui-btn-normal<?php endif; ?>" id="chinese">
                    <img class="img-thumbnail img-responsive img-selectLang" src="/poly/images/cn.png" title="<?php echo $language['chinese']; ?>">
                </a>
                <a href="javascript:void(0);" class="layui-btn <?php if ($lang != 'english') : ?>layui-btn-primary<?php else: ?>layui-btn-normal<?php endif; ?>" id="english">
                    <img class="img-thumbnail img-responsive img-selectLang" src="/poly/images/en.png" title="<?php echo $language['english']; ?>">
                </a>
            </div>
        </div>
    </div>
    <script src="/poly/dist/js/jquery.min.js"></script>
    <script src="/poly/dist/js/bootstrap.min.js"></script>
    <script src="/poly/dist/plugins/sweetalert/sweetalert.js"></script>
    <script src="/poly/js/common.js"></script>
    <script src="/poly/js/passport/login.js?v=1.1"></script>
</body>
</html>