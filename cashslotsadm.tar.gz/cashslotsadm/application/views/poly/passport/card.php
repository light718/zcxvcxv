<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title>牌型测试工具</title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
<div class="wrapper">
    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content col-xs-12 col-sm-12 col-md-6">
            <div class="box box-default">
                <div class="box-header">
                    <h3>牌型测试工具</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label>游戏ID:</label>
                        <select class="form-control select2" id="game_id">
                            <option value="">请选择游戏</option>
                        </select>
                    </div>

                    <div class="form-group" id="agentID">
                        <label>玩家ID:</label>
                        <input type="text" class="form-control" id="user_id" placeholder="">
                    </div>

                    <div class="form-group">
                        <label>用例牌型:</label>
                        <textarea id="card_type" class="form-control" rows="5" placeholder="json字符串" style="margin-bottom: 20px;"></textarea>
                    </div>
                </div>

                <div class="box-footer">
                    <button type="button" class="btn btn-primary" id="btn-save" style="width: 100px;">发送</button>
                </div>

            </div>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/dist/plugins/select2/js/select2.full.min.js"></script>
<script>
    $(function() {
        getGameLists();

        $('#btn-save').on('click', function() {
            var game_id = $('#game_id').val();
            var user_id = $('#user_id').val();
            var card_type = $('#card_type').val();

            $.ajax({
                url: '/card/index',
                dataType: 'json',
                data: {game_id: game_id, user_id: user_id, card_type: card_type},
                type: 'POST',
                success:function(result) {
                    if (result.errcode == 0) {
                        webDialog(result.errmsg, 0);
                    } else {
                        webDialog(result.errmsg, 1);
                    }
                },
                beforeSend: function () {
                    $('#btn-save').attr('disabled', 'disabled');
                },
                complete: function() {
                    $('#btn-save').removeAttr('disabled');
                }
            });
        });
    })
    function getGameLists() {
        $.ajax({
            url: '/card/gameList',
            dataType: 'json',
            type: 'GET',
            success:function(result) {
                if (result.errcode == 1001) {
                    window.location.reload();
                } else if (result.errcode == 0) {
                    var data = new Array();
                    $.each(result.data.game_list, function(i, v) {
                        data.push({id: v.id, text: v.name});
                    })
                    $('#game_id').select2({
                        placeholder: '请选择游戏',
                        data: data
                    });
                }
            }
        });
    }
</script>
</html>