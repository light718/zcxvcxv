<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['handle_title']; ?></title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['handle_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['handle_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-xs-4 col-sm-2 col-md-2">
                                <div class="form-group">
                                    <label><?php echo $language['action_username']; ?></label>
                                    <p><span class="badge bg-gray" id="username" style="font-size: 1em;"><?php echo $username; ?></span></p>
                                </div>
                            </div>
                            <div class="col-xs-4 col-sm-2 col-md-2">
                                <div class="form-group">
                                    <label><?php echo $language['action_nickname']; ?></label>
                                    <p><span class="badge bg-gray" id="nickname" style="font-size: 1em;"><?php echo $nickname; ?></span> </p>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <label><?php echo $language['action_setting_prob']; ?></label>
                        </div>
                        <div class="form-group">
                            <select class="form-control select2" id="prob">
                                <?php foreach ($prob as $key=>$val) : ?>
                                <option value="<?php echo $key; ?>" <?php if ($key == $cur_prob) : ?>selected<?php endif; ?>><?php echo $val; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <input type="hidden" class="form-control" id="time" value="1440">
                    </div>

                    <div class="box-footer">
                        <input type="hidden" id="type" value="<?php echo $type; ?>">
                        <input type="hidden" id="id" value="<?php echo $id; ?>">
                        <button type="button" class="btn btn-primary" id="btn-sure"><?php echo $language['btn_confirm']; ?></button>
                    </div>

                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/plugins/select2/js/select2.full.min.js"></script>
    <script src="/poly/js/prob/handle.js"></script>
</html>