<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['game_status']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <link rel="stylesheet" href="/poly/dist/plugins/iCheck/flat/blue.css">
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['game_status']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['game_status']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-primary">
                    <div class="box-header">
                        <h6 class="box-title" id="d_tip_1" style="font-size:0.9em;">
                            <span class="badge bg-red"><?php echo $language['batch_tag']; ?></span>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm"  href="javascript:void(0);" onclick="javascript:batchTag(0);"><?php echo $language['game_tag_0']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="javascript:void(0);" onclick="javascript:batchTag(1);"><?php echo $language['game_tag_1']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="javascript:void(0);" onclick="javascript:batchTag(2);"><?php echo $language['game_tag_2']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="javascript:void(0);" onclick="javascript:batchTag(3);"><?php echo $language['game_tag_3']; ?></a>
                            <div class="margin visible-xs visible-sm">
                                <div class="btn-group">
                                    <button class="btn btn-default btn-flat" type="button"><?php echo $language['select']; ?></button>
                                    <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                        <span class="caret"></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul role="menu" class="dropdown-menu">
                                        <li>
                                            <a href="javascript:void(0);" onclick="javascript:batchTag(0);" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['game_tag_0']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" onclick="javascript:batchTag(1);" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['game_tag_1']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" onclick="javascript:batchTag(2);" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['game_tag_2']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" onclick="javascript:batchTag(3);" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['game_tag_3']; ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </h6>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-body" style="display: block;">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" class="checkbox-toggle"></th>
                                        <th><?php echo $language['game_status_column_id']; ?></th>
                                        <th><?php echo $language['game_status_column_name']; ?></th>
                                        <th><?php echo $language['game_tag']; ?></th>
                                        <th><?php echo $language['game_status_column_status']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="list"></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="overlay" id="overlay" style="display: none;">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/dist/plugins/iCheck/icheck.min.js"></script>
    <script src="/poly/dist/plugins/layer/layer.js"></script>
    <script src="/poly/js/game/game_status.js?v=1.1"></script>
</html>