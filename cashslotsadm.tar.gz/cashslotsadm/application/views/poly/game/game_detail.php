<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['change_mission_config']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
<div class="wrapper">
    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content-header">
            <h1 class="hidden-xs"><?php echo $language['change_mission_config']; ?>
                <small style="margin-left: 8px; margin-right: 8px;">
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                </small>
            </h1>
            <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                <li>
                    <?php echo $language['change_mission_config']; ?>&nbsp;&nbsp;&nbsp;
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                        <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                    </a>
                </li>
            </ol>
        </section>
        <section class="content">
            <div class="box box-default">
                <div class="box-body">
                    <div class="form-group">
                        <label>游戏ID：</label>
                        <?php echo $id;?>
                        <p id="p1"></p>
                    </div>
                    <div class="form-group">
                        <label>游戏名称</label>
                        <input type="text" class="form-control" id="name" value="<?php echo $result['name']; ?>">
                        <p id="p2"></p>
                    </div>
                    <div class="form-group">
                        <label>游戏解锁等级</label>
                        <input type="text" class="form-control" id="level" value="<?php echo $result['level']; ?>">
                        <p id="p2"></p>
                    </div>
                    <div class="form-group">
                        <label>标签</label>
                        <select name="tagHot" id="tagHot" class="form-control">
                            <option value="0">普通</option>
                            <option value="1">最热</option>
                            <option value="2">最新</option>
                            <option value="3">在线</option>
                        </select>
                        <p id="p3"></p>
                    </div>
                    <div class="form-group">
                        <label>当前状态</label>
                        <select name="status" id="status" class="form-control">
                            <option value="1">正常</option>
                            <option value="0">维护中</option>
                        </select>
                        <p id="p4"></p>
                    </div>
                    <div class="form-group">
                        <label>排序</label>
                        <input type="text" class="form-control" id="ord" name="ord" value="<?php echo $result['ord']; ?>">
                        <p id="p5"></p>
                    </div>
                    <div class="form-group">
                        <label>类别</label>
                        <select name="type" id="type" class="form-control">
                            <option value="1">在线</option>
                            <option value="2">拉霸</option>
                            <option value="3">热门</option>
                            <option value="4">街机</option>
                            <option value="5">捕鱼</option>
                            <option value="6">桌游</option>
                        </select>
                        <p id="p6"></p>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="button" class="btn btn-primary" id="btn-sure" onclick="submitEdit()"><?php echo $language['btn_sure']; ?></button>
                    <button type="button" class="btn btn-default" style="margin-left: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                </div>
            </div>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/dist/js/laypage.js"></script>
<script src="/poly/dist/plugins/layer/layer.js"></script>
<script src="/poly/js/game/game_status.js"></script>

<script type="text/javascript">
    var id = "<?php echo $id ;?>";
    $(function () {
        $("#tagHot").val("<?php echo $result['tag'];?>");
        $("#status").val("<?php echo $result['status'];?>");
        $("#type").val("<?php echo $result['type'];?>");
    })

</script>
</body>
</html>