<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <div class="box box-solid box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $language['consume_coin']; ?></h3>
                            <div class="box-tools pull-right">
                                <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                            </div>
                        </div>
                        <div class="box-body">
                            <h6 class="box-title" id="d_tip_1" style="font-size:0.9em;">
                                <a class="hidden-xs hidden-sm" href="/game/commission" target="_self"><?php echo $language['history_consume_coin']; ?></a>
                                <span class="hidden-xs hidden-sm">　｜　</span>
                                <a class="hidden-xs hidden-sm" href="/prob/controlProxy" target="_self"><?php echo $language['menu_prob']; ?></a>
                                <div class="margin visible-xs visible-sm">
                                    <div class="btn-group">
                                        <button class="btn btn-default btn-flat" type="button"><?php echo $language['history_consume_coin']; ?></button>
                                        <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                            <span class="caret"></span>
                                            <span class="sr-only">Toggle Dropdown</span>
                                        </button>
                                        <ul role="menu" class="dropdown-menu">
                                            <li class="btn-commission-xs">
                                                <a href="/game/commission" target="_self">
                                                    <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['history_consume_coin']; ?></span>
                                                </a>
                                            </li>
                                            <li class="divider"></li>
                                            <li class="btn-commission-xs">
                                                <a href="/prob" target="_self">
                                                    <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['menu_prob']; ?></span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </h6>
                            <div class="form-group">
                                <p>
                                    <label class="text-blue"><?php echo $language['cur_consume_coin']; ?></label>
                                    <span class="badge bg-gray ui-autocomplete-input" id="cur_tax"><?php echo $cur['cur_tax']; ?> (<?php echo $cur['tax_ratio']; ?>)</span>
                                </p>
                                <p>
                                    <label class="text-blue"><?php echo $language['next_time_interval']; ?></label>
                                    <span class="badge bg-gray ui-autocomplete-input"><span id="minutes"><?php echo $cur['minutes']; ?> <?php echo $cur['reset_time']; ?></span>
                                </p>
                                <p>
                                    <label class="text-blue"><?php echo $language['cur_normal']; ?></label>
                                    <span class="badge bg-gray ui-autocomplete-input" id="cur_normal"><?php echo $cur['normal']; ?></span>
                                </p>
                            </div>
                            <div class="form-group">
                                <a class="btn btn-primary" href="/game/consumeCoin"><?php echo $language['btn_setting']; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <div class="box box-solid box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $language['jackpot']; ?></h3>
                            <div class="box-tools pull-right">
                                <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <p>
                                    <label class="text-blue"><?php echo $language['jackpot_cur_pos']; ?></label>
                                    <span class="badge bg-gray ui-autocomplete-input"><span id="jackpot"><?php echo $cur['jackpot']; ?> (<?php echo $cur['jackpot_ratio']; ?>)</span>
                                </p>
                            </div>
                            <div class="form-group">
                                <a class="btn btn-primary" href="/game/jackpot"><?php echo $language['btn_setting']; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <div class="box box-solid box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo $language['packet']; ?></h3>
                            <div class="box-tools pull-right">
                                <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                            </div>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <p>
                                    <label class="text-blue"><?php echo $language['packet_status']; ?></label>
                                    <span class="badge bg-gray ui-autocomplete-input"><span><?php if ($data['pool_rb_isopen'] == 1) : ?><?php echo $language['packet_status_open']; ?><?php else : ?><?php echo $language['packet_status_close']; ?><?php endif; ?></span>
                                </p>
                            </div>
                            <div class="form-group">
                                <a class="btn btn-primary" href="/game/packet"><?php echo $language['btn_setting']; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/js/game/index.js"></script>
</body>
</html>