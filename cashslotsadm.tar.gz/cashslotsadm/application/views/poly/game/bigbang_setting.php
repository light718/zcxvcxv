<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['bigbang_setting_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['bigbang_setting_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['bigbang_setting_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header with-border">
                        <div class="input-group">
                            <label style="margin-right: 20px;"><?php echo $language['bigbang_setting_base_value']; ?></label><span class="text-gray-active"><?php echo $language['bigbang_setting_base_value_tips']; ?></span>
                        </div>
                        <div class="input-group">
                            <input type="text" class="form-control" id="bb_disbaseline" value="<?php echo $data['bb_disbaseline']; ?>" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');">
                            <span class="input-group-addon">+- 50%</span>
                        </div>
                        <br>

                        <div class="input-group">
                            <label style="margin-right: 20px;"><?php echo $language['bigbang_setting_change_value']; ?></label><span class="text-gray-active"><?php echo $language['bigbang_setting_change_value_tips_01']; ?></span>
                        </div>
                        <div class="input-group">
                            <input type="text" class="form-control" id="bb_wave_val" value="<?php echo $data['bb_wave_val']; ?>" onkeyup="this.value=this.value.replace(/[^0-9]+/,'');">
                            <span class="input-group-addon">+- 50%</span>
                        </div>
                        <br>

                        <div class="input-group">
                            <label style="margin-right: 20px;"><?php echo $language['bigbang_setting_decline_time_interval']; ?></label><span class="text-gray-active"><?php echo $language['bigbang_setting_decline_tips']; ?></span>
                        </div>
                        <div class="input-group">
                            <input type="text" class="form-control" id="bb_valdown_time" value="<?php echo $data['bb_valdown_time']; ?>" onkeyup="this.value=this.value.replace(/[^0-9]+/,'');">
                            <span class="input-group-addon">+- 50%</span>
                        </div>
                        <br>

                        <div class="input-group">
                            <label style="margin-right: 20px;"><?php echo $language['bigbang_setting_decline_ratio']; ?></label>
                        </div>
                        <div class="input-group">
                            <input type="text" class="form-control" id="bb_valdown_parl" value="<?php echo $data['bb_valdown_parl']; ?>" onkeyup="this.value=this.value.replace(/[^0-9]+/,'');">
                            <span class="input-group-addon">+- 50%</span>
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="text-red"><?php echo $language['bigbang_setting_notice']; ?></label>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/js/game/bigbang_setting.js"></script>
</html>