<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['marquee_add_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <link rel="stylesheet" href="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.css" media="all">
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['marquee_add_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['marquee_add_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header with-border">
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['start_date']; ?></label>
                            <?php if ($lang == 'english') : ?>
                            <input type="text" class="form-control" id="start_date" onclick="WdatePicker({lang:'en'});">
                            <?php else : ?>
                            <input type="text" class="form-control" id="start_date" onclick="WdatePicker({lang:'zh-cn'});">
                            <?php endif; ?>
                        </div>

                        <div class="bootstrap-timepicker" id="begin_tp">
                            <div class="form-group">
                                <label>- <?php echo $language['time']; ?></label>
                                <div class="input-group">
                                    <input type="text" class="form-control timepicker" id="start_time">
                                    <div class="input-group-addon">
                                        <i class="fa fa-clock-o"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['marquee_add_send_times']; ?></label>
                            <input type="text" class="form-control" id="counts" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');">
                        </div>
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['marquee_add_send_space_time']; ?>(<?php echo $language['marquee_add_send_space_time_unit']; ?>)</label>
                            <input type="text" class="form-control" id="interval" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');">
                        </div>
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['marquee_add_content']; ?></label>
                            <textarea id="content" class="form-control" rows="3" placeholder="<?php echo $language['input'] . ' ' . $language['chinese']; ?>" style="margin-bottom: 20px;"></textarea>
                            <textarea id="contenten" class="form-control" rows="3" placeholder="<?php echo $language['input'] . ' ' . $language['english']; ?>"></textarea>
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                        <button type="button" class="btn btn-default" style="margin-left: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
    <script src="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <script src="/poly/js/game/add_marquee.js"></script>
</html>