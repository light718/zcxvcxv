<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_game_stat']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <link rel="stylesheet" href="/poly/dist/plugins/bootstrap-daterangepicker/daterangepicker.css" media="all">
    <style type="text/css">
        .calendar thead tr th {
            text-align: center;
            background-color: White;
            color: Black;
        }
    </style>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['menu_game_stat']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['menu_game_stat']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-primary">
                    <div class="box-header with-border" style="margin-bottom: 50px;">
                        <form class="form-inline">
                            <div class="form-group">
                                <select name="game_type" class="form-control" id="game-type">
                                    <?php foreach ($game_type as $type) : ?>
                                    <option value="<?php echo $type['type']; ?>"><?php echo $type['name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <select name="column" class="form-control" id="column">
                                    <option value="num_betofplayer"><?php echo $language['game_stat_player_num']; ?></option>
                                    <option value="amount_bet"><?php echo $language['game_stat_total_bet']; ?></option>
                                    <option value="amount_payout"><?php echo $language['game_stat_total_win']; ?></option>
                                    <option value="num_favorite"><?php echo $language['game_stat_collector']; ?></option>
                                    <option value="num_betfullofplayer"><?php echo $language['game_stat_max_bet_player_num']; ?></option>
                                    <option value="amount_betfull"><?php echo $language['game_stat_max_bet_total_bet']; ?></option>
                                    <option value="amount_betfullpayout"><?php echo $language['game_stat_max_bet_total_win']; ?></option>
                                </select>
                            </div>
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="fa fa-clock-o"></i>
                                </div>
                                <input type="text" class="form-control pull-right" id="reservationtime" style="width: 500px;" readonly>
                            </div>
                            <div class="form-group">
                                <select name="interval" class="form-control" id="interval">
                                    <?php foreach ($time as $key => $value) : ?>
                                    <option value="<?php echo $key?>"><?php echo $value; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="box-body">
                        <div id="bet-nums-container" style="height: 500px;"></div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/dist/plugins/echarts/echarts.min.js"></script>
    <script src="/poly/dist/plugins/moment/min/moment.min.js"></script>
    <script src="/poly/dist/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="/poly/js/game/game_stat_chart.js"></script>
    <script type="text/javascript">
        var start_time = "<?php echo date('Y-m-d'); ?> 00:00";
        var end_time = "<?php echo date('Y-m-d'); ?> 23:59";
        var type = 1;
        var column = 'num_betofplayer';
        var interval = 30;
        $('#reservationtime').daterangepicker({
            timePicker: true,
            // timePickerIncrement: 30,
            // format: 'MM/DD/YYYY h:mm A',
            locale: {
                format: "YYYY-MM-DD HH:mm", //设置显示格式
                applyLabel: '确定', //确定按钮文本
                cancelLabel: '取消', //取消按钮文本
            }
        }, function(start, end) {
            start_time = start.format('YYYY-MM-DD HH:mm');
            end_time = end.format('YYYY-MM-DD HH:mm');
            reloadChart();
        });
    </script>
</body>
</html>