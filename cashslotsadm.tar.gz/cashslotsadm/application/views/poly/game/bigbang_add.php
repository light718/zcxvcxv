<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['bigbang_jackpot_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['bigbang_jackpot_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['bigbang_jackpot_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header with-border">
                        <div class="form-group">
                            <label><?php echo $language['bigbang_jackpot_open_username']; ?></label>
                            <input type="text" class="form-control" id="username">
                        </div>
                        <div class="form-group">
                            <button type="button" class="btn btn-primary" id="btn-search"><?php echo $language['btn_search']; ?></button>
                        </div>
                    </div>
                    <div class="box-body" style="visibility: hidden;">
                        <div class="form-group">
                            <label><?php echo $language['player_username']; ?></label>
                            <span class="badge bg-gray" id="player_username" style="font-size: 1em;"></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['player_nickname']; ?></label>
                            <span class="badge bg-gray" id="nickname" style="font-size: 1em;"></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['bigbang_jackpot_seven_day_total_add_coin']; ?></label>
                            <span class="badge bg-gray" id="reload" style="font-size: 1em;"></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['bigbang_jackpot_seven_day_total_sub_coin']; ?></label>
                            <span class="badge bg-gray" id="withdraw" style="font-size: 1em;"></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['player_status']; ?></label>
                            <span class="badge bg-gray" id="status" style="font-size: 1em;"></span>
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['player_coin']; ?></label>
                            <span class="badge bg-gray" id="player_coin" style="font-size: 1em;"></span>
                        </div>
                    </div>
                    <div class="box-footer">
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['bigbang_jackpot_award']; ?></label><span class="text-gray-active"><?php echo $language['bigbang_jackpot_award_range']; ?>：10.00~10,000.00</span>
                            <input type="text" class="form-control" id="coin" onkeyup="clearNoNum(this, 2)">
                        </div>
                        <div class="form-group">
                            <label class="text-red"><?php echo $language['bigbang_jackpot_notice_01']; ?></label>
                        </div>
                        <div class="form-group">
                            <div class="checkbox">
                                <h3><label class="text-red">
                                    <input type="checkbox" id="flag" value="1"> <?php echo $language['bigbang_jackpot_notice_02']; ?>
                                </label></h3>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary" disabled="disabled" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                        <button type="button" class="btn btn-default" style="margin-left: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/sweetalert2.all.min.js"></script>
    <script src="/poly/js/game/bigbang_add.js"></script>
</html>