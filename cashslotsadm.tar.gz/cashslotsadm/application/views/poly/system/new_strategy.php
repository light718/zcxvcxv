<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['new_strategy']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['new_strategy']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['new_strategy']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header with-border">
                        <div class="form-group">
                            <a type="button" class="btn btn-primary" href="new_strategy_count"><?php echo $language['new_strategy_count']; ?></a>
                            <a type="button" class="btn btn-primary" href="new_strategy_list"><?php echo $language['new_strategy_list']; ?></a>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['new_strategy_01']; ?></label>
                            <input type="text" class="form-control" id="soul_s1_start_ipnum" value="<?php echo $data['soul_s1_start_ipnum']; ?>" onkeyup="clearNoNum(this, 2)">
                        </div>
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['new_strategy_02']; ?></label>
                            <input type="text" class="form-control" id="soul_s1_over_withinhour" value="<?php echo $data['soul_s1_over_withinhour']; ?>" onkeyup="clearNoNum(this, 2)">
                        </div>
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['new_strategy_03']; ?></label>
                            <textarea class="form-control" rows=4 id="soul_s1_over_bettotal"><?php echo json_encode(json_decode($data["soul_s1_over_bettotal"], true), JSON_PRETTY_PRINT); ?></textarea>
                            <!-- <input type="text" class="form-control" id="soul_s1_over_bettotal" value="<?php echo $data['soul_s1_over_bettotal']; ?>" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');"> -->
                        </div>
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['new_strategy_04']; ?></label>
                            <textarea class="form-control" rows=20 id="soul_s1_over_wintotal"><?php echo json_encode(json_decode($data["soul_s1_over_wintotal"], true), JSON_PRETTY_PRINT); ?></textarea>

                            <!-- <input type="text" class="form-control" id="soul_s1_over_wintotal" value='' onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');"> -->
                        </div>
                        <div class="form-group">
                            <label style="margin-right: 20px;"><?php echo $language['new_strategy_05']; ?></label>
                            <input type="text" class="form-control" id="soul_s1_over_agentwintotal" value="<?php echo $data['soul_s1_over_agentwintotal']; ?>" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');">
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/js/system/new_strategy.js"></script>
</html>