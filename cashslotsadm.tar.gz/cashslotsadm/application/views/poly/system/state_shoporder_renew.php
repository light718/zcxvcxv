<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_player_login_log']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <link rel="stylesheet" href="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.css" media="all">
</head>
<body class="skin-purple">
<div class="wrapper">
    <header class="main-header">
        <?php require APPPATH . "/views/poly/common/header.php"; ?>
    </header>

    <aside class="main-sidebar">
        <?php require APPPATH . "/views/poly/common/menu.php"; ?>
    </aside>

    <div class="main-footer hidden-xs bg-gray-light">
        <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
    </div>

    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content-header">
            <h1 class="hidden-xs"><?php echo $language['menu_state_shoporder_renew']; ?>
                <small style="margin-left: 8px; margin-right: 8px;">
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                </small>
            </h1>
            <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                <li>
                    <?php echo $language['menu_player_login_log']; ?>&nbsp;&nbsp;&nbsp;
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                        <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                    </a>
                </li>
            </ol>
        </section>
        <section class="content">
            <div class="box box-default">
                <div class="box-body">
                    <div class="form-group">
                        <label><?php echo $language['start_date']; ?></label>
                        <?php if ($lang == 'english') : ?>
                            <input type="text" class="form-control" id="start-date" onclick="WdatePicker({lang:'en'});">
                        <?php else : ?>
                            <input type="text" class="form-control" id="start-date" onclick="WdatePicker({lang:'zh-cn'});">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label><?php echo $language['end_date']; ?></label>
                        <?php if ($lang == 'english') : ?>
                            <input type="text" class="form-control" id="end-date" onclick="WdatePicker({lang:'en'});">
                        <?php else : ?>
                            <input type="text" class="form-control" id="end-date" onclick="WdatePicker({lang:'zh-cn'});">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-primary" id="btn-sure"><?php echo $language['btn_sure']; ?></button>
                        <button type="button" class="btn btn-primary" id="btn-export"><?php echo $language['btn_export']; ?></button>
                    </div>
                </div>
            </div>
            <div class="box box-primary">
                <div class="box-body" style="display: block;">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th><?php echo $language['state_order_date']; ?></th>
                                <th><?php echo $language['state_shoprenew_user1']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount1']; ?></th>
                                <th><?php echo $language['state_shoprenew_user2']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount2']; ?></th>
                                <th><?php echo $language['state_shoprenew_user3']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount3']; ?></th>
                                <th><?php echo $language['state_shoprenew_user4']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount4']; ?></th>
                                <th><?php echo $language['state_shoprenew_user5']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount5']; ?></th>
                                <th><?php echo $language['state_shoprenew_user6']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount6']; ?></th>
                                <th><?php echo $language['state_shoprenew_user7']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount7']; ?></th>
                                <th><?php echo $language['state_shoprenew_user8']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount8']; ?></th>
                                <th><?php echo $language['state_shoprenew_user9']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount9']; ?></th>
                                <th><?php echo $language['state_shoprenew_user10']; ?></th>
                                <th><?php echo $language['state_shoprenew_amount10']; ?></th>
                            </tr>
                            </thead>
                            <tbody id="list"></tbody>
                        </table>
                    </div>
                    <div id="pager" class="pull-left"></div>
                </div>
                <div class="overlay" id="overlay" style="display: none;">
                    <i class="fa fa-refresh fa-spin"></i>
                </div>
            </div>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/dist/js/laypage.js"></script>
<script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
<script src="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<script src="/poly/js/system/state_shopitem_renew.js"></script>
</body>
</html>
