<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_order_record']; ?></title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body>
<!--<div class="wrapper">-->
<form class="form-inline" method="post" id="mailAdd">
    <div class="form-group">
        <!--        <div class="input-group">-->
        <div class="form-group">
            <label for="stype" class="col-sm-2 control-label">邮件类别</label>
            <div class="col-sm-10">
                <select name="mail_type" class="form-control" id="stype">
                    <option value="1">常规邮件</option>
                    <option value="2">活动邮件</option>
                    <option value="3">广告邮件</option>
                </select>
            </div>
            <!--        </div>-->
        </div>
        <div class="form-group">
            <label for="email_title"class="col-sm-2 control-label">目标用户编号（逗号隔开）</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="uids" name="uids" placeholder="目标用户编号（逗号隔开）">
            </div>
        </div>
        <div class="form-group">
            <label for="email_title"class="col-sm-2 control-label">邮件标题</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="email_title" name="email_title" placeholder="邮件标题">
            </div>
        </div>
        <div class="form-group">
            <label for="content" class="col-sm-2 control-label">正文/活动内容</label>
            <div class="col-sm-10">
                <textarea name="content" id="content" class="form-control"></textarea>
            </div>
        </div>
        <div class="form-group">
            <label for="cover_img" class="col-sm-2 control-label">广告/活动小图</label>
            <div class="col-sm-10">
                    <input type="text" class="form-control" id="cover_img" name="cover_img" placeholder="封面图片">
            </div>
        </div>
        <div class="form-group">
            <label for="bonus_type" class="col-sm-2 control-label">奖励类型</label>
            <div class="col-sm-10">
                <select name="bonus_type" class="form-control"  id="bonus_type">
                    <option value="1">金币奖励</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label for="bonus_type" class="col-sm-2 control-label">奖励数量</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="bonus_amount" id="bonus_amount" placeholder="奖励数量">
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-10">
                <button type="button" class="btn btn-primary btn-lg form-control" onclick="submitApp()">确认</button>
            </div>
        </div>
</form>
</body>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/dist/js/laypage.js"></script>
<script src="/poly/dist/plugins/layer/layer.js"></script>
<script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
<script src="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<script src="/poly/js/mail/mail.js"></script>
</html>