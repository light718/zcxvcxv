<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_order_record']; ?></title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>
        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['mail_record']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['menu_player_list']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
                <button type="button" class="btn btn-success" onclick="mailAdd()">新增邮件</button>
            </section>
            <section class="content">
                <div class="box box-default">

                </div>
                <div class="box box-primary">
                    <table class="table table-bordered table-striped">

                        <thead>
                            <th>邮件编号</th>
                            <th>邮件标题</th>
                            <th>邮件内容</th>
                            <th>创建时间</th>
                            <th>邮件类别</th>
                            <th>操作</th>
                        </thead>
                        <tbody>
                        <?php foreach ($list as $val){ ?>
                            <tr>
                                <td><? echo $val['id'] ?></td>
                                <td><? echo $val['title'] ?></td>
                                <td><? echo $val['msg'] ?></td>
                                <td><? echo $val['timestamp_txt'] ?></td>
                                <td><? echo $val['stype_txt'] ?></td>
                                <td>
                                    <button type="button" class="btn btn-warning" onclick="delMail('<?php echo $val['id'];?>')">删除</button>

                                </td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/dist/plugins/layer/layer.js"></script>
    <script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
    <script src="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <script src="/poly/js/mail/mail.js"></script>
</body>
</html>