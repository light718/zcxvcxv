<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_home']; ?></title>

    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcss.com/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css"
          rel="stylesheet">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <style>
        .panel-row {
            font-size: 13px;
            width: 100%;
            height: 4rem;
            line-height: 4rem;
            border: 1px solid #FFFFFF;
            padding-top: 5px;
            text-align: left;
        }

        .row {
            margin-left: 0px;
        }

        #table_body tr > td {
            width: 150px;
        }

        #table_header > th {
            width: 200px;
        }

    </style>
</head>
<body class="skin-purple">
<div class="wrapper">
    <header class="main-header">
        <?php require APPPATH . "/views/poly/common/header.php"; ?>
    </header>

    <aside class="main-sidebar">
        <?php require APPPATH . "/views/poly/common/menu.php"; ?>
    </aside>

    <div class="main-footer hidden-xs bg-gray-light">
        <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
    </div>

    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content-header">
            <h1 class="hidden-xs"><?php echo $language['menu_home']; ?></small></h1>
            <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                <li><?php echo $language['menu_home']; ?>&nbsp;&nbsp;&nbsp;</li>
            </ol>
        </section>
        <section class="content">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h2 class="box-title">
                        <b><?php echo $language['title']; ?></b>
                    </h2>
                    <div class="box-tools pull-right">
                        <button data-widget="collapse" class="btn btn-box-tool" type="button"><i
                                    class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <span><?php echo isset($notice['content']) ? $notice['content'] : ''; ?></span>
                </div>
            </div>
            <?php if ($account['agent'] >= 2) : ?>
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <div>
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active" onclick="game_data()">
                                    <a href="#home"
                                       aria-controls="home"
                                       role="tab"
                                       data-toggle="tab"><?php echo $language['card_playing_data']; ?></a>
                                </li>
                                <li role="presentation" onclick="play_game_data()"><a href="#new_player_sub_game_data"
                                                           aria-controls="new_player_sub_game_data" role="tab"
                                                           data-toggle="tab"><?php echo $language['new_player_sub_game_data']; ?></a>
                                </li>
                                <!-- 新玩家首玩游戏 -->
                                <li role="presentation" onclick="firstPlay()"><a href="#game_first_time"
                                                           aria-controls="game_first_time" role="tab"
                                                           data-toggle="tab"><?php echo $language['game_first_time']; ?></a>
                                </li>
                                <!-- 玩牌数据 -->
                                <li role="presentation" onclick="play_card()"><a href="#active_playing_cards" aria-controls="active_playing_cards"
                                                           role="tab"
                                                           data-toggle="tab"><?php echo $language['active_playing_cards']; ?></a>
                                </li>
                                <!--  活跃玩家玩牌数据-->

                                <li role="presentation" onclick="activeData()"><a href="#loss_analysis" aria-controls="loss_analysis"
                                                           role="tab"
                                                           data-toggle="tab"><?php echo $language['active_playing_cards_sub']; ?></a>
                                </li>
                                <!-- 所有玩家子数据-->

                                <li role="presentation" onclick="allData()"><a href="#all_playing_cards"
                                                           aria-controls="all_playing_cards" role="tab"
                                                           data-toggle="tab"><?php echo $language['all_playing_cards']; ?></a>
                                </li>
                                <li role="presentation" onclick="userCoin()"><a href="#carry_gold_coins" aria-controls="carry_gold_coins"
                                                           role="tab"
                                                           data-toggle="tab"><?php echo $language['carry_gold_coins']; ?></a>
                                </li>
                                <li role="presentation" onclick="user_carry_coin()"><a href="#user_carry_gold_coins" aria-controls="user_carry_gold_coins"
                                                                                role="tab"
                                                                                data-toggle="tab"><?php echo $language['user_carry_gold_coins']; ?></a>
                                </li>
                                <li role="presentation" onclick="coinBack()"><a href="#gold_coin"
                                                           aria-controls="gold_coin" role="tab"
                                                           data-toggle="tab"><?php echo $language['gold_coin']; ?></a>
                                </li>
                                <li role="presentation" onclick="coinLog()"><a href="#stat_coin_log"
                                                                                aria-controls="stat_coin_log" role="tab"
                                                                                data-toggle="tab"><?php echo $language['stat_coin_log']; ?></a>
                                </li>

                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="home">
                                    <div class="table-responsive" style="width:100%;overflow-x: scroll">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                            <tr>
                                                <th>日期</th>
                                                <th>新增未游戏人数</th>
                                                <th>新增游戏人数</th>
                                                <th>新增游戏总次数</th>
                                                <th>活跃未游戏人数</th>
                                                <th>活跃游戏人数</th>
                                                <th>活跃游戏总次数</th>
                                            </tr>
                                            </thead>
                                            <tbody id="table_body" style="width: 110%">


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="new_player_sub_game_data">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>日期</th>
                                            <th>没有玩过子游戏的玩家</th>
                                            <th>只玩过一个子游戏</th>
                                            <th>只玩过二个子游戏</th>
                                            <th>只玩过三个子游戏</th>
                                            <th>只玩过四个子游戏</th>
                                            <th>四种以上子游戏</th>
                                            <th>汇总</th>
                                        </tr>
                                        </thead>
                                        <tbody id="play_game_list" style="width: 110%">


                                        </tbody>
                                    </table>

                                </div>
                                <div role="tabpanel" class="tab-pane" id="game_first_time">
                                    <div class="form-inline">

                                        <label>起始时间：</label>
                                        <!--指定 date标记-->
                                        <div class='input-group input-inline date'>
                                            <input type='text' class="form-control" id='start'/>
                                            <span class="input-group-addon"><span
                                                        class="glyphicon glyphicon-calendar"></span></span>
                                        </div>
                                        <label>终止时间：</label>
                                        <!--指定 date标记-->
                                        <div class='input-group date'>
                                            <input type='text' class="form-control form-inline"
                                                   id='end'/>
                                            <span class="input-group-addon">
                                                         <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                        </div>
                                        <button type="button" class="btn btn-success"
                                                onclick="userGame()">搜索
                                        </button>
                                    </div>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>序号</th>
                                            <th>日期</th>
                                            <th>子游戏编号</th>
                                            <th>子游戏名称</th>
                                            <th>游戏人数</th>
                                            <th>注册当天的下注金额</th>
                                            <th>注册当天的下注次数</th>
                                            <th>注册当天回报金额</th>
                                            <th>游戏中下注1w的次数</th>
                                            <th>游戏中下注2w的次数</th>
                                            <th>游戏中下注的其他次数</th>
                                            <th>免费游戏次数</th>
                                        </tr>
                                        </thead>
                                        <tbody id="data_list" style="width: 110%"></tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="active_playing_cards">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr id="play_card_head">
                                            <th>日期</th>
                                            <th>活跃玩家spin人数</th>
                                            <th>活跃玩家中没有spin的人数</th>
                                            <th>spin0-50的人数</th>
                                            <th>spin51-100的人数</th>
                                            <th>spin大于101的人数</th>
                                            <th>spin的中位数</th>
                                        </tr>
                                        </thead>
                                        <tbody id="playCard" style="width: 110%">


                                        </tbody>
                                    </table>

                                </div>
                                <div role="tabpanel" class="tab-pane" id="loss_analysis">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>日期</th>
                                            <th>没有玩过子游戏的玩家</th>
                                            <th>只玩过一个子游戏</th>
                                            <th>只玩过二个子游戏</th>
                                            <th>只玩过三个子游戏</th>
                                            <th>只玩过四个子游戏</th>
                                            <th>四种以上子游戏</th>
                                            <th>汇总</th>
                                        </tr>
                                        </thead>
                                        <tbody id="active_data" style="width: 110%"></tbody>
                                    </table>

                                </div>
                                <div role="tabpanel" class="tab-pane" id="all_playing_cards">
                                    <div class="form-inline">

                                        <label>起始时间：</label>
                                        <!--指定 date标记-->
                                        <div class='input-group input-inline date'>
                                            <input type='text' class="form-control" id='start_time_all'/>
                                            <span class="input-group-addon"><span
                                                        class="glyphicon glyphicon-calendar"></span></span>
                                        </div>
                                        <label>终止时间：</label>
                                        <!--指定 date标记-->
                                        <div class='input-group date'>
                                            <input type='text' class="form-control form-inline"
                                                   id='end_time_all'/>
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                        <button type="button" class="btn btn-success"
                                                onclick="allData()">搜索
                                        </button>
                                    </div>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>序号</th>
                                            <th>日期</th>
                                            <th>子游戏编号</th>
                                            <th>子游戏名称</th>
                                            <th>总游戏人数</th>
                                            <th>总下注金额</th>
                                            <th>总下注次数</th>
                                            <th>总回报金额</th>
                                            <th>游戏中下注1w的次数</th>
                                            <th>游戏中下注2w的次数</th>
                                            <th>游戏中下注的其他次数</th>
                                            <th>免费游戏次数</th>
                                            <th>破产次数</th>
                                            <th>破产人数</th>
                                        </tr>
                                        </thead>
                                        <tbody id="all_data" style="width: 110%">
                                        </tbody>
                                    </table>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="carry_gold_coins">
                                    <div class="form-inline">

                                        <label>起始时间：</label>
                                        <!--指定 date标记-->
                                        <div class='input-group input-inline date'>
                                            <input type='text' class="form-control" id='start_time'/>
                                            <span class="input-group-addon"><span
                                                        class="glyphicon glyphicon-calendar"></span></span>
                                        </div>
                                        <label>终止时间：</label>
                                        <!--指定 date标记-->
                                        <div class='input-group date'>
                                            <input type='text' class="form-control form-inline"
                                                   id='end_time'/>
                                            <span class="input-group-addon">
                                                         <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                        </div>
                                        <button type="button" class="btn btn-success"
                                                onclick="userCoin()">搜索
                                        </button>
                                    </div>
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>日期</th>
                                            <th>携带金币10w以内的用户</th>
                                            <th>携带金币10w-50w以内的用户</th>
                                            <th>携带金币50w-100w的用户</th>
                                            <th>携带金币100w-500w的用户</th>
                                            <th>携带金币500w以外的用户</th>
                                        </tr>
                                        </thead>
                                        <tbody id="dnu_coin" style="width: 110%">


                                        </tbody>
                                    </table>

                                </div>
                                <div role="tabpanel" class="tab-pane" id="user_carry_gold_coins">

                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>日期</th>
                                            <th>携带金币10w以内的人数</th>
                                            <th>携带金币10w-50w以内的人数</th>
                                            <th>携带金币50w-100w的人数</th>
                                            <th>携带金币100w-500w的人数</th>
                                            <th>携带金币500w以外的人数</th>
                                        </tr>
                                        </thead>
                                        <tbody id="user_carry_gold_coins_data" style="width: 110%">
                                        </tbody>
                                    </table>

                                </div>
                                <div role="tabpanel" class="tab-pane" id="gold_coin">

                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>日期</th>
                                            <th>通过下注回收的金币数目</th>
                                            <th>其他途径</th>
                                            <th>金币回收汇总</th>
                                        </tr>
                                        </thead>
                                        <tbody id="coinBack" style="width: 110%">


                                        </tbody>
                                    </table>

                                </div>
                                <div role="tabpanel" class="tab-pane" id="stat_coin_log">

                                    <table class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>日期</th>
                                            <th>登录赠送</th>
                                            <th>七日签到</th>
                                            <th>转盘</th>
                                            <th>绑定fb</th>
                                            <th>首次登录</th>
                                            <th>升级</th>
                                            <th>刮刮乐</th>
                                            <th>破产</th>
                                            <th>任务</th>
                                            <th>子游戏spin</th>
                                            <th>好友赠送</th>
                                            <th>好友中奖</th>
                                            <th>邮件接收</th>
                                            <th>特定邮件</th>
                                            <th>汇总</th>
                                        </tr>
                                        </thead>
                                        <tbody id="coinLog" style="width: 110%">


                                        </tbody>
                                    </table>

                                </div>
                            </div>

                        </div>
                        <h6 class="box-title">

                        </h6>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i
                                        class="fa fa-minus"></i></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>

<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="http://cdn.staticfile.org/moment.js/2.24.0/moment.js"></script>
<script src="https://cdn.bootcss.com/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script src="/poly/js/accountdata/accountdata.js"></script>

</body>
</html>