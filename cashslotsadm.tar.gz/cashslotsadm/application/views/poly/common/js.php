<script src="/poly/dist/js/jquery.min.js"></script>
<script src="/poly/dist/js/bootstrap.min.js"></script>
<script src="/poly/dist/js/adminlte.min.js"></script>
<script src="/poly/dist/plugins/sweetalert/sweetalert.js"></script>
<script src="/poly/js/common.js"></script>
<script src="/poly/dist/js/echarts.simple.js"></script>
<script type="text/javascript">
    var language = JSON.parse('<?php echo json_encode($language); ?>');
</script>