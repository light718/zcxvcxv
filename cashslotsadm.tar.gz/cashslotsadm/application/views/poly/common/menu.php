<section class="sidebar">
    <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
            <input type="text" id="search_username" maxlength="17" class="form-control" placeholder="<?php echo $language['search_account_tips']; ?>">
            <span class="input-group-btn">
                <button type="button" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
            </span>
        </div>
    </form>
    <ul class="sidebar-menu" data-widget="tree">
        <li><a href="/"><i class="fa fa-home"></i> <span class="text-bold"><?php echo $language['menu_home']; ?></span></a></li>
        <li><a href="/welcome/changePwd"><i class="fa fa-chevron-right"></i> <span class="text-bold"><?php echo $language['menu_chpwd']; ?></span></a></li>
        <?php foreach ($menu as $row) : ?>
            <?php if (isset($row['submenu']) && $row['submenu']) : ?>
            <li class="treeview <?php if ($row['selected'] == 1) : ?>active menu-open<?php endif; ?>">
                <a href="<?php echo $row['url']; ?>"><i class="fa fa-chevron-right"></i> <span class="text-bold"><?php echo $row['name']; ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php foreach ($row['submenu'] as $submenu) : ?>
                    <li <?php if ($submenu['selected'] == 1) : ?>class="active"<?php endif; ?>><a href="<?php echo $submenu['url']; ?>"><i class="fa fa-circle-o"></i> <span class="text-bold"><?php echo $submenu['name']; ?></span></a></li>
                    <?php endforeach; ?>
                </ul>
            </li>
            <?php else : ?>
                <li <?php if ($row['selected'] == 1) : ?>class="active"<?php endif; ?>><a href="<?php echo $row['url']; ?>"><i class="fa fa-chevron-right"></i> <span class="text-bold"><?php echo $row['name']; ?></span></a></li>
            <?php endif; ?>
        <?php endforeach; ?>
        <li><a href="javascript:void(0);" onclick='web_logout("<?php echo $language['logout_tips']; ?>", "<?php echo $language['btn_sure']; ?>", "/passport/logout");'><i class="fa fa-sign-out text-green fa-lg"></i> <span class="text-bold text-orange"><?php echo $language['btn_logout']; ?></span></a></li>
    </ul>
</section>