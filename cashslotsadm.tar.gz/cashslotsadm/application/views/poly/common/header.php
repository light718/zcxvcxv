<a href="javascript:void(0);" class="logo hidden-xs">
    <!-- <span class="logo-mini">
        <img src=""></span>
    <span class="logo-lg"><b></b></span> -->
</a>
<nav class="navbar navbar-static-top" role="navigation">
    <a href="javascript:void(0);" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only"></span>
    </a>
    <div style="padding: 15px; color: White;">
        <span style="margin-left: 5px;"><i class="fa fa-user"></i><span style="margin-right: 10px;" class="m_uid" id="zongdai">&nbsp;&nbsp;&nbsp;<?php echo $account['username']; ?></span></span>
        
        <span class="badge bg-gray span_d" id="n1" style="display: none;"></span>
        <span class="badge bg-orange span_d" id="n2" style="display: none;"></span>
        <span class="badge bg-aqua span_d" id="n3" title="my current score" style=""><?php echo $language['my_coin']; ?>: <?php echo $account['coin']; ?></span>

        <span class="hidden-xs"><i class="fa fa-calendar-times-o"></i>&nbsp;&nbsp;&nbsp;<span id="localtime" style="color: White;"><font color="#ffffff"></font></span></span>
    </div>
</nav>