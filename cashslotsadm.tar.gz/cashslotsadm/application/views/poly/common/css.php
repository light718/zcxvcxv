<link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
<link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
<link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
<link rel="stylesheet" href="/poly/css/common.css" media="all">
<link rel="stylesheet" href="/poly/dist/css/skins/skin-purple.css">
<link rel="stylesheet" href="/poly/dist/plugins/sweetalert/sweetalert.css">