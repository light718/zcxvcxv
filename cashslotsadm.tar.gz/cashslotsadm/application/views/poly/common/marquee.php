<span class="text-danger">
    <marquee behavior="scroll" scrollamount="2" direction="left" onmouseover="this.stop()" onmouseout="this.start()"></marquee>
</span>