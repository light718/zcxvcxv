<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['value_setting']; ?></title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <style type="text/css">
        .form-control {
            font-size: 18px;
        }
        .table tbody tr td{
            vertical-align: middle;
        }
    </style>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['value_setting']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['value_setting']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header">
                        <ul id="myTab" class="nav nav-tabs">
                            <li class="active btn-nav"><a href="#game-data" data-toggle="tab"><?php echo $language['lucky_redbag_title']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#big-player" data-toggle="tab"><?php echo $language['rainy_redbag_title']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#big-winner" data-toggle="tab"><?php echo $language['growth_value_setting_title']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#jackpot-status" data-toggle="tab"><?php echo $language['lucky_box_setting_title']; ?></a></li>
                            <li class="dropdown visible-xs visible-sm">
                                <a href="javascript:void(0);" id="myTabDrop1" class="dropdown-toggle" data-toggle="dropdown"><?php echo $language['rainy_redbag_title']; ?>
                                    <b class="caret"></b>
                                </a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1">
                                    <li class="btn-nav-xs"><a href="#big-player" tabindex="-1" data-toggle="tab"><?php echo $language['rainy_redbag_title']; ?></a></li>
                                    <li class="btn-nav-xs"><a href="#big-winner" tabindex="-1" data-toggle="tab"><?php echo $language['growth_value_setting_title']; ?></a></li>
                                    <li class="btn-nav-xs"><a href="#jackpot-status" tabindex="-1" data-toggle="tab"><?php echo $language['lucky_box_setting_title']; ?></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="box-body">
                        <div id="myTabContent" class="tab-content">
                            <div class="tab-pane fade in active" id="game-data">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box box-solid box-primary">
                                        <div class="box-header with-border">
                                            <h3 class="box-title"><?php echo $language['lucky_redbag_title']; ?></h3>
                                            <div class="box-tools pull-right">
                                                <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                                            </div>
                                        </div>
                                        <div class="box-body table-responsive no-padding">
                                            <table class="table">
                                                <tbody id="lucky_tbody">
                                                    <tr>
                                                        <th class="text-center"><?php echo $language['lucky_redbag_min']; ?></th>
                                                        <th class="text-center"><?php echo $language['lucky_redbag_max']; ?></th>
                                                        <th class="text-center"><?php echo $language['lucky_redbag_prob']; ?></th>
                                                        <th class="text-center">#</th>
                                                    </tr>
                                                    <?php foreach ($lucky_list as $row) : ?>
                                                    <tr class="lucky_trbody">
                                                        <td><input type="text" class="form-control" name="min_value" maxlength="5" value="<?php echo $row['min_value']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="max_value" maxlength="5" value="<?php echo $row['max_value']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="prob" maxlength="5" value="<?php echo $row['prob']; ?>"></td>
                                                        <td><button type="button" class="btn btn-primary" onclick="deleteLine(this)"><?php echo $language['btn_delete']; ?></button></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="lucky-btn-save"><?php echo $language['btn_sure']; ?></button>
                                            <button type="button" class="btn btn-normal" id="lucky-btn-add"><?php echo $language['lucky_redbag_add']; ?></button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box box-solid box-primary">
                                        <div class="box-header with-border">
                                            <h3 class="box-title"><?php echo $language['lucky_redbag_share_title']; ?></h3>
                                            <div class="box-tools pull-right">
                                                <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                                            </div>
                                        </div>
                                        <div class="box-body table-responsive no-padding">
                                            <table class="table">
                                                <tbody id="share_nums_tbody">
                                                    <tr>
                                                        <th class="text-center"><?php echo $language['lucky_redbag_share_nums']; ?></th>
                                                        <th class="text-center"><?php echo $language['lucky_redbag_redbag_nums']; ?></th>
                                                        <th class="text-center">#</th>
                                                    </tr>
                                                    <?php foreach ($share_nums_list as $row) : ?>
                                                    <tr class="lucky_trbody">
                                                        <td><input type="text" class="form-control" name="share_nums" value="<?php echo $row['share_nums']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="redbag_nums" value="<?php echo $row['redbag_nums']; ?>"></td>
                                                        <td><button type="button" class="btn btn-primary" onclick="deleteLine(this)"><?php echo $language['btn_delete']; ?></button></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="share-nums-btn-save"><?php echo $language['btn_sure']; ?></button>
                                            <button type="button" class="btn btn-normal" id="share-nums-btn-add"><?php echo $language['lucky_redbag_add']; ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="big-player">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box">
                                        <div class="box-body table-responsive no-padding">
                                            <table class="table">
                                                <tbody id="rainy_tbody">
                                                    <tr>
                                                        <th class="text-center"><?php echo $language['rainy_redbag_min']; ?></th>
                                                        <th class="text-center"><?php echo $language['rainy_redbag_max']; ?></th>
                                                        <th class="text-center"><?php echo $language['rainy_redbag_prob']; ?></th>
                                                        <th class="text-center"><?php echo $language['rainy_redbag_min_prob']; ?></th>
                                                        <th class="text-center"><?php echo $language['rainy_redbag_max_prob']; ?></th>
                                                        <th class="text-center"><?php echo $language['rainy_redbag_other_prob']; ?></th>
                                                        <th class="text-center">#</th>
                                                    </tr>
                                                    <?php foreach ($rainy_list as $row) : ?>
                                                    <tr class="rainy_trbody">
                                                        <td><input type="text" class="form-control" name="min_value" value="<?php echo $row['min_value']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="max_value" value="<?php echo $row['max_value']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="prob" value="<?php echo $row['prob']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="min_prob" value="<?php echo $row['min_prob']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="max_prob" value="<?php echo $row['max_prob']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="other_prob" value="<?php echo $row['other_prob']; ?>"></td>
                                                        <td><button type="button" class="btn btn-primary" onclick="deleteLine(this)"><?php echo $language['btn_delete']; ?></button></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="rainy-btn-save"><?php echo $language['btn_sure']; ?></button>
                                            <button type="button" class="btn btn-normal" id="rainy-btn-add"><?php echo $language['rainy_redbag_add']; ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="big-winner">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box">
                                        <div class="box-body table-responsive no-padding">
                                            <table class="table">
                                                <tbody id="growth_value_tbody">
                                                    <tr>
                                                        <th class="text-center"><?php echo $language['growth_value_setting_star']; ?></th>
                                                        <th class="text-center"><?php echo $language['growth_value_setting_growth_value']; ?></th>
                                                        <th class="text-center"><?php echo $language['growth_value_setting_type']; ?></th>
                                                        <th class="text-center"><?php echo $language['growth_value_setting_free_game_id']; ?></th>
                                                        <th class="text-center"><?php echo $language['growth_value_setting_free_game_nums']; ?></th>
                                                        <th class="text-center"><?php echo $language['growth_value_setting_free_game_desc']; ?></th>
                                                        <th class="text-center">#</th>
                                                    </tr>
                                                    <?php foreach ($growth_value_list as $row) : ?>
                                                    <tr class="growth_value_trbody">
                                                        <td><input type="text" class="form-control" name="star" value="<?php echo $row['star']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="growth_value" value="<?php echo $row['growth_value']; ?>" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');"></td>
                                                        <td>
                                                            <select name="type" class="single-tag input-sm">
                                                                <option value="0"><?php echo $language['growth_value_setting_type']; ?></option>
                                                                <option value="1" <?php if ($row['type'] == 1) echo "selected";?>><?php echo $language['growth_value_setting_type_1']; ?></option>
                                                                <option value="2" <?php if ($row['type'] == 2) echo "selected";?>><?php echo $language['growth_value_setting_type_2']; ?></option>
                                                            </select>
                                                        </td>
                                                        <td><input type="text" class="form-control" name="free_game_id" value="<?php echo $row['free_game_id']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="free_game_nums" value="<?php echo $row['free_game_nums']; ?>"></td>
                                                        <td>
                                                            <textarea class="form-control" name="free_game_desc_1" style="width:300px;" rows="1" placeholder="cn"><?php echo $row['free_game_desc'][1]; ?></textarea>
                                                            <br />
                                                            <textarea class="form-control" name="free_game_desc_2" style="width:300px;" rows="1" placeholder="en"><?php echo $row['free_game_desc'][1]; ?></textarea>
                                                        </td>
                                                        <td><button type="button" class="btn btn-primary" onclick="deleteLine(this)"><?php echo $language['btn_delete']; ?></button></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="growth-value-btn-save"><?php echo $language['btn_sure']; ?></button>
                                            <button type="button" class="btn btn-normal" id="growth-value-btn-add"><?php echo $language['rainy_redbag_add']; ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="jackpot-status">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box">
                                        <div class="box-body table-responsive no-padding">
                                            <table class="table">
                                                <tbody id="lucky_box_tbody">
                                                    <tr>
                                                        <th class="text-center"><?php echo $language['lucky_box_setting_coin']; ?></th>
                                                        <th class="text-center"><?php echo $language['lucky_box_setting_prob']; ?></th>
                                                        <th class="text-center">#</th>
                                                    </tr>
                                                    <?php foreach ($lucky_box_list as $row) : ?>
                                                    <tr class="lucky_box_trbody">
                                                        <td><input type="text" class="form-control" name="coin" value="<?php echo $row['coin']; ?>"></td>
                                                        <td><input type="text" class="form-control" name="prob" value="<?php echo $row['prob']; ?>"></td>
                                                        <td><button type="button" class="btn btn-primary" onclick="deleteLine(this)"><?php echo $language['btn_delete']; ?></button></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="lucky-box-btn-save"><?php echo $language['btn_sure']; ?></button>
                                            <button type="button" class="btn btn-normal" id="lucky-box-btn-add"><?php echo $language['rainy_redbag_add']; ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/js/activity/value_setting.js"></script>
</html>