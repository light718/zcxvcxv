<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['rainy_redbag_setting_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <link rel="stylesheet" href="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.css" media="all">
    <style type="text/css">
        .form-control {
            font-size: 18px;
        }
    </style>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['rainy_redbag_setting_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['rainy_redbag_setting_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['rainy_redbag_setting_send_time']; ?></label>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal"><?php echo $language['rainy_redbag_setting_add_time']; ?></button>
                        </div>
                        <div class="form-group">
                            <div id="send_time">
                            </div>
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['rainy_redbag_setting_prob']; ?></label>
                            <input type="text" class="form-control ui-autocomplete-input" name="prob" autocomplete="off" placeholder="0 ~ 100">
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['rainy_redbag_setting_total']; ?></label>
                            <span class="badge bg-red" id="maxValue" style="cursor: pointer;"></span>
                            <input type="text" class="form-control ui-autocomplete-input" name="total" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['note']; ?></label>
                            <textarea rows="2" class="form-control" name="remark"></textarea>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                        <button type="button" class="btn btn-default" style="margin-left: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                    </div>
                </div>
                <div class="box box-primary" id="tb_list" style="display: block;">
                    <div class="box-header with-border">
                        <h3 class="box-title text-bold"><span class="badge bg-red"><?php echo $language['rainy_redbag_setting_record']; ?></span></h3>
                    </div>
                    <div class="box-body" style="display: block; padding: 0px;">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo $language['rainy_redbag_setting_send_time']; ?></th>
                                        <th><?php echo $language['rainy_redbag_setting_prob']; ?></th>
                                        <th><?php echo $language['rainy_redbag_setting_total']; ?></th>
                                        <th><?php echo $language['rainy_redbag_setting_status']; ?></th>
                                        <th><?php echo $language['rainy_redbag_setting_create_time']; ?></th>
                                        <th><?php echo $language['note']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="list"></tbody>
                            </table>
                        </div>
                        <div id="pager" class="pull-left"></div>
                    </div>
                    <div class="overlay" id="overlay" style="display: none;">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"><?php echo $language['rainy_redbag_setting_send_time']; ?></h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label><?php echo $language['search_start_date']; ?></label>
                        <?php if ($lang == 'english') : ?>
                        <input type="text" class="form-control" id="start-date" maxlength="10" onclick="WdatePicker({lang:'en'});">
                        <?php else : ?>
                        <input type="text" class="form-control" id="start-date" maxlength="10" onclick="WdatePicker({lang:'zh-cn'});">
                        <?php endif; ?>
                    </div>
                    <div class="bootstrap-timepicker">
                        <div class="form-group">
                            <label>- <?php echo $language['time']; ?></label>
                            <div class="input-group">
                                <input type="text" class="form-control timepicker" id="start-time">
                                <div class="input-group-addon">
                                    <i class="fa fa-clock-o"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label><?php echo $language['search_end_date']; ?></label>
                        <?php if ($lang == 'english') : ?>
                        <input type="text" class="form-control" id="end-date" maxlength="10" onclick="WdatePicker({lang:'en'});">
                        <?php else : ?>
                        <input type="text" class="form-control" id="end-date" maxlength="10" onclick="WdatePicker({lang:'zh-cn'});">
                        <?php endif; ?>
                    </div>
                    <div class="bootstrap-timepicker">
                        <div class="form-group">
                            <label>- <?php echo $language['time']; ?></label>
                            <div class="input-group">
                                <input type="text" class="form-control timepicker" id="end-time">
                                <div class="input-group-addon">
                                    <i class="fa fa-clock-o"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="btn-add-time"><?php echo $language['btn_sure']; ?></button>
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $language['btn_cancel']; ?></button>
                </div>
            </div>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
    <script src="/poly/dist/plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/js/activity/rainy_redbag_setting.js"></script>
</body>
</html>