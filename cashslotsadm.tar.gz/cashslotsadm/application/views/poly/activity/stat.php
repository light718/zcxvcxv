<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['stat_title']; ?></title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <style type="text/css">
        .form-control {
            font-size: 18px;
        }
        .table tbody tr td{
            vertical-align: middle;
        }
    </style>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['stat_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['stat_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header">
                        <ul id="myTab" class="nav nav-tabs">
                            <li class="active btn-nav"><a href="#game-data" data-toggle="tab"><?php echo $language['lucky_redbag']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#big-player" data-toggle="tab"><?php echo $language['rainy_redbag']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#big-winner" data-toggle="tab"><?php echo $language['lucky_box']; ?></a></li>
                            <li class="dropdown visible-xs visible-sm">
                                <a href="javascript:void(0);" id="myTabDrop1" class="dropdown-toggle" data-toggle="dropdown"><?php echo $language['lucky_redbag']; ?>
                                    <b class="caret"></b>
                                </a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1">
                                    <li class="btn-nav-xs"><a href="#big-player" tabindex="-1" data-toggle="tab"><?php echo $language['rainy_redbag']; ?></a></li>
                                    <li class="btn-nav-xs"><a href="#big-winner" tabindex="-1" data-toggle="tab"><?php echo $language['lucky_box']; ?></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="box-body">
                        <div id="myTabContent" class="tab-content">
                            <div class="tab-pane fade in active" id="game-data">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box box-default">
                                        <div class="box-body">
                                            <div class="form-group">
                                                <label><?php echo $language['search_start_date']; ?></label>
                                                <?php if ($lang == 'english') : ?>
                                                <input type="text" class="form-control" id="lucky-redbag-start-date" onclick="WdatePicker({lang:'en'});" value="<?php echo $start_date; ?>">
                                                <?php else : ?>
                                                <input type="text" class="form-control" id="lucky-redbag-start-date" onclick="WdatePicker({lang:'zh-cn'});" value="<?php echo $start_date; ?>">
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo $language['search_end_date']; ?></label>
                                                <?php if ($lang == 'english') : ?>
                                                <input type="text" class="form-control" id="lucky-redbag-end-date" onclick="WdatePicker({lang:'en'});" value="<?php echo $end_date; ?>">
                                                <?php else : ?>
                                                <input type="text" class="form-control" id="lucky-redbag-end-date" onclick="WdatePicker({lang:'zh-cn'});" value="<?php echo $end_date; ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="lucky-redbag-btn-sure"><?php echo $language['btn_sure']; ?></button>
                                        </div>
                                    </div>
                                    <div class="box box-primary" id="lucky-redbag-table" style="display: none;">
                                        <div class="box-body table-responsive no-padding">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped" id="tb_lucky_redbag">
                                                    <thead>
                                                        <tr>
                                                            <th><?php echo $language['date']; ?></th>
                                                            <!-- <th><?php echo $language['stat_lucky_redbag_share_nums']; ?></th>-->
                                                            <th><?php echo $language['stat_lucky_redbag_user_nums']; ?></th>
                                                            <th><?php echo $language['stat_lucky_redbag_send_nums']; ?></th>
                                                            <th><?php echo $language['stat_lucky_redbag_total_coin']; ?></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="lucky-redbag-list"></tbody>
                                                </table>
                                            </div>
                                            <div id="lucky-redbag-pager" class="pull-left"></div>
                                        </div>
                                        <div class="overlay" id="lucky-redbag-overlay" style="display: none;">
                                            <i class="fa fa-refresh fa-spin"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="big-player">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box box-default">
                                        <div class="box-body">
                                            <div class="form-group">
                                                <label><?php echo $language['search_start_date']; ?></label>
                                                <?php if ($lang == 'english') : ?>
                                                <input type="text" class="form-control" id="rainy-redbag-start-date" onclick="WdatePicker({lang:'en'});" value="<?php echo $start_date; ?>">
                                                <?php else : ?>
                                                <input type="text" class="form-control" id="rainy-redbag-start-date" onclick="WdatePicker({lang:'zh-cn'});" value="<?php echo $start_date; ?>">
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo $language['search_end_date']; ?></label>
                                                <?php if ($lang == 'english') : ?>
                                                <input type="text" class="form-control" id="rainy-redbag-end-date" onclick="WdatePicker({lang:'en'});" value="<?php echo $end_date; ?>">
                                                <?php else : ?>
                                                <input type="text" class="form-control" id="rainy-redbag-end-date" onclick="WdatePicker({lang:'zh-cn'});" value="<?php echo $end_date; ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="rainy-redbag-btn-sure"><?php echo $language['btn_sure']; ?></button>
                                        </div>
                                    </div>
                                    <div class="box box-primary" id="rainy-redbag-table" style="display: none;">
                                        <div class="box-body table-responsive no-padding">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped" id="tb_rainy_redbag">
                                                    <thead>
                                                        <tr>
                                                            <th><?php echo $language['date']; ?></th>
                                                            <th><?php echo $language['stat_rainy_redbag_send_nums']; ?></th>
                                                            <th><?php echo $language['stat_rainy_redbag_user_nums']; ?></th>
                                                            <th><?php echo $language['stat_rainy_redbag_total_coin']; ?></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="rainy-redbag-list"></tbody>
                                                </table>
                                            </div>
                                            <div id="rainy-redbag-pager" class="pull-left"></div>
                                        </div>
                                        <div class="overlay" id="lucky-redbag-overlay" style="display: none;">
                                            <i class="fa fa-refresh fa-spin"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="big-winner">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div class="box box-default">
                                        <div class="box-body">
                                            <div class="form-group">
                                                <label><?php echo $language['search_start_date']; ?></label>
                                                <?php if ($lang == 'english') : ?>
                                                <input type="text" class="form-control" id="lucky-box-start-date" onclick="WdatePicker({lang:'en'});" value="<?php echo $start_date; ?>">
                                                <?php else : ?>
                                                <input type="text" class="form-control" id="lucky-box-start-date" onclick="WdatePicker({lang:'zh-cn'});" value="<?php echo $start_date; ?>">
                                                <?php endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label><?php echo $language['search_end_date']; ?></label>
                                                <?php if ($lang == 'english') : ?>
                                                <input type="text" class="form-control" id="lucky-box-end-date" onclick="WdatePicker({lang:'en'});" value="<?php echo $end_date; ?>">
                                                <?php else : ?>
                                                <input type="text" class="form-control" id="lucky-box-end-date" onclick="WdatePicker({lang:'zh-cn'});" value="<?php echo $end_date; ?>">
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="box-footer">
                                            <button type="button" class="btn btn-primary" id="lucky-box-btn-sure"><?php echo $language['btn_sure']; ?></button>
                                        </div>
                                    </div>
                                    <div class="box box-primary" id="lucky-box-table" style="display: none;">
                                        <div class="box-body table-responsive no-padding">
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped" id="tb_lucky_box">
                                                    <thead>
                                                        <tr>
                                                            <th><?php echo $language['date']; ?></th>
                                                            <th><?php echo $language['stat_lucky_box_user_nums']; ?></th>
                                                            <th><?php echo $language['stat_lucky_box_total_coin']; ?></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="lucky-box-list"></tbody>
                                                </table>
                                            </div>
                                            <div id="lucky-box-pager" class="pull-left"></div>
                                        </div>
                                        <div class="overlay" id="lucky-redbag-overlay" style="display: none;">
                                            <i class="fa fa-refresh fa-spin"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
    <script src="/poly/js/activity/stat.js"></script>
</html>