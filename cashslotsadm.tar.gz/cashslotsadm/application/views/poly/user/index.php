<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h6 class="box-title" id="d_tip_1" style="font-size:0.9em;">
                            <span class="badge bg-red"><?php echo $account['username']; ?> - <?php echo $language['user_list']; ?></span>
                            <?php if (!isset($permission) || array_intersect(array(11), $permission)) : ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm"  href="/user/add" target="_self"><?php echo $language['add_user']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm btn-change-status"  href="javascript:void(0);" target="_self" data-status="1"><?php echo $language['btn_disable_all_player']; ?></a>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm btn-change-status"  href="javascript:void(0);" target="_self" data-status="2"><?php echo $language['btn_enable_all_player']; ?></a>
                            <?php endif; ?>
                            <span class="hidden-xs hidden-sm">　｜　</span>
                            <a class="hidden-xs hidden-sm" href="javascript:void(0);" onclick='javascript:reloadList();' target="_self"><?php echo $language['refresh_list']; ?></a>
                            <div class="margin visible-xs visible-sm">
                                <div class="btn-group">
                                    <button class="btn btn-default btn-flat" type="button"><?php echo $language['user_list'] . $language['menu']; ?></button>
                                    <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                        <span class="caret"></span>
                                        <span class="sr-only">Toggle Dropdown</span>
                                    </button>
                                    <ul role="menu" class="dropdown-menu">
                                        <?php if (!isset($permission) || array_intersect(array(11), $permission)) : ?>
                                        <li>
                                            <a href="/account/add" target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['add_user']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" target="_self" id="disable">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['btn_disable_all_player']; ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" target="_self" id="enable">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['btn_enable_all_player']; ?></span>
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="javascript:void(0);" onclick='javascript:reloadList();' target="_self">
                                                <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['refresh_list']; ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </h6>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i class="fa fa-minus"></i></button>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['player_uid'] . '/' . $language['player_username']; ?></label>
                            <input type="text" class="form-control" id="keywords">
                        </div>
                        <div class="form-group">
                            <button type="button" class="btn btn-primary" id="btn-sure"><?php echo $language['btn_sure']; ?></button>
                        </div>
                    </div>
                    <div class="box-footer">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped" id="tb_agent">
                                <thead>
                                    <tr>
                                        <th><?php echo $language['player_uid']; ?></th>
                                        <th><?php echo $language['player_username']; ?></th>
                                        <th><?php echo $language['column_nickname']; ?></th>
                                        <th><?php echo $language['column_coin']; ?></th>
                                        <th><?php echo $language['column_last_login']; ?></th>
                                        <th><?php echo $language['player_status']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                        <th class="visible-xs"><?php echo $language['player_uid']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="list"></tbody>
                            </table>

                        </div>
                        <!--Pager-->
                        <div id="pager" class="pull-left"></div>
                    </div>
                    <div class="overlay" id="overlay" style="display: none;">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/js/user/user_list.js"></script>
</body>
</html>