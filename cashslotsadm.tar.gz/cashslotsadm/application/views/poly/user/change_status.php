<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['status_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['status_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['status_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-body">
                        <h4>
                            <label><?php echo $language['coin_record_username']; ?>：</label>
                            <span class="text-success badge bg-gray" id="username" style="font-size: 1em;"><?php echo $username; ?></span>
                        </h4>
                        <h4>
                            <label><?php echo $language['coin_record_nickname']; ?>：</label>
                            <span class="text-success badge bg-gray" id="nickname" style="font-size: 1em;"><?php echo $nickname; ?></span>
                        </h4>
                    </div>
                </div>
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="col-xs-12 col-sm-6 col-sm-3">
                            <div class="form-group">
                                <label><?php echo $language['coin_record_user_status']; ?></label>
                                <span class="badge bg-gray" id="status" style="font-size: 1em;"></span>
                                <span class="loading" style="display: none;">
                                    <img alt="Loading..." src="/poly/images/loading_1.gif" align="absmiddle" style="margin-left: 10px;" />
                                </span>
                            </div>
                            <div class="form-group">
                                <label><?php echo $language['coin_record_coin']; ?></label>
                                <span class="badge bg-gray" id="coin" style="font-size: 1em;"></span>
                                <span class="loading" style="display: none;">
                                    <img alt="Loading..." src="/poly/images/loading_1.gif" align="absmiddle" style="margin-left: 10px;" />
                                </span>
                            </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-sm-9">
                            <button type="button" class="btn btn-primary" id="btn-refresh-detail"><?php echo $language['btn_refresh']; ?></button>
                            <?php if ($status == 0) : ?>
                            <button type="button" class="btn btn-warning" style="margin-left: 15px;" id="btn-off-line"><?php echo $language['off_line']; ?></button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="box box-warning">
                    <?php if ($status == 0) : ?>
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['status_notice02']; ?></label>
                        </div>
                        <div class="form-group">
                            <button type="button" class="btn btn-primary btn-change-status" data-type="forbidden"><?php echo $language['status_btn_forbidden']; ?></button>
                        </div>
                    </div>
                    <?php else : ?>
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['status_notice03']; ?></label>
                        </div>
                        <div class="form-group">
                            <button type="button" class="btn btn-primary btn-change-status" data-type="normal"><?php echo $language['status_btn_normal']; ?></button>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/js/user/change_status.js"></script>
</html>