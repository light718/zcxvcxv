<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['edit_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['edit_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['edit_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['parent_agent']; ?></label>                            
                            <p><span class="badge bg-gray" id="agent" style="font-size:1em;"><?php echo $account['username']; ?></span></p>
                        </div>
            
                        <div class="form-group">
                            <label><?php echo $language['username']; ?></label>
                            <p><span class="badge bg-gray" id="username" style="font-size:1em;"><?php echo $player['account_pid']; ?></span></p>
                        </div>            

                        <div class="form-group">
                            <label><?php echo $language['password']; ?></label>
                            <input type="text" class="form-control" id="password" maxlength="15" value="********"/>
                            <p id="p1"></p>
                        </div>           

                        <div class="form-group">
                            <label><?php echo $language['nickname']; ?></label>
                            <input type="text" class="form-control" id="nickname" maxlength="20" value="<?php echo $player['account_nickname']; ?>"/>
                        </div>

                        <div class="form-group">
                            <label><?php echo $language['tel']; ?></label>
                            <input type="text" class="form-control" id="tel" maxlength="20" value="<?php echo isset($player['account_phone']) ? $player['account_phone'] : ''; ?>"/>
                        </div>

                        <div class="form-group">
                            <label><?php echo $language['note']; ?></label>
                            <textarea rows="2" class="form-control" id="note" ><?php echo isset($player['account_remark']) ? $player['account_remark'] : ''; ?></textarea>
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                    </div>

                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/js/user/edit.js"></script>
</html>