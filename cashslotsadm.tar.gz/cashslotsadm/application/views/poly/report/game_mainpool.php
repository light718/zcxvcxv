<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_mainpool']; ?></title>
    <link rel="stylesheet" href="/poly/dist/plugins/select2/css/select2.min.css" media="all">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <style>
        .stc_1{
            background: #01AAED;
            color:#FFF;
        }
        .stc_2{
            background: #2F4056;
            color:#FFF;
        }
        .stc_3{
            background: #5FB878;
            color:#FFF;
        }
        .stc_4{
            background: #009688;
            color:#FFF;
        }
        .stc_5{
            background: #2332e5;
            color:#FFF;
        }
        .stc_6{
            background: #FF5722;
            color:#FFF;
        }
        .row-block {
            width: 160px;
            display: inline-block;
            margin-right: 10px;
        }
    </style>
</head>
<body class="skin-purple">
<div class="wrapper">
    <header class="main-header">
        <?php require APPPATH . "/views/poly/common/header.php"; ?>
    </header>

    <aside class="main-sidebar">
        <?php require APPPATH . "/views/poly/common/menu.php"; ?>
    </aside>

    <div class="main-footer hidden-xs bg-gray-light">
        <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
    </div>

    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content-header">
            <h1 class="hidden-xs"><?php echo $language['menu_mainpool']; ?>
                <small style="margin-left: 8px; margin-right: 8px;">
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                </small>
            </h1>
            <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                <li>
                    <?php echo $language['menu_mainpool']; ?>&nbsp;&nbsp;&nbsp;
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                        <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                    </a>
                </li>
            </ol>
        </section>
        <section class="content">
            <div class="box box-primary">
                <div class="box-header">
                    <form class="form-inline">
                        <div class="form-group">
                            <label><?php echo $language['please_select_date']; ?></label>
                        </div>
                        <div class="form-group">
                            <?php if ($lang == 'english') : ?>
                            <input type="text" class="form-control" id="date" onclick="WdatePicker({lang:'en', onpicked:function() {getData();}});" value="<?php echo date('Y-m-d'); ?>">
                            <?php else : ?>
                            <input type="text" class="form-control" id="date" onclick="WdatePicker({lang:'zh-cn', onpicked:function() {getData();}});" value="<?php echo date('Y-m-d'); ?>">
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
                <div class="box-body with-border text-contain" style="overflow: hidden;max-height: 210px;">
                    <div class="form-group top-div" id="list">
                        <div class="small-box row-block stc_1">
                            <div class="inner">
                                <h5><?php echo $language['game_mainpool_total_coin']; ?></h5>
                                <p><?php echo $total_coin; ?></p>
                            </div>
                        </div>
                        <?php foreach ($game_list as $row) : ?>
                            <div class="small-box row-block <?php echo $row['color_css']; ?>">
                                <div class="inner">
                                    <h5><?php echo $row['name']; ?></h5>
                                    <p><?php echo $row['coin']; ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="box-footer">
                    <p style="text-align:center;margin-top: 5px;"><a id="display" style="display: none;" title="展开"><img id="display-img" src="/poly/images/display.png" width="20px;"></a></p>
                </div>
            </div>
            <div class="box box-primary">
                <div class="box-header with-border">
                    <form class="form-inline">
                        <div class="form-group">
                            <select class="form-control select2" id="game">
                            </select>
                        </div>
                    </form>
                </div>
                <div class="box-body">
                    <div id="game-mainpool-container" style="height: 500px;"></div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/dist/js/laypage.js"></script>
<script src="/poly/dist/plugins/select2/js/select2.full.min.js"></script>
<script src="/poly/dist/plugins/echarts/echarts.min.js"></script>
<script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
<script src="/poly/js/report/game_mainpool.js"></script>
</body>
</html>