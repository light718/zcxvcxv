<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['report_title']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['report_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['report_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <div class="box box-default">
                    <div class="box-header">
                        <ul id="myTab" class="nav nav-tabs">
                            <li class="active btn-nav"><a href="#game-data" data-toggle="tab"><?php echo $language['report_sub_title_01']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#big-player" data-toggle="tab"><?php echo $language['report_sub_title_02']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#big-winner" data-toggle="tab"><?php echo $language['report_sub_title_03']; ?></a></li>
                            <li class="hidden-xs hidden-sm btn-nav"><a href="#jackpot-status" data-toggle="tab"><?php echo $language['report_sub_title_04']; ?></a></li>
                            <li class="dropdown visible-xs visible-sm">
                                <a href="javascript:void(0);" id="myTabDrop1" class="dropdown-toggle" data-toggle="dropdown"><?php echo $language['report_sub_title_02']; ?>
                                    <b class="caret"></b>
                                </a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="myTabDrop1">
                                    <li class="btn-nav-xs"><a href="#big-player" tabindex="-1" data-toggle="tab"><?php echo $language['report_sub_title_02']; ?></a></li>
                                    <li class="btn-nav-xs"><a href="#big-winner" tabindex="-1" data-toggle="tab"><?php echo $language['report_sub_title_03']; ?></a></li>
                                    <li class="btn-nav-xs"><a href="#jackpot-status" tabindex="-1" data-toggle="tab"><?php echo $language['report_sub_title_04']; ?></a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="box-body">
                        <div id="myTabContent" class="tab-content">
                            <div class="tab-pane fade in active" id="game-data">
                                <div class="form-group">
                                    <a class="hidden-xs hidden-sm btn-date-time btn-success" href="javascript:void(0);" data-type="1"><?php echo $language['report_condition_01']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="2"><?php echo $language['report_condition_02']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="3"><?php echo $language['report_condition_03']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="4"><?php echo $language['report_condition_04']; ?></a>
                                    <div class="margin visible-xs visible-sm">
                                        <div class="btn-group">
                                            <button class="btn btn-default btn-flat btn-date-time-xs-selected" type="button"><?php echo $language['report_condition_01']; ?></button>
                                            <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                            </button>
                                            <ul role="menu" class="dropdown-menu">
                                                <li class="btn-date-time-xs" data-type="1">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_01']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="2">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_02']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="3">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_03']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="4">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_04']; ?></span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th><?php echo $language['report_column_game_name']; ?></th>
                                                    <th><?php echo $language['report_column_au']; ?></th>
                                                    <th><?php echo $language['report_column_bet_number']; ?></th>
                                                    <th><?php echo $language['report_column_bet']; ?></th>
                                                    <th><?php echo $language['report_column_win']; ?></th>
                                                    <th><?php echo $language['report_column_system_win_rate']; ?></th>
                                                    <th><?php echo $language['report_column_system_win_coin_rate']; ?></th>
                                                </tr>
                                            </thead>
                                            <tbody id="list"></tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="overlay" id="overlay" style="display: none;">
                                    <i class="fa fa-refresh fa-spin"></i>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="big-player">
                                <div class="form-group">
                                    <a class="hidden-xs hidden-sm btn-date-time btn-success" href="javascript:void(0);" data-type="1"><?php echo $language['report_condition_01']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="2"><?php echo $language['report_condition_02']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="3"><?php echo $language['report_condition_03']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="4"><?php echo $language['report_condition_04']; ?></a>
                                    <div class="margin visible-xs visible-sm">
                                        <div class="btn-group">
                                            <button class="btn btn-default btn-flat btn-date-time-xs-selected" type="button"><?php echo $language['report_condition_01']; ?></button>
                                            <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                            </button>
                                            <ul role="menu" class="dropdown-menu">
                                                <li class="btn-date-time-xs" data-type="1">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_01']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="2">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_02']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="3">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_03']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="4">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_04']; ?></span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th><?php echo $language['username']; ?></th>
                                                    <th><?php echo $language['nickname']; ?></th>
                                                    <th><?php echo $language['player_coin']; ?></th>
                                                    <th><?php echo $language['report_column_last_login_time']; ?></th>
                                                    <th><?php echo $language['report_column_bet']; ?></th>
                                                    <th><?php echo $language['report_column_win']; ?></th>
                                                    <th><?php echo $language['table_column_search']; ?></th>
                                                </tr>
                                            </thead>
                                            <tbody id="list"></tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="overlay" id="overlay" style="display: none;">
                                    <i class="fa fa-refresh fa-spin"></i>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="big-winner">
                                <div class="form-group">
                                    <a class="hidden-xs hidden-sm btn-date-time btn-success" href="javascript:void(0);" data-type="1"><?php echo $language['report_condition_01']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="2"><?php echo $language['report_condition_02']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="3"><?php echo $language['report_condition_03']; ?></a>
                                    <span class="hidden-xs hidden-sm">　｜　</span>
                                    <a class="hidden-xs hidden-sm btn-date-time" href="javascript:void(0);" data-type="4"><?php echo $language['report_condition_04']; ?></a>
                                    <div class="margin visible-xs visible-sm">
                                        <div class="btn-group">
                                            <button class="btn btn-default btn-flat btn-date-time-xs-selected" type="button"><?php echo $language['report_condition_01']; ?></button>
                                            <button data-toggle="dropdown" class="btn btn-default btn-flat dropdown-toggle" type="button">
                                                <span class="caret"></span>
                                                <span class="sr-only">Toggle Dropdown</span>
                                            </button>
                                            <ul role="menu" class="dropdown-menu">
                                                <li class="btn-date-time-xs" data-type="1">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_01']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="2">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_02']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="3">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_03']; ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li class="btn-date-time-xs" data-type="4">
                                                    <a href="javascript:void(0);">
                                                        <span class="text-bold"><i class="fa fa-angle-right"></i> <?php echo $language['report_condition_04']; ?></span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th><?php echo $language['username']; ?></th>
                                                    <th><?php echo $language['nickname']; ?></th>
                                                    <th><?php echo $language['player_coin']; ?></th>
                                                    <th><?php echo $language['report_column_last_login_time']; ?></th>
                                                    <th><?php echo $language['report_column_bet']; ?></th>
                                                    <th><?php echo $language['report_column_win']; ?></th>
                                                    <th><?php echo $language['table_column_search']; ?></th>
                                                </tr>
                                            </thead>
                                            <tbody id="list"></tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="overlay" id="overlay" style="display: none;">
                                    <i class="fa fa-refresh fa-spin"></i>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="jackpot-status">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h3 class="box-title"><?php echo $language['report_tips_01']; ?></h3>
                                        <div class="box-tools pull-right">
                                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="box-body">
                                        <div id="poolnormal-container" style="height: 300px;"></div>
                                    </div>
                                </div>
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h3 class="box-title"><?php echo $language['report_tips_03']; ?></h3>
                                        <div class="box-tools pull-right">
                                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="box-body">
                                        <div id="jackpot-container" style="height: 300px;"></div>
                                    </div>
                                </div>
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h3 class="box-title"><?php echo $language['report_tips_05']; ?></h3>
                                        <div class="box-tools pull-right">
                                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="box-body">
                                        <div id="pooltax-container" style="height: 300px;"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/dist/plugins/echarts/echarts.min.js"></script>
    <script src="/poly/js/report/game_data.js"></script>
</body>
</html>