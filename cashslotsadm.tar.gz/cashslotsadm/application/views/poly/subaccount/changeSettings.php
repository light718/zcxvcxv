<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['subaccount_btn_edit']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
    <div class="wrapper">
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content">
                <div class="box box-default">
                    <span class="badge bg-gray" id="username" style="display: none;"><?php echo $account_user['virtual_username']; ?></span>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo $language['subaccount_desc']; ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-bold text-blue">Default</td>
                                    <td class="text-left text-bold text-blue"><?php echo $language['subaccount_permission_0_title']; ?></td>
                                </tr>
                                <?php $i = 0; ?>
                                <?php foreach ($gids as $key=>$gid) : ?>
                                <?php $i++; ?>
                                <tr>
                                    <td><input type="checkbox" name="gids[]" value="<?php echo $key; ?>" <?php if (in_array($key, explode(',', $account_user['virtual_group_id']))) : ?>checked<?php endif; ?>></td>
                                    <td class="text-left"><span class="badge bg-blue"><?php echo $i; ?></span>：<?php echo $gid; ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <tr>
                                    <td>
                                        <div class="direct-chat-text bg-red msg" style="display: none;"></div>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-primary btn-block" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/js/subaccount/edit.js"></script>
</body>
</html>