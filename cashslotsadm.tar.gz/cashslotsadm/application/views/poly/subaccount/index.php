<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_subaccount']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <link rel="stylesheet" type="text/css" href="/poly/dist/plugins/artDialog4/skins/black.css">
</head>
<body class="skin-purple">
    <div class="wrapper">
        <header class="main-header">
            <?php require APPPATH . "/views/poly/common/header.php"; ?>
        </header>

        <aside class="main-sidebar">
            <?php require APPPATH . "/views/poly/common/menu.php"; ?>
        </aside>

        <div class="main-footer hidden-xs bg-gray-light">
            <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
        </div>
        
        <div class="content-wrapper" style="min-height: 868px;">
            <section class="content-header">
                <h1 class="hidden-xs"><?php echo $language['subaccount_title']; ?>
                    <small style="margin-left: 8px; margin-right: 8px;">
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                    </small>
                </h1>
                <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                    <li>
                        <?php echo $language['subaccount_title']; ?>&nbsp;&nbsp;&nbsp;
                        <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                            <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                        </a>
                    </li>
                </ol>
            </section>
            <section class="content">
                <?php if ((!isset($permission) || array_intersect(array(3), $permission))) : ?>
                <div class="box box-default">
                    <div class="box-body">
                        <div class="form-group">
                            <label><?php echo $language['subaccount_username']; ?></label>
                            <input type="text" class="form-control" id="username" maxlength="17">
                            <p id="p1"></p>
                        </div>

                        <div class="form-group">
                            <label><?php echo $language['password']; ?></label>
                            <input type="text" class="form-control" id="password" maxlength="15">
                            <p id="p2"></p>
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['note']; ?></label>
                            <textarea rows="2" class="form-control" id="nickname"></textarea>
                        </div>
                    </div>
                    <div class="box-body" style="display: block;">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo $language['subaccount_desc']; ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($account['agent'] != 3) : ?>
                                    <tr>
                                        <td class="text-bold text-blue">Default</td>
                                        <td class="text-left text-bold text-blue"><?php echo $language['subaccount_permission_0_title']; ?></td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php $i = 0; ?>
                                    <?php foreach ($gids as $key=>$gid) : ?>
                                    <?php $i++; ?>
                                    <tr>
                                        <td><input type="checkbox" name="gids[]" value="<?php echo $key; ?>"></td>
                                        <td class="text-left"><span class="badge bg-blue"><?php echo $key; ?></span>：<?php echo $gid; ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="button" class="btn btn-primary" id="btn-save"><?php echo $language['btn_sure']; ?></button>
                        <button type="button" class="btn btn-default" style="margin-left: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                    </div>
                </div>
                <?php endif; ?>
                <div class="box box-primary" id="tb_list" style="display: block;">
                    <div class="box-header with-border">
                        <h3 class="box-title text-bold"><span class="badge bg-red"><?php echo $language['subaccount_table_title']; ?></span></h3>
                    </div>
                    <div class="box-body" style="display: block; padding: 0px;">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo $language['table_column_username']; ?></th>
                                        <th><?php echo $language['table_column_permission']; ?></th>
                                        <th><?php echo $language['note']; ?></th>
                                        <th><?php echo $language['create_time']; ?></th>
                                        <th><?php echo $language['table_column_handle']; ?></th>
                                    </tr>
                                </thead>
                                <tbody id="list"></tbody>
                            </table>
                        </div>
                        <div id="pager" class="pull-left"></div>
                    </div>
                    <div class="overlay" id="overlay" style="display: none;">
                        <i class="fa fa-refresh fa-spin"></i>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
    <script src="/poly/dist/plugins/artDialog4/artDialog.js"></script>
    <script src="/poly/dist/plugins/artDialog4/plugins/iframeTools.js"></script>
    <script src="/poly/dist/js/laypage.js"></script>
    <script src="/poly/js/subaccount/subaccount_list.js"></script>
    <script type="text/javascript">
        var enable = 0;
        <?php if (!isset($permission) || array_intersect(array(4), $permission)) : ?>
            enable = 1
        <?php endif; ?>

        var editAccount = 0;
        <?php if (!isset($permission) || array_intersect(array(5), $permission)) : ?>
            editAccount = 1
        <?php endif; ?>
    </script>
</body>
</html>