<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top:3px;">
                        <tbody>
                            <tr>
                                <td class="text-right"><?php echo $language['player_card']; ?>:</td>
                                <td>
                                <?php foreach ($rlt['result'][0]['cards'] as $row) : ?>
                                    <img src="/poly/images/poker/<?php echo $row; ?>.png" />
                                <?php endforeach; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['banker_card']; ?>:</td>
                                <td>
                                <?php foreach ($rlt['result'][1]['cards'] as $row) : ?>
                                    <img src="/poly/images/poker/<?php echo $row; ?>.png" />
                                <?php endforeach; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['player_bet']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][0]); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['dogfall_bet']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][1]); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['banker_bet']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][2]); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['player_pair']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][3]); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['banker_pair']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][4]); ?>
                                </td>
                            </tr>
                            <?php if ($online == 0) : ?>
                            <tr>
                                <td class="text-right"><?php echo $language['big']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][5]); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['small']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][6]); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['any_pair']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][7]); ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['perfect_pair']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet'][8]); ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
