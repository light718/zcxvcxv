<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <tbody>
                            <tr>
                                <td class="text-right"><?php echo $language['niuniu_tip_01']; ?>:</td>
                                <td><?php echo implode(', ', array_map("formatMoney", $bet)); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['niuniu_tip_02']; ?>:</td>
                                <td><?php echo implode(', ', array_map("formatMoney", $win)); ?></td>
                            </tr>
                            <?php foreach ($cards as $key => $row) : ?>
                            <?php if ($key == 0) : ?>
                            <tr>
                                <td class="text-right"><?php echo $language['bank_5_card']; ?>:</td>
                                <td>
                                    <?php foreach ($row['cards'] as $card) : ?>
                                    <img src="/poly/images/poker/<?php echo $card; ?>.png"/> 
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['bank_card_01']; ?>:</td>
                                <td><?php echo $row['type']; ?></td>
                            </tr>
                            <?php else : ?>
                            <tr>
                                <td class="text-right"><?php echo $language['player_5_card']; ?><?php echo $key; ?>:</td>
                                <?php if (empty($row['cards'])) : ?>
                                <td>N/A</td>
                                <?php else : ?>
                                <td>
                                    <?php foreach ($row['cards'] as $card) : ?>
                                    <img src="/poly/images/poker/<?php echo $card; ?>.png"/> 
                                    <?php endforeach; ?>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['player_card_01']; ?>:</td>
                                <?php if (empty($row['cards'])) : ?>
                                <td>N/A</td>
                                <?php else : ?>
                                <td><?php echo $row['type']; ?></td>
                                <?php endif; ?>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
