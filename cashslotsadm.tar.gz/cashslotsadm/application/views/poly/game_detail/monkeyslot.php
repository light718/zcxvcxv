<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                            <tr>
                                <td>
                                    <table class="table table-bordered" style="width:auto;maxwidth:150px; margin:auto;">
                                        <tbody>
                                            <?php for ($i = 1; $i < 2; $i++) : ?>
                                            <tr>
                                                <?php for ($j = 0 ; $j < $x_line; $j++) : ?>
                                                <td><img style="width:44px;height:44px;" src="/poly/images/<?php echo $game_id; ?>/<?php echo generateIconName($resultCards[$i * $x_line + $j]); ?>" /></td>
                                                <?php endfor; ?>
                                            </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <thead>
                            <tr>
                                <th><?php echo $language['bet_info']; ?></th>
                                <th><?php echo $language['bet_mult']; ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo formatMoney($bet_line['singleBet']); ?></td>
                                <td><?php echo formatMoney($bet_line['mult']); ?></td>
                            </tr>
                            <?php if($win > 0) {
                                ?>
                           
                            <!-- <tr>
                                <td class="text-bold text-blue">Total:</td>
                                <td class="text-bold text-blue"><?php echo formatMoney($win); ?></td>
                            </tr> -->
                             <?php

                        }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
</body>
</html>