<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <tbody>
                            <tr>
                                <td class="text-right"><?php echo $language['total_bet']; ?>：</td>
                                <td><?php echo formatMoney($bet); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['total_win']; ?>：</td>
                                <td><?php echo formatMoney($win); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['banker_card']; ?>：</td>
                                <td>
                                <?php foreach ($rlt['result']['cards'][0] as $row) : ?>
                                <img src="/poly/images/poker/<?php echo $row; ?>.png"/>
                                <?php endforeach; ?>
                                </td>
                            </tr>
                            <?php foreach (array_slice($rlt['result']['cards'], 1, 5) as $key => $value) : ?>
                            <tr>
                                <td class="text-right"><?php echo $number[$key]; ?>：</td>
                                <td>
                                <?php foreach ($value as $row) : ?>
                                <img src="/poly/images/poker/<?php echo $row; ?>.png"/>
                                <?php endforeach; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['bet_and_win']; ?>：</td>
                                <td>
                                <?php echo implode(', ', array_map('formatMoney', array_slice($rlt['bet'][$key], 0, 2))); ?>
                                ,
                                <?php echo implode(', ', array_map('formatMoney', array_slice($rlt['win'][$key], 0, 2))); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
