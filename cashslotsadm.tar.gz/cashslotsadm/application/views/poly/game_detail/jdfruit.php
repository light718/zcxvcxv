<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
    <style type="text/css">
        .tb_info {
            width: 360px;
            margin: 0 auto;
            padding: 0;
        }

        .tb_List {
            width: 360px;
            margin: 0 auto;
            padding: 0;
            background: #fff;
            border: 1px solid #F5F5F5;
        }

        .tb_List td {
            line-height: 20px;
            height: 20px;
            color: #ffffff;
        }

        .td_div ul {
            list-style: none;
            margin: 0 auto;
            padding: 0;
            text-align: center;
        }

        .td_div ul li {
            line-height: 11px;
            font-weight: bold;
            font-size: 9px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left">
                                    <?php foreach ($rlt['result'] as $row) : ?>
                                    <img class="img-responsive center-block" src="/poly/images/jdfruit/<?php echo $row['index']; ?>.png" />
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left">送灯编号:N/AN/A,N/A,N/A,N/A,N/A,N/A</td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="tb_info">
                        <table border="1" cellspacing="1" cellpadding="1" class="tb_List">
                            <?php for ($i = 0; $i < 2; $i++) : ?>
                            <tr>
                                <td style="width: 80px; background-color: #4D4D4D;"><?php echo $language['info']; ?></td>
                                <?php for ($j = 1; $j <= 4; $j++) : ?>
                                <td style="width: 80px;">
                                    <img style="height: 35px;" class="img-responsive center-block" src="/poly/images/jdfruit/<?php echo $j + 4*$i; ?>.png" />
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>
                                    <div class="text-danger text-sm text-green"><?php echo $language['place']; ?>:</div>
                                    <div class="text-danger text-sm text-green"><?php echo $language['bet']; ?>:</div>
                                    <div class="text-danger text-sm text-red"><?php echo $language['win']; ?>:</div>
                                </td>
                                <?php for ($k = 1; $k <= 4; $k++) : ?>
                                <td>
                                    <div class="text-danger text-sm text-blue"><?php echo $rlt['odds'][$k + 4*$i - 1]; ?></div>
                                    <div class="text-danger text-sm text-green"><?php echo formatMoney($rlt['bet'][$k + 4*$i - 1]); ?></div>
                                    <div class="text-danger text-sm text-red"><?php echo formatMoney($rlt['win'][$k + 4*$i - 1]); ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <?php endfor; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
