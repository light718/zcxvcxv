<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
    <style type="text/css">
        .tb_info {
            width: 360px;
            height: 145px;
            margin: 0 auto;
            padding: 0;
        }

        .tb_List {
            width: 360px;
            margin: 0 auto;
            padding: 0;
        }

            .tb_List td {
                height: 40px;
                line-height: 40px;
                color: #ffffff;
            }

        .td_div ul {
            list-style: none;
            margin: 0 auto;
            padding: 0;
            text-align: center;
        }

            .td_div ul li {
                line-height: 11px;
                font-weight: bold;
                font-size: 9px;
                margin-bottom: 5px;
            }

    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['ranking']; ?>: <span class="badge bg-black" style="margin-right: 5px;"><?php 
                                $rankplace = implode(',', $rlt['result']['rankplace']);
                                echo $rankplace; ?></span></td>
                                <td class="text-left"><?php echo $language['place']; ?>: <span class="badge bg-black" style="margin-right: 5px;"><?php echo $rlt['result']['multiple']; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['gold']; ?>: <span class="badge bg-black" style="margin-right: 5px;"><?php echo $rlt['result']['goldennum']; ?></span> - <?php echo $language['out']; ?>：<span class="badge bg-black"><?php echo $rlt['result']['out']; ?></span></td>
                                <td class="text-left"><?php echo $language['total_jackpot']; ?>: <span class="badge bg-black" style="margin-right: 5px;"><?php echo $rlt['result']['jackpot']; ?></span></td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="tb_info" style="background: url(/poly/images/240.png) no-repeat center; padding: 0px 0 0 0;width:360px; height:240px; background-size:360px 260px;">
                        <table border="0" cellspacing="0" cellpadding="0" class="tb_List">
                            <tr>
                                <td style="width: 35px;"></td>
                                <td style="width: 92px;"></td>
                                <td style="width: 92px;"></td>
                                <td style="width: 92px;"></td>
                                <td style="width: 92px;"></td>
                                <td style="width: 92px;"></td>
                            </tr>
                            <?php $index = 0; ?>
                            <?php for ($i = 0; $i < 5; $i++) : ?>
                            <tr>
                                <td style="width: 35px;"></td>
                                <?php for ($j = 5 - $i; $j > 0; $j--) : ?>
                                <td>
                                    <div class="td_div">
                                        <ul>
                                            <li><span style="color: Red;"><?php echo $rlt['odds'][$index]; ?></span></li>
                                            <li><?php echo $rlt['bet'][$index]; ?></li>
                                        </ul>
                                    </div>
                                </td>
                                <?php $index++; ?>
                                <?php endfor; ?>
                            </tr>
                            <?php endfor; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
