<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                            <tr>
                                <td>
                                    <span class="badge bg-aqua text-bold"><?php echo $rlt['winplace']; ?></span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <thead>
                            <tr>
                                <th><?php echo $language['info']; ?></th>
                                <th><?php echo $language['bet']; ?></th>
                                <th><?php echo $language['win']; ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rlt['rs'] as $row) : ?>
                            <?php if ($row['win'] > 0) : ?>
                            <tr id="r_show">
                                <td><?php echo $row['bet_site']; ?></td>
                                <td><?php echo $row['bet']; ?></td>
                                <td class="text-red"><?php echo $row['win']; ?></td>
                            </tr>
                            <?php else : ?>
                            <tr id="r_show">
                                <td><?php echo $row['bet_site']; ?></td>
                                <td><?php echo $row['bet']; ?></td>
                                <td><?php echo $row['win']; ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
