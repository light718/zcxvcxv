<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <tbody>
                            <tr>
                                <td class="text-right"><?php echo $language['bureau_bet']; ?>:</td>
                                <td><?php echo formatMoney($rlt['bet']['bet']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['bureau_win']; ?>:</td>
                                <td><?php echo formatMoney($rlt['win']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['banker_card']; ?>:</td>
                                <td>
                                <?php foreach ($rlt['result'][0]['cards'] as $row) : ?>
                                    <img src="/poly/images/poker/<?php echo $row; ?>.png"/>  
                                <?php endforeach; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['banker_cardtype']; ?>:</td>
                                <td><?php echo $rlt['result'][0]['cardtype']; ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['banker_blackjack']; ?>:</td>
                                <td><?php echo $rlt['result'][0]['blackjack']; ?></td>
                            </tr>
                            <?php foreach (array_slice($rlt['result'], 1, 5) as $row) : ?>
                            <tr>
                                <td class="text-right"><?php echo $language['player_card']; ?>:</td>
                                <td>
                                <?php foreach ($row['cards'] as $card) : ?>
                                    <img src="/poly/images/poker/<?php echo $card; ?>.png"/>  
                                <?php endforeach; ?>
                                </td>    
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['player_cardtype']; ?>:</td>
                                <td><?php echo $row['cardtype']; ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['player_blackjack']; ?>:</td>
                                <td><?php echo $row['blackjack']; ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['issafe']; ?>:</td>
                                <td><?php if ($row['issafe'] == 0) : ?>NO<?php else : ?>YES<?php endif; ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['haddouble']; ?>:</td>
                                <td><?php if ($row['haddouble'] == 0) : ?>NO<?php else : ?>YES<?php endif; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
