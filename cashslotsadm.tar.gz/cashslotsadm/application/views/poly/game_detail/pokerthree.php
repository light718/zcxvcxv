<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <tbody>
                            <tr>
                                <td class="text-right"><?php echo $language['bank_3_card']; ?>:</td>
                                <td>
                                <?php foreach ($rlt['result']['cards'][0]['card'] as $row) :?>
                                <img src="/poly/images/poker/<?php echo $row; ?>.png"/>  
                                <?php endforeach; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['bank_card']; ?>:</td>
                                <td><?php echo $cardType[$rlt['result']['cards'][0]['type']]; ?></td>
                            </tr>
                            <?php foreach (array_slice($rlt['result']['cards'], 1, 3) as $key => $row) :?>
                            <tr>
                                <td class="text-right"><?php echo $language['duizi_bet_win']; ?>(<?php echo $key + 1;?>):</td>
                                <td><?php echo $language['bet']; ?>: <?php echo formatMoney($rlt['bet'][$key][0]); ?> -  <?php echo $language['win']; ?>:<?php echo formatMoney($rlt['win'][$key][0]); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['pang_bet_win']; ?>(<?php echo $key + 1;?>):</td>
                                <td><?php echo $language['bet']; ?>: <?php echo formatMoney($rlt['bet'][$key][1]); ?> -  <?php echo $language['win']; ?>:<?php echo formatMoney($rlt['win'][$key][1]); ?></td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['follow_bet_win']; ?>(<?php echo $key + 1;?>):</td>
                                <td><?php echo $language['bet']; ?>: <?php echo formatMoney($rlt['bet'][$key][2]); ?> -  <?php echo $language['win']; ?>:<?php echo formatMoney($rlt['win'][$key][2]); ?></td>
                            </tr>
                            <?php if (array_sum($row['card']) > 0) : ?>
                            <tr>
                                <td class="text-right"><?php echo $language['card']; ?>:</td>
                                <td>
                                <?php foreach ($row['card'] as $value) :?>
                                <img src="/poly/images/poker/<?php echo $value; ?>.png"/>  
                                <?php endforeach; ?>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['card_type']; ?>:</td>
                                <td><?php if ($rlt['op'][$key] == 0) : ?><?php echo $language['discard']; ?><?php else : ?><?php echo $cardType[$row['type']]; ?><?php endif; ?></td>
                            </tr>
                            <?php else : ?>
                            <tr>
                                <td class="text-right"><?php echo $language['card']; ?>:</td>
                                <td>N/A</td>
                            </tr>
                            <tr>
                                <td class="text-right"><?php echo $language['card_type']; ?>:</td>
                                <td>N/A</td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</body>
</html>