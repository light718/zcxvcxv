<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                            <tr>
                                <td>
                                    <table class="table table-bordered" style="width:auto;maxwidth:150px; margin:auto;">
                                        <tbody>
                                            <?php for ($i = 0; $i < $y_line; $i++) : ?>
                                            <tr>
                                                <?php for ($j = 0 ; $j < $x_line; $j++) : ?>
                                                <td><img style="width:44px;height:44px;" src="/poly/images/<?php echo $game_id; ?>/<?php echo generateIconName($resultCards[$i * $x_line + $j]); ?>" /></td>
                                                <?php endfor; ?>
                                            </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <thead>
                            <tr>
                                <th><?php echo $language['line']; ?></th>
                                <th><?php echo $language['bet']; ?></th>
                                <th><?php echo $language['win']; ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for ($i = 1; $i <= $bet_line['line']; $i++) : ?>
                            <?php if (isset($zjLuXian[$i])) : ?>
                            <tr>
                                <td>Line <?php echo $i; ?></td>
                                <td><?php echo formatMoney($bet_line['singleBet']); ?></td>
                                <td class="text-red"><?php if(isset($zjLuXian[$i]['coin'])) { echo formatMoney($zjLuXian[$i]['coin']); } else {echo formatMoney(0);}  ?></td>
                            </tr>
                            <?php else : ?>
                            <tr>
                                <td>Line <?php echo $i; ?></td>
                                <td><?php echo formatMoney($bet_line['singleBet']); ?></td>
                                <td><?php echo formatMoney(0); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php endfor; ?>
                            <tr>
                                <td class="text-red">ALL OF A KIND: </td>
                                <td>-</td>
                                <?php if ($result['spLuXian'] > 0) : ?>
                                <td class="text-red"><?php echo formatMoney($result['wincoin']); ?></td>
                                <?php else : ?>
                                <td class="text-red">N/A</td>
                                <?php endif; ?>
                            </tr>
                            <?php if (isset($result['scatterZJLuXian']) && count($result['scatterZJLuXian']) > 0) : ?>
                            <tr>
                                <td class="text-red"><?php echo $language['scatter_num']; ?>: <?php echo count($result['scatterZJLuXian']['indexs']); ?></td>
                                <td>-</td>
                                <td class="text-red"><?php echo formatMoney($result['scatterZJLuXian']['coin']); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if (isset($result['subGameReport']['win_coin']) && $result['subGameReport']['win_coin'] > 0) : ?>
                            <tr>
                                <?php if (isset($result['subGameReport']['logType']) && $result['subGameReport']['logType'] == 2) : ?>
                                <td class="text-red">Bet X 0</td>
                                <?php else : ?>
                                <td class="text-red">Bonus Game：<?php echo isset($result['subGameReport']['game_cnt']) ? $result['subGameReport']['game_cnt'] : 1; ?></td>
                                <?php endif; ?>
                                <td>-</td>
                                <td class="text-red"><?php echo formatMoney($result['subGameReport']['win_coin']); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td class="text-bold text-blue">Total:</td>
                                <td class="text-bold text-blue"><?php echo formatMoney($bet); ?></td>
                                <td class="text-bold text-blue"><?php echo formatMoney($win); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php require APPPATH . "/views/poly/common/js.php"; ?>
</body>
</html>