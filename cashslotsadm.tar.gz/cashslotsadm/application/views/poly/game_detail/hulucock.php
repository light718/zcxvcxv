<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                            <tr>
                                <td>
                                    <table class="table table-bordered" style="width:auto;margin:auto;">
                                    <tbody>
                                    <tr>
                                    <?php foreach ($winplace as $row) : ?>
                                    <td><img src="/poly/images/huluji/<?php echo $row; ?>.png" /></td>
                                    <?php endforeach;?>
                                    </tr>
                                    </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table><table class="table table-striped table-bordered" style="margin-top: 3px;">
                        <thead>
                            <tr>
                                <th><?php echo $language['bet_info']; ?></th>
                                <th><?php echo $language['bet_coin']; ?></th>
                                <th><?php echo $language['win']; ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bets as $row) : ?>
                            <tr id="r_show">
                            <td>Bet: <?php echo $row['bet_site']; ?></td>
                            <td><?php echo formatMoney($row['bet']); ?></td>
                            <td><?php echo formatMoney($row['win']); ?></td>
                            </tr>
                            <?php endforeach; ?>>
                            <tr id="r_show">
                                <td class="text-bold text-blue">Total:</td>
                                <td class="text-bold text-blue"><?php echo formatMoney($bet); ?></td>
                                <td class="text-bold text-blue"><?php echo formatMoney($win); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>