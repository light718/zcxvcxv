<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.01, user-scalable=yes">
    <title>Show Bet Info</title>
    <link rel="stylesheet" href="/poly/dist/css/bootstrap.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/font-awesome.min.css" media="all">
    <link rel="stylesheet" href="/poly/dist/css/AdminLTE.css" media="all">
    <link rel="stylesheet" href="/poly/css/common.css" media="all">
    <style type="text/css">
        .tb_info {
            width: 240px;
            margin: 0 auto;
            padding: 0;
        }

        .tb_List {
            width: 240px;
            margin: 0 auto;
            padding: 0;
            background: #fff;
            border: 1px solid #F5F5F5;
        }

            .tb_List td {
                line-height: 20px;
                color: #ffffff;
            }

        .td_div ul {
            list-style: none;
            margin: 0 auto;
            padding: 0;
            text-align: center;
        }

            .td_div ul li {
                line-height: 11px;
                font-weight: bold;
                font-size: 9px;
            }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12">

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_name']; ?>: <span class="badge bg-yellow"><?php echo $game_name; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left"><?php echo $language['date_time']; ?>: <span class="badge bg-yellow"><?php echo $game_timestamp; ?></span></td>
                            </tr>
                            <tr>
                                <td class="text-left">
                                    <?php foreach ($rlt['result']['place'] as $row) : ?>
                                        <?php if (!in_array($row[0], [13, 14, 15])) : ?>
                                        <img class="img-responsive center-block" src="/poly/images/<?php echo $game_id; ?>/<?php echo $row[0]; ?>.png" />
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td class="text-left"><?php echo $language['game_event']; ?>: <span class="badge bg-black" style="margin-right: 5px;">
                                    <?php if ($rlt['result']['luck'] == 0) : ?>
                                    N/A
                                    <?php else : ?>
                                    <img class="img-responsive center-block" src="/poly/images/<?php echo $game_id; ?>/event/<?php echo $rlt['result']['luck']; ?>.png" />
                                    <?php endif; ?>
                                </span></td>
                            </tr>
                            <?php if(isset($rlt['result']['retbanker'])):?>
                            <tr>
                                <td class="text-left"><?php echo $language['bank_player']; ?>: <span class="badge bg-black" style="margin-right: 5px;">
                                    <?php if ($rlt['result']['retbanker'] == 13) : ?>
                                    Bank
                                    <?php elseif ($rlt['result']['retbanker'] == 14) : ?>
                                    Tie
                                    <?php else : ?>
                                    Player
                                    <?php endif; ?>
                                </span></td>
                            </tr>
                            <?php
                            endif;
                            ?>
                            <tr>
                                <td class="text-left"><?php echo $language['total_jackpot']; ?>: <span class="badge bg-black" style="margin-right: 5px;"><?php echo formatMoney($rlt['result']['caijing']); ?></span></td>
                            </tr>
                        </tbody>
                    </table>

                    <div class="tb_info">
                        <table border="1" cellspacing="1" cellpadding="1" class="tb_List">
                            <tr>
                                <td style="width: 32px; background-color: #4D4D4D;"><?php echo $language['info']; ?></td>
                                <?php $win_detail = $rlt['result']['win_detail']; ?>
                                <?php for ($i = 0; $i <= 3; $i++) : ?>
                                <td style="width: 32px; background-color: Red;">
                                    <img class="img-responsive center-block" src="/poly/images/<?php echo $game_id; ?>/<?php echo 1+$i; ?>.png" /></td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>
                                    <div class="text-danger text-sm text-blue"><?php echo $language['place']; ?>:</div>
                                    <div class="text-danger text-sm text-green"><?php echo $language['bet']; ?>:</div>
                                    <div class="text-danger text-sm text-red"><?php echo $language['win']; ?>:</div>
                                </td>
                                <?php for ($i = 0; $i <= 3; $i++) : ?>
                                <td>
                                    <div class="text-danger text-sm text-blue"><?php echo $win_detail[$i]['place']; ?></div>
                                    <div class="text-danger text-sm text-green"><?php echo $win_detail[$i]['bet']; ?></div>
                                    <div class="text-danger text-sm text-red"><?php echo $win_detail[$i]['wincoin']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td style="width: 32px; background-color: #4D4D4D;"><?php echo $language['info']; ?></td>
                                <?php for ($i = 4; $i <= 7; $i++) : ?>
                                <td style="width: 32px; background-color: Green;">
                                    <img class="img-responsive center-block" src="/poly/images/<?php echo $game_id; ?>//<?php echo 1+$i; ?>.png" /></td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>
                                    <div class="text-danger text-sm text-blue"><?php echo $language['place']; ?>:</div>
                                    <div class="text-danger text-sm text-green"><?php echo $language['bet']; ?>:</div>
                                    <div class="text-danger text-sm text-red"><?php echo $language['win']; ?>:</div>
                                </td>
                                <?php for ($i = 4; $i <= 7; $i++) : ?>
                                <td>
                                    <div class="text-danger text-sm text-blue"><?php echo $win_detail[$i]['place']; ?></div>
                                    <div class="text-danger text-sm text-green"><?php echo $win_detail[$i]['bet']; ?></div>
                                    <div class="text-danger text-sm text-red"><?php echo $win_detail[$i]['wincoin']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td style="width: 32px; background-color: #4D4D4D;"><?php echo $language['info']; ?></td>
                                <?php for ($i = 8; $i <= 11; $i++) : ?>
                                <td style="width: 32px; background-color: #FFC125;">
                                    <img class="img-responsive center-block" src="/poly/images/<?php echo $game_id; ?>//<?php echo 1+$i; ?>.png" /></td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td>
                                    <div class="text-danger text-sm text-blue"><?php echo $language['place']; ?>:</div>
                                    <div class="text-danger text-sm text-green"><?php echo $language['bet']; ?>:</div>
                                    <div class="text-danger text-sm text-red"><?php echo $language['win']; ?>:</div>
                                </td>
                                <?php for ($i = 8; $i <= 11; $i++) : ?>
                                <td>
                                    <div class="text-danger text-sm text-blue"><?php echo $win_detail[$i]['place']; ?></div>
                                    <div class="text-danger text-sm text-green"><?php echo $win_detail[$i]['bet']; ?></div>
                                    <div class="text-danger text-sm text-red"><?php echo $win_detail[$i]['wincoin']; ?></div>
                                </td>
                                <?php endfor; ?>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
