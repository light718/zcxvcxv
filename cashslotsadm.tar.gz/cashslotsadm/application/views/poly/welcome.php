<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['menu_home']; ?></title>

    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.bootcss.com/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css"
          rel="stylesheet">
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
    <style>
        .panel-row {
            font-size: 13px;
            width: 100%;
            height: 4rem;
            line-height: 4rem;
            border: 1px solid #FFFFFF;
            padding-top: 5px;
            text-align: left;
        }

        .row {
            margin-left: 0px;
        }
        #table_body tr>td{
            width:150px;
        }
        #table_header>th{
            width: 200px;
        }

    </style>
</head>
<body class="skin-purple">
<div class="wrapper">
    <header class="main-header">
        <?php require APPPATH . "/views/poly/common/header.php"; ?>
    </header>

    <aside class="main-sidebar">
        <?php require APPPATH . "/views/poly/common/menu.php"; ?>
    </aside>

    <div class="main-footer hidden-xs bg-gray-light">
        <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
    </div>

    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content-header">
            <h1 class="hidden-xs"><?php echo $language['menu_home']; ?></small></h1>
            <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                <li><?php echo $language['menu_home']; ?>&nbsp;&nbsp;&nbsp;</li>
            </ol>
        </section>
        <section class="content">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h2 class="box-title">
                        <b><?php echo $language['title']; ?></b>
                    </h2>
                    <div class="box-tools pull-right">
                        <button data-widget="collapse" class="btn btn-box-tool" type="button"><i
                                    class="fa fa-minus"></i></button>
                    </div>
                </div>
                <div class="box-body">
                    <span><?php echo isset($notice['content']) ? $notice['content'] : ''; ?></span>
                </div>
            </div>
            <?php if ($account['agent'] >= 2) : ?>
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <div>
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active" onclick="reloadOnlineNums()"><a href="#home"
                                                                                                       aria-controls="home"
                                                                                                       role="tab"
                                                                                                       data-toggle="tab"><?php echo $language['market_data']; ?></a>
                                </li>
                                <li role="presentation" onclick="subGames();"><a href="#game_operation_tools"
                                                           aria-controls="game_operation_tools" role="tab"
                                                           data-toggle="tab"><?php echo $language['game_operation_tools']; ?></a>
                                </li>
                                <li role="presentation"><a href="#personal_model_analysis"
                                                           aria-controls="personal_model_analysis" role="tab"
                                                           data-toggle="tab"><?php echo $language['personal_model_analysis']; ?></a>
                                </li>
                                <li role="presentation"><a href="#launch_basic_data" aria-controls="launch_basic_data"
                                                           role="tab"
                                                           data-toggle="tab"><?php echo $language['launch_basic_data']; ?></a>
                                </li>
                                <li role="presentation"><a href="#loss_analysis" aria-controls="loss_analysis"
                                                           role="tab"
                                                           data-toggle="tab"><?php echo $language['loss_analysis']; ?></a>
                                </li>
                                <li role="presentation"><a href="#online_duration_analysis"
                                                           aria-controls="online_duration_analysis" role="tab"
                                                           data-toggle="tab"><?php echo $language['online_duration_analysis']; ?></a>
                                </li>
                                <li role="presentation"><a href="#sub_game_analysis" aria-controls="sub_game_analysis"
                                                           role="tab"
                                                           data-toggle="tab"><?php echo $language['sub_game_analysis']; ?></a>
                                </li>
                                <li role="presentation"><a href="#utilization_analysis"
                                                           aria-controls="utilization_analysis" role="tab"
                                                           data-toggle="tab"><?php echo $language['utilization_analysis']; ?></a>
                                <li role="presentation"><a href="#order_data"
                                                           aria-controls="order_data" role="tab"
                                                           data-toggle="tab"><?php echo '用户付费数据 '; ?></a>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="home">
                                    <div>
                                        <div class="box box-primary">
                                            <div class="box-header with-border">
                                                <div>
                                                    <!-- Nav tabs -->
                                                    <ul class="nav nav-tabs" role="tablist">
                                                        <li role="presentation" class="active"
                                                            onclick="reloadOnlineNums()">
                                                            <a
                                                                    href="#current_day_data"
                                                                    aria-controls="current_day_data"
                                                                    role="tab"
                                                                    data-toggle="tab"><?php echo $language['current_day_data']; ?></a>
                                                        </li>
                                                        <li role="presentation"><a href="#show_other_day"
                                                                                   aria-controls="show_other_day"
                                                                                   role="tab"
                                                                                   data-toggle="tab"><?php echo $language['show_other_day']; ?></a>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane active" id="current_day_data">
                                                <div class="row bg-info panel-row" style="margin-top: 2rem">
                                                    <div class="col-xs-12 col-sm-6 col-md-8"><?php echo $language['total_online']; ?>
                                                        ：<span class="badge bg-gray ui-autocomplete-input"
                                                               id="online_nums"></span></div>
                                                </div>
                                                <div class="row bg-info panel-row">
                                                    <div class="col-xs-6 col-md-3"><?php echo $language['fb_online']; ?>
                                                        : <span
                                                                id="fb_online_nums"></span>
                                                    </div>
                                                    <div class="col-xs-6 col-md-3"><?php echo $language['google_online']; ?>
                                                        : <span
                                                                id="google_online_nums"></span>
                                                    </div>
                                                    <div class="col-xs-6 col-md-3"><?php echo $language['guest_online']; ?>
                                                        : <span
                                                                id="guest_online_nums"></span>
                                                    </div>
                                                </div>
                                                <div class="row bg-info panel-row" id="city_list">
                                                </div>
                                                <div class="row bg-success panel-row">
                                                    <div class="col-xs-6 col-md-6"><?php echo $language['ios_online']; ?>
                                                        : <span
                                                                id="ios_online_nums"></span>
                                                    </div>
                                                    <div class="col-xs-6 col-md-6"><?php echo $language['android_online']; ?>
                                                        : <span
                                                                id="android_online_nums"></span></div>
                                                </div>
                                                <div class="row" style="width: 100%">
                                                    <div id="today_online_data" class="col-xs-12 col-sm-12 col-md-12" style="height: 400px;"></div>
                                                </div>
                                            </div>
                                            <div role="tabpanel" class="tab-pane" id="show_other_day">
                                                <div class="form-inline">
                                                    <label>渠道：</label>
                                                    <div class='form-control input-group input-inline'>
                                                        <select name="channel" id="channel">
                                                            <option value="">全部渠道</option>
                                                            <option value="1">安卓</option>
                                                            <option value="2">IOS</option>

                                                        </select>
                                                    </div>
                                                    <label>起始时间：</label>
                                                    <!--指定 date标记-->
                                                    <div class='input-group input-inline date'>
                                                        <input type='text' class="form-control" id='start_time'/>
                                                        <span class="input-group-addon"><span
                                                                    class="glyphicon glyphicon-calendar"></span></span>
                                                    </div>
                                                    <label>终止时间：</label>
                                                    <!--指定 date标记-->
                                                    <div class='input-group date'>
                                                        <input type='text' class="form-control form-inline"
                                                               id='end_time'/>
                                                        <span class="input-group-addon">
                                                         <span class="glyphicon glyphicon-calendar"></span>
                                                    </span>
                                                    </div>
                                                    <button type="button" class="btn btn-success"
                                                            onclick="searchOnline()">搜索
                                                    </button>
                                                </div>
                                                <div class="table-responsive" style="width:100%;overflow-x: scroll">
                                                    <table  class="table table-bordered table-striped">
                                                        <thead>
                                                        <tr id="table_header">

                                                        </tr>
                                                        </thead>
                                                        <tbody id="table_body" style="width: 110%">
                                                            <tr id="new_activation">

                                                            </tr>
                                                            <tr id="login_count">

                                                            </tr>
                                                            <tr id="fb_login_count">

                                                            </tr>
                                                            <tr id="google_login_count">

                                                            </tr>
                                                            <tr id="guest_login_count">

                                                            </tr>
                                                            <tr id="guest_login_count">

                                                            </tr>
                                                            <tr id="dnu_info">

                                                            </tr>
                                                            <tr id="fb_dnu">

                                                            </tr>
                                                            <tr id="guest_dnu">

                                                            </tr>
                                                            <tr id="google_dnu">

                                                            </tr>
                                                            <tr id="active_users">

                                                            </tr>
                                                            <tr id="active_users_fb_count">

                                                            </tr>
                                                            <tr id="active_users_google_count">
                                                            </tr>
                                                            <tr id="active_users_guest_count">
                                                            </tr>
                                                            <tr id="dau_spin">

                                                            </tr>
                                                            <tr id="dau_spin_old">

                                                            </tr>
                                                            <tr id="dau_spin_new">

                                                            </tr>
                                                            <tr id="dau_not_spin">
                                                            </tr>
                                                            <tr id="dau_not_spin_old">
                                                            </tr>
                                                            <tr id="dau_not_spin_new">
                                                            </tr>
                                                            <tr id="max_online_data">
                                                            </tr>
                                                            <tr id="arpu_data">
                                                            </tr>
                                                            <tr id="arppu_data">
                                                            </tr>
                                                            <tr id="payrate_data">
                                                            </tr>
                                                            <tr id="paynum_data">
                                                            </tr>
                                                            <tr id="payed_data">
                                                            </tr>
                                                            <tr id="pay2num_data">
                                                            </tr>
                                                            <tr id="pay2amount_data">
                                                            </tr>
                                                            <tr id="payfirstnum_data">
                                                            </tr>
                                                            <tr id="payfirstamount_data">
                                                            </tr>
                                                            <tr id="bankrupt_log_data">
                                                            </tr>
                                                            <tr id="bankrupt_list_data">
                                                            </tr>

                                                            <tr id="stay1">
                                                            </tr>
                                                            <tr id="stay3">
                                                            </tr>
                                                            <tr id="stay7">
                                                            </tr>
                                                            <tr id="stay14">
                                                            </tr>
                                                            <tr id="stay30">
                                                            </tr>
                                                            <tr id="ltv1">
                                                            </tr>
                                                            <tr id="ltv3">
                                                            </tr>
                                                            <tr id="ltv7">
                                                            </tr>
                                                            <tr id="ltv14">
                                                            </tr>
                                                            <tr id="ltv30">
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                                <div role="tabpanel" class="tab-pane" id="game_operation_tools">
                                    <div class="box-header with-border">
                                        <div>
                                            <!-- Nav tabs -->
                                            <ul class="nav nav-tabs" role="tablist">
<!--                                                <li role="presentation" class="active" onclick="subGames()"><a href="#sub_games_html"-->
<!--                                                                                                                       aria-controls="sub_games_html"-->
<!--                                                                                                                       role="tab"-->
<!--                                                                                                                       data-toggle="tab">--><?php //echo $language['sub_slots_game']; ?><!--</a>-->
<!--                                                </li>-->
                                                <li role="presentation" onclick="shopGoods()"><a href="#shop_goods"
                                                                                                               aria-controls="shop_goods"
                                                                                                               role="tab"
                                                                                                               data-toggle="tab"><?php echo $language['shop_goods']; ?></a>
                                                </li>
                                                <li role="presentation" onclick="bonusList()"><a href="#bonus_list"
                                                                                                 aria-controls="bonus_list"
                                                                                                 role="tab"
                                                                                                 data-toggle="tab"><?php echo $language['bonus_list']; ?></a>
                                                </li>
                                                <li role="presentation" onclick="mission_config()"><a href="#mission_config"
                                                                                                 aria-controls="mission_config"
                                                                                                 role="tab"
                                                                                                 data-toggle="tab"><?php echo $language['mission_config']; ?></a>
                                                </li>
                                                <li role="presentation" onclick="seven_day()"><a href="#seven_day"
                                                                                                      aria-controls="seven_day"
                                                                                                      role="tab"
                                                                                                      data-toggle="tab"><?php echo $language['seven_day']; ?></a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="tab-content">
                                            <div role="tabpanel" class="tab-pane active" id="sub_games_html">
                                                <table  class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr id="table_header">
                                                        <th>序号</th>
                                                        <th>游戏编号</th>
                                                        <th>子游戏英文</th>
                                                        <th>子游戏中文名</th>
                                                        <th>顺序行</th>
                                                        <th>顺序列</th>
                                                        <th>标签</th>
                                                        <th>解锁等级</th>
                                                        <th>是否开放</th>
                                                        <th>操作</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="sub_games_body">

                                                    </tbody>
                                                </table>
                                            </div>
                                            <div role="tabpanel" class="tab-pane" id="shop_goods">
                                                <table  class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr id="table_header">
                                                        <th>序号</th>
                                                        <th>商品编号</th>
                                                        <th>商品英文</th>
                                                        <th>商品中文名</th>
                                                        <th>顺序</th>
                                                        <th>是否开放</th>
                                                        <th>标签数字显示</th>
                                                        <th>商品金币数量</th>
                                                        <th>是否限时</th>
                                                        <th>限时显示剩余时间</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="shop_goods_html">

                                                    </tbody>
                                                </table>
                                            </div>
                                            <div role="tabpanel" class="tab-pane" id="bonus_list">
                                                <table  class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr id="table_header">
                                                        <th>序号</th>
                                                        <th>活动编号</th>
                                                        <th>活动英文名</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="bonus_list_html">

                                                    </tbody>
                                                </table>
                                            </div>
                                            <div role="tabpanel" class="tab-pane" id="bonus_list">
                                                <table  class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr id="table_header">
                                                        <th>序号</th>
                                                        <th>活动编号</th>
                                                        <th>活动英文名</th>
                                                        <th>活动中文名</th>
                                                        <th>顺序</th>
                                                        <th>是否开放</th>
                                                        <th>是否限时</th>
                                                        <th>限时显示剩余时间</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="bonus_list_html">

                                                    </tbody>
                                                </table>
                                            </div>
                                            <div role="tabpanel" class="tab-pane" id="mission_config">
                                                <button class="primary" onclick="mission_edit(0)">新增</button>
                                                <table  class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr id="table_header">
                                                        <th>序号</th>
                                                        <th>任务标题</th>
                                                        <th>任务正文</th>
                                                        <th>任务跳转（界面OR子游戏）</th>
                                                        <th>任务奖励类型</th>
                                                        <th>任务奖励数量（乘等级系数）</th>
                                                        <th>任务图标</th>
                                                        <th>任务活跃点数</th>
                                                        <th>操作</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="mission_config_html">
                                                    </tbody>
                                                </table>
                                                <h3>活跃度奖励表</h3>
                                                <button class="primary" onclick="active_edit(0)">新增</button>
                                                <table  class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr id="table_header">
                                                        <th>序号</th>
                                                        <th>活跃点</th>
                                                        <th>奖励物品</th>
                                                        <th>奖励数量（诚意系数等级）</th>
                                                        <th>操作</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="active_list_html">
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div role="tabpanel" class="tab-pane" id="seven_day">
                                                <button class="primary" onclick="config_edit(0)">新增</button>
                                                <table  class="table table-bordered table-striped">
                                                    <thead>
                                                    <tr id="table_header">
                                                        <th>序号</th>
                                                        <th>编号</th>
                                                        <th>配置金币</th>
                                                        <th>是否强制上线弹出</th>
                                                        <th>弹出顺序</th>
                                                        <th>操作</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody id="seven_day_html">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="personal_model_analysis">333</div>
                                <div role="tabpanel" class="tab-pane" id="loss_analysis">444</div>
                                <div role="tabpanel" class="tab-pane" id="online_duration_analysis">555</div>
                                <div role="tabpanel" class="tab-pane" id="sub_game_analysis">666</div>
                                <div role="tabpanel" class="tab-pane" id="utilization_analysis">777</div>
                                <div role="tabpanel" class="tab-pane" id="order_data">
                                    <div class="form-group">
                                        <label><?php echo $language['search_start_date']; ?></label>
                                        <input type="text" class="form-control" id="start-date" maxlength="10" onclick="WdatePicker({lang:'en'});" value="">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo $language['search_end_date']; ?></label>
                                            <input type="text" class="form-control" id="end-date" maxlength="10" onclick="WdatePicker({lang:'zh-cn'});" value="">
                                    </div>
                                    <div class="box-footer">
                                        <button type="button" class="btn btn-primary" id="btn-sure" onclick="downloadData()"><?php echo $language['btn_sure']; ?></button>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <h6 class="box-title">

                        </h6>
                        <div class="box-tools pull-right">
                            <button data-widget="collapse" class="btn btn-box-tool" type="button"><i
                                        class="fa fa-minus"></i></button>
                        </div>
                    </div>

                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th><?php echo $language['welcome_type']; ?></th>
                                    <th><?php echo $language['welcome_score']; ?></th>
                                </tr>
                                </thead>
                                <tbody id="list">
                                <tr>
                                    <td><?php echo $language['welcome_total_reload']; ?></td>
                                    <td><?php echo $data['today_player_total_add_coin']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['welcome_total_withdraw']; ?></td>
                                    <td><?php echo $data['today_player_total_sub_coin']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['welcome_total_win']; ?></td>
                                    <td><?php echo $data['today_total_win_coin']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['welcome_reload_history']; ?></td>
                                    <td><?php echo $data['total_reload']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['welcome_withdraw_history']; ?></td>
                                    <td><?php echo $data['total_withdraw']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['welcome_win_history']; ?></td>
                                    <td><?php echo $data['total_win']; ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th><?php echo '今日统计'; ?></th>
                                    <th><?php echo '数据'; ?></th>
                                </tr>
                                </thead>
                                <tbody id="list">
                                <tr>
                                    <td><?php echo $language['market_dnu']; ?></td>
                                    <td><?php
                                        echo $market['dnu']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['market_dau']; ?></td>
                                    <td><?php echo $market['dau']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['market_paynum']; ?></td>
                                    <td><?php echo $market['paynum']; ?></td>
                                </tr>
                                <tr>
                                    <td><?php echo $language['market_payamount']; ?></td>
                                    <td><?php echo $market['payamount']; ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/dist/plugins/My97DatePicker/WdatePicker.js"></script>
<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="http://cdn.staticfile.org/moment.js/2.24.0/moment.js"></script>
<script src="https://cdn.bootcss.com/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script src="/poly/dist/plugins/layer/layer.js"></script>
<script src="/poly/js/welcome/welcome.js"></script>

</body>
</html>