<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Pragma" content="no-cache">
    <title><?php echo $language['change_mission_config']; ?></title>
    <?php require APPPATH . "/views/poly/common/css.php"; ?>
</head>
<body class="skin-purple">
<div class="wrapper">
    <div class="main-footer hidden-xs bg-gray-light">
        <?php require APPPATH . "/views/poly/common/marquee.php"; ?>
    </div>

    <div class="content-wrapper" style="min-height: 868px;">
        <section class="content-header">
            <h1 class="hidden-xs"><?php echo $language['change_mission_config']; ?>
                <small style="margin-left: 8px; margin-right: 8px;">
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self"><i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?></a>
                </small>
            </h1>
            <ol class="breadcrumb hidden-md hidden-lg hidden-sm">
                <li>
                    <?php echo $language['change_mission_config']; ?>&nbsp;&nbsp;&nbsp;
                    <a href="javascript:void(0);" onclick="javascript:window.history.back()" target="_self">
                        <i class="fa fa-arrow-left"></i> <?php echo $language['btn_back']; ?>
                    </a>
                </li>
            </ol>
        </section>
        <section class="content">
            <div class="box box-default">
                <div class="box-body">
                    <div class="form-group">
                        <label>任务标题</label>
                        <input type="text" class="form-control" id="descr" value="<?php echo isset($result['descr']) ? $result['descr'] : "" ?>">
                        <p id="p1"></p>
                    </div>
<!--                    <div class="form-group">-->
<!--                        <label>任务正文</label>-->
<!--                        <input type="text" class="form-control" id="d_descr"  value="--><?php //echo isset($result['d_descr']) ? $result['d_descr'] : "" ?><!--">-->
<!--                        <p id="p2"></p>-->
<!--                    </div>-->
                    <div class="form-group">
                        <label>任务跳转（界面OR子游戏）	</label>
                        <input type="text" class="form-control" id="jump_to" value="<?php echo isset($result['jumpTo']) ? $result['jumpTo'] : "" ?>">
                        <p id="p3"></p>
                    </div>
                    <div class="form-group">
                        <label>奖励类型</label>
                        <select class="form-control" id="reward_type" name="reward_type">
                            <option value="1">金币</option>
                            <option value="2">Vip点数</option>
                            <option value="3">金币</option>
                            <option value="4">双倍等级经验</option>
                            <option value="5">双倍等级奖励</option>
                            <option value="6">双倍等级奖励</option>
                        </select>
                        <p id="p4"></p>
                    </div>
                    <div class="form-group">
                        <label>任务奖励数量</label>
                        <input type="text" class="form-control" id="reward_coin" value="<?php echo isset($result['reward_coin']) ? $result['reward_coin'] : "" ?>">
                        <p id="p5"></p>
                    </div>
                    <div class="form-group">
                        <label>奖励图标</label>
<!--                        上传图片插件                        -->
                        <img src="/backend/images/icon/<?php echo isset($result['icon']) ? $result['icon'] : "" ?>" height="50" width="50">
                        <p id="p6"></p>
                    </div>
                    <div class="form-group">
                        <label>任务活跃点数 </label>
                        <input type="text" class="form-control" id="active_reward" value="<?php echo isset($result['active_reward']) ? $result['active_reward'] : "" ?>">
                        <p id="p7"></p>
                    </div>
                    <div class="form-group">
                        <label>状态</label>
                        <select class="form-control" id="status" name="status">
                            <option value="1">开启</option>
                            <option value="0">关闭</option>
                        </select>
                        <p id="p7"></p>
                    </div>
                    <div class="form-group">
                        <label>任务类别</label>
                        <select class="form-control" id="type" name="type">
                            <option value="1">每周任务</option>
                            <option value="2">一次任务</option>
                            <option value="3">邀请有礼</option>
                        </select>
                        <p id="p7"></p>
                    </div>
                    <div class="form-group">
                        <label>所属游戏编号(0表示通用)</label>
                        <input type="text" class="form-control" id="gameid" value="<?php echo isset($result['gameid']) ? $result['gameid'] : 0 ?>">
                        <p id="p7"></p>
                    </div>
                </div>
                <div class="box-footer">
                    <button type="button" class="btn btn-primary" id="btn-sure" onclick="submitEdit()"><?php echo $language['btn_sure']; ?></button>
                    <button type="button" class="btn btn-default" style="margin-left: 15px;" id="btn-cancel"><?php echo $language['btn_cancel']; ?></button>
                </div>
            </div>
        </section>
    </div>
</div>
<?php require APPPATH . "/views/poly/common/js.php"; ?>
<script src="/poly/dist/js/laypage.js"></script>
<script src="/poly/dist/plugins/layer/layer.js"></script>
<script type="text/javascript">
    var id = "<?php echo $id ;?>";
    $(function () {
        $("#reward_type").val("<?php echo isset($result['reward_type']) ? $result['reward_type'] : "" ?>")
        $("#type").val("<?php echo isset($result['type']) ? $result['type'] : "" ?>")
        $("#status").val("<?php echo isset($result['status']) ? $result['status'] : "" ?>")
    })

</script>
<script src="/poly/js/welcome/mission_edit.js"></script>
</body>
</html>