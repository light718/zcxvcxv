<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['subaccount_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 400px;padding: 0px 0px 9px 15px;color: #858585;line-height: 38px;">
                    <?php echo $language['subaccount_title_tips']; ?>
                </label>
                <div class="layui-input-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="btn-add" id="btn-add">
                        <?php echo $language['subaccount_btn_add']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="subaccount-list" lay-filter="subaccount-list">
            </table>
            <script type="text/html" id="toolbar-subaccount-list-handle">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edit"><?php echo $language['btn_edit']; ?></a>
                {{#  if(d.account_status == '0'){ }}
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status"><?php echo $language['btn_status_disable']; ?></a>
                {{# }else{  }}
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status"><?php echo $language['btn_status_enable']; ?></a>
                {{# } }}
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.4'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'subaccount_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$;

            $('#btn-add').on('click', function() {
                layer.open({
                    type: 2,
                    title: "<?php echo $language['subaccount_btn_add']; ?>",
                    content: '/subaccount/add',
                    maxmin: true,
                    area: ['100%', '100%'],
                    btn:[]
                });
            });
        });
</script>
</body>

</html>