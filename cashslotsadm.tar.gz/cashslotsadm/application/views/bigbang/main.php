<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-text-right {
            text-align: right;
        }
        .layui-text-left {
            text-align: left;
        }
    </style>
</head>

<body>
<div class="layui-fluid">
            <div class="layui-card">
                <div class="layui-card-header">
                    <h2><b><?php echo $language['title']; ?></b></h2>
                </div>
                <div class="layui-card-body">
                    <?php echo isset($notice['content']) ? $notice['content'] : ''; ?>
                </div>
            </div>
        <?php if ($account['agent'] >= 2) : ?>
            <div class="layui-card">
                <div class="layui-card-body">
                    <div class="layui-row layui-col-space10">
                        <div class="layui-col-xs12 layui-col-sm4">
                            <div class="layuiadmin-card-text">
                                <div class="layui-text-top"><h3><b><?php echo $language['today_proxy_total_add_coin']; ?></b></h3></div>
                                <p class="layui-text-right"><b><?php echo $data['today_agent_total_add_coin']; ?></b></p>
                                <p class="layui-text-right"><?php echo $language['yesterday']; ?>：<?php echo $data['yesterday_agent_total_add_coin']; ?></p>
                                <p class="layui-text-left"><?php echo $language['today_proxy_total_add_coin_tips']; ?></p>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm4">
                            <div class="layuiadmin-card-text">
                                <div class="layui-text-top"><h3><b><?php echo $language['today_player_total_add_coin']; ?></b></h3></div>
                                <p class="layui-text-right"><b><?php echo $data['today_player_total_add_coin']; ?></b></p>
                                <p class="layui-text-right"><?php echo $language['yesterday']; ?>：<?php echo $data['yesterday_player_total_add_coin']; ?></p>
                                <p class="layui-text-left"><?php echo $language['today_player_total_add_coin_tips']; ?></p>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm4">
                            <div class="layuiadmin-card-text">
                                <div class="layui-text-top"><h3><b><?php echo $language['today_player_total_sub_coin']; ?></b></h3></div>
                                <p class="layui-text-right"><b><?php echo $data['today_player_total_sub_coin']; ?></b></p>
                                <p class="layui-text-right"><?php echo $language['yesterday']; ?>：<?php echo $data['yesterday_player_total_sub_coin']; ?></p>
                                <p class="layui-text-left"><?php echo $language['today_player_total_sub_coin_tips']; ?></p>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm4">
                            <div class="layuiadmin-card-text">
                                <div class="layui-text-top"><h3><b><?php echo $language['today_total_sub_coin']; ?></b></h3></div>
                                <p class="layui-text-right"><b><?php echo $data['today_total_consume_coin']; ?></b></p>
                                <p class="layui-text-right"><?php echo $language['yesterday']; ?>：<?php echo $data['yesterday_total_consume_coin']; ?></p>
                                <p class="layui-text-left"><?php echo $language['today_total_sub_coin_tips']; ?></p>
                            </div>
                        </div>
                        <div class="layui-col-xs12 layui-col-sm4">
                            <div class="layuiadmin-card-text">
                                <div class="layui-text-top"><h3><b><?php echo $language['today_total_win_coin']; ?></b></h3></div>
                                <p class="layui-text-right"><b><?php echo $data['today_total_win_coin']; ?></b></p>
                                <p class="layui-text-right"><?php echo $language['yesterday']; ?>：<?php echo $data['yesterday_total_win_coin']; ?></p>
                                <p class="layui-text-left"><?php echo $language['today_total_win_coin_tips']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="layui-card">
                <div class="layui-card-header"><?php echo $language['sub_title_01']; ?></div>
                <div class="layui-card-body">
                    <div id="online-container" style="height: 300px;"></div>
                </div>
            </div>
            <div class="layui-card">
                <div class="layui-card-header"><?php echo $language['sub_title_02']; ?></div>
                <div class="layui-card-body">
                    <div id="player-coin-container" style="height: 300px;"></div>
                </div>
            </div>
            <script type="text/javascript" src="/backend/lib/extend/jquery.min.js"></script>
            <script type="text/javascript" src="/backend/lib/extend/echarts.min.js"></script>
            <script type="text/javascript" src="/backend/modules/welcome/online.js?v=1.03"></script>
        <?php endif; ?>
</div>
</body>
</html>