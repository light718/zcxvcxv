<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['report_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <label class="layui-form-label" style="width: 100%;"><?php echo $language['report_title_tips']; ?></label>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <a href="/report/game_data?type=1" class="layui-btn layuiadmin-btn-list layui-btn-primary"><?php echo $language['report_sub_title_01']; ?></a>
                    </div>
                    <div class="layui-inline">
                        <a href="/report/big_player?type=1" class="layui-btn layuiadmin-btn-list layui-btn-primary"><?php echo $language['report_sub_title_02']; ?></a>
                    </div>
                    <div class="layui-inline">
                        <a href="javascript:void(0);" class="layui-btn layuiadmin-btn-list layui-btn-normal"><?php echo $language['report_sub_title_03']; ?></a>
                    </div>
                    <div class="layui-inline">
                        <a href="/report/jackpot_status" class="layui-btn layuiadmin-btn-list layui-btn-primary"><?php echo $language['report_sub_title_04']; ?></a>
                    </div>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <a href="/report/big_winner?type=1" class="layui-btn layuiadmin-btn-list <?php if ($type == 1) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>"><?php echo $language['report_condition_01']; ?></a>
                    </div>
                    <div class="layui-inline">
                        <a href="/report/big_winner?type=2" class="layui-btn layuiadmin-btn-list <?php if ($type == 2) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>"><?php echo $language['report_condition_02']; ?></a>
                    </div>
                    <div class="layui-inline">
                        <a href="/report/big_winner?type=3" class="layui-btn layuiadmin-btn-list <?php if ($type == 3) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>"><?php echo $language['report_condition_03']; ?></a>
                    </div>
                    <div class="layui-inline">
                        <a href="/report/big_winner?type=4" class="layui-btn layuiadmin-btn-list <?php if ($type == 4) : ?>layui-btn-normal<?php else : ?>layui-btn-primary<?php endif; ?>"><?php echo $language['report_condition_04']; ?></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="big-winner" lay-filter="big-winner"></table>
            <script type="text/html" id="search">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="game_log"><?php echo $language['report_column_btn_game_log']; ?></a>
            </script>
            <script type="text/html" id="handle">
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="handle"><?php echo $language['btn_handle']; ?></a>
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/report/big_winner.js?v=1.0"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var type = "<?php echo $type; ?>";
</script>
</body>
</html>