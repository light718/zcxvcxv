<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['add_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
</head>

<body id="iosiframe">
<div class="layui-card">
    <div class="layui-card-header"><?php echo $language['add_success']; ?></div>
    <div class="layui-card-body">
        <blockquote class="layui-elem-quote layui-quote-nm">
            <?php echo $language['add_success_message']; ?>
        </blockquote>
        <?php echo $language['add_success_notice']; ?>
    </div>
</div>
<div style="float: right;margin-right: 50px;"><button class="layui-btn" id="close"><?php echo $language['add_btn_close']; ?></button></div>

<script src="/backend/layui/layui.js">
</script>
<script>
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index'],
        function() {
            var $ = layui.$;
            $(document).on('click','#close',function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                parent.layui.table.reload('LAY-app-content-list'); //重载表格
                parent.layer.close(index); //再执行关闭
            });
        });
</script>
</body>
</html>