<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['red_envelope_setting']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 200px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 230px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body id="iosiframe">
    <input type="text" style="display: none;">
    <input type="password" style="display: none;">
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="add">
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 10px 0px 9px 15px;color: #858585;">
                <?php echo $language['red_envelope_setting_tips01']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label"><b><?php echo $language['red_envelope_setting_switch']; ?></b></label>
            <div class="layui-input-block">
                <input type="checkbox" <?php if ($setting && $setting['red_envelope_switch'] == 1) : ?>checked=""<?php endif; ?> name="red_envelope_switch" id="red_envelope_switch" lay-skin="switch" lay-filter="red_envelope_switch" lay-text="ON|OFF" value="1">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['red_envelope_setting_range']; ?>：</b>
            </label>
            <div class="layui-input-inline" style="width: 100px;">
                <input type="text" name="red_envelope_min" id="red_envelope_min" placeholder="" autocomplete="new-password" class="layui-input" value="<?php echo $setting ? $setting['red_envelope_min'] : ''; ?>">
            </div>
            <div class="layui-input-inline" style="width: 20px;">
                <div style="height: 38px;line-height: 38px;">~</div>
            </div>
            <div class="layui-input-inline" style="width: 100px;">
                <input type="text" name="red_envelope_max" id="red_envelope_max" placeholder="" autocomplete="new-password" class="layui-input" value="<?php echo $setting ? $setting['red_envelope_max'] : ''; ?>">
            </div>
        </div>
        <div class="layui-form-item" style="margin-top: 20px;">
            <div class="layui-input-block">
                <button style="width: 100px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="red_envelope_setting" id="red_envelope_setting"><?php echo $language['btn_save']; ?></button>
                <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
            </div>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/user/red_envelope_setting.js?v=1.0"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
</script>
</body>
</html>