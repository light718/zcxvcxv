<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style type="text/css">
        .layui-table-cell {
            height: auto; 
            line-height: 28px;
            padding: 0 15px;
            position: relative;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: normal;
            box-sizing: border-box;
        }
    </style>
</head>

<body id="iosiframe">
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" name="keywords" placeholder="<?php echo $language['search_placeholder_username_nickname_player']; ?>" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <button style="width: 100px;margin-right: 100px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="player-list-search" id="player-list-search">
                        <?php echo $language['search']; ?>
                    </button>
                </div>
                <?php if (!isset($permission) || array_intersect(array(11), $permission)) : ?>
                <div class="layui-inline">
                    <button style="width: 100px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="add">
                        <?php echo $language['add_user']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-danger" data-type="disable">
                        <?php echo $language['btn_disable_all_player']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-warm" data-type="enable">
                        <?php echo $language['btn_enable_all_player']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="refresh">
                        <?php echo $language['refresh_list']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="setting">
                        <?php echo $language['red_envelope_setting']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="record">
                        <?php echo $language['red_envelope_record']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="divide_record">
                        <?php echo $language['divide_record']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="total_flows">
                        <?php echo $language['total_flows']; ?>
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="layui-card-body" style="z-index: 1000;">
            <table id="player-list" lay-filter="player-list">
            </table>
            <script type="text/html" id="table-content-search-list">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_search"><?php echo $language['action_coin_search']; ?></a>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_log"><?php echo $language['action_coin_log']; ?></a>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="game_log"><?php echo $language['action_game_log']; ?></a>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="copy_login_info"><?php echo $language['action_copy_login_info']; ?></a>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="user_list"><?php echo $language['user_list']; ?></a>
            </script>
            <script type="text/html" id="table-content-handle-list">
                <?php if (!isset($permission) || array_intersect(array(11), $permission)) : ?>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edit"><?php echo $language['action_edit']; ?></a>
                {{#  if(d.account_banby_id == '0'){ }}
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status"><?php echo $language['action_status_forbidden']; ?></a>
                {{# }else{  }}
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status"><?php echo $language['action_status_normal']; ?></a>
                {{# } }}
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="change_coin"><?php echo $language['btn_coin_change']; ?></a>
                <?php endif; ?>
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.41'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'user_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            //监听搜索
            form.on('submit(player-list-search)',
                function(data) {
                    var field = data.field;

                    //执行重载
                    table.reload('player-list', {
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });
                });

            var $ = layui.$,
                active = {
                    add: function() {
                        var addIndex = layer.open({
                            type: 2,
                            title: "<?php echo $language['add_title']; ?>",
                            content: '/user/add',
                            maxmin: true,
                            area: ['100%', '100%'],
                            btn:[]
                        });
                    },
                    refresh: function() {
                        table.reload('player-list');
                    },
                    disable: function() {
                        var index = layer.confirm(language.disable_all_player_tips, {title: language.tips, btn: [language.btn_sure, language.btn_cancel]}, function() {
                            $.ajax({
                                url: "/user/changeStatusAllPlayer",
                                dataType: 'json',
                                type: 'POST',
                                data: {status: 1},
                                success:function(result) {
                                    if (result.errcode == 0) {
                                        layer.close(index);
                                        table.reload('player-list');
                                    } else {
                                        layer.msg(result.errmsg);
                                    }
                                }
                            });
                        })
                    },
                    enable: function() {
                        var index = layer.confirm(language.enable_all_player_tips, {title: language.tips, btn: [language.btn_sure, language.btn_cancel]}, function() {
                            $.ajax({
                                url: "/user/changeStatusAllPlayer",
                                dataType: 'json',
                                type: 'POST',
                                data: {status: 2},
                                success:function(result) {
                                    if (result.errcode == 0) {
                                        layer.close(index);
                                        table.reload('player-list');
                                    } else {
                                        layer.msg(result.errmsg);
                                    }
                                }
                            });
                        })
                    },
                    setting: function() {
                        var addIndex = layer.open({
                            type: 2,
                            title: "<?php echo $language['red_envelope_setting']; ?>",
                            content: '/user/red_envelope_setting',
                            maxmin: true,
                            area: ['100%', '100%'],
                            btn:[]
                        });
                    },
                    record: function() {
                        var addIndex = layer.open({
                            type: 2,
                            title: "<?php echo $language['red_envelope_record']; ?>",
                            content: '/user/red_envelope_record',
                            maxmin: true,
                            area: ['100%', '100%'],
                            btn:[]
                        });
                    },
                    divide_record: function() {
                        var addIndex = layer.open({
                            type: 2,
                            title: "<?php echo $language['divide_record']; ?>",
                            content: '/user/divide_record',
                            maxmin: true,
                            area: ['100%', '100%'],
                            btn:[]
                        });
                    },
                    total_flows: function() {
                        var addIndex = layer.open({
                            type: 2,
                            title: "<?php echo $language['total_flows']; ?>",
                            content: '/user/total_flows',
                            maxmin: true,
                            area: ['100%', '100%'],
                            btn:[]
                        });
                    },
                };
            $('.layui-btn.layuiadmin-btn-list').on('click',
                function() {
                    var type = $(this).data('type');
                    active[type] ? active[type].call(this) : '';
                });
        });
</script>
</body>

</html>