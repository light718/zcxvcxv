<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['red_envelope_setting']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 200px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 230px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body id="iosiframe">
    <input type="text" style="display: none;">
    <input type="password" style="display: none;">
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="add">
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 10px 0px 9px 15px;color: #858585;">
                <?php echo $language['red_packet_setting_tips01']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['red_envelope_record_coin']; ?>：</b>
            </label>
            <div class="layui-input-inline" style="width: 240px;">
                <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="clearNoNum(this, 2)" name="coin" id="red_packet_coin" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $red_packet_limitup; ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: red;">
                <?php echo $language['red_packet_setting_tips02']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['red_packet_account']; ?>：</b>
            </label>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block" style="margin-left:0px;width: 100%;padding: 0px 0px 9px 15px;color: red;">
                <textarea name="content"  placeholder="<?php echo $language['input'] . ' ' . $language['red_packet_setting_tips03']; ?>" class="layui-textarea"></textarea>
            </div>
        </div>
        <div class="layui-form-item" style="margin-top: 20px;">
            <div class="layui-input-block">
                <button style="width: 100px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="red_packet_setting" id="red_packet_setting"><?php echo $language['packet_btn_open']; ?></button>
                <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
            </div>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js"></script>
<script>
    function clearNoNum(obj, num){
        obj.value = obj.value.replace(/[^\-?\d.]/g,"");  //清除“数字”和“.”以外的字符
        obj.value = obj.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
        obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
        if (num == 1) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d).*$/,'$1$2.$3');//只能输入两个小数
        } else if (num ==2) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');//只能输入两个小数
        }

        if(obj.value.indexOf(".")< 0 && obj.value !=""){//以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
            // obj.value= parseFloat(obj.value);
        }
    }
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var start_time = '';
    var end_time = '';
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.9'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form,
                laydate = layui.laydate;

            //监听搜索
            form.on('submit(red_packet_setting)',
                function(data) {
                    layerIndex = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#red_packet_setting').prop('disabled', true);
                    $.ajax({
                        url: '/user/red_packet_setting',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.close(layerIndex);
                                layer.msg(result.errmsg);
                                $('#red_packet_setting').prop('disabled', false);
                            } else {
                                layer.close(layerIndex);
                                layer.msg(result.errmsg);
                                $('#red_packet_setting').prop('disabled', false);
                            }
                        }
                    });
                });
            var $ = layui.$;
            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                parent.layer.close(index); //再执行关闭
            });
        });
</script>
</body>
</html>