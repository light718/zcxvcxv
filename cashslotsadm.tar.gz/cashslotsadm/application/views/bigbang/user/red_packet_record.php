<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['red_envelope_record']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style type="text/css">
        .layui-table-cell {
            height: auto; 
            line-height: 28px;
            padding: 0 15px;
            position: relative;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: normal;
            box-sizing: border-box;
        }
    </style>
</head>

<body id="iosiframe">
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_start_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="start_time" id="start_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['week']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_end_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="end_time" id="end_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['today']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" name="keywords" placeholder="<?php echo $language['search_placeholder_username_nickname_player']; ?>" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <button style="width: 100px;margin-right: 100px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="search" id="search">
                        <?php echo $language['search']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="control_player" id="packet_setting">
                        <?php echo $language['packet_btn_open']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="list" lay-filter="list">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var start_time = '';
    var end_time = '';
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.9'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form,
                laydate = layui.laydate;

            <?php if ($lang == 'english') : ?>
            laydate.render({
                elem: '#start_time'
                ,lang: 'en'
            });
            laydate.render({
                elem: '#end_time'
                ,lang: 'en'
            });
            <?php else : ?>
            laydate.render({
                elem: '#start_time'
            });
            laydate.render({
                elem: '#end_time'
            });
            <?php endif; ?>

            table.render({
                elem: "#list",
                url: "/user/red_packet_record",
                autoSort: false,
                page: {
                    layout: ['prev', 'page', 'next'],
                    theme: '#1E9FFF',
                    groups: 9,
                },
                cols: [[
                    {
                        field: "id",
                        title: language.player_uid,
                        align: "center",
                        minWidth: 100
                    },
                    {
                        field: "pid",
                        title: language.player_username,
                        align: "center",
                        minWidth: 150
                    },
                    {
                        field: "nickname",
                        title: language.column_nickname,
                        align: "center",
                        minWidth: 150
                    },
                    {
                        field: "coin",
                        title: language.red_envelope_record_coin,
                        align: "center",
                        minWidth: 150
                    },
                    {
                        field: "create_time",
                        title: language.red_envelope_record_time,
                        align: "center",
                        minWidth: 150
                    }
                ]],
                limit: 10,
                limits: [10],
                text: {
                    none: language.no_data
                },
                done: function(res, curr, count) {
                    if (res.errcode == '1001') {
                        parent.window.location.reload();
                    }
                }
            });

            //监听搜索
            form.on('submit(search)',
                function(data) {
                    var field = data.field;
                    start_time = field.start_time;
                    end_time = field.end_time;

                    //执行重载
                    table.reload('list', {
                        url: "/user/red_packet_record",
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });
                });

            var $ = layui.$;
            $('.search').click();

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                parent.layer.close(index); //再执行关闭
            });

            $(document).on('click', '#packet_setting', function() {
                var addIndex = layer.open({
                    type: 2,
                    title: "<?php echo $language['red_packet_setting']; ?>",
                    content: '/user/red_packet_setting',
                    maxmin: true,
                    area: ['100%', '100%'],
                    btn:[]
                });
            });
        });
</script>
</body>

</html>