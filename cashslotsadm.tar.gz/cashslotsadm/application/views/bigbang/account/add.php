<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['add_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 0px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-input-inline {
            width: 250px !important;
        }
    </style>
</head>

<body>
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">
            <?php echo $language['add_sub_title']; ?>
        </label>
    </div>
    <input type="text" style="display: none;">
    <input type="password" style="display: none;">
    <div class="add">
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;color: #858585;">
                <?php echo $language['username_tips']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['username']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="text" name="username" id="username" lay-verify="username" placeholder="" autocomplete="new-password" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
                <?php echo $language['password_tips']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['password']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="password" name="password" id="password" lay-verify="password" placeholder="" autocomplete="new-password" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
                <?php echo $language['nickname_tips']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['nickname']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="text" name="nickname" id="nickname" placeholder="" autocomplete="new-password" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
                <?php echo $language['upcoin_tips']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['upcoin']; ?>：</b>
            </label>
            <div class="layui-input-inline">
                <input type="number" name="score" id="score" placeholder="" value="0" class="layui-input">
            </div>
        </div>
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-header"></div>
                <div class="layui-card-body">
                    <?php echo $language['add_notice01']; ?><br>
                    <?php echo $language['add_notice02']; ?><br>
                    <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<span style="color: red;"><?php echo $language['add_notice03']; ?></span><br>
                    <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<span><?php echo $language['add_notice04']; ?></span><br>
                    <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<?php echo $language['add_notice05']; ?><br>
                </div>
            </div>
        </div>
        <div class="layui-form-item" style="margin-top: 20px;">
            <div class="layui-input-block">
                <button style="width: 100px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="save" id="save"><?php echo $language['btn_add']; ?></button>
                <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
            </div>
        </div>
    </div>
    <div class="success" style="display: none;">
        <div class="layui-card">
            <div class="layui-card-header" style="text-align: center;"><b><?php echo $language['add_success']; ?></b></div>
            <div class="layui-card-body">
                <blockquote class="layui-elem-quote layui-quote-nm" scrolling="yes" id="message">

                </blockquote>
                <!-- <b><?php echo $language['add_success_notice']; ?></b> -->
                <button class="layui-btn copy" style="margin-left: 10px;"><?php echo $language['btn_copy']; ?></button>
            </div>
        </div>
        <div style="text-align: center;">
            <button class="layui-btn layui-btn-primary close"><?php echo $language['add_btn_close']; ?></button>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js"></script>
<script src="/backend/lib/extend/clipboard.min.js"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;

            form.verify({
                username: [
                    /^[a-zA-Z0-9]{3,12}$/,
                    language.add_account_tips_01
                ],
                password: [
                    /^[a-zA-Z0-9]{3,12}$/,
                    language.add_account_tips_02
                ],
                nickname: [
                    /^[a-zA-Z0-9]{1,12}$/,
                    language.add_account_tips_03
                ]
            });

            //监听提交
            form.on('submit(save)',
                function(data) {
                    var index = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#save').prop('disabled', true);
                    $.ajax({
                        url: '/account/save',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {

                                layer.close(index);

                                console.log($("#agentcoin"));
                                $("#agentcoin").trigger("click");
                          
                                $('.add').hide();
                                $('#message').html(result.data.success_message);
                                $('.success').show();
                                var clipboard = new ClipboardJS('.copy', {
                                    text: function(trigger) {
                                        return result.data.success_message.replace(/<br>/g, '');
                                    }
                                });
                                clipboard.on('success', function(e) {
                                    var that = $('.copy');
                                    layer.tips(language.copy_success, that, {
                                        tips: [2, 'blue'], //还可配置颜色
                                        time: 1000
                                    });
                                });
                            } else {
                                layer.close(index);
                                layer.msg(result.errmsg);
                                $('#save').prop('disabled', false);
                            }
                        }
                    });
                });
            $(document).on('click','.close',function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.layui.table.reload('proxy-list');
                parent.layer.close(index);
            });
        })
</script>
</body>
</html>