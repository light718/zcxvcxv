<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
</head>

<body id="iosiframe">
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" name="keywords" placeholder="<?php echo $language['search_placeholder_username_nickname_agent']; ?>" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <button style="width: 100px;margin-right: 100px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="proxy-list-search" id="proxy-list-search">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
                <?php if ($account['agent'] != 3 && (!isset($permission) || array_intersect(array(6, 9), $permission))) : ?>
                <div class="layui-inline">
                    <button style="width: 100px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="add">
                        <?php echo $language['btn_add_account']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" data-type="refresh">
                        <?php echo $language['refresh_list']; ?>
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="proxy-list" lay-filter="proxy-list">
            </table>
            <script type="text/html" id="toolbar-proxy-list-search">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_search"><?php echo $language['btn_coin_search']; ?></a>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_log"><?php echo $language['btn_coin_change_record']; ?></a>
            </script>
            <script type="text/html" id="toolbar-proxy-list-handle">
                <?php if (!isset($permission) || array_intersect(array(6, 9), $permission)) : ?>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="change_coin"><?php echo $language['btn_coin_change']; ?></a>
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edit"><?php echo $language['btn_edit']; ?></a>
                {{#  if(d.account_status == '0'){ }}
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status"><?php echo $language['btn_status_disable']; ?></a>
                {{# }else{  }}
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status"><?php echo $language['btn_status_enable']; ?></a>
                {{# } }}
                <?php endif; ?>
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            //监听搜索
            form.on('submit(proxy-list-search)',
                function(data) {
                    var field = data.field;

                    //执行重载
                    table.reload('proxy-list', {
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });
                });

            var $ = layui.$,
                active = {
                    add: function() {
                        layer.open({
                            type: 2,
                            title: "<?php echo $language['add_title']; ?>",
                            content: '/account/add',
                            maxmin: true,
                            area: ['100%', '100%'],
                            btn:[]
                        });
                    },
                    refresh: function() {
                        table.reload('proxy-list');
                    },
                };

            $('.layui-btn.layuiadmin-btn-list').on('click',
                function() {
                    var type = $(this).data('type');
                    active[type] ? active[type].call(this) : '';
                });

        });
</script>
</body>

</html>