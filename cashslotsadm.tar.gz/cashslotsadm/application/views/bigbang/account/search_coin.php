<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['btn_coin_search']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 130px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body id="iosiframe">
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">
                    <?php echo $language['agent_general_tips']; ?>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b><?php echo $language['proxy_username']; ?>：<?php echo $username; ?></b>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <b><?php echo $language['proxy_nickname']; ?>：<?php echo $nickname; ?></b>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_start_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="start_time" id="start_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['today']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_end_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="end_time" id="end_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['today']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-normal layui-btn-radius date-time" start-time="<?php echo $date_time['today']; ?>" end-time="<?php echo $date_time['today']; ?>"><?php echo $language['search_today']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start-time="<?php echo $date_time['yesterday']; ?>" end-time="<?php echo $date_time['yesterday']; ?>"><?php echo $language['search_yesterday']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start-time="<?php echo $date_time['week']; ?>" end-time="<?php echo $date_time['today']; ?>"><?php echo $language['search_recent_seven_day']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start-time="<?php echo $date_time['month']; ?>" end-time="<?php echo $date_time['today']; ?>"><?php echo $language['search_month']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start-time="<?php echo date("Y-m-d",strtotime("-2 week Sunday")); ?>" end-time="<?php echo date("Y-m-d",strtotime("-1 week Saturday")); ?>"><?php echo $language['search_pre_week']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="coin-search" id="coin-search" style="width: 150px;">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-primary layuiadmin-btn-list close" style="width: 150px;">
                        <?php echo $language['btn_close']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <div class="layui-row" style="margin-bottom: 10px;border: 1px solid rgb(230, 230, 230);text-align: center;height: 30px;line-height: 30px;width: 200px;">
                <b><?php echo $language['total_coin']; ?>：</b><span id="total-win"><?php echo $total_change_coin; ?></span>
            </div>
            <table id="coin-search-list" lay-filter="coin-search-list">
            </table>
            <script type="text/html" id="toolbar-coin-search-handle">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="search_coin_detail"><?php echo $language['btn_detail']; ?></a>
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form,
                laydate = layui.laydate;

            <?php if ($lang == 'english') : ?>
            laydate.render({
                elem: '#start_time'
                ,lang: 'en'
            });
            laydate.render({
                elem: '#end_time'
                ,lang: 'en'
            });
            <?php else : ?>
            laydate.render({
                elem: '#start_time'
            });
            laydate.render({
                elem: '#end_time'
            });
            <?php endif; ?>

            //监听搜索
            form.on('submit(coin-search)',
                function(data) {
                    var field = data.field;

                    //执行重载
                    table.reload('coin-search-list', {
                        url: "/account/searchCoin?username=<?php echo $username; ?>&nickname=<?php echo $nickname; ?>",
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });
                });

            var $ = layui.$;
            $(document).on('click', '.date-time', function() {
                $(this).removeClass('layui-btn-warm').addClass('layui-btn-normal');
                $(this).parent().siblings().find('.date-time').removeClass('layui-btn-normal').removeClass('layui-btn-warm').addClass('layui-btn-warm');
                $('#start_time').val($(this).attr('start-time'));
                $('#end_time').val($(this).attr('end-time'));
            });

            $('#coin-search').click();

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                parent.layer.close(index); //再执行关闭
            });
        });
</script>
</body>

</html>