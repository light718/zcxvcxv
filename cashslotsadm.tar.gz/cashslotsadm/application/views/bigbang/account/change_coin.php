<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['change_coin_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }/*
        .layui-input-block {
            margin-left: 0px; min-height: 0px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body id="iosiframe">
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <div class="layui-input-block" style="margin-left: 0px; min-height: 0px;">
                    <label class="layui-form-label" style="width: 100%;"><b><?php echo $language['proxy_username']; ?></b>：<?php echo $username; ?></label>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block" style="margin-left: 0px; min-height: 0px;">
                    <label class="layui-form-label" style="width: 100%;"><b><?php echo $language['proxy_nickname']; ?></b>：<?php echo $nickname; ?></label>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block" style="margin-left: 0px; min-height: 0px;">
                    <label class="layui-form-label"><b><?php echo $language['btn_add_coin']; ?>：</b></label>
                    <div class="layui-input-inline">
                        <input type="text" style="text-align: right; padding-right: 3px;" onkeyup="clearNoNum(this, 4)" class="layui-input" name="add_coin" id="add_coin" style="width: 300px;">
                    </div>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button class="layui-btn layui-btn-normal change-coin" type="add" style="width: 100px;"><?php echo $language['btn_add_coin']; ?></button>
                    <button class="layui-btn layui-btn-primary close" style="width: 100px;margin-left: 30px;"><?php echo $language['btn_close']; ?></button>
                </div>
            </div>
            <hr class="layui-bg-black">
            <div class="layui-form-item">
                <div class="layui-input-block" style="margin-left: 0px; min-height: 0px;">
                    <label class="layui-form-label"><b><?php echo $language['btn_sub_coin']; ?>：</b></label>
                    <div class="layui-input-inline">
                        <input type="text" style="text-align: right; padding-right: 3px;" onkeyup="clearNoNum(this, 4)" class="layui-input" name="sub_coin" id="sub_coin" style="width: 300px;">
                    </div>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button class="layui-btn layui-btn-normal change-coin" type="sub" style="width: 100px;"><?php echo $language['btn_sub_coin']; ?></button>
                    <button class="layui-btn layui-btn-primary close" style="width: 100px;margin-left: 30px;"><?php echo $language['btn_close']; ?></button>
                </div>
            </div>
            <hr class="layui-bg-black">
            <div class="layui-form-item">
                <div class="layui-input-block" style="margin-left: 0px; min-height: 0px;">
                    <label class="layui-form-label" style="width: 100%;"><b><?php echo $language['recent_record']; ?>：</b></label>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="coin-record-recent-ten-list" lay-filter="coin-record-recent-ten-list">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/public.js?v=1.0"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$;
            table.reload('coin-record-recent-ten-list', {
                url: "/account/coinRecordLists?username=<?php echo $username; ?>"
            });
            $(document).on('click', '.change-coin', function() {
                var type = $(this).attr('type');
                var coin = 0;
                var that = this;
                var coinObj = '';
                if (type == 'add') {
                    coinObj = $('#add_coin');
                } else {
                    coinObj = $('#sub_coin');
                }
                coin = coinObj.val();

                if (coin <= 0) {
                    layer.tips(language.return_fail, that, {
                        tips: [4, 'red'],
                        time: 1000,
                        end: function() {
                            $('.change-coin').attr('disabled', false);
                        }
                    });
                    return false;
                }
                $('.change-coin').prop('disabled', true);
                $.ajax({
                    url: '/account/changeCoin',
                    dataType: 'json',
                    data: {type: type, coin: coin, username: "<?php echo $username; ?>"},
                    type: 'POST',
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            layer.tips(result.errmsg, that, {
                                tips: [4, 'blue'], //还可配置颜色
                                time: 1000,
                                end: function() {
                                    coinObj.val("");
                                    table.reload('coin-record-recent-ten-list');
                                    $('.change-coin').attr('disabled', false);
                                    window.parent.parent.document.getElementById("refresh").click();
                                }
                            });
                        } else {
                            layer.tips(result.errmsg, that, {
                                tips: [4, 'red'],
                                time: 1000,
                                end: function() {
                                    $('.change-coin').attr('disabled', false);
                                }
                            });
                        }
                    }
                });
            });

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.layui.table.reload('proxy-list');
                parent.layer.close(index);
            });
        });
</script>
</body>

</html>