<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['btn_detail']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 130px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body id="iosiframe">
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b><?php echo $language['proxy_username']; ?>：<?php echo $username; ?></b>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <b><?php echo $language['proxy_nickname']; ?>：<?php echo $nickname; ?></b>
                </label>
            </div>
        </div>
        <div class="layui-card-body">
            <!-- <div class="layui-row" style="margin-bottom: 20px;">
                <div class="layui-col-xs3" style="border: 1px solid rgb(230, 230, 230);text-align: center;height: 30px;line-height: 30px;">
                    <b><?php echo $language['general_agent_report_total_add_coin']; ?>：</b><span id="total-win"><?php echo $total_add_coin; ?></span>
                </div>
                <div class="layui-col-xs1" style="text-align: center;height: 30px;line-height: 30px;">
                    <b>-</b>
                </div>
                <div class="layui-col-xs3" style="border: 1px solid rgb(230, 230, 230);text-align: center;height: 30px;line-height: 30px;">
                    <b><?php echo $language['general_agent_report_total_sub_coin']; ?>：</b><span id="total-sub"><?php echo $total_sub_coin; ?></span>
                </div>
                <div class="layui-col-xs1" style="text-align: center;height: 30px;line-height: 30px;">
                    <b>=</b>
                </div>
                <div class="layui-col-xs3" style="border: 1px solid rgb(230, 230, 230);text-align: center;height: 30px;line-height: 30px;">
                    <b><?php echo $language['general_agent_report_total_diff_coin']; ?>：</b><span id="total-diff"><?php echo $total_diff_coin; ?></span>
                </div>
            </div> -->
            <table id="general-agent-report-detail-list" lay-filter="general-agent-report-detail-list">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var start_time = '';
    var end_time = '';
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.6'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'account_list', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form,
                laydate = layui.laydate;

            //执行重载
            table.reload('general-agent-report-detail-list', {
                url: "/account/generalAgentReportDetail",
                where: {start_time: "<?php echo $start_time; ?>", end_time: "<?php echo $end_time; ?>", account_id: "<?php echo $account_id; ?>"},
                page: {
                    curr: 1,
                    layout: ['prev', 'page', 'next'],
                    theme: '#1E9FFF',
                    groups: 9,
                },
            });
            

            var $ = layui.$;
            $(document).on('click', '.date-time', function() {
                $(this).removeClass('layui-btn-warm').addClass('layui-btn-normal');
                $(this).parent().siblings().find('.date-time').removeClass('layui-btn-normal').removeClass('layui-btn-warm').addClass('layui-btn-warm');
                $('#start_time').val($(this).attr('start-time'));
                $('#end_time').val($(this).attr('end-time'));
            });

            $('#general-agent-report-detail-search').click();

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                parent.layer.close(index); //再执行关闭
            });
        });
</script>
</body>

</html>