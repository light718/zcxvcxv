<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['status_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 0px;
        }*/
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b><?php echo $language['proxy_username']; ?>：</b><?php echo $username; ?>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <b><?php echo $language['proxy_nickname']; ?>：</b><?php echo $nickname; ?>
                </label>
            </div>
            <?php if ($status == 0) : ?>
                <div class="layui-form-item">
                    <div class="layui-card">
                        <div class="layui-card-body">
                            <b><?php echo $language['status_notice01']; ?>：</b><br>
                            <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<b><?php echo $language['status_notice02']; ?></b><br>
                            <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<b><?php echo $language['status_notice03']; ?></b><br>
                            <span class="layui-badge-dot layui-bg-black"></span>&nbsp;<b><?php echo $language['status_notice04']; ?></b><br>
                        </div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn change_status layui-btn-danger" style="width: 150px;" type="forbidden"><?php echo $language['status_btn_forbidden']; ?></button>
                    </div>
                </div>
            <?php else : ?>
                <div class="layui-form-item">
                    <div class="layui-input-block" style="margin-left: 0px;">
                        <label class="layui-form-label" style="width: 100%;"><b><?php echo $language['status_notice05']; ?></b></label>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn change_status layui-btn-normal" style="width: 150px;" type="normal"><?php echo $language['status_btn_normal']; ?></button>
                    </div>
                </div>
            <?php endif; ?>
            <div class="layui-form-item">
                <div class="layui-input-block">
                    <button class="layui-btn layui-btn-primary close" style="width: 120px;margin-top: 40px;"><?php echo $language['btn_cancel']; ?></button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'user_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            var $ = layui.$;

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.layer.close(index);
            });

            $(document).on('click', '.change_status', function() {
                var obj = $(this);
                $(obj).prop('disabled', true);
                var type = $(this).attr('type');
                var index = layer.load(0, {shade: false});
                $.ajax({
                    url: "/account/changeStatus",
                    dataType: 'json',
                    type: 'POST',
                    data: {username: "<?php echo $username; ?>", type: type},
                    success:function(result) {
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            layer.close(index);
                            layer.msg(result.errmsg, {
                                    time: 1000
                                },
                                function() {
                                    var index = parent.layer.getFrameIndex(window.name);
                                    parent.layui.table.reload('proxy-list');
                                    parent.layer.close(index);
                                });
                        } else {
                            $(obj).prop('disabled', false);
                            layer.close(index);
                            layer.msg(result.errmsg);
                        }
                    }
                });
            });
        });
</script>
</body>

</html>