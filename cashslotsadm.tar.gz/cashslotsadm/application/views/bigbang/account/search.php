<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-input-block {
            margin-left: 10px;
        }
        .layui-card-body {
            padding: 10px 0px;
        }
        th,td{
            text-align: center !important;
        }
    </style>
</head>

<body id="iosiframe">
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
        <div class="layui-form-item">
            <blockquote class="layui-elem-quote layui-quote-nm">
                <div class="layui-input-block">
                    <input type="text" name="username" id="username"  lay-verify="username" autocomplete="off" placeholder="<?php echo $language['search_account_tips']; ?>" class="layui-input" style="padding-right: 80px;">
                    <button id="btn-sure" style="width: 100px;position: absolute;top: 0;right: 0px; cursor: pointer;" type="button" class="layui-btn layui-btn-normal">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
            </blockquote>
        </div>
        <div class="layui-card-body">
            <blockquote class="layui-elem-quote layui-quote-nm" id="agent" style="display: none;">
                <div class="layui-field-box">
                    <table id="agent-table"></table>
                </div>
            </blockquote>
            <blockquote class="layui-elem-quote layui-quote-nm" id="player" style="display: none;">
                <div class="layui-field-box">
                    <table id="player-table"></table>
                </div>
            </blockquote>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    
    layui.define(["table", "form"], function(t) {
    var $ = layui.$,
        i = layui.table,
        n = layui.form;

        $("#btn-sure").on('click', function () {
            if ($.trim($("#username").val()).length <= 0) {
                return false;
            }
            doSearch($("#username").val());
        })
    
        function doSearch(username) {
            $.ajax({
                url: "/account/search",
                type: "post",
                dataType: "json",
                data: {
                    username: username
                },
                success: function (json) {
                    if (json.code == 0 && json.data.account.id > 0) {
                        result = json.data.account;
                        if (json.data.agent == 0) {
                            var player_status = '';
                            if (result.login_time > 0) {
                                if (result.online == 1) {
                                    player_status = language.player_status_online;
                                } else {
                                    player_status = language.player_status_offline;
                                }
                            } else {
                                player_status = 'N/A';
                            }

                            var search = '';
                            search += '<div data-username="'+result.pid+'" data-nickname="'+result.nickname+'"><a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_search" id="player_coin_search"><?php echo $language['action_coin_search']; ?></a>';
                            search += '<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_log" id="player_coin_log"><?php echo $language['action_coin_log']; ?></a>';
                            search += '<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_log" id="player_game_log"><?php echo $language['action_game_log']; ?></a></div>';

                            var handle = '';
                            handle += '<div data-username="'+result.pid+'" data-nickname="'+result.nickname+'">';
                            <?php if (!isset($permission) || array_intersect(array(6, 9), $permission)) : ?>
                            handle += '<a class="layui-btn layui-btn-normal layui-btn-xs ' + (result.is_direct === 0 ? 'layui-btn-disabled' : '') + '" lay-event="change_coin" id="player_change_coin"><?php echo $language['btn_coin_change']; ?></a>';
                            handle += '<a class="layui-btn layui-btn-normal layui-btn-xs ' + (result.is_direct === 0 ? 'layui-btn-disabled' : '') + '" lay-event="edit" id="player_edit"><?php echo $language['btn_edit']; ?></a>';
                            if (result.banby_id == '0') {
                                handle += '<a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status" id="player_status"><?php echo $language['btn_status_disable']; ?></a>';
                            } else {
                                handle += '<a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status" id="player_status"><?php echo $language['btn_status_enable']; ?></a>';
                            }
                            <?php endif; ?>
                            handle += '</div>';


                            i.render({
                                elem: '#player-table',
                                cols: [[
                                    {field: "pid",title: language.player_username,align: "center",minWidth: 150},
                                    {field: "nickname",title: language.column_nickname,align: "center",minWidth: 100},
                                    {field: "coin",title: language.column_coin,align: "center",minWidth: 100},
                                    {field: "parent_username",title: language.agent,align: "center",minWidth: 100},
                                    {field: "player_status",title: language.player_status,align: "center",minWidth: 100},
                                    {field: "login_time",title: language.table_column_last_login,align: "center",minWidth: 200},
                                    {field: "search",title: language.column_search,align: "center",minWidth: 300},
                                    {field: "handle",title: language.column_handle,align: "center",minWidth: 300}
                                ]],
                                data: [
                                    {
                                        'pid': result.pid,
                                        'nickname': result.nickname,
                                        'coin': result.coin,
                                        'parent_username': result.parent_username,
                                        'player_status': player_status,
                                        'login_time': result.login_time,
                                        'search': search,
                                        'handle': handle
                                    }
                                ]
                            });
                            $('#player').show();
                            $('#agent').hide();

                            $('#player_coin_search').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.btn_coin_search,
                                    content: "/user/searchCoin?username=" + username + '&nickname=' + nickname,
                                    maxmin: true,
                                    area: ['100%', '100%'],
                                    btn:[]
                                });
                            })

                            $('#player_coin_log').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.coin_record_title,
                                    content: "/user/coinRecord?username=" + username + '&nickname=' + nickname,
                                    maxmin: true,
                                    area: ['100%', '100%'],
                                    btn:[]
                                });
                            })

                            $('#player_game_log').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.game_log_title,
                                    content: "/user/gameRecord?username=" + username + '&nickname=' + nickname,
                                    maxmin: true,
                                    area: ['100%', '100%'],
                                    btn:[]
                                });
                            })

                            $('#player_change_coin').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.change_coin_title,
                                    content: "/user/coin?username=" + username + '&nickname=' + nickname,
                                    maxmin: !0,
                                    area: ['100%', '100%'],
                                    btn:[]
                                });
                            })

                            $('#player_edit').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.edit_title,
                                    content: "/user/edit?username=" + username,
                                    maxmin: !0,
                                    area: ['100%', '100%'],
                                    btn:[]
                                })
                            })

                            $('#player_status').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.status_title,
                                    content: "/user/changeStatus?username=" + username + '&nickname=' + nickname,
                                    maxmin: !0,
                                    area: ['100%', '100%'],
                                    btn:[]
                                });
                            })
                        } else {
                            var search = '';
                            search += '<div data-username="'+result.username+'" data-nickname="'+result.nickname+'"><a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_search" id="agent_coin_search"><?php echo $language['btn_coin_search']; ?></a>';
                            search += '<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="coin_log" id="agent_coin_log"><?php echo $language['btn_coin_change_record']; ?></a></div>';

                            var handle = '';
                            handle += '<div data-username="'+result.username+'" data-nickname="'+result.nickname+'">';
                            <?php if (!isset($permission) || array_intersect(array(6, 9), $permission)) : ?>
                            handle += '<a class="layui-btn layui-btn-normal layui-btn-xs ' + (result.is_direct === 0 ? 'layui-btn-disabled' : '') + '" lay-event="change_coin" id="agent_change_coin"><?php echo $language['btn_coin_change']; ?></a>';
                            handle += '<a class="layui-btn layui-btn-normal layui-btn-xs ' + (result.is_direct === 0 ? 'layui-btn-disabled' : '') + '" lay-event="edit" id="agent_edit"><?php echo $language['btn_edit']; ?></a>';
                            if (result.banby_id == '0') {
                                handle += '<a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status" id="agent_status"><?php echo $language['btn_status_disable']; ?></a>';
                            } else {
                                handle += '<a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status" id="agent_status"><?php echo $language['btn_status_enable']; ?></a>';
                            }
                            <?php endif; ?>
                            handle += '</div>';
                            i.render({
                                elem: '#agent-table',
                                cols: [[
                                    {field: "username",title: language.table_column_username,align: "center",minWidth: 150},
                                    {field: "nickname",title: language.table_column_nickname,align: "center",minWidth: 100},
                                    {field: "coin",title: language.table_column_coin,align: "center",minWidth: 100},
                                    {field: "parent_username",title: language.agent,align: "center",minWidth: 100},
                                    {field: "login_time",title: language.column_last_login,align: "center",minWidth: 200},
                                    {field: "search",title: language.table_column_search,align: "center",minWidth: 300},
                                    {field: "handle",title: language.table_column_handle,align: "center",minWidth: 300}
                                ]],
                                data: [
                                    {
                                        'username': result.username,
                                        'nickname': result.nickname,
                                        'coin': result.coin,
                                        'parent_username': result.parent_username,
                                        'login_time': result.login_time,
                                        'search': search,
                                        'handle': handle
                                    }
                                ]
                            });
                            $('#agent').show();
                            $('#player').hide();

                            $('#agent_coin_search').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.btn_coin_search,
                                    content: "/account/searchCoin?username=" + username + '&nickname=' + nickname,
                                    maxmin: true,
                                    area: ['100%', '100%'],
                                    btn:[]
                                });
                            })

                            $('#agent_coin_log').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.coin_record_title,
                                    content: "/account/coinRecord?username=" + username + '&nickname=' + nickname,
                                    maxmin: true,
                                    area: ['100%', '100%'],
                                    btn:[]
                                });
                            })

                            $('#agent_change_coin').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.change_coin_title,
                                    content: "/account/coin?username=" + username + '&nickname=' + nickname,
                                    maxmin: !0,
                                    area: ['100%', '100%'],
                                    btn:[]
                                })
                            })

                            $('#agent_edit').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.edit_title,
                                    content: "/account/edit?username=" + username,
                                    maxmin: !0,
                                    area: ['100%', '100%'],
                                    btn:[]
                                })
                            })

                            $('#agent_status').on('click', function() {
                                var username = $(this).parent().attr('data-username');
                                var nickname = $(this).parent().attr('data-nickname');
                                layer.open({
                                    type: 2,
                                    title: language.status_title,
                                    content: "/account/changeStatus?username=" + username + '&nickname=' + nickname,
                                    maxmin: !0,
                                    area: ['100%', '100%'],
                                    btn:[]
                                })
                            })
                        }
                    } else {
                        $('#agent').hide();
                        $('#player').hide();
                        layer.msg(language.no_data);
                    }
                },
                beforeSend: function () {
                    $("#btn-sure").attr("disabled", "disabled");
                },
                complete: function () {
                    $("#btn-sure").removeAttr("disabled");
                }
            })
        }
});    
</script>
</body>

</html>