<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['change_pwd']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
</head>

<body>
<div class="layui-fluid" style="margin-top: 10px;">
    <div class="layui-card">
        <div class="layui-card-body" pad15="">
            <div class="layui-form" lay-filter="">
                <div class="layui-form-item">
                    <label class="layui-form-label"><b><?php echo $language['old_password']; ?>：</b></label>
                    <div class="layui-input-inline">
                        <input type="password" name="old_password" placeholder="" autocomplete="new-password" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label"><b><?php echo $language['new_password']; ?>：</b></label>
                    <div class="layui-input-inline">
                        <input type="password" name="new_password" placeholder="" autocomplete="new-password" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label"><b><?php echo $language['confirm_pwd']; ?>：</b></label>
                    <div class="layui-input-inline">
                        <input type="password" name="confirm_pwd" placeholder="" autocomplete="new-password" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button style="width: 150px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="save" id="save"><?php echo $language['btn_confirm']; ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js">
</script>
<script>
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;

            var layerIndex;
            //监听提交
            form.on('submit(save)',
                function(data) {
                    layerIndex = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#save').prop('disabled', true);
                    $.ajax({
                        url: '/welcome/changePwd',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            layer.close(layerIndex);
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        offset: ['30px', '100px'],
                                        icon: 1,
                                        time: 1000
                                    },
                                    function() {
                                        window.location.reload();
                                    });
                            } else {
                                layer.msg(result.errmsg, {
                                    offset: ['30px', '100px'],
                                    anim: 6
                                });
                                $('#save').prop('disabled', false);
                            }
                        }
                    });
                });
        })
</script>
</body>
</html>