<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['menu_player_win']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" name="account" placeholder="<?php echo $language['player_uid'] . '/' . $language['player_username']; ?>" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <?php if (in_array($account['agent'], [ADMIN_PROXY_GENERAL, ADMIN_SYSTEM])) : ?>
                <div class="layui-inline">
                    <div class="layui-input-inline" style="width: 150px;">
                        <select name="is_control" lay-filter="is_control" id="is_control">
                            <option value="0"><?php echo $language['player_win_select_all']; ?></option>
                            <option value="1"><?php echo $language['player_win_select_control']; ?></option>
                            <option value="2"><?php echo $language['player_win_select_not_control']; ?></option>
                        </select>
                    </div>
                </div>
                <?php endif; ?>
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" class="layui-input" name="start_time" id="start_time" placeholder="yyyy-MM-dd" autocomplete="new-password" width="200px;" readonly="" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" class="layui-input" name="end_time" id="end_time" placeholder="yyyy-MM-dd" autocomplete="new-password" width="200px;" readonly="" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
                <div class="layui-inline">
                    <button style="width: 100px;margin-right: 100px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="player-win-search" id="player-win-search">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
            </div>
        </div>

        <div class="layui-row layui-col-space10" style="padding: 10px 15px;">
            <div class="layui-col-sm4 layui-col-md3 layui-col-lg2">
                <b><?php echo $language['player_win_total']; ?>：<span id="player_win_total">0.00</span></b>
            </div>
            <div class="layui-col-sm4 layui-col-md3 layui-col-lg2">
                <b><?php echo $language['player_win_reload']; ?>：<span id="player_win_reload">0.00</span></b>
            </div>
            <div class="layui-col-sm4 layui-col-md3 layui-col-lg2">
                <b><?php echo $language['player_win_ratio']; ?>：<span id="player_win_ratio">0</span></b>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="player-win-list" lay-filter="player-win-list">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/system/player_win.js?v=1.112"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var lang = "<?php echo $lang; ?>";
</script>
</body>

</html>