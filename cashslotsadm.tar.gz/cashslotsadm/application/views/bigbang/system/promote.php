<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['promote_setting']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 200px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 230px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body>

<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="add">
        <div class="layui-form-item">
            <label class="layui-form-label"><b><?php echo $language['promote_switch']; ?></b></label>
            <div class="layui-input-block">
                <input type="checkbox" <?php if ($data['promoter_profit_switch'] == 1) : ?>checked=""<?php endif; ?> name="promoter_profit_switch" id="promoter_profit_switch" lay-skin="switch" lay-filter="promoter_profit_switch" lay-text="ON|OFF" value="1">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label"><b><?php echo $language['promote_ratio']; ?></b></label>
            <div class="layui-input-inline">
                <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="clearNoNum(this, 2)" name="promoter_profit_par" id="promoter_profit_par" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['promoter_profit_par']; ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label"><b><?php echo $language['promote_level_ratio']; ?></b></label>
            <div class="layui-input-inline">
                <textarea placeholder="" id="promoter_profit_plsit"  name="promoter_profit_plsit" class="layui-textarea" rows="8"><?php echo json_encode(json_decode($data["promoter_profit_plsit"], true), JSON_PRETTY_PRINT); ?></textarea>
            </div>
        </div>
        <div class="layui-form-item" style="margin-top: 20px;">
            <div class="layui-input-block">
                <button style="width: 100px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="setting" id="setting"><?php echo $language['btn_save']; ?></button>
                <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
            </div>
        </div>
    </div>
</div>

<script src="/backend/layui/layui.js">
</script>
<script>
    function clearNoNum(obj, num){
        obj.value = obj.value.replace(/[^\-?\d.]/g,"");  //清除“数字”和“.”以外的字符
        obj.value = obj.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
        obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
        if (num == 1) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d).*$/,'$1$2.$3');//只能输入两个小数
        } else if (num ==2) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');//只能输入两个小数
        }

        if(obj.value.indexOf(".")< 0 && obj.value !=""){//以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
            // obj.value= parseFloat(obj.value);
        }
    }
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;

            var layerIndex;
            //监听提交
            form.on('submit(setting)',
                function(data) {
                    layerIndex = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#setting').prop('disabled', true);
                    $.ajax({
                        url: '/system/promote',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            layer.close(layerIndex);
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        offset: ['190px', "250px"],
                                        icon: 1,
                                        time: 1000
                                    }, function() {
                                        $('#setting').prop('disabled', false);
                                    });
                            } else {
                                layer.close(layerIndex);
                                layer.msg(result.errmsg);
                                $('#setting').prop('disabled', false);
                            }
                        }
                    });
                });
        })
</script>
</body>
</html>