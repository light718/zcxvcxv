<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['menu_bigbang_list']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 130px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_start_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="start_time" id="start_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['week']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['search_end_date']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="end_time" id="end_time" placeholder="yyyy-MM-dd" value="<?php echo $date_time['today']; ?>" width="200px;">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start-time="<?php echo $date_time['today']; ?>" end-time="<?php echo $date_time['today']; ?>"><?php echo $language['search_today']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start-time="<?php echo $date_time['yesterday']; ?>" end-time="<?php echo $date_time['yesterday']; ?>"><?php echo $language['search_yesterday']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-normal layui-btn-radius date-time" start-time="<?php echo $date_time['week']; ?>" end-time="<?php echo $date_time['today']; ?>"><?php echo $language['search_recent_seven_day']; ?></button>
                </div>
                <div class="layui-inline">
                    <button class="layui-btn layui-btn-warm layui-btn-radius date-time" start-time="<?php echo $date_time['month']; ?>" end-time="<?php echo $date_time['today']; ?>"><?php echo $language['search_month']; ?></button>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="bigbang-list-search" id="bigbang-list-search" style="width: 150px;">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="bigbang-list" lay-filter="bigbang-list">
            </table>
            <script type="text/html" id="toolbar-bigbang-list">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="detail"><?php echo $language['btn_detail']; ?></a>
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/system/bigbang_list.js"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    var lang = "<?php echo $lang; ?>";
</script>
</body>

</html>