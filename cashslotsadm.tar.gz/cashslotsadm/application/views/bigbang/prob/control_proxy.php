<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['control_proxy_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 150px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 130px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height:auto;
            overflow:visible;
            text-overflow:inherit;
            white-space:normal;
        }
        body{overflow:hidden;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b style="font-size: 20px;"><?php echo $language['control_proxy_sub_title01']; ?></b>
                </label>
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                    <?php echo $language['control_proxy_sub_title02']; ?>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label"><b><?php echo $language['control_proxy_username_nickname']; ?>：</b></label>
                <div class="layui-input-inline">
                    <input type="text" class="layui-input" name="keywords" id="keywords" placeholder="" width="200px;">
                </div>
                <label class="layui-form-label"><b><?php echo $language['control_proxy_username_nickname_tips']; ?></b></label>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="proxy-list-search" id="proxy-list-search">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layui-btn-primary layuiadmin-btn-list close">
                        <?php echo $language['btn_close']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <div class="layui-row" style="margin-bottom: 20px;">
                <div class="layui-col-xs3" style="border: 1px solid rgb(230, 230, 230);text-align: center;height: 30px;line-height: 30px;width: 200px;margin-bottom: 10px;">
                    <b><?php echo $language['total_coin']; ?>：<span id="total-win">0.00</span></b>
                </div>
                <div class="layui-col-xs9">
                    <a class="layui-btn layui-btn-normal" style="float:right; height: 30px;line-height: 30px;" id="batch"><?php echo $language['batch_handle_title']; ?></a>
                </div>
            </div>
            <table id="proxy-list" lay-filter="proxy-list">
            </table>
            <script type="text/html" id="table-content-handle-list">
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="handle"><?php echo $language['btn_handle']; ?></a>
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.6'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'prob_list', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form;

            var field;

            //监听搜索
            form.on('submit(proxy-list-search)',
                function(data) {
                    field = data.field;
                    field.page = 1;

                    //执行重载
                    table.reload('proxy-list', {
                        url: "/prob/proxyLists",
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });

                    console.log(field)
                });

            var $ = layui.$;

            $('#proxy-list-search').click();

            $('#batch').on('click', function(){
                if (table.cache['proxy-list'].length > 0) {
                    layer.open({
                        type: 2,
                        title: language.batch_handle_title,
                        content: '/prob/batchHandle?keywords=' + field.keywords + '&type=proxy',
                        maxmin: true,
                        area: ['100%', '100%'],
                        btn:[]
                    });
                }
            })

            $(document).on('click', '.close', function() {
                var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
                // parent.layui.table.reload('LAY-app-content-list'); //重载表格
                parent.layer.close(index); //再执行关闭
            });
        });
</script>
</body>

</html>