<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
            padding: 0px 15px 2px 15px;
        }
        .layui-input-block {
            margin-left: 0px;
            min-height: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item" style="margin-bottom: 30px;">
                <div class="layui-input-block">
                    <label class="layui-form-label" style="width: 100%;"><?php echo $language['sub_title']; ?></label>
                </div>
            </div>
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <label class="layui-form-label" style="width: 100%;"><b><?php echo $language['search_title']; ?>：</b></label>
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-inline">
                    <div class="layui-input-inline">
                        <input type="text" name="keywords" placeholder="" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div class="layui-inline">
                    <button style="width: 100px;margin-right: 100px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="LAY-app-contlist-search" id="LAY-app-contlist-search">
                        <?php echo $language['btn_search']; ?>
                    </button>
                </div>
                <div class="layui-inline">
                    <button style="width: 150px;" class="layui-btn layuiadmin-btn-list layui-btn-normal" lay-submit lay-filter="control_player" id="control_proxy">
                        <?php echo $language['btn_control_proxy']; ?>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <table id="LAY-app-content-list" lay-filter="LAY-app-content-list">
            </table>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
        ,version: '1.5'
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'prob_list', 'table'],
        function() {
            var table = layui.table,
                form = layui.form;

            //监听搜索
            form.on('submit(LAY-app-contlist-search)',
                function(data) {
                    var field = data.field;
                    //执行重载
                    table.reload('LAY-app-content-list', {
                        where: field,
                        page: {
                            curr: 1,
                            layout: ['prev', 'page', 'next'],
                            theme: '#1E9FFF',
                            groups: 9,
                        },
                    });
                });

            var $ = layui.$;

            $(document).on('click', '#control_proxy', function() {
                layer.open({
                    type: 2,
                    title: language.control_proxy_title,
                    content: '/prob/controlProxy',
                    maxmin: true,
                    area: ['100%', '100%'],
                    btn:[]
                });
            });
        });
</script>
</body>

</html>