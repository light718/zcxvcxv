<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['handle_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 150px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body>
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 15px 2px 15px;">
            <b><?php echo $language['action_username']; ?>：<?php echo $username; ?></b>
        </label>
    </div>
    <div class="layui-form-item" style="margin-bottom: 10px;">
        <label class="layui-form-label" style="width: 100%;padding: 0px 15px 2px 15px;">
            <b><?php echo $language['action_nickname']; ?>：<?php echo $nickname; ?></b>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;color: #858585;">
            <?php echo $language['notice01']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">
            <?php echo $language['notice02']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['action_setting_prob']; ?>：</b>
        </label>
        <div class="layui-input-inline">
            <select name="prob" id="prob">
                <?php foreach ($prob as $key=>$val) : ?>
                <option value="<?php echo $key; ?>" <?php if ($key == $cur_prob) : ?>selected<?php endif; ?>><?php echo $val; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
            <?php echo $language['notice03']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['action_setting_time']; ?>：</b>
        </label>
        <div class="layui-input-inline">
            <input type="text" style="text-align: right; padding-right: 3px;" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');" value="5" name="time" id="time" placeholder="" autocomplete="off" class="layui-input">
        </div>
        <div class="layui-input-inline">
            <label class="layui-form-label"><?php echo $language['action_setting_time_minutes']; ?></label>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
            <?php echo $language['notice04']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">
            <?php echo $language['notice05']; ?>
        </label>
    </div>
    <input type="hidden" name="type" value="<?php echo $type; ?>">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
    <div class="layui-form-item" style="text-align: center;margin-top: 20px;">
        <div class="layui-input-block">
            <button style="width: 100px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="layuiadmin-app-form-submit" id="layuiadmin-app-form-submit"><?php echo $language['btn_handle']; ?></button>
            <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_cancel']; ?></button>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js">
</script>
<script>
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;

            //监听提交
            form.on('submit(layuiadmin-app-form-submit)',
                function(data) {
                    var field = data.field;
                    $('#layuiadmin-app-form-submit').prop('disabled', true);
                    var index = layer.load(0, {shade: false});
                    $.ajax({
                        url: '/prob/saveHandle',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        // offset: '15px',
                                        icon: 1,
                                        time: 1000
                                    },
                                    function() {
                                        var index = parent.layer.getFrameIndex(window.name);
                                        parent.layui.table.reload('proxy-list');
                                        parent.layer.close(index);
                                    });
                            } else {
                                layer.close(index);
                                layer.msg(result.errmsg);
                                $('#layuiadmin-app-form-submit').prop('disabled', false);
                            }
                        }
                    });
                });
            $(document).on('click','.close',function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.layer.close(index);
            });
        })
</script>
</body>
</html>