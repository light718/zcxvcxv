<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['site_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
</head>

<body class="layui-layout-body">
<div id="LAY_app">
    <div class="layui-layout layui-layout-admin">
        <!-- PC端顶部 -->
        <div class="layui-header" id="pc-header">
            <ul class="layui-nav layui-layout-left">
                <li class="layui-layout-header layui-nav-item layadmin-flexible" lay-unselect>
                    <a href="javascript:;" layadmin-event="flexible" title="侧边伸缩">
                        <i class="layui-icon layui-icon-shrink-right" id="LAY_app_flexible"></i>
                    </a>
                </li>
                <li class="layui-layout-header layui-nav-item" style="margin-right: 5px;">
                    <a href="javascript:;"><cite><?php echo $account['username']; ?></cite></a>
                </li>
                <li class="layui-layout-header layui-nav-item">
                    <a lay-href="/welcome/changePwd" class="layui-btn layuiadmin-btn-list layui-btn-normal" style="height: 25px;line-height: 25px;display: inline-block;padding: 0 18px;color: #fff;white-space: nowrap;text-align: center;font-size: 14px;border: none;border-radius: 2px;cursor: pointer;"><?php echo $language['btn_change_pwd']; ?></a>
                </li>
                <li class="layui-layout-header layui-nav-item" style="margin-right: 5px;">
                    <a href="javascript:;"><cite><b><?php echo $language['my_coin']; ?>：<span class="coin" id="agentcoin"><?php echo $coin; ?></span></b></cite></a>
                </li>
                <li class="layui-layout-header layui-nav-item" lay-unselect>
                    <a href="javascript:;" class="refresh" id="refresh" title="刷新">
                        <i class="layui-icon layui-icon-refresh-3"></i>
                    </a>
                </li>
            </ul>
            <ul class="layui-nav layui-layout-right" lay-filter="layadmin-layout-right">
                <?php if ($account['agent'] == ADMIN_SYSTEM) : ?>
                <li class="layui-nav-item" lay-unselect="">
                    <a href="javascript:;">
                        <cite><?php echo $select_region_name; ?></cite>
                        <span class="layui-nav-more"></span>
                    </a>
                    <dl class="layui-nav-child layui-anim layui-anim-upbit">
                        <?php foreach ($select_region as $key => $value) : ?>
                        <dd><a href="javascript:void(0);" data-key="<?php echo $key; ?>" class="select_region"><?php echo $value; ?></a></dd>
                        <?php endforeach; ?>
                    </dl>
                </li>
                <?php endif; ?>
                <li class="layui-nav-item" style="margin-right: 5px;">
                    <a href="javascript:;"><cite><?php echo $right_name; ?></cite></a>
                </li>
                <li class="layui-nav-item">
                    <a href="javascript:;" id="logout"><cite><?php echo $language['btn_logout']; ?></cite></a>
                </li>
            </ul>
        </div>
        <!-- 移动端顶部 -->
        <div class="layui-header" id="mobile-header" style="display: none;">
            <ul class="layui-nav layui-layout-left">
                <li class="layui-layout-header layui-nav-item layadmin-flexible" lay-unselect>
                    <a href="javascript:;" layadmin-event="flexible" title="侧边伸缩">
                        <i class="layui-icon layui-icon-shrink-right" id="LAY_app_flexible"></i>
                    </a>
                </li>
                <li class="layui-layout-header layui-nav-item" style="margin: 0;">
                    <a href="javascript:;"><cite><b><?php echo $language['my_coin']; ?>：<span class="coin"><?php echo $coin; ?></span></b></cite></a>
                </li>
                <?php if ($account['agent'] == ADMIN_SYSTEM) : ?>
                <?php else : ?>
                <li class="layui-layout-header layui-nav-item" lay-unselect>
                    <a href="javascript:;" class="refresh" title="刷新">
                        <i class="layui-icon layui-icon-refresh-3"></i>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            <ul class="layui-nav layui-layout-right" lay-filter="layadmin-layout-right">
                <?php if ($account['agent'] == ADMIN_SYSTEM) : ?>
                <li class="layui-nav-item" lay-unselect="">
                    <a href="javascript:;">
                        <cite><?php echo $select_region_name; ?></cite>
                        <span class="layui-nav-more"></span>
                    </a>
                    <dl class="layui-nav-child layui-anim layui-anim-upbit">
                        <?php foreach ($select_region as $key => $value) : ?>
                        <dd><a href="javascript:void(0);" data-key="<?php echo $key; ?>" class="select_region"><?php echo $value; ?></a></dd>
                        <?php endforeach; ?>
                    </dl>
                </li>
                <?php endif; ?>
                <li class="layui-nav-item" lay-unselect="">
                    <a href="javascript:;">
                        <cite><?php echo $account['username']; ?></cite>
                        <span class="layui-nav-more"></span>
                    </a>
                    <dl class="layui-nav-child layui-anim layui-anim-upbit">
                    <dd><a lay-href="/welcome/changePwd"><?php echo $language['btn_change_pwd']; ?></a></dd>
                    <dd><a href="javascript:;" id="logout"><?php echo $language['btn_logout']; ?></a></dd>
                    </dl>
                </li>
            </ul>
        </div>
        <!-- 侧边菜单 -->
        <div class="layui-side layui-side-menu">
            <div class="layui-side-scroll">
                <div class="layui-logo">
                    <span><?php echo $language['site_title']; ?></span>
                </div>
                <ul class="layui-nav layui-nav-tree" lay-shrink="all" id="LAY-system-side-menu" lay-filter="layadmin-system-side-menu">
                    <?php foreach ($menu as $row) : ?>
                        <?php if (isset($row['submenu']) && $row['submenu']) : ?>
                        <li data-name="home" class="layui-nav-item">
                            <a href="javascript:;" lay-tips="<?php echo $row['name']; ?>" lay-direction="2">
                                <cite><?php echo $row['name']; ?></cite>
                                <span class="layui-nav-more"></span>
                            </a>
                            <?php foreach ($row['submenu'] as $submenu) : ?>
                            <dl class="layui-nav-child">
                                <dd>
                                    <a lay-href="<?php echo $submenu['url']; ?>">&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $submenu['name']; ?></a>
                                </dd>
                            </dl>
                            <?php endforeach; ?>
                        </li>
                        <?php else : ?>
                        <li data-name="home" class="layui-nav-item layui-nav-itemed">
                            <a lay-href="<?php echo $row['url']; ?>" lay-tips="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></a>
                        </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
                <div style="height: 8px; padding: 0 0 10px 6px; position: fixed; bottom: 0;">V1.0.0</div>
                <div style="display: none;"><?php echo $_SERVER['SERVER_ADDR']; ?></div>
            </div>
        </div>
        <!-- 页面标签 -->
        <div class="layadmin-pagetabs" id="LAY_app_tabs">
            <div class="layui-icon layadmin-tabs-control layui-icon-prev" layadmin-event="leftPage">
            </div>
            <div class="layui-icon layadmin-tabs-control layui-icon-next" layadmin-event="rightPage">
            </div>
            <div class="layui-icon layadmin-tabs-control layui-icon-down">
                <ul class="layui-nav layadmin-tabs-select" lay-filter="layadmin-pagetabs-nav">
                    <li class="layui-nav-item" lay-unselect>
                        <a href="javascript:;">
                        </a>
                        <dl class="layui-nav-child layui-anim-fadein">
                            <dd layadmin-event="closeThisTabs">
                                <a href="javascript:;">
                                    关闭当前标签页
                                </a>
                            </dd>
                            <dd layadmin-event="closeOtherTabs">
                                <a href="javascript:;">
                                    关闭其它标签页
                                </a>
                            </dd>
                            <dd layadmin-event="closeAllTabs">
                                <a href="javascript:;">
                                    关闭全部标签页
                                </a>
                            </dd>
                        </dl>
                    </li>
                </ul>
            </div>
            <div class="layui-tab" lay-unauto lay-allowClose="true" lay-filter="layadmin-layout-tabs">
                <ul class="layui-tab-title" id="LAY_app_tabsheader">
                    <li lay-id="home/console.html" lay-attr="home/console.html" class="layui-this">
                        <i class="layui-icon layui-icon-home">
                        </i>
                    </li>
                </ul>
            </div>
        </div>
        <!-- 主体内容 -->
        <div class="layui-body" id="LAY_app_body">
            <div class="layadmin-tabsbody-item layui-show">
                <iframe src="/welcome/main" frameborder="0" class="layadmin-iframe">
                </iframe>
            </div>
        </div>
        <!-- 辅助元素，一般用于移动设备下遮罩 -->
        <div class="layadmin-body-shade" layadmin-event="shade">
        </div>
    </div>
</div>
<script type="text/javascript" src="/backend/lib/extend/device.min.js"></script>
<script type="text/javascript">
    if (device.mobile()) {
        document.getElementById("pc-header").remove();
        document.getElementById("mobile-header").style.display="inline";
    } else {
        document.getElementById("pc-header").style.display="inline";
        document.getElementById("mobile-header").remove();
    }
</script>
<script src="/backend/layui/layui.js">
</script>
<script>
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use('index', function() {
        var $ = layui.$;
        $(document).on('click', '.refresh', function() {
            var that = this;
            $(that).prop('disabled', true);
            $('.coin').html('<img style="width: 16px;" src="/backend/layui/css/modules/layer/default/loading-1.gif">');
            $.ajax({
                url: "/welcome/loginInfo",
                dataType: 'json',
                type: 'POST',
                success:function(result) {
                    if (result.errcode == 1001) {
                        parent.window.location.reload();
                    } else if (result.errcode == 0) {
                        $('.coin').html(result.data.info.account_coin);
                        $(that).prop('disabled', false);
                    }
                }
            });
        });
        "<?php if ($account['agent'] == ADMIN_SYSTEM) : ?>"
        $(document).on('click', '.select_region', function() {
            var that = this;
            if ($(that).attr('data-key') === '<?php echo $select_region_key; ?>') {
                return false;
            }
            $(that).prop('disabled', true);
            $.ajax({
                url: "/welcome/select_region",
                dataType: 'json',
                data: {region: $(that).attr('data-key')},
                type: 'POST',
                success:function(result) {
                    if (result.errcode == 1001) {
                        parent.window.location.reload();
                    } else if (result.errcode == 0) {
                        window.location.reload();
                    }
                }
            });
        });
        "<?php endif; ?>"

        $(document).on('click','#logout',function(){
            layer.confirm("<?php echo $language['logout_tips']; ?>", {title:'<?php echo $language['logout_title']; ?>', btn: ['<?php echo $language['btn_sure']; ?>','<?php echo $language['btn_cancel']; ?>']}, function(e) {
                window.location.href = '/passport/logout';
            })
        });

        $(document).on('click','#btn-change-pwd',function(){
            layer.open({
                type: 2,
                title: "<?php echo $language['change_pwd']; ?>",
                content: '/welcome/changePwd',
                maxmin: true,
                area: ['100%', '100%'],
                btn:[]
            });
        });
    });
</script>
<?php if ($css_version == 'poly99') : ?>
<style id="LAY_layadmin_theme">.layui-side-menu,.layadmin-pagetabs .layui-tab-title li:after,.layadmin-pagetabs .layui-tab-title li.layui-this:after,.layui-layer-admin .layui-layer-title,.layadmin-side-shrink .layui-side-menu .layui-nav>.layui-nav-item>.layui-nav-child{background-color:#28333E !important;}.layui-nav-tree .layui-this,.layui-nav-tree .layui-this>a,.layui-nav-tree .layui-nav-child dd.layui-this,.layui-nav-tree .layui-nav-child dd.layui-this a{background-color:#AA3130 !important;}.layui-layout-admin .layui-logo{background-color:#28333E !important;}.layui-layout-admin .layui-header{background-color:#AA3130;}.layui-layout-admin .layui-header a,.layui-layout-admin .layui-header a cite{color: #f8f8f8;}.layui-layout-admin .layui-header a:hover{color: #fff;}.layui-layout-admin .layui-header .layui-nav .layui-nav-more{border-top-color: #fbfbfb;}.layui-layout-admin .layui-header .layui-nav .layui-nav-mored{border-color: transparent; border-bottom-color: #fbfbfb;}.layui-layout-admin .layui-header .layui-nav .layui-this:after, .layui-layout-admin .layui-header .layui-nav-bar{background-color: #fff; background-color: rgba(255,255,255,.5);}.layadmin-pagetabs .layui-tab-title li:after{display: none;}</style>
<?php endif; ?>
</body>

</html>