<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <link rel="stylesheet" href="/backend/style/login.css" media="all">
    <script type="text/javascript">
        var local_lang = localStorage.getItem('local_lang');
        if (!local_lang || local_lang === 'zh_cn') {
            local_lang = "<?php echo $lang; ?>";
            localStorage.setItem('local_lang', local_lang);
        }
        if ("<?php echo $lang; ?>" === 'zh_cn' && local_lang === 'english') {
            window.location.href = '/passport/login?lang=english';
        }
    </script>
</head>

<body class="login-body">
    <input type="text" style="display: none;">
    <input type="password" style="display: none;">
<div class="layadmin-user-login layadmin-user-display-show" id="LAY-user-login"
     style="display: none;">
    <div class="layadmin-user-login-main">
        <div class="layadmin-user-login-box layadmin-user-login-header">
            <h2>
                <?php 
                    if (DOMAIN === SYS_ADMIN_DOMAIN) {
                        echo $language['title'];  
                    } elseif (DOMAIN === ROOT_ADMIN_DOMAIN) {
                        echo $language['title_root_agent'];
                    } else {
                        echo $language['title_general_agent'];
                    }
                ?>
            </h2>
        </div>
        <div class="layui-tab-item layui-show">
            <div style="text-align: center;">
                <a href="javascript:void(0);" class="layui-btn <?php if ($lang != 'zh_cn') : ?>layui-btn-primary<?php else: ?>layui-btn-normal<?php endif; ?>" id="chinese" style="width: 42%;"><?php echo $language['chinese']; ?></a>
                <a href="javascript:void(0);" class="layui-btn <?php if ($lang != 'english') : ?>layui-btn-primary<?php else: ?>layui-btn-normal<?php endif; ?>" id="english" style="width: 42%;"><?php echo $language['english']; ?></a>
            </div>

            <div class="layadmin-user-login-box layadmin-user-login-body layui-form chinese">
                <input type="hidden" name="lang" id="LAY-user-login-lang" value="<?php echo $lang; ?>">
                <div class="layui-form-item">
                    <label class="layadmin-user-login-icon layui-icon layui-icon-username" for="LAY-user-login-username">
                    </label>
                    <input type="text" name="username" id="LAY-user-login-username" placeholder="<?php echo $language['username']; ?>" autocomplete="new-password" class="layui-input">
                </div>
                <div class="layui-form-item">
                    <label class="layadmin-user-login-icon layui-icon layui-icon-password" for="LAY-user-login-password">
                    </label>
                    <input type="password" name="password" id="LAY-user-login-password" placeholder="<?php echo $language['password']; ?>" autocomplete="new-password" class="layui-input">
                </div>
                <div class="layui-form-item">
                    <button class="layui-btn layui-btn-fluid layui-btn-normal" lay-submit lay-filter="user-login-submit" id="user-login-submit">
                        <?php echo $language['login']; ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/passport/login.js?v=1.0"></script>
<?php if ($css_version == 'poly99') : ?>
<style id="LAY_layadmin_theme">.login-body{background-color:#AA3130;}.layadmin-user-login-header h2{color: #f8f8f8 !important;}.layui-side-menu,.layadmin-pagetabs .layui-tab-title li:after,.layadmin-pagetabs .layui-tab-title li.layui-this:after,.layui-layer-admin .layui-layer-title,.layadmin-side-shrink .layui-side-menu .layui-nav>.layui-nav-item>.layui-nav-child{background-color:#28333E !important;}.layui-nav-tree .layui-this,.layui-nav-tree .layui-this>a,.layui-nav-tree .layui-nav-child dd.layui-this,.layui-nav-tree .layui-nav-child dd.layui-this a{background-color:#AA3130 !important;}.layui-layout-admin .layui-logo{background-color:#28333E !important;}.layui-layout-admin .layui-header{background-color:#AA3130;}.layui-layout-admin .layui-header a,.layui-layout-admin .layui-header a cite{color: #f8f8f8;}.layui-layout-admin .layui-header a:hover{color: #fff;}.layui-layout-admin .layui-header .layui-nav .layui-nav-more{border-top-color: #fbfbfb;}.layui-layout-admin .layui-header .layui-nav .layui-nav-mored{border-color: transparent; border-bottom-color: #fbfbfb;}.layui-layout-admin .layui-header .layui-nav .layui-this:after, .layui-layout-admin .layui-header .layui-nav-bar{background-color: #fff; background-color: rgba(255,255,255,.5);}.layadmin-pagetabs .layui-tab-title li:after{display: none;}</style>
<?php endif; ?>
</body>
</html>