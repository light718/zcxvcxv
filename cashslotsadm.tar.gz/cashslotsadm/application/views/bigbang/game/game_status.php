<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['game_status']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/backend/style/admin.css" media="all">
    <style>
        .layui-form-label {
            text-align: left;
        }
        .layui-input-block {
            margin-left: 130px;
        }
        .layui-card-header .layui-icon {
            line-height: inherit;
            position: absolute;
            right: 15px;
            top: 0;
            margin-top: 0;
            left: 0;
        }
        .layui-icon-refresh-3:hover {
            cursor: pointer;
        }
        .layui-table-cell {
            height: auto;
            overflow: visible !important;
        }
        body{overflow-y: scroll;}
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-card-body">
            <div class="layui-form-item">
                <label class="layui-form-label"><?php echo $language['batch_tag']; ?></label>
                <div class="layui-input-block">
                    <div class="layui-inline">
                        <button style="width: 100px;" class="layui-btn layui-btn-normal game_tag" data-tag="0"><?php echo $language['game_tag_0']; ?></button>
                    </div>
                    <div class="layui-inline">
                        <button style="width: 100px;" class="layui-btn layui-btn-normal game_tag" data-tag="1"><?php echo $language['game_tag_1']; ?></button>
                    </div>
                    <div class="layui-inline">
                        <button style="width: 100px;" class="layui-btn layui-btn-normal game_tag" data-tag="2"><?php echo $language['game_tag_2']; ?></button>
                    </div>
                </div>
            </div>
            <table id="game-list" lay-filter="game-list">
            </table>
            <script type="text/html" id="toolbar-game-list-handle">
                {{#  if(d.status == '1'){ }}
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="status"><?php echo $language['game_status_btn_close']; ?></a>
                {{# }else{  }}
                <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="status"><?php echo $language['game_status_btn_open']; ?></a>
                {{# } }}
            </script>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js"></script>
<script src="/backend/modules/game/game_status.js?v=1.55"></script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
</script>
</body>
</html>