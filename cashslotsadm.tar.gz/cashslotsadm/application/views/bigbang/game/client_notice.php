<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['menu_client_notice']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 100px;
            text-align: left;
        }
        .layui-input-block {
            margin-left: 0px;
        }
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-card {
            height: 500px;
            /*width: 700px;*/
            margin-top: 10px;
        }
    </style>
</head>

<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item" style="margin-bottom: 10px;">
                <div class="layui-input-block">
                    <label class="layui-form-label" style="width: 100%;"><?php echo $language['client_notice_sub_title']; ?></label>
                </div>
            </div>


            <input type="hidden" name="id" id="id" value="<?php echo isset($info['id']) ? $info['id'] : 0; ?>">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;color: #858585;">
                    <h3 style="color: #0C0C0C;"><b><?php echo $language['client_notice_tips']; ?>：</b></h3>
                </label>
            </div>
            <div class="layui-form-item">
                <textarea class="layui-textarea" id="LAY_demo2" style="display: none"><?php echo isset($info['content']) ? $info['content'] : ''; ?></textarea>
            </div>
            <div class="layui-form-item" style="text-align: right;margin-top: 20px;">
                <div class="layui-input-block">
                    <button style="width: 100px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="setting" id="setting"><?php echo $language['btn_setting_02']; ?></button>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'user_list', 'table', 'layedit'],
        function() {
            var table = layui.table,
                form = layui.form,
                layedit = layui.layedit;

            var layeditIndex = layedit.build('LAY_demo2', {
                tool: ['strong', 'colorpicker']
                ,height: '300px'
            })

            var $ = layui.$;
            var index;

            $(document).on('click', '#setting', function() {
                var content = layedit.getContent(layeditIndex);
                if (!content) {
                    return false;
                }
                $(this).prop('disabled', true);
                index = layer.load(1, {
                    shade: [0.1,'#fff'], //0.1透明度的白色背景
                    offset: ['190px', "250px"]
                });
                $.ajax({
                    url: "/game/clientNotice",
                    dataType: 'json',
                    type: 'POST',
                    data: {id: $('#id').val(), content: content},
                    success:function(result) {
                        layer.close(index);
                        if (result.errcode == 1001) {
                            parent.window.location.reload();
                        } else if (result.errcode == 0) {
                            layer.msg(result.errmsg, {
                                    offset: ['190px', "250px"],
                                    icon: 1,
                                    time: 1000
                                },
                                function() {
                                    window.location.reload();
                                });
                        } else {
                            layer.msg(result.errmsg);
                            $('#setting').prop('disabled', false);
                        }
                    }
                });
            });
        });
</script>
</body>

</html>