<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['bigbang_jackpot_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 150px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 10px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
        .layui-form-checkbox[lay-skin=primary] span {
            color: red;
            font-size: 24px;
            line-height: 24px;
        }
        .layui-form-checked[lay-skin="primary"] i {
            background-color: #1E9FFF;
            border-color: #1E9FFF;
        }
        .layui-form-checkbox[lay-skin="primary"]:hover i {
            color: rgb(255, 255, 255);
            border-color: #1E9FFF;
        }
    </style>
</head>

<body>
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['bigbang_jackpot_open_username']; ?>：</b>
        </label>
        <div class="layui-input-inline" style="width: 240px;">
            <input style="text-align: right; padding-right: 3px;" type="text" name="username" id="username" placeholder="" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item" style="margin-top: 20px;">
        <div class="layui-input-block">
            <button style="width: 150px;" class="layui-btn layui-btn-normal" lay-submit="" lay-filter="search" id="search"><?php echo $language['btn_search']; ?></button>
        </div>
    </div>
    <div style="height: 170px;">
        <div style="display: none" id="search-content">
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 10px 0px 0px 15px;">
                    <b><?php echo $language['player_username']; ?>：<span id="player_username"></span></b>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 0px 15px;">
                    <b><?php echo $language['player_nickname']; ?>：<span id="nickname"></span></b>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 10px 0px 0px 15px;">
                    <b><?php echo $language['bigbang_jackpot_seven_day_total_add_coin']; ?>：<span id="reload"></span></b>
                </label>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 10px 15px;">
                    <b><?php echo $language['bigbang_jackpot_seven_day_total_sub_coin']; ?>：<span id="withdraw"></span></b>
                </label>
            </div>
            <div class="layui-form-item">
                <div class="layui-row">
                    <div class="layui-col-xs6 layui-col-sm4 layui-col-md2">
                        <div class="layui-row">
                            <div class="layui-col-xs12">
                                <label class="layui-form-label" style="width: 150px;padding: 0px 0px 2px 15px;">
                                    <b><?php echo $language['player_status']; ?>：<span id="status"></span></b>
                                </label>
                            </div>
                        </div>
                        <div class="layui-row">
                            <div class="layui-col-xs12">
                                <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;">
                                    <b><?php echo $language['player_coin']; ?>：<span id="coin"></span></b>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-xs6 layui-col-sm8 layui-col-md10">
                        <div class="layui-col-xs2"><a id="refresh" style="display: inline-block;width: 30px;height: 30px;"><i class="layui-icon layui-icon-refresh-3" style="font-size: 28px; width:30px; height:30px;color: #1E9FFF;"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 10px 0px 0px 15px;color: #858585;">
            <?php echo $language['bigbang_jackpot_award_range']; ?>：10.00~10,000.00
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['bigbang_jackpot_award']; ?>：</b>
        </label>
        <div class="layui-input-inline" style="width: 240px;">
            <input style="text-align: right; padding-right: 3px;" onkeyup="clearNoNum(this, 2)" type="text" name="coin" id="coin" placeholder="" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 20px 0px 9px 15px;color: red;">
            <?php echo $language['bigbang_jackpot_notice_01']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-inline" style="width: 240px;margin-left: 10px;">
            <input style="font-size: 34px;" type="checkbox" lay-filter="flag" name="flag" id="flag" value="1" lay-skin="primary" title="<?php echo $language['bigbang_jackpot_notice_02']; ?>">
        </div>
    </div>
    <div class="layui-form-item" style="margin-top: 40px;">
        <div class="layui-input-block">
            <button style="width: 150px;margin-right: 50px;" class="layui-btn layui-btn-disabled" lay-submit="" lay-filter="setting" id="setting"><?php echo $language['btn_lottery']; ?></button>
            <button style="width: 150px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
        </div>
    </div>
</div>


<script src="/backend/layui/layui.js">
</script>
<script>
    var language = JSON.parse('<?php echo json_encode($language); ?>');
    function clearNoNum(obj, num){
        obj.value = obj.value.replace(/[^\d.]/g,"");  //清除“数字”和“.”以外的字符
        obj.value = obj.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
        obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
        if (num == 1) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d).*$/,'$1$2.$3');//只能输入两个小数
        } else if (num ==2) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');//只能输入两个小数
        }

        if(obj.value.indexOf(".")< 0 && obj.value !=""){//以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
            obj.value= parseFloat(obj.value);
        }
    }
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'table', 'laydate'],
        function() {
            var table = layui.table,
                form = layui.form,
                laydate = layui.laydate;
            var $ = layui.$;

            //监听提交
            form.on('submit(setting)',
                function(data) {
                    if ($('#setting').hasClass('layui-btn-disabled')) {
                        return false;
                    }
                    layerIndex = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#setting').prop('disabled', true);
                    $.ajax({
                        url: '/game/addBigbang',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            layer.close(layerIndex);
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        offset: ['190px', "250px"],
                                        icon: 1,
                                        time: 1000
                                    },
                                    function() {
                                        var index = parent.layer.getFrameIndex(window.name);
                                        parent.window.location.reload();
                                        parent.layer.close(index);
                                    });
                            } else {
                                layer.close(layerIndex);
                                layer.msg(result.errmsg);
                                $('#setting').prop('disabled', false);
                            }
                        }
                    });
                });

            $(document).on('click', '#refresh', function() {
                var username = $('#username').val();
                $(this).prop('disabled', true);
                var index = layer.load(1, {
                    shade: [0.1,'#fff'], //0.1透明度的白色背景
                    offset: ['180px', "150px"]
                });
                $.ajax({
                    url: "/user/getUserInfo",
                    dataType: 'json',
                    type: 'POST',
                    data: {username: username},
                    success:function(result) {
                        if (result.errcode == 0) {
                            if (result.data.player.player_online == 1) {
                                $('#status').html("<?php echo $language['player_status_online']; ?>");
                            } else {
                                $('#status').html("<?php echo $language['player_status_offline']; ?>");
                            }
                            $('#coin').html(result.data.player.player_coin);
                            layer.close(index);
                            $('#refresh').prop('disabled', false);
                        }
                    }
                });
            });

            $('#search').on('click', function() {
                var username = $('#username').val();
                if (!username) {
                    return false;
                }
                var that = this;
                $.ajax({
                    url: "/user/getUserInfo",
                    dataType: 'json',
                    type: 'POST',
                    data: {username: username},
                    success:function(result) {
                        if (result.errcode == 0) {
                            if (result.data.player.player_online == 1) {
                                $('#status').html("<?php echo $language['player_status_online']; ?>");
                            } else {
                                $('#status').html("<?php echo $language['player_status_offline']; ?>");
                            }
                            $('#coin').html(result.data.player.player_coin);
                            $('#player_username').html(result.data.player.player_username);
                            $('#nickname').html(result.data.player.player_nickname);
                            $.ajax({
                                url: "/user/getUserSevenCoin",
                                dataType: 'json',
                                type: 'POST',
                                data: {username: username},
                                success: function (result) {
                                    $('#reload').html(result.data.reload);
                                    $('#withdraw').html(result.data.withdraw);
                                    $('#search-content').show();
                                }
                            })
                            layer.close(index);
                        } else {
                            layer.tips(result.errmsg, that, {
                                tips: [4, 'red'] //还可配置颜色
                            });
                        }
                    }
                });
            })

            form.on('checkbox(flag)', function(data){
                if (data.elem.checked) {
                    $('#setting').removeClass('layui-btn-disabled').addClass('layui-btn-danger');
                } else {
                    $('#setting').removeClass('layui-btn-danger').addClass('layui-btn-disabled');
                }
            });

            $(document).on('click','.close',function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.window.location.reload();
                parent.layer.close(index);
            });
        })
</script>
</body>
</html>