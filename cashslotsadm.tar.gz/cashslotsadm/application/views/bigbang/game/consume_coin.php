<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>
        <?php echo $language['consume_coin_title']; ?>
    </title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/backend/layui/css/layui.css" media="all">
    <style>
        .layui-form-label {
            width: 150px;
            text-align: left;
        }/*
        .layui-input-block {
            margin-left: 0px;
        }*/
        .layui-form-item {
            margin-bottom: 2px;
        }
    </style>
</head>

<body>
<div class="layui-form" lay-filter="layuiadmin-app-form-list" id="layuiadmin-app-form-list" style="padding: 0px 30px 0 0;">
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: #858585;">
            <?php echo $language['consume_coin_sub_title']; ?>
        </label>
    </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 2px 15px;color: #858585;">
                <?php echo $language['consume_coin_ratio_tips']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['consume_coin_ratio']; ?>：</b>
            </label>
            <div class="layui-input-inline" style="width: 240px;">
                <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="clearNoNum(this, 1)" name="pool_tax_par" id="pool_tax_par" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['pool_tax_par']; ?>">
            </div>
            <div class="layui-input-inline" style="width: 5px;padding: 9px 0px;">
                <b>%</b>
            </div>
        </div>
    <div class="layui-form-item">
        <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
            <?php echo $language['consume_coin_pospar_tips']; ?>
        </label>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">
            <b><?php echo $language['consume_coin_pospar']; ?>：</b>
        </label>
        <div class="layui-input-inline" style="width: 240px;">
            <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="clearNoNum(this, 1)" name="pool_tax_pospar" id="pool_tax_pospar" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['pool_tax_pospar']; ?>">
        </div>
    </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
                <?php echo $language['consume_coin_max_tips']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['consume_coin_max']; ?>：</b>
            </label>
            <div class="layui-input-inline" style="width: 240px;">
                <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="clearNoNum(this, 2)" name="pool_tax_limitup" id="pool_tax_limitup" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['pool_tax_limitup']; ?>">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 9px 0px 2px 15px;color: #858585;">
                <?php echo $language['reset_time_interval_tips01']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: red;">
                <?php echo $language['reset_time_interval_tips02']; ?>
            </label>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">
                <b><?php echo $language['reset_time_interval']; ?>：</b>
            </label>
            <div class="layui-input-inline" style="width: 240px;">
                <input style="text-align: right; padding-right: 3px;" type="text" onkeyup="this.value=this.value.replace(/[^0-9-]+/,'');" name="pool_tax_interval" id="pool_tax_interval" placeholder="" autocomplete="off" class="layui-input" value="<?php echo $data['pool_tax_interval']; ?>">
            </div>
            <div class="layui-input-inline" style="width: 30px;padding: 9px 0px;">
                <b><?php echo $language['minute']; ?></b>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label" style="width: 100%;padding: 0px 0px 9px 15px;color: red;">
                <?php echo $language['notice_04']; ?>
            </label>
        </div>
        <div class="layui-form-item" style="margin-top: 20px;">
            <div class="layui-input-block">
                <button style="width: 100px;" class="layui-btn layui-btn-danger" lay-submit="" lay-filter="setting" id="setting"><?php echo $language['btn_setting_02']; ?></button>
                <button style="width: 100px;" type="reset" class="layui-btn layui-btn-primary close"><?php echo $language['btn_close']; ?></button>
            </div>
        </div>
</div>


<script src="/backend/layui/layui.js">
</script>
<script>
    function clearNoNum(obj, num){
        obj.value = obj.value.replace(/[^\-?\d.]/g,"");  //清除“数字”和“.”以外的字符
        obj.value = obj.value.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
        obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
        if (num == 1) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d).*$/,'$1$2.$3');//只能输入两个小数
        } else if (num ==2) {
            obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');//只能输入两个小数
        }

        if(obj.value.indexOf(".")< 0 && obj.value !=""){//以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
            // obj.value= parseFloat(obj.value);
        }
    }
    layui.config({
        base: '/backend/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index', 'form'],
        function() {
            var $ = layui.$,
                form = layui.form;

            var layerIndex;
            //监听提交
            form.on('submit(setting)',
                function(data) {
                    layerIndex = layer.load(0, {shade: false});
                    var field = data.field;
                    $('#setting').prop('disabled', true);
                    $.ajax({
                        url: '/game/consumeCoin',
                        dataType: 'json',
                        data: field,
                        type: 'POST',
                        success:function(result) {
                            layer.close(layerIndex);
                            if (result.errcode == 1001) {
                                parent.window.location.reload();
                            } else if (result.errcode == 0) {
                                layer.msg(result.errmsg, {
                                        offset: ['190px', "250px"],
                                        icon: 1,
                                        time: 1000
                                    },
                                    function() {
                                        var index = parent.layer.getFrameIndex(window.name);
                                        parent.window.location.reload();
                                        parent.layer.close(index);
                                    });
                            } else {
                                layer.close(layerIndex);
                                layer.msg(result.errmsg);
                                $('#setting').prop('disabled', false);
                            }
                        }
                    });
                });
            $(document).on('click','.close',function() {
                var index = parent.layer.getFrameIndex(window.name);
                parent.window.location.reload();
                parent.layer.close(index);
            });
        })
</script>
</body>
</html>