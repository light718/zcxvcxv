<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Levelsearch extends MY_Controller
{
    public function index()
    {
        exit('正在开发中');
        $this->load->view('subaccount/index');
    }
}
