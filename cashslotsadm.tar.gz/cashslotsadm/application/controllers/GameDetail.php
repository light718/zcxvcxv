<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class GameDetail extends MY_Controller
{
    public $result = [];

    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('game_detail_lang');
    }

    public function index()
    {
        $logId = $this->input->get('log_id');
        $result = $this->requestApi('/stat/game_record_detail', 'GET', ['log_id' => $logId]);
        if (empty($result)) {
            show_404();
        }
        $this->result = $result['data'];
        $gameId = $this->result['game_id'];
        $gameLists = $this->getGameList(1);
        $game = isset($gameLists[$gameId]) ? $gameLists[$gameId] : [];
        if (empty($game)) {
            show_404();
        }
        $this->result['game_name'] = $game['name'];
        $this->result['game_timestamp'] = date('Y-m-d H:i:s', $this->result['game_timestamp']);
        if ($game['type'] == 2) { // 拉霸
            if(in_array($this->result['game_id'], [407, 408, 409, 410])) {
                return $this->monkeySlot();
            }
            return $this->slot();
        }
        switch ($this->result['game_id']) {
            case 204:// 鱼虾耗
                return $this->belangkai();
            case 226:// 龙虎斗
            case 206:
            case 227:
            case 228:
                return $this->longhu();
            case 234:// 牛牛
                return $this->niuniu();
            case 223:// 轮盘
            case 224:
            case 225:
            case 239:
            case 209:
            case 219:
            case 220:
                return $this->roulette();
            case 214:// 豹子王
            case 229:// 豹子王
                return $this->sicbo();
            case 216:// 葫芦鸡
                return $this->hulucock();
            case 232:// 赌场
                return $this->holdem();
            case 230:// 百家乐(单机版)
                return $this->baccarat();
            case 201:// 百家乐
            case 218:
            case 221:
                return $this->baccarat(1);
            case 233:// 赌城战争
                return $this->casinowar();
            case 235:// 单挑
                return $this->singlepick();
            case 231:// 三卡扑克
                return $this->pokerthree();
            case 210:// 21点
                return $this->blackjack();
            case 241:// 战无不胜
            case 203:// 西游争霸
            case 222:// 西游争霸在线版
                return $this->droiyan();
            case 205:// 奔驰宝马
                return $this->bmw();
            case 237:// 新奔驰宝马
                return $this->newbmw();
            case 208:// 飞禽走兽
                return $this->phoenix($this->result['account_id']);
            case 202:// 猴子爬树
                return $this->thunderbolt();
            case 211:// 赛马
            case 243:// 赛马918
                return $this->horserace();
            case 236:// 摩托赛车
                return $this->motorbike();
            case 213:// 经典水果机
            case 242:// 经典水果机918
                return $this->jdfruit($this->result['account_id']);
            case 207:// 森林舞会
                return $this->animals();
            case 212:// 英超联赛
                return $this->premierleague();
            case 248: //火飞凤舞单机918
                return $this->droiyanTable2();
            case 249: //宠物小精灵918
            case 251: //森林舞会918
                return $this->droiyanTable();
            case 246:// 飞禽走兽单机918
                return $this->droiyanTable3();
        }
    }

   // 猴子拉霸
    public function monkeySlot()
    {
        $language = $this->lang->language;
        
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['bet_line'] = $rlt['bet'];
        $data['bet_line']['mult'] = floor($rlt['bet']['totalBet']/$rlt['bet']['singleBet']);
        $data['zjLuXian'] = array_column($rlt['result']['zjLuXian'], null, 'xlid');
        $data['resultCards'] = $rlt['result']['resultCards'];
        $data['result'] = $rlt['result'];
        $data['x_line'] = $rlt['result']['x'];
        $data['y_line'] = $rlt['result']['y'];
        $data['language'] = $language;
        return $this->render('game_detail/monkeyslot', $data);
    }

    // 拉霸
    public function slot()
    {
        $language = $this->lang->language;
        
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['bet_line'] = $rlt['bet'];
        $data['zjLuXian'] = array_column($rlt['result']['zjLuXian'], null, 'xlid');
        $data['resultCards'] = $rlt['result']['resultCards'];
        $data['result'] = $rlt['result'];
        $data['x_line'] = $rlt['result']['x'];
        $data['y_line'] = $rlt['result']['y'];

        $data['language'] = $language;
        if ($data['game_id'] == 169) { //壮志凌云
            return $this->render('game_detail/topgun', $data);
        } elseif ($data['game_id'] == 238 || $data['game_id'] == 416 || $data['game_id'] == 415 ) { //五龙，财神到2
            return $this->render('game_detail/fivedragons', $data);
        } elseif ($data['game_id'] == 153) { //狂热金钱
            return $this->render('game_detail/moneyfever', $data);
        }
        return $this->render('game_detail/slot', $data);
    }

    // 轮盘
    public function roulette()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        if (isset($gameconf[$data['game_id']])) {
            $rlt = json_decode($data['rlt'], true);
            $gameconf = $gameconf[$data['game_id']]['bet']['betname'];
            foreach ($rlt['rs'] as $key => &$one) {
                if (isset($gameconf[$key])) {
                    $one['bet_site'] = $gameconf[$key];
                } else {
                    $one['bet_site'] = 'Bet: ' . $one['bet_site'];
                }
            }
            $data['rlt'] = $rlt;
            
        }
        $data['language'] = $language;
        $this->render('game_detail/roulette', $data);
    }

    // 牛牛
    public function niuniu()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $result = $this->result;
        $gameconf = [
            1 => '没牛',
            2 => '牛一',
            3 => '牛二',
            4 => '牛三',
            5 => '牛四',
            6 => '牛五',
            7 => '牛六',
            8 => '牛七',
            9 => '牛八',
            10 => '牛九',
            11 => '牛牛',
            12 => '顺子',
            13 => '同花',
            14 => '葫芦',
            15 => '四梅',
            16 => '金牛',
            17 => '五小牛',
            18 => '同花顺'
        ];
        $rlt = json_decode($result['rlt'], true);
        $bet = [];
        $win = [];
        foreach ($rlt['bet'] as $row) {
            $bet[] = $row[0];
            $bet[] = $row[1];
        }
        $data['bet'] = $bet;
        foreach ($rlt['win'] as $row) {
            $win[] = $row[0];
            $win[] = $row[1];
        }
        foreach ($win as $key => $value) {
            if ($value < 0) {
                $win[$key] = $value + $bet[$key];
            }
        }
        $data['win'] = $win;
        $cards = [];
        foreach ($rlt['result']['cards'] as $row) {
            $tmp = [];
            $card = array_merge($row['cards'][0], $row['cards'][1]);
            if (array_sum($card) > 0) { //有牌
                $tmp['cards'] = $card;
                $tmp['type'] = isset($gameconf[$row['type']]) ? $gameconf[$row['type']] : '没牛';
            } else {
                $tmp['cards'] = [];
                $tmp['type'] = '没牛';
            }
            $cards[] = $tmp;
        }
        $data['cards'] = $cards;
        $data['game_id'] = $result['game_id'];
        $data['game_name'] = $result['game_name'];
        $data['game_timestamp'] = $result['game_timestamp'];
        $data['language'] = $language;
        $this->render('game_detail/niuniu', $data);
    }

    // 龙虎斗
    public function longhu()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = $rlt;
        $data['language'] = $language;
        $this->render('game_detail/longhu', $data);
    }

    // 鱼虾耗
    public function belangkai()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = $rlt;
        $gameconf = config_item('gameconf');
        $gameconf = $gameconf[$this->result['game_id']]['bet']['betname'];
        foreach ($data['rlt']['rs'] as &$one) {
            $one['bet_site'] = isset($gameconf[$one['bet_site']]) ? $gameconf[$one['bet_site']] : $one['bet_site'];
        }
        $data['language'] = $language;
        $this->render('game_detail/belangkai', $data);
    }

    // 豹子王
    public function sicbo()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        if (isset($gameconf[$data['game_id']])) {
            $rlt = json_decode($data['rlt'], true);
            $gameconf = $gameconf[$data['game_id']]['bet']['betname'];
            $bets = [];
            foreach ($rlt['rs'] as $key => $value) {
                if (isset($gameconf[$key])) {
                    $value['bet_site'] = $gameconf[$key];
                }
                
                $bets[] = $value;
            }
            $data['bets'] = $bets;
            $data['winplace'] = $rlt['winplace'];
        }
        $data['language'] = $language;
        $this->render('game_detail/sicbo', $data);
    }

    // 葫芦鸡
    public function hulucock()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        if (isset($gameconf[$data['game_id']])) {
            $rlt = json_decode($data['rlt'], true);
            $gameconf = $gameconf[$data['game_id']]['bet']['betname'];
            $bets = [];
            foreach ($rlt['rs'] as $key => $value) {
                if (isset($gameconf[$key])) {
                    $value['bet_site'] = $gameconf[$key];
                }
                
                $bets[] = $value;
            }
            $data['bets'] = $bets;
            $data['winplace'] = $rlt['winplace'];
        }
        $data['language'] = $language;
        $this->render('game_detail/hulucock', $data);
    }

    // 赌场
    public function holdem()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $cardType = [
            0 => '没有牌型',
            1 => '没有牌型',
            2 => '没有牌型',
            3 => '1对',
            4 => '2对',
            5 => '3条',
            6 => '顺子',
            7 => '同花',
            8 => '葫芦',
            9 => '铁子',
            10 => '同花顺',
            11 => '同花大顺',
        ];
        $data['cardType'] = $cardType;
        $data['rlt'] = $rlt;
        $data['language'] = $language;
        $this->render('game_detail/holdem', $data);
    }

    // 百家乐
    public function baccarat($online = 0)
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = $rlt;
        $data['language'] = $language;
        $data['online'] = $online;
        $this->render('game_detail/baccarat', $data);
    }

    // 赌城战争
    public function casinowar()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = $rlt;
        $data['number'] = [
            '第一组', '第二组', '第三组', '第四组', '第五组'
        ];
        $data['language'] = $language;
        $this->render('game_detail/casinowar', $data);
    }

    // 单挑
    public function singlepick()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = $rlt;
        $data['language'] = $language;
        $this->render('game_detail/singlepick', $data);
    }

    // 三卡扑克
    public function pokerthree()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = $rlt;
        $data['language'] = $language;
        $data['cardType'] = [
            0 => '没有计算牌型',
            1 => '没有超过Q点',
            2 => '没有牌型',
            3 => '对子',
            4 => '同花',
            5 => '顺子',
            6 => '同花',
            7 => '同花顺'
        ];
        $this->render('game_detail/pokerthree', $data);
    }

    // 21点
    public function blackjack()
    {
        $data = [];
        $language = $this->lang->language;
        $gameconf = config_item('gameconf');
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        foreach ($rlt['result'] as &$one) {
            $one['blackjack'] = 'NO';
            if ($one['cardtype'] == 100) {
                $one['cardtype'] = 'BlackJack';
                $one['blackjack'] = 'YES';
            } elseif ($one['cardtype'] == 101) {
                $one['cardtype'] = '5小龙';
            }
        }
        $data['rlt'] = $rlt;
        $data['language'] = $language;
        $this->render('game_detail/blackjack', $data);
    }

    // 918 宠物小精灵,森林舞会
    public function droiyanTable()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);//d($data['rlt']);
        $data['language'] = $language;
        $this->render('game_detail/droiyanTable', $data);
    }

    // 918 飞禽走兽单机
    public function droiyanTable3()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);//d($data['rlt']);
        $data['language'] = $language;
        $this->render('game_detail/droiyanTable3', $data);
    }

    // 918 火飞凤舞
    public function droiyanTable2()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);//d($data['rlt']);
        $data['language'] = $language;
        $this->render('game_detail/droiyanTable2', $data);
    }

    // 战无不胜  西游争霸
    public function droiyan()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);//d($data['rlt']);
        $data['language'] = $language;
        $data['luck_conf'] = [
            //1 红悟空,2 绿悟空,3 黄悟空,4 红娜扎,5 绿娜扎,6 黄娜扎,7 红沙悟净,8 绿沙悟净,9 黄沙悟净,10 红牛魔王,11 绿牛魔王,12 黄牛魔王 13 庄 14 和 15 闲 16 南天门 17 水帘洞
            1 => '红悟空',
            2 => '绿悟空',
            3 => '黄悟空',
            4 => '红娜扎',
            5 => '绿娜扎',
            6 => '黄娜扎',
            7 => '红沙悟净',
            8 => '绿沙悟净',
            9 => '黄沙悟净',
            10 => '红牛魔王',
            11 => '绿牛魔王',
            12 => '黄牛魔王',
            13 => '庄',
            14 => '和',
            15 => '闲',
            16 => '南天门',
            17 => '水帘洞'
        ];
        $this->render('game_detail/droiyan', $data);
    }

    // 奔驰宝马
    public function bmw()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);
        $data['language'] = $language;
        $data['luck_conf'] = [
            1 => '大三元',
            2 => '大四喜'
        ];
        $this->render('game_detail/bmw', $data);
    }

    // 新奔驰宝马
    public function newbmw()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);
        $data['language'] = $language;
        $data['luck_conf'] = [
            1 => '大三元',
            2 => '小三元',
            3 => '纵横四海',
            4 => '彩金',
            5 => '全中',
            6 => '空门',
            7 => '送灯',
            8 => '开火车',
            9 => '大满贯'
        ];
        $this->render('game_detail/newbmw', $data);
    }

    public function phoenix($accountId)
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = isset($rlt[$accountId]) ? $rlt[$accountId] : $rlt;
        $data['language'] = $language;
        $this->render('game_detail/phoenix', $data);
    }

    // 水果机
    public function jdfruit($accountId)
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $rlt = json_decode($data['rlt'], true);
        $data['rlt'] = isset($rlt[$accountId]) ? $rlt[$accountId] : $rlt;
        $data['language'] = $language;
        $this->render('game_detail/jdfruit', $data);
    }

    // 森林舞会
    public function animals()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);
        $data['language'] = $language;
        $this->render('game_detail/animals', $data);
    }

    // 赛马
    public function horserace()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);
        $data['language'] = $language;
        $this->render('game_detail/horserace', $data);
    }

    // 猴子爬树
    public function thunderbolt()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);
        $data['language'] = $language;
        $this->render('game_detail/thunderbolt', $data);
    }

    // 摩托赛车
    public function motorbike()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);
        $data['language'] = $language;
        $this->render('game_detail/motorbike', $data);
    }

    // 英超联赛
    public function premierleague()
    {
        $data = [];
        $language = $this->lang->language;
        $data = $this->result;
        $data['rlt'] = json_decode($data['rlt'], true);
        $data['language'] = $language;
        $this->render('game_detail/premierleague', $data);
    }
}
