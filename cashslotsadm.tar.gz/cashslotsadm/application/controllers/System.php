<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class System extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('system_lang');
        $this->load->library('encrypt/encrypt_string');
    }

    public function player_login_log()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $account = $this->input->get('account');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $account = $account ? $account : '';

            $params = array(
                'account_id_or_pid' => $account,
                'page' => $page
            );
            if ($startTime && $endTime) {
                $params['time'] = strtotime($startTime);
                $params['time2'] = strtotime($endTime);
            }
            $result = $this->requestApi('/account/playerloginlogs', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/player_login_log', $data);
    }

    public function player_game_log()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $accountId = $this->input->get('account_id');
            $gameId = $this->input->get('game_id');
            $field = $this->input->get('field');
            $field = $field ? $field : 'create_time';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'page' => $page,
                // 'orderby' => $field . ' ' . $order
            );
            $gameId && $params['gameid'] = $gameId;
            $accountId && $params['account'] = $accountId;
            $result = $this->requestApi('/account/playergamelogs', 'GET', $params, true);
            $lists = $result['data']['list'];
            $count = $result['data']['total'];
            $gameLists = $this->getGameList(1);
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                $one['before'] = formatMoney($one['before']);
                $one['coin'] = formatMoney($one['coin']);
                $one['after'] = formatMoney($one['after']);
                if ($one['coin'] > 0) {
                    $one['type'] = $language['win'];
                } else {
                    $one['type'] = $language['bet'];
                }

                if ($one['game_id'] > 0) {
                    $one['game_name'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['name'] : $one['game_id'];
                } else {
                    $one['game_name'] = '';
                }
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/player_game_log', $data);
    }

    public function agent_list()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'id';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'keywords' => $keywords,
                'page' => $page,
                'orderby' => $field . ' ' . $order
            );
            $result = $this->requestApi('/stat/agent_list', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin'] = formatMoney($one['coin']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/agent_list', $data);
    }

    public function agent_score_log()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'create_time';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'keywords' => $keywords,
                'page' => $page,
                'orderby' => $field . ' ' . $order
            );
            $result = $this->requestApi('/stat/agent_score_log', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin'] = formatMoney($one['coin']);
                $one['before'] = formatMoney($one['before']);
                $one['after'] = formatMoney($one['after']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/agent_score_log', $data);
    }

    public function system_win()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            // $field = $this->input->get('field');
            // $field = $field ? $field : 'time';
            // $order = $this->input->get('order');
            // $order = $order ? $order : 'desc';

            $params = array(
                // 'keywords' => $keywords,
                'page' => $page,
                // 'orderby' => $field . ' ' . $order
            );
            if ($startTime && $endTime) {
                $params['time'] = $startTime;
                $params['time2'] = $endTime;
            }
            
            $result = $this->requestApi('/stat/stat_daily_syswin', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['syswin'] = formatMoney($one['syswin']);
                $one['sysout'] = formatMoney($one['sysout']);
                $one['sysin'] = formatMoney($one['sysin']);
                $one['player'] = formatMoney($one['player']);
                $one['agent'] = formatMoney($one['agent']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/system_win', $data);
    }

    public function player_ip()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $account = $this->input->get('account');
            $params = array(
                'account' => $account,
            );
            
            $result = $this->requestApi('/report/player_ip', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['datetime'] = date('Y-m-d H:i:s', $one['create_time']);
                    $one['username'] = $account;
                }
                $count = count($lists);
                echo json_encode(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
            } else {
                $lists = [];
                $count = 0;
                echo json_encode(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
            }
        } else {
            $data['language'] = $language;
            $this->render('system/player_ip', $data);
        }
    }

    public function player_win()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $account = $this->input->get('account');
            $isControl = $this->input->get('is_control');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $params = array(
                'page' => $page
            );
            $account && $params['account'] = str_replace('-', '', $account);
            if ($startTime && $endTime) {
                $params['start_time'] = strtotime($startTime);
                $params['end_time'] = strtotime($endTime) + 86400;
            }
            if ($field && $order) {
                $params['order_by'] = $field . ' ' . $order;
            }
            if ($isControl) {
                $params['is_control'] = $isControl;
            }
            
            $result = $this->requestApi('/report/player_win', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['win'] = formatMoney($one['win']);
                    $one['reload'] = formatMoney($one['reload']);
                }
                $count = $result['data']['total'];
                $total = $result['data']['count'];
                $total['win'] = formatMoney($total['win']);
                $total['reload'] = formatMoney($total['reload']);
            } else {
                $lists = [];
                $count = 0;
            }
            
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'total' => $total));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/player_win', $data);
    }

    public function player_list()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'id';
            $order = $this->input->get('order');
            $order = $order ? $order : 'ASC';

            $params = array(
                'keywords' => $keywords,
                'page' => $page,
                'order_by' => $field . ' ' . $order
            );
            $result = $this->requestApi('/report/all_players', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['coin'] = formatMoney($one['coin']);
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/player_list', $data);
    }

    public function player_detail_list()
    {
        $this->lang->load('user_lang');
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $keywords = $this->input->get('keywords');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');

            $params = array(
                'page' => $page
            );

            if ($startTime && $endTime) {
                if (strtotime($startTime) === strtotime(date('Y-m-d H:i:s', strtotime($startTime))) && strtotime($endTime) === strtotime(date('Y-m-d H:i:s', strtotime($endTime)))) {
                    $params['start_time'] = strtotime($startTime);
                    $params['end_time'] = strtotime($endTime);
                } else {
                    $params['start_time'] = strtotime($startTime);
                    $params['end_time'] = strtotime($endTime) + 86399;
                }
            }

            $keywords && $params['keywords'] = str_replace('-', '', $keywords);
            
            $result = $this->requestApi('/report/player_details', 'GET', $params, true);
            $gameLists = $this->getGameList(1);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                $count = $result['data']['total'];
                foreach ($lists as &$one) {
                    $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                    $one['before'] = formatMoney($one['before']);
                    $one['coin'] = formatMoney($one['coin']);
                    $one['after'] = formatMoney($one['after']);

                    if ($one['game_id'] > 0) {
                        $one['game_name'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['name'] : $one['game_id'];
                    } elseif (in_array($one['type'], [1, 2])) {
                        $one['game_name'] = 'Recharge';
                    } elseif ($one['type'] == 5) {
                        $one['game_name'] = $language['red_envelope'];
                    } elseif ($one['type'] == 6) {
                        $one['game_name'] = 'BigBang';
                    }
                }
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/player_detail_list', $data);
    }

    public function operation_log()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $username = $this->input->get('username');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $field = $field ? $field : 'create_time';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'page' => $page,
                'orderby' => $field . '|' . strtoupper($order)
            );

            if ($startTime && $endTime) {
                $params['time'] = strtotime($startTime);
                $params['time2'] = strtotime($endTime) + 86400;
            }

            $username && $params['username'] = $username;
            $params['lan'] = $this->selectedLang === 'english' ? 2 : 1;
            
            $result = $this->requestApi('/system/log_agent_api', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                $count = $result['data']['total'];
                foreach ($lists as &$one) {
                    $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                }
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/operation_log', $data);
    }

    public function tax_empty_log()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);

            $params = array(
                'page' => $page
            );
            $result = $this->requestApi('/system/tax_empty_log', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                $one['balance'] = formatMoney($one['balance']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/tax_empty_log', $data);
    }

    /**
     * bigbang查询
     */
    public function bigbang_list()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'bigbang';
            $order = $this->input->get('order');
            $order = $order ? $order : 'DESC';
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');

            $params = array(
                'keywords' => $keywords,
                'page' => $page,
                'field' => $field,
                'order' => $order,
                'start_time' => $startTime,
                'end_time' => $endTime
            );
            $result = $this->requestApi('/stat/bigbang_list', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['date'] = $startTime . '~' . $endTime;
                    $one['bigbang'] = formatMoney($one['bigbang']);
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('system/bigbang_list', $data);
    }

    /**
     * bigbang详情列表
     */
    public function bigbang_detail()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $accountId = $this->input->get('account_id');
            $field = $this->input->get('field');
            $field = $field ? $field : 'date';
            $order = $this->input->get('order');
            $order = $order ? $order : 'DESC';
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $username = $this->input->get('username');

            $params = array(
                'account_id' => $accountId,
                'page' => $page,
                'field' => $field,
                'order' => $order,
                'start_time' => $startTime,
                'end_time' => $endTime
            );
            $result = $this->requestApi('/stat/bigbang_detail', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['bigbang'] = formatMoney($one['bigbang']);
                    $one['username'] = $username;
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['start_time'] = $this->input->get('start_time');
        $data['end_time'] = $this->input->get('end_time');
        $data['username'] = $this->input->get('username');
        $data['account_id'] = $this->input->get('account_id');
        $this->render('system/bigbang_detail', $data);
    }

    /**
     * 查账
     */
    public function check_accounts()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);

            $params = array(
                'page' => $page
            );
            $result = $this->requestApi('/stat/check_accounts', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['datetime'] = date('Y-m-d H:i:s', $one['datetime']);
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('system/check_accounts', $data);
    }

    public function new_strategy()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $soul_s1_start_ipnum = $this->input->post('soul_s1_start_ipnum');
            $soul_s1_over_withinhour = $this->input->post('soul_s1_over_withinhour');
            $soul_s1_over_bettotal = $this->input->post('soul_s1_over_bettotal');
            $soul_s1_over_wintotal = $this->input->post('soul_s1_over_wintotal');
            $soul_s1_over_agentwintotal = $this->input->post('soul_s1_over_agentwintotal');
            if ($soul_s1_start_ipnum == "" || $soul_s1_over_withinhour == "" || $soul_s1_over_bettotal == "" || $soul_s1_over_wintotal == "" || $soul_s1_over_agentwintotal == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }

            $soul_s1_over_bettotal = json_encode(json_decode($soul_s1_over_bettotal));
            $soul_s1_over_wintotal = json_encode(json_decode($soul_s1_over_wintotal));

            $str = "soul_s1_start_ipnum[@kv@]{$soul_s1_start_ipnum}[@par@]soul_s1_over_withinhour[@kv@]{$soul_s1_over_withinhour}[@par@]soul_s1_over_bettotal[@kv@]{$soul_s1_over_bettotal}[@par@]soul_s1_over_wintotal[@kv@]{$soul_s1_over_wintotal}[@par@]soul_s1_over_agentwintotal[@kv@]{$soul_s1_over_agentwintotal}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('系统设置', "新手策略设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('系统设置', "新手策略设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('system/new_strategy', $data);
    }

    public function new_strategy_list()
    {
        $this->lang->load('prob_lang');
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);

            $params = array(
                'page' => $page
            );
            $result = $this->requestApi('/stat/new_strategy_list', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['login_time'] = date('Y-m-d H:i:s', $one['login_time']);
                    $one['win'] = formatMoney($one['win']);
                    if ($one['status'] == 1) {
                        $one['status_name'] = $language['new_strategy_list_status_1'];
                    } else {
                        $one['status_name'] = $language['new_strategy_list_status_2'];
                    }
                    $one['prob'] = $language['prob_' . $one['prob']];
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/new_strategy_list', $data);
    }

    public function new_strategy_count()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);

            $params = array(
                'page' => $page
            );
            $result = $this->requestApi('/stat/new_strategy_count', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['datetime'] = date('Y-m-d H:i:s', $one['datetime']);
                    $one['win'] = formatMoney($one['win']);
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('system/new_strategy_count', $data);
    }

    public function promote()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $promoter_profit_switch = $this->input->post('promoter_profit_switch');
            $promoter_profit_par = $this->input->post('promoter_profit_par');
            $promoter_profit_plsit = $this->input->post('promoter_profit_plsit');
            $promoter_profit_switch = $promoter_profit_switch ? $promoter_profit_switch : 0;
            if ($promoter_profit_switch === "" || $promoter_profit_par == "" || $promoter_profit_plsit == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }

            $promoter_profit_plsit = json_encode(json_decode($promoter_profit_plsit));

            $str = "promoter_profit_switch[@kv@]{$promoter_profit_switch}[@par@]promoter_profit_par[@kv@]{$promoter_profit_par}[@par@]promoter_profit_plsit[@kv@]{$promoter_profit_plsit}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('系统设置', "推广员设置设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('系统设置', "推广员设置设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('system/promote', $data);
    }

    public function transfer()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $username = $this->input->get('username', 1);

            $params = array(
                'username' => $username,
                'page' => $page
            );
            $result = $this->requestApi('/stat/transfer', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                    $one['coin'] = formatMoney(-1*$one['coin']);
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/transfer', $data);
    }

    public function game_stat()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $field = $this->input->get('field');
            $field = $field ? $field : 'create_time';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'keywords' => $keywords,
                'page' => $page,
                'orderby' => $field . ' ' . $order
            );
            $result = $this->requestApi('/stat/agent_score_log', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin'] = formatMoney($one['coin']);
                $one['before'] = formatMoney($one['before']);
                $one['after'] = formatMoney($one['after']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/agent_score_log', $data);
    }

    //人数数据统计, ltv, 留存等
    public function state_player_count()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $startDate = date('Ymd', strtotime($startDate));
            $endDate = date('Ymd', strtotime($endDate));
            $this->load->model('Statemarketday_model', 'marketday');
            $lists = $this->marketday->getListData($startDate, $endDate);

            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_player_count', $data);
    }

    //人数数据统计, ltv, 留存等导出
    public function state_player_count_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $startDate = date('Ymd', strtotime($startDate));
        $endDate = date('Ymd', strtotime($endDate));
        $this->load->model('Statemarketday_model', 'marketday');
        $lists = $this->marketday->getListData($startDate, $endDate);
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("人数数据统计_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['日期', 'DNU', 'DAU', 'ARPU', 'ARPPU','充值笔数', '付费率', '付费人数', '付费金额', '多次付费人数', '多次付费金额', '第1次付费人数', '第1次付费金额', '次留', '3留' , '7留', '14留', '30留', '当日ltv', '3日ltv', '7日ltv', '14日ltv', '30日ltv'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['day']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['dnu']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['dau']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['arpu']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['arppu']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(5, $row, $data['ordernum']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(6, $row, $data['payrate']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(7, $row, $data['paynum']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(8, $row, $data['payamount']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(9, $row, $data['pay2num']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(10, $row, $data['pay2amount']);
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(11, $row, intval($data['paynum'] - $data['pay2num']));
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(12, $row, $data['payamount'] - $data['pay2amount']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(13, $row, $data['stay1']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(14, $row, $data['stay3']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(15, $row, $data['stay7']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(16, $row, $data['stay14']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(17, $row, $data['stay30']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(18, $row, $data['ltv1']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(19, $row, $data['ltv3']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(20, $row, $data['ltv7']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(21, $row, $data['ltv14']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(22, $row, $data['ltv30']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "人数数据统计_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    private function get_game_today_data($startDate, $endDate) {
        $this->load->model('Gametoday_model', 'gametoday');
        $lists = $this->gametoday->getListData($startDate, $endDate);
        $gameLists = $this->getGameList(1);
        foreach ($lists as $k=>$v) {
            $lists[$k]['day'] = date('Y-m-d', $v['create_time']);
            if ($v['allbet'] > 0 ) {
                $lists[$k]['rate'] = ($v['allwin'] / $v['allbet']) * 100 . '%';
            } else {
                $lists[$k]['rate'] = '0%';
            }
            $lists[$k]['game_id'] = isset($gameLists[$v['game_id']]) ? $gameLists[$v['game_id']]['name'] : $v['game_id'];
        }
        return $lists;
    }

    //今日注册玩家每个游戏的参与人数、局数、赢钱、下注等
    public function state_game_today()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $lists = $this->get_game_today_data($startDate, $endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_game_today', $data);
    }

    //今日注册玩家每个游戏的导出 -- 新用户游戏数据统计
    public function state_game_today_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $lists = $this->get_game_today_data($startDate, $endDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("新用户游戏数据统计_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['日期', '游戏ID', '总次数', '总人数', '总下注', '总赢钱', '回报率'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['day']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['game_id']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['alltimes']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['allusers']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['allbet']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(5, $row, $data['allwin']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(6, $row, $data['rate']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "新用户游戏数据统计_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    private function get_game_active_data($startDate, $endDate) {
        $this->load->model('Gameactive_model', 'gameactive');
        $lists = $this->gameactive->getListData($startDate, $endDate);
        $gameLists = $this->getGameList(1);
        foreach ($lists as $k=>$v) {
            $lists[$k]['day'] = date('Y-m-d', $v['create_time']);
            if ($v['allbet'] > 0 ) {
                $lists[$k]['rate'] = ($v['allwin'] / $v['allbet']) * 100 . '%';
            } else {
                $lists[$k]['rate'] = '0%';
            }
            $lists[$k]['game_id'] = isset($gameLists[$v['game_id']]) ? $gameLists[$v['game_id']]['name'] : $v['game_id'];
        }
        return $lists;
    }

    //今日登录玩家每个游戏的参与人数、局数、赢钱、下注等
    public function state_game_active()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $lists = $this->get_game_active_data($startDate, $endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_game_active', $data);
    }

    //今日登录玩家每个游戏导出 -- 活跃用户游戏数据统计
    public function state_game_active_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $lists = $this->get_game_active_data($startDate, $endDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("活跃用户游戏数据统计_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['日期', '游戏ID', '总次数', '总人数', '总下注', '总赢钱', '回报率'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['day']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['game_id']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['alltimes']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['allusers']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['allbet']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(5, $row, $data['allwin']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(6, $row, $data['rate']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "活跃用户游戏数据统计_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    private function get_reward_active_data($startDate, $endDate) {
        $this->load->model('Rewardactive_model', 'rewardactive');
        $lists = $this->rewardactive->getListData($startDate, $endDate);
        foreach ($lists as $k=>$v) {
            $lists[$k]['day'] = date('Y-m-d', $v['create_time']);
        }
        return $lists;
    }

    //今日登录玩家领取每种奖励的统计等
    public function state_reward_active()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $lists = $this->get_reward_active_data($startDate, $endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_reward_active', $data);
    }

    //今日登录玩家领取每种奖励的统计导出 -- 活跃用户领取奖励统计
    public function state_reward_active_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $lists = $this->get_reward_active_data($startDate, $endDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("活跃用户领取奖励统计_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['日期', '奖励类型', '总人数', '总金币', '金币价值'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['day']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['act']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['allusers']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['allcoin']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['allcost']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "活跃用户领取奖励统计_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    private function get_user_online_data($startDate, $endDate) {
        $this->load->model('Useronline_model', 'onlinemodel');
        $lists = $this->onlinemodel->getListData($startDate, $endDate);
        $dict = [];
        $dict[1] = '30s';
        $dict[2] = '31~60s';
        $dict[3] = '1~3min';
        $dict[4] = '3~10min';
        $dict[5] = '10~30min';
        $dict[6] = '30min~1h';
        $dict[7] = '1h~2h';
        $dict[8] = '2h+';

        foreach ($lists as $k=>$v) {
            $lists[$k]['day'] = date('Y-m-d', $v['create_time']);
            $lists[$k]['stype'] = isset($dict[$v['stype']]) ? $dict[$v['stype']] : '未知';
        }
        return $lists;
    }

    //用户在线时长统计
    public function state_user_online()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $lists = $this->get_user_online_data($startDate, $endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_user_online', $data);
    }

    //用户在线时长统计导出
    public function state_user_online_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $lists = $this->get_user_online_data($startDate, $endDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("用户在线时长_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['日期', '在线时长类型', '总人数', '金币平均值'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['day']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['stype']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['allusers']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['avgcoin']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "用户在线时长_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    private function get_newuser_online_data($startDate) {
        $this->load->model('User_model', 'usermodel');
        $lists = $this->usermodel->getNewUserOnlineData($startDate);
        $dict = [];
        $dict[1] = '30s';
        $dict[2] = '31~60s';
        $dict[3] = '1~3min';
        $dict[4] = '3~10min';
        $dict[5] = '10~30min';
        $dict[6] = '30min~1h';
        $dict[7] = '1h~2h';
        $dict[8] = '2h+';

        foreach ($lists as $k=>$v) {
            // $lists[$k]['day'] = date('Y-m-d', $v['create_time']);
            $lists[$k]['stype'] = isset($dict[$v['onlinetype']]) ? $dict[$v['onlinetype']] : '未知';
        }
        return $lists;
    }

    //新用户在线时长统计
    public function state_newuser_online()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $lists = $this->get_newuser_online_data($startDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_newuser_online', $data);
    }

    //新用户在线时长统计导出
    public function state_newuser_online_export(){
        $startDate = $this->input->get('start_time');
        $lists = $this->get_newuser_online_data($startDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("新用户在线时长_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['在线时长类型', '总人数'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
            // $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['day']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['stype']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['allusers']);
            // $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['avgcoin']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "新用户在线时长_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    private function get_user_level_data($startDate, $endDate) {
        $this->load->model('User_model', 'usermodel');
        $lists = $this->usermodel->getDistByLevel($startDate, $endDate);
        $dict = [];
        $dict[1] = '1级';
        $dict[2] = '2级';
        $dict[3] = '3级';
        $dict[4] = '4级';
        $dict[5] = '5级';
        $dict[6] = '6级';
        $dict[7] = '7级';
        $dict[8] = '8级';
        $dict[9] = '9级';
        $dict[10] = '10级';
        $dict[11] = '11~20级';
        $dict[12] = '20~30级';
        $dict[13] = '30~50级';
        $dict[14] = '50级+';
        foreach ($lists as $k=>$v) {
//            $lists[$k]['day'] = date('Y-m-d', $v['create_time']);
            $lists[$k]['level_type'] = isset($dict[$v['level_type']]) ? $dict[$v['level_type']] : '未知';
        }
        return $lists;
    }
    //用户等级分布
    public function state_user_level()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $lists = $this->get_user_level_data($startDate, $endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_user_level', $data);
    }

    //用户等级分布导出
    public function state_user_level_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $lists = $this->get_user_level_data($startDate, $endDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("用户等级分布_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['等级区间', '人数', '金币价值', '总破产次数', '充值总额'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
//            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['day']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['level_type']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['allusers']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['avgcoinval']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['allrupt']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['chargeamount']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "用户等级分布_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //注册当天首充用户订单明细
    public function state_user_orderlist()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $this->load->model('Userorder_model', 'ordermodel');
            $lists = $this->ordermodel->getListData($startDate, $endDate);
            foreach ($lists as $k=>$v) {
                $lists[$k]['create_time'] = date('Y-m-d H:i:s', $v['create_time']);
//                $lists[$k]['level_type'] = isset($dict[$v['level_type']]) ? $dict[$v['level_type']] : '未知';
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_user_orderlist', $data);
    }

    //注册当天首充用户订单明细导出
    public function state_user_orderlist_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $this->load->model('Userorder_model', 'ordermodel');
        $lists = $this->ordermodel->getListData($startDate, $endDate);
        foreach ($lists as $k=>$v) {
            $lists[$k]['create_time'] = date('Y-m-d H:i:s', $v['create_time']);
//                $lists[$k]['level_type'] = isset($dict[$v['level_type']]) ? $dict[$v['level_type']] : '未知';
        }
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("注册当天首充用户订单明细_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['UID', '用户等级', '用户金币', '订单商品id', '商品名称', '商品价格', '下单时间'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['uid']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['user_level']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['user_coin']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['shopid']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['title']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(5, $row, $data['amount']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(6, $row, $data['create_time']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "注册当天首充用户订单明细_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //注册当天首充用户统计
    public function state_user_order()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $this->load->model('Userorder_model', 'ordermodel');
            $lists = $this->ordermodel->getRegStateData($startDate, $endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_user_order', $data);
    }

    //注册当天首充用户统计导出
    public function state_user_order_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $this->load->model('Userorder_model', 'ordermodel');
        $lists = $this->ordermodel->getRegStateData($startDate, $endDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("注册当天首充用户统计_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['下单时间', '总人数', '总金额'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data ){
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['createdate']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['num']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['price']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "注册当天首充用户统计_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //最近的支付成功的物品排名
    public function state_shopitem_sort()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $this->load->model('Userorder_model', 'ordermodel');
            $lists = $this->ordermodel->getOrderStateData($startDate, $endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_shopitem_sort', $data);
    }

    //最近的支付成功的物品排名导出
    public function state_shopitem_sort_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $this->load->model('Userorder_model', 'ordermodel');
        $lists = $this->ordermodel->getOrderStateData($startDate, $endDate);
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("最近的支付成功的物品排名_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['商品ID', '商品名', '订单数', '总金额'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['shopid']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['title']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['total']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['price']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "最近的支付成功的物品排名_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //首充后续充
    public function state_shoporder_renew()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $endDate = $this->input->get('end_time');
            $this->load->model('Shoprenew_model', 'shoprenew');
            $lists = $this->shoprenew->getListData($startDate, $endDate);
            foreach ($lists as $k=>$v) {
                $lists[$k]['create_time'] = date('Y-m-d', $v['create_time']);
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_shoporder_renew', $data);
    }

    //首充后续充导出
    public function state_shoporder_renew_export(){
        $startDate = $this->input->get('start_time');
        $endDate = $this->input->get('end_time');
        $this->load->model('Shoprenew_model', 'shoprenew');
        $lists = $this->shoprenew->getListData($startDate, $endDate);
        foreach ($lists as $k=>$v) {
            $lists[$k]['create_time'] = date('Y-m-d', $v['create_time']);
        }
        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("首充后续充_". $startDate . "_to_".$endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['日期', '当日充值人数', '当日充值金额', '次日充值人数', '次日充值金额', '3日充值人数', '3日充值金额', '4日充值人数', '4日充值金额', '5日充值人数', '5日充值金额', '6日充值人数', '6日充值金额', '7日充值人数', '7日充值金额', '8日充值人数', '8日充值金额', '9日充值人数', '9日充值金额', '10日充值人数', '10日充值金额'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['create_time']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['users1']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['amount1']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['users2']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['amount2']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(5, $row, $data['users3']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(6, $row, $data['amount3']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(7, $row, $data['users4']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(8, $row, $data['amount4']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(9, $row, $data['users5']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(10, $row, $data['amount5']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(11, $row, $data['users6']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(12, $row, $data['amount6']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(13, $row, $data['users7']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(14, $row, $data['amount7']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(15, $row, $data['users8']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(16, $row, $data['amount8']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(17, $row, $data['users9']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(18, $row, $data['amount9']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(19, $row, $data['users10']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(20, $row, $data['amount10']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "首充后续充_". $startDate . "_to_".$endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //流失等级百分比分布
    public function state_level_dist()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $endDate = $this->input->get('end_time');
            $this->load->model('User_model', 'usermodel');
            $lists = $this->usermodel->getLevelDistribution($endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_level_dist', $data);
    }

    //流失等级百分比分布导出
    public function state_level_dist_export(){
        $endDate = $this->input->get('end_time');
        $this->load->model('User_model', 'usermodel');
        $lists = $this->usermodel->getLevelDistribution($endDate);

        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("流失等级百分比分布_". $endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);

        $fields  = ['等级分布', '人数', '百分比'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['title']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['num']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['rate']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "流失等级百分比分布_". $endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //流失存量金币百分比分布
    public function state_coin_dist()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $endDate = $this->input->get('end_time');
            $this->load->model('User_model', 'usermodel');
            $lists = $this->usermodel->getCoinDistribution($endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_coin_dist', $data);
    }

    //流失存量金币百分比分布导出
    public function state_coin_dist_export(){
        $endDate = $this->input->get('end_time');
        $this->load->model('User_model', 'usermodel');
        $lists = $this->usermodel->getCoinDistribution($endDate);

        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("流失存量金币百分比分布_". $endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);

        $fields  = ['金币分布', '人数', '百分比'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['title']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['num']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['rate']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "流失存量金币百分比分布_". $endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //流失充值金额百分比分布
    public function state_recharge_dist()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $endDate = $this->input->get('end_time');
            $this->load->model('User_model', 'usermodel');
            $lists = $this->usermodel->getRechargeDistribution($endDate);
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_recharge_dist', $data);
    }

    //流失充值金额百分比分布
    public function state_recharge_dist_export(){
        $endDate = $this->input->get('end_time');
        $this->load->model('User_model', 'usermodel');
        $lists = $this->usermodel->getRechargeDistribution($endDate);

        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("流失充值金额百分比分布_". $endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);

        $fields  = ['充值金额分布', '人数', '百分比'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['title']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['num']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['rate']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "流失充值金额百分比分布_". $endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //流失最后游戏百分比分布
    public function state_gameloss_dist()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $endDate = $this->input->get('end_time');
            $this->load->model('User_model', 'usermodel');
            $lists = $this->usermodel->getGameLostDist($endDate);
            $gameLists = $this->getGameList();
            foreach($lists as $k=>$v) {
                $lists[$k]['title'] = isset($gameLists[$k]) ? $gameLists[$k]['name'] : '';
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_gameloss_dist', $data);
    }

    //导出流失最后游戏百分比分布
    public function state_gameloss_dist_export(){
        $endDate = $this->input->get('end_time');
        $this->load->model('User_model', 'usermodel');
        $lists = $this->usermodel->getGameLostDist($endDate);
        $gameLists = $this->getGameList();
        foreach($lists as $k=>$v) {
            $lists[$k]['title'] = isset($gameLists[$k]) ? $gameLists[$k]['name'] : '';
        }

        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("流失最后游戏百分比分布_". $endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);

        $fields  = ['游戏名称', '人数', '百分比'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['title']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['num']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['rate']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "流失最后游戏百分比分布_". $endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

    //流失用户的列表
    public function state_gameloss_list()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $endDate = $this->input->get('end_time');
            $page = $this->input->get('page');
            if($page <= 0) {
                $page = 1;
            }
            $this->load->model('User_model', 'usermodel');
            $lists = $this->usermodel->getLostList($endDate, $page);
            $gameLists = $this->getGameList();
            foreach($lists as $k=>$v) {
                $lists[$k]['last_game_title'] = isset($gameLists[$v['last_game_id']]) ? $gameLists[$v['last_game_id']]['name'] : '';
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('system/state_gameloss_list', $data);
    }

    //导出流失用户列表为excel
    public function stat_gameloss_list_export(){
        $endDate = $this->input->get('end_time');
        $page = $this->input->get('page');
        if($page <= 0) {
            $page = 1;
        }
        $this->load->model('User_model', 'usermodel');
        $lists = $this->usermodel->getLostList($endDate, $page, true);
        $gameLists = $this->getGameList();
        foreach($lists as $k=>$v) {
            $lists[$k]['last_game_title'] = isset($gameLists[$v['last_game_id']]) ? $gameLists[$v['last_game_id']]['name'] : '';
        }

        $this->load-> library('PHPExcel');
        $this->load-> library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("流失用户列表_". $endDate)->setDescription("none");
        $objPHPExcel->setActiveSheetIndex(0);
        $fields  = ['UID', '金币', '等级', '充值金额', '创建时间', '最后登录时间','最后游戏','最后游戏时间'];
        $col = 0;
        foreach($fields as $field){
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }

        $row = 2;
        foreach($lists as $data )
        {
            $objPHPExcel ->getActiveSheet() -> setCellValueByColumnAndRow(0, $row, $data['uid']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(1, $row, $data['coin']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(2, $row, $data['level']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(3, $row, $data['price']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(4, $row, $data['create_time']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(5, $row, $data['login_time']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(6, $row, $data['last_game_title']);
            $objPHPExcel -> getActiveSheet() -> setCellValueByColumnAndRow(7, $row, $data['last_game_time']);
            $row++;
        }
        $objPHPExcel -> setActiveSheetIndex(0);
        $objWriter = IOFactory :: createWriter($objPHPExcel, 'Excel5');
        header('Content-Type:application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "流失用户列表_". $endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter -> save('php://output');
    }

}