<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/2/5
 * Time: 10:18
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Accountdata extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('account_lang');
    }

    // 代理管理
    public function index()
    {
        $this->lang->load('user_lang');
        $language = $this->lang->language;
        $data['language'] = $language;

        if (isset($this->account['vid']) && $this->account['vid']) { //子账号
            $result = $this->requestApi('/account/current', 'GET', array());
            $gid = explode(',', $result['data']['virtual_group_id']);
            $data['permission'] = $gid;
        }
        $id = $this->input->get('id');
        $data['id'] = $id;
        $this->render('accountdata/index', $data);
    }

    /***
     *
     */
    public function getData(){
        $language = $this->lang->language;
        $sql = "select dau_not_spin,dau_spin,reg_spin_count,active_not_spin_count,active_spin_count,activeuser_spin_count,`day`  from stat_market_day  order by id desc limit 0,100";
        $adm = $this->load->database('adm', TRUE);
        $data = $adm->query($sql)->result_array();
        jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        exit();
    }

    /***
     * 活跃玩家子游戏数据
     * 所有玩家子游戏数据
     */
    public function firstPlay(){
        $language = $this->lang->language;
        $n = "-30";
        $start = strtotime($this->input->post('start'));
        $end = strtotime($this->input->post('end'));

        $startDate = date("Y-m-d", strtotime($n . " day"));

        $start = $start ? $start:strtotime($startDate); //今天统计昨天的
        $end = $end ? :time();
        $type = $this->input->post('type',1);
        $adm = $this->load->database('adm', TRUE);
        if ($type == 1){
            $sql_played_game = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_game_detail_today  where create_time >= {$start} and create_time < {$end}  order by create_time desc";
            $data = $adm->query($sql_played_game)->result_array();
        }else{
//            $sql_played_game = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_game_detail_today where create_time >= {$start} and create_time < {$end} group by create_times order by create_time desc";
//            $data_all= $adm->query($sql_played_game)->result_array();
            $sql_all_played = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_game_detail where create_time >= {$start} and create_time < {$end} order by create_time desc limit 0,500";
            $data = $adm->query($sql_all_played)->result_array();
//            foreach ($data as &$val){
//                foreach ($data_all as $value){
//                    if ($val['game_id'] == $value['game_id']){
//                        $val['allusers'] += $value['allusers'];
//                        $val['allbet'] += $value['allbet'];
//                        $val['allwin'] += $value['allwin'];
//                        $val['bet_one'] += $value['bet_one'];
//                        $val['bet_two'] += $value['bet_one'];
//                        $val['bet_other'] += $value['bet_other'];
////                        $val['bankrupt_user_count'] = $value['bankrupt_user_count'];
////                        $val['bankrupt_count'] = $value['bankrupt_count'];
//                    }
//                }
//
//            }
        }
        jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        exit();
    }

    /***
     * 新增玩家子游戏数据
     */
    public function playGame(){
        $language = $this->lang->language;
        $n = "-30";
        $type = $this->input->post('type',1);
        $startDate = date("Y-m-d", strtotime($n . " day"));
        $start = strtotime($startDate); //今天统计昨天的
        $end = $start + 86400 * abs($n);
        $adm = $this->load->database('adm', TRUE);
        if ($type== 1){
            $sql_played_game = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_game_data where create_time >= {$start} and create_time < {$end} order by create_time desc";
            $data = $adm->query($sql_played_game)->result_array();
            foreach ($data as &$val){
                $val['played_count'] = $val['played_six_game'] + $val['played_five_game'] + $val['played_more_game'];
            }
        }elseif ($type == 2){
            $sql_played_game = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_game_data where create_time >= {$start} and create_time < {$end} order by create_time desc";
            $data = $adm->query($sql_played_game)->result_array();
            foreach ($data as &$val){
                $val['played_count'] = $val['active_five_game'] + $val['active_six_game'] + $val['active_more_game'];
            }
        }else{
            $sql_played_game = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_game_data where create_time >= {$start} and create_time < {$end} order by create_time desc";
            $data = $adm->query($sql_played_game)->result_array();
            foreach ($data as &$val){
                $val['active_not_played_game'] += $val['not_play_game'];
                $val['active_one_game'] += $val['played_one_game'];
                $val['active_two_game'] += $val['played_two_game'];
                $val['active_three_game'] += $val['played_three_game'];
                $val['active_four_game'] += $val['played_four_game'];
                $val['dau_count'] += $val['all_count'];
                $val['played_count'] = $val['active_four_game'] + $val['played_five_game']+ $val['active_more_game'] + $val['played_six_game'] + $val['played_five_game'] + $val['played_more_game'];
            }
        }
        jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        exit();
    }

    /***
     *
     */
    public function getDnuCoin(){

        $start = strtotime($this->input->post('start_time'))? : strtotime('-1 day');
        $end = strtotime($this->input->post('end_time').":59")?:time();
        $language = $this->lang->language;

        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where create_time < {$end} and create_time >= {$start} and coin <100000 group by create_times order by create_time desc";
        $data = [];

        $data['hundred_one'] = $this->db->query($sql)->result_array();

        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where create_time < {$end} and create_time >= {$start} and coin >= 100000 and coin <= 500000 order by create_time desc";
        $data['hundred_five'] = $this->db->query($sql)->result_array();

        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where create_time < {$end} and create_time >= {$start} and coin >= 500000 and coin < 1000000  order by create_time desc";

        $data['hundred_ten'] = $this->db->query($sql)->result_array();
        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where create_time < {$end} and create_time >= {$start} and coin >= 1000000 and coin < 5000000 order by create_time desc";

        $data['million_one'] = $this->db->query($sql)->result_array();
        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where create_time < {$end} and create_time >= {$start} and coin >= 5000000   order by create_time desc";
        $data['million_five'] = $this->db->query($sql)->result_array();

        $dates_diff = floor(($end - $start) / 86400);

        $dates_arr = [];
        for ($i = 0 ;$i <= $dates_diff ; $i++ ){
            $dates_arr[] = date('Y-m-d',strtotime("-{$i} day",$end));
        }
        $data['dates'] = $dates_arr;
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);

    }

    public function getDauCoin(){
        $start = strtotime(date('Y-m-d'));
        $end = time();

        $language = $this->lang->language;

        $regUserSql = "select uid from d_user where create_time<{$end} and  create_time>={$start}";
        $user_ids_arr = $this->db->query("select distinct uid from d_user_login_log where create_time<{$end} and  create_time>={$start}")->result_array();
        $user_ids = implode(',',array_column($user_ids_arr,'uid'));

        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where coin <100000 and uid not in ({$regUserSql}) and uid in ({$user_ids}) order by create_time desc";
        $data = [];

        $data['hundred_one'] = $this->getCount($sql,$this->db);
        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where coin >= 100000 and coin <= 500000 and uid in ({$user_ids}) and uid not in ({$regUserSql})order by create_time desc";

        $data['hundred_five'] = $this->getCount($sql,$this->db);
        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where coin >= 500000 and coin < 1000000 and uid in ({$user_ids}) and uid not in ({$regUserSql}) order by create_time desc";

        $data['hundred_ten'] = $this->getCount($sql,$this->db);
        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where coin >= 1000000 and coin < 5000000 and uid in ({$user_ids}) and uid not in ({$regUserSql}) order by create_time desc";

        $data['million_one'] = $this->getCount($sql,$this->db);

        $sql = "select count(uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user where coin >= 5000000 and uid in ({$user_ids}) and uid not in ({$regUserSql}) order by create_time desc";

        $data['million_five'] = $this->getCount($sql,$this->db);

        $data['dates'] = date('Y-m-d');
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
    }

    /****
     * 金币回收监控
     */
    public function coinBack(){
        $language = $this->lang->language;
        $sql = "select sum(sgd.allbet) as allbet, FROM_UNIXTIME(sgd.create_time,'%Y-%m-%d') as create_times from stat_game_detail as sgd group by create_times order by sgd.create_time desc limit 100";

        $adm = $this->load->database('adm', TRUE);

        $data = $adm->query($sql)->result_array();
        foreach ($data as &$val) {
            $val['allbet'] = intval($val['allbet']);
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);

    }

    public function getCount($sql, $db)
    {
        $ret = $db->query($sql)->result_array();
        $count = isset($ret[0]['t']) ? $ret[0]['t'] : 0;
        return $count;
    }

    /***
     * 玩牌数据
     */
    public function playCard(){
        $language = $this->lang->language;
        $adm = $this->load->database('adm', TRUE);

        $sql = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_game_play_log order by create_time desc";

        $data = $adm->query($sql)->result_array();
        foreach ($data as &$val){
            $val['json_data'] = json_decode($val['json_data'],true)?:[];
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
    }

    /***
     * 金币发放情况
     */
    public function coinLog(){
        $language = $this->lang->language;
        $adm = $this->load->database('adm', TRUE);

        $sql = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_coin_log group by create_times order by create_time desc limit 100";

        $data = $adm->query($sql)->result_array();
        foreach ($data as &$val){
            $val['login_coin_count'] = intval($val['login_coin_count']);
            $val['sign_coin_count'] = intval($val['sign_coin_count']);
            $val['turntable_coin_count'] = intval($val['turntable_coin_count']);
            $val['bind_fb_coin_count'] = intval($val['bind_fb_coin_count']);
            $val['first_login_coin_count'] = intval($val['first_login_coin_count']);
            $val['level_up_coin_count'] = intval($val['level_up_coin_count']);
            $val['guagua_coin_count'] = intval($val['guagua_coin_count']);
            $val['bankruptcy_coin_count'] = intval($val['bankruptcy_coin_count']);
            $val['mission_coin_count'] = intval($val['mission_coin_count']);
            $val['sonspin_coin_count'] = intval($val['sonspin_coin_count']);
            $val['firendsend_coin_count'] = intval($val['firendsend_coin_count']);
            $val['firendprize_coin_count'] = intval($val['firendprize_coin_count']);
            $val['mail_coin_count'] = intval($val['mail_coin_count']);
            $val['special_coin_count'] = intval($val['special_coin_count']);
            $val['all_coin_count'] = intval($val['all_coin_count']);
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
    }
}