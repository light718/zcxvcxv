<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Game extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('game_lang');
        $this->load->library('encrypt/encrypt_string');
    }

    public function index()
    {
        $language = $this->lang->language;

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['data']['pool_tax_limitup'] = formatMoney($data['data']['pool_tax_limitup']);
        $data['data']['pool_jp_outline'] = formatMoney($data['data']['pool_jp_outline']);
        $data['data']['player_vipbaseline'] = formatMoney($data['data']['player_vipbaseline']);

        $result = $this->requestApi('/stat/game_setting_coin_data', 'GET', array());
        $data['coin'] = $result['data'];
        $data['coin']['sys_tax'] = formatMoney($data['coin']['sys_tax']);
        $data['coin']['reload'] = formatMoney($data['coin']['reload']);
        $data['coin']['withdraw'] = formatMoney($data['coin']['withdraw']);
        $data['coin']['total_diff'] = formatMoney($data['coin']['total_diff']);

        $result = $this->requestApi('/stat/game_setting_cur_data', 'GET', array());
        $cur = $result['data'];
        $cur['tax_ratio'] = $cur['cur_tax'] ? (round($cur['cur_tax'] / $cur['pool_tax_limitup'], 2) * 100 . '%') : 0;
        $cur['jackpot_ratio'] = $cur['jackpot'] ? (round($cur['jackpot'] / $cur['pool_jp_outline'], 2) * 100 . '%') : 0;
        $cur['minutes'] = $cur['reset_time'] < 0 ? 'In progress' : (ceil($cur['reset_time'] / 60) . $language['minute']);
        $cur['reset_time'] = $cur['reset_time'] < 0 ? '' : ('('.date("Y-m-d H:i:s", time() + $cur['reset_time']).')');
        $cur['pool_tax_limitup'] = formatMoney($cur['pool_tax_limitup']);
        $cur['pool_jp_outline'] = formatMoney($cur['pool_jp_outline']);
        $cur['cur_tax'] = formatMoney($cur['cur_tax']);
        $cur['normal'] = formatMoney($cur['normal']);
        $cur['jackpot'] = formatMoney($cur['jackpot']);
        $cur['redbag'] = formatMoney($cur['redbag']);
        $data['cur'] = $cur;

        $data['language'] = $language;
        $this->render('game/index', $data);
    }

    //在线人数 图表
    public function online()
    {
        $language = $this->lang->language;
        $data['language'] = $language;

        $this->render('game/online', $data);
    }

    public function curData()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $result = $this->requestApi('/stat/game_setting_cur_data', 'GET', array());
            $cur = $result['data'];
            $cur['tax_ratio'] = $cur['cur_tax'] ? (round($cur['cur_tax'] / $cur['pool_tax_limitup'], 2) * 100 . '%') : 0;
            $cur['jackpot_ratio'] = $cur['jackpot'] ? (round($cur['jackpot'] / $cur['pool_jp_outline'], 2) * 100 . '%') : 0;
            $cur['minutes'] = $cur['reset_time'] < 0 ? 'In progress' : (ceil($cur['reset_time'] / 60) . $language['minute']);
            $cur['reset_time'] = $cur['reset_time'] < 0 ? '' : ('('.date("Y-m-d H:i:s", time() + $cur['reset_time']).')');
            $cur['pool_tax_limitup'] = formatMoney($cur['pool_tax_limitup']);
            $cur['pool_jp_outline'] = formatMoney($cur['pool_jp_outline']);
            $cur['cur_tax'] = formatMoney($cur['cur_tax']);
            $cur['normal'] = formatMoney($cur['normal']);
            $cur['jackpot'] = formatMoney($cur['jackpot']);
            $cur['redbag'] = formatMoney($cur['redbag']);
            $data['cur'] = $cur;
            jsonReturn(EXIT_SUCCESS, '', $data);
        }
    }

    public function emptyPool()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $type = $this->input->post('type');
            if ($type == 1) {
                $result = $this->requestApi('/system/redis_balance_pooltax_flush', 'PUT', []);
            } else if ($type == 2) {
                $result = $this->requestApi('/system/redis_balance_poolnormal_flush', 'PUT', []);
            } else if ($type == 3) {
                $result = $this->requestApi('/system/redis_balance_pooljp_flush', 'PUT', []);
            }
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($type == 1) {
                    $this->record('游戏配置', "清空抽水池成功");
                } elseif ($type == 2) {
                    $this->record('游戏配置', "清空普通奖池成功");
                } elseif ($type == 3) {
                    $this->record('游戏配置', "清空Jackpot奖池成功");
                }
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                if ($type == 1) {
                    $this->record('游戏配置', "清空抽水池失败");
                } elseif ($type == 2) {
                    $this->record('游戏配置', "清空普通奖池失败");
                } elseif ($type == 3) {
                    $this->record('游戏配置', "清空Jackpot奖池失败");
                }
            }
        }
    }

    public function commission()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startTime = $this->input->post('start_time');
            $endTime = $this->input->post('end_time');
            $type = $this->input->post('type');
            if ($startTime && $endTime) {
                $params = [
                    'start_time' => strtotime($startTime),
                    'end_time' => strtotime($endTime) + 86399
                ];
                $result = $this->requestApi('/stat/commission', 'GET', $params);
                $commission = formatMoney($result['data']);
                jsonReturn(EXIT_SUCCESS, '', ['commission' => $commission]);
            } else {
                $type = $type ? $type : 1;
                $startTime = $endTime = 0;
                if ($type == 2) {
                    $startTime = strtotime(date('Y-m-d'));
                    $endTime = time();
                } elseif ($type == 3) {
                    $startTime = strtotime('-7 days');
                    $endTime = time();
                } elseif ($type == 4) {
                    $startTime = strtotime(date('Y-m-01'));
                    $endTime = time();
                }
                $params = [
                    'start_time' => $startTime,
                    'end_time' => $endTime
                ];
                $result = $this->requestApi('/stat/commission', 'GET', $params);
                $commission = $result['data'];
                if ($type == 1) {
                    $commission = $language['history_consume_coin'] . '：' . formatMoney($commission);
                } else if ($type == 2) {
                    $commission = $language['today_consume_coin'] . '：' . formatMoney($commission);
                } else if ($type == 3) {
                    $commission = $language['seven_day_consume_coin'] . '：' . formatMoney($commission);
                } else if ($type == 4) {
                    $commission = $language['month_consume_coin'] . '：' . formatMoney($commission);
                }
                jsonReturn(EXIT_SUCCESS, '', ['commission' => $commission]);
            }
        } else {
            $data['language'] = $language;
            $data['lang'] = $this->selectedLang;
            $this->render('game/commission', $data);
        }
    }

    public function consumeCoin()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $pool_tax_par = $this->input->post('pool_tax_par');
            $pool_tax_pospar = $this->input->post('pool_tax_pospar');
            $pool_tax_limitup = $this->input->post('pool_tax_limitup');
            $pool_tax_interval = $this->input->post('pool_tax_interval');

            if ($pool_tax_par == "" || $pool_tax_limitup == "" || $pool_tax_interval == "" || $pool_tax_pospar == '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if ($pool_tax_par < 0 || $pool_tax_par > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_01']);
                exit();
            }
            if ($pool_tax_pospar < 0 || $pool_tax_pospar > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_22']);
                exit();
            }
            if ($pool_tax_limitup < 1 || $pool_tax_limitup > 999999999999.99) {
                jsonReturn(EXIT_ERROR, $language['return_error_13']);
                exit();
            }
            if ($pool_tax_interval < 60 || $pool_tax_interval > 43200) {
                jsonReturn(EXIT_ERROR, $language['return_error_02']);
                exit();
            }

            $str = "pool_tax_par[@kv@]{$pool_tax_par}[@par@]pool_tax_pospar[@kv@]{$pool_tax_pospar}[@par@]pool_tax_limitup[@kv@]{$pool_tax_limitup}[@par@]pool_tax_interval[@kv@]{$pool_tax_interval}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏配置', "抽水设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏配置', "抽水设置失败");
            }
        } else {
            $result = $this->requestApi('/system/setting', 'GET', array());
            $data['data'] = $result['data'];
            $data['language'] = $language;
            $this->render('game/consume_coin', $data);
        }
    }

    public function packet()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $pool_rb_limitup = $this->input->post('pool_rb_limitup');
            $pool_rb_limitdown = $this->input->post('pool_rb_limitdown');
            $pool_rb_coinless = $this->input->post('pool_rb_coinless');
            $pool_rb_7daycoindiff = $this->input->post('pool_rb_7daycoindiff');
            $pool_rb_isopen = $this->input->post('pool_rb_isopen');
            if ($pool_rb_limitup == "" || $pool_rb_limitdown == "" || $pool_rb_coinless == "" || $pool_rb_7daycoindiff == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if ($pool_rb_limitup < 1 || $pool_rb_limitup > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_05']);
                exit();
            }
            if ($pool_rb_limitdown < 1 || $pool_rb_limitdown > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_06']);
                exit();
            }
            if ($pool_rb_limitup <= $pool_rb_limitdown) {
                jsonReturn(EXIT_ERROR, $language['return_error_24']);
                exit();
            }
            if ($pool_rb_coinless < 0 || $pool_rb_coinless > 5) {
                jsonReturn(EXIT_ERROR, $language['return_error_10']);
                exit();
            }
            if ($pool_rb_7daycoindiff < 5) {
                jsonReturn(EXIT_ERROR, $language['return_error_11']);
                exit();
            }

            $str = "pool_rb_limitup[@kv@]{$pool_rb_limitup}[@par@]pool_rb_limitdown[@kv@]{$pool_rb_limitdown}[@par@]pool_rb_coinless[@kv@]{$pool_rb_coinless}[@par@]pool_rb_7daycoindiff[@kv@]{$pool_rb_7daycoindiff}[@par@]pool_rb_isopen[@kv@]{$pool_rb_isopen}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏配置', "救济红包设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏配置', "救济红包设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('game/packet', $data);
    }

    public function packetStatus()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $pool_rb_limitup = $this->input->post('pool_rb_limitup');
            $pool_rb_limitdown = $this->input->post('pool_rb_limitdown');
            $pool_rb_coinless = $this->input->post('pool_rb_coinless');
            $pool_rb_7daycoindiff = $this->input->post('pool_rb_7daycoindiff');
            $pool_rb_isopen = $this->input->post('status');
            if ($pool_rb_limitup == "" || $pool_rb_limitdown == "" || $pool_rb_coinless == "" || $pool_rb_7daycoindiff == "" || $pool_rb_isopen == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if ($pool_rb_limitup < 1 || $pool_rb_limitup > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_05']);
                exit();
            }
            if ($pool_rb_limitdown < 1 || $pool_rb_limitdown > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_06']);
                exit();
            }
            if ($pool_rb_coinless < 0 || $pool_rb_coinless > 5) {
                jsonReturn(EXIT_ERROR, $language['return_error_10']);
                exit();
            }
            if ($pool_rb_7daycoindiff < -999999.99 || $pool_rb_7daycoindiff > 999999.99) {
                jsonReturn(EXIT_ERROR, $language['return_error_11']);
                exit();
            }
            $pool_rb_isopen = $pool_rb_isopen ? 0 : 1;

            $str = "pool_rb_limitup[@kv@]{$pool_rb_limitup}[@par@]pool_rb_limitdown[@kv@]{$pool_rb_limitdown}[@par@]pool_rb_coinless[@kv@]{$pool_rb_coinless}[@par@]pool_rb_7daycoindiff[@kv@]{$pool_rb_7daycoindiff}[@par@]pool_rb_isopen[@kv@]{$pool_rb_isopen}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏配置', "救济红包状态设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏配置', "救济红包状态设置失败");
            }
        }
    }

    public function jackpot()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $pool_jp_outline = $this->input->post('pool_jp_outline');
            $pool_jp_outlimup = $this->input->post('pool_jp_outlimup');
            $pool_jp_outlimdown = $this->input->post('pool_jp_outlimdown');
            $pool_jp_par = $this->input->post('pool_jp_par');
            $pool_jp_disbaseline = $this->input->post('pool_jp_disbaseline');
            $pool_jp_diswave = $this->input->post('pool_jp_diswave');
            $pool_jp_disinterval = $this->input->post('pool_jp_disinterval');
            $pool_jp_disdownpar = $this->input->post('pool_jp_disdownpar');

            if ($pool_jp_outline == "" || $pool_jp_outlimup == "" || $pool_jp_outlimdown == "" || $pool_jp_disbaseline == "" || $pool_jp_diswave == "" || $pool_jp_disinterval == "" || $pool_jp_disdownpar == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if ($pool_jp_outline < 10000 || $pool_jp_outline > 999999999999.99) {
                jsonReturn(EXIT_ERROR, $language['return_error_14']);
                exit();
            }
            if ($pool_jp_outlimup < 1 || $pool_jp_outlimup > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_03']);
                exit();
            }
            if ($pool_jp_outlimdown < 1 || $pool_jp_outlimdown > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_04']);
                exit();
            }
            if ($pool_jp_par < 0 || $pool_jp_par > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_16']);
                exit();
            }
            if ($pool_jp_disbaseline < 1000 || $pool_jp_disbaseline > 999999999999.99) {
                jsonReturn(EXIT_ERROR, $language['return_error_17']);
                exit();
            }
            if ($pool_jp_diswave < -100 || $pool_jp_diswave > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_18']);
                exit();
            }
            if ($pool_jp_disinterval < 3 || $pool_jp_disinterval > 1440) {
                jsonReturn(EXIT_ERROR, $language['return_error_19']);
                exit();
            }
            if ($pool_jp_disdownpar < 1 || $pool_jp_disdownpar > 65) {
                jsonReturn(EXIT_ERROR, $language['return_error_20']);
                exit();
            }

            $str = "pool_jp_outline[@kv@]{$pool_jp_outline}[@par@]pool_jp_outlimup[@kv@]{$pool_jp_outlimup}[@par@]pool_jp_outlimdown[@kv@]{$pool_jp_outlimdown}[@par@]pool_jp_par[@kv@]{$pool_jp_par}[@par@]pool_jp_disbaseline[@kv@]{$pool_jp_disbaseline}[@par@]pool_jp_diswave[@kv@]{$pool_jp_diswave}[@par@]pool_jp_disinterval[@kv@]{$pool_jp_disinterval}[@par@]pool_jp_disdownpar[@kv@]{$pool_jp_disdownpar}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏配置', "大奖池（Jackpot）设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏配置', "大奖池（Jackpot）设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('game/jackpot', $data);
    }

    public function vip()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $player_vipbaseline = $this->input->post('player_vipbaseline');
            if ($player_vipbaseline == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }

            if ($player_vipbaseline < 100 || $player_vipbaseline > 999999999.99) {
                jsonReturn(EXIT_ERROR, $language['return_error_21']);
                exit();
            }

            $str = "player_vipbaseline[@kv@]{$player_vipbaseline}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏配置', "VIP玩家设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏配置', "VIP玩家设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('game/vip', $data);
    }

    // 客户端公告
    public function clientNotice()
    {
        $language = $this->lang->language;
        $data['language'] = $language;

        if ($this->is_ajax()) {
            $id = $this->input->post('id');
            $content = $this->input->post('content');
            if (mb_strlen(strip_tags($content), 'utf-8') >= 100) {
                jsonReturn(EXIT_ERROR, $language['client_notice_error']);
                exit();
            }
            if ($id) {
                $result = $this->requestApi('/system/notice_client', 'PUT', array('id' => $id, 'content' => $content));
            } else {
                $result = $this->requestApi('/system/notice_client', 'POST', array('content' => $content));
            }
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('客户端公告', "客户端公告设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('客户端公告', "客户端公告设置失败");
            }
        }

        // 获取公告详情
        $result = $this->requestApi('/system/notice_client', 'GET', array());
        $data['info'] = $result['data'];

        $this->render('game/client_notice', $data);
    }

    public function marquee()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $status = $this->input->get('status');
            $status = $status ? $status : 'all';

            $params = array(
                'page' => $page,
                'status' => $status
            );
            $result = $this->requestApi('/system/marquees', 'GET', $params, true);
            $lists = array();
            $time = time();
            foreach ($result['data']['list'] as $row) {
                $tmp['id'] = $row['id'];
                $tmp['open_time'] = date('Y-m-d H:i:s', $row['start_time']);
                $tmp['content'] = $row['content'];
                $tmp['add_time'] = date('Y-m-d H:i:s', $row['create_time']);
                if ($row['status'] == 1) {
                    $times = ceil(($row['revoke_time'] - $row['start_time']) / ($row['interval'] * 60));
                    $status = $language['marquee_status_30'] . '<br>' . $times . '/' . $row['counts'];
                } else {
                    if ($row['start_time'] > $time) {
                        $status = $language['marquee_status_00'];
                    } else if ($row['start_time'] + (($row['counts'] - 1) * $row['interval'] * 60) < $time) {
                        $status = $language['marquee_status_20'] . '<br>' . $row['counts'] . '/' . $row['counts'];
                    } else {
                        $times = ceil(($time - $row['start_time']) / ($row['interval'] * 60));
                        $status = $language['marquee_status_10'] . '<br>' . ($times) . '/' . $row['counts'];
                    }
                }

                $tmp['status'] = $status;
                if ($row['counts'] == 1) {
                    $tmp['hz'] = 1 . $language['times'];
                } else {
                    $tmp['hz'] = $row['counts'] . $language['times'] . '<br>' . $row['interval'] . $language['minute'] . '/' . $language['times'];
                }
                $lists[] = $tmp;
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('game/marquee', $data);
    }

    public function addMarquee()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $start_time = $this->input->post('start_time');
            $counts = $this->input->post('counts');
            $interval = $this->input->post('interval');
            $content = $this->input->post('content');
            $contenten = $this->input->post('contenten');

            if ($start_time == "" || $counts == "" || $interval == "" || $content == "" || $contenten == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if ($counts < 0 || $counts > 99) {
                jsonReturn(EXIT_ERROR, $language['return_error_07']);
                exit();
            }
            if ($interval < 1 || $interval > 60) {
                jsonReturn(EXIT_ERROR, $language['return_error_08']);
                exit();
            }
            if (mb_strlen($content, 'utf8') <= 0 || mb_strlen($content, 'utf8') > 200) {
                jsonReturn(EXIT_ERROR, $language['return_error_09']);
                exit();
            }
            if (mb_strlen($contenten, 'utf8') <= 0 || mb_strlen($contenten, 'utf8') > 200) {
                jsonReturn(EXIT_ERROR, $language['return_error_09']);
                exit();
            }
            if (strtotime($start_time) <= time()) {
                jsonReturn(EXIT_ERROR, $language['error_msg_marquee_add']);
                exit();
            }
            $params = array(
                'start_time' => strtotime($start_time),
                'counts' => $counts,
                'interval' => $interval,
                'content' => $content,
                'contenten' => $contenten,
            );
            $result = $this->requestApi('/system/marquee', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('跑马灯配置', "添加跑马灯成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('跑马灯配置', "添加跑马灯失败");
            }
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;

        $this->render('game/add_marquee', $data);
    }

    public function marqueeDetail()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $id = $this->input->post('id');
            $params = array(
                'id' => $id
            );
            $result = $this->requestApi('/system/marquee', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('跑马灯配置', "撤销跑马灯（%s）成功", [$id]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('跑马灯配置', "撤销跑马灯（%s）失败", [$id]);
            }
        } else {
            $id = $this->input->get('id');

            $params = array(
                'id' => $id
            );
            $result = $this->requestApi('/system/marquee', 'GET', $params);
            $data = $result['data'];
            $time = time();
            if ($data['status'] == 1) {
                $data['status'] = '30'; // 已撤回
            } else {
                if ($data['start_time'] > $time) {
                    $data['status'] = '00'; // 等待中
                } else if ($data['start_time'] + (($data['counts'] - 1) * $data['interval'] * 60) < $time) {
                    $data['status'] = '20'; // 已完成
                } else {
                    $data['status'] = '10'; // 生效中
                }
            }
            $data['data'] = $data;

            $data['language'] = $language;
            $this->render('game/marquee_detail', $data);
        }
    }

    public function bigbang()
    {
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01'),
            'pre_week_start' => date("Y-m-d",strtotime("-2 week Sunday")),
            'pre_week_end' => date("Y-m-d",strtotime("-1 week Saturday")),
        );

        $result = $this->requestApi('/stat/bigbang', 'GET', array());
        $data['acc'] = $result['data'];
        $language = $this->lang->language;
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('game/bigbang', $data);
    }

    public function bigbangRecordLists()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $account = $this->input->get('keywords');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');

            $params = array(
                'page' => $page,
                'account' => str_replace('-', '', $account),
                'times' => strtotime($startTime) . '.' . (strtotime($endTime) + 86400)
            );

            $result = $this->requestApi('/system/bigbangs', 'GET', $params, true);
            $lists = $result['data']['list'];
            $count = $result['data']['total'];
            foreach ($lists as &$one) {
                $one['createtime'] = date('Y-m-d H:i:s', $one['create_time']);
                if ($one['status'] == 0) {
                    $one['state'] = $language['bigbang_award_status_waitting'];
                } else if ($one['status'] == 1) {
                    $one['state'] = $language['bigbang_award_status_success'];
                } else if ($one['status'] == -1) {
                    $one['state'] = $language['bigbang_award_status_fail'];
                } else if ($one['status'] == -2) {
                    $one['state'] = 'game server error';
                }
                $one['coins'] = formatMoney($one['coin']);
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }
    }

    public function bigbangSetting()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $bb_disbaseline = $this->input->post('bb_disbaseline');
            $bb_wave_val = $this->input->post('bb_wave_val');
            $bb_valdown_time = $this->input->post('bb_valdown_time');
            $bb_valdown_parl = $this->input->post('bb_valdown_parl');

            if ($bb_disbaseline == "" || $bb_wave_val == "" || $bb_valdown_time == "" || $bb_valdown_parl == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }

            if ($bb_wave_val < -100 && $bb_wave_val > 100) {
                jsonReturn(EXIT_ERROR, $language['return_error_18']);
                exit();
            }

            $str = "bb_disbaseline[@kv@]{$bb_disbaseline}[@par@]bb_wave_val[@kv@]{$bb_wave_val}[@par@]bb_valdown_time[@kv@]{$bb_valdown_time}[@par@]bb_valdown_parl[@kv@]{$bb_valdown_parl}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('Bigbang', "Bigbang Jackpot设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('Bigbang', "Bigbang Jackpot设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('game/bigbang_setting', $data);
    }

    // 系统公告
    public function systemNotice()
    {
        $language = $this->lang->language;
        $data['language'] = $language;

        if ($this->is_ajax()) {
            $id = $this->input->post('id');
            $content = $this->input->post('content');
            if ($id) {
                $result = $this->requestApi('/account/notice_system', 'PUT', array('id' => $id, 'content' => $content));
            } else {
                $result = $this->requestApi('/account/notice_system', 'POST', array('content' => $content));
            }
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('系统公告', "添加系统公告成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('系统公告', "添加系统公告失败");
            }
        }

        // 获取公告详情
        $result = $this->requestApi('/account/notice_system', 'GET', array());
        $data['info'] = $result['data'];
        $this->render('game/system_notice', $data);
    }

    public function addBigbang()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $username = $this->input->post('username');
            $coin = $this->input->post('coin');
            $flag = $this->input->post('flag');
            if (empty($username) || empty($coin) || empty($flag) || $flag != 1) {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if ($coin < 10 || $coin > 10000) {
                jsonReturn(EXIT_ERROR, $language['return_error_23']);
                exit();
            }
            $params = array(
                'account' => str_replace('-', '', $username),
                'coin' => $coin
            );
            $result = $this->requestApi('/system/bigbang', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('Bigbang', "添加Bigbang成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('Bigbang', "添加Bigbang失败");
            }
        }

        $data['language'] = $language;
        $this->render('game/bigbang_add', $data);
    }

    public function jpHistory()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $account = $this->input->get('keywords');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');

            $params = array(
                'page' => $page,
                'account' => $account,
                'times' => strtotime($startTime) . '.' . (strtotime($endTime) + 86400)
            );

            $result = $this->requestApi('/system/jackpots', 'GET', $params, true);
            $lists = $result['data']['list'];
            $count = $result['data']['total'];
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01'),
            'pre_week_start' => date("Y-m-d",strtotime("-2 week Sunday")),
            'pre_week_end' => date("Y-m-d",strtotime("-1 week Saturday")),
        );

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('game/jp_history', $data);
    }

    public function rbHistory()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $account = $this->input->get('keywords');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');

            $params = array(
                'page' => $page,
                'account' => $account,
                'times' => strtotime($startTime) . '.' . (strtotime($endTime) + 86400)
            );

            $result = $this->requestApi('/system/redbags', 'GET', $params, true);
            $lists = $result['data']['list'];
            $count = $result['data']['total'];
            foreach ($lists as &$one) {
                $one['createtime'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01'),
            'pre_week_start' => date("Y-m-d",strtotime("-2 week Sunday")),
            'pre_week_end' => date("Y-m-d",strtotime("-1 week Saturday")),
        );

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('game/rb_history', $data);
    }

    public function prob()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $id = $this->input->post('id');
            $prob = $this->input->post('prob');
            $type = $this->input->post('type');
            if ($id == '' || $prob == '{}' || empty($prob) || $prob == '[]' || $type == '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $params = array(
                'id' => $id,
                'type' => $type,
                'prob' => $prob
            );
            $result = $this->requestApi('/system/prob', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏概率', "设定（%s）概率成功", [$id]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏概率', "设定（%s）概率失败", [$id]);
            }
        } else {
            $this->lang->load('prob_lang');

            $data['prob'] = array(
                1 => $this->lang->language['prob_1'],
                2 => $this->lang->language['prob_2'],
                3 => $this->lang->language['prob_3'],
                4 => $this->lang->language['prob_4'],
                5 => $this->lang->language['prob_5']
            );
            $data['language'] = $language;
            $this->render('game/prob', $data);
        }
    }

    public function gameLists()
    {
        if ($this->is_ajax()) {
            $type = $this->input->post_get('type');
            $uniq = $this->input->post_get('uniq');
            $uniq != 1 && $uniq = 0;
            $gameLists = $this->getGameList($uniq);
            if ($type > 0) {
                $data['game_list'] = [];
                foreach ($gameLists as $row) {
                    if ($type == $row['type']) {
                        $data['game_list'][] = $row;
                    }
                }
            } else {
                $data['game_list'] = $gameLists;
            }
            
            jsonReturn(EXIT_SUCCESS, '', $data);
        }
    }

    public function getProb()
    {
        if ($this->is_ajax()) {
            $id = $this->input->post('id');
            $type = $this->input->post('type');
            $type = 1;
            $result = $this->requestApi('/system/prob', 'GET', array('id' => $id, 'type' => $type));
            $prob = isset($result['data']['prob']) ? $result['data']['prob'] : json_encode([]);
            jsonReturn(EXIT_SUCCESS, '', ['prob' => $prob]);
        }
    }

    public function switch()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $gameSwitch = $this->input->post('game_switch');
            $gameSwl = $this->input->post('game_swl');
            $gameSwlContent = $this->input->post('game_swl_content');
            $gameSwlContenten = $this->input->post('game_swl_contenten');
            if ($gameSwitch == '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $str = "game_switch[@kv@]{$gameSwitch}[@par@]game_swl[@kv@]{$gameSwl}[@par@]game_swl_content[@kv@]{$gameSwlContent}[@par@]game_swl_contenten[@kv@]{$gameSwlContenten}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($gameSwitch == 1) {
                    $this->record('游戏开关-游戏开关', "游戏开关打开成功");
                } else {
                    $this->record('游戏开关-游戏开关', "游戏开关关闭成功");
                }
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                if ($gameSwitch == 1) {
                    $this->record('游戏开关-游戏开关', "游戏开关打开失败");
                } else {
                    $this->record('游戏开关-游戏开关', "游戏开关关闭失败");
                }
            }
        } else {
            $data['language'] = $language;
            $result = $this->requestApi('/system/setting', 'GET', array());
            $data['data'] = $result['data'];

            $result = $this->requestApi('/stat/stat_online_player', 'GET', array());
            $nums = isset($result['data']['online']) ? $result['data']['online'] : 0;
            $data['all_nums'] = $nums;

            $this->render('game/switch', $data);
        }
    }

    // 小游戏开关
    public function gameStatus()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $gameId = $this->input->post('id');
            $status = $this->input->post('status');
            if ($gameId == '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $params = array(
                'id' => $gameId
            );
            $result = $this->requestApi('/system/game_status', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($status == 1) {
                    $this->record('游戏开关-小游戏开关', "（%s）关服成功", [$gameId]);
                } else {
                    $this->record('游戏开关-小游戏开关', "（%s）开服成功", [$gameId]);
                }
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                if ($status == 1) {
                    $this->record('游戏开关-小游戏开关', "（%s）关服失败", [$gameId]);
                } else {
                    $this->record('游戏开关-小游戏开关', "（%s）开服失败", [$gameId]);
                }
            }
        } else {
            $data['language'] = $language;
            $this->render('game/game_status', $data);
        }
    }

    public function serverList()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $result = $this->requestApi('/system/gameserverlist', 'GET', []);
            $serverList = isset($result['data']) ? $result['data'] : [];
            $data = [];
            $status = [
                0 => $language['server_list_status_start'],
                1 => $language['server_list_status_run'],
                2 => $language['server_list_status_full'],
                3 => $language['server_list_status_weihu'],
                4 => $language['server_list_status_stop']
            ];
            foreach ($serverList['servers'] as $type => $server) {
                foreach ($server as $row) {
                    $tmp = [];
                    $tmp['type'] = $type;
                    $tmp['name'] = $row['name'];
                    $tmp['status'] = $status[$row['status']];
                    $data[] = $tmp;
                }
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => count($data), 'data' => $data));
        }

        $data['language'] = $language;
        $this->render('game/server_list', $data);
    }

    public function closeServer()
    {
        die;
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $name = $this->input->post('name');
            $result = $this->requestApi('/system/gameserverlist', 'POST', ['servername' => $name]);
            if ($result['errcode'] == 0) {
                $this->record('游戏开关-服务器列表', "（%s）关服成功", [$name]);
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                $this->record('游戏开关-服务器列表', "（%s）关服失败", [$name]);
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function major()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $pool_zbc_disbaseline = $this->input->post('pool_zbc_disbaseline');
            $pool_zbc_disdownpar = $this->input->post('pool_zbc_disdownpar');
            $pool_zbc_disinterval = $this->input->post('pool_zbc_disinterval');
            $pool_zbc_diswave = $this->input->post('pool_zbc_diswave');

            if ($pool_zbc_disbaseline == "" || $pool_zbc_disdownpar == "" || $pool_zbc_disinterval == "" || $pool_zbc_diswave == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }

            $str = "pool_zbc_disbaseline[@kv@]{$pool_zbc_disbaseline}[@par@]pool_zbc_disdownpar[@kv@]{$pool_zbc_disdownpar}[@par@]pool_zbc_disinterval[@kv@]{$pool_zbc_disinterval}[@par@]pool_zbc_diswave[@kv@]{$pool_zbc_diswave}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏配置', "争霸彩设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏配置', "争霸彩设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('game/major', $data);
    }

    public function minor()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $pool_slc_disbaseline = $this->input->post('pool_slc_disbaseline');
            $pool_slc_disdownpar = $this->input->post('pool_slc_disdownpar');
            $pool_slc_disinterval = $this->input->post('pool_slc_disinterval');
            $pool_slc_diswave = $this->input->post('pool_slc_diswave');

            if ($pool_slc_disbaseline == "" || $pool_slc_disdownpar == "" || $pool_slc_disinterval == "" || $pool_slc_diswave == "") {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }

            $str = "pool_slc_disbaseline[@kv@]{$pool_slc_disbaseline}[@par@]pool_slc_disdownpar[@kv@]{$pool_slc_disdownpar}[@par@]pool_slc_disinterval[@kv@]{$pool_slc_disinterval}[@par@]pool_slc_diswave[@kv@]{$pool_slc_diswave}";
            $str = $this->encrypt_string->encode($str);
            $params = array(
                'pars' => $str
            );
            $result = $this->requestApi('/system/setting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏配置', "双龙彩设置成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏配置', "双龙彩设置失败");
            }
        }

        $result = $this->requestApi('/system/setting', 'GET', array());
        $data['data'] = $result['data'];
        $data['language'] = $language;

        $this->render('game/minor', $data);
    }

    public function gameTag()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $ids = $this->input->post('ids');
            $tag = $this->input->post('tag');
            if ($ids == '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if (is_array($ids)) {
                $ids = implode(',', $ids);
            }
            $params = array(
                'ids' => $ids,
                'tag' => $tag
            );
            $result = $this->requestApi('/system/game_tag', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏开关-小游戏标签', "小游戏标签修改成功");
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏开关-小游戏开关', "小游戏标签修改失败");
            }
        }
    }

    public function setGameLimit()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $gameId = $this->input->post('game_id');
            $username = $this->input->post('username');
            $chips = $this->input->post('chips');

            list($min, $max) = explode('-', $chips);
            $setting = json_encode(['chips' => [['min' => $min, 'max' => $max]]]);
            $params = [
                'game_id' => $gameId,
                'username' => $username,
                'setting' => $setting
            ];
            $result = $this->requestApi('/system/multgamesetting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('多人游戏设定', "多人游戏设定（%s）设定成功", [$username]);
            } elseif ($result['errcode'] == 4001) {
                jsonReturn(EXIT_ERROR, $language['username_not_exist']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('多人游戏设定', "多人游戏设定（%s）设定失败", [$username]);
            }
        } else {
            $data['language'] = $language;
            $this->render('game/set_game_limit', $data);
        }
    }

    public function openOrCloseGame()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $gameId = $this->input->post('game_id');
            $username = $this->input->post('username');
            $state = $this->input->post('state');

            $setting = json_encode(['state' => $state]);
            $params = [
                'game_id' => $gameId,
                'username' => $username,
                'setting' => $setting
            ];
            $result = $this->requestApi('/system/multgamesetting', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($state == 1) {
                    $this->record('开启或关闭游戏', "开启游戏（%s）成功", [$username]);
                } else {
                    $this->record('开启或关闭游戏', "关闭游戏（%s）成功", [$username]);
                }
                
            } elseif ($result['errcode'] == 4001) {
                jsonReturn(EXIT_ERROR, $language['username_not_exist']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                if ($state == 1) {
                    $this->record('开启或关闭游戏', "开启游戏（%s）失败", [$username]);
                } else {
                    $this->record('开启或关闭游戏', "关闭游戏（%s）失败", [$username]);
                }
            }
        } else {
            $data['language'] = $language;
            $this->render('game/open_or_close_game', $data);
        }
    }

    public function getMultGame()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $gameId = $this->input->post('game_id');
            $result = $this->requestApi('/system/multgame', 'GET');
            $list = $result['data'];
            $gameLists = $this->getGameList(1);
            foreach ($list as &$one) {
                $one['title'] = isset($gameLists[$one['gameid']]) ? $gameLists[$one['gameid']]['name'] : $one['title'];
            }
            if ($gameId > 0) {
                $list = array_column($list, null, 'gameid');
                $list['chips'] = isset($list[$gameId]['chips']) ? json_decode($list[$gameId]['chips']) : [];
                $list['state'] = isset($list[$gameId]['state']) ? $list[$gameId]['state'] : 1;
            }

            jsonReturn(EXIT_SUCCESS, '', ['list' => $list]);
        }
    }

    public function getMultGameSetting()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $gameId = $this->input->post('game_id');
            $username = $this->input->post('username');
            $result = $this->requestApi('/system/multgamesetting', 'GET', ['game_id' => $gameId, 'username' => $username]);
            
            if (isset($result['data']) && $result['data']) {
                $rs = [];
                $rs['chips'] = isset($result['data']['chips']) ? $result['data']['chips'] : [];
                $rs['state'] = isset($result['data']['state']) ? $result['data']['state'] : '';
                jsonReturn(EXIT_SUCCESS, '', $rs);
            } elseif ($result['errcode'] == 4001) {
                jsonReturn(EXIT_ERROR, $language['username_not_exist']);
            } else {
                jsonReturn(EXIT_ERROR, $language['multi_game_setting_tips_01']);
            }
        }
    }

    //游戏排序
    public function gameSort()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $gameId = $this->input->post('id');
            $type = $this->input->post('type');
            $ord = $this->input->post('ord');
            if ($gameId == '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $params = array(
                'id' => $gameId,
                'type' => $type,
                'ord' => $ord
            );
            $result = $this->requestApi('/system/game_sort', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('游戏排序', "（%s）排序成功", [$gameId]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('游戏排序', "（%s）排序失败", [$gameId]);
            }
        } else {
            $data['game_type'] = [
                ['type' => 1, 'name' => $language['game_type_1']],
                ['type' => 2, 'name' => $language['game_type_2']],
                ['type' => 3, 'name' => $language['game_type_3']],
                ['type' => 4, 'name' => $language['game_type_4']],
                ['type' => 5, 'name' => $language['game_type_5']],
                ['type' => 6, 'name' => $language['game_type_6']]
            ];
            $data['language'] = $language;
            $this->render('game/game_sort', $data);
        }
    }

    //老虎机游戏等级数据设置
    public function gameLevel()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $gameId = $this->input->post('id');
            $level = $this->input->post('level');
            if ($gameId == '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }

            if(intval($level) >= 0) {
                $this->load->model('Game_model', 'gamemodel');
                $result = $this->gamemodel->updateGameLevel($gameId, $level);
                if($result) {
                    $params = array(
                        'id' => $gameId,
                        'level' => $level
                    );
                    $result = $this->requestApi('/system/game_level', 'PUT', $params);
                    if ($result['errcode'] == 0) {
                        jsonReturn(EXIT_SUCCESS, $language['return_success']);
                        $this->record('游戏等级', "（%s）等级成功", [$gameId]);
                    } 
                }
            } 
            
            jsonReturn(EXIT_ERROR, $language['return_fail']);
            $this->record('游戏等级', "（%s）等级失败", [$gameId]);
        } else {
            $data['language'] = $language;
            $this->render('game/game_level', $data);
        }
    }

    /**
    * 老虎机等级列表数据拉取
    */
    public function gameLevelList()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {

            $this->load->model('Game_model', 'gamemodel');
            $results = $this->gamemodel->getGameLevelList();

            $count = count($results);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $results));
        } 
    }

    /**
     * 游戏统计
     */
    public function gameStat()
    {
        $language = $this->lang->language;
        $chart = $this->input->get('chart');

        if ($this->is_ajax()) {
            if ($chart == 1) {
                $language = $this->lang->language;
                $type = $this->input->post('type');
                $column = $this->input->post('column');
                $startTime = $this->input->post('start_time');
                $endTime = $this->input->post('end_time');
                $interval = $this->input->post('interval');
                $gameLists = $this->getGameList(1);
                $games = [];
                if ($type > 0) {
                    foreach ($gameLists as $row) {
                        if (in_array($type, explode(',', $row['type']))) {
                            $games[] = $row;
                        }
                    }
                } else {
                    $games = array_values($gameLists);
                }
                if (empty($games)) {
                    jsonReturn(EXIT_SUCCESS, $language['return_success'], []);
                    exit();
                }
                $data['data'] = [];
                $data['time'] = [];
                $data['title'] = array_column($games, 'name');
                $params = array(
                    'time_min_start' => strtotime($startTime),
                    'time_min_end' => strtotime($endTime),
                    'min' => $interval,
                );
                $result = $this->requestApi('/stat/game_stat3', 'GET', $params);
                if (isset($result['data']['list'])) {
                    foreach ($result['data']['list'] as $row) {
                        $data['time'][] = date('m-d H:i', $row['time']);
                        foreach ($games as $key => $game) {
                            $data['data'][$key][] = isset($row['data'][$game['id']]) ? $row['data'][$game['id']][$column] : 0;
                        }
                    }
                }
                jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
                exit();
            } else {
                $startTime = $this->input->post('start_time');
                $endTime = $this->input->post('end_time');
                $type = $this->input->post('type');
                $field = $this->input->post('field');
                $field = $field ? $field : 'num_betofplayer';
                $order = $this->input->post('order');
                $order = $order ? $order : 'desc';
                $gameLists = $this->getGameList(1);
                $params = array(
                    'time_min_start' => strtotime($startTime),
                    'time_min_end' => strtotime($endTime),
                    'field' => $field,
                    'order' => $order
                );
                $result = $this->requestApi('/stat/game_stat2', 'GET', $params);
                if (!isset($result['data']['list'])) {
                    jsonListReturn(array('code' => 0, 'msg' => '', 'count' => 0, 'data' => []));
                }
                $lists = $result['data']['list'];
                if ($type > 0) {
                    $gameList = $this->getGameList(0);
                    foreach ($gameList as $key => $row) {
                        if ($type != $row['type']) {
                            unset($gameList[$key]);
                        }
                    }
                } else {
                    $gameList = $this->getGameList(1);
                }
                $gameList = array_column($gameList, null, 'id');
                foreach ($lists as $key => $value) {
                    if (isset($gameList[$key])) {
                        $lists[$key]['game_id'] = $key;
                        $lists[$key]['game_name'] = $gameList[$key]['name'];
                        $lists[$key]['amount_bet'] = formatMoney($value['amount_bet']);
                        $lists[$key]['amount_payout'] = formatMoney($value['amount_payout']);
                        $lists[$key]['amount_betfull'] = formatMoney($value['amount_betfull']);
                        $lists[$key]['amount_betfullpayout'] = formatMoney($value['amount_betfullpayout']);
                    } else {
                        unset($lists[$key]);
                    }
                }
                $count = count($lists);
                jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => array_values($lists)));
            }
        } else {
            $data['game_type'] = [
                ['type' => '', 'name' => $language['game_type_0']],
                ['type' => 1, 'name' => $language['game_type_1']],
                ['type' => 2, 'name' => $language['game_type_2']],
                // ['type' => 3, 'name' => $language['game_type_3']],
                ['type' => 4, 'name' => $language['game_type_4']],
                ['type' => 5, 'name' => $language['game_type_5']],
                ['type' => 6, 'name' => $language['game_type_6']]
            ];
            $data['lang'] = $this->selectedLang;
            $data['language'] = $language;
            if ($chart == 1) {
                $data['game_type'] = [
                    ['type' => 1, 'name' => $language['game_type_1']],
                    ['type' => 2, 'name' => $language['game_type_2']],
                    // ['type' => 3, 'name' => $language['game_type_3']],
                    ['type' => 4, 'name' => $language['game_type_4']],
                    ['type' => 5, 'name' => $language['game_type_5']],
                    ['type' => 6, 'name' => $language['game_type_6']]
                ];
                $data['time'] = [
                    '30' => $language['game_stat_30_minute'],
                    '60' => $language['game_stat_1_hour'],
                    '1440' => $language['game_stat_1_day'],
                ];
                $this->render('game/game_stat_chart', $data);
            } else {
                $this->render('game/game_stat', $data);
            }
        }
    }

    /**
     * 编辑游戏详情
     */
    public function game_detail(){
        $data = [] ;
        $type = 1;
        $uniq = 1;
        $uniq != 1 && $uniq = 0;
        $gameid = $this->input->get('id');
        $language = $this->lang->language;
        if($this->is_ajax()){
            $db = $this->db;
            $gametype = $this->input->post('type');
            $level = $this->input->post('level');
            $tag = $this->input->post('tagHot');
            $ord = $this->input->post('ord');
            $db->where('gameid',$gameid);
            $update_data = [
                'gametype' => $gametype,
                'level' => $level,
            ];
            // 更新游戏等级
            $res = $db->update('s_game_type',$update_data);
            // 更新标签 以及状态
            if (!$res){
                return jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
            $tagParams = array(
                'ids' => $gameid,
                'tag' => $tag
            );
            $result = $this->requestApi('/system/game_tag', 'POST', $tagParams);
            if ($result['errcode'] != 0) {
                $this->record('游戏开关-小游戏开关', "小游戏标签修改失败");
                return jsonReturn(EXIT_ERROR, '游戏开关-小游戏开关,小游戏标签修改失败');
            }

            $status_params = [
                'id' => $gameid,
            ];
            $result = $this->requestApi('/system/game_status', 'PUT', $status_params);
            if ($result['errcode'] != 0) {
                $this->record('游戏开关-小游戏开关', "（%s）关服失败", [$gameid]);
                return jsonReturn(EXIT_ERROR, "{$gameid}关服失败");
            }

            $params = array(
                'id' => $gameid,
                'type' => $type,
                'ord' => $ord
            );
            $result = $this->requestApi('/system/game_sort', 'PUT', $params);
            if ($result['errcode'] != 0) {
                $this->record('游戏排序', "（%s）排序失败", [$gameid]);
                return jsonReturn(EXIT_ERROR, "游戏排序修改（{$gameid}）排序失败");
            }
            if ($result){
                return jsonReturn(EXIT_SUCCESS, $language['return_success']);
            }else{
                return jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
        $gameLists = $this->getGameList($uniq);
        if ($type > 0) {
            $data['game_list'] = [];
            foreach ($gameLists as $row) {
                if ($type == $row['type']) {
                    $data['game_list'][] = $row;
                }
            }
        } else {
            $data['game_list'] = $gameLists;
        }
        $result = [];
        foreach ($gameLists as $key => $val){
            if ($val['id'] == $gameid){
                $sql = "select * from s_game_type where gameid = {$gameid}";
                $res = $this->db->query($sql)->result_array();
                if (isset($res[0])){
                    $val['level'] = $res[0]['level'];
                }else{
                    $val['level'] = 0;
                }
                if (isset($res[0])){
                    $val['game_type'] = $res[0]['gametype'];
                }else{
                    $val['game_type'] = 0;
                }
                $result = $val;
            }
        }
        $data['result'] = $result;
        $data['language'] = $this->lang->language;
        $data['id'] = $gameid;
        $this->render('game/game_detail', $data);
    }
}