<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 订单管理
 * Class Order
 * 支付订单列表
 * 订单分布统计
 * 充值排行榜Top 100 (累计充值)
 */

class Order extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('order_lang');
    }

    //订单列表
    public function index()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $sdate = $this->input->get('stime', date('Y-m-d'));
            $edate = $this->input->get('etime', date('Y-m-d'));
            $stime = strtotime($sdate);
            $etime = strtotime($edate);
            if($etime == $stime) {
                $etime = $stime + 86400;
            }
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'id';
            $order = $this->input->get('order');
            $order = $order ? $order : 'ASC';

            $params = array(
                'keywords' => $keywords,
                'page' => $page,
                'order_by' => $field . ' ' . $order,
                'stime' => $stime,
                'etime' => $etime,
            );
            $result = $this->requestApi('/order/orders', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                    $one['pay_time'] = date('Y-m-d H:i:s', $one['pay_time']);
                    $one['notify_time'] = date('Y-m-d H:i:s', $one['notify_time']);
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['username'] = "";
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-1 weeks')),
            'month' => date('Y-m-01')
        );
        $this->render('order/index', $data);
    }

    // 订单分布 饼图
    public function distribution()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $sdate = $this->input->post('sdate', date('Y-m-d'));
            $edate = $this->input->post('edate', date('Y-m-d'));

            $stime = strtotime($sdate);
            $etime = strtotime($edate);
            if($etime <= $stime) {
                $etime = $stime + 86400;
            }
            $params = array(
                'status' => 100,
                'pay_channel' => 100, //不限支付渠道
                'user_channel' => 100, //不限用户渠道
                'start_time' => $stime,
                'end_time' => $etime,
            );
            $result = $this->requestApi('/order/pie', 'GET', $params, true);
            $lists = array();
            $count = 0;
            if ($result) {
                // foreach ($result['data']['list'] as $row) {
                //     // $tmp = array();
                //     // $tmp['account_id'] = $row['account_id'];
                //     // $tmp['account_pid'] = formatPlayerUsername($row['account_pid']);
                //     // $tmp['account_nickname'] = $row['account_nickname'];
                //     // $tmp['account_coin'] = formatMoney($row['account_coin']);
                //     // $tmp['account_bandepth'] = intval($row['account_banby_id']);
                //     // $tmp['account_banby_id'] = intval($row['account_banby_id']);
                //     // $tmp['account_online'] = isset($row['account_online']) ? $row['account_online'] : 0;
                //     // $tmp['account_login_time'] = $row['account_login_time'] ? date('Y-m-d H:i:s', $row['account_login_time']) : 0;
                //     // $tmp['account_vip'] = $row['account_vip'];
                //     // $tmp['account_phone'] = $row['account_phone'];
                //     // $tmp['account_remark'] = $row['account_remark'];
                //     // $tmp['red_envelope_flag'] = isset($row['red_envelope']) && $row['red_envelope'] > 0 ? 1 : 0;
                //     // $tmp['red_envelope'] = formatMoney(isset($row['red_envelope']) ? $row['red_envelope'] : 0);
                //     // $lists[] = $tmp;
                //     $lists[] = $row;
                // }
                $count = $result['data']['total'];
            }

            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $result['data']['list']));
        }
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-1 weeks')),
            'month' => date('Y-m-01')
        );
        $this->render('order/distribution', $data);
    }
}
