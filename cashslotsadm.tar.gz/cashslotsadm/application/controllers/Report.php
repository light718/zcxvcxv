<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('report_lang');
    }

    public function game_data()
    {
        $language = $this->lang->language;
        $type = $this->input->get('type');
        $type = $type ? $type : 1;

        if ($this->is_ajax()) {
            $startTime = $endTime = 0;
            $endTime = time();
            if ($type == 1) {
                $startTime = $endTime - 3600;
            } else if ($type == 2) {
                $startTime = $endTime - 86400;
            } else if ($type == 3) {
                $startTime = $endTime - 86400*7;
            } else if ($type == 4) {
                $startTime = $endTime - 86400*30;
            }
            $params = [
                'time' => $startTime,
                'time2' => $endTime
            ];
            $result = $this->requestApi('/stat/stat_sysexclusive_bygameid', 'GET', $params);
            $lists = $result['data'];
            $gameLists = $this->getGameList(1);
            foreach ($lists as &$one) {
                $one['bet'] = formatMoney($one['bet']);
                $one['sys_win_coin'] = formatMoney($one['sys_win_coin']);
                $one['game_name'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['name'] : '';
                if(empty($one['game_name'])) {
                    $one['game_name'] = $this->getActGameName($one['game_id']);
                }
                if(empty($one['game_name']) || !$one['game_name']) {
                    $one['game_name'] = $one['game_id'];
                }
                $one['sys_win_ratio'] = formatMoney($one['sys_win_ratio'] * 100) . '%';
                $one['sys_win_coin_ratio'] = formatMoney($one['sys_win_coin_ratio'] * 100) . '%';
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['type'] = $type;
        $this->render('report/game_data', $data);
    }

    //当天输赢最大的50列表
    public function game_win_list()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            $startDate = date('Ymd', strtotime($startDate));

            $redis = $this->getRedisObj();

            $preKey = 'gameWinList_';
            $cacheKey = $preKey . $startDate;
            $lostList = $redis->zRangeByScore($cacheKey, '-inf', '+inf', array('withscores' => true, 'limit' => array(0, 50)));
            asort($lostList);
            $loseData = [];
            $i = 1;
            foreach($lostList as $k=>$v){
                $item = [
                    'id' => $i,
                    'uid'=>$k,
                    'wincoin' => $v,
                ];
                $loseData[] = $item;
                $i++;
            }
            $winList = $redis->zRevRangeByScore($cacheKey, '+inf', '-inf', array('withscores' => true, 'limit' => array(0, 50)));
            arsort($winList);
            $winData = [];
            $i = 1;
            foreach($winList as $k=>$v){
                $item = [
                    'id' => $i,
                    'uid'=>$k,
                    'wincoin' => $v,
                ];
                $winData[] = $item;
                $i++;
            }
            $lists = [
                'winlist' => $winData,
                'lostlist'=> $loseData
            ];
            $count = 1;
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('report/game_win_list', $data);
    }

    //当天slots游戏的回报率
    public function game_payrate_today()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $startDate = $this->input->get('start_time');
            // $endDate = $this->input->get('end_time');
            $startDate = date('Ymd', strtotime($startDate));
            // $endDate = date('Ymd', strtotime($endDate));
            $this->load->model('Gamepayrateday_model', 'payratedayModel');
            $lists = $this->payratedayModel->getListData($startDate);

            $gameList = $this->getGameList(1);
            foreach ($lists as $key => $value) {
                if (isset($gameList[$value['game_id']])) {
                    $lists[$key]['title'] = $gameList[$value['game_id']]['name'];
                } 
                $lists[$key]['payrate'] = $this->_getFloat($value['win'], $value['bet'], 1);
                $lists[$key]['day'] = date('Y-m-d', $value['day']);
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('report/game_payrate_today', $data);
    }

    //总的slots游戏回报率统计
    public function game_payrate()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            // $startDate = $this->input->get('start_time');
            // $endDate = $this->input->get('end_time');
            // $startDate = date('Ymd', strtotime($startDate));
            // $endDate = date('Ymd', strtotime($endDate));
            $this->load->model('Gamepayrate_model', 'payrateModel');
            $lists = $this->payrateModel->getListData();

            $gameList = $this->getGameList(1);
            foreach ($lists as $key => $value) {
                if (isset($gameList[$value['game_id']])) {
                    $lists[$key]['title'] = $gameList[$value['game_id']]['name'];
                } 
                $lists[$key]['payrate'] = $this->_getFloat($value['win'], $value['bet'], 1);
                $lists[$key]['create_time'] = date('Y-m-d H:i:s', $value['create_time']);
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $this->render('report/game_payrate', $data);
    }

    public function big_player()
    {
        $language = $this->lang->language;
        $type = $this->input->get('type');
        $type = $type ? $type : 1;

        if ($this->is_ajax()) {
            $startTime = $endTime = 0;
            $endTime = time();
            if ($type == 1) {
                $startTime = $endTime - 3600;
            } else if ($type == 2) {
                $startTime = $endTime - 86400;
            } else if ($type == 3) {
                $startTime = $endTime - 86400*7;
            } else if ($type == 4) {
                $startTime = $endTime - 86400*30;
            }
            $params = [
                'time' => $startTime,
                'time2' => $endTime
            ];
            $result = $this->requestApi('/stat/stat_sysexclusive_superplayer', 'GET', $params);
            $lists = $result['data'];
            foreach ($lists as &$one) {
                $one['pid'] = formatPlayerUsername($one['pid']);
                $one['login_time'] = date('Y-m-d H:i:s', $one['login_time']);
                $one['coin'] = formatMoney($one['coin']);
                $one['userbet'] = formatMoney($one['userbet']);
                $one['userwin'] = formatMoney($one['userwin']);
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['type'] = $type;
        $this->render('report/big_player', $data);
    }

    public function big_winner()
    {
        $language = $this->lang->language;
        $type = $this->input->get('type');
        $type = $type ? $type : 1;

        if ($this->is_ajax()) {
            $startTime = $endTime = 0;
            $endTime = time();
            if ($type == 1) {
                $startTime = $endTime - 3600;
            } else if ($type == 2) {
                $startTime = $endTime - 86400;
            } else if ($type == 3) {
                $startTime = $endTime - 86400*7;
            } else if ($type == 4) {
                $startTime = $endTime - 86400*30;
            }
            $params = [
                'time' => $startTime,
                'time2' => $endTime
            ];
            $result = $this->requestApi('/stat/stat_sysexclusive_superwiner', 'GET', $params);
            $lists = $result['data'];
            foreach ($lists as &$one) {
                $one['pid'] = formatPlayerUsername($one['pid']);
                $one['login_time'] = date('Y-m-d H:i:s', $one['login_time']);
                $one['coin'] = formatMoney($one['coin']);
                $one['userbet'] = formatMoney($one['userbet']);
                $one['userwin'] = formatMoney($one['userwin']);
            }
            $count = count($lists);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['type'] = $type;
        $this->render('report/big_winner', $data);
    }

    public function jackpot_status()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        $this->render('report/jackpot_status', $data);
    }

    public function poolnormal()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $now = time();
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = [$language['report_pool_normal']];
            $startTime = strtotime(date('Y-m-d H:i:00', strtotime('-1 day')));
            $endTime = $startTime + 86400;
            $params = array(
                'time' => $startTime,
                'time2' => $endTime
            );
            $result = $this->requestApi('/stat/stat_5min_pool_normal', 'GET', $params);
            if (isset($result['data'])) {
                foreach ($result['data'] as $row) {
                    $data['time'][] = date('m-d H:i', strtotime($row['datetime']));
                    $data['data'][0][] = $row['coin'];
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        }
    }

    public function jackpot()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $now = time();
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = [$language['report_pool_jackpot'], $language['report_pool_jackpot_baseline']];
            $startTime = strtotime(date('Y-m-d H:i:00', strtotime('-1 day')));
            $endTime = $startTime + 86400;
            $params = array(
                'time' => $startTime,
                'time2' => $endTime
            );
            $result = $this->requestApi('/stat/stat_5min_pool_jp', 'GET', $params);
            if (isset($result['data'])) {
                foreach ($result['data'] as $row) {
                    $data['time'][] = date('m-d H:i', strtotime($row['datetime']));
                    $data['data'][0][] = $row['coin'];
                    $data['data'][1][] = $row['outline'];
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        }
    }

    public function pooltax()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $now = time();
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = [$language['report_pool_tax'], $language['report_pool_tax_baseline']];
            $startTime = strtotime(date('Y-m-d H:i:00', strtotime('-1 day')));
            $endTime = $startTime + 86400;
            $params = array(
                'time' => $startTime,
                'time2' => $endTime
            );
            $result = $this->requestApi('/stat/stat_5min_pool_tax', 'GET', $params);
            if (isset($result['data'])) {
                foreach ($result['data'] as $row) {
                    $data['time'][] = date('m-d H:i', strtotime($row['datetime']));
                    $data['data'][0][] = $row['coin'];
                    $data['data'][1][] = $row['limitup'];
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        }
    }

    public function bet_nums()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $type = $this->input->post('type');
            $gameLists = $this->getGameList(1);
            $games = [];
            if ($type > 0) {
                foreach ($gameLists as $row) {
                    if (in_array($type, explode(',', $row['type']))) {
                        $games[] = $row;
                    }
                }
            } else {
                $games = $gameLists;
            }
            if (empty($games)) {
                jsonReturn(EXIT_SUCCESS, $language['return_success'], []);
                exit();
            }
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = array_column($games, 'name');
            $startTime = strtotime(date('Y-m-d H:i:00', strtotime('-1 day')));
            $endTime = $startTime + 86400;
            $params = array(
                'start_time' => $startTime,
                'end_time' => $endTime
            );
            $result = $this->requestApi('/report/bet_nums', 'GET', $params);
            if (isset($result['data']['list'])) {
                foreach ($result['data']['list'] as $row) {
                    $data['time'][] = date('m-d H:i', strtotime($row['minute']));
                    foreach ($games as $key => $game) {
                        $data['data'][$key][] = isset($row['data'][$game['id']]) ? $row['data'][$game['id']] : 0;
                    }
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
            exit();
        }

        $data['game_type'] = [
            ['type' => 1, 'name' => $language['game_type_1']],
            ['type' => 2, 'name' => $language['game_type_2']],
            ['type' => 4, 'name' => $language['game_type_4']],
            ['type' => 6, 'name' => $language['game_type_6']]
        ];

        $data['language'] = $language;
        $this->render('report/bet_nums', $data);
    }

    /**
     * 游戏服本地子库存变化 
     * 获取游戏对库存变化的列表
     */
    public function game_selfmainpool()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $language = $this->lang->language;
            // $gameId = $this->input->post('game_id');
            // $gameName = $this->input->post('game_name');
            $gameId = 0;
            $gameName = "";
            $data['data'] = [];
            $data['time'] = [];
            if ($gameId && $gameName) {
                $data['title'] = [$language['stocks'], $gameName];
            } else {
                $data['title'] = [$language['stocks']];
            }
            $gameIds[] = 0; // 总库存
            $gameId && $gameIds[] = $gameId;
            $endTime = strtotime(date('Y-m-d', strtotime('-1 day')));
            $startTime = $endTime - 86400*6;
            $params = array(
                'start_time' => $startTime,
                'end_time' => $endTime
            );
            $result = $this->requestApi('/report/mainpool', 'GET', $params);
            if (isset($result['data']['list'])) {
                foreach ($result['data']['list'] as $row) {
                    $data['time'][] = date('m-d', strtotime($row['dtime']));
                    foreach ($gameIds as $key => $game) {
                        $data['data'][$key][] = isset($row['data'][$game]) ? $row['data'][$game] : '0.00';
                    }
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
            exit();
        }

        // $gameList = $this->getGameList(1);
        $params['start_time'] = strtotime(date('Y-m-d'));
        $params['end_time'] = $params['start_time'] + 86399;
        $result = $this->requestApi('/report/all_selfsubmainpool', 'GET', $params);
        $data['game_list'] = $result['data'];

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('report/game_selfmainpool', $data);
    }

    /**
     * 库存变化 - 总库存
     * 获取游戏对库存变化的列表
     */
    public function game_mainpool()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $gameId = $this->input->post('game_id');
            $gameName = $this->input->post('game_name');
            $data['data'] = [];
            $data['time'] = [];
            if ($gameId && $gameName) {
                $data['title'] = [$language['stocks'], $gameName];
            } else {
                $data['title'] = [$language['stocks']];
            }
            $gameIds[] = 0; // 总库存
            $gameId && $gameIds[] = $gameId;
            $endTime = strtotime(date('Y-m-d', strtotime('-1 day')));
            $startTime = $endTime - 86400*6;
            $params = array(
                'start_time' => $startTime,
                'end_time' => $endTime
            );
            $result = $this->requestApi('/report/mainpool', 'GET', $params);
            if (isset($result['data']['list'])) {
                foreach ($result['data']['list'] as $row) {
                    $data['time'][] = date('m-d', strtotime($row['dtime']));
                    foreach ($gameIds as $key => $game) {
                        $data['data'][$key][] = isset($row['data'][$game]) ? $row['data'][$game] : '0.00';
                    }
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
            exit();
        }

        $gameList = $this->getGameList(1);
        $params['start_time'] = strtotime(date('Y-m-d'));
        $params['end_time'] = $params['start_time'] + 86399;
        $result = $this->requestApi('/report/today_mainpool', 'GET', $params);
        $todayData = $result['data'];
        $data['game_list'] = [];
        $totalCoin = 0;
        foreach ($gameList as $row) {
            $tmp = [];
            $tmp['name'] = $row['name'];
            $coin = isset($todayData[$row['id']]) ? $todayData[$row['id']] : 0;
            $totalCoin += $coin;
            if ($coin >= 0) {
                $tmp['color_css'] = 'stc_' . explode(',', $row['type'])[0];
            } else {
                $tmp['color_css'] = 'stc_6';
            }
            $tmp['coin'] = formatMoney($coin);
            $data['game_list'][] = $tmp;
        }
        $data['total_coin'] = $totalCoin;

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('report/game_mainpool', $data);
    }

    public function online()
    {
        $language = $this->lang->language;
        $type = $this->input->get('type');
        $type = $type ? $type : 1;

        $gameLists = $this->getGameList(1);
        $games = [];
        foreach ($gameLists as $row) {
            if ($type == $row['type']) {
                $games[] = $row;
            }
        }

        if ($this->is_ajax()) {
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = array_column($games, 'name');
            $endTime = time();
            $startTime = $endTime - 86400;
            $params = array(
                'time' => $startTime,
                'time2' => $endTime
            );
            $result = $this->requestApi('/stat/stat_5min_game_online_player', 'GET', $params);
            if (isset($result['data'])) {
                foreach ($result['data'] as $row) {
                    $gameData = json_decode($row['counts'], true);
                    $data['time'][] = date('m-d H:i', strtotime($row['datetime']));
                    foreach ($games as $key => $game) {
                        $data['data'][$key][] = isset($gameData[$game['id']]) ? $gameData[$game['id']] : '0.00';
                    }
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
            exit();
        }

        $data['game_type'] = [
            ['type' => 1, 'name' => $language['game_type_1']],
            ['type' => 2, 'name' => $language['game_type_2']],
            ['type' => 4, 'name' => $language['game_type_4']],
            ['type' => 6, 'name' => $language['game_type_6']]
        ];
        $data['language'] = $language;

        $result = $this->requestApi('/stat/stat_online_player', 'GET', array());
        $nums = isset($result['data']['online']) ? $result['data']['online'] : 0;
        $data['all_nums'] = $nums;

        $result = $this->requestApi('/stat/stat_game_online_player', 'GET', ['gameid' => -1]);
        $onlineGames = isset($result['data']) && $result['data'] ? array_column($result['data'], 'onlinenum', 'gameid') : [];
        foreach ($games as &$one) {
            $one['online_nums'] = isset($onlineGames[$one['id']]) ? $onlineGames[$one['id']] : 0;
        }
        $data['list'] = $games;
        $data['type'] = $type;
        $this->render('report/online', $data);
    }

    public function game_mainpool_by_day()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $date = $this->input->post('date');
            $date = $date ? $date : date('Y-m-d');
            $gameList = $this->getGameList(1);
            $params = [];
            if ($date) {
                $params['start_time'] = strtotime($date);
                $params['end_time'] = $params['start_time'] + 86399;
            }
            $result = $this->requestApi('/report/today_mainpool', 'GET', $params);
            $todayData = $result['data'];
            $data['game_list'] = [];
            $totalCoin = 0;
            foreach ($gameList as $row) {
                $tmp = [];
                $tmp['name'] = $row['name'];
                $coin = isset($todayData[$row['id']]) ? $todayData[$row['id']] : 0;
                $totalCoin += $coin;
                if ($coin >= 0) {
                    $tmp['color_css'] = 'stc_' . explode(',', $row['type'])[0];
                } else {
                    $tmp['color_css'] = 'stc_6';
                }
                $tmp['coin'] = formatMoney($coin);
                $data['game_list'][] = $tmp;
            }
            $data['total_coin'] = formatMoney($totalCoin);
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
            exit();
        }
    }

    private function getCountryName() {
        return [
            "Afghanistan"=> "阿富汗",
            "Angola"=> "安哥拉",
            "Albania"=> "阿尔巴尼亚",
            "Algeria"=> "阿尔及利亚",
            "Argentina"=> "阿根廷",
            "Armenia"=> "亚美尼亚",
            "Australia"=> "澳大利亚",
            "Austria"=> "奥地利",
            "Azerbaijan"=> "阿塞拜疆",
            "Bahamas"=> "巴哈马",
            "Bangladesh"=> "孟加拉国",
            "Belgium"=> "比利时",
            "Benin"=> "贝宁",
            "Burkina Faso"=> "布基纳法索",
            "Burundi"=> "布隆迪",
            "Bulgaria"=> "保加利亚",
            "Bosnia and Herz."=> "波斯尼亚和黑塞哥维那",
            "Belarus"=> "白俄罗斯",
            "Belize"=> "伯利兹",
            "Bermuda"=> "百慕大群岛",
            "Bolivia"=> "玻利维亚",
            "Brazil"=> "巴西",
            "Brunei"=> "文莱",
            "Bhutan"=> "不丹",
            "Botswana"=> "博茨瓦纳",
            "Cambodia"=> "柬埔寨",
            "Cameroon"=> "喀麦隆",
            "Canada"=> "加拿大",
            "Central African Rep."=> "中非共和国",
            "Chad"=> "乍得",
            "Chile"=> "智利",
            "China"=> "中国",
            "Colombia"=> "哥伦比亚",
            "Congo"=> "刚果",
            "Costa Rica"=> "哥斯达黎加",
            "Côte d'Ivoire"=> "科特迪瓦",
            "Croatia"=> "克罗地亚",
            "Cuba"=> "古巴",
            "Cyprus"=> "塞浦路斯",
            "Czech Rep."=> "捷克共和国",
            "Dem. Rep. Korea"=> "韩国",
            "Dem. Rep. Congo"=> "民主刚果",
            "Denmark"=> "丹麦",
            "Djibouti"=> "吉布提",
            "Dominican Rep."=> "多米尼加共和国",
            "Ecuador"=> "厄瓜多尔",
            "Egypt"=> "埃及",
            "El Salvador"=> "萨尔瓦多",
            "Eq. Guinea"=> "赤道几内亚",
            "Eritrea"=> "厄立特里亚",
            "Estonia"=> "爱沙尼亚",
            "Ethiopia"=> "埃塞俄比亚",
            "Falkland Is."=> "福克兰群岛",
            "Fiji"=> "斐济",
            "Finland"=> "芬兰",
            "France"=> "法国",
            "French Guiana"=> "法属圭亚那",
            "Fr. S. Antarctic Lands"=> "法属南部领地",
            "Gabon"=> "加蓬",
            "Gambia"=> "冈比亚",
            "Germany"=> "德国",
            "Georgia"=> "佐治亚州",
            "Ghana"=> "加纳",
            "Greece"=> "希腊",
            "Greenland"=> "格陵兰",
            "Guatemala"=> "危地马拉",
            "Guinea"=> "几内亚",
            "Guinea-Bissau"=> "几内亚比绍",
            "Guyana"=> "圭亚那",
            "Haiti"=> "海地",
            "Heard I. and McDonald Is."=> "赫德岛和麦克唐纳群岛",
            "Honduras"=> "洪都拉斯",
            "Hungary"=> "匈牙利",
            "Iceland"=> "冰岛",
            "India"=> "印度",
            "Indonesia"=> "印度尼西亚",
            "Iran"=> "伊朗",
            "Iraq"=> "伊拉克",
            "Ireland"=> "爱尔兰",
            "Israel"=> "以色列",
            "Italy"=> "意大利",
            "Ivory Coast"=> "象牙海岸",
            "Jamaica"=> "牙买加",
            "Japan"=> "日本",
            "Jordan"=> "乔丹",
            "Kashmir"=> "克什米尔",
            "Kazakhstan"=> "哈萨克斯坦",
            "Kenya"=> "肯尼亚",
            "Kosovo"=> "科索沃",
            "Kuwait"=> "科威特",
            "Kyrgyzstan"=> "吉尔吉斯斯坦",
            "Laos"=> "老挝",
            "Lao PDR"=> "老挝人民民主共和国",
            "Latvia"=> "拉脱维亚",
            "Lebanon"=> "黎巴嫩",
            "Lesotho"=> "莱索托",
            "Liberia"=> "利比里亚",
            "Libya"=> "利比亚",
            "Lithuania"=> "立陶宛",
            "Luxembourg"=> "卢森堡",
            "Madagascar"=> "马达加斯加",
            "Macedonia"=> "马其顿",
            "Malawi"=> "马拉维",
            "Malaysia"=> "马来西亚",
            "Mali"=> "马里",
            "Mauritania"=> "毛里塔尼亚",
            "Mexico"=> "墨西哥",
            "Moldova"=> "摩尔多瓦",
            "Mongolia"=> "蒙古",
            "Montenegro"=> "黑山",
            "Morocco"=> "摩洛哥",
            "Mozambique"=> "莫桑比克",
            "Myanmar"=> "缅甸",
            "Namibia"=> "纳米比亚",
            "Netherlands"=> "荷兰",
            "New Caledonia"=> "新喀里多尼亚",
            "New Zealand"=> "新西兰",
            "Nepal"=> "尼泊尔",
            "Nicaragua"=> "尼加拉瓜",
            "Niger"=> "尼日尔",
            "Nigeria"=> "尼日利亚",
            "Korea"=> "朝鲜",
            "Northern Cyprus"=> "北塞浦路斯",
            "Norway"=> "挪威",
            "Oman"=> "阿曼",
            "Pakistan"=> "巴基斯坦",
            "Panama"=> "巴拿马",
            "Papua New Guinea"=> "巴布亚新几内亚",
            "Paraguay"=> "巴拉圭",
            "Peru"=> "秘鲁",
            "Republic of the Congo"=> "刚果共和国",
            "Philippines"=> "菲律宾",
            "Poland"=> "波兰",
            "Portugal"=> "葡萄牙",
            "Puerto Rico"=> "波多黎各",
            "Qatar"=> "卡塔尔",
            "Republic of Seychelles"=> "塞舌尔共和国",
            "Romania"=> "罗马尼亚",
            "Russia"=> "俄罗斯",
            "Rwanda"=> "卢旺达",
            "Samoa"=> "萨摩亚",
            "Saudi Arabia"=> "沙特阿拉伯",
            "Senegal"=> "塞内加尔",
            "Serbia"=> "塞尔维亚",
            "Sierra Leone"=> "塞拉利昂",
            "Slovakia"=> "斯洛伐克",
            "Slovenia"=> "斯洛文尼亚",
            "Solomon Is."=> "所罗门群岛",
            "Somaliland"=> "索马里兰",
            "Somalia"=> "索马里",
            "South Africa"=> "南非",
            "S. Geo. and S. Sandw. Is."=> "南乔治亚和南桑德威奇群岛",
            "S. Sudan"=> "南苏丹",
            "Spain"=> "西班牙",
            "Sri Lanka"=> "斯里兰卡",
            "Sudan"=> "苏丹",
            "Suriname"=> "苏里南",
            "Swaziland"=> "斯威士兰",
            "Sweden"=> "瑞典",
            "Switzerland"=> "瑞士",
            "Syria"=> "叙利亚",
            "Tajikistan"=> "塔吉克斯坦",
            "Tanzania"=> "坦桑尼亚",
            "Thailand"=> "泰国",
            "The Kingdom of Tonga"=> "汤加王国",
            "Timor-Leste"=> "东帝汶",
            "Togo"=> "多哥",
            "Trinidad and Tobago"=> "特立尼达和多巴哥",
            "Tunisia"=> "突尼斯",
            "Turkey"=> "土耳其",
            "Turkmenistan"=> "土库曼斯坦",
            "Uganda"=> "乌干达",
            "Ukraine"=> "乌克兰",
            "United Arab Emirates"=> "阿拉伯联合酋长国",
            "United Kingdom"=> "大不列颠联合王国",
            "United Republic of Tanzania"=> "坦桑尼亚联合共和国",
            "United States"=> "美国",
            "United States of America"=> "美利坚合众国",
            "Uruguay"=> "乌拉圭",
            "Uzbekistan"=> "乌兹别克斯坦",
            "Vanuatu"=> "瓦努阿图",
            "Venezuela"=> "委内瑞拉",
            "Vietnam"=> "越南",
            "West Bank"=> "西岸",
            "W. Sahara"=> "西撒哈拉",
            "Yemen"=> "也门",
            "Zambia"=> "赞比亚",
            "Zimbabwe"=> "津巴布韦"
        ];
    }

    //启动人数按天
    public function startapp_data()
    {
        $language = $this->lang->language;
        $type = $this->input->get('type');
        $type = $type ? $type : 1;

        if ($this->is_ajax()) {
            $startTime = $endTime = 0;
            $endTime = time();
            if ($type == 1) {
                $startTime = $endTime - 3600;
            } else if ($type == 2) {
                $startTime = $endTime - 86400;
            } else if ($type == 3) {
                $startTime = $endTime - 86400*7;
            } else if ($type == 4) {
                $startTime = $endTime - 86400*30;
            }
            $params = [
                'time' => $startTime,
                'time2' => $endTime
            ];

            $this->load->model('Statapplogstart_model', 'stat_model');
            $lists = $this->stat_model->getAllStartTimes($startTime, $endTime);
            $result = [];
            $result['status'] = true;
            $result['namemap'] = $this->getCountryName();
            
            $data_list = [];
            foreach ($lists as $k=>$v) {
                if(!isset($data_list[$v['country']])) {
                    $data_list[$v['country']] = [
                        'name' => $v['countrycn'],
                        'value' => 0,
                    ];
                }
                $data_list[$v['country']]['value'] = $data_list[$v['country']]['value'] + $v['total'];
            }
            $result['dataArr'] = $data_list;
           
            $count = count($result);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $data['language'] = $language;
        $data['type'] = $type;
        $this->render('report/startapp_data', $data);
    }
}
