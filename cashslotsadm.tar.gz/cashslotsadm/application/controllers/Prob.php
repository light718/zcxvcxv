<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 概率控制
 * Class User
 */

class Prob extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('prob_lang');
    }

    public function index()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        $this->render('prob/index', $data);
    }

    // 概率控制
    public function lists()
    {
        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');

            $language = $this->lang->language;
            $params = array(
                'keyword' => str_replace('-', '', $keywords),
                'page' => $page,
//                'orderBy' => $field . '|' . $order
            );
            $result = $this->requestApi('/prob/generals', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['date_time'] = date('Y-m-d', $one['create_time']) . '<br>' . date('H:i:s', $one['create_time']);
                $one['username'] = $one['username'] ? $one['username'] : formatPlayerUsername($one['pid']);
                $one['prob'] = $language['prob_' . $one['prob']];
                $one['time'] = $one['duration'];
                $one['status'] = $one['status'] == 1 ? 0 : ($one['remain_time'] > 0 ? 1 : 0);
                $one['add_coin'] = formatMoney($one['add_coin']);
                $one['sub_coin'] = formatMoney($one['sub_coin']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }
    }

    public function controlProxy()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['total_coin'] = formatMoney(0);
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-1 weeks')),
            'month' => date('Y-m-01')
        );
        $this->render('prob/control_proxy', $data);
    }

    public function proxyLists()
    {
        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $keywords = $this->input->get('keywords');
            $language = $this->lang->language;
            $params = array(
                'keyword' => $keywords,
                'page' => $page,
//                'orderBy' => $field . '|' . $order
            );
            $result = $this->requestApi('/prob/first_proxy', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['date'] = date('Y-m-d');
                $one['prob'] = $language['prob_' . $one['cur_prob']];
                $one['add_coin'] = formatMoney($one['add_coin']);
                $one['sub_coin'] = formatMoney($one['sub_coin']);
                $one['win'] = formatMoney($one['win']);
            }
            $count = $result['data']['total'];
            $totalWin = $result['data']['total_win'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'total_win' => $totalWin));
        }
    }

    public function controlPlayer()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['total_coin'] = formatMoney(0);
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-1 weeks')),
            'month' => date('Y-m-01')
        );
        $this->render('prob/control_player', $data);
    }

    public function playerLists()
    {
        if ($this->is_ajax()) {
            $page = $this->input->get('page');
            $keywords = $this->input->get('keywords');
            $vip = $this->input->get('vip');

            if (empty($keywords)) {
                exit(json_encode(array('code' => 0, 'msg' => '', 'count' => 0, 'data' => array())));
            }

            $language = $this->lang->language;

            $params = array(
                'vip' => $vip,
                'keyword' => str_replace('-', '', $keywords),
                'page' => $page
            );
            $result = $this->requestApi('/prob/players', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['date'] = date('Y-m-d');
                $one['prob'] = $language['prob_' . $one['cur_prob']];
            }
            $count = $result['data']['total'];
            $totalWin = $result['data']['total_win'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'total_win' => $totalWin));
        }
    }

    public function handle()
    {
        $username = $this->input->get('username');
        $nickname = $this->input->get('nickname');
        $type = $this->input->get('type');
        $id = $this->input->get('id');
        $curProb = $this->input->get('cur_prob');
        $language = $this->lang->language;
        $data['prob'] = array(
            1 => $language['prob_1'],
            2 => $language['prob_2'],
            3 => $language['prob_3'],
            4 => $language['prob_4'],
            5 => $language['prob_5']
        );
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $username;
        $data['nickname'] = $nickname;
        $data['id'] = $id;
        $data['type'] = $type;
        $data['cur_prob'] = $curProb;

        $this->render('prob/handle', $data);
    }

    public function saveHandle()
    {
        if ($this->is_ajax()) {
            $prob = $this->input->post('prob');
            $time = $this->input->post('time');
            $id = $this->input->post('id');

            $language = $this->lang->language;

            if (!$time) {
                jsonReturn(EXIT_ERROR, $language['return_error_01']);
                exit();
            }

            if ($time > 1440) {
                jsonReturn(EXIT_ERROR, $language['return_error_02']);
                exit();
            }

            $params = array(
                'account_id' => $id,
                'prob' => $prob,
                'duration' => $time
            );
            $result = $this->requestApi('/prob/general', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);

                $this->config->set_item('language', 'zh_cn_' . CSS_VERSION);
                $this->lang->load('prob_lang');
                $cn_prob = $this->lang->language['prob_' . $prob];
                $this->config->set_item('language', 'english_' . CSS_VERSION);
                $this->lang->load('prob_lang');
                $en_prob = $this->lang->language['prob_' . $prob];

                $this->record('概率控制', "设定（%s）概率（%s）（%s）分钟", [$id, $cn_prob . '|||' . $en_prob, $time]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }    
    }

    public function batchHandle()
    {
        $type = $this->input->get('type');
        $keywords = $this->input->get('keywords');
        $vip = $this->input->get('vip');
        $language = $this->lang->language;
        $data['prob'] = array(
            1 => $language['prob_1'],
            2 => $language['prob_2'],
            3 => $language['prob_3'],
            4 => $language['prob_4'],
            5 => $language['prob_5']
        );
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['keywords'] = $keywords;
        $data['type'] = $type;
        $data['vip'] = $vip;

        $this->render('prob/batch_handle', $data);
    }

    public function saveBatchHandle()
    {
        if ($this->is_ajax()) {
            $prob = $this->input->post('prob');
            $time = $this->input->post('time');
            $type = $this->input->post('type');
            $keywords = $this->input->post('keywords');
            $vip = $this->input->post('vip');

            $language = $this->lang->language;

            if (!$time) {
                jsonReturn(EXIT_ERROR, $language['return_error_01']);
                exit();
            }

            if ($time > 1440) {
                jsonReturn(EXIT_ERROR, $language['return_error_02']);
                exit();
            }

            $params = array(
                'type' => $type,
                'keyword' => $keywords,
                'vip' => $vip,
                'prob' => $prob,
                'duration' => $time
            );
            $result = $this->requestApi('/prob/batch_add', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);

                $this->config->set_item('language', 'zh_cn_' . CSS_VERSION);
                $this->lang->load('prob_lang');
                $cn_prob = $this->lang->language['prob_' . $prob];
                $this->config->set_item('language', 'english_' . CSS_VERSION);
                $this->lang->load('prob_lang');
                $en_prob = $this->lang->language['prob_' . $prob];
                
                $this->record('概率控制', "批量设定概率（%s）（%s）分钟", [$cn_prob . '|||' . $en_prob, $time]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }
}