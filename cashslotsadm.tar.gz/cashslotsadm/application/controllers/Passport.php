<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Passport extends MY_Controller
{
    public function captcha()
    {
        $this->load->library('captcha');
        $captcha= $this->captcha->getCaptcha();
        $this->session->set_userdata('captcha', $captcha);
        $this->captcha->showImg();
    }

    public function login()
    {
        $data = array();
        $lang = $this->input->get('lang');
        $lang = $lang === 'english' ? 'english' : 'zh_cn';
        $this->session->set_userdata('lang', $lang);
        $data['lang'] = $lang;
        $this->config->set_item('language', $lang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('passport_lang');
        $data['language'] = $this->lang->language;
        return $this->render('passport/login', $data);
    }

    public function checkLogin()
    {
        $lang = $this->session->userdata('lang');
        $this->config->set_item('language', $lang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('passport_lang');
        $language = $this->lang->language;

        $username = $this->input->post('username');
        $username = strtolower($username); //一律小写
        $password = $this->input->post('password');
        // $vercode = $this->input->post('vercode');
        if (empty($username)) {
            jsonReturn(EXIT_ERROR, $language['username_empty']);
            exit();
        }
        if (empty($password)) {
            jsonReturn(EXIT_ERROR, $language['password_empty']);
            exit();
        }
        // if (empty($vercode)) {
        //     jsonReturn(EXIT_ERROR, $language['captcha_empty']);
        // }
        // if (strtolower($vercode) !== strtolower($this->session->userdata('captcha'))) {
        //     jsonReturn(EXIT_ERROR, $language['captcha_error']);
        // } else {
        //     $this->session->unset_userdata('captcha');
        // }

        $params = array(
            'username' => $username,
            'pwdmd5' => md5($password),
            'ip' => getIp(),
        );
        $result = $this->requestApi(API_URL_BASE . '/account/login', 'GET', $params);
        if ($result['errcode'] === 0) { //登录成功
            // 判断域名是否对应
            // if ($result['data']['account']['agent'] == ADMIN_SYSTEM) {
            //     $admin_domains = explode(',', SYS_ADMIN_DOMAIN);
            //     if(!in_array(DOMAIN, $admin_domains)) {
            //         jsonReturn(EXIT_ERROR, $language['username_password_error'].'1');
            //         exit();
            //     }
            // } elseif ($result['data']['account']['agent'] == ADMIN_PROXY_GENERAL) {
            //     $agent_domains = explode(',', ROOT_ADMIN_DOMAIN);
            //     if(!in_array(DOMAIN, $agent_domains)) {
            //         jsonReturn(EXIT_ERROR, $language['username_password_error'].'2');
            //         exit();
            //     }
            // } elseif ($result['data']['account']['agent'] == ADMIN_PROXY_NORMAL) {
            //     $agent_domains = explode(',', GENERAL_ADMIN_DOMAIN);
            //     if(!in_array(DOMAIN, $agent_domains)) {
            //         jsonReturn(EXIT_ERROR, $language['username_password_error'].'3');
            //         exit();
            //     }
            // }
            $this->session->set_userdata('user_info', $result['data']);
            // 用户账号密码保存到session，用户地区
            $this->session->set_userdata('user_account_pwd', $params);
            $this->token = $result['data']['token'];
            $this->account = $result['data']['account'];
            // 清除登录地区
            $this->session->unset_userdata('select_region');
            $this->record('登录', "代理（%s）登录成功", [$username], false);
            jsonReturn(EXIT_SUCCESS, $language['login_success']);
        } else {
            if ($result['errcode'] == EXIT_LOGIN_FORBIDDEN) {
                jsonReturn(EXIT_ERROR, $language['login_forbidden']);
            } elseif (in_array($result['errcode'], array('30050001', '30050021', '30050051', '30050101', '30050201', '30056001', '30050021')) && isset($result['data']['locksec'])) {
                $locksec = $result['data']['locksec'];
                if (floor($locksec / 60) > 1) {
                    $seconds = ceil($locksec / 60) . $language['minute'];
                } else {
                    $seconds = $locksec . $language['second'];
                }
                jsonReturn(EXIT_ERROR, str_replace("{%seconds%}", $seconds, $language['account_lock']));
            } elseif ($result['errcode'] == EXIT_ACCOUNT_IP) {
                jsonReturn(EXIT_ERROR, $language['login_ip_error']);
            } else {
                jsonReturn(EXIT_ERROR, $language['username_password_error'].$result['errcode']);
            }
        }
    }

    public function logout()
    {
        $this->requestApi('/account/logout', 'GET', array());
        $this->session->unset_userdata('user_info');
        redirect(SCHEME . '://' . DOMAIN . '/passport/login');
    }
}