<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 玩家管理
 * Class User
 */

class User extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('user_lang');
    }

    public function index()
    {
        $language = $this->lang->language;
        $data['language'] = $language;

        if (isset($this->account['vid']) && $this->account['vid']) { //子账号
            $result = $this->requestApi('/account/current', 'GET', array());
            $gid = explode(',', $result['data']['virtual_group_id']);
            $data['permission'] = $gid;
        }

        $this->render('user/index', $data);
    }

    // 玩家列表
    public function lists()
    {
        if ($this->is_ajax()) {
            $id = $this->input->get('id');
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'account_id';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'keyword' => $keywords,
                'page' => $page,
                'orderby' => $field . '|' . $order
            );
            $id && $params['id'] = $id;
            $result = $this->requestApi('/account/players', 'GET', $params, true);
            // var_dump($result);exit;
            $lists = array();
            $count = 0;
            if ($result) {
                foreach ($result['data']['list'] as $row) {
                    $tmp = array();
                    $tmp['account_id'] = $row['account_id'];
                    $tmp['account_pid'] = formatPlayerUsername($row['account_pid']);
                    $tmp['account_nickname'] = $row['account_nickname'];
                    $tmp['account_coin'] = formatMoney($row['account_coin']);
                    $tmp['account_bandepth'] = intval($row['account_banby_id']);
                    $tmp['account_banby_id'] = intval($row['account_banby_id']);
                    $tmp['account_online'] = isset($row['account_online']) ? $row['account_online'] : 0;
                    $tmp['account_login_time'] = $row['account_login_time'] ? date('Y-m-d H:i:s', $row['account_login_time']) : 0;
                    $tmp['account_vip'] = $row['account_vip'];
                    $tmp['account_phone'] = $row['account_phone'];
                    $tmp['account_remark'] = $row['account_remark'];
                    $tmp['red_envelope_flag'] = isset($row['red_envelope']) && $row['red_envelope'] > 0 ? 1 : 0;
                    $tmp['red_envelope'] = formatMoney(isset($row['red_envelope']) ? $row['red_envelope'] : 0);
                    $lists[] = $tmp;
                }
                $count = $result['data']['total'];
            }

            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }
    }

    // 新增玩家
    public function add()
    {
        if (CSS_VERSION == 'poly') {
            // 生成用户ID
            $result = $this->requestApi('/account/playerPoly', 'PUT', []);
            $data['account_id'] = $result['data']['account'];
        } else {
            $result = $this->requestApi('/system/account_setting', 'GET');
            $data['setting'] = $result['data'];
        }
        $data['language'] = $this->lang->language;
        $result = $this->requestApi('/account/current', 'GET', array());
        $data['max_value'] = formatMoney($result['data']['account_coin']);
        $this->render('user/add', $data);
    }

    // 编辑玩家
    public function edit()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $nickname = $this->input->post('nickname');
            $tel = $this->input->post('tel');
            $note = $this->input->post('note');
            if (empty($password) && empty($nickname)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = array(
                'account' => str_replace('-', '', $username),
            );
            if ($password != '********') {
                $password && $params['password'] = md5($password);
            }
            $nickname && $params['nickname'] = $nickname;
            $tel && $params['phone'] = $tel;
            $note && $params['remark'] = $note;
            $result = $this->requestApi('/account/player', 'PUT', $params);
            if ($result['errcode'] != 0) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('玩家管理', "编辑玩家（%s）成功", [$username]);
            } else {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('玩家管理', "编辑玩家（%s）失败", [$username]);
            }
        } else {
            $username = $this->input->get('username');
            $params = array(
                'account' => str_replace('-', '', $username)
            );
            $result = $this->requestApi('/account/player_detail', 'GET', $params);
            $data['player'] = $result['data'];
            $data['language'] = $language;
            $this->render('user/edit', $data);
        }
    }

    // 提交新增玩家
    public function save()
    {
        if ($this->is_post()) {
            if (CSS_VERSION == 'poly') {
                $account = $this->input->post('username');
                $password = $this->input->post('password');
                $nickname = $this->input->post('nickname');
                $score = $this->input->post('score');
                $tel = $this->input->post('tel');
                $note = $this->input->post('note');
                $language = $this->lang->language;
                if (empty($account) || empty($password) || empty($nickname)) {
                    jsonReturn(EXIT_ERROR, $language['add_empty']);
                    exit();
                }
                $params = array(
                    'account' => $account,
                    'password' => md5($password),
                    'nickname' => $nickname,
                    'coin' => $score,
                    'phone' => $tel,
                    'remark' => $note,
                    'ipaddr' => getIp()
                );
                $result = $this->requestApi('/account/playerPoly', 'POST', $params);
                if ($result['errcode'] == 0) {
                    jsonReturn(EXIT_SUCCESS, $language['return_success']);
                    $this->record('玩家管理', "添加玩家成功" );
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    $this->record('玩家管理', "添加玩家失败");
                }
            } else {
                $number = $this->input->post('number');
                $password = $this->input->post('password');
                $nickname = $this->input->post('nickname');
                $language = $this->lang->language;
                if (empty($number) || empty($password) || empty($nickname)) {
                    jsonReturn(EXIT_ERROR, $language['add_empty']);
                    exit();
                }
                if ($number > 20) {
                    jsonReturn(EXIT_ERROR, $language['add_number_error_max']);
                    exit();
                }

                $params = array(
                    'playertotal' => $number,
                    'password' => md5($password),
                    'nickname' => $nickname
                );
                $result = $this->requestApi('/account/player', 'POST', $params);
                if ($result['errcode'] == 0) {
                    $uids = implode('<br>', $result['data']);
                    jsonReturn(EXIT_SUCCESS, $language['return_success'], array('uids' => $uids));
                    $this->record('玩家管理', "添加玩家成功");
                } else if ($result['errcode'] == 4001) {
                    jsonReturn(EXIT_ERROR, $language['add_number_error_max_all']);
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    $this->record('玩家管理', "添加玩家失败");
                }
            }

        }
    }

    // 上下分记录
    public function coinRecord()
    {
        $language = $this->lang->language;
        $username = $this->input->get('username');
        $nickname = $this->input->get('nickname');
        $data['username'] = $username;
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $username;
        $data['nickname'] = $nickname;
        $data['status'] = 1;
        $data['coin'] = formatMoney(0);
        $data['total_change_coin'] = formatMoney(0);
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-1 weeks')),
            'month' => date('Y-m-01')
        );
        $this->render('user/coin_record', $data);
    }

    // 上下分记录列表
    public function coinRecordLists()
    {
        if ($this->is_ajax()) {
            $username = $this->input->get('username');
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $field = $field ? $field : 'coin_time';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';
            $params = array(
                'account' => str_replace('-', '', $username),
                'page' => $page,
                'orderby' => $field . '|' . $order
            );
            if ($startTime && $endTime) {
                $params['times'] = strtotime($startTime) . '.' . (strtotime($endTime) + 86400);
            }
            $result = $this->requestApi('/finance/player_coins', 'GET', $params, true);

            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin_time'] = date('Y-m-d H:i:s', $one['coin_time']);
                $one['coin_change'] = formatMoney($one['coin_change']);
                $one['coin_befor'] = formatMoney($one['coin_befor']);
                $one['coin_after'] = formatMoney($one['coin_after']);
                $one['ipaddr'] = isset($one['ipaddr']) ? $one['ipaddr'] : '';
                $one['from_username'] = isset($one['from_username']) ? $one['from_username'] : '';
                $one['to_username'] = isset($one['to_username']) ? $one['to_username'] : '';
            }
            $count = $result['data']['total'];
            $coinTotal = formatMoney(isset($result['data']['cointotal']) ? $result['data']['cointotal'] : 0);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'cointotal' => $coinTotal));
        }
    }

    public function coin()
    {
        $uid = $this->input->get('uid');
        $data['uid'] = $uid;
        $data['language'] = $this->lang->language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $this->input->get('username');
        $data['nickname'] = $this->input->get('nickname');

        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-1 weeks')),
            'month' => date('Y-m-01')
        );
        $this->render('user/change_coin', $data);
    }

    public function changeCoin()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $coin = $this->input->post('coin');
            $type = $this->input->post('type');
            $username = $this->input->post('username');

            $params = array(
                'account' => $username,
                'coin' => $coin,
                'ipaddr' => getIp()
            );
            if ($type == 'add') {
                $result = $this->requestApi('/finance/player_coin_up', 'POST', $params);
            } else if ($type == 'sub') {
                $result = $this->requestApi('/finance/player_coin_down', 'POST', $params);
            } else if ($coin > 0) {
                $type = 'add';
                $result = $this->requestApi('/finance/player_coin_up', 'POST', $params);
            } else if ($coin < 0) {
                $type = 'sub';
                // 踢玩家下线
                // $result = $this->requestApi('/account/player_offline', 'PUT', ['account' => $username]);
                // if ($result['errcode'] != 0) {
                //     jsonReturn(EXIT_ERROR, $language['return_fail']);
                //     exit();
                // }
                $params['coin'] = abs($coin);
                $result = $this->requestApi('/finance/player_coin_down', 'POST', $params);
            }
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($type === 'add') {
                    $this->record('玩家管理', "玩家（%s）上分（%s）成功", [$username, $coin]);
                } else {
                    $this->record('玩家管理', "玩家（%s）下分（%s）成功", [$username, $coin]);
                }
            } elseif ($result['errcode'] == EXIT_COIN_LACK) {
                jsonReturn(EXIT_ERROR, $type == 'add' ? $language['return_up_coin_lack'] : $language['return_down_coin_lack']);
                if ($type === 'add') {
                    $this->record('玩家管理', "玩家（%s）上分（%s）失败。额度不足", [$username, $coin]);
                } else {
                    $this->record('玩家管理', "玩家（%s）下分（%s）失败。额度不足", [$username, $coin]);
                }
            } else {
                if ($type === 'add') {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail'] . ', ' . $language['off_line_error']);
                }
            }
        }
    }

    public function changeStatus()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $username = $this->input->post('username');
            $type = $this->input->post('type');
            if ($username == '' || !in_array($type, array('offline', 'normal', 'forbidden'))) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                exit();
            }

            if ($type === 'offline') {
                $params = array(
                    'account' => $username
                );
                $result = $this->requestApi('/account/player_offline', 'PUT', $params);
                if ($result['errcode'] == 0) {
                    jsonReturn(EXIT_SUCCESS, $language['return_success']);
                    $this->record('玩家管理', "玩家（%s）踢下线成功", [$username]);
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    $this->record('玩家管理', "玩家（%s）踢下线失败", [$username]);
                }
            } else {
                $params = array(
                    'account' => $username
                );
                if($type == 'forbidden') {
                    $result = $this->requestApi('/account/player_offline', 'PUT', $params);
                    if ($result['errcode'] != 0) {
                        jsonReturn(EXIT_ERROR, $language['return_fail']);
                        $this->record('玩家管理', "禁用玩家, 玩家（%s）踢下线失败", [$username]);
                        return;
                    }
                }

                $result = $this->requestApi('/account/ban', 'PUT', $params);
                if ($result['errcode'] == 0) {
                    jsonReturn(EXIT_SUCCESS, $language['return_success']);
                    if ($type === 'forbidden') {
                        $this->record('玩家管理', "禁用玩家（%s）成功", [$username]);
                    } else {
                        $this->record('玩家管理', "启用玩家（%s）成功", [$username]);
                    }
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    if ($type === 'forbidden') {
                        $this->record('玩家管理', "禁用玩家（%s）失败", [$username]);
                    } else {
                        $this->record('玩家管理', "启用玩家（%s）失败", [$username]);
                    }
                }
            }
        } else {
            $data['language'] = $language;
            $data['lang'] = $this->selectedLang;
            $username = $this->input->get('username');
            $nickname = $this->input->get('nickname');
            $data['username'] = $username;
            $data['nickname'] = $nickname;
            $params = array(
                'account' => str_replace('-', '', $username)
            );
            $result = $this->requestApi('/account/player_detail', 'GET', $params);
            $data['status'] = $result['data']['account_banby_id'];
            $data['online'] = $result['data']['account_online'];
            $data['coin'] = formatMoney($result['data']['account_coin']);
            $this->render('user/change_status', $data);
        }
    }

    public function copyInfo()
    {
        $username = $this->input->get('username');
        $nickname = $this->input->get('nickname');
        $coin = $this->input->get('coin');
        $language = $this->lang->language;
        $language['copy_notice02'] = str_replace('{%username%}', $username, $language['copy_notice02']);
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $username;
        $data['nickname'] = $nickname;
        $data['status'] = 0;
        $this->render('user/copy_info', $data);
    }

    // 获取用户状态和分数
    public function getUserInfo()
    {
        if ($this->is_ajax()) {
            $username = $this->input->post('username');

            if (!$username) {
                jsonReturn(EXIT_ERROR, '');
                exit();
            }

            $params = array(
                'account' => str_replace('-', '', $username)
            );
            $result = $this->requestApi('/account/player_detail', 'GET', $params);
            $language = $this->lang->language;
            if ($result['errcode'] == 0) {
                $info['player_status'] = intval($result['data']['account_banby_id']);
                $info['player_coin'] = formatMoney($result['data']['account_coin']);
                $info['player_online'] = intval($result['data']['account_online']);
                $info['player_username'] = formatPlayerUsername($result['data']['account_pid']);
                $info['player_nickname'] = $result['data']['account_nickname'];
                $data['player'] = $info;
                jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
            } else {
                jsonReturn(EXIT_ERROR, $language['user_not_exist']);
            }
        }
    }

    // 获取用户7日上下分
    public function getUserSevenCoin()
    {
        if ($this->is_ajax()) {
            $username = $this->input->post('username');

            if (!$username) {
                jsonReturn(EXIT_ERROR, '');
                exit();
            }

            $endTime = time();
            $startTime = $endTime - 86400*7;
            $params = array(
                'account' => str_replace('-', '', $username),
                'times' => $startTime . '.' . $endTime
            );
            $result = $this->requestApi('/finance/player_coin', 'GET', $params);

            $language = $this->lang->language;
//            $data['player'] = $info;

            jsonReturn(EXIT_SUCCESS, $language['return_success'], $result['data']);
        }
    }

    // 游戏记录
    public function gameRecord()
    {
        $language = $this->lang->language;
        $uid = $this->input->get('uid');
        $data['username'] = $this->input->get('username');
        $data['nickname'] = $this->input->get('nickname');
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('user/game_record', $data);
    }

    // 游戏记录列表
    public function gameRecordLists()
    {
        $this->lang->load('game_detail_lang');
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $username = $this->input->get('username');
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $type = $this->input->get('type');
            $field = $field ? $field : 'id';
            $order = $order ? $order : 'desc';
            $type = $type ? $type : 1; //默认是单人记录

            $params = array(
                'account' => str_replace('-', '', $username),
                'page' => $page,
                'start_time' => strtotime($startTime),
                'end_time' => strtotime($endTime),
                'orderby' => $field . ' ' . $order,
                'type' => $type,
            );
            $result = $this->requestApi('/stat/game_records_poly', 'GET', $params, true);
            $lists = $result['data']['list'];
            $count = $result['data']['total'];
            $coin = formatMoney($result['data']['coin']);
            $gameLists = $this->getGameList(1);
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                $one['before'] = formatMoney($one['before']);
                $one['after'] = formatMoney($one['after']);
                $one['game_type'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['type'] : 0;
                $one['is_open'] = 0;
                if ($one['game_id'] >= 10000) {
                    if (in_array($one['game_id'], [10000, 20000])) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['change_coin_title'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 60000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['red_envelope'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 120000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['online_reward'] . '：' . formatMoney($one['win']) . '</span>';
                    }
                    $one['bet'] = "<span style='color:red;font-weight:bold;'>-</span>";
                    $one['win'] = "<span style='color:red;font-weight:bold;'>-</span>";
                    $one['game_name'] = '-';
                } else {
                    // 捕鱼不能查看详情
                    $buyuGameIds = [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39];
                    if (!in_array($one['game_id'], $buyuGameIds)) {
                        $one['is_open'] = 1;
                    }
                    $one['table_id'] = $one['desk_id'];
                    $one['bet'] = formatMoney($one['bet']);
                    if ($one['bet'] == '0.00' && $one['game_type'] != 4) { //过滤捕鱼的技能炮
                        $one['bet'] = $language['game_log_free_game'];
                    }
                    $one['win'] = formatMoney($one['win']);
                    $one['game_name'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['name'] : $one['game_id'];
                }
                $rlt = json_decode($one['rlt'], true);
                $one['isbibei'] = isset($rlt['isbibei']) && $rlt['isbibei'] ? 1 : 0;
                if ($one['isbibei'] == 1) {
                    $one['is_open'] = 0;
                    $double = $one['win'] > 0 ? $language['double_win'] : $language['double_loss'];
                    $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $double . '</span>';
                }
                unset($one['rlt']);

            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'coin' => $coin));
        }
    }

    public function searchCoin()
    {
        $language = $this->lang->language;
        $username = $this->input->get('username');
        $nickname = $this->input->get('nickname');
        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $field = $field ? $field : 'date';
            $order = $order ? $order : 'desc';

            $params = array(
                'account' => str_replace('-', '', $username),
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'orderby' => $field . ' ' . $order
            );
            $result = $this->requestApi('/stat/players', 'GET', $params, true);
            $lists = array();
            if(isset($result['data']['list'])) {
                foreach ($result['data']['list'] as $row) {
                    $tmp = array();
                    $tmp['date'] = $row['date'];
                    $tmp['username'] = $username;
                    $tmp['win'] = formatMoney($row['win'] ? $row['win'] : 0);
                    $tmp['bigbang'] = formatMoney($row['bigbang'] ? $row['bigbang'] : 0);
                    $tmp['evowin'] = formatMoney($row['evowin'] ? $row['evowin'] : 0);
                    $lists[] = $tmp;
                }
            }
            $count = (strtotime($endTime) - strtotime($startTime)) / 86400 + 1;
            $totalWin = formatMoney(isset($result['data']['total_win']) ? $result['data']['total_win'] : 0);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'total_win' => $totalWin, 'data' => $lists));
        }
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $username;
        $data['nickname'] = $nickname;
        $data['total_change_coin'] = formatMoney(0);
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('user/search_coin', $data);
    }

    public function changeStatusAllPlayer()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $status = $this->input->post('status');

            if ($status == 1) {
                $params = array(
                    'account' => '000000000000'
                );
                $result = $this->requestApi('/account/ban', 'PUT', $params);
                if ($result['errcode'] == 0) {
                    jsonReturn(EXIT_SUCCESS, $language['return_success']);
                    $this->record('玩家管理', "禁用所有玩家成功");
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    $this->record('玩家管理', "禁用所有玩家失败");
                }
            } else {
                $params = array(
                    'account' => '000000000001'
                );
                $result = $this->requestApi('/account/ban', 'PUT', $params);
                if ($result['errcode'] == 0) {
                    jsonReturn(EXIT_SUCCESS, $language['return_success']);
                    $this->record('玩家管理', "解禁所有玩家成功");
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    $this->record('玩家管理', "解禁所有玩家失败");
                }
            }
        }
    }

    // 玩家总账
    public function playerTotalReport()
    {
        $language = $this->lang->language;
        $username = $this->input->get('username', '');
        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');

            $startTime = strtotime($startTime);
            $endTime = strtotime($endTime) + 86399;

            $params = array(
                'username' => $username,
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime
            );
            $result = $this->requestApi('/stat/player_total_report', 'GET', $params, true);
            $lists = [];
            if(isset($result['data']['list'])) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['coin'] = formatMoney($one['coin']);
                    $one['evocoin'] = formatMoney($one['evocoin']);
                }
            }

            $count = $result['data']['total'];
            $result['data']['total_win'] = $result['data']['total_win'] ;
            $totalWin = formatMoney($result['data']['total_win']);
            $totalEvoWin = formatMoney($result['data']['total_evo']);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'total_win' => $totalWin, 'total_evo_win' => $totalEvoWin));
        }

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $data['username'] = $username;
        $this->render('user/player_total_report', $data);
    }

    // 游戏记录列表
    public function gameRecordPolyLists()
    {
        $this->lang->load('game_detail_lang');
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $username = $this->input->get('username');
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $field = $field ? $field : 'create_time';
            $order = $order ? $order : 'desc';
            $type = $this->input->get('type');
            $type = $type ? intval($type) : 1;

            $params = array(
                'account' => str_replace('-', '', $username),
                'page' => $page,
                'start_time' => strtotime($startTime),
                'end_time' => strtotime($endTime),
                'orderby' => $field . ' ' . $order,
                'type' => $type,
            );
            $result = $this->requestApi('/stat/game_records_poly', 'GET', $params, true);
            $lists = $result['data']['list'];
            $count = $result['data']['total'];
            $coin = $result?0:formatMoney($result['data']['coin']);
            $gameLists = $this->getGameList(1);
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
                $one['before'] = formatMoney($one['before']);
                $one['after'] = formatMoney($one['after']);
                $one['game_type'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['type'] : 0;
                $one['is_open'] = 0;
                if ( in_array($one['game_id'], [30201,30206,30209,30210])) {
                    // $one['bet'] = '<span class="text-red text-bold">-</span>';
                    // $one['win'] = '<span class="text-red text-bold">-</span>';
                    $one['game_name'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['name'] : $one['game_id'];
                    if(!empty($one['extend1'])) {
                        $one['game_name'] = '视讯 - ' . $one['extend1'];
                    }

                }
                else if ($one['game_id'] >= 10000) {
                    if (in_array($one['game_id'], [10000, 20000])) {
                        $one['table_id'] = '<span class="text-red text-bold">' . $language['set_coin'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 60000 || $one['game_id']==100000) {
                        $one['table_id'] = '<span class="text-red text-bold">' . $language['red_envelope'] . '：' . formatMoney($one['win']) . '</span>';
                    }  elseif ($one['game_id'] == 120000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['online_reward'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 80000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['upgrade_reward'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 130000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['register_reward'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 140000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['turntable_reward'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 150000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['mail_reward'] . '：' . formatMoney($one['win']) . '</span>';
                    } elseif ($one['game_id'] == 160000) {
                        $one['table_id'] = '<span style="color:red;font-weight:bold;">' . $language['quest_reward'] . '：' . formatMoney($one['win']) . '</span>';
                    }


                    $one['bet'] = '<span class="text-red text-bold">-</span>';

                    $one['game_name'] = '-';
                    if($one['game_id'] == 100000) {
                        $one['game_name'] = '<img src="/RedEnvelope.png" />';
                    }

                    if ($one['game_id'] == 30000) {
                        if($one['extend1'] == 106) {
                            $one['table_id'] = '<span class="text-red text-bold">' . $language['evo_recharge'] . '：' . formatMoney($one['win']) . '</span>';
                        } else {
                            $one['table_id'] = '<span class="text-red text-bold">' . $language['evo_withdrawal'] . '：' . formatMoney($one['win']) . '</span>';
                        }
                        $one['win'] = "0";
                    } else {
                        $one['win'] = '<span class="text-red text-bold">-</span>';
                    }
                } else {
                    // 捕鱼不能查看详情
                    $buyuGameIds = [24, 25, 26, 27, 28, 29, 30, 31, 32, 33];
                    if (!in_array($one['game_id'], $buyuGameIds)) {
                        $one['is_open'] = 1;
                    }
                    // 闪亮之星自由转不能点击查看详情
                    if ($one['game_id'] == 156 && $one['bet'] == '0.00') {
                        $one['is_open'] = 0;
                    }
                    $one['table_id'] = $one['desk_id'];
                    $one['bet'] = formatMoney($one['bet']);
                    if ($one['bet'] == '0.00' && $one['game_type'] != 4) { //过滤捕鱼的技能炮
                        $one['bet'] = $language['game_log_free_game'];
                    }
                    // 牛牛特殊处理 将输钱加入到下注里面
                    if ($one['game_id'] == 234 && $one['win'] < 0) {
                        $one['bet'] = formatMoney($one['bet'] + abs($one['win']));
                    }
                    $one['win'] = formatMoney($one['win']);
                    $one['game_name'] = isset($gameLists[$one['game_id']]) ? $gameLists[$one['game_id']]['name'] : $one['game_id'];
                }
                $rlt = json_decode($one['rlt'], true);
                $one['isbibei'] = isset($rlt['isbibei']) && $rlt['isbibei'] ? 1 : 0;
                if ($one['isbibei'] == 1) {
                    $one['is_open'] = 0;
                    $double = $one['win'] > 0 ? $language['double_win'] : $language['double_loss'];
                    $one['table_id'] = '<span class="text-red text-bold">' . $double . '</span>';
                }
                unset($one['rlt']);

            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'coin' => $coin));
        }
    }

    // 上下分记录列表
    public function coinRecordPolyLists()
    {
        if ($this->is_ajax()) {
            $username = $this->input->get('username');
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $field = $field ? $field : 'coin_time';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';
            $params = array(
                'username' => str_replace('-', '', $username),
                'page' => $page,
                'orderby' => $field . '|' . $order
            );
            if ($startTime && $endTime) {
                $params['times'] = strtotime($startTime) . '.' . (strtotime($endTime) + 86400);
            }
            $result = $this->requestApi('/finance/coins', 'GET', $params, true);

            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin_time'] = date('Y-m-d H:i:s', $one['coin_time']);
                $one['coin_change'] = formatMoney($one['coin_change']);
                $one['coin_befor'] = formatMoney($one['coin_befor']);
                $one['coin_after'] = formatMoney($one['coin_after']);
                $one['ipaddr'] = isset($one['ipaddr']) ? $one['ipaddr'] : '';
                $one['from_username'] = isset($one['from_username']) ? $one['from_username'] : '';
                $one['to_username'] = isset($one['to_username']) ? $one['to_username'] : '';
            }
            $count = $result['data']['total'];
            $coinTotal = formatMoney(isset($result['data']['cointotal']) ? $result['data']['cointotal'] : 0);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'cointotal' => $coinTotal));
        }
    }

    public function gameRecordDetail()
    {
        $this->lang->load('game_detail_lang');
        $language = $this->lang->language;
        $logId = $this->input->get('log_id');
        $result = $this->requestApi('/stat/game_record_detail', 'GET', ['log_id' => $logId]);
        if ($result) {
            $data = $result['data'];
            $gameLists = $this->getGameList(1);
            $data['game_name'] = isset($gameLists[$data['game_id']]) ? $gameLists[$data['game_id']]['name'] : '';
            $data['game_timestamp'] = date('Y-m-d H:i:s', $data['game_timestamp']);
            $rlt = json_decode($data['rlt'], true);
            $data['resultCards'] = $rlt['result']['resultCards'];
            $data['x_line'] = 3;
            $data['y_line'] = 5;
        }
        $data['language'] = $language;
        $this->render('user/game_record_detail', $data);
    }

    public function red_envelope_setting()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $red_envelope_switch = $this->input->post('red_envelope_switch');
            !$red_envelope_switch && $red_envelope_switch = 0;
            $red_envelope_max = $this->input->post('red_envelope_max');
            $red_envelope_min = $this->input->post('red_envelope_min');
            if ($red_envelope_max === '' || $red_envelope_min === '') {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = [
                'red_envelope_switch' => $red_envelope_switch,
                'red_envelope_max' => $red_envelope_max,
                'red_envelope_min' => $red_envelope_min
            ];
            $result = $this->requestApi('/system/account_setting', 'POST', $params);
            if ($result['errcode'] != 0) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('玩家管理', "红包设置成功");
            } else {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('玩家管理', "红包设置失败");
            }
        } else {
            $result = $this->requestApi('/system/account_setting', 'GET');
            $data['setting'] = $result['data'];
            $data['language'] = $language;
            $this->render('user/red_envelope_setting', $data);
        }
    }

    // 红包记录
    public function red_envelope_record()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'id';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'keywords' => $keywords,
                'page' => $page,
                'orderby' => $field . '|' . $order
            );
            $result = $this->requestApi('/stat/red_envelope_record', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin'] = formatMoney($one['coin']);
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        } else {
            $data['language'] = $language;
            $this->render('user/red_envelope_record', $data);
        }
    }

    // 红包记录(总代直接发红包，凭空产生)
    public function red_packet_record()
    {
        $language = $this->lang->language;
        $username = $this->input->get('username', "");
        $startTime = $this->input->get('start_time', "");
        $endTime = $this->input->get('end_time', "");

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'id';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $startTime = strtotime($startTime);
            $endTime = strtotime($endTime) + 86399;

            $params = array(
                'keywords' => $keywords,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'page' => $page,
                'orderby' => $field . '|' . $order
            );
            $result = $this->requestApi('/stat/red_packet_record', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin'] = formatMoney($one['coin']);
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        } else {
            $data['language'] = $language;
            $data['username']   = $username;
            $data['start_time'] = $startTime;
            $data['end_time']   = $endTime;
            $data['lang'] = $this->selectedLang;
            $data['date_time'] = array(
                'today' => date('Y-m-d'),
                'yesterday' => date('Y-m-d', strtotime('-1 days')),
                'week' => date('Y-m-d', strtotime('-6 days')),
                'month' => date('Y-m-01')
            );
            $this->render('user/red_packet_record', $data);
        }
    }

    //总代红包设置
    public function red_packet_setting()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {

            $red_coin = $this->input->post('coin');
            $red_account_str = $this->input->post('content');
            if ($red_coin === '' && $red_account_str === '') {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = [
                'coin' => $red_coin,
                'content' => $red_account_str
            ];
            $result = $this->requestApi('/stat/red_packet_setting', 'POST', $params);
            if ($result['errcode'] != 0) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('系统红包', "红包设置成功");
            } else {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('系统红包', "红包设置失败");
            }
        } else {
            $result = $this->requestApi('/system/account_setting', 'GET');
            $data['setting'] = $result['data'];
            $data['language'] = $language;
            $data['red_packet_limitup'] = 20;

            $this->render('user/red_packet_setting', $data);
        }
    }

    // 玩家列表
    public function user_list()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $id = $this->input->get('id');
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'account_id';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'account_id' => $id,
                'keyword' => $keywords,
                'page' => $page
            );
            $result = $this->requestApi('/stat/user_list', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin'] = formatMoney($one['coin']);
                $one['pprofit_total'] = formatMoney($one['pprofit_total']);
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            $count = $result['data']['total'];

            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        } else {
            $data['language'] = $language;
            $this->render('user/user_list', $data);
        }
    }

    // 单个玩家分别对五级代理的分成记录
    public function divide_record()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $account = $this->input->get('account');

            $params = array(
                'account' => $account
            );
            $result = $this->requestApi('/stat/divide_record', 'GET', $params, true);
            if ($result['errcode'] == 0) {
                $lists = $result['data'];
                foreach ($lists as &$one) {
                    $one['total_coin'] = formatMoney($one['total_coin']);
                }
                $count = count($lists);
            } else {
                $lists = [];
                $count = 0;
            }

            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        } else {
            $data['language'] = $language;
            $this->render('user/divide_record', $data);
        }
    }

    // 总流水
    public function total_flows()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $account = $this->input->get('username');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $page = $this->input->get('page');

            $params = array(
                'account' => $account,
                'start_time' => strtotime($startTime),
                'end_time' => strtotime($endTime),
                'page' => $page,
            );
            $result = $this->requestApi('/stat/total_flows', 'GET', $params, true);
            if ($result['errcode'] === 0) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['coin'] = formatMoney(abs($one['coin']));
                }
                $count = $result['data']['total'];
            } else {
                $lists = [];
                $count = 0;
            }

            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        } else {
            $data['language'] = $language;
            $data['lang'] = $this->selectedLang;
            $this->render('user/total_flows', $data);
        }
    }
}
