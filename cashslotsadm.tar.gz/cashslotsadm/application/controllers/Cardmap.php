<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 卷轴配置工具
*/
class Cardmap extends MY_Controller
{
    public function index()
    {
        if ($this->is_post()) {
            $redis = new Redis();
            $port = 6379;
            $host = '127.0.0.1';
            $timeout  = 30;
            $db = 13;
            $password = 'xingC99';

            $gameId = $this->input->post('game_id');
            $userId = $this->input->post('user_id');
            $cardType = $this->input->post('card_type'); //卷轴

            if (!$gameId || !$userId || !$cardType) {
                jsonReturn(EXIT_ERROR, '请输入完整参数');
                exit();
            }
            try {
                if (!$redis->connect($host, $port, $timeout)) {
                    exit();
                }

                if ($password && !$redis->auth($password)) {
                    jsonReturn(EXIT_ERROR, '请输入完整参数');
                    exit();
                }

                if ($db) {
                    $redis->select($db);
                }
            } catch (\Exception $e) {
                jsonReturn(EXIT_ERROR, 'redis连接失败' . $e->getMessage());
            }


            $key = "game_cardmap:{$gameId}";
            if ($userId == 2) {
                $key = "game_freemap:{$gameId}";
            } elseif ($userId == 3) {
                $key = "game_bonusmap:{$gameId}";
            } elseif ($userId == 4) {
                $key = "game_collectfreemap:{$gameId}";
            } elseif ($userId == 5) {
                $key = "game_mapfreegame:{$gameId}";
            }elseif ($userId == 6) {
                $key = "game_firegamemap:{$gameId}";
            }elseif ($userId == 7) {
                $key = "game_bonusgamemap:{$gameId}";
            }

            $value = $cardType;
            if ($redis->set($key, $value)) {
                jsonReturn(EXIT_SUCCESS, '发送成功');
                exit();
            } else {
                jsonReturn(EXIT_SUCCESS, '发送失败');
                exit();
            }
        }

        $this->config->set_item('language', 'zh_cn_poly');
        $this->lang->load('comm_lang');
        $this->lang->load('passport_lang');
        $data['language'] = $this->lang->language;
        $this->render('passport/cardmap', $data);
    }

    public function gameList()
    {
        // 获取游戏列表
        if ($this->is_ajax()) {
            $type = $this->input->post('type');
            $type = 1;
            //$result = $this->requestApi('/system/games', 'GET', array('lang' => ($this->selectedLang === 'english' ? 2 : 1)));
            $gameLists = $this->getGameList(1);//isset($result['data']['list']) ? $result['data']['list'] : array();
            if ($type > 0) {
                $data['game_list'] = [];
                foreach ($gameLists as $row) {
                    $data['game_list'][] = $row;
//                    if (in_array($type, explode(',', $row['type']))) {
//                        $data['game_list'][] = $row;
//                    }
                }
            } else {
                $data['game_list'] = $gameLists;
            }

            jsonReturn(EXIT_SUCCESS, '', $data);
            exit();
        }
    }
}