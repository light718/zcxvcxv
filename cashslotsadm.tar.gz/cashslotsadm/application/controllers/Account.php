<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('account_lang');
    }

    // 代理管理
    public function index()
    {
        $this->lang->load('user_lang');
        $language = $this->lang->language;
        $data['language'] = $language;

        if (isset($this->account['vid']) && $this->account['vid']) { //子账号
            $result = $this->requestApi('/account/current', 'GET', array());
            $gid = explode(',', $result['data']['virtual_group_id']);
            $data['permission'] = $gid;
        }
        $id = $this->input->get('id');
        $data['id'] = $id;
        $this->render('account/index', $data);
    }

    // 代理列表
    public function lists()
    {
        if ($this->is_ajax()) {
            $id = $this->input->get('id');
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $field = $this->input->get('field');
            $field = $field ? $field : 'account_username';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';

            $params = array(
                'keyword' => $keywords,
                'page' => $page,
                // 'orderby' => $field . '|' . $order
            );
            $id && $params['id'] = $id;
            $result = $this->requestApi('/account/generals', 'GET', $params, true);
            $lists = array();
            foreach ($result['data']['list'] as $row) {
                $tmp = array();
                $tmp['account_id'] = $row['account_id'];
                $tmp['account_username'] = $row['account_username'];
                $tmp['account_nickname'] = $row['account_nickname'];
                $tmp['account_coin'] = formatMoney($row['account_coin']);
                $tmp['account_status'] = intval($row['account_banby_id']);
                $tmp['account_phone'] = $row['account_phone'];
                $tmp['account_remark'] = $row['account_remark'];
                $tmp['account_prefix_username'] = $row['account_prefix_username'] ? $row['account_prefix_username'] : '';
                $tmp['account_login_time'] = $row['account_login_time'] ? date('Y-m-d H:i:s', $row['account_login_time']) : 0;
                $lists[] = $tmp;
            }
            $count = $result['data']['total'];
            $username = $result['data']['account'] ? $result['data']['account']['username'] : '';
            $agent = $result['data']['account'] ? $result['data']['account']['agent'] : '';
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'username' => $username, 'agent' => $agent));
        }
    }

    // 设置代理登录IP
    public function loginip()
    {
        $this->lang->load('user_lang');
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $act = $this->input->post('act');
            $username = $this->input->post('username');
            $state = $this->input->post('state', 0);
            if(!in_array($act, ['delip','addip','editip', 'save'])) {
                jsonReturn(EXIT_ERROR, '非法操作');
                exit();
            }
            $sip = $this->input->post('sip');
            if($act != 'save') {
                $ip = $this->input->post('ip');
                if (empty($ip)) {
                    jsonReturn(EXIT_ERROR, 'ip不能为空');
                    exit();
                }
            } else {
                if(!in_array($state, [1, 2])) {
                    jsonReturn(EXIT_ERROR, '状态选择不对');
                    exit();
                }
            }

            $params = [];
            if($act == 'save') {
                $params['username'] = $username;
                $params['state'] = $state;
                $params['act'] = $act;
                $result = $this->requestApi('/account/loginip', 'PUT', $params);
            } else {
                $params['username'] = $username;
                $params['ip'] = $ip;
                $params['sip'] = $sip;
                $params['act'] = $act;
                $result = $this->requestApi('/account/loginip', 'POST', $params);
            }

            $msg = '删除';
            switch ($act) {
                case 'addip':
                    $msg = '添加';
                    break;
                case 'editip':
                    $msg = '修改';
                    break;
                case 'save':
                    $msg = '保存状态';
                    break;
            }
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if($act == 'save') {
                    $this->record('设置代理登录IP', "{$msg}（%s）的登录IP状态 (%s) 成功", [$username, $state]);
                } else {
                    $this->record('设置代理登录IP', "{$msg}（%s）的登录IP (%s) 成功", [$username, $ip]);
                }
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                if($act == 'save') {
                    $this->record('设置代理登录IP', "{$msg}（%s）的登录IP状态 (%s) 失败", [$username, $state]);
                } else {
                    $this->record('设置代理登录IP', "{$msg}（%s）的登录IP (%s) 失败", [$username, $ip]);
                }
            }
            return;
        }

        $username  = $this->input->get('username');
        $params =[
            'username' => $username,
        ];
        $result = $this->requestApi('/account/loginip', 'GET', $params);
        $data['loginip'] = isset($result['data']) ? $result['data'] : null;
        if(is_null($data['loginip'])) {
            $data['loginip'] = [
                'status' => 2
            ];
        }
        $data['username'] = $username;
        $data['language'] = $language;

        $this->render('account/loginip', $data);
    }

    // 新增代理
    public function add()
    {
        $data['language'] = $this->lang->language;
        $result = $this->requestApi('/account/current', 'GET', array());
        $data['max_value'] = formatMoney($result['data']['account_coin']);
        $this->render('account/add', $data);
    }

    // 编辑代理
    public function edit()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $nickname = $this->input->post('nickname');
            $tel = $this->input->post('tel');
            $note = $this->input->post('note');
            if (empty($password) && empty($nickname)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params['username'] = $username;
            if ($password != '********') {
                $password && $params['password'] = md5($password);
            }
            $nickname && $params['nickname'] = $nickname;
            $tel && $params['phone'] = $tel;
            $note && $params['remark'] = $note;
            $result = $this->requestApi('/account/general', 'PUT', $params);
            if ($result['errcode'] == 0) {
                $this->record('代理管理', "编辑代理（%s）成功", [$username]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('代理管理', "编辑代理（%s）失败", [$username]);
            }
        } else {
            $username = $this->input->get('username');
            $params = array(
                'username' => $username
            );
            $result = $this->requestApi('/account/general_detail', 'GET', $params);
            $data['account_user'] = $result['data'];
            $data['language'] = $language;
            $this->render('account/edit', $data);
        }
    }

    // 提交新增代理
    public function save()
    {
        if ($this->is_post()) {
            $region_id = $this->input->post('region_id');
            $prefix_username = $this->input->post('prefix_username');
            $username = $this->input->post('username');
            $username = strtolower($username); //不管代理是大写还是小写，一律存小写
            $password = $this->input->post('password');
            $nickname = $this->input->post('nickname');
            $score = $this->input->post('score');
            $score = intval($score);
            $tel = $this->input->post('tel');
            $note = $this->input->post('note');
            $language = $this->lang->language;
            if(empty($username)) {
                jsonReturn(EXIT_ERROR, $language['username_empty']);
                exit();
            }
            if(empty($password)) {
                jsonReturn(EXIT_ERROR, $language['password_empty']);
                exit();
            }
            // file_put_contents('/tmp/file.log', "nickname is {$nickname}". "\r\n", FILE_APPEND);
            if(intval($nickname)!=0 && empty($nickname)) {
                jsonReturn(EXIT_ERROR, $language['nickname_empty']);
                exit();
            }
//            if (empty($username) || empty($password) || (empty($nickname) && $nickname!=0)) {
//                jsonReturn(EXIT_ERROR, $language['add_empty']);
//                exit();
//            }
            $params = array(
                'region_id' => $region_id,
                'prefix_username' => $prefix_username,
                'username' => $username,
                'password' => md5($password),
                'nickname' => $nickname,
                'coin' => $score,
                'phone' => $tel,
                'remark' => $note,
                'ipaddr' => getIp()
            );
            $result = $this->requestApi('/account/general', 'POST', $params);
            if ($result['errcode'] == 0) {
                $message = str_replace('{%username%}', $prefix_username . $username, $language['add_success_message']);
                $message = str_replace('{%password%}', $password, $message);
                $message = str_replace('{%url%}', SCHEME . '://' . GENERAL_ADMIN_DOMAIN, $message);
                jsonReturn(EXIT_SUCCESS, $language['return_success'], array('success_message' => $message));
                $this->record('代理管理', "添加代理（%s）成功", [$username]);
            } elseif ($result['errcode'] == EXIT_ACCOUNT_REPEAT) {
                jsonReturn(EXIT_ERROR, $language['error_msg_account_repeat']);
                $this->record('代理管理', "添加代理（%s）失败", [$username]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('代理管理', "添加代理（%s）失败", [$username]);
            }
        }
    }

    // 上下分记录
    public function coinRecord()
    {
        $data['language'] = $this->lang->language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $this->input->get('username');
        $data['nickname'] = $this->input->get('nickname');
        $data['total_change_coin'] = formatMoney(0);
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('account/coin_record', $data);
    }

    // 上下分记录列表
    public function coinRecordLists()
    {
        if ($this->is_ajax()) {
            $username = $this->input->get('username');
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $field = $field ? $field : 'coin_time';
            $order = $this->input->get('order');
            $order = $order ? $order : 'desc';
            $params = array(
                'username' => $username,
                'page' => $page,
                'orderby' => $field . '|' . $order
            );
            if ($startTime && $endTime) {
                if (strtotime($endTime) == strtotime(date('Y-m-d', strtotime($endTime)))) {
                    $params['times'] = strtotime($startTime) . '.' . (strtotime($endTime) + 86400);
                } else {
                    $params['times'] = strtotime($startTime) . '.' . strtotime($endTime);
                }
            }
            $result = $this->requestApi('/finance/agent_coins', 'GET', $params, true);

            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin_time'] = date('Y-m-d H:i:s', $one['coin_time']);
                $one['coin_change'] = formatMoney($one['coin_change']);
                $one['coin_befor'] = formatMoney($one['coin_befor']);
                $one['coin_after'] = formatMoney($one['coin_after']);
                $one['ipaddr'] = isset($one['ipaddr']) ? $one['ipaddr'] : '';
                $one['from_username'] = isset($one['from_username']) ? $one['from_username'] : '';
                $one['to_username'] = isset($one['to_username']) ? $one['to_username'] : '';
            }
            $count = $result['data']['total'];
            $coinTotal = formatMoney(isset($result['data']['cointotal']) ? $result['data']['cointotal'] : 0);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'cointotal' => $coinTotal));
        }
    }

    public function coin()
    {
        $data['language'] = $this->lang->language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $this->input->get('username');
        $data['nickname'] = $this->input->get('nickname');
        $this->render('account/change_coin', $data);
    }

    public function changeCoin()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $coin = $this->input->post('coin');
            $type = $this->input->post('type');
            $username = $this->input->post('username');

            $params = array(
                'username' => $username,
                'coin' => $coin,
                'ipaddr' => getIp()
            );
            if ($type == 'add') {
                $result = $this->requestApi('/finance/agent_coin_up', 'POST', $params);
            } elseif ($type == 'sub') {
                $result = $this->requestApi('/finance/agent_coin_down', 'POST', $params);
            } else {
                if ($coin > 0) {
                    $type = 'add';
                    $result = $this->requestApi('/finance/agent_coin_up', 'POST', $params);
                } elseif ($coin < 0) {
                    $type = 'sub';
                    $params['coin'] = abs($coin);
                    $result = $this->requestApi('/finance/agent_coin_down', 'POST', $params);
                }
            }
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($type == 'add') {
                    $this->record('代理管理', "代理（%s）上分（%s）成功", [$username, $coin]);
                } else {
                    $this->record('代理管理', "代理（%s）下分（%s）成功", [$username, $coin]);
                }
            } elseif ($result['errcode'] == EXIT_COIN_LACK) {
                if ($type =='add') {
                    jsonReturn(EXIT_ERROR, $language['return_up_coin_lack']);
                    $this->record('代理管理', "代理（%s）上分（%s）失败。额度不足", [$username, $coin]);
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_down_coin_lack']);
                    $this->record('代理管理', "代理（%s）下分（%s）失败。额度不足", [$username, $coin]);
                }
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            } 
        }
    }

    public function changeStatus()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $username = $this->input->post('username');
            $type = $this->input->post('type');

            if ($username == '') {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                exit();
            }

            $params = array(
                'username' => $username,
            );
            $result = $this->requestApi('/account/ban', 'PUT', $params);
            if ($result['errcode'] === 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($type === 'forbidden') {
                    $this->record('代理管理', "禁用代理（%s）成功", [$username]);
                } else {
                    $this->record('代理管理', "启用代理（%s）成功", [$username]);
                }
            } elseif ($result['errcode'] != 0) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                if ($type === 'forbidden') {
                    $this->record('代理管理', "禁用代理（%s）失败", [$username]);
                } else {
                    $this->record('代理管理', "启用代理（%s）失败", [$username]);
                }
            }
        } else {
            $username = $this->input->get('username');
            $nickname = $this->input->get('nickname');
            $data['language'] = $language;
            $data['lang'] = $this->selectedLang;
            $data['username'] = $username;
            $data['nickname'] = $nickname;
            $params = array(
                'username' => $username
            );
            $result = $this->requestApi('/account/general_detail', 'GET', $params);
            $data['status'] = intval($result['data']['account_banby_id']);
            $data['coin'] = intval($result['data']['account_coin']);
            $this->render('account/change_status', $data);
        }
    }

    public function searchCoin()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $username = $this->input->get('username');
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $field = $field ? $field : 'username';
            $order = $order ? $order : 'asc';

            $params = array(
                'page' => $page,
                'username' => $username,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'orderby' => $field . ' ' . $order
            );
            $result = $this->requestApi('/stat/agents', 'GET', $params, true);
            $lists = array();
            foreach ($result['data']['list'] as $row) {
                $tmp = array();
                $tmp['date'] = $startTime . ' ~ ' . $endTime;
                $tmp['username'] = $row['username'];
                $tmp['nickname'] = $row['nickname'];
                $tmp['win'] = formatMoney($row['win'] ? $row['win'] : 0);
                $tmp['bigbang'] = formatMoney($row['bigbang'] ? $row['bigbang'] : 0);
                $tmp['start_time'] = $startTime;
                $tmp['end_time'] = $endTime;
                $lists[] = $tmp;
            }
            $count = $result['data']['total'];
            $totalWin = formatMoney(isset($result['data']['total_win']) ? $result['data']['total_win'] : 0);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'total_win' => $totalWin, 'data' => $lists));
        }
        $username  = $this->input->get('username');
        $nickname  = $this->input->get('nickname');
        $starttime = $this->input->get('start_time', date('Y-m-d'));
        $endtime   = $this->input->get('end_time', date('Y-m-d'));

        $data['start_time'] = $starttime;
        $data['end_time']   = $endtime;
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $username;
        $data['nickname'] = $nickname;
        $data['total_change_coin'] = '0.00';
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('account/search_coin', $data);
    }

    public function searchCoinDetail()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $username = $this->input->get('username');
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $field = $field ? $field : 'date';
            $order = $order ? $order : 'desc';

            $params = array(
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'username' => $username,
                'orderby' => $field . ' ' . $order
            );
            $result = $this->requestApi('/stat/agents_detail', 'GET', $params, true);
            $lists = array();
            foreach ($result['data']['list'] as $row) {
                $tmp = array();
                $tmp['date'] = $row['date'];
                $tmp['username'] = $username;
                $tmp['win'] = formatMoney($row['win'] ? $row['win'] : 0);
                $tmp['bigbang'] = formatMoney($row['bigbang'] ? $row['bigbang'] : 0);
                $lists[] = $tmp;
            }
            $count = $result['data']['total'];
            $totalWin = formatMoney(isset($result['data']['total_win']) ? $result['data']['total_win'] : 0);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'total_win' => $totalWin, 'data' => $lists));
        }

        $username = $this->input->get('username');
        $nickname = $this->input->get('nickname');
        $startTime = $this->input->get('start_time');
        $endTime = $this->input->get('end_time');
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $username;
        $data['nickname'] = $nickname;
        $data['start_time'] = $startTime;
        $data['end_time'] = $endTime;
        $data['total_change_coin'] = formatMoney(0);
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('account/search_coin_detail', $data);
    }

    // 总代报表
    public function generalAgentReport()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $username = $this->input->get('username');
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $field = $field ? $field : 'username';
            $order = $order ? $order : 'desc';

            $params = array(
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'field' => $field,
                'order' => $order
            );
            $username && $params['username'] = $username;
            $result = $this->requestApi('/stat/general_agent_report', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['agent_add_coin'] = formatMoney($one['agent_add_coin']);
                $one['agent_sub_coin'] = formatMoney($one['agent_sub_coin']);
                $one['player_add_coin'] = formatMoney($one['player_add_coin']);
                $one['player_sub_coin'] = formatMoney($one['player_sub_coin']);
                $one['player_win_coin'] = formatMoney($one['player_win_coin']);
                $one['bigbang'] = formatMoney($one['bigbang']);
            }
            $count = $result['data']['total'];
            $total = array(
                'win' => formatMoney($result['data']['total_add_coin']),
                'sub' => formatMoney($result['data']['total_sub_coin']),
                'diff' => formatMoney($result['data']['total_diff_coin'])
            );
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'total' => $total));
        }

        $data['username'] = $this->input->get('username');
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['total_add_coin'] = formatMoney(0);
        $data['total_sub_coin'] = formatMoney(0);
        $data['total_diff_coin'] = formatMoney(0);
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('account/general_agent_report', $data);
    }

    // 总代报表-明细
    public function generalAgentReportDetail()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');
            $accountId = $this->input->get('account_id');

            $params = array(
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'account_id' => $accountId
            );
            $result = $this->requestApi('/stat/general_agent_report_detail', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['agent_add_coin'] = formatMoney($one['agent_add_coin']);
                $one['agent_sub_coin'] = formatMoney($one['agent_sub_coin']);
                $one['player_add_coin'] = formatMoney($one['player_add_coin']);
                $one['player_sub_coin'] = formatMoney($one['player_sub_coin']);
                $one['player_win_coin'] = formatMoney($one['player_win_coin']);
                $one['bigbang'] = formatMoney($one['bigbang']);
            }
            $count = $result['data']['total'];
            $total = array(
                // 'win' => formatMoney($result['data']['total_add_coin']),
                // 'sub' => formatMoney($result['data']['total_sub_coin']),
                // 'diff' => formatMoney($result['data']['total_diff_coin'])
            );
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'total' => $total));
        }
        $data = [];
        $data['language'] = $language;
        $data['start_time'] = $this->input->get('start_time');
        $data['end_time'] = $this->input->get('end_time');
        $data['account_id'] = $this->input->get('id');
        $data['username'] = $this->input->get('username');
        $data['nickname'] = $this->input->get('nickname');
        $this->render('account/general_agent_report_detail', $data);
    }

    // 分级查询
    public function levelSearch()
    {
        $language = $this->lang->language;

        $accountId = $this->input->get('account_id');
        $type = $this->input->get('type');
        $type = $type ? $type : 1;
        $endTime = time();
        switch ($type) {
            case 1: // 1小时
                $startTime = $endTime - 3600;
                break;
            case 2: // 24小时
                $startTime = $endTime - 86400;
                break;
            case 3: // 7天
                $startTime = $endTime - 86400*7;
                break;
            case 4: // 30天
                $startTime = $endTime - 86400*30;
                break;
            default: // 1小时
                $startTime = $endTime - 3600;
                break;
        }

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $field = $this->input->get('field');
            $order = $this->input->get('order');
            $field = $field ? $field : 'username';
            $order = $order ? $order : 'desc';

            $params = array(
                'account_id' => $accountId,
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'orderby' => $field . ' ' . $order
            );

            $result = $this->requestApi('/stat/level_search_detail', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['coin'] = formatMoney($one['coin']);
                $one['bets'] = formatMoney($one['bets']);
                $one['win'] = formatMoney($one['win']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $params = array(
            'account_id' => $accountId,
            'start_time' => $startTime,
            'end_time' => $endTime
        );

        $result = $this->requestApi('/stat/level_search', 'GET', $params);
        $data['type'] = $type;
        if ($result['data']) {
            $result['data']['coin'] = formatMoney($result['data']['coin']);
            $result['data']['bets'] = formatMoney($result['data']['bets']);
            $result['data']['win'] = formatMoney($result['data']['win']);
        }
        $data['cur_data'] = $result['data'];
        $data['language'] = $language;
        $this->render('account/level_search', $data);
    }

    // 代理总账
    public function agentTotalReport()
    {
        $language = $this->lang->language;
        $username = $this->input->get('username', "");
        $startTime = $this->input->get('start_time', "");
        $endTime = $this->input->get('end_time', "");

        if ($this->is_ajax()) {
            $id = $this->input->get('id');
            $page = $this->input->get('page', 1);
            $startTime = $this->input->get('start_time');
            $endTime = $this->input->get('end_time');

            $startTime = strtotime($startTime);
            $endTime = strtotime($endTime) + 86399;

            $params = array(
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'username' => $username,
            );
            $id && $params['id'] = $id;
            $result = $this->requestApi('/stat/agent_total_report', 'GET', $params, true);
            $lists = [];
            if(isset($result['data']['list'])) {
                $lists = $result['data']['list'];
                foreach ($lists as &$one) {
                    $one['coin'] = formatMoney($one['coin']);
                    $one['evocoin'] = formatMoney($one['evocoin']);
                }
            }
            $count = $result['data']['total'];
            $totalWin = formatMoney($result['data']['total_win']);
            $totalEvoWin = formatMoney($result['data']['total_evo_win']);
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists, 'total_win' => $totalWin,'total_evo_win' => $totalEvoWin,'start_time' => date('Y-m-d', $startTime),'end_time' => date('Y-m-d', $endTime)));
        }
        $id = $this->input->get('id');
        $data['id'] = $id;
        $data['language']   = $language;
        $data['username']   = $username;
        $data['start_time'] = $startTime;
        $data['end_time']   = $endTime;
        $data['lang'] = $this->selectedLang;
        $data['date_time'] = array(
            'today' => date('Y-m-d'),
            'yesterday' => date('Y-m-d', strtotime('-1 days')),
            'week' => date('Y-m-d', strtotime('-6 days')),
            'month' => date('Y-m-01')
        );
        $this->render('account/agent_total_report', $data);
    }

    public function getAccountInfo()
    {
        if ($this->is_ajax()) {
            $username = $this->input->post('username');

            if (!$username) {
                jsonReturn(EXIT_ERROR, '');
                exit();
            }

            $params = array(
                'account' => str_replace('-', '', $username)
            );
            $data = [];
            $result = $this->requestApi('/account/player_detail', 'GET', $params);
            $data['cur_coin'] = isset($result['data']['account_coin']) ? formatMoney($result['data']['account_coin']) : 0;
            $result = $this->requestApi('/account/current', 'GET', array());
            $data['set_coin'] = formatMoney($result['data']['account_coin']);
            jsonReturn(EXIT_SUCCESS, '', $data);
        }
    }

    public function getAccountGeneralInfo()
    {
        if ($this->is_ajax()) {
            $username = $this->input->post('username');

            if (!$username) {
                jsonReturn(EXIT_ERROR, '');
                exit();
            }

            $data = [];
            $params = array(
                'username' => $username
            );
            $result = $this->requestApi('/account/general_detail', 'GET', $params);
            $data['cur_coin'] = formatMoney($result['data']['account_coin']);
            $result = $this->requestApi('/account/current', 'GET', array());
            $data['set_coin'] = formatMoney($result['data']['account_coin']);
            if ($this->account['agent'] == 3) {
                $data['set_coin'] = '1000000000000000000';
            }
            jsonReturn(EXIT_SUCCESS, '', $data);
        }
    }

    // 搜索账号
    public function search()
    {
        $this->lang->load('user_lang');
        $language = $this->lang->language;
        $username = $this->input->get('username');

        if ($this->is_ajax()) {
            $username = $this->input->post('username');

            $params = array(
                'username' => $username
            );
            $data = [];
            $result = $this->requestApi('/account/search', 'GET', $params);
            if(isset($result['data']['account'])) {
                $account = $result['data']['account'];
                if ($account) {
                    $account['coin'] = formatMoney($account['coin']);
                    if ($account['agent'] == 0 && $account['online'] == 0 && $account['login_time'] > 0) { //获取玩家离线时长
                        $account['offline_time'] = ceil((time() - $account['login_time']) / 86400);
                    }
                    $account['login_time'] = $account['login_time'] ? date('Y-m-d H:i:s', $account['login_time']) : 0;
                }

                $data['account']   = $account;
                $data['agentlist'] = $result['data']['agentlist'];
            }
            jsonListReturn(array('code' => 0, 'msg' => '', 'data' => $data));
        }

        if (isset($this->account['vid']) && $this->account['vid']) { //子账号
            $result = $this->requestApi('/account/current', 'GET', array());
            $gid = explode(',', $result['data']['virtual_group_id']);
            $data['permission'] = $gid;
        }
        $data['language'] = $language;
        $data['username'] = $username;
        $this->render('account/search', $data);
    }

    public function auth()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        $data['auth'] = [
            1 => $language['auth_01'],
        ];

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);

            $params = array(
                'page' => $page
            );
            $result = $this->requestApi('/auth/generals', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $this->render('account/auth', $data);
    }

    public function authSave()
    {
        if ($this->is_post()) {
            $username = $this->input->post('username');
            $auth = $this->input->post('auth');
            $language = $this->lang->language;
            if (empty($username) || empty($auth)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = array(
                'username' => $username,
                'auth' => implode(',', $auth)
            );
            $result = $this->requestApi('/auth/general', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('账号管理', "功能授权成功");
            } elseif ($result['errcode'] == 4001) {
                jsonReturn(EXIT_ERROR, $language['username_not_exist']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function authDelete()
    {
        if ($this->is_post()) {
            $account_id = $this->input->post('account_id');
            $language = $this->lang->language;
            if (empty($account_id)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = array(
                'id' => $account_id
            );
            $result = $this->requestApi('/auth/general', 'DELETE', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('账号管理', "功能删除成功");
            } elseif ($result['errcode'] == 4001) {
                jsonReturn(EXIT_ERROR, $language['username_not_exist']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function getRegions()
    {
        if ($this->is_ajax()) {
            $result = $this->requestApi('/system/regions', 'GET', array());
            $list = $result['data'];
            if ($this->selectedLang == 'english') {
                foreach ($list as &$one) {
                    $one['name'] = $one['name_en'];
                }
            } else {
                foreach ($list as &$one) {
                    $one['name'] = $one['name_cn'];
                }
            }
            jsonReturn(EXIT_SUCCESS, '', ['list' => $list]);
        }
    }
}
