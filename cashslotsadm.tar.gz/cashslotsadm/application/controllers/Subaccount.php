<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subaccount extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('account_lang');
    }

    // 子账号管理
    public function index()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        if (CSS_VERSION === 'poly') {
            if ($this->account['agent'] == 3) {
                $data['gids'] = [
                    7 => $language['subaccount_permission_7_title']
                ];
            } else {
                $data['gids'] = [
                    1 => $language['subaccount_permission_1_title'],
                    2 => $language['subaccount_permission_2_title'],
                    3 => $language['subaccount_permission_3_title'],
                    4 => $language['subaccount_permission_4_title'],
                    5 => $language['subaccount_permission_5_title'],
                    6 => $language['subaccount_permission_6_title']
                ];
                if ($this->account['agent'] == 2) {
                    $data['gids'][8] = $language['subaccount_permission_8_title'];
                    $data['gids'][9] = $language['subaccount_permission_9_title'];
                    $data['gids'][10] = $language['subaccount_permission_10_title'];
                }
            }
        } else {
            if ($this->account['agent'] == 2) {
                $data['gids'] = array(
                    5 => $language['subaccount_permission_5_title'] . '：' . $language['subaccount_permission_5_desc'],
                    6 => $language['subaccount_permission_6_title'] . '：' . $language['subaccount_permission_6_desc'],
                    7 => $language['subaccount_permission_7_title'] . '：' . $language['subaccount_permission_7_desc'],
                );
            } else if ($this->account['agent'] == 1) {
                $data['gids'] = array(
                    8 => $language['subaccount_permission_8_title'] . '：' . $language['subaccount_permission_8_desc'],
                    9 => $language['subaccount_permission_9_title'] . '：' . $language['subaccount_permission_9_desc'],
                    10 => $language['subaccount_permission_10_title'] . '：' . $language['subaccount_permission_10_desc'],
                    11 => $language['subaccount_permission_11_title'] . '：' . $language['subaccount_permission_11_desc'],
                );
            }
        }
        $this->render('subaccount/index', $data);
    }

    // 子账号列表
    public function lists()
    {
        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);

            $params = array(
                'page' => $page
            );
            $result = $this->requestApi('/account/vchilds', 'GET', $params, true);
            $lists = array();
            $language = $this->lang->language;
            foreach ($result['data']['list'] as $row) {
                $tmp = array();
                $tmp['account_id'] = $row['account_id'];
                $tmp['account_username'] = $row['virtual_username'];
                $tmp['account_nickname'] = $row['virtual_nickname'];
                $tmp['account_status'] = $row['virtual_ban'];
                $tmp['virtual_group_id'] = $row['virtual_group_id'];
                $tmp['virtual_create_time'] = date('Y-m-d H:i:s', $row['virtual_create_time']);
                $permission = explode(',', $row['virtual_group_id']);
                foreach ($permission as &$one) {
                    if (isset($language["subaccount_permission_{$one}_title"])) {
                        $one = $language["subaccount_permission_{$one}_title"];
                    } else {
                        unset($one);
                    }
                }
                $tmp['account_permission'] = implode('、', $permission);
                $lists[] = $tmp;
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }
    }

    // 新增代理
    public function add()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        if ($this->account['agent'] == 2) {
            $data['gids'] = array(
                5 => $language['subaccount_permission_5_title'] . '：' . $language['subaccount_permission_5_desc'],
                6 => $language['subaccount_permission_6_title'] . '：' . $language['subaccount_permission_6_desc'],
                7 => $language['subaccount_permission_7_title'] . '：' . $language['subaccount_permission_7_desc'],
            );
        } else if ($this->account['agent'] == 1) {
            $data['gids'] = array(
                8 => $language['subaccount_permission_8_title'] . '：' . $language['subaccount_permission_8_desc'],
                9 => $language['subaccount_permission_9_title'] . '：' . $language['subaccount_permission_9_desc'],
                10 => $language['subaccount_permission_10_title'] . '：' . $language['subaccount_permission_10_desc'],
                11 => $language['subaccount_permission_11_title'] . '：' . $language['subaccount_permission_11_desc'],
            );
        }

        $this->render('subaccount/add', $data);
    }

    // 编辑子账号
    public function edit()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $nickname = $this->input->post('nickname');
            $gids = $this->input->post('gids');
            if (empty($password) && empty($nickname) && empty($gids)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = array(
                'username' => $username,
            );
            $password && $params['password'] = md5($password);
            $nickname && $params['nickname'] = $nickname;
            $gids && $params['pergids'] = implode('|', $gids);
            $result = $this->requestApi('/account/vchild', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('子账号管理', "编辑子账号（%s）成功", [$username]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('子账号管理', "编辑子账号（%s）失败", [$username]);
            }
        } else {
            $username = $this->input->get('username');
            $params = array(
                'username' => $username
            );
            $result = $this->requestApi('/account/vchild_detail', 'GET', $params);
            $data['account_user'] = $result['data'];
            $data['language'] = $language;
            if (CSS_VERSION === 'poly') {
                if ($this->account['agent'] == 3) {
                    $data['gids'] = [
                        7 => $language['subaccount_permission_7_title']
                    ];
                } else {
                    $data['gids'] = [
                        1 => $language['subaccount_permission_1_title'],
                        2 => $language['subaccount_permission_2_title'],
                        3 => $language['subaccount_permission_3_title'],
                        4 => $language['subaccount_permission_4_title'],
                        5 => $language['subaccount_permission_5_title'],
                        6 => $language['subaccount_permission_6_title']
                    ];
                    if ($this->account['agent'] == 2) {
                        $data['gids'][8] = $language['subaccount_permission_8_title'];
                        $data['gids'][9] = $language['subaccount_permission_9_title'];
                        $data['gids'][10] = $language['subaccount_permission_10_title'];
                    }
                }
            } else {
                if ($this->account['agent'] == 2) {
                    $data['gids'] = array(
                        5 => $language['subaccount_permission_5_title'] . '：' . $language['subaccount_permission_5_desc'],
                        6 => $language['subaccount_permission_6_title'] . '：' . $language['subaccount_permission_6_desc'],
                        7 => $language['subaccount_permission_7_title'] . '：' . $language['subaccount_permission_7_desc'],
                    );
                } else if ($this->account['agent'] == 1) {
                    $data['gids'] = array(
                        8 => $language['subaccount_permission_8_title'] . '：' . $language['subaccount_permission_8_desc'],
                        9 => $language['subaccount_permission_9_title'] . '：' . $language['subaccount_permission_9_desc'],
                        10 => $language['subaccount_permission_10_title'] . '：' . $language['subaccount_permission_10_desc'],
                        11 => $language['subaccount_permission_11_title'] . '：' . $language['subaccount_permission_11_desc'],
                    );
                }
            }
            
            $this->render('subaccount/edit', $data);
        }
    }


    public function changeSettings()
    {
        $language = $this->lang->language;
        $username = $this->input->get('username');
        $params = array(
            'username' => $username
        );
        $result = $this->requestApi('/account/vchild_detail', 'GET', $params);
        $data['account_user'] = $result['data'];
        $data['language'] = $language;
        if (CSS_VERSION === 'poly') {
            if ($this->account['agent'] == 3) {
                $data['gids'] = [
                    7 => $language['subaccount_permission_7_title']
                ];
            } else {
                $data['gids'] = [
                    1 => $language['subaccount_permission_1_title'],
                    2 => $language['subaccount_permission_2_title'],
                    3 => $language['subaccount_permission_3_title'],
                    4 => $language['subaccount_permission_4_title'],
                    5 => $language['subaccount_permission_5_title'],
                    6 => $language['subaccount_permission_6_title']
                ];
                if ($this->account['agent'] == 2) {
                    $data['gids'][8] = $language['subaccount_permission_8_title'];
                    $data['gids'][9] = $language['subaccount_permission_9_title'];
                    $data['gids'][10] = $language['subaccount_permission_10_title'];
                }
            }
        } else {
            if ($this->account['agent'] == 2) {
                $data['gids'] = array(
                    5 => $language['subaccount_permission_5_title'] . '：' . $language['subaccount_permission_5_desc'],
                    6 => $language['subaccount_permission_6_title'] . '：' . $language['subaccount_permission_6_desc'],
                    7 => $language['subaccount_permission_7_title'] . '：' . $language['subaccount_permission_7_desc'],
                );
            } else if ($this->account['agent'] == 1) {
                $data['gids'] = array(
                    8 => $language['subaccount_permission_8_title'] . '：' . $language['subaccount_permission_8_desc'],
                    9 => $language['subaccount_permission_9_title'] . '：' . $language['subaccount_permission_9_desc'],
                    10 => $language['subaccount_permission_10_title'] . '：' . $language['subaccount_permission_10_desc'],
                    11 => $language['subaccount_permission_11_title'] . '：' . $language['subaccount_permission_11_desc'],
                );
            }
        }
        
        $this->render('subaccount/changeSettings', $data);
    }

    // 提交新增代理
    public function save()
    {
        if ($this->is_post()) {
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $nickname = $this->input->post('nickname');
            $gids = $this->input->post('gids');
            $language = $this->lang->language;
            if(empty($nickname)) {
                $nickname = $username;
            }
            if (empty($username) || empty($password) || empty($gids)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = array(
                'username' => $username,
                'password' => md5($password),
                'nickname' => $nickname,
                'pergids' => implode('|', $gids)
            );
            $result = $this->requestApi('/account/vchild', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('子账号管理', "添加子账号（%s）成功", [$username]);
            } elseif ($result['errcode'] == EXIT_ACCOUNT_REPEAT) {
                jsonReturn(EXIT_ERROR, $language['return_fail'] . ', ' . $language['error_msg_account_repeat']);
                $this->record('子账号管理', "添加子账号（%s）失败", [$username]);
            } elseif ($result['errcode'] == EXIT_ACCOUNT_REACHED_MAXINUM) {
                jsonReturn(EXIT_ERROR, $language['return_fail'] . ', ' . $language['error_msg_account_reached_maxnum']);
                $this->record('子账号管理', "添加子账号（%s）失败", [$username]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('子账号管理', "添加子账号（%s）失败", [$username]);
            }
        }
    }

    public function changeStatus()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            $username = $this->input->post('username');
            $type = $this->input->post('type');
            if (empty($username) || !in_array($type, array(0, 1))) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                exit();
            }
            $params = array(
                'username' => $username,
                'switch' => $type
            );
            $result = $this->requestApi('/account/vchild_switch', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                if ($type == 1) {
                    $this->record('子账号管理', "禁用子账号（%s）成功", [$username]);
                } else {
                    $this->record('子账号管理', "启用子账号（%s）成功", [$username]);
                }
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                if ($type == 1) {
                    $this->record('子账号管理', "禁用子账号（%s）失败", [$username]);
                } else {
                    $this->record('子账号管理', "启用子账号（%s）失败", [$username]);
                }
            }
        }

        $username = $this->input->get('username');
        $nickname = $this->input->get('nickname');
        $status = $this->input->get('status');

        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $data['username'] = $username;
        $data['nickname'] = $nickname;
        $data['status'] = $status;
        $this->render('subaccount/change_status', $data);
    }
}
