<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Card extends MY_Controller
{
    public function index()
    {
        if ($this->is_post()) {
            $redis = new Redis();
            $port = 6379;
            $host = '127.0.0.1';
            $timeout  = 30;
            $db = 13;
            $password = 'xingC99';

            $gameId = $this->input->post('game_id');
            $userId = $this->input->post('user_id');
            $cardType = $this->input->post('card_type');

            if (!$gameId || !$userId || !$cardType) {
                jsonReturn(EXIT_ERROR, '请输入完整参数');
                exit();
            }
            try {
                if (!$redis->connect($host, $port, $timeout)) {
                    exit();
                }

                if ($password && !$redis->auth($password)) {
                    jsonReturn(EXIT_ERROR, '请输入完整参数');
                    exit();
                }

                if ($db) {
                    $redis->select($db);
                }
            } catch (\Exception $e) {
                jsonReturn(EXIT_ERROR, 'redis连接失败' . $e->getMessage());
            }


            $key = "testcase:{$gameId}:{$userId}";
            $value = $cardType;
            if ($redis->setex($key, 600, $value)) {
                jsonReturn(EXIT_SUCCESS, '发送成功');
                exit();
            } else {
                jsonReturn(EXIT_SUCCESS, '发送失败');
                exit();
            }
        }

        $this->config->set_item('language', 'zh_cn_poly');
        $this->lang->load('comm_lang');
        $this->lang->load('passport_lang');
        $data['language'] = $this->lang->language;
        $this->render('passport/card', $data);
    }

    public function gameList()
    {
        // 获取游戏列表
        if ($this->is_ajax()) {
            $type = $this->input->post('type');
            $type = 1;
            //$result = $this->requestApi('/system/games', 'GET', array('lang' => ($this->selectedLang === 'english' ? 2 : 1)));
            $gameLists = $this->getGameList(1);//isset($result['data']['list']) ? $result['data']['list'] : array();
            if ($type > 0) {
                $data['game_list'] = [];
                foreach ($gameLists as $row) {
                    $data['game_list'][] = $row;
//                    if (in_array($type, explode(',', $row['type']))) {
//                        $data['game_list'][] = $row;
//                    }
                }
            } else {
                $data['game_list'] = $gameLists;
            }

            jsonReturn(EXIT_SUCCESS, '', $data);
            exit();
        }
    }
}