<?php

class Platform extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
    }

    public function index()
    {
        $language = $this->lang->language;
        $data['language'] = $language;

        if ($this->is_ajax()) {
            $page = $this->input->get('page', 1);
            $keywords = $this->input->get('keywords');
            $params = array(
                'keyword' => $keywords,
                'page' => $page
            );
            $result = $this->requestApi('/platform/generals', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $one['create_time'] = date('Y-m-d H:i:s', $one['create_time']);
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }

        $this->render('platform/index', $data);
    }

    public function add()
    {
        $data['language'] = $this->lang->language;

        if ($this->is_post()) {
            $name = $this->input->post('name');
            $api_whitelist = $this->input->post('api_whitelist');
            $agent_username = $this->input->post('agent_username');
            $agent_password = $this->input->post('agent_password');
            $remark = $this->input->post('remark');
            $language = $this->lang->language;
            if (empty($name) || empty($api_whitelist) || empty($agent_username) || empty($agent_password)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = array(
                'name' => $name,
                'api_whitelist' => $api_whitelist,
                'agent_username' => $agent_username,
                'agent_password' => md5($agent_password)
            );
            $remark && $params['remark'] = $remark;
            $result = $this->requestApi('/platform/general', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success'], ['info' => $result]);
                $this->record('平台管理', "添加平台（%s）成功", [$name]);
            } elseif ($result['errcode'] == EXIT_ACCOUNT_REPEAT) {
                jsonReturn(EXIT_ERROR, $language['error_msg_account_repeat']);
                $this->record('平台管理', "添加平台（%s）失败", [$name]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('平台管理', "添加平台（%s）失败", [$name]);
            }
        }

        $this->render('platform/add', $data);
    }

    public function getApiPassword()
    {
        $language = $this->lang->language;

        if ($this->is_post()) {
            $id = $this->input->post('id');
            $params = array(
                'id' => $id
            );
            $result = $this->requestApi('/platform/api_password', 'GET', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success'], ['info' => $result['data']]);
                $this->record('平台管理', "查询平台（%s）密码成功", [$id]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('平台管理', "查询平台（%s）密码失败", [$id]);
            }
        }
    }

    public function setIpWhitelist()
    {
        $language = $this->lang->language;

        if ($this->is_post()) {
            $id = $this->input->post('id');
            $api_whitelist = $this->input->post('api_whitelist');
            if (empty($api_whitelist)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = [
                'id' => $id
            ];
            $api_whitelist && $params['api_whitelist'] = $api_whitelist;
            $result = $this->requestApi('/platform/general', 'PUT', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success'], ['info' => $result]);
                $this->record('平台管理', "编辑平台（%s）成功", [$id]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('平台管理', "编辑平台（%s）失败", [$id]);
            }
        }
    }

    public function recharge()
    {
        if ($this->is_post()) {
            $appid = $this->input->post('id');
            $coin = $this->input->post('coin');
            $language = $this->lang->language;
            if (empty($appid) || empty($coin)) {
                jsonReturn(EXIT_ERROR, $language['add_empty']);
                exit();
            }
            $params = array(
                'appid' => $appid,
                'coin' => $coin,
                'ipaddr' => getIp()
            );
            $result = $this->requestApi('/platform/recharge', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                $this->record('平台管理', "（%s）充值（%s）成功", [$appid, $coin]);
            } elseif ($result['errcode'] == EXIT_COIN_LACK) {
                jsonReturn(EXIT_ERROR, $language['return_down_coin_lack']);
                $this->record('平台管理', "（%s）充值（%s）失败", [$appid, $coin]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                $this->record('平台管理', "（%s）充值（%s）失败", [$appid, $coin]);
            }
        }

        $data['language'] = $this->lang->language;
        $id = $this->input->get('id');
        $result = $this->requestApi('/platform/general', 'GET', ['id' => $id]);
        $data['info'] = $result['data'];
        $this->render('platform/recharge', $data);
    }

    public function getCurCoin()
    {
        if ($this->is_post()) {
            $id = $this->input->post('id');
            $result = $this->requestApi('/platform/general', 'GET', ['id' => $id]);
            $data['coin'] = formatMoney($result['data']['coin']);
            jsonReturn(EXIT_SUCCESS, '', $data);
        }
    }
}