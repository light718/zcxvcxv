<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('welcome_lang');
        $this->load->library('encrypt/encrypt_string');
    }

    public function index()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        $result = $this->requestApi('/account/current', 'GET', array());
        if (CSS_VERSION === 'bigbang') {
            $menu = config_item('menu');
            $myMenu = array();

            $gid = 0;
            if (isset($this->account['vid']) && $this->account['vid']) { //子账号
                $data['right_name'] = $result['data']['account_username'];
                $gid = explode(',', $result['data']['virtual_group_id']);
                foreach ($menu as $row) {
                    $row['name'] = $language['menu_' . $row['name']];
                    if (array_intersect($gid, $row['child'])) {
                        $myMenu[] = $row;
                    }
                }
            } else {
                foreach ($menu as $row) {
                    $row['name'] = $language['menu_' . $row['name']];
                    if (isset($row['submenu'])) {
                        foreach ($row['submenu'] as $key => $submenu) {
                            if (in_array($this->account['agent'], $submenu['visible'])) {
                                $row['submenu'][$key] = $submenu;
                                $row['submenu'][$key]['name'] = $language['menu_' . $submenu['name']];
                            } else {
                                unset($row['submenu'][$key]);
                            }
                        }
                    }
                    if (in_array($this->account['agent'], $row['visible'])) {
                        $myMenu[] = $row;
                    }
                }
                if ($this->account['agent'] == ADMIN_SYSTEM) {
                    $data['right_name'] = 'Sys Admin';
                } else if ($this->account['agent'] == ADMIN_PROXY_GENERAL) {
                    $data['right_name'] = 'General agent';
                } else if ($this->account['agent'] == ADMIN_PROXY_NORMAL) {
                    $data['right_name'] = $this->account['username'];
                }
            }
            $data['menu'] = $myMenu;
        }

        $data['coin'] = formatMoney($result['data']['account_coin']);
        $data['language'] = $language;

        // 获取公告详情
        $result = $this->requestApi('/account/notice_system', 'GET', array());
        $data['notice'] = $result['data'];

        if ($this->account['agent'] >= ADMIN_PROXY_GENERAL) {
            // 获取统计数据
            $result = $this->requestApi('/stat/welcome', 'GET', array());
            $data['data'] = array_map('formatMoney', $result['data']);
        }
        $data['market'] = $this->getMarketData();
        $this->render('welcome', $data);
    }

    public function main()
    {
        $language = $this->lang->language;
        $data['language'] = $language;
        // 获取公告详情
        $result = $this->requestApi('/account/notice_system', 'GET', array());
        $data['notice'] = $result['data'];

        // 获取统计数据
        $result = $this->requestApi('/stat/welcome', 'GET', array());
        $data['data'] = array_map('formatMoney', $result['data']);

        $this->render('main', $data);
    }

    //统计数据
    public function getMarketData()
    {
        $data = [
            'dnu' => 0,
            'dau' => 0,
            'paynum' => 0,
            'payamount' => 0,
        ];
        $this->load->model('Shop_model', 'shop');
        $paynum = $this->shop->getTodayPaynum();
        $payamount = $this->shop->getTodayPayAmount();
        $this->load->model('User_model', 'user');
        $data['dnu'] = $this->user->getDNU();
        $data['dau'] = $this->user->getDAU();
        $data['paynum'] = $paynum;
        $data['payamount'] = $payamount;
        return $data;
    }

    public function changePwd()
    {
        $language = $this->lang->language;

        if ($this->is_ajax()) {
            // bigbang管理员需要通知所有的地区服务器
            if (CSS_VERSION === 'bigbang' && $this->account['agent'] == ADMIN_SYSTEM) {
                $oldPassword = $this->input->post('old_password');
                $newPassword = $this->input->post('new_password');
                if (empty($oldPassword) && empty($password)) {
                    jsonReturn(EXIT_ERROR, $language['return_empty']);
                    exit();
                }
                $params = array(
                    'username' => $this->account['username'],
                    'oldpassword' => md5($oldPassword),
                    'newpassword' => md5($newPassword)
                );
                $regionconf = config_item('regionconf');
                foreach ($regionconf as $url) {
                    $result = $this->requestApi($url . '/account/passwordX', 'PUT', $params);
                }

                if ($result['errcode'] == 0) {
                    // 退出系统
                    $this->session->unset_userdata('user_info');
                    jsonReturn(EXIT_SUCCESS, $language['return_success']);
                    // $this->record('密码修改', "密码修改成功");
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    // $this->record('密码修改', "密码修改失败");
                }
            } else {
                $oldPassword = $this->input->post('old_password');
                $newPassword = $this->input->post('new_password');
                $confirmPwd = $this->input->post('confirm_pwd');
                if (empty($oldPassword) && empty($password) && empty($confirmPwd)) {
                    jsonReturn(EXIT_ERROR, $language['return_empty']);
                    exit();
                }
                if ($newPassword !== $confirmPwd) {
                    jsonReturn(EXIT_ERROR, $language['return_password_not_same']);
                    exit();
                }
                $params = array(
                    'oldpassword' => md5($oldPassword),
                    'newpassword' => md5($newPassword)
                );
                $result = $this->requestApi('/account/password', 'PUT', $params);
                if ($result['errcode'] == 0) {
                    // 退出系统
                    $this->session->unset_userdata('user_info');
                    jsonReturn(EXIT_SUCCESS, $language['return_success']);
                    // $this->record('密码修改', "密码修改成功");
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                    // $this->record('密码修改', "密码修改失败");
                }
            }

        } else {
            $data['language'] = $language;
            $this->render('welcome/change_pwd', $data);
        }
    }

    // 获取当前登录用户信息
    public function loginInfo()
    {
        if ($this->is_ajax()) {
            $result = $this->requestApi('/account/current', 'GET', array());
            $language = $this->lang->language;
            $data['language'] = $language;
            $data['info'] = $result['data'];
            $data['info']['account_coin'] = formatMoney($data['info']['account_coin']);

            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        }
    }

    public function online()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $now = time();
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = [$language['sub_title_01_tips_01']];
            $startTime = strtotime(date('Y-m-d H:i:00', strtotime('-1 day')));
            $endTime = $startTime + 86400;
            $params = array(
                'time' => $startTime,
                'time2' => $endTime
            );
            $result = $this->requestApi('/stat/stat_30min_online_player', 'GET', $params);
            if (isset($result['data'])) {
                foreach ($result['data'] as $row) {
                    $data['time'][] = date('m/d H:i', strtotime($row['datetime']));
                    $data['data'][0][] = $row['count'];
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        }
    }

    public function player_coin()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $data['data'] = [];
            $data['time'] = [];
            $data['title'] = [$language['sub_title_02_tips_01']];
            $startTime = strtotime(date('Y-m-d H:i:00', strtotime('-1 day')));
            $endTime = $startTime + 86400;
            $params = array(
                'time' => $startTime,
                'time2' => $endTime
            );
            $result = $this->requestApi('/stat/stat_30min_coin_player', 'GET', $params);
            if (isset($result['data'])) {
                foreach ($result['data'] as $row) {
                    $data['time'][] = date('m-d H:i', strtotime($row['datetime']));
                    $data['data'][0][] = $row['coin'];
                }
            }
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        }
    }

    public function online_nums()
    {
        if ($this->is_ajax()) {
            $result = $this->requestApi('/stat/stat_online_player', 'GET', array());
            $nums = isset($result['data']['online']) ? $result['data']['online'] : 0;
            $redis = $this->getRedisObj();
            $fb_user_count = $redis->sCard('online_logintype_12');
            $guest_user_count = $redis->sCard('online_logintype_1');
            $google_user_count = $redis->sCard('online_logintype_10');
            $ios_count = $redis->sCard('online_platform_2');
            $android_count = $redis->sCard('online_platform_1');
            $country_data = [];
            $online_all_country_list = $redis->sMembers("online_all_country_list");
            foreach ($online_all_country_list as $country) {
                $country_data[] = [
                    'key' => $country,
                    'val' => $redis->sCard('online_country_' . $country),
                ];
            }
            $data = [];
            $data['online_nums'] = $nums;
            $data['fb_online_nums'] = $fb_user_count;
            $data['google_online_nums'] = $google_user_count;
            $data['guest_online_nums'] = $guest_user_count;
            $data['ios_online_nums'] = $ios_count;
            $data['android_online_nums'] = $android_count;
            $data['country'] = $country_data;
            jsonReturn(EXIT_SUCCESS, '', $data);
        }
    }

    /**
     * 切换地区
     * @return [type] [description]
     */
    public function select_region()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $region = $this->input->post('region');
            $regionconf = config_item('regionconf');
            if (!isset($regionconf[$region])) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                exit();
            }
            $params = $this->session->userdata('user_account_pwd');
            if (empty($params)) {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
                exit();
            }
            $result = $this->requestApi($regionconf[$region] . '/account/login', 'GET', $params);
            if ($result['errcode'] === 0) { //切换地区，重新登录
                $this->session->set_userdata('user_info', $result['data']);
                $this->session->set_userdata('select_region', $region);
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
                exit();
            }
            jsonReturn(EXIT_ERROR, $language['return_fail']);
            exit();
        }
    }

    /***
     * 实时获取用户在线数目
     *
     */
    public function get_online_count()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $now_time = time();
            $data = [];
            $adm = $this->load->database('adm', TRUE);
            $start_time = strtotime(date("Y-m-d 00:00:00"));
            $sql = "select FROM_UNIXTIME(create_time,'%Y-%m-%d %H:%i') as dates ,online_user_count,fb_user_count,ios_count,android_count,google_user_count,guest_user_count,country_data from stat_user_online_data where create_time <= {$now_time} and create_time >= {$start_time}";
            $query = $adm->query($sql);
            $list = $query->result_array();
            $x_data = array_column($list, 'dates');
            $y_data = array_column($list, 'online_user_count');
            jsonReturn(EXIT_SUCCESS, $language['return_success'], compact('x_data', 'y_data'));
        }
    }

    /***
     * 根据日期进行数据搜索
     */
    public function show_other_data()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $start = strtotime($this->input->post('start_time'));
            $end = strtotime($this->input->post('end_time')) ?: time();
            $post_channel = $this->input->post("channel");
            if ($post_channel) {
                $channel = $post_channel;
                $user_sql = "select uid from d_user where platform = {$channel}";
                $user_id_arr = implode(',', array_column($this->db->query($user_sql)->result_array(), 'uid'));
                if (!$user_id_arr) {
                    $user_expire = " and uid = ''";
                } else {
                    $user_expire = " and uid in({$user_id_arr})";

                }
                if ($channel == 2) {
                    $table = "stat_market_day_ios";
                    $user_login_type = " and channel = 'IOS'";
                    $platform = "and platform = {$channel}";
                    $login_condition = " and channel = 'Android'";
                    $online_data_field = 'max(ios_user_count) as t ';
                } else {
                    $table = "stat_market_day_android";
                    $user_login_type = " and channel = 'Android'";
                    $platform = "and platform = {$channel}";
                    $login_condition = " and channel = 'IOS'";
                    $online_data_field = 'max(google_user_count) as t ';

                }
            } else {
                $table = "stat_market_day";
                $user_expire = "and uid != ''";
                $user_login_type = '';
                $platform = '';
                $login_condition = '';
                $online_data_field = 'max(online_user_count) as t ';
            }
            $adm = $this->load->database('adm', TRUE);
            //  新增激活
            $sql_act = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from s_send_coin where create_time>= {$start} and create_time<{$end} {$user_expire} and act='initcoin' group by create_times";
            $data_info = $this->db->query($sql_act)->result_array();
            $login_and_notreg = [];
            // 这里一定有问题
            $regUserSql = "select id from account where create_time>={$start} and create_time< {$end} and FROM_UNIXTIME(create_time,'%Y-%m-%d') = FROM_UNIXTIME(gameserver_gamelog.create_time,'%Y-%m-%d')";

            // create_time>=" . $start . " and create_time <" . $end .
            // 谷歌活跃用户
            $active_user_sql = "select distinct account_id from gameserver_gamelog where create_time>=" . $start . " and create_time <" . $end . " and account_id not in ({$regUserSql}) ";
            $active_users_fb_sql = "select account_id from gameserver_gamelog where create_time>=" . $start . " and create_time <" . $end . " and account_id in ({$active_user_sql})";

            $active_users_fb_count = $adm->query($active_users_fb_sql)->result_array();
            $active_users_ids = implode(',', array_column($active_users_fb_count, 'account_id'));

            $active_users_fb_sql = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user_login_log where login_type = 12 and create_time>=" . $start . " and create_time <" . $end . " {$login_condition} and uid in ({$active_users_ids}) group by create_times";

            $active_users_fb_count = $this->db->query($active_users_fb_sql)->result_array();

            $active_users_google_sql = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user_login_log where login_type = 10 and create_time>=" . $start . " and create_time <" . $end . " {$login_condition} and uid in ({$active_users_ids}) group by create_times";

            $active_users_google_count = $this->db->query($active_users_google_sql)->result_array();

            $active_users_guest_sql = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_user_login_log where login_type = 1 and create_time>=" . $start . " and create_time <" . $end . " {$login_condition} and uid in ({$active_users_ids}) group by create_times";

            $active_users_guest_count = $this->db->query($active_users_guest_sql)->result_array();
            $user_online_data_sql = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_user_online_data where create_time>=" . $start . " and create_time < " . $end . " group by create_times";
            $user_online_data = $adm->query($user_online_data_sql)->result_array();
            $guest_online_data = [];
            $google_online_data = [];
            $ios_online_data = [];
            $fb_online_data = [];
            foreach ($user_online_data as $value) {
                $guest_online_data[] = ['create_times' => $value['create_times'], 't' => $value['guest_user_count']];
                $google_online_data[] = ['create_times' => $value['create_times'], 't' => $value['google_user_count']];
                $ios_online_data[] = ['create_times' => $value['create_times'], 't' => $value['ios_user_count']];
                $fb_online_data[] = ['create_times' => $value['create_times'], 't' => $value['fb_user_count']];
            }
            //  $regUserSql = "select id from account where create_time>={$start} and create_time< {$end} and FROM_UNIXTIME(create_time,'%Y-%m-%d') = d.create_time";
            $max_online_sql = "select $online_data_field,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from stat_user_online_data  where create_time>=" . $start . " and create_time <" . $end . " group by create_times";
            $max_online_data = $adm->query($max_online_sql)->result_array();
            $sql = "select *,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from {$table} where  create_time>=" . $start . " and create_time <" . $end . " group by create_times";
            $arpu_data = $adm->query($sql)->result_array();
            //
            $sql = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_bankrupt_log where  create_time>=" . $start . " and create_time <" . $end . " {$user_expire} group by create_times";

            $bank_rupt = $this->db->query($sql)->result_array();

            $payd_user_id = 'select count(distinct uid) as t from s_shop_order where create_time>=' . $start . ' and create_time<' . $end . " and status=2 and FROM_UNIXTIME(create_time,'%Y-%m-%d') = d_bankrupt_log.create_time {$user_expire}";

            $sql = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_time from d_bankrupt_log where  create_time>=" . $start . " and create_time <" . $end . " and uid in({$payd_user_id}) group by create_time ";

            $bank_rupt_payed = $this->db->query($sql)->result_array();
            $dau_spin_old = [];
            $dau_spin_new = [];
            foreach ($arpu_data as $val) {
                // 或取这段时间内的新增用户
                $dau_spin_old[] = [
                    'create_times' => $val['create_times'],
                    't' => $val['activeuser_spin_count']
                ];

                $dau_spin_new[] = [
                    'create_times' => $val['create_times'],
                    't' => $val['dau_spin'],
                ];
            }
            $dau_not_spin_new = [];
            $dau_not_spin_old = [];
            //$dau_not_spin
            foreach ($arpu_data as $val) {
                // 或取这段时间内的新增用户

                $dau_not_spin_new[] = [
                    'create_times' => $val['create_times'],
                    't' => $val['active_not_spin_count']
                ];
                $dau_not_spin_old[] = [
                    'create_times' => $val['create_times'],
                    't' => $val['dau_not_spin']
                ];
            }
            foreach ($arpu_data as $k => $value) {
                $login_and_notreg[] = [
                    'create_times' => $value['create_times'],
                    't' => $value['dau'] - $value['dnu'],
                ];
            }

            $dates_diff = floor(($end - $start) / 86400);
            $dates_arr = [];
            for ($i = $dates_diff; $i >= 0; $i--) {
                $dates_arr[] = date('Y-m-d', strtotime("-{$i} day", $end));
            }
            $bankrupt_log_sql = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from d_bankrupt_log where create_time>=" . $start . " and create_time <" . $end . " group by create_times";
            // 破产记录表
            $bankrupt_log = $this->db->query($bankrupt_log_sql)->result_array();
            // 当日付费的用户编号
            $bankrupt_uid_sql = "select distinct uid from d_bankrupt_log  where create_time>=" . $start . " and create_time <" . $end;
            $sql_paynum = "select count(distinct uid) as t,FROM_UNIXTIME(create_time,'%Y-%m-%d') as create_times from s_shop_order where create_time>=" . $start . " and create_time <" . $end . " and status=2 and uid not in ({$bankrupt_uid_sql}) group by create_times";
            $bankrupt_list = $this->db->query($sql_paynum)->result_array();
            $dau_not_spin_old = [];
            $dau_not_spin_new = [];
            $data = compact('data_info',
                'login_and_notreg',
                'bank_rupt_payed', 'bank_rupt',
                'guest_online_data',
                'google_online_data',
                'ios_online_data',
                'fb_online_data',
                'arpu_data',
                'max_online_data',
                'dates_arr',
                'active_users_fb_count',
                'dau_spin_old',
                'dau_spin_new',
                'bankrupt_log',
                'bankrupt_list',
                'dau_not_spin_old',
                'dau_not_spin_new',
                'active_users_google_count',
                'active_users_guest_count'
            );
            jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        }
    }

    /***
     * 子游戏数据
     */
    public function sub_games()
    {
        $sql = "select sgt.*,sg.title as title_en,sg.gametag from s_game_type as sgt right join s_game as sg on sgt.gameid = sg.id where sgt.gametype = 2 and sgt.gameid >= 419 order by sg.ord asc";
        $language = $this->lang->language;
        $game_list = $this->db->query($sql)->result_array();
        $result = $this->requestApi('/system/multgame', 'GET');
        $list = $result['data'];
        $game_list = $this->getGameList(1);
        foreach ($game_list as $key => &$value) {
            if ($value['status'] == 1) {
                $value['status_text'] = '正常';
            } elseif ($value['status'] == 2) {
                $value['status_text'] = '维护中';
            } else {
                $value['status_text'] = '暂时不上线';
            }
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $game_list);
    }

    /***
     * 商城商品陈列
     */
    public function shop_goods()
    {
        $sql = "select * from s_shop where stype = 1 order by ord asc";
        $language = $this->lang->language;
        $game_list = $this->db->query($sql)->result_array();

        foreach ($game_list as $key => &$value) {
            if ($value['status'] == 1) {
                $value['status_text'] = '正常';
            } elseif ($value['status'] == 2) {
                $value['status_text'] = '禁止';
            }
            if ($value['discountTime'] > 0) {
                $value['is_discount'] = 1;
            } else {
                $value['is_discount'] = 0;
            }
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $game_list);
    }

    public function bonus_list()
    {
        $redis = $this->getRedisObj();
        $bonus_list = json_decode($redis->get("bonuslist"), true);
        $sql = "";
        $data = [];
        $language = $this->lang->language;
        $bonus_arr = ['Daily Bonus', 'onine Bonus', 'daily task', 'mission pass', 'fb share', 'stamp'];
        foreach ($bonus_list as $value) {
            $data[] = ['id' => $value, 'title_en' => $bonus_arr[$value - 1], 'title' => ''];
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
        exit;
    }

    /***
     * 任务界面配置
     */
    public function mission_config()
    {
        $sql = "select sq.*,dq.descr as d_descr, dq.jumpTo as d_jumpTo,dq.icon,count(dq.uid) as active_count from s_quest as sq left join d_quest as dq on sq.id = dq.questid group by sq.id order by sq.id desc ";
        $data = $this->db->query($sql)->result_array();
        $language = $this->lang->language;

        foreach ($data as &$value) {
            $arr = explode('|', $value['rewards']);
            $str = '';
            $value['active_reward'] = 0;
            $value['reward_coin'] = 0;
            if ($arr) {
                foreach ($arr as $val) {
                    $coin_arr = explode(':', $val);

                    if ($coin_arr[0] == 1) {
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type'] = '金币';

                    } elseif ($coin_arr[0] == 2) {
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type'] = 'Vip点数';
                    } elseif ($coin_arr[0] == 3) {
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type'] = '双倍等级经验';
                    } elseif ($coin_arr[0] == 4) {
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type'] = '双倍等级奖励';
                    } elseif ($coin_arr[0] == 5) {
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type'] = '双倍等级奖励';
                    } elseif ($coin_arr[0] == 6) {
                        $value['active_reward'] = $coin_arr[1];
                    } else {
                        $value['reward_type'] = '未知类别';
                        $value['reward_coin'] = 0;
                        $value['active_reward'] = 0;

                    }
                }
            } else {
                $value['reward_type'] = '未知类别';
                $value['reward_coin'] = 0;
                $value['active_reward'] = 0;

            }

            $value['rewards'] = '';
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);

    }

    public function active_list()
    {
        $sql = 'select * from s_activity_reward ';
        $data = $this->db->query($sql)->result_array();
        $language = $this->lang->language;
        foreach ($data as &$value) {
            $coin_arr = explode(':', $value['rewards']);
            if ($coin_arr[0] == 1) {
                $value['reward_coin'] = $coin_arr[1];
                $value['reward_type'] = '金币';
            } elseif ($coin_arr[0] == 2) {
                $value['reward_coin'] = $coin_arr[1];
                $value['reward_type'] = 'VIP点数';
            } elseif ($coin_arr[0] == 3) {
                $value['reward_coin'] = $coin_arr[1];
                $value['reward_type'] = '双倍等级经验';
            } elseif ($coin_arr[0] == 4) {
                $value['reward_coin'] = $coin_arr[1];
                $value['reward_type'] = '双倍等级奖励';
            } elseif ($coin_arr[0] == 5) {
                $value['reward_coin'] = $coin_arr[1];
                $value['reward_type'] = '双倍等级奖励';
            } elseif ($coin_arr[0] == 6) {
                $value['active_reward'] = $coin_arr[1];
            } else {
                $value['reward_type'] = '未知类别';
                $value['reward_coin'] = 0;
                $value['active_reward'] = 0;
            }
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);

    }

    /**
     * 编辑
     */
    public function mission_edit()
    {
        $game_id = $this->input->get('id');
        $language = $this->lang->language;
        if ($this->is_ajax()) {

            $data = [];
            $data['descr'] = $this->input->post('descr');
            $data['d_descr'] = $this->input->post('d_descr');
            $data['jumpTo'] = $this->input->post('jump_to');
            $data['reward_type'] = $this->input->post('reward_type');
            $data['reward_coin'] = $this->input->post('reward_coin');
            $data['icon'] = $this->input->post('icon');
            $data['active_reward'] = $this->input->post('active_reward');
            $gameid = $this->input->post('gameid');
            $type = $this->input->post('type');
            $status = $this->input->post('status');

            $rewards = $data['reward_type'] . ':' . $data['reward_coin'];
            if ($data['active_reward']) {
                $rewards .= "|" . "6:" . $data['active_reward'];
            }
            if ($game_id) {
                $game_db = $this->db;
                $game_db->where('id', $game_id);

                $update_data = [];
                $update_data['descr'] = $data['descr'];
                $update_data['update_time'] = time();
                $update_data['rewards'] = $rewards;
                $update_data['jumpTo'] = $data['jumpTo'];
                $update_data['gameid'] = $gameid;
                $update_data['type'] = $type;
                $update_data['status'] = $status;
                $update_data['count'] = $data['reward_coin'];
                $re = $game_db->update("s_quest", $update_data);
            } else {
                $update_data = [];
                $update_data['descr'] = $data['descr'];
                $update_data['update_time'] = time();
                $update_data['rewards'] = $rewards;
                $update_data['jumpTo'] = $data['jumpTo'];
                $update_data['gameid'] = $gameid;
                $update_data['parm2'] = 0;
                $update_data['parm1'] = 1;
                $update_data['parmCnt'] = 1;
                $update_data['count'] = $data['reward_coin'];
                $update_data['type'] = $type;
                $update_data['status'] = $status;
                $update_data['icon'] = '10001_icon.png';

                $arr = $this->db->query("select id from s_quest order by id desc limit 1")->result_array();
                if (isset($arr[0])) {
                    $id = $arr[0]['id'] + 1;
                } else {
                    $id = 1;
                }
                $update_data['id'] = $id;
                $re = $this->db->insert('s_quest', $update_data);
            }
            if ($re) {
                return jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                return jsonReturn(EXIT_ERROR, $language['return_error']);
            }
        } else {
            $data = [];
            $data['language'] = $this->lang->language;
            if ($game_id) {
                $sql = "select sq.*,dq.descr as d_descr, dq.jumpTo as d_jumpTo,dq.icon,count(dq.uid) as active_count from s_quest as sq left join d_quest as dq on sq.id = dq.questid where sq.id = {$game_id} group by sq.id order by sq.id desc ";
                $datas = $this->db->query($sql)->result_array();
                foreach ($datas as &$value) {
                    $arr = explode('|', $value['rewards']);
                    $value['active_reward'] = 0;
                    $value['reward_coin'] = 0;
                    if ($arr) {
                        foreach ($arr as $val) {
                            $coin_arr = explode(':', $val);
                            if ($coin_arr[0] == 1) {
                                $value['reward_coin'] = $coin_arr[1];
                                $value['reward_type_text'] = '金币';
                                $value['reward_type'] = $coin_arr[0];
                            } elseif ($coin_arr[0] == 2) {
                                $value['reward_type'] = $coin_arr[0];
                                $value['reward_coin'] = $coin_arr[1];
                                $value['reward_type_text'] = 'Vip点数';
                            } elseif ($coin_arr[0] == 3) {
                                $value['reward_type'] = $coin_arr[0];
                                $value['reward_coin'] = $coin_arr[1];
                                $value['reward_type_text'] = '双倍等级经验';
                            } elseif ($coin_arr[0] == 4) {
                                $value['reward_type'] = $coin_arr[0];
                                $value['reward_coin'] = $coin_arr[1];
                                $value['reward_type_text'] = '双倍等级奖励';
                            } elseif ($coin_arr[0] == 5) {
                                $value['reward_type'] = $coin_arr[0];
                                $value['reward_coin'] = $coin_arr[1];
                                $value['reward_type_text'] = '双倍等级奖励';
                            } elseif ($coin_arr[0] == 6) {
                                $value['active_reward'] = $coin_arr[1];
                            } else {
                                $value['reward_type_text'] = '未知类别';
                                $value['reward_type'] = $coin_arr[0];
                                $value['reward_coin'] = 0;
                                $value['active_reward'] = 0;
                            }
                        }
                    } else {
                        $value['reward_type'] = '未知类别';
                        $value['reward_coin'] = 0;
                        $value['active_reward'] = 0;
                    }

                    $value['rewards'] = '';
                }
            } else {
                $datas = [];
            }
            if (isset($datas[0])) {
                $data['result'] = $datas[0];
            } else {
                $data['result'] = [];
            }
            $data['id'] = $game_id;
            $this->render('welcome/mission_edit', $data);
        }
    }

    /***
     *  编辑活跃度奖励
     */
    public function active_edit()
    {
        $id = $this->input->get('id');
        $data = [];
        $data['language'] = $language = $this->lang->language;
        if ($this->is_ajax()) {
            $activity = $this->input->post('activity');
            $reward_type = $this->input->post('reward_type');
            $reward_coin = $this->input->post('reward_coin');
            $rewards = $reward_type . ':' . $reward_coin;
            if ($id) {
                $db = $this->db;
                $update_data = [];
                $update_data['activity'] = $activity;
                $update_data['rewards'] = $rewards;
                $db->where('id', $id);
                $re = $db->update("s_activity_reward", $update_data);
            } else {
                $arr = $this->db->query("select id from s_activity_reward order by id desc limit 1")->result_array();
                if (isset($arr[0])) {
                    $id = $arr[0]['id'] + 1;
                } else {
                    $id = 1;
                }
                $update_data = [];
                $update_data['activity'] = $activity;
                $update_data['rewards'] = $rewards;
                $data['id'] = $id;
                $re = $this->db->insert('s_activity_reward', $update_data);
            }
            if ($re) {
                return jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                return jsonReturn(EXIT_ERROR, $language['return_error']);
            }
        } else {
            if ($id) {
                $sql = "select * from s_activity_reward where id = {$id}";
                $re = $this->db->query($sql)->result_array();
                foreach ($re as &$value) {
                    $coin_arr = explode(':', $value['rewards']);
                    if ($coin_arr[0] == 1) {
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type_text'] = '金币';
                        $value['reward_type'] = $coin_arr[0];
                    } elseif ($coin_arr[0] == 2) {
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type_text'] = 'VIP点数';
                        $value['reward_type'] = $coin_arr[0];
                    } elseif ($coin_arr[0] == 3) {
                        $value['reward_type'] = $coin_arr[0];
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type_text'] = '双倍等级经验';
                    } elseif ($coin_arr[0] == 4) {
                        $value['reward_type'] = $coin_arr[0];
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type_text'] = '双倍等级奖励';
                    } elseif ($coin_arr[0] == 5) {
                        $value['reward_type'] = $coin_arr[0];
                        $value['reward_coin'] = $coin_arr[1];
                        $value['reward_type_text'] = '双倍等级奖励';
                    } elseif ($coin_arr[0] == 6) {
                        $value['active_reward'] = $coin_arr[1];
                    } else {
                        $value['reward_type_text'] = '未知类别';
                        $value['reward_coin'] = 0;
                        $value['reward_type'] = 1;
                        $value['active_reward'] = 0;
                    }
                }
                if (isset($re[0])) {
                    $data['result'] = $re[0];
                } else {
                    $data['result'] = [];
                }
            } else {
                $data['result'] = [];
            }
        }
        $data['id'] = $id;
        $this->render('welcome/active_edit', $data);
    }

    /**
     * 七日签到
     */
    public function seven_day()
    {
        $sql = "select * from s_sign order by id desc";
        $data = $this->db->query($sql)->result_array();
        $language = $this->lang->language;
        $db = $this->db;
        $list = $db->query("select * from s_config where k = 'sign_config'")->result_array();
        if (isset($list[0])) {
            $sign_config = json_decode($list[0]['v'], true);
        } else {
            $sign_config = [];
        }
        foreach ($data as &$val) {
            if ($sign_config) {
                foreach ($sign_config as $v) {
                    if ($val['id'] == $v['day']) {
                        $val['bullet'] = $v['data']['bullet'];
                        $val['sort'] = $v['data']['sort'];
                        if ($val['bullet']) {
                            $val['bullet_text'] = '强弹';
                        } else {
                            $val['bullet_text'] = '不强弹';
                        }
                    }
                }
            } else {
                $val['bullet'] = '暂未配置';
                $val['sort'] = 1;
                $val['bullet_text'] = '暂未配置';
            }
            if (!isset($val['bullet'])) {
                $val['bullet'] = '暂未配置';
            }
            if (!isset($val['sort'])) {
                $val['sort'] = 1;
            }
            if (!isset($val['bullet_text'])) {
                $val['bullet_text'] = '暂未配置';
            }
        }
        return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
    }

    /***
     *  编辑配置
     */
    public function config_edit()
    {
        $id = $this->input->get('id');
        if ($this->is_ajax()) {
            $count = $this->input->post('count');
            $upCount = $this->input->post('upCount');

            $sort = $this->input->post('sort');
            $bullet = $this->input->post('bullet');

            $language = $this->lang->language;

            $sing_update_data = [];

            $sing_update_data['count'] = $count;

            $sing_update_data['upCount'] = $upCount;

            $db = $this->db;

            $db->where('id', $id);
            if ($id) {

                $re = $db->update('s_sign', $sing_update_data);

                $db = $this->db;

                $list = $db->query("select * from s_config where k = 'sign_config'")->result_array();

                if (isset($list[0])) {
                    $sign_config = json_decode($list[0]['v'], true);
                    // 更新配置项
                    $db = $this->db;
                    if (in_array($id, array_column($sign_config, 'day'))) {
                        foreach ($sign_config as &$v) {
                            if ($v['day'] == $id) {
                                $v['data']['sort'] = $sort;
                                $v['data']['bullet'] = $bullet;
                            }
                        }
                    } else {
                        $sign_config[] = ['day' => $id, 'data' => compact('sort', 'bullet')];
                    }
                    $db->where('k', 'sign_config');
                    $update_data = [
                        'v' => json_encode($sign_config),
                    ];
                    $re = $db->update('s_config', $update_data);

                } else {
                    // 插入配置项目
                    $sign_config = [];
                    $sign_config['k'] = 'sign_config';
                    $sign_config['v'] = json_encode([['day' => $id, 'data' => compact('sort', 'bullet')]]);
                    $sign_config['memo'] = '七日签到配置';
                    $re = $db->insert('s_config', $sign_config);
                }
            } else {
                $sing_update_data = [];

                $sing_update_data['count'] = $count;

                $sing_update_data['upCount'] = $upCount;

                $re = $db->insert('s_sign', $sing_update_data);
                $list = $db->query("select * from s_config where k = 'sign_config '")->result_array();

                $last_re = $db->query("select * from s_sign order by id desc limit 1")->result_array();
                $id = $last_re[0]['id'] + 1;

                if (isset($list[0])) {
                    $sign_config = json_decode($list[0]['v'], true);
                    // 更新配置项
                    $db = $this->db;
                    if (in_array($id, array_column($sign_config, 'day'))) {
                        foreach ($sign_config as &$v) {
                            if ($v['day'] == $id) {
                                $v['data']['sort'] = $sort;
                                $v['data']['bullet'] = $bullet;
                            }
                        }
                    } else {
                        $sign_config[] = ['day' => $id, 'data' => compact('sort', 'bullet')];
                    }
                    $db->where('k', 'sign_config');
                    $update_data = [
                        'v' => json_encode($sign_config),
                    ];
                    $re = $db->update('s_config', $update_data);

                } else {
                    // 插入配置项目
                    $sign_config = [];
                    $sign_config['k'] = 'sign_config';
                    $sign_config['v'] = json_encode([['day' => $id, 'data' => compact('sort', 'bullet')]]);
                    $sign_config['memo'] = '七日签到配置';
                    $re = $db->insert('s_config', $sign_config);
                }

            }

            if ($re) {
                return jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                return jsonReturn(EXIT_ERROR, $language['return_error']);
            }
        }

        $sql = "select * from s_sign where id = {$id} ";

        $re = $this->db->query($sql)->result_array();

        $list = $this->db->query("select * from s_config where k = 'sign_config'")->result_array();

        if (isset($list[0])) {
            $sign_config = json_decode($list[0]['v'], true);
        } else {
            $sign_config = [];
        }
        foreach ($re as &$val) {
            if ($sign_config) {
                foreach ($sign_config as $v) {
                    if ($val['id'] == $v['day']) {
                        $val['bullet'] = $v['data']['bullet'];
                        $val['sort'] = $v['data']['sort'];
                        if ($val['bullet']) {
                            $val['bullet_text'] = '强弹';
                        } else {
                            $val['bullet_text'] = '不强弹';
                        }
                    }
                }
            } else {
                $val['bullet'] = '暂未配置';
                $val['sort'] = 1;
                $val['bullet_text'] = '暂未配置';
            }

        }
        $data = [];
        $data['language'] = $this->lang->language;
        $data['id'] = $id;
        if (isset($re[0])) {
            $data['result'] = $re[0];

        } else {
            $data['result'] = [];
        }
        $this->render('welcome/config_edit', $data);
    }

    /***
     * 游戏编辑
     */
    public function game_edit()
    {
        $id = $this->input->get('id');
        if ($this->is_ajax()) {

            $status = $this->input->post('status');
            $game_name = $this->input->post('game_name');
            $game_name_en = $this->input->post('game_name_en');
            $ord = $this->input->post('ord');
            $type = $this->input->post('type');
            $taghot = $this->input->post('taghot');
            $update_data = [
                'status' => $status,
            ];
        }
        $data = [];
        $data['language'] = $this->lang->language;
        $data['id'] = $id;
        $this->render('welcome/game_edit', $data);
    }


    public function paymentDownLoad()
    {
        $users = [
            '180036' => '李毅',
            '183378' => '胡翔',
            '183541' => '田思思',
            '183645' => '陈柯良',
            '184826' => '胡文良',
            '184890' => '龙建民',
            '189544' => '彭洁',
            '189406' => '李皓皓',
            '189407' => '陈如培',
            '189410' => '杨晴',
            '189411' => '马皓',
            '189414' => '瞿茜',
            '189415' => '施蕙',
            '189416' => '彭浩然',
            '189417' => '马陈吉尔',
            '189468' => '刘军',
            '189469' => '蔡文斌',
            '189470' => '杨意',
            '189776' => '曾言',
            '189472' => '刘易斌',
            '189473' => '张波',
            '189474' => '刘敏',
            '189475' => '谢斌',
            '189476' => '刘琴',
            '189479' => '龚捷',
            '189518' => '赵云',
            '189481' => '崔国洋',
            '189587' => '周海燕',
            '189729' => '黄剑',
            '189776' => '曾言',
            '189765' => '董哥',
            '183324' => '',
        ];
        $sql = 'select uid,user_name from test_account';
        $adm = $this->load->database('adm', TRUE);

        $adm_list = $adm->query($sql)->fetchAll();
        foreach ($adm_list as $value){
            $users[$value['uid']] = $value['user_name'];
        }
        $uids = array_keys($users);
        foreach ($uids as &$va){
            $va = "'{$va}'";
        }
        $uids = implode(',',$uids);

        $startDate = strtotime($this->input->get('start_time')) ? : 0;
        $endDate = strtotime($this->input->get('end_time'))? :time();
        $order_sql = "select s_order.create_time,s_order.user_coin,du.create_platform,s_order.login_type,s_order.title,s_order.amount,s_order.status,du.uid from s_shop_order as s_order inner join d_user as du on s_order.uid = du.uid  where s_order.create_time >= {$startDate} and  s_order.create_time < {$endDate} and s_order.status =2 and  s_order.uid not in ({$uids})";
        $list = $this->db->query($order_sql)->result_array();
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory');
        $objPHPExcel = new PHPExcel();
        $objPHPExcel->getActiveSheet()->setTitle("付费数据统计_" . $startDate . "_to_" . $endDate);
        $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(100);
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(100);
        $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(100);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(100);
        $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(100);
        $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(100);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(100);

        $fields = ['订单日期', '付费类型', '金额', '下单用户类型','下单渠道','用户uid','user_coin'];
        $col = 0;
        foreach ($fields as $field) {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
        $row = 2;
        $arr = ['安卓','ios'];
        foreach ($list as $data) {
            $data['create_time'] = date('Y-m-d H:i:s', $data['create_time']);
            $data['create_platform_text'] = isset($arr[$data['create_platform']]) ? $arr[$data['create_platform']] : '未知';
            if ($data['login_type'] == 12) {
                $data['from_channel_text'] = 'Fb';
            } elseif ($data['login_type'] == 10) {
                $data['from_channel_text'] = 'Google';
            } elseif ($data['login_type'] == 1) {
                $data['from_channel_text'] = 'Guest';
            } elseif ($data['login_type'] == 11) {
                $data['from_channel_text'] = 'ios';
            } else {
                $data['from_channel_text'] = '未知';
            }
            if ($data['status'] == 0) {
                $data['status_text'] = '未支付';
            } else if ($data['status'] == 1) {
                $data['status_text'] = '支付中';
            } else if ($data['status'] == 2){
                $data['status_text'] = '支付成功';
            }else{
                $data['status_text'] = '交易关闭';
            }
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$row, $data['create_time']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$row, $data['title']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue("C". $row, $data['amount']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue("D". $row, $data['from_channel_text']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue("E".$row, $data['status_text']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue("F".$row, $data['uid']);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue("G".$row, $data['user_coin']);

            $row++;
        }
        $objPHPExcel->setActiveSheetIndex(0);
        $objWriter = IOFactory::createWriter($objPHPExcel, 'Excel2007');
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition:attachment;filename=' . "付费数据统计_" . $startDate . "_to_" . $endDate . '.xls');
        header('Cache-Control:max-age=0');
        $objWriter->save('php://output');
    }


}