<?php
/**
 * Created by PhpStorm.
 * User: 9you
 * Date: 2021/2/5
 * Time: 10:18
 */
defined('BASEPATH') OR exit('No direct script access allowed');

class Mail extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('account_lang');
    }

    // 代理管理
    public function index()
    {
        $this->lang->load('user_lang');
        $language = $this->lang->language;
        $data['language'] = $language;
        $page = $this->input->post('page',1);
//        if ($this->is_ajax()){
            $start = strtotime($this->input->post('start_time',0))?:0;
            $end = strtotime($this->input->post('end_time'))?:time();
            $pageNum = 15;
            $limit = ($page - 1) *$pageNum;
            $sql = "select * from d_sys_mail where `timestamp` >= {$start} and `timestamp` < {$end} order by `timestamp` desc ";
//            $count = $this->getCount("select count(*) as t from d_sys_mail where `timestamp` >= {$start} and `timestamp` <{$end} order by `timestamp` desc",$this->db);
            $lists = $this->db->query($sql)->result_array();
            foreach ($lists as &$val){
                if ($val['stype'] == 1){
                    $val['stype_txt'] = '常规邮件';
                }elseif ($val['stype'] == 2){
                    $val['stype_txt'] = '活动邮件';
                }else{
                    $val['stype_txt'] = '广告邮件';
                }
                $val['timestamp_txt'] = date('Y-m-d H:i:s',$val['timestamp']);
            }
//            $data['count'] = $count;
            $data['list'] = $lists;
            $data['language'] = $language;
//            $data['total'] = ceil($count/$pageNum);
//            return jsonReturn(EXIT_SUCCESS, $language['return_success'], $data);
//        }
        $this->render('mail/index', $data);
    }

    /***
     *
     */
    public function mailAdd(){
        $language = $this->lang->language;
        $data = compact('language') ;
        if ($id = $this->input->get('id')){
            $data['mail_data'] = $this->db->query("select * from d_sys_mail where id = {$id}")->result_array();
        }elseif($this->is_post()){
            $data['mail_data'] = [];
            $insert_data  = [];
            $attach = [];
            $uids = $this->input->post('uids');

            $uids_arr = explode(',', $uids);
            foreach ($uids_arr as $value){
                $attach[] = [
                    'id' =>$value,
                    'num' =>$this->input->post('bonus_amount'),
                ];
            }
            $insert_data['stype'] = $this->input->post('mail_type');
            $insert_data['title'] = $this->input->post('email_title');
            $insert_data['msg'] = $this->input->post('content');
            $insert_data['timestamp'] = time();
            $insert_data['attach'] = json_encode($attach);
            $insert_data['cover_img'] = $this->input->post('cover_img');
            $insert_data['bonus_type'] = $this->input->post('bonus_type');
            $re = $this->db->insert('d_sys_mail',$insert_data);
            $mail_data = [
                'mod' => 'mail',
                'uids' => $uids,
                'title' => $insert_data['title'],
                'msg' => $insert_data['msg'] ,
                'type' => $insert_data['bonus_type'] ,
                'attach_id' => 1 ,
                'attach_count' => $this->input->post('bonus_amount'),
            ];
            $this->sendMail($mail_data);
            if ($re){
                return jsonReturn(EXIT_SUCCESS, $language['return_success'], []);
            }else{
                return jsonReturn(EXIT_ERROR, $language['return_error'], []);
            }
        }
        return $this->render('mail/mailAdd',$data);
    }

    /***
     * 发送邮件
     * @param $mail_data
     */
    private function sendMail($mail_data){
        $config_url = $this->config->item('mail_host_url');
        return $this->requestApi($config_url,'get',$mail_data);
    }

    /***
     * 删除邮件
     */
    public function delMail(){
        $language = $this->lang->language;
        $id = $this->input->get('id');
        $re = $this->db->query('delete from d_sys_mail where id ='.$id);
        if ($re){
            return jsonReturn(EXIT_SUCCESS, $language['return_success'], []);
        }else{
            return jsonReturn(EXIT_ERROR, $language['return_error'], []);
        }
    }
}