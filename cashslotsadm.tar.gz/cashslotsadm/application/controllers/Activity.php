<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Activity extends MY_Controller
{
    // 幸运红包数值
    const LUCKY_REDBAG_CONFIG   = 'lucky_redbag_config';
    // 分享次数数值
    const SHARE_NUMS_CONFIG  = 'share_nums_config';
    // 红包雨数值
    const RAINY_REDBAG_CONFIG   = 'rainy_redbag_config';
    // 成长值数值
    const GROWTH_VALUE_CONFIG   = 'growth_value_config';
    // 幸运宝箱数值
    const LUCKY_BOX_CONFIG      = 'lucky_box_config';
    // 幸运红包开关
    const LUCKY_REDBAG_SWITCH   = 'lucky_redbag_switch';
    // 成长值比例
    const GROWTH_VALUE_RATIO    = 'growth_value_ratio';
    // 成长值开关
    const GROWTH_VALUE_SWITCH   = 'growth_value_switch';

    public function __construct()
    {
        parent::__construct();
        $this->config->set_item('language', $this->selectedLang . '_' . CSS_VERSION);
        $this->lang->load('comm_lang');
        $this->lang->load('activity_lang');
    }

    public function value_setting()
    {
        $language = $this->lang->language;
        $result = $this->requestApi('/activity/value_setting', 'GET');
        $rs = array_column($result['data'], 'svalue', 'skey');
        $data['lucky_list'] = isset($rs[self::LUCKY_REDBAG_CONFIG]) ? json_decode($rs[self::LUCKY_REDBAG_CONFIG], true) : [];
        $data['rainy_list'] = isset($rs[self::RAINY_REDBAG_CONFIG]) ? json_decode($rs[self::RAINY_REDBAG_CONFIG], true) : [];
        $data['growth_value_list'] = isset($rs[self::GROWTH_VALUE_CONFIG]) ? json_decode($rs[self::GROWTH_VALUE_CONFIG], true) : [];
        $data['lucky_box_list'] = isset($rs[self::LUCKY_BOX_CONFIG]) ? json_decode($rs[self::LUCKY_BOX_CONFIG], true) : [];
        $data['share_nums_list'] = isset($rs[self::SHARE_NUMS_CONFIG]) ? json_decode($rs[self::SHARE_NUMS_CONFIG], true) : [];
        $data['language'] = $language;
        $this->render('activity/value_setting', $data);
    }

    public function lucky_redbag()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $data = json_decode($this->input->post('data'), true);
            if (empty($data)) {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $totalProb = 0;
            foreach ($data as $row) {
                if ($row['min_value'] === '' || $row['max_value'] === '' || $row['prob'] === '') {
                    jsonReturn(EXIT_ERROR, $language['return_empty']);
                    exit();
                }
                if (!is_numeric($row['min_value']) || !is_numeric($row['max_value']) || !is_numeric($row['prob'])) {
                    jsonReturn(EXIT_ERROR, $language['lucky_redbag_tips_03']);
                    exit();
                }
                if ($row['min_value'] > $row['max_value']) {
                    jsonReturn(EXIT_ERROR, $language['lucky_redbag_tips_01']);
                    exit();
                }
                $totalProb += $row['prob'];
            }
            if ($totalProb != 100) {
                jsonReturn(EXIT_ERROR, $language['lucky_redbag_tips_02']);
                exit();
            }
            $params = [
                'key' => self::LUCKY_REDBAG_CONFIG,
                'value' => json_encode($data)
            ];
            $result = $this->requestApi('/activity/value_setting', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function rainy_redbag()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $data = json_decode($this->input->post('data'), true);
            if (empty($data)) {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $totalProb = 0;
            foreach ($data as $row) {
                if ($row['min_value'] === '' || $row['max_value'] === '' || $row['prob'] === '' || $row['min_prob'] === '' || $row['max_prob'] === '' || $row['other_prob'] === '') {
                    jsonReturn(EXIT_ERROR, $language['return_empty']);
                    exit();
                }
                if (!is_numeric($row['min_value']) || !is_numeric($row['max_value']) || !is_numeric($row['prob']) || !is_numeric($row['min_prob']) || !is_numeric($row['max_prob']) || !is_numeric($row['other_prob'])) {
                    jsonReturn(EXIT_ERROR, $language['rainy_redbag_tips_03']);
                    exit();
                }
                if ($row['min_value'] > $row['max_value']) {
                    jsonReturn(EXIT_ERROR, $language['rainy_redbag_tips_01']);
                    exit();
                }
                $totalProb += $row['prob'];
                if (($row['min_prob'] + $row['max_prob'] + $row['other_prob']) != 100) {
                    jsonReturn(EXIT_ERROR, $language['rainy_redbag_tips_04']);
                    exit();
                }
            }
            if ($totalProb != 100) {
                jsonReturn(EXIT_ERROR, $language['rainy_redbag_tips_02']);
                exit();
            }
            $params = [
                'key' => self::RAINY_REDBAG_CONFIG,
                'value' => json_encode($data)
            ];
            $result = $this->requestApi('/activity/value_setting', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function rainy_redbag_setting()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $sendTime = json_decode($this->input->post('send_time'), true);
            $prob = $this->input->post('prob');
            $total = $this->input->post('total');
            $remark = $this->input->post('remark');
            if (empty($sendTime) || $prob === '' || $total === '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $sendTimeArray = [];
            $endTimeArray = [];
            foreach ($sendTime as $row) {
                list($startTime, $endTime) = explode(' ~ ', $row);
                $startTime = strtotime($startTime);
                $endTime = strtotime($endTime);
                if ($startTime > $endTime) {
                    jsonReturn(EXIT_ERROR, $language['rainy_redbag_setting_tips_01']);
                    exit();
                }
                $endTimeArray[] = $endTime;
                $sendTimeArray[] = $startTime . '|' . $endTime;
            }
            if ($prob < 0 || $prob > 100) {
                jsonReturn(EXIT_ERROR, $language['rainy_redbag_setting_tips_02']);
                exit();
            }
            $params = [
                'send_time' => implode('#', $sendTimeArray),
                'prob' => $prob,
                'total' => $total,
                'end_time' => max($endTimeArray)
            ];
            $remark && $params['remark'] = $remark;
            $result = $this->requestApi('/activity/rainy_redbag_setting', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } elseif ($result['errcode'] == 30001) {
                jsonReturn(EXIT_ERROR, $language['rainy_redbag_setting_tips_03']);
            } elseif ($result['errcode'] == 30002) {
                jsonReturn(EXIT_ERROR, $language['rainy_redbag_setting_tips_04']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        } else {
            $language = $this->lang->language;
            $data['language'] = $language;
            $data['lang'] = $this->selectedLang;
            $this->render('activity/rainy_redbag_setting', $data);
        }
    }

    public function rainy_redbag_setting_lists()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $page = $this->input->get('page', 1);
            $params = array(
                'page' => $page
            );
            $result = $this->requestApi('/activity/rainy_redbag_setting', 'GET', $params, true);
            $lists = $result['data']['list'];
            foreach ($lists as &$one) {
                $sendTime = explode('#', $one['send_time']);
                $sendTimeArray = [];
                foreach ($sendTime as $row) {
                    list($startTime, $endTime) = explode('|', $row);
                    $sendTimeArray[] = date('Y-m-d H:i:s', $startTime) . '~' . date('Y-m-d H:i:s', $endTime);
                }
                $one['send_time'] = implode('<br>', $sendTimeArray);
                $one['create_time'] = date('Y-m-d H:i:s');
                if ($one['status'] == 1) {
                    $one['status_name'] = $language['rainy_redbag_setting_status_02'];
                } else {
                    if ($one['end_time'] > time()) {
                        $one['status_name'] = $language['rainy_redbag_setting_status_01'];
                    } else {
                        $one['status'] = 2;
                        $one['status_name'] = $language['rainy_redbag_setting_status_03'];
                    }
                }
            }
            $count = $result['data']['total'];
            jsonListReturn(array('code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists));
        }
    }

    public function rollback_rainy_redbag()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $id = $this->input->post('id');
            $params = array(
                'id' => $id
            );
            $result = $this->requestApi('/activity/rainy_redbag_setting', 'PUT', $params, true);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function add_jackpot()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $coin = $this->input->post('coin');
            if ($coin === '') {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $params = [
                'coin' => $coin
            ];
            $result = $this->requestApi('/activity/add_jackpot', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } elseif ($result['errcode'] == 4001) {
                jsonReturn(EXIT_ERROR, $language['activity_jackpot_tips_01']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        } else {
            $language = $this->lang->language;
            $data['language'] = $language;
            $result = $this->requestApi('/stat/game_setting_cur_data', 'GET', array());
            $cur = $result['data'];
            $data['normal'] = formatMoney($cur['normal']);
            $this->render('activity/add_jackpot', $data);
        }
    }

    public function get_activity_jackpot()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $result = $this->requestApi('/activity/activity_jackpot', 'GET');
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success'], ['data' => formatMoney($result['data'])]);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function share_nums()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $data = $this->input->post('data');
            if (empty($data)) {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $params = [
                'key' => self::SHARE_NUMS_CONFIG,
                'value' => $data
            ];
            $result = $this->requestApi('/activity/value_setting', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function growth_value()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $data = $this->input->post('data');
            if (empty($data)) {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            $data = json_decode($data, true);
            foreach ($data as &$one) {
                if ($one['type'] == 2) {
                    $one['free_game_id'] = 0;
                    $one['free_game_nums'] = 0;
                }
            }
            $params = [
                'key' => self::GROWTH_VALUE_CONFIG,
                'value' => json_encode($data)
            ];
            $result = $this->requestApi('/activity/value_setting', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function lucky_box()
    {
        if ($this->is_ajax()) {
            $language = $this->lang->language;
            $data = $this->input->post('data');
            if (empty($data)) {
                jsonReturn(EXIT_ERROR, $language['return_empty']);
                exit();
            }
            if (array_sum(array_column(json_decode($data, true), 'prob')) != 100) {
                jsonReturn(EXIT_ERROR, $language['lucky_box_setting_tips_01']);
                exit();
            }
            $params = [
                'key' => self::LUCKY_BOX_CONFIG,
                'value' => $data
            ];
            $result = $this->requestApi('/activity/value_setting', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                jsonReturn(EXIT_ERROR, $language['return_fail']);
            }
        }
    }

    public function setting()
    {
        $language = $this->lang->language;
        if ($this->is_ajax()) {
            $key = $this->input->post('key');
            $value = $this->input->post('value');
            $params = [
                'key' => $key,
                'value' => $value
            ];
            $result = $this->requestApi('/activity/value_setting', 'POST', $params);
            if ($result['errcode'] == 0) {
                jsonReturn(EXIT_SUCCESS, $language['return_success']);
            } else {
                if ($result['errcode'] == '30001') {
                    jsonReturn(EXIT_ERROR, $language['setting_tip_01']);
                } else if ($result['errcode'] == '30002') {
                    jsonReturn(EXIT_ERROR, $language['setting_tip_02']);
                } else if ($result['errcode'] == '30003') {
                    jsonReturn(EXIT_ERROR, $language['setting_tip_03']);
                } else {
                    jsonReturn(EXIT_ERROR, $language['return_fail']);
                }
            }
        } else {
            $result = $this->requestApi('/activity/value_setting', 'GET');
            $rs = array_column($result['data'], 'svalue', 'skey');
            $data['lucky_redbag_switch'] = isset($rs[self::LUCKY_REDBAG_SWITCH]) ? $rs[self::LUCKY_REDBAG_SWITCH] : 0;
            $data['growth_value_ratio'] = isset($rs[self::GROWTH_VALUE_RATIO]) ? $rs[self::GROWTH_VALUE_RATIO] : 0;
            $data['growth_value_switch'] = isset($rs[self::GROWTH_VALUE_SWITCH]) ? $rs[self::GROWTH_VALUE_SWITCH] : 0;
            $data['language'] = $language;
            $this->render('activity/setting', $data);
        }
    }

    public function stat()
    {
        if ($this->is_ajax()) {
            $type = $this->input->get('type');
            $page = $this->input->get('page', 1);
            $startDate = $this->input->get('start_date');
            $endDate = $this->input->get('end_date');

            $startTime = strtotime($startDate);
            $endTime = strtotime($endDate) + 86399;
            $params = array(
                'page' => $page,
                'start_time' => $startTime,
                'end_time' => $endTime
            );
            if ($type == 1) { // 幸运红包
                $result = $this->requestApi('/activity/stat_lucky_redbag', 'GET', $params, true);
            } else if ($type == 2) { // 红包雨
                $result = $this->requestApi('/activity/stat_rainy_redbag', 'GET', $params, true);
            } else if ($type == 3) { // 幸运宝箱
                $result = $this->requestApi('/activity/stat_lucky_box', 'GET', $params, true);
            }
            $lists = $result['data']['list'];
            $count = $result['data']['total'];
            jsonListReturn(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $lists]);
        }
        $language = $this->lang->language;
        $data['end_date'] = date('Y-m-d', strtotime('-1 days'));
        $data['start_date'] = date('Y-m-d', strtotime('-7 days'));
        $data['language'] = $language;
        $data['lang'] = $this->selectedLang;
        $this->render('activity/stat', $data);
    }
}