<?php
class Game_model extends CI_Model {

    private static $table = 's_game';

    public function __construct()
    {
        parent::__construct();
//        $this->load->database();
    }

    //获取slots游戏的等级列表
    public function getGameLevelList() {

        $sql = "select a.id,b.title,a.level from s_game a left join s_game_type b on a.id = b.gameid where b.state=1 and b.gametype=2";
        $query = $this->db->query($sql);
        // $this->db->order_by('id', 'DESC');
        $results = $query->result_array();
        // $res = $this->db->query($sql)->row_array();
        // return $res['num'] ? $res['num'] : 0;;
        return $results;
    }

    //更新游戏开放的等级
    public function updateGameLevel($gameId, $level=0)
    {
        $data = array(
            'level' => $level,
        );

        $this->db->where('id', $gameId);
        $this->db->update(self::$table, $data);

        return true;
    }
}