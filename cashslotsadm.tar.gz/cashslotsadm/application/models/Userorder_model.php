<?php
class Userorder_model extends CI_Model {

    private static $table = 's_shop_order';
    private $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('default', TRUE);
    }

    //按时间获取列表
    public function getListData($startDate, $endDate) {
        $startTime = strtotime($startDate);
        $endTime = strtotime($endDate);
        $sql = "select * from " . self::$table . " where create_time>={$startTime} and create_time < {$endTime} and `status`=2 and isfirst=1 ";
        $query = $this->db->query($sql);
        $this->db->order_by('id', 'DESC');
        $results = $query->result_array();
        return $results;
    }

    //注册当天付费人数和金额统计
    public function getRegStateData($startDate, $endDate) {
        $startTime = strtotime($startDate);
        $endTime = strtotime($endDate);
        $sql = "select count(distinct a.uid) as num, sum(a.amount) as price, date(from_unixtime(a.create_time)) as createdate from s_shop_order a join (select uid, date(from_unixtime(create_time)) as createdate from d_user where create_time>={$startTime} and create_time<{$endTime}) b on a.uid = b.uid and date(from_unixtime(a.create_time)) = b.createdate where a.create_time>={$startTime} and a.create_time<{$endTime} and `status`=2 group by date(from_unixtime(a.create_time))";
        $query = $this->db->query($sql);
        $results = $query->result_array();
        return $results;
    }

    //充值成功的物品排名
    public function getOrderStateData($startDate, $endDate) {
        $startTime = strtotime($startDate);
        $endTime = strtotime($endDate);
        $sql = "select count(*) as total, sum(amount) as price, shopid from s_shop_order where create_time>={$startTime} and create_time<{$endTime} and `status`=2 group by shopid order by total desc";
        $query = $this->db->query($sql);
        $results = $query->result_array();

        $shop_sql = "select id, title from s_shop";
        $query = $this->db->query($shop_sql);
        $shop_result = $query->result_array();
        $shop_dict = [];
        foreach($shop_result as $row) {
            $shop_dict[$row['id']] = $row['title'];
        }

        $data = [];
        foreach($results as $v) {
            $data[] = [
                'total' => $v['total'],
                'price' => $v['price'],
                'shopid' => $v['shopid'],
                'title' => $shop_dict[$v['shopid']],
            ];
        }
        return $data;
    }
}