<?php
//人数数据和留存，ltv统计
class Statemarketday_model extends CI_Model {

    private static $table = 'stat_market_day';
    private $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('adm', TRUE);
    }

    //按时间获取列表
    public function getListData($startDate, $endDate) {
        $sql = "select * from " . self::$table . " where day>='{$startDate}' and day < '{$endDate}' order by id desc";
        $query = $this->db->query($sql);
        $results = $query->result_array();
        return $results;
    }
}