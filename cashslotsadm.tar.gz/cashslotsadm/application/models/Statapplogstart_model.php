<?php
//启动人数，次数统计
class Statapplogstart_model extends CI_Model {

    private static $table = 'stat_app_log_areastartapp';
    private $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('adm', TRUE);
    }

    //按时间获取列表
    public function getListData($startDate, $endDate) {
        $sql = "select * from " . self::$table . " where day>='{$startDate}' and day < '{$endDate}' order by id desc";
        $query = $this->db->query($sql);
        $results = $query->result_array();
        return $results;
    }

    public function getAllStartTimes($startDate, $endDate) {
        $sql = "select * from " . self::$table . "";
        $query = $this->db->query($sql);
        $results = $query->result_array();
        return $results;
    }
}