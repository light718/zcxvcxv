<?php
class Shop_model extends CI_Model {

    private static $table = 's_shop_order';

    public function __construct()
    {
        parent::__construct();
//        $this->load->database();
    }

    //获取今日下单人数
    public function getTodayPayNum() {
        $todayStamp = strtotime(date('Y-m-d'));

        $sql = "SELECT count(distinct uid) as num FROM " .self::$table. " WHERE create_time>= ? AND status = ?";
        $res = $this->db->query($sql, array($todayStamp, 2))->row_array();
        return $res['num'] ? $res['num'] : 0;;
    }

    //今日下单成功的金额
    public function getTodayPayAmount()
    {
        $todayStamp = strtotime(date('Y-m-d'));
        $sql = "SELECT sum(amount) as num FROM " .self::$table. " WHERE create_time>= ? AND status = ?";
        $res = $this->db->query($sql, array($todayStamp, 2))->row_array();
        $num = $res['num'] ? $res['num'] : 0;
        return $num;
    }
}