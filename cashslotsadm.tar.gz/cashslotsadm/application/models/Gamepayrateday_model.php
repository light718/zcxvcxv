<?php
/**
* 当天的游戏回报率, 从游戏发版本后的统计
*
*/
class Gamepayrateday_model extends CI_Model {

    private static $table = 'state_slots_payrate_day';
    private $db;

    public function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('adm', TRUE);
    }

    //获取总体数据列表
    public function getListData($startDate) {
        $startTime = strtotime($startDate);
        $endTime = $startTime + 86400;
        $sql = "select * from " . self::$table . " where day>={$startTime} and day < {$endTime}";
        $query = $this->db->query($sql);
        $this->db->order_by('id', 'DESC');
        $results = $query->result_array();
        return $results;
    }
}