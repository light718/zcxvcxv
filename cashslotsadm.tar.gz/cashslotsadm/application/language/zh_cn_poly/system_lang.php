<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['player_login_log_title'] = '玩家登录日志';
$lang['player_login_log_uid'] = 'UID';
$lang['player_login_log_pid'] = '玩家ID';
$lang['player_login_log_time'] = '登录时间';

$lang['state_player_title'] = '人数留存统计';
$lang['state_player_date'] = '日期';
$lang['state_player_dnu'] = 'UID';
$lang['state_player_dau'] = 'DAU';
$lang['state_player_arpu'] = 'ARPU';
$lang['state_player_arppu'] = 'ARPPU';
$lang['state_player_ordernum'] = '充值笔数';
$lang['state_player_payrate'] = '付费率';
$lang['state_player_paynum'] = '付费人数';
$lang['state_player_payamount'] = '付费金额';
$lang['state_player_payagainnum'] = '多次付费人数';
$lang['state_player_payagainamount'] = '多次付费金额';
$lang['state_player_payfirstnum'] = '第1次付费人数';
$lang['state_player_payfirstamount'] = '第1次付费金额';
$lang['state_player_stay1'] = '次留 ';
$lang['state_player_stay3'] = '3留';
$lang['state_player_stay7'] = '7留';
$lang['state_player_stay14'] = '14留';
$lang['state_player_stay30'] = '30留';
$lang['state_player_ltv1'] = '当日ltv';
$lang['state_player_ltv3'] = '3日ltv';
$lang['state_player_ltv7'] = '7日ltv';
$lang['state_player_ltv14'] = '14日ltv';
$lang['state_player_ltv30'] = '30日ltv';

$lang['state_gamedetail_title'] = '新用户游戏数据回报率';
$lang['state_date'] = '日期';
$lang['state_gamedetail_gameid'] = '游戏ID';
$lang['state_gamedetail_alltimes'] = '总次数';
$lang['state_gamedetail_allusers'] = '总人数';
$lang['state_gamedetail_allbet'] = '总下注';
$lang['state_gamedetail_allwin'] = '总赢钱';
$lang['state_gamedetail_backrate'] = '回报率';

$lang['state_reward_act'] = '奖励类型';
$lang['state_reward_allusers'] = '总人数';
$lang['state_reward_allcoin'] = '总金币';
$lang['state_reward_allcost'] = '金币价值';

$lang['state_online_allusers'] = '总人数';
$lang['state_online_stype'] = '在线时长类型';
$lang['state_online_avgcoin'] = '金币平均值';

$lang['state_level_allusers'] = '人数';
$lang['state_level_avgcoin'] = '金币价值';
$lang['state_level_times'] = '总破产次数';
$lang['state_level_recharge'] = '充值总额';
$lang['state_level_type'] = '等级区间';

$lang['state_order_shopid'] = '订单商品id';
$lang['state_order_shopname'] = '商品名称';
$lang['state_order_shopprice'] = '商品价格';
$lang['state_order_uid'] = 'UID';
$lang['state_order_userlevel'] = '用户等级';
$lang['state_order_usercoin'] = '用户金币';
$lang['state_order_time'] = '下单时间';

$lang['state_order_date'] = '日期';
$lang['state_order_allusers'] = '总人数';
$lang['state_order_allamount'] = '总金额';

$lang['state_shopitem_id'] = '商品ID';
$lang['state_shopitem_title'] = '商品名';
$lang['state_shopitem_total'] = '订单数';
$lang['state_shopitem_price'] = '总金额';

$lang['state_shoprenew_user1'] = '当日充值人数';
$lang['state_shoprenew_user2'] = '次日充值人数';
$lang['state_shoprenew_user3'] = '3日充值人数';
$lang['state_shoprenew_user4'] = '4日充值人数';
$lang['state_shoprenew_user5'] = '5日充值人数';
$lang['state_shoprenew_user6'] = '6日充值人数';
$lang['state_shoprenew_user7'] = '7日充值人数';
$lang['state_shoprenew_user8'] = '8日充值人数';
$lang['state_shoprenew_user9'] = '9日充值人数';
$lang['state_shoprenew_user10'] = '10日充值人数';
$lang['state_shoprenew_amount1'] = '当日充值金额';
$lang['state_shoprenew_amount2'] = '次日充值金额';
$lang['state_shoprenew_amount3'] = '3日充值金额';
$lang['state_shoprenew_amount4'] = '4日充值金额';
$lang['state_shoprenew_amount5'] = '5日充值金额';
$lang['state_shoprenew_amount6'] = '6日充值金额';
$lang['state_shoprenew_amount7'] = '7日充值金额';
$lang['state_shoprenew_amount8'] = '8日充值金额';
$lang['state_shoprenew_amount9'] = '9日充值金额';
$lang['state_shoprenew_amount10'] = '10日充值金额';

$lang['state_leveldist_title'] = '等级分布';
$lang['state_leveldist_num'] = '人数';
$lang['state_leveldist_rate'] = '比例';
$lang['state_coindist_title'] = '金币分布';
$lang['state_rechargedist_title'] = '充值金额分布';

$lang['state_gamedist_title'] = '游戏名称';
$lang['state_gamedist_num'] = '人数';
$lang['state_gamedist_rate'] = '百分比';

$lang['state_gamelist_uid'] = 'UID';
$lang['state_gamelist_coin'] = '金币';
$lang['state_gamelist_level'] = '等级';
$lang['state_gamelist_price'] = '商城金额';
$lang['state_gamelist_createtime'] = '注册时间';
$lang['state_gamelist_logintime'] = '最后登录时间';
$lang['state_gamelist_gametitle'] = '最后游戏';
$lang['state_gamelist_gametime'] = '最后游戏时间';

$lang['agent_list_title'] = '代理列表';
$lang['agent_list_column_username'] = '代理ID';
$lang['agent_list_column_nickname'] = '昵称';
$lang['agent_list_column_parent_agent'] = '上级代理ID';
$lang['agent_list_column_first_agent'] = '一级代理ID';
$lang['agent_list_column_coin'] = '分数余额';
$lang['agent_list_column_create_time'] = '注册时间';
$lang['agent_list_column_last_login_time'] = '最后登录时间';

$lang['agent_score_log_title'] = '代理上下分记录';
$lang['agent_score_log_column_username'] = '代理ID';
$lang['agent_score_log_column_nickname'] = '昵称';
$lang['agent_score_log_column_coin'] = '上下分';
$lang['agent_score_log_column_before'] = '上分前';
$lang['agent_score_log_column_after'] = '上分后';
$lang['agent_score_log_column_create_time'] = '时间';

$lang['player_game_log_title'] = '玩家游戏记录';
$lang['player_game_log_game_name'] = '游戏名字(Game)';
$lang['player_game_log_type'] = '下注or中奖';
$lang['player_game_log_coin'] = '金币变化';
$lang['player_game_log_coin_before'] = '变化前金币';
$lang['player_game_log_coin_after'] = '变化后金币';
$lang['player_game_log_time'] = '时间';

$lang['system_win_title'] = '系统输赢';
$lang['system_win_date'] = '日期';
$lang['system_win_sysout'] = '系统上分';
$lang['system_win_sysin'] = '系统下分';
$lang['system_win_player'] = '玩家总分数';
$lang['system_win_agent'] = '代理总分数';

$lang['player_ip_title'] = '玩家登入IP查询';
$lang['player_ip_tips'] = '显示最新 10 笔记录.';

$lang['player_win_column_id'] = '玩家ID';
$lang['player_win_column_name'] = '账号';
$lang['player_win_nickname'] = '昵称';
$lang['player_win_total'] = '总输赢';
$lang['player_win_reload'] = '总上分';
$lang['player_win_ratio'] = '输赢比例';
$lang['player_win_select_all'] = '全部玩家';
$lang['player_win_select_control'] = '控制过的玩家';
$lang['player_win_select_not_control'] = '未控制过的玩家';

$lang['player_list_title'] = '玩家列表';
$lang['player_list_column_id'] = 'UID';
$lang['player_list_column_pid'] = '玩家ID';
$lang['player_list_column_nickname'] = '昵称';
$lang['player_list_column_coin'] = '分数';
$lang['player_list_column_online'] = '在线状态';
$lang['player_list_column_status_ban'] = '账号状态';
$lang['player_list_column_create_time'] = '添加时间';
$lang['player_list_column_last_login_time'] = '最后登录时间';

$lang['operation_log_title'] = '操作日志';
$lang['operation_log_column_id'] = '#';
$lang['operation_log_column_admin_id'] = 'ID';
$lang['operation_log_column_admin_username'] = '账号';
$lang['operation_log_column_ip'] = 'IP';
$lang['operation_log_column_os'] = '操作系统';
$lang['operation_log_column_browser'] = '浏览器';
$lang['operation_log_column_menu'] = '操作菜单';
$lang['operation_log_column_detail'] = '详情';
$lang['operation_log_column_create_time'] = '操作时间';
$lang['operation_log_tips'] = '显示最新 1000 笔记录.';

$lang['red_envelope'] = '救济红包';

$lang['tax_empty_title'] = '税池清空日志';
$lang['tax_empty_column_id'] = 'ID';
$lang['tax_empty_column_oin'] = '分数';
$lang['tax_empty_column_create_time'] = '清空时间';

$lang['new_strategy'] = '新手策略';
$lang['new_strategy_01'] = '首次登录IP地址相同个数限制';
$lang['new_strategy_02'] = 'x小时内';
$lang['new_strategy_03'] = '下注总额';
$lang['new_strategy_04'] = '净赢总额';
$lang['new_strategy_05'] = '代理净赢总额';

$lang['new_strategy_count'] = '打点数据';
$lang['new_strategy_count_time'] = '时间';
$lang['new_strategy_count_total'] = '账号总数';
$lang['new_strategy_count_ing'] = '生效中的账号总数';
$lang['new_strategy_count_win'] = '玩家总输赢';

$lang['new_strategy_list'] = '用户列表';
$lang['new_strategy_list_uid'] = 'UID';
$lang['new_strategy_list_status'] = '策略状态';
$lang['new_strategy_list_status_1'] = '生效中';
$lang['new_strategy_list_status_2'] = '已失效';
$lang['new_strategy_list_win'] = '输赢（当前分数-上分）';
$lang['new_strategy_list_login_time'] = '首次登录时间';