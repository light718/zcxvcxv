<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['btn_control_proxy'] = '控制代理';
$lang['btn_control_player'] = '控制玩家';

$lang['title'] = '点控';
$lang['sub_title'] = '控制直属代理或某一具体玩家的概率';
$lang['search_title'] = '操作记录（不可修改）';
$lang['control_proxy_title'] = '控制代理';
$lang['control_proxy_sub_title01'] = '选择要控制的代理';
$lang['control_proxy_sub_title02'] = '只能控制你的直属代理';
$lang['control_proxy_username_nickname'] = '账号';
$lang['control_proxy_username_nickname_tips'] = '可不填';

$lang['control_player_title'] = '控制玩家';
$lang['control_player_sub_title01'] = '选择要控制的用户';
$lang['control_player_sub_title02'] = '所有的用户不论属于哪一级代理都可以控制';
$lang['control_player_username'] = 'ID';
$lang['control_player_username_tips'] = '至少输入4位';

$lang['handle_title'] = '点控设置';

$lang['setting_time_status_normal'] = '生效中';
$lang['setting_time_status_pass'] = '已过期';

$lang['table_column_date_time'] = '设定时间与日期';
$lang['table_column_date'] = '日期';
$lang['table_column_operated_username'] = '账号';
$lang['table_column_nickname'] = '名字';
$lang['table_column_setting_prob'] = '设定';
$lang['table_column_setting_time'] = '时长设定';
$lang['table_column_add_coin'] = '7日上分';
$lang['table_column_sub_coin'] = '7日下分';
$lang['table_column_win_coin'] = '7日输赢';
$lang['table_column_username'] = '账号';
$lang['table_column_current_prob'] = '点控状态（24小时）';
$lang['table_column_handle'] = '操作';

$lang['action_username'] = '账号';
$lang['action_nickname'] = '名字';
$lang['action_setting_prob'] = '点控设定（维持24小时）';
$lang['action_setting_time'] = '有效期';
$lang['action_setting_time_minutes'] = '分钟';
$lang['notice01'] = '对代理操作时将会对代理旗下所有的用户以及其下级代理的用户生效';
$lang['notice02'] = '对用户操作时将会覆盖其上级代理的概率操作（用户操作优先）';
$lang['notice03'] = '';//'必须为本次操作指定有效时长，最大1440分钟（24小时）';
$lang['notice04'] = '一旦操作无法修改或撤回';
$lang['notice05'] = '但后续对于同一ID的操作，可以覆盖本次操作（后操作优先）';

$lang['prob_1'] = '稳赢';
$lang['prob_2'] = '赢';
$lang['prob_3'] = '自动';
$lang['prob_4'] = '小输';
$lang['prob_5'] = '稳输';

$lang['return_error_01'] = '请输入时长';
$lang['return_error_02'] = '最大时长不能超过1440分钟';
$lang['return_error_03'] = '至少输入4位';

$lang['batch_handle_title'] = '批量操作';
$lang['batch_handle_number'] = '被操作代理 / 玩家数量';
$lang['batch_handle_list'] = '被操作代理 / 玩家列表';
$lang['notice06'] = '批量操作将会同时对上表中的所有代理 / 玩家生效。';
$lang['vip_0'] = '显示所有用户';
$lang['vip_1'] = '仅显示VIP用户';