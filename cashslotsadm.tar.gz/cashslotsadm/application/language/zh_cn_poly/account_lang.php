<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = '代理管理';
$lang['account_title'] = '账号管理';
$lang['sub_title'] = '你的直属代理';
$lang['btn_add_account'] = '添加代理';
$lang['agent_list'] = '代理列表';
$lang['parent_agent'] = '上级代理';
$lang['subaccount_list'] = '子帐号列表';
$lang['refresh_list'] = '刷新代理列表';
$lang['agent_list_menu'] = '代理列表菜单';
$lang['player_list_menu'] = '玩家列表菜单';
$lang['set_score_log'] = '进分记录';

$lang['table_column_username'] = '账号';
$lang['table_column_nickname'] = '名字';
$lang['table_column_coin'] = '分数';
$lang['table_column_time'] = '日期时间';
$lang['table_column_coin_change'] = '设定分数';
$lang['table_column_coin_change_before'] = '之前分数';
$lang['table_column_coin_change_after'] = '之后分数';
$lang['table_column_permission'] = '开启功能';
$lang['table_column_from_username'] = '进分账号';
$lang['table_column_to_username'] = '被进分账号';
$lang['table_column_ip'] = '操作IP';


// 新增代理
$lang['add_title'] = '新增代理';
$lang['add_agent_title'] = '新增代理';
$lang['add_sub_title'] = '新增一个你的直属代理';
$lang['username'] = '账号';
$lang['password'] = '密码';
$lang['nickname'] = '名字';
$lang['username_tips'] = '下级代理商用于登录本后台的代理ID，无法修改';
$lang['password_tips'] = '下级代理商用于登录本后台的密码，他自己可以修改';
$lang['nickname_tips'] = '只有你能看到的昵称，下级代理自己不会看到这个设定';
$lang['add_notice01'] = '代理商一旦创建，无法删除，但是可以禁用';
$lang['add_notice02'] = '注意！';
$lang['add_notice03'] = '代理ID无法修改！！';
$lang['add_notice04'] = '你可以协助下级代理重新设定他的密码';
$lang['add_notice05'] = '你可以随时修改下级代理的昵称';
$lang['add_success'] = '成功新增代理';
$lang['add_success_message'] = '代理账号 {%username%} 已创建！<br>可通过浏览器访问 {%url%}。<br>用户名：{%username%}<br>密码：{%password%}';
$lang['add_success_notice'] = '将上面的文字贴给你的代理，邀请他们登录后台立即开始一起赚钱吧';
$lang['add_btn_save'] = '新增';
$lang['add_btn_close'] = '关闭';
$lang['add_empty'] = '请输入完整的信息';
$lang['username_empty'] = '账号必须填写';
$lang['password_empty'] = '密码必须填写';
$lang['nickname_empty'] = '名字必须填写';

// 编辑代理
$lang['edit_title'] = '编辑帐号';
$lang['loginip_title'] = '代理登录IP设置';
$lang['loginip_subtitle'] = '登录IP设置';

// 上下分记录
$lang['coin_record_title'] = '进分记录';
$lang['coin_record_username'] = '账号';
$lang['coin_record_nickname'] = '名字';
$lang['coin_record_total_coin'] = '总进分';
$lang['coin_record_column_time'] = '日期时间';
$lang['coin_record_column_change_coin'] = '设定分数';
$lang['coin_record_column_before_coin'] = '之前分数';
$lang['coin_record_column_after_coin'] = '之后分数';

// 上下分
$lang['change_coin_title'] = '进分';
$lang['add_coin'] = '上分';
$lang['sub_coin'] = '下分';
$lang['recent_record'] = '最近10条进分记录';

// 禁用代理
$lang['status_title'] = '禁用代理';
$lang['status_notice01'] = '禁用代理将会';
$lang['status_notice02'] = '禁用代理及其所有子账号，并踢下线';
$lang['status_notice03'] = '禁用代理其下所有玩家，并踢下线';
$lang['status_notice04'] = '禁用代理其下的所有下级代理';
$lang['status_notice05'] = '解除代理禁用状态';
$lang['status_btn_forbidden'] = '禁用并踢下线';
$lang['status_btn_normal'] = '解除禁用';

// 子账号管理
$lang['subaccount_title'] = '子账号管理';
$lang['subaccount_title_tips'] = '协助你进行日常管理工作的账号';
$lang['subaccount_btn_add'] = '添加子账号';
$lang['subaccount_btn_edit'] = '编辑子账号';
$lang['subaccount_tips_01'] = '子账号ID只能使用英文字母和数字 5～30位';
$lang['subaccount_tips_011'] = '密码只能使用英文字母和数字 5～30位';
$lang['subaccount_tips_02'] = '使用子账号ID登录时不区分大小写';
$lang['subaccount_tips_03'] = '用于登录本后台的密码，他自己可以修改';
$lang['subaccount_tips_04'] = '昵称仅对你可见，用户自身无法看到自己的昵称';
$lang['subaccount_tips_05'] = '权限（可多选）';
$lang['subaccount_tips_06'] = '子账号将回到登录界面，在解除禁用前无法登录';
$lang['subaccount_tips_07'] = '解除子账号禁用状态';
$lang['subaccount_username'] = '账号';
$lang['subaccount_nickname'] = '子账号昵称';
$lang['subaccount_table_title'] = '子帐号列表 - 最多设定5个子帐号';
$lang['subaccount_desc'] = '功能描述-description';
$lang['subaccount_permission_0_title'] = '查游戏记录和进出分记录';
$lang['subaccount_permission_1_title'] = '是否开启查账';
$lang['subaccount_permission_2_title'] = '是否可以进分';
$lang['subaccount_permission_3_title'] = '是否可以新开帐号';
$lang['subaccount_permission_4_title'] = '是否可以禁用/解禁帐号';
$lang['subaccount_permission_5_title'] = '是否可以编辑帐号';
$lang['subaccount_permission_6_title'] = '是否可以禁用/解禁子帐号';
$lang['subaccount_permission_7_title'] = '总代报表';
$lang['subaccount_permission_8_title'] = '小游戏开关';
$lang['subaccount_permission_9_title'] = '小游戏排序';
$lang['subaccount_permission_10_title'] = '游戏统计';

// 总代报表
$lang['general_agent_report_title'] = '总代报表';
$lang['general_agent_report_title_tips'] = '结算报表';
$lang['general_agent_report_total_add_coin'] = '总上分';
$lang['general_agent_report_total_sub_coin'] = '总下分';
$lang['general_agent_report_total_diff_coin'] = '上下分差';
$lang['table_column_agent_total_add_coin'] = '代理总上分';
$lang['table_column_agent_total_sub_coin'] = '代理总下分';
$lang['table_column_player_total_add_coin'] = '玩家总上分';
$lang['table_column_player_total_sub_coin'] = '玩家总下分';
$lang['table_column_bigbang'] = 'Bigbang';

// 分级查询
$lang['level_search_title'] = '分级查询';
$lang['level_search_title_tips'] = '各个级别的代理的活跃状况查询';
$lang['level_search_btn_condition_01'] = '1小时数据';
$lang['level_search_btn_condition_02'] = '24小时数据';
$lang['level_search_btn_condition_03'] = '7天数据';
$lang['level_search_btn_condition_04'] = '30天数据';
$lang['table_column_au'] = 'AU';
$lang['table_column_bets'] = '注金';
$lang['level_search_btn_parent'] = '上级';
$lang['level_search_btn_expand'] = '展开';

$lang['agent_general_tips'] = '他的直属玩家以及他的直属代理的输赢状况';

$lang['comfirm_forbidden'] = '确认禁用账号？';
$lang['comfirm_offline'] = '确认解禁账号？';
$lang['agent_total_report'] = '代理总账';