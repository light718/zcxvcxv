<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['user_name'] = '账号';
$lang['order_id'] = '订单id';
$lang['order_uid'] = 'UID';
$lang['order_title'] = '产品';
$lang['order_price'] = '价格';
$lang['order_status'] = '状态';
$lang['order_platform'] = '平台';
$lang['order_createtime'] = '下单时间';
$lang['order_paytime'] = '支付时间';
$lang['order_notifytime'] = '发货时间';