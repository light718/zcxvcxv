<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = 'RummySlots';
$lang['title_root_agent'] = 'RummySlots';
$lang['title_general_agent'] = 'RummySlots';
$lang['username'] = 'ID';
$lang['password'] = 'Password';
$lang['vercode'] = 'Verification code';
$lang['login'] = 'Login';
$lang['captcha_empty'] = 'captcha can not empty';
$lang['captcha_error'] = 'captcha is wrong';
$lang['username_empty'] = 'Agent ID can not empty';
$lang['username_password_error'] = 'Agent ID or Password is wrong';
$lang['login_ip_error'] = 'The account is not allowed to log in to this IP';
$lang['login_forbidden'] = 'Account has been disabled, please contact administrator to unlock';
$lang['password_empty'] = 'Verification code is not empty';
$lang['login_success'] = 'Login Success';
$lang['chinese'] = 'Chinese';
$lang['english'] = 'English';
$lang['select'] = 'Please select a language';

$lang['account_lock'] = 'Cannot login，wait {%seconds%} and try again';