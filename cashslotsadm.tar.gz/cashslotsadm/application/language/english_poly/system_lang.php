<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['player_login_log_title'] = 'Player Login Log';
$lang['player_login_log_uid'] = 'UID';
$lang['player_login_log_pid'] = 'Player ID';
$lang['player_login_log_time'] = 'Time';

$lang['state_player_title'] = '人数留存统计';
$lang['state_player_date'] = '日期';
$lang['state_player_dnu'] = 'DNU';
$lang['state_player_dau'] = 'DAU';
$lang['state_player_arpu'] = 'ARPU';
$lang['state_player_arppu'] = 'ARPPU';
$lang['state_player_ordernum'] = '充值笔数';
$lang['state_player_payrate'] = '付费率';
$lang['state_player_paynum'] = '付费人数';
$lang['state_player_payamount'] = '付费金额';
$lang['state_player_payagainnum'] = '多次付费人数';
$lang['state_player_payagainamount'] = '多次付费金额';
$lang['state_player_payfirstnum'] = '第1次付费人数';
$lang['state_player_payfirstamount'] = '第1次付费金额';
$lang['state_player_stay1'] = '次留 ';
$lang['state_player_stay3'] = '3留';
$lang['state_player_stay7'] = '7留';
$lang['state_player_stay14'] = '14留';
$lang['state_player_stay30'] = '30留';
$lang['state_player_ltv1'] = '当日ltv';
$lang['state_player_ltv3'] = '3日ltv';
$lang['state_player_ltv7'] = '7日ltv';
$lang['state_player_ltv14'] = '14日ltv';
$lang['state_player_ltv30'] = '30日ltv';

$lang['state_gamedetail_title'] = '新用户游戏数据回报率';
$lang['state_date'] = '日期';
$lang['state_gamedetail_gameid'] = '游戏ID';
$lang['state_gamedetail_alltimes'] = '总次数';
$lang['state_gamedetail_allusers'] = '总人数';
$lang['state_gamedetail_allbet'] = '总下注';
$lang['state_gamedetail_allwin'] = '总赢钱';

$lang['state_reward_act'] = '奖励类型';
$lang['state_reward_allusers'] = '总人数';
$lang['state_reward_allcoin'] = '总金币';
$lang['state_reward_allcost'] = '金币价值';

$lang['state_online_allusers'] = '总人数';
$lang['state_online_stype'] = '在线时长类型';
$lang['state_online_avgcoin'] = '金币平均值';

$lang['state_level_allusers'] = '人数';
$lang['state_level_avgcoin'] = '金币价值';
$lang['state_level_times'] = '总破产次数';
$lang['state_level_recharge'] = '充值总额';
$lang['state_level_type'] = '等级区间';

$lang['state_order_shopid'] = '订单商品id';
$lang['state_order_shopname'] = '商品名称';
$lang['state_order_shopprice'] = '商品价格';
$lang['state_order_uid'] = 'UID';
$lang['state_order_userlevel'] = '用户等级';
$lang['state_order_usercoin'] = '用户金币';
$lang['state_order_time'] = '下单时间';

$lang['state_order_date'] = '日期';
$lang['state_order_allusers'] = '总人数';
$lang['state_order_allamount'] = '总金额';

$lang['state_shopitem_id'] = '商品ID';
$lang['state_shopitem_title'] = '商品名';
$lang['state_shopitem_total'] = '订单数';
$lang['state_shopitem_price'] = '总金额';

$lang['state_shoprenew_user1'] = '当日充值人数';
$lang['state_shoprenew_user2'] = '次日充值人数';
$lang['state_shoprenew_user3'] = '3日充值人数';
$lang['state_shoprenew_user4'] = '4日充值人数';
$lang['state_shoprenew_user5'] = '5日充值人数';
$lang['state_shoprenew_user6'] = '6日充值人数';
$lang['state_shoprenew_user7'] = '7日充值人数';
$lang['state_shoprenew_user8'] = '8日充值人数';
$lang['state_shoprenew_user9'] = '9日充值人数';
$lang['state_shoprenew_user10'] = '10日充值人数';
$lang['state_shoprenew_amount1'] = '当日充值金额';
$lang['state_shoprenew_amount2'] = '次日充值金额';
$lang['state_shoprenew_amount3'] = '3日充值金额';
$lang['state_shoprenew_amount4'] = '4日充值金额';
$lang['state_shoprenew_amount5'] = '5日充值金额';
$lang['state_shoprenew_amount6'] = '6日充值金额';
$lang['state_shoprenew_amount7'] = '7日充值金额';
$lang['state_shoprenew_amount8'] = '8日充值金额';
$lang['state_shoprenew_amount9'] = '9日充值金额';
$lang['state_shoprenew_amount10'] = '10日充值金额';

$lang['state_leveldist_title'] = '等级分布';
$lang['state_leveldist_num'] = '人数';
$lang['state_leveldist_rate'] = '比例';
$lang['state_coindist_title'] = '金币分布';
$lang['state_rechargedist_title'] = '充值金额分布';

$lang['state_gamedist_title'] = '游戏名称';
$lang['state_gamedist_num'] = '人数';
$lang['state_gamedist_rate'] = '百分比';

$lang['state_gamelist_uid'] = 'UID';
$lang['state_gamelist_coin'] = '金币';
$lang['state_gamelist_level'] = '等级';
$lang['state_gamelist_price'] = '商城金额';
$lang['state_gamelist_createtime'] = '注册时间';
$lang['state_gamelist_logintime'] = '最后登录时间';
$lang['state_gamelist_gametitle'] = '最后游戏';
$lang['state_gamelist_gametime'] = '最后游戏时间';

$lang['agent_list_title'] = 'Agent List';
$lang['agent_list_column_username'] = 'Agent ID';
$lang['agent_list_column_nickname'] = 'Nickname';
$lang['agent_list_column_parent_agent'] = 'Parent ID';
$lang['agent_list_column_first_agent'] = 'First Agent ID';
$lang['agent_list_column_coin'] = 'Coin';
$lang['agent_list_column_create_time'] = 'Register Time';
$lang['agent_list_column_last_login_time'] = 'Last Login Time';

$lang['agent_score_log_title'] = 'Agent Score Log';
$lang['agent_score_log_column_username'] = 'Agent ID';
$lang['agent_score_log_column_nickname'] = 'Nickname';
$lang['agent_score_log_column_coin'] = 'Coins Change';
$lang['agent_score_log_column_before'] = 'Before Change';
$lang['agent_score_log_column_after'] = 'After Change';
$lang['agent_score_log_column_create_time'] = 'Time';

$lang['player_game_log_title'] = 'Player Game Log';
$lang['player_game_log_game_name'] = 'Game Name';
$lang['player_game_log_type'] = 'Bet or  Win';
$lang['player_game_log_coin'] = 'Coins Change';
$lang['player_game_log_coin_before'] = 'Before Change';
$lang['player_game_log_coin_after'] = 'After Change';
$lang['player_game_log_time'] = 'Time';

$lang['system_win_title'] = 'System win/lose';
$lang['system_win_date'] = 'Date';
$lang['system_win_sysout'] = 'Sys reload';
$lang['system_win_sysin'] = 'Sys withdraw';
$lang['system_win_player'] = 'Player total coin';
$lang['system_win_agent'] = 'Agent total coin';

$lang['player_ip_title'] = 'Query Player LoginIP';
$lang['player_ip_tips'] = 'Last 10.';

$lang['player_win_column_id'] = 'UID';
$lang['player_win_column_name'] = 'ID';
$lang['player_win_nickname'] = 'Nickname';
$lang['player_win_total'] = 'Total win/lose';
$lang['player_win_reload'] = 'Total reload';
$lang['player_win_ratio'] = 'Ratio';
$lang['player_win_select_all'] = 'all player';
$lang['player_win_select_control'] = 'controlled player';
$lang['player_win_select_not_control'] = 'no controlled player';

$lang['player_list_title'] = 'Player List';
$lang['player_list_column_id'] = 'UID';
$lang['player_list_column_pid'] = 'PlayerID';
$lang['player_list_column_nickname'] = 'Nickname';
$lang['player_list_column_coin'] = 'score';
$lang['player_list_column_online'] = 'Online State';
$lang['player_list_column_status_ban'] = 'Account State';
$lang['player_list_column_create_time'] = 'Add Time';
$lang['player_list_column_last_login_time'] = 'last login time';

$lang['operation_log_title'] = 'Operation log';
$lang['operation_log_column_id'] = '#';
$lang['operation_log_column_admin_id'] = 'ID';
$lang['operation_log_column_admin_username'] = 'Username';
$lang['operation_log_column_ip'] = 'IP';
$lang['operation_log_column_os'] = 'System';
$lang['operation_log_column_browser'] = 'Browser';
$lang['operation_log_column_menu'] = 'Menu';
$lang['operation_log_column_detail'] = 'Description';
$lang['operation_log_column_create_time'] = 'DateTime';
$lang['operation_log_tips'] = 'Show last 1000 {%username%} operation log.ok[{%username%}].';

$lang['red_envelope'] = 'Red envelope';

$lang['tax_empty_title'] = 'Tax empty log';
$lang['tax_empty_column_id'] = 'ID';
$lang['tax_empty_column_oin'] = 'Coin';
$lang['tax_empty_column_create_time'] = 'Time';