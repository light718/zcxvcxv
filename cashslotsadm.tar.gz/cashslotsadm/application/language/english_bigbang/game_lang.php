<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = 'Game Setting';
$lang['sub_title'] = 'Setting of the game configuration management';
$lang['consume_coin'] = 'Commission';
$lang['consume_coin_tips'] = 'Commission per bet';
$lang['history_consume_coin'] = 'Commission history';
$lang['today_consume_coin'] = 'Commission today';
$lang['seven_day_consume_coin'] = 'Commission recent 7 days';
$lang['month_consume_coin'] = 'Commission month';
$lang['history_add_coin'] = 'Reload history';
$lang['history_sub_coin'] = 'Withdraw history';
$lang['history_total_coin'] = 'Total credit difference';

$lang['consume_coin_title'] = 'Commission Setting';
$lang['consume_coin_sub_title'] = 'Commission setting by every betting from player';
$lang['consume_coin_ratio'] = 'Commission rate';
$lang['consume_coin_ratio_tips'] = 'Commission from players every betting, 0.0 ~ 100.0';
$lang['consume_coin_max'] = 'Commission limit';
$lang['consume_coin_max_tips'] = 'System will stop getting commission when reach the commission limit.';
$lang['consume_coin_pospar'] = 'Table game commission rate';
$lang['consume_coin_pospar_tips'] = 'Table game get commission from system win.';
$lang['cur_consume_coin_ratio'] = 'Current commission rate';
$lang['cur_consume_coin_max_setting'] = 'Current commission limit';
$lang['cur_consume_coin'] = 'Current commission';
$lang['cur_normal'] = 'Current normal pool';
$lang['btn_empty_normal'] = 'Clear';
$lang['empty_normal_tips'] = 'Confirm to clear the pond？';

$lang['reset_time_interval'] = 'Time reset';
$lang['reset_time_interval_tips01'] = 'System will stop getting commission when reach the commission limit';
$lang['reset_time_interval_tips02'] = 'Time reset range: 60 - 43200 minute (1 hour - 30 days)';
$lang['next_time_interval'] = 'Time remaining';

$lang['jackpot_title'] = 'Jackpot Setting';
$lang['jackpot'] = 'Jackpot';
$lang['jackpot_tips'] = 'Jackpot for slots and fish game.';
$lang['jackpot_setting'] = 'Pool limit';
$lang['jackpot_setting_tips'] = 'Jackpot will drop after reaches the pool limit.';
$lang['jackpot_limit_tips_01'] = 'Minimum limit cannot be greater then maximum limit.';
$lang['jackpot_limit_tips_02'] = '1.0～100.0';
$lang['jackpot_limit_max'] = 'Maximum limit';
$lang['jackpot_limit_min'] = 'Minimum limit';
$lang['jackpot_cur_pos'] = 'Current pool';
$lang['jackpot_btn_record'] = 'Jackpot drop history';
$lang['jackpot_base_tips'] = 'Jackpot display of all slots and fish game according to this setting.';
$lang['jackpot_base'] = 'Jackpot Display Setting';
$lang['jackpot_change_tips_01'] = 'Jackpot fluctuation according to players betting frequency.';
$lang['jackpot_change_tips_02'] = '';
$lang['jackpot_change'] = 'Jackpot Fluctuation Setting';
$lang['jackpot_decline_tips'] = 'Jackpot display drop frequency.';
$lang['jackpot_decline_time_interval'] = 'Drop time';
$lang['jackpot_decline_ratio'] = 'Drop rate';
$lang['jackpot_ratio'] = 'Jackpot accumulation rate';
$lang['jackpot_ratio_tips'] = 'All slots and fish game from player every betting will collect a percentage to accumulate the jackpot pool 0.0～100.0%';

$lang['packet'] = 'Red envelope setting';
$lang['packet_tips'] = 'Player will get red envelope when finish the credit and go back to game lobby.';
$lang['packet_total_award'] = 'Red envelope total send';
$lang['packet_status'] = 'Status';
$lang['packet_status_tips'] = 'Sending or stop will not change the setting';
$lang['packet_status_open'] = 'Sending';
$lang['packet_status_close'] = 'Stop';
$lang['packet_max'] = 'Maximum limit';
$lang['packet_min'] = 'Minimum limit';
$lang['packet_limit_tips'] = 'Red envelope amount limit, setting minimum greater then maximum will be unable to send.';
$lang['packet_condition_coin'] = 'Players credit less then';
$lang['packet_condition_seven_coin'] = '7 days diffrence';
$lang['packet_condition_tips_01'] = 'Player will only get red envelope when meet the following condition.';
$lang['packet_condition_tips_02'] = '7 days credit difference: player total reload minus total witdraw.';
$lang['packet_send_condition'] = 'Send red evelope when player reach credit';
$lang['packet_send_condition_tips'] = '';
$lang['packet_seven_coin'] = 'Player 7 days credit diffrence';
$lang['packet_btn_record'] = 'History';
$lang['packet_btn_open'] = 'Send';
$lang['packet_btn_close'] = 'Stop';

$lang['vip'] = 'VIP Player Setting';
$lang['vip_tips'] = 'VIP players are marked by the number of credit.';
$lang['vip_standard'] = 'VIP Standard';
$lang['vip_base_tips'] = 'After reaches the VIP standard, player will be certify to VIP Player.';
$lang['vip_base'] = 'VIP standard';

$lang['notice_01'] = 'Positive number：system wins ; Negative number：system loss';
$lang['notice_02'] = 'System will stop getting commission when reach the commission limit.';
$lang['notice_03'] = 'Commission will reset when reach the time limit.';
$lang['notice_04'] = 'After press the [SET] button, commission will be reset to current setting.';
$lang['notice_05'] = 'Player only receive 1 red envelope every 24 hours.';
$lang['notice_06'] = 'After press the [SET] button, all system will be reset to your current setting.';
$lang['notice_07'] = 'After press the [SET] button, system will not reset VIP Player.';
$lang['notice_08'] = 'VIP player will only reset after player reload.';

$lang['client_notice_title'] = 'Announcement';
$lang['client_notice_sub_title'] = 'Pop-up announcements that will be seen when your  player logs into the game';
$lang['client_notice_tips'] = 'Content';
$lang['client_notice_error'] = 'Content is up to 100 words';

$lang['system_notice_title'] = 'System announcement configuration';
$lang['system_notice_sub_title'] = 'Announcements that can be seen at welcome after the all agents go online.';

// 跑马灯
$lang['marquee_title'] = 'signboard setting';
$lang['marquee_title_tips'] = 'Configure the signboard announcement in the game';
$lang['marquee_btn_all'] = 'All announcement';
$lang['marquee_btn_open'] = 'Effective  Announcement';
$lang['marquee_btn_cancel'] = 'Cancel Annoucement';
$lang['marquee_btn_add'] = 'New Announcement';
$lang['marquee_btn_detail'] = 'detail';
$lang['marquee_column_add_time'] = 'add time';
$lang['marquee_column_content'] = 'announcement text';
$lang['marquee_column_open_time'] = 'effective time';
$lang['marquee_column_status'] = 'effective status';
$lang['marquee_column_hz'] = 'announvement frequency';
$lang['marquee_status'] = 'status';
$lang['marquee_status_open'] = 'effective';
$lang['marquee_status_cancel'] = 'recall';
$lang['marquee_status_complete'] = 'done';

$lang['marquee_add_title'] = 'New announcement';
$lang['marquee_add_title_tips'] = 'Signboard added';
$lang['marquee_add_start_time'] = 'Start time';
$lang['marquee_add_send_times'] = 'The number of announce';
$lang['marquee_add_send_times_unit'] = 'times';
$lang['marquee_add_send_times_tips_01'] = 'The same announcement can be sent only once at the specified time.';
$lang['marquee_add_send_times_tips_02'] = 'Repeat the same announcement (1 to 99) multiple times from this time.';
$lang['marquee_add_send_space_time'] = 'interval';
$lang['marquee_add_send_space_time_unit'] = 'minutes';
$lang['marquee_add_send_space_time_tips_01'] = 'Only valid for more than one announcement, and repeated once every few minutes';
$lang['marquee_add_send_space_time_tips_02'] = 'Send interval support 1 to 60 minutes';
$lang['marquee_add_content'] = 'Announcement content';
$lang['marquee_add_content_tips'] = 'The announcement content is up to 200 words';
$lang['marquee_add_notice_01'] = 'Once the announcement is sent, it cannot be changed!';
$lang['marquee_add_notice_01'] = 'Announcements that have not been sent can be withdrawn, but cannot be guranteed !';
$lang['marquee_status'] = 'Announcement status';
$lang['marquee_status_00'] = 'Waitting';
$lang['marquee_status_10'] = 'Effective';
$lang['marquee_status_20'] = 'Done';
$lang['marquee_status_30'] = 'Recall';

$lang['marquee_detail_title'] = 'Annoucenment details';
$lang['marquee_detail_title_tips'] = 'View the specific configuration of an announcement. You can withdraw it , If the announcement is still in effect.';
$lang['marquee_detail_notice'] = 'The announcement revocation function is only valid for announcements that have not yet been issued. For example, an announcement has been sent 2 times, and 3 times have not been sent. The withdrawal function has the opportunity to terminate the remaining 3 transmissions.';

// Poly大奖池（Poly Jackpot）
$lang['bigbang_title'] = 'BIGBANG Jackpot Setting';
$lang['bigbang_title_tips'] = 'As a prize pool for systematic activities';
$lang['bigbang_today_total_award'] = 'Today drop';
$lang['bigbang_seven_day_total_award'] = 'Recent 7 days drop';
$lang['bigbang_three_month_total_award'] = 'Recent 3 months drop';
$lang['bigbang_column_time'] = 'Time';
$lang['bigbang_jackpot_username'] = 'Player ID';
$lang['bigbang_first_proxy_username'] = 'Agent ID';
$lang['bigbang_first_proxy_nickname'] = 'Agent nickname';
$lang['bigbang_award_coin'] = 'Amount';
$lang['bigbang_award_status'] = 'Drop status';
$lang['bigbang_award_status_waitting'] = 'Pending';
$lang['bigbang_award_status_success'] = 'Success';
$lang['bigbang_award_status_fail'] = 'Fail';

$lang['bigbang_jackpot_title'] = 'Poly Jackpot Drop';
$lang['bigbang_jackpot_open_username'] = 'Player ID';
$lang['bigbang_jackpot_seven_day_total_add_coin'] = 'Recent 7 days reload';
$lang['bigbang_jackpot_seven_day_total_sub_coin'] = 'Recent 7 days withdraw';
$lang['bigbang_jackpot_award_range'] = 'Amount range';
$lang['bigbang_jackpot_award'] = 'Drop amount';
$lang['bigbang_jackpot_notice_01'] = 'After press the [DROP] button, system will drop BBJP within 1 minute, player must be remain betting, otherwise the BBJP drop will be cancel.';
$lang['bigbang_jackpot_notice_02'] = 'Confirm drop?';

$lang['bigbang_setting_title'] = 'BIGBANG Jackpot Setting';
$lang['bigbang_setting_title_tips'] = 'BIGBANG jackpot display setting';
$lang['bigbang_setting_base_value'] = 'Poly Display Setting';
$lang['bigbang_setting_base_value_tips'] = 'BBJP display of all slots and fish game according to this setting.';
$lang['bigbang_setting_change_value'] = 'Jackpot Fluctuation Setting';
$lang['bigbang_setting_change_value_tips_01'] = 'BBJP fluctuation according to players betting frequency.';
$lang['bigbang_setting_decline_time_interval'] = 'Drop time';
$lang['bigbang_setting_decline_ratio'] = 'Drop rate';
$lang['bigbang_setting_decline_tips'] = 'BBJP display drop frequency according to the setting below.';
$lang['bigbang_setting_notice'] = 'After press the [SET] button, all system will be reset to your current setting.';

$lang['return_error_01'] = 'Commission rate interval range is 0.0 ~ 100.0';
$lang['return_error_02'] = 'Time reset interval range is 60 ~ 43200 minutes';
$lang['return_error_03'] = 'Jackpot maximum limit interval range 1.0 ~ 100.0';
$lang['return_error_04'] = 'Jackpot minimum limit interval range 1.0 ~ 100.0';
$lang['return_error_05'] = 'Red Envelope maximum limit interval range 1 ~ 100';
$lang['return_error_06'] = 'Red Envelope minimum limit interval range 1 ~ 100';
$lang['return_error_07'] = 'Times Error';
$lang['return_error_08'] = 'Interval Error';
$lang['return_error_09'] = 'Content Wrong';
$lang['return_error_10'] = 'Players credit less interval range 0.00 ~ 5.00';
$lang['return_error_11'] = '7 days credit diffrence interval not less than 5';
$lang['return_error_12'] = 'Table game commission rate interval range is 0.0 ~ 100.0';
$lang['return_error_13'] = 'Commission limit interval range is 1.00 ~ 999,999,999,999.99';
$lang['return_error_14'] = 'Pool limit interval range is 10,000.00 ~ 999,999,999,999.99';
$lang['return_error_15'] = 'Commission limit interval range is 1.00 ~ 999,999,999,999.99';
$lang['return_error_16'] = 'Jackpot accumulation rate interval range is 0.0 ~ 100.0%';
$lang['return_error_17'] = 'Jackpot Display Setting interval range is 1,000.00 ~ 999,999,999,999.99';
$lang['return_error_18'] = 'Jackpot Fluctuation Setting interval range is -100.00 ~ 100.00';
$lang['return_error_19'] = 'Drop time interval range is 3 ~ 1440';
$lang['return_error_20'] = 'Drop rate interval range is 1.0 ~ 65.0%';
$lang['return_error_21'] = 'VIP Standard interval range is 100.00 ~ 999,999,999.99';
$lang['return_error_22'] = 'Table game commission rate interval range is 0.0 ~ 100.0';
$lang['return_error_22'] = 'Drop amount rate interval range is 10.00 ~ 10,000.00';
$lang['return_error_24'] = 'Red envelope max is greater than the min';

$lang['game_switch_title'] = 'Game Switch';
$lang['game_switch_status_normal'] = 'Nromal';
$lang['game_switch_status_off'] = 'Game is off';
$lang['game_switch_uid_whitelist'] = 'UID whitelist';
$lang['game_switch_content'] = 'Close server notice';
$lang['game_switch_tips'] = 'English comma separated uid';
$lang['game_switch_tips_01'] = 'Confirm open service？';
$lang['game_switch_tips_02'] = 'Confirm close service？';

$lang['game_status'] = 'Open or Close Game';
$lang['game_status_column_id'] = 'GameID';
$lang['game_status_column_name'] = 'GameName';
$lang['game_status_column_status'] = 'Current state';
$lang['game_status_normal'] = 'Normal';
$lang['game_status_close'] = 'Closed';
$lang['game_status_btn_open'] = 'Open Game';
$lang['game_status_btn_close'] = 'Close Game';
$lang['game_status_tips_01'] = 'Confirm open this game';
$lang['game_status_tips_02'] = 'Confirm close this game';

$lang['server_list'] = 'Server List';
$lang['server_list_type'] = 'Type';
$lang['server_list_name'] = 'Name';
$lang['server_list_status'] = 'state';
$lang['server_list_status_start'] = 'start';
$lang['server_list_status_run'] = 'run';
$lang['server_list_status_full'] = 'full';
$lang['server_list_status_weihu'] = 'weihu';
$lang['server_list_status_stop'] = 'stop';
$lang['server_list_btn_close_server'] = 'Closed serve';
$lang['server_list_tips_01'] = 'Confirm close this serve？';

$lang['game_switch_total_online'] = 'Total online number';

$lang['major'] = 'MAJOR';
$lang['major_setting'] = 'MAJOR setting';
$lang['minor'] = 'MINOR';
$lang['minor_setting'] = 'MINOR setting';
$lang['major_base_value'] = 'Display the base value';
$lang['major_decline_rate'] = 'Decline rate';
$lang['major_falling_interval'] = 'Falling interval';
$lang['major_fluctuation'] = 'Fluctuation';