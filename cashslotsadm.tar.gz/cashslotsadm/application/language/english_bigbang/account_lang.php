<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = 'Agent Management';
$lang['sub_title'] = 'Direct agent';
$lang['btn_add_account'] = 'Add agent';
$lang['agent_list'] = 'Agent list';
$lang['parent_agent'] = 'Parent ID';
$lang['subaccount_list'] = 'Agent-sub list';

$lang['table_column_username'] = 'Agent ID';
$lang['table_column_nickname'] = 'Nickname';
$lang['table_column_coin'] = 'Credit balance';
$lang['table_column_time'] = 'Time';
$lang['table_column_coin_change'] = 'Reload/Withdraw';
$lang['table_column_coin_change_before'] = 'Before score';
$lang['table_column_coin_change_after'] = 'After score';
$lang['table_column_permission'] = 'Authority';
$lang['table_column_last_login'] = 'Last time log in';


// 新增代理
$lang['add_title'] = 'new agent';
$lang['add_sub_title'] = 'Add new direct agent';
$lang['username'] = 'Agent ID';
$lang['password'] = 'Password';
$lang['nickname'] = 'Nickname';
$lang['upcoin'] = 'Coin';
$lang['username_tips'] = 'Agent ID cannot be modified.';
$lang['password_tips'] = 'Agent password can be modified.';
$lang['nickname_tips'] = 'Only the nickname you can see, the subordinate agent will not see this setting.';
$lang['upcoin_tips'] = 'Add points to Agent';
$lang['add_notice01'] = 'Once the agent is created, it cannot be deleted, but it can be disabled.';
$lang['add_notice02'] = 'Caution !';
$lang['add_notice03'] = 'ID cannot be modified! !';
$lang['add_notice04'] = 'You can assist the subordinate agent to reset his password.';
$lang['add_notice05'] = 'You can modify the nickname of the subordinate agent at any time.';
$lang['add_success'] = 'Agent create successful';
$lang['add_success_message'] = 'Account {%username%} has been created!<br>Access {%url%} by a Browser.<br>User name: {%username%} <br>Password: {%password%}';
$lang['add_success_notice'] = 'Paste the above text to your agent and invite them.';
$lang['add_btn_save'] = 'Add';
$lang['add_btn_close'] = 'Close';
$lang['add_empty'] = 'Please enter the complete information';
$lang['add_success_tips'] = '代理账号 {%username%} 已创建';
$lang['username_empty'] = 'Account cannot be empty';
$lang['password_empty'] = 'Password cannot be empty';
$lang['nickname_empty'] = 'Name cannot be empty';

// 编辑代理
$lang['edit_title'] = 'Edit Agent';

// 上下分记录
$lang['coin_record_title'] = 'Score Log';
$lang['coin_record_username'] = 'Agent ID';
$lang['coin_record_nickname'] = 'Agent nickname';
$lang['coin_record_total_coin'] = 'Total credit diff';
$lang['coin_record_column_time'] = 'Time';
$lang['coin_record_column_change_coin'] = 'Score';
$lang['coin_record_column_before_coin'] = 'Before score';
$lang['coin_record_column_after_coin'] = 'After score';

// 上下分
$lang['change_coin_title'] = 'Score log';
$lang['add_coin'] = 'Reload';
$lang['sub_coin'] = 'Withdraw';
$lang['recent_record'] = '10 Recent score log';

// 禁用代理
$lang['status_title'] = 'Disable agent';
$lang['status_notice01'] = 'Disabled agent will';
$lang['status_notice02'] = 'Disabled agent and all its sub-accounts will be kick off and unabe to log in. ';
$lang['status_notice03'] = 'Disabled agent`s player will be kick off and unabe to log in. ';
$lang['status_notice04'] = 'All agent under this disabled agent are unable to log in.';
$lang['status_notice05'] = 'Enable agent ID';
$lang['status_btn_forbidden'] = 'Disable and kick off';
$lang['status_btn_normal'] = 'Enable';

// 子账号管理
$lang['subaccount_title'] = 'Agent-sub account management';
$lang['subaccount_title_tips'] = 'An account to assists you with your daily management';
$lang['subaccount_btn_add'] = 'Add sub-account';
$lang['subaccount_btn_edit'] = 'Edit';
$lang['subaccount_tips_01'] = 'Sub-account ID only can use by 5-30 digit with  alphabets and numbers.';
$lang['subaccount_tips_011'] = 'Password only can use by 5-30 digit with  alphabets and numbers.';
$lang['subaccount_tips_02'] = 'Login with sub-account ID is not case sensitive.';
$lang['subaccount_tips_03'] = 'Agent password can be modified.';
$lang['subaccount_tips_04'] = 'Sub-account nickname only visible to you.';
$lang['subaccount_tips_05'] = 'Authority ( multi selection )';
$lang['subaccount_tips_06'] = 'The sub-account will return to the login screen and will not be able to log in until the disabling is disabled.';
$lang['subaccount_tips_07'] = 'Enable sub-account';
$lang['subaccount_permission_5_title'] = 'Finance';
$lang['subaccount_permission_5_desc'] = 'Agent inquiry: query direct agent information and audit.';
$lang['subaccount_permission_6_title'] = 'Agent Management';
$lang['subaccount_permission_6_desc'] = 'Add and manage direct agents.';
$lang['subaccount_permission_7_title'] = 'Control';
$lang['subaccount_permission_7_desc'] = 'query user information and control probability.';
$lang['subaccount_permission_8_title'] = 'Agent inquiry';
$lang['subaccount_permission_8_desc'] = 'query direct agent information and audit.';
$lang['subaccount_permission_9_title'] = 'Agent Management';
$lang['subaccount_permission_9_desc'] = 'Add and manage direct agents.';
$lang['subaccount_permission_10_title'] = 'Player inquiry';
$lang['subaccount_permission_10_desc'] = 'query direct agent information and audit.';
$lang['subaccount_permission_11_title'] = 'Player Management';
$lang['subaccount_permission_11_desc'] = 'Add and manage direct players.';
$lang['subaccount_username'] = 'Sub-account ID';
$lang['subaccount_nickname'] = 'Nickname';

// 总代报表
$lang['general_agent_report_title'] = 'Agent report';
$lang['general_agent_report_title_tips'] = 'Statement';
$lang['general_agent_report_total_add_coin'] = 'Total reload';
$lang['general_agent_report_total_sub_coin'] = 'Total withdraw';
$lang['general_agent_report_total_diff_coin'] = 'Total difference';
$lang['table_column_agent_total_add_coin'] = 'Agent total reload';
$lang['table_column_agent_total_sub_coin'] = 'Agent total withdraw';
$lang['table_column_player_total_add_coin'] = 'Player total reload';
$lang['table_column_player_total_sub_coin'] = ' Player total withdraw';
$lang['table_column_bigbang'] = 'Bigbang';

// 分级查询
$lang['level_search_title'] = 'Hierarchical query';
$lang['level_search_title_tips'] = 'Active status query for all agents';
$lang['level_search_btn_condition_01'] = '1 hour data';
$lang['level_search_btn_condition_02'] = '24 hours data';
$lang['level_search_btn_condition_03'] = '7 days data';
$lang['level_search_btn_condition_04'] = '30 days data';
$lang['table_column_au'] = 'AU';
$lang['table_column_bets'] = 'Bet';
$lang['level_search_btn_parent'] = 'Superior';
$lang['level_search_btn_expand'] = 'Expand';

$lang['agent_general_tips'] = 'The winning status of his players and his agent';

$lang['comfirm_forbidden'] = 'Are you sure?';
$lang['comfirm_offline'] = 'Are you sure?';
$lang['agent_total_report'] = 'Agent total report';