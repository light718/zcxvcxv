<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['title'] = 'Poly Admin Login';
$lang['title_root_agent'] = 'Poly Admin Login';
$lang['title_general_agent'] = 'Poly Agent Login';
$lang['username'] = 'Agent ID';
$lang['password'] = 'Password';
$lang['vercode'] = 'Verification code';
$lang['login'] = 'Login';
$lang['captcha_empty'] = 'captcha can not empty';
$lang['captcha_error'] = 'captcha is wrong';
$lang['username_empty'] = 'Agent ID can not empty';
$lang['username_password_error'] = 'Agent ID or Password is wrong';
$lang['login_forbidden'] = 'Login forbidden';
$lang['password_empty'] = 'Verification code is not empty';
$lang['login_success'] = 'Login Success';
$lang['chinese'] = 'Chinese';
$lang['english'] = 'English';
$lang['select'] = 'Please select a language';

$lang['account_lock'] = 'Cannot login，wait {%seconds%} and try again';