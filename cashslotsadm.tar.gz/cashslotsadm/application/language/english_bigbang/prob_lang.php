<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['btn_control_proxy'] = 'Control agent';
$lang['btn_control_player'] = 'Control player';

$lang['title'] = 'Probability control';
$lang['sub_title'] = 'Control the probability of a direct agent or a specific player';
$lang['search_title'] = 'Operation record (not modifiable)';
$lang['control_proxy_title'] = 'Control agent';
$lang['control_proxy_sub_title01'] = 'Select the agent to control';
$lang['control_proxy_sub_title02'] = 'Only can control your direct agent';
$lang['control_proxy_username_nickname'] = 'ID / Nickname';
$lang['control_proxy_username_nickname_tips'] = "Don`t fill in";

$lang['control_player_title'] = 'Control player';
$lang['control_player_sub_title01'] = 'Key-in player id to control';
$lang['control_player_sub_title02'] = 'All users can control regardless of which level of agent ';
$lang['control_player_username'] = 'ID';
$lang['control_player_username_tips'] = 'Enter at least 4 digits';

$lang['handle_title'] = 'Operate';

$lang['setting_time_status_normal'] = 'effective';
$lang['setting_time_status_pass'] = 'expired';

$lang['table_column_date_time'] = 'Control time';
$lang['table_column_date'] = 'Date';
$lang['table_column_operated_username'] = 'id been controled';
$lang['table_column_nickname'] = 'Nickname';
$lang['table_column_setting_prob'] = 'Set probability';
$lang['table_column_setting_time'] = 'Set duration';
$lang['table_column_add_coin'] = '7 days reload';
$lang['table_column_sub_coin'] = '7 days withdraw';
$lang['table_column_win_coin'] = '7 days win';
$lang['table_column_username'] = 'ID';
$lang['table_column_current_prob'] = 'Current probability';
$lang['table_column_handle'] = 'Control';

$lang['action_username'] = 'ID';
$lang['action_nickname'] = 'Nickname';
$lang['action_setting_prob'] = 'Set probability';
$lang['action_setting_time'] = 'Effective duration';
$lang['action_setting_time_minutes'] = 'minutes';
$lang['notice01'] = 'For the agent operation, it will take effect for all players of the agent and players of its direct agents.';
$lang['notice02'] = 'Probabilistic operation that overrides its superior agent when the user operates (user operation takes precedence)';
$lang['notice03'] = 'A valid duration must be specified for this operation, maximum 1440 minutes (24 hours)';
$lang['notice04'] = 'Once operate, cannot be modified or recall';
$lang['notice05'] = 'subsequent operations on the same player can override this operation (post-operation priority)';

$lang['prob_1'] = 'Big win';
$lang['prob_2'] = 'Small win';
$lang['prob_3'] = 'Auto';
$lang['prob_4'] = 'Small lose';
$lang['prob_5'] = 'Big lose';

$lang['return_error_01'] = 'duration can not empty';
$lang['return_error_02'] = 'The duration should not exceed 1440 minutes';
$lang['return_error_03'] = '至少输入4位';

$lang['batch_handle_title'] = 'Batch operate';
$lang['batch_handle_number'] = 'Operated Agent/Player quantity';
$lang['batch_handle_list'] = 'Operated Agent/Player list';
$lang['notice06'] = 'Above agent/player will be operate';
$lang['vip_0'] = 'Show all player';
$lang['vip_1'] = 'Show all VIP player';